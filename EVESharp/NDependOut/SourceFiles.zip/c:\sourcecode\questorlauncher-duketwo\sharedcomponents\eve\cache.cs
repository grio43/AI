﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 07.03.2014
 * Time: 15:50
 *
 * ---------------------------------------
 */

using SharedComponents.Utility;
using SharedComponents.Utility.AsyncLogQueue;
using SharedComponents.IPC;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace SharedComponents.EVE
{
    /// <summary>
    ///     Description of Cache.
    /// </summary>
    public class Cache
    {
        #region Delegates

        public delegate void IsShuttingDownDelegate();

        #endregion Delegates

        #region Constructors

        private Cache()
        {
        }

        #endregion Constructors

        #region Destructors

        ~Cache()
        {
            Interlocked.Decrement(ref CacheInstances);
        }

        #endregion Destructors

        #region Events

        public static event IsShuttingDownDelegate IsShuttingDownEvent;

        #endregion Events

        #region Fields

        public static int CacheInstances;

        public static bool IsServer = false;

        public static bool IsShuttingDown = false;

        public SerializeableSortableBindingList<EveAccount> EveAccountSerializeableSortableBindingList;

        public SerializeableSortableBindingList<EveSetting> EveSettingsSerializeableSortableBindingList;

        private static readonly object _asyncLogQueueLock = new object();
        private static readonly Cache _instance = new Cache();

        private static readonly object initLock = new object();
        private static AsyncLogQueue _asyncLogQueue;
        private static volatile bool _isInitialized;
        private string _assemblyPath;

        private string _getLogFileName;

        private CancellationTokenSource ts;

        #endregion Fields

        #region Properties

        public static AsyncLogQueue AsyncLogQueue
        {
            get
            {
                lock (_asyncLogQueueLock)
                {
                    if (_asyncLogQueue == null)
                        _asyncLogQueue = new AsyncLogQueue();
                    return _asyncLogQueue;
                }
            }
        }

        public static Cache Instance
        {
            get
            {
                if (IsServer && !_isInitialized)
                    _instance.LoadSettingsFromPersistentStorage();
                return _instance;
            }
        }

        public string AssemblyPath
        {
            get
            {
                if (_assemblyPath == null)
                    _assemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                return _assemblyPath;
            }
        }

        public string EveLocation => Instance.EveSettings.EveDirectory;

        public EveSetting EveSettings
        {
            get
            {
                if (!IsServer)
                    return WCFClient.Instance.GetPipeProxy.GetEVESettings();

                if (!EveSettingsSerializeableSortableBindingList.List.Any())
                    EveSettingsSerializeableSortableBindingList.List.Add(new EveSetting("C:\\eveoffline\\bin\\exefile.exe", DateTime.MinValue));
                return EveSettingsSerializeableSortableBindingList.List[0];
            }
        }

        public void ClearCache()
        {
            Cache.Instance.EveSharpCoreCompileTime = null;
            Cache.Instance.EveSharpLauncherCompileTime = null;
        }

        private DateTime? _eveSharpCoreCompileTime = null;

        public DateTime? EveSharpCoreCompileTime
        {
            get
            {
                try
                {
                    if (_eveSharpCoreCompileTime == null)
                    {
                        _eveSharpCoreCompileTime = File.GetLastWriteTime(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "EVESharpCore.exe"));
                        if (_eveSharpCoreCompileTime != null)
                            return (DateTime)_eveSharpCoreCompileTime;

                        return DateTime.MinValue;
                    }

                    return (DateTime)_eveSharpCoreCompileTime;
                }
                catch (Exception)
                {
                    return DateTime.MinValue;
                }
            }
            set => _eveSharpCoreCompileTime = value;
        }

        private DateTime? _eveSharpLauncherCompileTime;

        public DateTime? EveSharpLauncherCompileTime
        {
            get
            {
                try
                {
                    if (_eveSharpLauncherCompileTime == null)
                    {
                        _eveSharpLauncherCompileTime = File.GetLastWriteTime(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "EVESharpLauncher.exe"));
                        if (_eveSharpLauncherCompileTime != null)
                            return (DateTime)_eveSharpLauncherCompileTime;

                        return DateTime.MinValue;
                    }

                    return (DateTime)_eveSharpLauncherCompileTime;
                }
                catch (Exception)
                {
                    return DateTime.MinValue;
                }
            }
            set => _eveSharpLauncherCompileTime = value;
        }

        public string FirefoxLocation => Instance.EveSettings.FireFoxDirectory;
        public bool IsMainFormMinimized { get; set; }

        public long MainFormHWnd { get; set; }

        private string GetLogFileName
        {
            get
            {
                if (string.IsNullOrEmpty(_getLogFileName))
                {
                    string dir = Instance.AssemblyPath + "\\Logs";
                    string fileName = dir + "\\Injector.log";
                    if (!Directory.Exists(dir))
                        Directory.CreateDirectory(dir);
                    _getLogFileName = fileName;
                }
                return _getLogFileName;
            }
        }

        #endregion Properties

        #region Methods

        public static void BroadcastShutdown()
        {
            IsShuttingDownEvent?.Invoke();
        }

        public bool AnyAccountsLinked(bool verbose = false)
        {
            bool linksFound = false;
            IEnumerable<EveAccount> list = Instance.EveAccountSerializeableSortableBindingList.List.Where(a => a != null && a.HWSettings != null);
            List<EveAccount> links = new List<EveAccount>();
            foreach (EveAccount eA in list)
            {
                if (links.Contains(eA))
                    continue;

                IEnumerable<EveAccount> t = list.Where(a => a != eA && a.HWSettings.CheckEquality(eA.HWSettings));
                if (t.Any())
                    foreach (EveAccount r in t)
                    {
                        linksFound = true;
                        if (verbose)
                            Instance.Log($"{eA.CharacterName} is linked with {r.CharacterName}");
                        links.Add(r);
                        links.Add(eA);
                    }
            }

            if (verbose && !linksFound)
                Instance.Log("No linked accounts were found.");

            return linksFound;
        }

        public void CreateBackupXMLFiles()
        {
            // save the backup  here "AcccountData.xml.bak" , "EveSettings.xml.bak"
            EveAccountSerializeableSortableBindingList.List.XmlSerialize(EveAccountSerializeableSortableBindingList.FilePathName + ".bak");
            EveSettingsSerializeableSortableBindingList.List.XmlSerialize(EveSettingsSerializeableSortableBindingList.FilePathName + ".bak");
        }

        public void InitTokenSource()
        {
            if (ts == null)
            {
                ts = new CancellationTokenSource();
                Task.Run(() =>
                {
                    while (!ts.Token.IsCancellationRequested && !IsShuttingDown)
                    {
                        int d = 300000;
                        ts.Token.WaitHandle.WaitOne(d);
                        try
                        {
                            if (!_isInitialized)
                                continue;

                            lock (initLock)
                            {
                                foreach (EveAccount e in EveAccountSerializeableSortableBindingList.List)
                                {
                                    DateTime now = DateTime.UtcNow;
                                    DateTime dt = e.StartingTokenTime;
                                    if (dt.Year != now.Year || dt.Month != now.Month || dt.Day != now.Day)
                                    {
                                        e.StartingTokenTime = now;
                                        e.StartingTokenTimespan = TimeSpan.Zero;
                                    }
                                    if (e.EveProcessExists())
                                        e.StartingTokenTimespan = e.StartingTokenTimespan.Add(TimeSpan.FromMilliseconds(d));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.ToString());
                        }
                    }
                }, ts.Token);
            }
        }

        public void LoadSettingsFromPersistentStorage()
        {
            if (_isInitialized)
                return;

            lock (initLock)
            {
                if (_isInitialized)
                    return;

                _isInitialized = true;

                if (!IsServer)
                    return;

                InitTokenSource();

                string accountDataXML = "AcccountData.xml";
                string eveSettingsXML = "EveSettings.xml";
                string questorLauncherSettingsPath = AssemblyPath + "\\EVESharpSettings\\";
                string accountDataXMLWithPath = questorLauncherSettingsPath + accountDataXML;
                string eveSettingsXMLWithPath = questorLauncherSettingsPath + eveSettingsXML;
                string accountDataXMLWithPathDefunct = questorLauncherSettingsPath + accountDataXML + ".defunct";
                string eveSettingsXMLWithPathDefunct = questorLauncherSettingsPath + eveSettingsXML + ".defunct";
                string accountDataXMLWithPathBackup = questorLauncherSettingsPath + accountDataXML + ".bak";
                string eveSettingsXMLWithPathBackup = questorLauncherSettingsPath + eveSettingsXML + ".bak";

                try
                {
                    EveAccountSerializeableSortableBindingList = new SerializeableSortableBindingList<EveAccount>(accountDataXMLWithPath, 30000, true, 60000);
                    EveSettingsSerializeableSortableBindingList = new SerializeableSortableBindingList<EveSetting>(eveSettingsXMLWithPath, 30000, true, 60000);
                }
                catch (Exception e)
                {
                    // try to load the previous saved backup here
                    // if exists, delete "AcccountData.xml.defunct", "EveSettings.xml.defunct"
                    // move "AcccountData.xml", "EveSettings.xml" to "AcccountData.xml.defunct", "EveSettings.xml.defunct"
                    // copy ..  "AcccountData.xml.bak" ->  "AcccountData.xml"
                    // copy ..  "EveSettings.xml.bak" ->  "EveSettings.xml"

                    Console.WriteLine(e);
                    MessageBox.Show(e.ToString(), "Error!");
                    Log(e.ToString());
                    if (File.Exists(accountDataXMLWithPathBackup) && File.Exists(eveSettingsXMLWithPathBackup))
                        try
                        {
                            if (File.Exists(accountDataXMLWithPathDefunct))
                                File.Delete(accountDataXMLWithPathDefunct);

                            if (File.Exists(eveSettingsXMLWithPathDefunct))
                                File.Delete(eveSettingsXMLWithPathDefunct);

                            File.Move(accountDataXMLWithPath, accountDataXMLWithPathDefunct);
                            File.Move(eveSettingsXMLWithPath, eveSettingsXMLWithPathDefunct);

                            File.Copy(accountDataXMLWithPathBackup, accountDataXMLWithPath);
                            File.Copy(eveSettingsXMLWithPathBackup, eveSettingsXMLWithPath);

                            EveAccountSerializeableSortableBindingList = new SerializeableSortableBindingList<EveAccount>(accountDataXMLWithPath, 30000, true, 60000);
                            EveSettingsSerializeableSortableBindingList = new SerializeableSortableBindingList<EveSetting>(eveSettingsXMLWithPath, 30000, true, 60000);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex);
                            throw new Exception("Couldn't load the xml files. Even the backup xml files are faulty.");
                        }
                    else
                        throw new Exception("Couldn't load the xml files. There aren't any backup xml files.");
                }

                CreateBackupXMLFiles();
            }
        }

        public void Log(string text, Color? col = null, [CallerMemberName] string memberName = "")
        {
            if (!IsServer)
                return;

            try
            {
                //OnMessage?.Invoke("[" + String.Format("{0:dd-MMM-yy HH:mm:ss:fff}", DateTime.UtcNow) + "] [" + memberName + "] " + text.ToString(), col);
                AsyncLogQueue.File = GetLogFileName;
                AsyncLogQueue.Enqueue(new LogEntry(text, memberName, col));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        #endregion Methods
    }
}