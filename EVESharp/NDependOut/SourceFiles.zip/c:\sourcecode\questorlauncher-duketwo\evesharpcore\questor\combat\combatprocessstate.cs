﻿using System;
using System.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.States;

namespace EVESharpCore.Questor.Combat
{
    public static partial class Combat
    {
        #region Fields

        private static EntityCache _killTarget;

        private static EntityCache killTarget
        {
            get
            {
                try
                {
                    if (_killTarget == null)
                        _killTarget = PickPrimaryWeaponTarget();

                    return _killTarget;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        #endregion Fields

        #region Methods

        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetAbyssalDeadSpace;
        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetTriglavianInvasion;

        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetWspaceDreadnaught;
        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetWspace;
        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard;
        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank;
        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetBasedOnTargetsForABattleship;
        private static IOrderedEnumerable<EntityCache> _pickWhatToLockNextBasedOnTargetsForABattleship;
        private static IOrderedEnumerable<EntityCache> _pickWhatToLockNextBasedOnTargetsForLowValueTargets;
        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetBasedOnTargetsForAFrigate;
        private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetBasedOnTargetsForBurners;
        //private static IOrderedEnumerable<EntityCache> _pickPrimaryWeaponTargetFleetAbyssalDeadSpace;

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetWSpaceDreadnaught
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetWspaceDreadnaught == null)
                    {
                        _pickPrimaryWeaponTargetWspaceDreadnaught = Combat.PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.Name.Contains("Arithmos Tyrannos"))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && j.IsTrackable && j.IsInOptimalRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && j.IsTrackable && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && j.IsTrackable && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattleship && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && j.IsTrackable && j.IsInOptimalRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && j.IsTrackable && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && j.IsTrackable && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsBattlecruiser && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsTrackable && j.IsInOptimalRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsTrackable && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.IsTrackable && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsPlayer && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable)
                            .ThenByDescending(j => j.IsNPCBattleship && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable)
                            .ThenByDescending(j => j.IsNPCCruiser && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCCruiser)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable)
                            .ThenByDescending(j => j.IsNPCFrigate && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCFrigate)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsTrackable)
                            .ThenByDescending(j => j.HealthPct < 100)
                            .ThenBy(p => p.StructurePct)
                            .ThenBy(q => q.ArmorPct)
                            .ThenBy(r => r.ShieldPct);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetWspaceDreadnaught);

                        return _pickPrimaryWeaponTargetWspaceDreadnaught;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetWspaceDreadnaught;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetWSpace
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetWspace == null)
                    {
                        _pickPrimaryWeaponTargetWspace = Combat.PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.IsNpcCapitalEscalation && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                            .ThenByDescending(j => j.Name.Contains("Arithmos Tyrannos"))
                            .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable)
                            .ThenByDescending(j => j.IsNPCBattleship && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable)
                            .ThenByDescending(j => j.IsNPCCruiser && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCCruiser)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable)
                            .ThenByDescending(j => j.IsNPCFrigate && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsNPCFrigate)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange)
                            .ThenByDescending(j => j.IsTrackable && j.HealthPct < 100)
                            .ThenByDescending(j => j.IsTrackable)
                            .ThenByDescending(j => j.HealthPct < 100)
                            .ThenBy(p => p.StructurePct)
                            .ThenBy(q => q.ArmorPct)
                            .ThenBy(r => r.ShieldPct);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetWspace);

                        return _pickPrimaryWeaponTargetWspace;
                    }

                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetWspace;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetTriglavianInvasion
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetTriglavianInvasion == null)
                    {
                        _pickPrimaryWeaponTargetTriglavianInvasion = PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderBy(j => j.IsNPCCapitalShip)
                            .ThenByDescending(j => !j.IsEntityEngagedByMyOtherToons)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct && k.IsDroneKillTarget)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && !k.IsAttacking)
                            .ThenByDescending(k => k.IsNPCBattlecruiser)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && !l.IsAttacking)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCFrigate)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsMissileDisruptingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && !l.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser)
                            .ThenByDescending(j => j.IsNPCBattleship && 100 > j.HealthPct && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.WeShouldFocusFire && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(j => j.IsNPCBattleship && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                            .ThenBy(p => p.StructurePct)
                            .ThenBy(q => q.ArmorPct)
                            .ThenBy(r => r.ShieldPct);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetTriglavianInvasion);

                        return _pickPrimaryWeaponTargetTriglavianInvasion;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetTriglavianInvasion;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetTriglavianInvasionObeservatory
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetTriglavianInvasion == null)
                    {
                        _pickPrimaryWeaponTargetTriglavianInvasion = PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderBy(j => j.IsNPCCapitalShip)
                            .ThenByDescending(j => !j.IsEntityEngagedByMyOtherToons)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct && k.IsDroneKillTarget)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && !k.IsAttacking)
                            .ThenByDescending(k => k.IsNPCBattlecruiser)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && !l.IsAttacking)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCFrigate)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsMissileDisruptingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && !l.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser)
                            .ThenByDescending(j => j.IsNPCBattleship && 100 > j.HealthPct && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.WeShouldFocusFire && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(j => j.IsNPCBattleship && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                            .ThenBy(p => p.StructurePct)
                            .ThenBy(q => q.ArmorPct)
                            .ThenBy(r => r.ShieldPct);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetTriglavianInvasion);

                        return _pickPrimaryWeaponTargetTriglavianInvasion;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetTriglavianInvasion;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetAbyssalDeadSpace
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetAbyssalDeadSpace == null)
                    {
                        _pickPrimaryWeaponTargetAbyssalDeadSpace = PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                            .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                            //.ThenByDescending(j => j.IsNPCBattleship && !Drones.DronesKillHighValueTargets && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                            //.ThenByDescending(j => j.IsNPCBattlecruiser && !Drones.DronesKillHighValueTargets && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                            .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                            .ThenByDescending(j => j.IsNPCCruiser && j.WeShouldFocusFire && 100 > j.HealthPct)
                            .ThenByDescending(j => j.IsNPCCruiser && j.WeShouldFocusFire && j.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCCruiser && j.WeShouldFocusFire)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct && k.IsDroneKillTarget)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct)
                            .ThenByDescending(k => k.IsNPCBattlecruiser)
                            .ThenByDescending(l => !l.WeShouldFocusFire && !l.IsDroneKillTarget)
                            //.ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                            .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsMissileDisruptingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                            .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted()).ThenByDescending(o => o != Combat.killTarget && o.IsNPCFrigate)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsMissileDisruptingMe && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCCruiser)
                            .ThenByDescending(i => !i.Name.ToLower().Contains("karybdis tyrannos".ToLower()))
                            .ThenByDescending(j => j.IsNPCBattleship && 100 > j.HealthPct)
                            .ThenByDescending(j => j.IsNPCBattleship && j.WeShouldFocusFire)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsHighDps)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(i => i.IsEntityIShouldKeepShooting);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetAbyssalDeadSpace);

                        return _pickPrimaryWeaponTargetAbyssalDeadSpace;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetAbyssalDeadSpace;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetAbyssalDeadSpaceDronesKillHighValueTargets
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetAbyssalDeadSpace == null)
                    {
                        _pickPrimaryWeaponTargetAbyssalDeadSpace = PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                            .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && ESCache.Instance.ActiveShip.IsActiveTanked)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct && k.IsDroneKillTarget)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && 100 > k.HealthPct)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && !k.IsAttacking)
                            .ThenByDescending(k => k.IsNPCBattlecruiser)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && !l.IsAttacking)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCFrigate)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsMissileDisruptingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && !l.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser)
                            .ThenByDescending(j => j.IsNPCBattleship && 100 > j.HealthPct && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.WeShouldFocusFire && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(j => j.IsNPCBattleship && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                            .ThenBy(p => p.StructurePct)
                            .ThenBy(q => q.ArmorPct)
                            .ThenBy(r => r.ShieldPct);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetAbyssalDeadSpace);

                        return _pickPrimaryWeaponTargetAbyssalDeadSpace;
                    }
                }
                catch (Exception ex)
                {

                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetAbyssalDeadSpace;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard == null)
                    {
                        _pickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard = Combat.PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe && 100 > l.HealthPct)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsWithinOptimalOfDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && l.IsCloseToDrones)
                            .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire)
                            .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsMissileDisruptingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && !l.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted()).ThenByDescending(o => o != Combat.killTarget && o.IsNPCFrigate)
                            .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsMissileDisruptingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && !l.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCCruiser && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCCruiser)
                            .ThenByDescending(j => j.IsNPCBattleship && 100 > j.HealthPct && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.WeShouldFocusFire && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsHighDps && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe && !j.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && !l.IsDroneKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(j => j.IsNPCBattleship && !j.IsDroneKillTarget)
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                            .ThenBy(p => p.StructurePct)
                            .ThenBy(q => q.ArmorPct)
                            .ThenBy(r => r.ShieldPct);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard);

                        return _pickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank
        {
            get
            {
                try
                {
                    if (_pickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank == null)
                    {
                        _pickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank = Combat.PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                            .OrderByDescending(l => !l.WeShouldFocusFire && !l.IsDroneKillTarget)
                            .ThenByDescending(l => l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                            .ThenByDescending(j => j.IsNPCBattlecruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                            .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                            .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                            .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                            .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600 && j.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600)
                            .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800 && j.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                            .ThenByDescending(l => l.IsNPCBattleship && l.StructurePct < 90)
                            .ThenByDescending(l => l.IsNPCBattleship && l.ArmorPct < 90)
                            .ThenByDescending(l => l.IsNPCBattleship && l.ShieldPct < 90)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                            .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsHighDps)
                            .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(j => j.IsNPCBattleship)
                            .ThenByDescending(l => l.IsNPCBattlecruiser && l.StructurePct < 90)
                            .ThenByDescending(l => l.IsNPCBattlecruiser && l.ArmorPct < 90)
                            .ThenByDescending(l => l.IsNPCBattlecruiser && l.ShieldPct < 90)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasRemoteRepair)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsSensorDampeningMe)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsWebbingMe)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasNeutralizers)
                            .ThenByDescending(j => j.IsNPCBattlecruiser && j.IsHighDps)
                            .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(k => k.IsNPCBattlecruiser)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsMissileDisruptingMe)
                            .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                            .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                            .ThenByDescending(l => l.IsNPCCruiser && l.StructurePct < 90 && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.ArmorPct < 90 && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.ShieldPct < 90 && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.StructurePct < 90)
                            .ThenByDescending(l => l.IsNPCCruiser && l.ArmorPct < 90)
                            .ThenByDescending(l => l.IsNPCCruiser && l.ShieldPct < 90)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                            .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                            .ThenByDescending(l => l.IsNPCCruiser)
                            .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                            .ThenByDescending(l => l.IsNPCFrigate && l.StructurePct < 90 && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.ArmorPct < 90 && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.ShieldPct < 90 && l.IsWebbingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.StructurePct < 90)
                            .ThenByDescending(l => l.IsNPCFrigate && l.ArmorPct < 90)
                            .ThenByDescending(l => l.IsNPCFrigate && l.ShieldPct < 90)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                            .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                            .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted()).ThenByDescending(o => o != Combat.killTarget && o.IsNPCFrigate)
                            .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                            .ThenBy(p => p.StructurePct)
                            .ThenBy(q => q.ArmorPct)
                            .ThenBy(r => r.ShieldPct);

                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank);

                        return _pickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return _pickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetBasedOnTargetsForABattleship
        {
            get
            {
                if (_pickPrimaryWeaponTargetBasedOnTargetsForABattleship == null)
                {
                    _pickPrimaryWeaponTargetBasedOnTargetsForABattleship = Combat.PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                        .OrderByDescending(j => j.IsWarpScramblingMe && ((Drones.DronesKillHighValueTargets && !j.IsHighValueTarget) || j.IsHighValueTarget))
                        //.ThenByDescending(j => !j.IsTrigger)
                        .ThenByDescending(j => j.IsPrimaryWeaponPriorityTarget && !Drones.DronesKillHighValueTargets)
                        .ThenByDescending(j => j.IsLargeCollidableWeAlwaysWantToBlowupFirst)
                        //.ThenByDescending(i => i.IsAttacking && i.IsPlayer && i.IsBattlecruiser)
                        //.ThenByDescending(i => i.IsAttacking && i.IsPlayer && i.IsBattleship)
                        //.ThenByDescending(i => i.IsAttacking && i.IsPlayer && i.IsCruiser)
                        //.ThenByDescending(i => i.IsCorrectSizeForMyWeapons && i.IsWarpScramblingMe && !i.IsLargeCollidable)
                        //.ThenByDescending(i => i.IsCorrectSizeForMyWeapons)
                        //.ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                        .ThenByDescending(i => i.IsNPCBattleship && 100 > i.HealthPct && i.IsLastTargetPrimaryWeaponsWereShooting)
                        .ThenByDescending(i => i.IsNPCBattleship && 100 > i.HealthPct)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsAttacking && i.IsInOptimalRange && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsAttacking && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsAttacking && i.IsInOptimalRange)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsTargetedBy)
                        .ThenByDescending(i => i.IsNPCBattleship)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && 100 > i.HealthPct && i.IsLastTargetPrimaryWeaponsWereShooting)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && 100 > i.HealthPct)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsAttacking && i.IsInOptimalRange && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsAttacking && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsAttacking && i.IsInOptimalRange)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsTargetedBy)
                        .ThenByDescending(i => i.IsNPCBattlecruiser)
                        .ThenByDescending(i => i.IsNPCCruiser && 100 > i.HealthPct && i.IsLastTargetPrimaryWeaponsWereShooting)
                        .ThenByDescending(i => i.IsNPCCruiser && 100 > i.HealthPct)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsAttacking && i.IsInOptimalRange && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsAttacking && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsAttacking && i.IsInOptimalRange)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsTargetedBy)
                        .ThenByDescending(i => i.IsNPCCruiser)
                        .ThenByDescending(j => j.IsLargeCollidableWeAlwaysWantToBlowupLast)
                        //If the PotentialCombatTarget is repote repairing we should prioritize that target! but we do not
                        .ThenBy(i => i.StructurePct)
                        .ThenBy(i => i.ArmorPct)
                        .ThenBy(i => i.ShieldPct);

                    if (DebugConfig.DebugLogOrderOfKillTargets)
                        LogOrderOfKillTargets(_pickPrimaryWeaponTargetBasedOnTargetsForABattleship);

                    return _pickPrimaryWeaponTargetBasedOnTargetsForABattleship;
                }

                return _pickPrimaryWeaponTargetBasedOnTargetsForABattleship;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetBasedOnTargetsForACruiser => PickPrimaryWeaponTargetBasedOnTargetsForABattleship;

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetBasedOnTargetsForAFrigate
        {
            get
            {
                if (_pickPrimaryWeaponTargetBasedOnTargetsForAFrigate == null)
                {
                    _pickPrimaryWeaponTargetBasedOnTargetsForAFrigate = Combat.PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                        .OrderByDescending(j => j.IsWarpScramblingMe && ((Drones.DronesKillHighValueTargets && j.IsLowValueTarget) || !j.IsLowValueTarget))
                        .ThenByDescending(j => j.IsPrimaryWeaponPriorityTarget && !Drones.DronesKillHighValueTargets)
                        .ThenByDescending(j => j.IsDronePriorityTarget && Drones.DronesKillHighValueTargets)
                        .ThenByDescending(i => i.IsTrackable && i.IsInOptimalRange && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsTrackable && i.IsInOptimalRange && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsTrackable && i.IsInOptimalRange && i.ShieldPct < 90)
                        .ThenByDescending(i => i.IsTrackable && i.IsInOptimalRange)
                        .ThenByDescending(i => i.IsTargetedBy && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsTargetedBy && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsTargetedBy && i.ShieldPct < 90)
                        .ThenByDescending(i => i.IsTargetedBy)
                        .ThenByDescending(i => i.IsAttacking && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsAttacking && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsAttacking && i.ShieldPct < 90)
                        .ThenByDescending(i => i.IsAttacking)
                        .ThenByDescending(i => i.IsTrackable && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsTrackable && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsTrackable && i.ShieldPct < 90)
                        .ThenByDescending(i => i.IsTrackable)
                        .ThenByDescending(i => i.IsInOptimalRange)
                        .ThenByDescending(i => i.IsNPCFrigate && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCFrigate && i.StructurePct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCFrigate && i.ArmorPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCFrigate && i.ShieldPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWebbingNpc)
                        .ThenByDescending(i => i.IsNPCFrigate && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCFrigate && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCFrigate)
                        .ThenByDescending(i => i.IsNPCFrigate && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsNPCFrigate && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsNPCFrigate && i.ShieldPct < 90)
                        .ThenByDescending(i => i.IsNPCCruiser && i.StructurePct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCCruiser && i.ArmorPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCCruiser && i.ShieldPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWebbingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCCruiser)
                        .ThenByDescending(i => i.IsNPCCruiser && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsNPCCruiser && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsNPCCruiser && i.ShieldPct < 90)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.StructurePct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.ArmorPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.ShieldPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattlecruiser)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.ShieldPct < 90)
                        .ThenByDescending(i => i.IsNPCBattleship && i.StructurePct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattleship && i.ArmorPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattleship && i.ShieldPct < 90 && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattleship)
                        .ThenByDescending(i => i.IsNPCBattleship && i.StructurePct < 90)
                        .ThenByDescending(i => i.IsNPCBattleship && i.ArmorPct < 90)
                        .ThenByDescending(i => i.IsNPCBattleship && i.ShieldPct < 90)
                        .ThenByDescending(i => i.KillThisNeutralizingNpc)
                        .ThenBy(i => i.StructureHitPoints)
                        .ThenBy(i => i.ArmorHitPoints)
                        .ThenBy(i => i.ShieldHitPoints);

                    if (DebugConfig.DebugLogOrderOfKillTargets)
                        LogOrderOfKillTargets(_pickPrimaryWeaponTargetBasedOnTargetsForAFrigate);

                    return _pickPrimaryWeaponTargetBasedOnTargetsForAFrigate;
                }

                return _pickPrimaryWeaponTargetBasedOnTargetsForAFrigate;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetBasedOnTargetsForABurners
        {
            get
            {
                if (_pickPrimaryWeaponTargetBasedOnTargetsForBurners == null)
                {
                    _pickPrimaryWeaponTargetBasedOnTargetsForBurners = ESCache.Instance.Targets.Where(i => !i.IsWreck && !i.IsBadIdea && i.IsTarget && !i.IsNPCDrone)
                        .OrderByDescending(j => j.IsPrimaryWeaponPriorityTarget)
                        .ThenByDescending(j => j.IsDronePriorityTarget)
                        .ThenByDescending(j => j.IsBurnerMainNPC);

                    if (_pickPrimaryWeaponTargetBasedOnTargetsForBurners != null)
                    {
                        if (DebugConfig.DebugLogOrderOfKillTargets)
                            LogOrderOfKillTargets(_pickPrimaryWeaponTargetBasedOnTargetsForBurners);

                        return _pickPrimaryWeaponTargetBasedOnTargetsForBurners;
                    }

                    return null;
                }

                return null;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickPrimaryWeaponTargetFleetAbyssalDeadSpace
        {
            get
            {
                if (_pickPrimaryWeaponTargetAbyssalDeadSpace == null)
                {
                    _pickPrimaryWeaponTargetAbyssalDeadSpace = Combat.PotentialCombatTargets.Where(i => i.IsReadyToShoot)
                        .OrderByDescending(j => j.IsNPCFrigate && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                        .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                        .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                        .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                        .ThenByDescending(j => j.IsNPCBattlecruiser && j.NpcHasNeutralizers && j.IsAttacking && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                        .ThenByDescending(j => j.IsNPCBattlecruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                        .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && j.IsAttacking && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                        .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                        .ThenByDescending(j => j.IsNPCFrigate && Drones.DronesKillHighValueTargets && j.IsNeutralizingMe && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                        .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                        .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                        .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                        .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                        .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                        .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                        .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600 && j.NpcHasRemoteRepair)
                        .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600)
                        .ThenByDescending(k => k.IsAbyssalPrecursorCache)
                        .ThenByDescending(l => l.IsNPCFrigate && l.StructurePct < 90)
                        .ThenByDescending(l => l.IsNPCFrigate && l.ArmorPct < 90)
                        .ThenByDescending(l => l.IsNPCFrigate && l.ShieldPct < 90)
                        .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                        .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                        .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                        .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                        .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                        .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                        .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                        .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                        .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                        .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                        .ThenByDescending(i => i.IsNPCFrigate && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCFrigate && i.IsInOptimalRange)
                        .ThenByDescending(l => l.IsNPCCruiser && l.StructurePct < 90)
                        .ThenByDescending(l => l.IsNPCCruiser && l.ArmorPct < 90)
                        .ThenByDescending(l => l.IsNPCCruiser && l.ShieldPct < 90)
                        .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                        .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                        .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                        .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                        .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                        .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsInOptimalRange)
                        .ThenByDescending(k => k.IsNPCCruiser)
                        .ThenByDescending(j => j.IsNPCBattleship && j.IsAttacking && j.TriglavianDamage != null && j.TriglavianDamage > 800 && j.NpcHasRemoteRepair)
                        .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800 && j.NpcHasRemoteRepair)
                        .ThenByDescending(j => j.IsNPCBattleship && j.IsAttacking && j.TriglavianDamage != null && j.TriglavianDamage > 800)
                        .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800)
                        .ThenByDescending(l => l.IsNPCBattleship && l.StructurePct < 90)
                        .ThenByDescending(l => l.IsNPCBattleship && l.ArmorPct < 90)
                        .ThenByDescending(l => l.IsNPCBattleship && l.ShieldPct < 90)
                        .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                        .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                        .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                        .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                        .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                        .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsInOptimalRange)
                        .ThenByDescending(j => j.IsNPCBattleship)
                        .ThenByDescending(l => l.IsNPCBattlecruiser && l.StructurePct < 90)
                        .ThenByDescending(l => l.IsNPCBattlecruiser && l.ArmorPct < 90)
                        .ThenByDescending(l => l.IsNPCBattlecruiser && l.ShieldPct < 90)
                        .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasRemoteRepair)
                        .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsSensorDampeningMe)
                        .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsWebbingMe)
                        .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasNeutralizers)
                        .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsTargetPaintingMe)
                        .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsTrackable)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsInOptimalRange)
                        .ThenByDescending(k => k.IsNPCBattlecruiser)
                        .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                        .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                        .ThenBy(p => p.StructurePct)
                        .ThenBy(q => q.ArmorPct)
                        .ThenBy(r => r.ShieldPct);

                    if (DebugConfig.DebugLogOrderOfKillTargets)
                        LogOrderOfKillTargets(_pickPrimaryWeaponTargetAbyssalDeadSpace);

                    return _pickPrimaryWeaponTargetAbyssalDeadSpace;
                }

                return _pickPrimaryWeaponTargetAbyssalDeadSpace;
            }
        }

        public static bool CombatIsAppropriateHere()
        {
            try
            {
                if (!ESCache.Instance.InSpace || ESCache.Instance.InStation)
                    return false;

                if (ESCache.Instance.InSpace && ESCache.Instance.InWarp)
                {
                    if (DebugConfig.DebugCombat || DebugConfig.DebugTargetCombatants) Log.WriteLine("CombatIsAppropriateHere: False: if (ESCache.Instance.InSpace && ESCache.Instance.InWarp)");
                    icount = 0;
                    return false;
                }

                if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController")
                {
                    if (ESCache.Instance.Stations.Any() && ESCache.Instance.ClosestStation.Distance > 50000)
                        return true;

                    //station/Citadel is close...
                    if (!ESCache.Instance.Targets.Any() && (!PotentialCombatTargets.Any() || PotentialCombatTargets.All(i => !i.IsTargetedBy)))
                        return false; //We are probably tethered

                    return true;
                }

                if (State.CurrentHydraState == HydraState.Combat)
                    return true;

                if (State.CurrentHydraState == HydraState.Leader)
                    return true;

                if (State.CurrentWormHoleAnomalyState == WormHoleAnomalyState.Combat)
                    return true;

                if (State.CurrentWormHoleAnomalyState == WormHoleAnomalyState.Leader)
                    return true;

                if ((State.CurrentCombatState != CombatState.Idle ||
                     State.CurrentCombatState != CombatState.OutOfAmmo) &&
                    (ESCache.Instance.InStation ||
                     !ESCache.Instance.InSpace ||
                     ESCache.Instance.ActiveShip.Entity == null ||
                     ESCache.Instance.ActiveShip.Entity.IsCloaked))
                {
                    State.CurrentCombatState = CombatState.Idle;
                    if (DebugConfig.DebugCombat || DebugConfig.DebugTargetCombatants)
                        Log.WriteLine("CombatIsAppropriateHere: False: NotIdle, NotOutOfAmmo and InStation or NotInspace or ActiveShip is null or cloaked");
                    return false;
                }

                if (ESCache.Instance.InStation)
                {
                    State.CurrentCombatState = CombatState.Idle;
                    if (DebugConfig.DebugCombat || DebugConfig.DebugTargetCombatants) Log.WriteLine("CombatIsAppropriateHere: False: We are in station, do nothing");
                    return false;
                }

                if (ESCache.Instance.InsidePosForceField)
                {
                    State.CurrentCombatState = CombatState.Idle;
                    if (DebugConfig.DebugCombat || DebugConfig.DebugTargetCombatants) Log.WriteLine("CombatIsAppropriateHere: False: We are in a POS ForceField, do nothing");
                    return false;
                }

                if (ESCache.Instance.InSpace && ESCache.Instance.Citadels.Any(i => !ESCache.Instance.Targets.Any() && i.IsOnGridWithMe && 9500 > i.Distance))
                {
                    State.CurrentCombatState = CombatState.Idle;
                    if (DebugConfig.DebugCombat || DebugConfig.DebugTargetCombatants) Log.WriteLine("CombatIsAppropriateHere: False: We are probably tethered, do nothing");
                    return false;
                }

                try
                {
                    if (!ESCache.Instance.MyShipEntity.IsFrigate &&
                        !ESCache.Instance.MyShipEntity.IsCruiser &&
                        ESCache.Instance.MyShipEntity.GroupId != (int)Group.Capsule &&
                        ESCache.Instance.ActiveShip.GivenName.ToLower() != Settings.Instance.SalvageShipName.ToLower() &&
                        ESCache.Instance.ActiveShip.GivenName.ToLower() != Settings.Instance.TransportShipName.ToLower() &&
                        ESCache.Instance.ActiveShip.GivenName.ToLower() != Settings.Instance.StorylineTransportShipName.ToLower() &&
                        ESCache.Instance.ActiveShip.GivenName.ToLower() != Settings.Instance.TravelShipName.ToLower() &&
                        ESCache.Instance.ActiveShip.GivenName.ToLower() != Settings.Instance.MiningShipName.ToLower() &&
                        ESCache.Instance.ActiveShip.GroupId != (int)Group.Shuttle)
                    {
                        if (!ESCache.Instance.Weapons.Any() && ESCache.Instance.InSpace)
                        {
                            Log.WriteLine("CombatIsAppropriateHere: False: Your Current ship [" + ESCache.Instance.ActiveShip.GivenName + "] has no weapons!");
                            State.CurrentCombatState = CombatState.OutOfAmmo;
                            return false;
                        }

                        if (ESCache.Instance.MyShipEntity.GivenName.ToLower() != CombatShipName.ToLower() && !ESCache.Instance.InWormHoleSpace)
                        {
                            Log.WriteLine("CombatIsAppropriateHere: False: Your Current ship [" + ESCache.Instance.MyShipEntity.GivenName + "] GroupID [" +
                                          ESCache.Instance.MyShipEntity.GroupId + "] TypeID [" +
                                          ESCache.Instance.MyShipEntity.TypeId + "] is not the CombatShipName [" + CombatShipName + "]");
                            State.CurrentCombatState = CombatState.OutOfAmmo;
                            return false;
                        }

                        if (State.CurrentCombatState == CombatState.Idle)
                        {
                            State.CurrentCombatState = CombatState.KillTargets;
                        }
                    }

                    if (ESCache.Instance.InAbyssalDeadspace)
                        return true;

                    if (ESCache.Instance.InWormHoleSpace)
                        return true;

                    if (!ESCache.Instance.Weapons.Any() && !Drones.UseDrones)
                        return false;

                    if (!ESCache.Instance.InMission)
                    {
                        if (ESCache.Instance.EntitiesOnGrid.All(i => !i.IsTargetedBy))
                        {
                            if (DebugConfig.DebugCombat || DebugConfig.DebugTargetCombatants) Log.WriteLine("CombatIsAppropriateHere: False: if (ESCache.Instance.EntitiesOnGrid.All(i => !i.IsTargetedBy))");
                            return false;
                        }

                        if (DebugConfig.DebugCombat || DebugConfig.DebugTargetCombatants) Log.WriteLine("CombatIsAppropriateHere: True: Something has us targeted...");
                        return true;
                    }
                }
                catch (Exception exception)
                {
                    Log.WriteLine(exception.ToString());
                    return false;
                }

                return true;
            }
            catch (Exception exception)
            {
                Log.WriteLine(exception.ToString());
                return false;
            }
        }

        public static void InvalidateCache()
        {
            try
            {
                _activateBastion = null;
                _aggressed = null;
                _deActivateBastion = null;
                _doWeCurrentlyHaveProjectilesMounted = null;
                _doWeCurrentlyHaveTurretsMounted = null;
                _killTarget = null;
                _maxrange = null;
                _maxWeaponRange = null;
                _maxTargetRange = null;
                _potentialCombatTargets = null;
                _primaryWeaponPriorityTargetsPerFrameCaching = null;
                _targetedBy = null;
                _pickPrimaryWeaponTarget = null;
                _pickPrimaryWeaponTargetBasedOnTargetsForAFrigate = null;
                _pickPrimaryWeaponTargetBasedOnTargetsForBurners = null;
                //_pickPrimaryWeaponTargetBasedOnTargetsForACruiser = null;
                _pickPrimaryWeaponTargetBasedOnTargetsForABattleship = null;
                _pickPrimaryWeaponTargetAbyssalDeadSpace = null;
                _pickPrimaryWeaponTargetTriglavianInvasion = null;
                _pickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard = null;
                //_pickPrimaryWeaponTargetFleetAbyssalDeadSpace = null;
                _pickPrimaryWeaponTargetWspaceDreadnaught = null;
                _pickPrimaryWeaponTargetWspace = null;
                _pickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank = null;
                _pickWhatToLockNextBasedOnTargetsForABattleship = null;
                _pickWhatToLockNextBasedOnTargetsForLowValueTargets = null;
                _primaryWeaponPriorityEntities = null;
                _preferredPrimaryWeaponTarget = null;
                Targeting_AbyssalTargetsToLock = null;
                Targeting_TriglavianInvasionTargetsToLock = null;
                Targeting_TriglavianInvasionNestorTargetsToLock = null;
                Targeting_TriglavianInvasionLogisticsTargetsToLock = null;
                Targeting_TriglavianInvasionAntiLooterTargetsToLock = null;

                if (_primaryWeaponPriorityTargets != null && _primaryWeaponPriorityTargets.Any())
                    _primaryWeaponPriorityTargets.ForEach(pt => pt.ClearCache());
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static EntityCache ewarTarget
        {
            get
            {
                if (Drones.DronesKillHighValueTargets)
                    return Drones._cachedDroneTarget ?? killTarget;

                return killTarget;
            }
        }
        public static bool KillTargets()
        {
            //if (DateTime.UtcNow.Subtract(_lastPulse).TotalMilliseconds < 500)
            //    return false;
            //
            //_lastPulse = DateTime.UtcNow;

            if (!CombatIsAppropriateHere())
            {
                if (DebugConfig.DebugKillTargets) Log.WriteLine("KillTargets: if (!CombatIsAppropriateHere())");
                return false;
            }

            if (State.CurrentHydraState == HydraState.Leader)
            {
                if (DebugConfig.DebugKillTargets) Log.WriteLine("KillTargets: if (State.CurrentHydraState == HydraState.Leader) return true");
                return true;
            }

            if (ESCache.Instance.EveAccount.BotUsesHydra && ESCache.Instance.EveAccount.IsLeader)
                HydraController.PushAggroEntityInfo();

            try
            {
                if (NavigateOnGrid.ChooseNavigateOnGridTargets != null && NavigateOnGrid.ChooseNavigateOnGridTargets.Any())
                    if (!ESCache.Instance.InMission || ESCache.Instance.InAbyssalDeadspace)
                    {
                        if (DebugConfig.DebugNavigateOnGrid)
                            Log.WriteLine("KillTargets: NavigateIntoRange: InMission [" + ESCache.Instance.InMission + "] SpeedTank [" + NavigateOnGrid.SpeedTank + "] InAbyssalDeadspace [" + ESCache.Instance.InAbyssalDeadspace + "]");

                        NavigateOnGrid.NavigateIntoRange(NavigateOnGrid.ChooseNavigateOnGridTargets.FirstOrDefault(), "Combat", ESCache.Instance.NormalNavigation);
                    }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }

            if (!ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTarget))
            {
                if (DebugConfig.DebugKillTargets) Log.WriteLine("KillTargets: No Targets yet. waiting.");
                return false;
            }

            try
            {
                if (killTarget != null)
                {
                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("[" + icount + "] Overloading Weapons");
                    OverloadWeapons();
                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("[" + icount + "] Overloading Ecm");
                    OverloadEcm();
                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("[" + icount + "] Overloading Webs");
                    OverloadWeb();
                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("[" + icount + "] Activating Ecm");
                    ActivateEcm();
                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("[" + icount + "] Activating Tracking Disruptors");
                    ActivateTrackingDisruptors(ewarTarget);
                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("[" + icount + "] Activating Painters");
                    ActivateTargetPainters(ewarTarget);
                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("[" + icount + "] Activating SensorDampeners");
                    ActivateSensorDampeners(ewarTarget);

                    if (killTarget.IsReadyToShoot)
                    {
                        icount++;
                        if (DebugConfig.DebugKillTargets)
                            Log.WriteLine("[" + icount + "] Activating BastionAndSiegeModules");
                        ActivateBastion(DateTime.UtcNow.AddMinutes(5), false);
                        if (DebugConfig.DebugKillTargets)
                            Log.WriteLine("[" + icount + "] Activating Webs");
                        ActivateStasisWeb(ewarTarget);
                        if (DebugConfig.DebugKillTargets)
                            Log.WriteLine("[" + icount + "] Activating WarpDisruptors");
                        ActivateWarpDisruptor(ewarTarget);
                        if (DebugConfig.DebugKillTargets)
                            Log.WriteLine("[" + icount + "] Activating NOS/Neuts");
                        ActivateNos(ewarTarget);
                        if (DebugConfig.DebugKillTargets)
                            Log.WriteLine("[" + icount + "] Activating Weapons");
                        ActivateWeapons(killTarget);
                        return true;
                    }

                    if (DebugConfig.DebugKillTargets)
                        Log.WriteLine("killTarget [" + killTarget.Name + "][" + Math.Round(killTarget.Distance / 1000, 0) + "k][" +
                                      killTarget.MaskedId +
                                      "] is not yet ReadyToShoot, LockedTarget [" + killTarget.IsTarget + "] My MaxRange [" +
                                      Math.Round(MaxRange / 1000, 0) + "]");
                    return true;
                }

                if (DebugConfig.DebugKillTargets)
                    Log.WriteLine("We do not have a killTarget targeted, waiting");

                if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController")
                    return true;

                if (PrimaryWeaponPriorityTargets.Any() ||
                    PotentialCombatTargets.Any() && ESCache.Instance.Targets.Any() && (!ESCache.Instance.InMission || NavigateOnGrid.SpeedTank))
                {
                    GetBestPrimaryWeaponTarget(MaxRange, false, "Combat");
                    icount = 0;
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }
        }

        public static void ShootNPCWeAreAlreadyEngagingIfSameName()
        {
            if (_pickPrimaryWeaponTarget != null && PotentialCombatTargets != null && PotentialCombatTargets.Any())
                if (PotentialCombatTargets.Any(i => i.IsLastTargetPrimaryWeaponsWereShooting && i.IsInRangeOfWeapons && i.IsTarget && i.Name == _pickPrimaryWeaponTarget.Name && !i.WeShouldFocusFire))
                {
                    _pickPrimaryWeaponTarget = PotentialCombatTargets.FirstOrDefault(i => i.IsLastTargetPrimaryWeaponsWereShooting && i.IsInRangeOfWeapons && i.IsTarget && !i.WeShouldFocusFire);
                }
        }

        public static EntityCache _pickPrimaryWeaponTarget { get; set; }

        public static EntityCache PickPrimaryWeaponTarget()
        {
            if (_pickPrimaryWeaponTarget != null)
                return _pickPrimaryWeaponTarget;

            if (ESCache.Instance.Targets.Any(i => !i.IsContainer && !i.IsBadIdea))
            {
                if (DebugConfig.DebugPreferredPrimaryWeaponTarget || DebugConfig.DebugKillTargets)
                    if (ESCache.Instance.Targets.Any())
                        if (PreferredPrimaryWeaponTarget != null)
                            Log.WriteLine("PreferredPrimaryWeaponTarget [" + PreferredPrimaryWeaponTarget.Name + "][" +
                                          Math.Round(PreferredPrimaryWeaponTarget.Distance / 1000, 0) + "k][" +
                                          PreferredPrimaryWeaponTarget.MaskedId + "]");
                        else
                            Log.WriteLine("PreferredPrimaryWeaponTarget [ null ]");

                if (ESCache.Instance.InWormHoleSpace)
                {
                    if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.Dreadnaught)
                    {
                        if (DebugConfig.DebugTargetCombatants)
                            Log.WriteLine("DebugTargetCombatants: Targeting_WormHoleAnomaly_Dread();");
                        _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetWSpaceDreadnaught.FirstOrDefault();
                        ShootNPCWeAreAlreadyEngagingIfSameName();
                        return _pickPrimaryWeaponTarget;
                    }

                    if (DebugConfig.DebugTargetCombatants)
                        Log.WriteLine("DebugTargetCombatants: Targeting_WormHoleAnomaly();");
                    _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetWSpace.FirstOrDefault();
                    ShootNPCWeAreAlreadyEngagingIfSameName();
                    return _pickPrimaryWeaponTarget;
                }

                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    if (ESCache.Instance.EntitiesOnGrid.Any() && ESCache.Instance.EntitiesOnGrid.Any(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && i.IsTarget && i.IsInRangeOfWeapons))
                    {
                        var bioadaptivecache = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && i.IsTarget && i.IsInRangeOfWeapons);
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("IsAbyssalDeadspaceTriglavianBioAdaptiveCache found [" + bioadaptivecache.Name + "][" + bioadaptivecache.TypeId + "][" + bioadaptivecache.GroupId + "]");
                        _pickPrimaryWeaponTarget = bioadaptivecache;
                        return _pickPrimaryWeaponTarget;
                    }

                    if (ESCache.Instance.EntitiesOnGrid.Any() && ESCache.Instance.EntitiesOnGrid.Any(i => i.IsAbyssalDeadspaceTriglavianExtractionNode && i.IsTarget && i.IsInRangeOfWeapons))
                    {
                        var extractionnode = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsAbyssalDeadspaceTriglavianExtractionNode && i.IsTarget && i.IsInRangeOfWeapons);
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("IsAbyssalDeadspaceTriglavianExtractionNode found [" + extractionnode.Name + "][" + extractionnode.TypeId + "][" + extractionnode.GroupId + "]");
                        _pickPrimaryWeaponTarget = extractionnode;
                        return _pickPrimaryWeaponTarget;
                    }

                    if (Drones.DronesKillHighValueTargets)
                    {
                        try
                        {
                            if (Drones._cachedDroneTarget == null)
                                Drones.PickDroneTarget();
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                        }

                        if (Drones._cachedDroneTarget != null)
                        {
                            if (Drones._cachedDroneTarget.WeShouldFocusFire)
                            {
                                if (DebugConfig.DebugPickTargets && Drones._cachedDroneTarget.Name.Contains("Vedmak"))
                                    Log.WriteLine("DebugPickTargets: WeShouldFocusFire [" + Drones._cachedDroneTarget.WeShouldFocusFire + "]");
                                if (Drones._cachedDroneTarget.IsReadyToShoot)
                                {
                                    if (DebugConfig.DebugPickTargets && Drones._cachedDroneTarget.Name.Contains("Vedmak"))
                                        Log.WriteLine("DebugPickTargets: IsReadyToShoot [" + Drones._cachedDroneTarget.IsReadyToShoot + "]: using dronetarget [" + Drones._cachedDroneTarget.Name + "] as KillTarget");
                                    _pickPrimaryWeaponTarget = Drones._cachedDroneTarget;
                                    return _pickPrimaryWeaponTarget;
                                }
                            }
                        }
                    }

                    if (ESCache.Instance.MyShipEntity.IsFrigate || ESCache.Instance.MyShipEntity.GroupId == (int)Group.AssaultShip)
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetFleetAbyssalDeadSpace();");
                        _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetFleetAbyssalDeadSpace.FirstOrDefault(i => !i.IsWreck);
                        ShootNPCWeAreAlreadyEngagingIfSameName();
                        return _pickPrimaryWeaponTarget;
                    }

                    if (ESCache.Instance.Modules.Any(i => i.GroupId == (int)Group.Afterburner) && NavigateOnGrid.SpeedTank)
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank();");
                        return PickPrimaryWeaponTargetAbyssalDeadSpaceWhileSpeedTank.FirstOrDefault(i => !i.IsWreck); ;
                    }

                    if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs)
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard();");
                        _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetAbyssalDeadSpaceConstructionYard.FirstOrDefault(i => !i.IsWreck);
                        //ShootNPCWeAreAlreadyEngagingIfSameName();
                        return _pickPrimaryWeaponTarget;
                    }

                    if (Drones.DronesKillHighValueTargets)
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetAbyssalDeadSpaceDronesKillHighValueTargets();");
                        _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetAbyssalDeadSpaceDronesKillHighValueTargets.FirstOrDefault(i => !i.IsWreck);
                        ShootNPCWeAreAlreadyEngagingIfSameName();
                        return _pickPrimaryWeaponTarget;
                    }

                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetAbyssalDeadSpace();");
                    _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetAbyssalDeadSpace.FirstOrDefault(i => !i.IsWreck);
                    ShootNPCWeAreAlreadyEngagingIfSameName();
                    return _pickPrimaryWeaponTarget;
                }

                if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController")
                {
                    //
                    // Observatory
                    //
                    if (ESCache.Instance.AccelerationGates.Any(i => i.Name.Contains("Observatory")))
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetTriglavianInvasionObeservatory();");
                        _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetTriglavianInvasionObeservatory.FirstOrDefault(i => !i.IsWreck);
                        ShootNPCWeAreAlreadyEngagingIfSameName();
                        return _pickPrimaryWeaponTarget;
                    }

                    //
                    // All other Sites
                    //
                    //if (Drones.DronesKillHighValueTargets)
                    //{
                    //    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetAbyssalDeadSpaceDronesKillHighValueTargets();");
                    //    _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetTriglavianInvasionDronesKillHighValueTargets.FirstOrDefault(i => !i.IsWreck);
                    //    ShootNPCWeAreAlreadyEngagingIfSameName();
                    //    return _pickPrimaryWeaponTarget;
                    //}

                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("DebugTargetCombatants: PickPrimaryWeaponTargetTriglavianInvasion();");
                    _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetTriglavianInvasion.FirstOrDefault(i => !i.IsWreck);
                    ShootNPCWeAreAlreadyEngagingIfSameName();
                    return _pickPrimaryWeaponTarget;
                }

                if (State.CurrentHydraState == HydraState.Combat)
                {
                    if (ESCache.Instance.Targets.Any(i => i.Id == ESCache.Instance.EveAccount.LeaderIsAggressingTargetId))
                    {
                        _pickPrimaryWeaponTarget = ESCache.Instance.Targets.FirstOrDefault(i => i.Id == ESCache.Instance.EveAccount.LeaderIsAggressingTargetId);
                        return _pickPrimaryWeaponTarget;
                    }

                }

                //
                // Regular Behaviors: Missions / Belts / Anomalies, etc
                //

                if (ESCache.Instance.InMission)
                    if (ESCache.Instance.MyShipEntity != null)
                    {
                        if (ESCache.Instance.MyShipEntity.IsFrigate)
                        {
                            if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name.Contains("Anomic"))
                            {
                                _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetBasedOnTargetsForABurners.FirstOrDefault();
                                return _pickPrimaryWeaponTarget;
                            }

                            if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsFrigate)");
                            _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetBasedOnTargetsForAFrigate.FirstOrDefault();
                            return _pickPrimaryWeaponTarget;
                        }

                        if (ESCache.Instance.MyShipEntity.IsCruiser)
                        {
                            if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsCruiser)");
                            _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetBasedOnTargetsForACruiser.FirstOrDefault();
                            return _pickPrimaryWeaponTarget;
                        }

                        if (ESCache.Instance.MyShipEntity.IsBattleship)
                        {
                            if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsBattleship)");
                            _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetBasedOnTargetsForABattleship.FirstOrDefault();
                            ShootNPCWeAreAlreadyEngagingIfSameName();
                            return _pickPrimaryWeaponTarget;
                        }

                        //
                        // Default to picking targets for a battleship sized ship
                        //
                        if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) MyShipEntity class unknown");
                        _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetBasedOnTargetsForABattleship.FirstOrDefault();
                        ShootNPCWeAreAlreadyEngagingIfSameName();
                        return _pickPrimaryWeaponTarget;
                    }

                if (DebugConfig.DebugKillTargets) Log.WriteLine("!if (ESCache.Instance.InMission)");
                _pickPrimaryWeaponTarget = PickPrimaryWeaponTargetBasedOnTargetsForABattleship.FirstOrDefault();
                ShootNPCWeAreAlreadyEngagingIfSameName();
                return _pickPrimaryWeaponTarget;
            }

            return null;
        }

        public static void ProcessState()
        {
            try
            {
                if (DateTime.UtcNow < _lastCombatProcessState.AddMilliseconds(350))
                {
                    if (DebugConfig.DebugCombat)
                        Log.WriteLine("if (DateTime.UtcNow < _lastCombatProcessState.AddMilliseconds(350) || Logging.DebugDisableCombat)");
                    return;
                }

                _lastCombatProcessState = DateTime.UtcNow;

                switch (State.CurrentCombatState)
                {
                    case CombatState.CheckTargets:
                        //State.CurrentCombatState = CombatState.KillTargets;
                        if (!TargetCombatants()) return;
                        break;

                    case CombatState.KillTargets:
                        //State.CurrentCombatState = CombatState.CheckTargets;
                        if (!KillTargets()) return;
                        break;

                    case CombatState.OutOfAmmo:
                        if (ESCache.Instance.InStation)
                        {
                            Log.WriteLine("Out of ammo. Pausing questor if in station.");
                            ControllerManager.Instance.SetPause(true);
                        }

                        break;

                    case CombatState.Idle:

                        if (ESCache.Instance.InSpace && ESCache.Instance.ActiveShip.Entity != null && !ESCache.Instance.ActiveShip.Entity.IsCloaked &&
                            ESCache.Instance.ActiveShip.GivenName.ToLower() == CombatShipName.ToLower() && !ESCache.Instance.InWarp)
                        {
                            State.CurrentCombatState = CombatState.KillTargets;
                            if (DebugConfig.DebugCombat)
                                Log.WriteLine("We are in space and ActiveShip is null or Cloaked or we arent in the combatship or we are in warp");
                        }
                        break;

                    default:

                        Log.WriteLine("CurrentCombatState was not set thus ended up at default");
                        State.CurrentCombatState = CombatState.KillTargets;
                        break;
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void LogOrderOfKillTargets(IOrderedEnumerable<EntityCache> killTargets)
        {
            int targetnum = 0;
            Log.WriteLine("----------------[ killtargets ]------------------");
            foreach (EntityCache myKillTarget in killTargets)
            {
                targetnum++;
                Log.WriteLine(targetnum + ";" + myKillTarget.Name + ";" + Math.Round(myKillTarget.Distance / 1000, 0) + "k;" + myKillTarget.IsBattleship + ";BC;" + myKillTarget.IsBattlecruiser + ";C;" + myKillTarget.IsCruiser + ";F;" + myKillTarget.IsFrigate + ";isAttacking;" + myKillTarget.IsAttacking + ";IsTargetedBy;" + myKillTarget.IsTargetedBy + ";IsWarpScramblingMe;" + myKillTarget.IsWarpScramblingMe + ";IsNeutralizingMe;" + myKillTarget.IsNeutralizingMe + ";Health;" + myKillTarget.HealthPct + ";ShieldPct;" + myKillTarget.ShieldPct + ";ArmorPct;" + myKillTarget.ArmorPct + ";StructurePct;" + myKillTarget.StructurePct);
            }

            Log.WriteLine("----------------------------------------------");
        }

        #endregion Methods
    }
}