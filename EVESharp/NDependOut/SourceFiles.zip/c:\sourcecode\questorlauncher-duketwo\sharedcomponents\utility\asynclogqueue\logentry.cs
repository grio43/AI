﻿using System.Drawing;

namespace SharedComponents.Utility.AsyncLogQueue
{
    public class LogEntry
    {
        #region Constructors

        public LogEntry(string m, string dow, Color? c)
        {
            Message = m;
            Color = c;
            DescriptionOfWhere = dow;
        }

        #endregion Constructors

        #region Properties

        public Color? Color { get; }
        public string DescriptionOfWhere { get; }
        public string Message { get; }

        #endregion Properties
    }
}