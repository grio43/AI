﻿using System.Runtime.InteropServices;

namespace SharedComponents.Utility
{
    public class GPUDriverHelpers
    {
        #region Methods

        public static long ConvertGpuDriverStringToLong(string s)
        {
            if (s.Contains("."))
            {
                int k = 0;
                ushort[] res = new ushort[4];
                foreach (string p in s.Split('.'))
                {
                    ushort i = ushort.Parse(p);
                    res[k] = i;
                    k++;
                }
                LARGE_INTEGER largeInt;
                largeInt.QuadPart = 0;
                largeInt.A = res[3];
                largeInt.B = res[2];
                largeInt.C = res[1];
                largeInt.D = res[0];
                return largeInt.QuadPart;
            }
            return 0;
        }

        #endregion Methods

        #region Structs

        [StructLayout(LayoutKind.Explicit, Size = 8)]
        public struct LARGE_INTEGER
        {
            [FieldOffset(0)] public long QuadPart;
            [FieldOffset(0)] public ushort A;
            [FieldOffset(2)] public ushort B;
            [FieldOffset(4)] public ushort C;
            [FieldOffset(6)] public ushort D;
        }

        #endregion Structs
    }
}