﻿using System;
using System.Linq;
using System.Management;
using System.Security.Cryptography;
using System.Text;

namespace SharedComponents.EVE
{
    public class LauncherHash
    {
        #region Fields

        private static readonly Random random = new Random();
        private static Tuple<string, string, string> _getLauncherHash;
        private static int? _maxNonPrintableChars;

        #endregion Fields

        #region Methods

        public static string CCPMagic(string md5)
        {
            byte[] ba = StringToByteArray(md5);
            string str = Encoding.ASCII.GetString(ba) + " \"\"";
            str = str.Replace("?", "�");
            return str;
        }

        public static Tuple<string, string, string> GetLauncherHash()
        {
            if (_getLauncherHash == null)
            {
                string pUID = WMIQuery("Win32_Processor", "UniqueId");
                string pId = WMIQuery("Win32_Processor", "ProcessorId");
                string diskS = WMIQuery("Win32_DiskDrive", "SerialNumber");
                string biosS = WMIQuery("Win32_Bios", "SerialNumber");
                string baseS = WMIQuery("Win32_BaseBoard", "SerialNumber");
                string proc = pUID != string.Empty ? pUID : pId;
                string result = $"{proc}_{diskS}_{biosS}_{baseS}";
                string md5Result = MD5Hash(result);
                _getLauncherHash = new Tuple<string, string, string>(result, md5Result, CCPMagic(md5Result));
            }
            return _getLauncherHash;
        }

        public static Tuple<string, string> GetRandomLauncherHash()
        {
            double linuxTime = DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1)).TotalMilliseconds;
            string launcherHash = string.Empty;
            string ccpMagic = string.Empty;
            do
            {
                launcherHash = MD5Hash(GetLauncherHash().Item1 + random.Next(50000, 9999999) + linuxTime);
                ccpMagic = CCPMagic(launcherHash);
            } while (!CheckHash(launcherHash));
            _maxNonPrintableChars = null;
            return new Tuple<string, string>(launcherHash, ccpMagic);
        }

        public static string MD5Hash(string s)
        {
            using (MD5 provider = MD5.Create())
            {
                StringBuilder builder = new StringBuilder();

                foreach (byte b in provider.ComputeHash(Encoding.UTF8.GetBytes(s)))
                    builder.Append(b.ToString("x2").ToLower());

                return builder.ToString();
            }
        }

        private static bool CheckHash(string md5)
        {
            int notPrintableCount = 0;
            for (int i = 0; i < md5.Length; i = i + 2)
            {
                string p = md5.Substring(i, 2);
                int n = Convert.ToByte(p, 16);
                if (n < 33 || n == 63)
                    return false;
                if (n > 126)
                    notPrintableCount++;
            }
            return notPrintableCount <= GetNumMaxNonPrintableChars();
        }

        private static int GetNumMaxNonPrintableChars()
        {
            if (_maxNonPrintableChars == null)
                _maxNonPrintableChars = random.Next(5, 8);
            return _maxNonPrintableChars.Value;
        }

        private static byte[] StringToByteArray(string hex)
        {
            return Enumerable.Range(0, hex.Length)
                .Where(x => x % 2 == 0)
                .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                .ToArray();
        }

        private static string WMIQuery(string className, string attributeName)
        {
            WqlObjectQuery wquery = new WqlObjectQuery($"SELECT * from {className}");
            ManagementObjectSearcher searcher1 = new ManagementObjectSearcher(wquery);
            foreach (ManagementObject mo1 in searcher1.Get())
                try
                {
                    return mo1.GetPropertyValue(attributeName).ToString();
                }
                catch (Exception)
                {
                    return string.Empty;
                }
            return string.Empty;
        }

        #endregion Methods
    }
}