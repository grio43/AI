﻿/*
 * Created by SharpDevelop.
 * User: duketwo
 * Date: 23.10.2016
 * Time: 22:07
 *
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using System;
using System.Collections.Generic;

namespace SharedComponents.Extensions
{
    /// <summary>
    ///     Description of IEnumerableExtensions.
    /// </summary>
    public static class IEnumerableExtensions
    {
        #region Methods

        public static IEnumerable<TSource> DistinctBy<TSource, TKey>
            (this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> seenKeys = new HashSet<TKey>();
            foreach (TSource element in source)
                if (seenKeys.Add(keySelector(element)))
                    yield return element;
        }

        #endregion Methods
    }
}