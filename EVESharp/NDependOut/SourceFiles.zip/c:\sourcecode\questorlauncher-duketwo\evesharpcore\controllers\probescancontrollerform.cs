﻿using EVESharpCore.Cache;
using EVESharpCore.Controllers.Debug;
using EVESharpCore.Questor.BackgroundTasks;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using EVESharpCore.Framework;

namespace EVESharpCore.Controllers
{
    public partial class ProbeScanControllerForm : Form
    {
        #region Fields

        private ProbeScanController _probeScanController;

        #endregion Fields

        #region Constructors

        public ProbeScanControllerForm(ProbeScanController probeScanController)
        {
            _probeScanController = probeScanController;
            InitializeComponent();
        }

        #endregion Constructors

        private void DebugAssetsButton_Click(object sender, EventArgs e)
        {
            new DebugWindows().Show();
        }

        #region Methods

        private void button1_Click(object sender, EventArgs e)
        {
            new DebugEntities().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new DebugSkills().Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new DebugScan().Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new DebugModules().Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new DebugChannels().Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            new DebugMap().Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            new DebugWindows().Show();
        }

        #endregion Methods

        private void button8_Click(object sender, EventArgs e)
        {

        }
    }
}