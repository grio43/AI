﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using SC::SharedComponents.Py;
using System;
using System.Collections.Generic;
using System.Linq;
using SC::SharedComponents.Utility;

namespace EVESharpCore.Framework
{
    public class DirectActiveShip : DirectItem
    {
        #region Constructors

        internal DirectActiveShip(DirectEve directEve)
            : base(directEve)
        {
            PyItem = directEve.GetLocalSvc("clientDogmaIM").Attribute("dogmaLocation").Call("GetShip");

            if (!PyItem.IsValid) DirectEve.Log("Warning: DirectActiveShip - GetShip returned null.");
        }

        #endregion Constructors

        #region Fields

        /// <summary>
        ///     Entity cache
        /// </summary>
        private DirectEntity _entity;

        private DirectEntity _followingEntity;

        private long? _itemId;

        #endregion Fields

        #region Properties

        /// <summary>
        ///     Your current amount of armor
        /// </summary>
        public double Armor => MaxArmor - Attributes.TryGet<double>("armorDamage");

        /// <summary>
        ///     Armor percentage
        /// </summary>
        public double ArmorPercentage => Math.Round(Math.Abs(Armor / MaxArmor * 100), 1);

        public bool IsShieldTanked
        {
            get
            {
                //default to true
                if (DirectEve.Session.IsInSpace)
                {
                    if (DirectEve.Modules != null)
                    {
                        if (DirectEve.Modules.Any(i => i.IsShieldTankModule))
                            return true;

                        return false;
                    }

                    return true;
                }

                return true;
            }
        }

        public bool IsArmorTanked
        {
            get
            {
                //default to true
                if (DirectEve.Session.IsInSpace)
                {
                    if (DirectEve.Modules != null)
                    {
                        if (DirectEve.Modules.Any(i => i.IsArmorTankModule))
                            return true;

                        return false;
                    }

                    return true;
                }

                return true;
            }
        }

        public bool IsActiveTanked
        {
            get
            {
                try
                {
                    if (DirectEve.Session.IsInSpace)
                    {
                        if (DirectEve.Modules != null)
                        {
                            if (DirectEve.Modules.Any(i => i.IsArmorRepairModule))
                                return true;

                            if (DirectEve.Modules.Any(i => i.IsShieldRepairModule))
                                return true;

                            return false;
                        }

                        return false;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    Logging.Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        /// <summary>
        ///     Your current amount of capacitor
        /// </summary>
        public double Capacitor => Attributes.TryGet<double>("charge");

        /// <summary>
        ///     Capacitor percentage
        /// </summary>
        public double CapacitorPercentage => Math.Round(Math.Abs(Capacitor / MaxCapacitor * 100), 1);

        /// <summary>
        ///     DroneBandwidth
        /// </summary>
        public int DroneBandwidth => (int)Attributes.TryGet<double>("droneBandwidth");

        /// <summary>
        ///     DroneCapacity
        /// </summary>
        public int DroneCapacity => (int)Attributes.TryGet<double>("droneCapacity");

        // other checks -> treeData.py
        //    if bool (godmaSM.GetType(typeID).hasShipMaintenanceBay):
        //shipData.append(TreeDataShipMaintenanceBay(parent=self, clsName='ShipMaintenanceBay', itemID=itemID))
        //if bool (godmaSM.GetType(typeID).hasFleetHangars):
        //shipData.append(TreeDataFleetHangar(parent=self, clsName='ShipFleetHangar', itemID=itemID))
        //if bool (godmaSM.GetType(typeID).specialFuelBayCapacity):
        //shipData.append(TreeDataInv(parent=self, clsName='ShipFuelBay', itemID=itemID))
        //if bool (godmaSM.GetType(typeID).specialOreHoldCapacity):

        /// <summary>
        ///     The entity associated with your ship
        /// </summary>
        /// <remarks>
        ///     Only works in space, return's null if no entity can be found
        /// </remarks>
        public DirectEntity Entity => _entity ?? (_entity = DirectEve.GetEntityById(DirectEve.Session.ShipId ?? -1));

        public DirectEntity FollowingEntity => _followingEntity ?? (_followingEntity = DirectEve.GetEntityById(Entity != null ? Entity.FollowId : -1));

        /// <summary>
        ///     Inertia Modifier (also called agility)
        /// </summary>
        public double InertiaModifier => Attributes.TryGet<double>("agility");

        public bool IsImmobile
        {
            get
            {
                List<DirectModule> bastionAndSiegeModules = DirectEve.Modules.Where(m => m.GroupId == (int)Group.BastionAndSiegeModules && m.IsOnline).ToList();
                if (bastionAndSiegeModules.Any(i => i.IsActive))
                    return true;

                return false;
            }
        }

        public bool IsShipWithFleetHangar
        {
            get
            {
                try
                {
                    if (GroupId == 380 || //TransportShip
                        GroupId == 547 || //Carrier
                        GroupId == 485 || //Dreadnaught
                        GroupId == 941 || //Industrial Command Ships - Orca
                        GroupId == 883 || //Capital Industrial Ships - Rorqual
                        GroupId == 1538) //Force Auxillary
                        return true;

                    return false;
                }
                catch (Exception exception)
                {
                    DirectEve.Log("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsShipWithNoDroneBay
        {
            get
            {
                try
                {
                    //
                    // if we are in abyssaldeadspace just use UseDrones to determine if we should use drones or not
                    // in regular space we might be in various ships, in abyssaldeadspace we should always be in the combatship
                    //

                    if (DirectEve.Session.IsAbyssalDeadspace)
                        return false;

                    if (GroupId == (int)Group.Dreadnaught)
                        return false;

                    if (GroupId == (int)Group.Capsule)
                        return false;

                    if (DroneCapacity < 5)
                        return true;

                    return false;
                }
                catch (Exception exception)
                {
                    DirectEve.Log("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public new long ItemId
        {
            get
            {
                if (!_itemId.HasValue)
                    _itemId = (long)DirectEve.Session.ShipId;

                return _itemId.Value;
            }
            internal set => _itemId = value;
        }

        public bool ManageMyOwnDroneTargets
        {
            get
            {
                //if this is false the drone behavior will try to assist any available drones to another fleet member
                if (DirectEve.Session.InFleet && DirectEve.Entities.Any(i => i.CategoryId == (int)CategoryID.Ship && 80000 > i.Distance && i.IsPlayer && i.InMyFleet))
                {
                    if (TypeId == (int)TypeID.Nestor)
                        return false;

                    if (TypeId == (int)TypeID.Noctis)
                        return false;

                    if (GroupId == (int)Group.Logistics)
                        return false;
                }

                return true;
            }
        }

        public bool IsLogisticsOnly
        {
            get
            {
                //if this is false the drone behavior will try to assist any available drones to another fleet member
                if (!DirectEve.Weapons.Any())
                {
                    if (TypeId == (int)TypeID.Nestor)
                        return true;

                    if (GroupId == (int)Group.Logistics)
                        return true;
                }

                return false;
            }
        }

        /// <summary>
        ///     The maximum amount of armor
        /// </summary>
        public double MaxArmor => Attributes.TryGet<double>("armorHP");

        /// <summary>
        ///     The maximum amount of capacitor
        /// </summary>
        public double MaxCapacitor => Attributes.TryGet<double>("capacitorCapacity");

        /// <summary>
        ///     Maximum locked targets
        /// </summary>
        /// <remarks>
        ///     Skills may cause you to lock less targets!
        /// </remarks>
        public int MaxLockedTargets => (int)Attributes.TryGet<double>("maxLockedTargets");

        /// <summary>
        ///     The maxmimum amount of shields
        /// </summary>
        public double MaxShield => Attributes.TryGet<double>("shieldCapacity");

        /// <summary>
        ///     The maximum amount of structure
        /// </summary>
        public double MaxStructure => Attributes.TryGet<double>("hp");

        /// <summary>
        ///     The maximum target range
        /// </summary>
        public double MaxTargetRange => Attributes.TryGet<double>("maxTargetRange");

        /// <summary>
        ///     Maximum velocity
        /// </summary>
        public double MaxVelocity => Attributes.TryGet<double>("maxVelocity");

        /// <summary>
        ///     Your current amount of shields
        /// </summary>
        public double Shield => Attributes.TryGet<double>("shieldCharge");

        /// <summary>
        ///     Shield percentage
        /// </summary>
        public double ShieldPercentage => Math.Round(Math.Abs(Shield / MaxShield * 100), 1);

        /// <summary>
        ///     Your current amount of structure
        /// </summary>
        public double Structure => MaxStructure - Attributes.TryGet<double>("damage");

        /// <summary>
        ///     Structure percentage
        /// </summary>
        public double StructurePercentage => Math.Round(Math.Abs(Structure / MaxStructure * 100), 1);

        #endregion Properties

        #region Methods

        public bool CanGroupAll()
        {
            PyObject dogmaLocation = DirectEve.GetLocalSvc("clientDogmaIM").Attribute("dogmaLocation");
            bool canGroupAll = (bool)dogmaLocation.Call("CanGroupAll", DirectEve.Session.ShipId);
            return canGroupAll;
        }

        /// <summary>
        ///     Eject from your current ship
        /// </summary>
        /// <returns></returns>
        public bool EjectFromShip()
        {
            PyObject Eject = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("Eject");
            return DirectEve.ThreadedCall(Eject);
        }

        /// <summary>
        ///     Groups all weapons if possible
        /// </summary>
        /// <returns>Fails if it's not allowed to group (because there is nothing to group)</returns>
        /// <remarks>Only works in space</remarks>
        public bool GroupAllWeapons()
        {
            PyObject dogmaLocation = DirectEve.GetLocalSvc("clientDogmaIM").Attribute("dogmaLocation");
            bool canGroupAll = (bool)dogmaLocation.Call("CanGroupAll", DirectEve.Session.ShipId);
            if (!canGroupAll)
                return false;

            return DirectEve.ThreadedCall(dogmaLocation.Attribute("LinkAllWeapons"), DirectEve.Session.ShipId.Value);
        }

        /// <summary>
        ///     Launch all drones
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Only works in space
        /// </remarks>
        public bool LaunchAllDrones()
        {
            DirectContainer droneBay = DirectEve.GetShipsDroneBay();

            if (droneBay == null)
                return false;

            int maxDrones = DirectEve.Me.MaxActiveDrones;
            int currentShipsDroneBandwidth = DirectEve.ActiveShip.DroneBandwidth;
            List<DirectEntity> activeDrones = DirectEve.ActiveDrones;

            DirectItem droneDirectItem = new DirectItem(DirectEve);
            if (activeDrones.Any()) droneDirectItem.TypeId = activeDrones.FirstOrDefault().TypeId;

            int activeDronesBandwidth = activeDrones.Sum(d => (int)droneDirectItem.Attributes.TryGet<double>("droneBandwidthUsed"));
            activeDronesBandwidth = activeDronesBandwidth < 0 ? 0 : activeDronesBandwidth;

            int remainingDronesBandwidth = currentShipsDroneBandwidth - activeDronesBandwidth;
            remainingDronesBandwidth = remainingDronesBandwidth < 0 ? 0 : remainingDronesBandwidth;

            int remainingDrones = maxDrones - activeDrones.Count;
            remainingDrones = remainingDrones < 0 ? 0 : remainingDrones;

            if (!droneBay.Items.Any())
                return false;

            if (activeDrones.Count >= 5)
                return false;

            //			DirectEve.Log("remainingDrones: " + remainingDrones);
            //			DirectEve.Log("remainingDronesBandwidth: " + remainingDronesBandwidth);

            List<DirectItem> dronesToLaunch = new List<DirectItem>();

            if (droneBay.Items.Count(d => d.Stacksize == 1) >= remainingDrones)
                foreach (DirectItem d in droneBay.Items.Where(d => d.Stacksize == 1))
                {
                    int bandwidth = (int)d.Attributes.TryGet<double>("droneBandwidthUsed");

                    if (remainingDronesBandwidth - bandwidth >= 0 && remainingDrones - 1 >= 0)
                    {
                        remainingDrones--;
                        remainingDronesBandwidth = remainingDronesBandwidth - bandwidth;
                        dronesToLaunch.Add(d);
                    }
                    else
                    {
                        break;
                    }
                }
            else
                dronesToLaunch = droneBay.Items;

            //			foreach(var d in dronesToLaunch){
            //				DirectEve.Log(d.TypeName + " " + d.Stacksize);
            //			}

            return LaunchDrones(dronesToLaunch);
        }

        /// <summary>
        ///     Launch a specific list of drones
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Only works in space
        /// </remarks>
        public bool LaunchDrones(IEnumerable<DirectItem> drones)
        {
            if (!DirectEve.Interval(3000, 4000))
                return false;

            IEnumerable<PyObject> invItems = drones.Where(d => d.PyItem.IsValid).Select(d => d.PyItem);
            return DirectEve.ThreadedLocalSvcCall("menu", "LaunchDrones", invItems);
        }

        public bool MoveTo(Vector3 coord)
        {
            if (!DirectEve.Interval(3000, 4000))
                return false;

            ////Create unit length
            double length = Math.Sqrt(coord.X * coord.X + coord.Y * coord.Y + coord.Z * coord.Z);
            if (length == 0)
                return false;

            double X = coord.X / length;
            double Y = coord.Y / length;
            double Z = coord.Z / length;

            return DirectEve.ThreadedCall(DirectEve.GetLocalSvc("michelle").Call("GetRemotePark").Attribute("CmdGotoDirection"), X, Y, Z);
        }

        public bool MoveTo(DirectEntity b)
        {
            DirectEntity a = DirectEve.ActiveShip.Entity;
            return MoveTo(new Vector3(b.X - a.X, b.Y - a.Y, b.Z - a.Z));
        }

        /// <summary>
        ///     Strips active ship, use only in station!
        /// </summary>
        /// <returns></returns>
        public bool StripFitting()
        {
            string calledFrom = "StripFitting";
            if (!DirectEve.NoLockedItemsOrWaitAndClearLocks(calledFrom)) return false;
            return DirectEve.ThreadedCall(DirectEve.GetLocalSvc("menu").Attribute("invCache").Call("GetInventoryFromId", ItemId).Attribute("StripFitting"));
        }

        /// <summary>
        ///     Ungroups all weapons
        /// </summary>
        /// <returns>
        ///     Fails if anything can still be grouped. Execute GroupAllWeapons first if not everything is grouped, this is
        ///     done to mimic client behavior.
        /// </returns>
        /// <remarks>Only works in space</remarks>
        public bool UngroupAllWeapons()
        {
            PyObject dogmaLocation = DirectEve.GetLocalSvc("clientDogmaIM").Attribute("dogmaLocation");
            bool canGroupAll = (bool)dogmaLocation.Call("CanGroupAll", DirectEve.Session.ShipId.Value);
            if (canGroupAll)
                return false;

            return DirectEve.ThreadedCall(dogmaLocation.Attribute("UnlinkAllWeapons"), DirectEve.Session.ShipId.Value);
        }

        public void GetHeaderAndSubtextFromBall()
        {
            // todo:
            //spaceMgr.py --> GetHeaderAndSubtextFromBall
            // returns the header text and subtext for the ship's actions.
            // Can return None, None which means there is nothing to display
            //
        }

        #endregion Methods
    }
}