﻿extern alias SC;
using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Logging;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectBlueprint : DirectItem
    {
        #region Constructors

        internal DirectBlueprint(DirectEve directEve, PyObject pyModule) : base(directEve)
        {
            PyObject GetPyModule = pyModule;
        }

        #endregion Constructors

        #region Fields

        #endregion Fields


        #region Methods

        public bool UseBlueprint()
        {
            if (CategoryId != (int)CategoryID.Blueprint)
                return false;

            PyObject pyUseBlueprint = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("UseBlueprint");

            if (pyUseBlueprint == null || !pyUseBlueprint.IsValid)
            {
                Log.WriteLine("UseBlueprint: if (pyUseBlueprint == null || !pyUseBlueprint.IsValid)");
                return false;
            }

            return DirectEve.ThreadedCall(pyUseBlueprint, PyItem);
        }

        public bool UseFormula()
        {
            if (CategoryId != (int)CategoryID.Blueprint)
                return false;

            PyObject pyUseFormula = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("UseFormula");

            if (pyUseFormula == null || !pyUseFormula.IsValid)
            {
                Log.WriteLine("UseFormula: if (pyUseFormula == null || !pyUseFormula.IsValid)");
                return false;
            }

            return DirectEve.ThreadedCall(pyUseFormula, PyItem);
        }

        #endregion Methods
    }
}