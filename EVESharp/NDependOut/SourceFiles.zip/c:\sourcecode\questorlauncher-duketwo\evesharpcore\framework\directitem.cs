﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;
using System;
using EVESharpCore.Logging;
using SC::SharedComponents.Py;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using EVESharpCore.Lookup;
using SC::SharedComponents.EVE.ClientSettings;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectItem : DirectInvType
    {
        #region Constructors

        internal DirectItem(DirectEve directEve) : base(directEve)
        {
            PyItem = PySharp.PyZero;
        }

        #endregion Constructors

        //

        //                return false;

        //            if (TypeId != 29668)

        //        {
        //        public bool ActivatePLEX()

        #region Fields

        private DirectItemAttributes _attributes;

        private int? _flagId;
        private string _givenName;
        //private bool? _isDroneWeHaveLaunched;
        private bool? _isSingleton;

        private long? _itemId;

        private DirectLocation _location;

        //private long? _metaLevel;
        //private long? _techLevel;
        private long? _locationId;

        private string _locationName;

        private List<DirectItem> _materials;
        private int? _ownerId;
        private PyObject _pyItem;
        private int? _quantity;
        private int? _stacksize;

        #endregion Fields

        /**
                public bool SplitStack()
                {
                    if (LocationId != DirectEve.Session.StationId)
                        return false;

                    if (IsSingleton)
                        return false;

                    if (Quantity > 1)
                    {
                        //var splitStack = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("SplitStack");
                        //return DirectEve.ThreadedCall(splitStack, new List<PyObject>() { PyItem });
                    }

                    return false;
                }
        **/

        #region Properties

        private static Dictionary<int, float> _packagedOverridePerGroupId;

        private static Dictionary<int, float> _packagedOverridePerTypeId;

        public DirectItemAttributes Attributes
        {
            get
            {
                if (_attributes == null && PyItem.IsValid)
                {
                    PyObject pyItemId = PyItem.Attribute("itemID");
                    if (pyItemId.IsValid)
                        _attributes = new DirectItemAttributes(DirectEve, pyItemId);
                }

                _attributes = _attributes ?? new DirectItemAttributes(DirectEve, ItemId);
                return _attributes;
            }
        }

        public int FlagId
        {
            get
            {
                if (!_flagId.HasValue)
                    _flagId = (int)PyItem.Attribute("flagID");

                return _flagId.Value;
            }
            internal set => _flagId = value;
        }

        public string GivenName
        {
            get
            {
                if (_givenName == null)
                    _givenName = DirectEve.GetLocationName(ItemId);

                return _givenName;
            }
        }

        public AmmoType DefinedAsAmmoType
        {
            get
            {
                foreach (AmmoType definedAmmoType in DirectModule.DefinedAmmoTypes)
                {
                    if (TypeId == definedAmmoType.TypeId)
                        return definedAmmoType;
                }

                return null;
            }
        }

        public bool IsCommonMissionItem => TypeId == 28260
                                           || TypeId == 3814
                                           || TypeId == 2076
                                           || TypeId == 25373
                                           || TypeId == 3810
                                           || TypeId == 24576
                                           || TypeId == 24766
                                           || CategoryId == (int)CategoryID.Asteroid
                                           || TypeId == (int)TypeID.AngelDiamondTag
                                           || TypeId == (int)TypeID.GuristasDiamondTag
                                           || TypeId == (int)TypeID.ImperialNavyGatePermit
                                           || GroupId == (int)Group.AccelerationGateKeys
                                           || GroupId == (int)Group.Livestock
                                           || GroupId == (int)Group.MiscSpecialMissionItems
                                           || GroupId == (int)Group.Kernite
                                           || GroupId == (int)Group.Omber
                                           || GroupId == (int)Group.Commodities
                                           //|| TypeId == (int)TypeID.MetalScraps
                                           //|| TypeId == (int)TypeID.ReinforcedMetalScraps
                                           || TypeId == (int)TypeID.Marines
                                           ;

        public bool IsContraband
        {
            get
            {
                bool result = false;
                result |= GroupId == (int)Group.Drugs;
                result |= GroupId == (int)Group.ToxicWaste;
                result |= TypeId == (int)TypeID.Slaves;
                result |= TypeId == (int)TypeID.Small_Arms;
                result |= TypeId == (int)TypeID.Ectoplasm;
                return result;
            }
        }

        /**
        public bool IsDroneWeHaveLaunched
        {
            get
            {
                if (!_isDroneWeHaveLaunched.HasValue)
                    _isDroneWeHaveLaunched = DirectEve.DronesWeHaveLaunched.Contains(ItemId);

                return (bool) _isDroneWeHaveLaunched;
            }
        }
        **/

        public double? IskPerM3
        {
            get
            {
                if (AveragePrice() > 0 && Volume > 0)
                    return AveragePrice() / Volume;
                return 0;
            }
        }

        public bool IsSingleton
        {
            get
            {
                if (!_isSingleton.HasValue)
                    _isSingleton = (bool)PyItem.Attribute("singleton");

                return _isSingleton.Value;
            }
            internal set => _isSingleton = value;
        }

        public long ItemId
        {
            get
            {
                if (!_itemId.HasValue)
                    _itemId = (long)PyItem.Attribute("itemID");

                return _itemId.Value;
            }
            internal set => _itemId = value;
        }

        public DirectLocation Location
        {
            get
            {
                if (_location == null)
                {
                    _location = DirectEve.GetLocation((int)LocationId);
                    return _location;
                }

                return _location;
            }
        }

        public long LocationId
        {
            get
            {
                if (!_locationId.HasValue)
                    _locationId = (long)PyItem.Attribute("locationID");

                return _locationId.Value;
            }
            internal set => _locationId = value;
        }

        public string LocationName
        {
            get
            {
                if (string.IsNullOrEmpty(_locationName))
                {
                    _locationName = DirectEve.GetLocationName(LocationId);
                    return _locationName;
                }

                return _locationName;
            }
        }

        public List<DirectItem> Materials
        {
            get
            {
                if (_materials == null)
                {
                    _materials = new List<DirectItem>();
                    foreach (PyObject pyMaterial in PySharp.Import("__builtin__").Attribute("cfg").Attribute("invtypematerials").DictionaryItem(TypeId).ToList())
                    {
                        DirectItem material = new DirectItem(DirectEve);
                        material.ItemId = -1;
                        material.Stacksize = -1;
                        material.OwnerId = -1;
                        material.LocationId = -1;
                        material.FlagId = 0;
                        material.IsSingleton = false;
                        material.TypeId = (int)pyMaterial.Attribute("materialTypeID");
                        material.Quantity = (int)pyMaterial.Attribute("quantity");
                        _materials.Add(material);
                    }
                }

                return _materials;
            }
        }

        public int OwnerId
        {
            get
            {
                if (!_ownerId.HasValue)
                    _ownerId = (int)PyItem.Attribute("ownerID");

                return _ownerId.Value;
            }
            internal set => _ownerId = value;
        }

        public int Quantity
        {
            get
            {
                if (!_quantity.HasValue)
                    _quantity = (int)PyItem.Attribute("quantity");

                return _quantity.Value;
            }
            internal set => _quantity = value;
        }

        public DirectSolarSystem SolarSystem => Station.SolarSystem;

        public long SolarSystemId => Station.SolarSystem.Id;

        public int Stacksize
        {
            get
            {
                if (!_stacksize.HasValue)
                    _stacksize = (int)PyItem.Attribute("stacksize");

                return _stacksize.Value;
            }
            internal set => _stacksize = value;
        }

        public DirectStation Station
        {
            get
            {
                if (DirectEve.Stations.Any())
                {
                    DirectStation _station = null;
                    DirectEve.Stations.TryGetValue((int)LocationId, out _station);
                    if (_station != null) return _station;
                    return null;
                }

                return null;
            }
        }

        public double TotalVolume => Volume * Quantity;

        public new double Volume
        {
            get
            {
                double vol = base.Volume;

                if (TypeId == 3468) // plastic wraps
                    return vol;

                if (!IsSingleton) // get packaged vol
                {
                    float? group = GetPackagedVolOverrideGroup(GroupId, DirectEve);
                    if (group.HasValue)
                        return group.Value;

                    float? type = GetPackagedVolOverrideType(TypeId, DirectEve);
                    if (type.HasValue)
                        return type.Value;
                }

                return vol;
            }
        }

        internal PyObject PyItem
        {
            get => _pyItem;
            set
            {
                _pyItem = value;

                if (_pyItem != null && _pyItem.IsValid)
                    TypeId = (int)_pyItem.Attribute("typeID");
            }
        }

        private static float? GetPackagedVolOverrideGroup(int groupId, DirectEve de)
        {
            if (_packagedOverridePerGroupId == null)
            {
                _packagedOverridePerGroupId = new Dictionary<int, float>();
                //inventorycommon.util.packagedVolumeOverridesPerGroup
                PyObject invCommon = de.PySharp.Import("inventorycommon");
                Dictionary<int, PyObject> dict = invCommon.Attribute("util").Attribute("packagedVolumeOverridesPerGroup").ToDictionary<int>();
                foreach (KeyValuePair<int, PyObject> kv in dict)
                    _packagedOverridePerGroupId.Add(kv.Key, kv.Value.ToFloat());
            }

            if (_packagedOverridePerGroupId.TryGetValue(groupId, out var val))
                return val;

            return null;
        }

        private static float? GetPackagedVolOverrideType(int typeId, DirectEve de)
        {
            if (_packagedOverridePerTypeId == null)
            {
                _packagedOverridePerTypeId = new Dictionary<int, float>();
                //inventorycommon.util.packagedVolumeOverridesPerType
                PyObject invCommon = de.PySharp.Import("inventorycommon");
                Dictionary<int, PyObject> dict = invCommon.Attribute("util").Attribute("packagedVolumeOverridesPerType").ToDictionary<int>();
                foreach (KeyValuePair<int, PyObject> kv in dict)
                    _packagedOverridePerTypeId.Add(kv.Key, kv.Value.ToFloat());
            }

            if (_packagedOverridePerTypeId.TryGetValue(typeId, out var val))
                return val;

            return null;
        }

        #endregion Properties

        /**
                public int? Metalevel
                {
                    get
                    {
                        try
                        {
                            if (!_metaLevel.HasValue)
                                _metaLevel = Attributes.TryGet<int>("metalevel");

                            //(bool)PyItem.Attribute("singleton");

                            return (int)_metaLevel.Value;
                        }
                        catch (Exception)
                        {
                            return null;
                        }
                    }
                }

                public int? TechLevel
                {
                    get
                    {
                        try
                        {
                            if (!_techLevel.HasValue)
                                _techLevel = Attributes.TryGet<int>("techlevel");

                            return (int)_techLevel.Value;
                        }
                        catch (Exception)
                        {
                            return null;
                        }
                    }
                }

        **/

        #region Methods

        public bool ActivateAbyssalKey()
        {
            if (GroupId != (int)Group.AbyssalDeadspaceFilament)
                return false;

            PyObject pyActivateAbyssalKey = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("ActivateAbyssalKey");

            if (pyActivateAbyssalKey == null || !pyActivateAbyssalKey.IsValid)
            {
                Log.WriteLine("ActivateAbyssalKey: if (pyActivateAbyssalKey == null || !pyActivateAbyssalKey.IsValid)");
                return false;
            }

            return DirectEve.ThreadedCall(pyActivateAbyssalKey, PyItem);
        }

        public bool IsSafeToUseAbyssalKeyHere
        {
            get
            {
                try
                {
                    if (!DirectEve.Session.IsInSpace || DirectEve.Session.IsInDockableLocation)
                    {
                        Log.WriteLine("IsSafeToUseAbyssalKeyHere: IsInSpace [" + DirectEve.Session.IsInSpace + "] IsInDockableLocation [" + DirectEve.Session.IsInDockableLocation + "]");
                        return false;
                    }

                    if (DirectEve.Entities == null || !DirectEve.Entities.Any())
                    {
                        Log.WriteLine("IsSafeToUseAbyssalKeyHere: if (DirectEve.Entities == null || !DirectEve.Entities.Any())");
                        return false;
                    }

                    // this isnt really necessary: but it at least makes sense to not return true if we use this on a non-filament.
                    if (GroupId != (int)Group.AbyssalDeadspaceFilament)
                    {
                        Log.WriteLine("IsSafeToUseAbyssalKeyHere: [" + TypeName + "] TypeId [" + TypeId + "] GroupId [" + GroupId + "] is not a filament?");
                        return false;
                    }

                    if (DirectEve.Entities.Any(entity => entity != null && entity.Distance != 0 && (int)Distances.OnGridWithMe > entity.Distance))
                    {
                        if (DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).Any(entity => entity.GroupId == (int)Group.MobileDepot))
                        {
                            DirectEntity closestMobileDepot = DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).OrderBy(i => i.Distance).FirstOrDefault(entity => entity.GroupId == (int)Group.MobileDepot);
                            if (closestMobileDepot != null)
                            {
                                Log.WriteLine("IsSafeToUseAbyssalKeyHere: MobileDepot named [" + closestMobileDepot.GivenName + "] found [" + Math.Round(closestMobileDepot.Distance / 1000, 0) + "] k");
                                return false;
                            }

                            return false;
                        }

                        if (DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).Any(entity => entity.GroupId == (int)Group.MobileTractor))
                        {
                            DirectEntity closestMobileTractor = DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).OrderBy(i => i.Distance).FirstOrDefault(entity => entity.GroupId == (int)Group.MobileTractor);
                            if (closestMobileTractor != null)
                            {
                                Log.WriteLine("IsSafeToUseAbyssalKeyHere: MobileTractor named [" + closestMobileTractor.GivenName + "] found [" + Math.Round(closestMobileTractor.Distance / 1000, 0) + "] k");
                                return false;
                            }

                            return false;
                        }

                        if (DirectEve.Entities.Where(i => (int) Distances.OnGridWithMe > i.Distance).Any(entity => entity.GroupId == (int) Group.Station))
                        {
                            DirectEntity closestStation = DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).OrderBy(i => i.Distance).FirstOrDefault(entity => entity.GroupId == (int)Group.Station);
                            if (closestStation != null)
                            {
                                Log.WriteLine("IsSafeToUseAbyssalKeyHere: Station named [" + closestStation.GivenName + "] found [" + Math.Round(closestStation.Distance / 1000, 0) + "] k");
                                return false;
                            }

                            return false;
                        }

                        if (DirectEve.Entities.Where(i => (int) Distances.OnGridWithMe > i.Distance).Any(entity => entity.GroupId == (int) Group.Citadel))
                        {
                            DirectEntity closestCitadel = DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).OrderBy(i => i.Distance).FirstOrDefault(entity => entity.GroupId == (int)Group.Citadel);
                            if (closestCitadel != null)
                            {
                                Log.WriteLine("IsSafeToUseAbyssalKeyHere: Citadel named [" + closestCitadel.GivenName + "] found [" + Math.Round(closestCitadel.Distance / 1000, 0) + "] k");
                                return false;
                            }

                            return false;
                        }

                        if (DirectEve.Entities.Where(i => (int) Distances.OnGridWithMe > i.Distance).Any(entity => entity.GroupId == (int) Group.Stargate))
                        {
                            DirectEntity closestStargate = DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).OrderBy(i => i.Distance).FirstOrDefault(entity => entity.GroupId == (int)Group.CustomsOffice);
                            if (closestStargate != null)
                            {
                                Log.WriteLine("IsSafeToUseAbyssalKeyHere: CustomsOffice found on [" + Math.Round(closestStargate.Distance / 1000, 0) + "] k");
                                return false;
                            }

                            return false;
                        }

                        if (DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).Any(entity => entity.GroupId == (int)Group.POSControlTower))
                        {
                            DirectEntity closestPosControlTower = DirectEve.Entities.Where(i => (int)Distances.OnGridWithMe > i.Distance).OrderBy(i => i.Distance).FirstOrDefault(entity => entity.GroupId == (int)Group.POSControlTower);
                            if (closestPosControlTower != null)
                            {
                                Log.WriteLine("IsSafeToUseAbyssalKeyHere: CustomsOffice found on [" + Math.Round(closestPosControlTower.Distance / 1000, 0) + "] k");
                                return false;
                            }

                            return false;
                        }
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        //
        // todo: impliment: see menusvc.py - Note some of these arent for DirectItems but for DirectEntitys or other
        // LaunchForCorp
        // LeaveShip
        // ShowInfo (to read attribuites?!)
        // MoveToDroneBay
        // FitToActiveShip
        // DropOffItem (used from space to deliver items to a hangar in a citadel you cant dock in)
        // Reprocess (already exists?)
        // AssembleShip
        // PlugInImplant
        // InjectSkill (already exists?)
        // TrashIt
        // DeliverCorpStuffTo (deliverTo Menu)
        // Compress
        // Open All kinds of bays: FighterBay, FleetHangar, FuelBay, OreHold, GasHold, MineralHold
        // SpitStack
        // UseBlueprint
        // UseFormula
        // Insure - UI/Insurance/InsuranceWindow/Commands/Insure
        // SetName
        // SimulateShip
        // StripFitting
        // BoardShip
        // LaunchFromBay
        // BoardShipFromBay
        // InviteToFleet - UI/Fleet/InvitePilotToFleet
        // FormFleetWith - UI/Fleet/FormFleetWith
        // KickFleetMember - UI/Fleet/KickFleetMember
        // MakeFleetLeader - UI/Fleet/MakeFleetLeader
        // AddPilotToWatchlist - UI/Fleet/AddPilotToWatchlist
        // LeaveFleet - UI/Fleet/LeaveMyFleet
        // TransferCorpCash - UI/Corporations/Common/TransferCorpCash
        // SendCorpInvite - UI/Corporations/Common/SendCorpInvite
        // SelfDestruct - UI/Inflight/SelfDestructShipOrPod
        // EnterPOSPassword - UI/Inflight/POS/EnterStarbasePassword
        // JumpTo - UI/Inflight/Submenus/JumpTo
        // BridgeTo - UI/Inflight/Submenus/BridgeTo
        // WarpFleet - UI/Fleet/WarpFleet
        // WarpFleetToWithin - UI/Fleet/FleetSubmenus/WarpFleetToWithin
        // AssumeStructureControl - UI/Inflight/POS/AssumeStructureControl
        // RelinquishPOSControl - UI/Inflight/POS/RelinquishPOSControl

        public bool LaunchForSelf()
        {
            if (GroupId != (int)Group.MobileTractor && GroupId != (int)Group.MobileDepot)
                return false;

            if (!DirectEve.Interval(3000, 4000))
                return false;

            //Dictionary<string, object> keywords = new Dictionary<string, object>();
            //keywords.Add("maxQty", 1);
            //keywords.Add("ignoreWarning", true);
            PyObject jettison = DirectEve.GetLocalSvc("gameui").Call("GetShipAccess").Attribute("Drop");
            return DirectEve.ThreadedCall(jettison, ItemId, DirectEve.Session.CharacterId, true);

            //return DirectEve.ThreadedCallWithKeywords(PySharp.Import("util").Call("LaunchFromShip"), keywords, ItemId, DirectEve.Session.CharacterId);
        }

        public bool ShowIndustryWindow()
        {
            if (CategoryId == (int)CategoryID.Blueprint)
            {
                //def ShowInIndustryWindow(invItem):
                //Industry.OpenOrShowBlueprint(blueprintID = invItem.itemID)

                //todo: implement
            }

            return false;
        }

        /// <summary>
        ///     Activate this ship
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Fails if the current location is not the same as the current station and if its not a CategoryShip
        /// </remarks>
        public bool ActivateShip()
        {
            DirectSession.SetSessionNextSessionReady();

            if (LocationId != DirectEve.Session.StationId && !DirectEve.Session.Structureid.HasValue)
                return false;

            if (CategoryId != (int)DirectEve.Const.CategoryShip)
                return false;

            return DirectEve.ThreadedLocalSvcCall("station", "TryActivateShip", PyItem);
        }

        /// <summary>
        ///     Assembles this ship
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Fails if the current location is not the same as the current station and if its not a CategoryShip and is not
        ///     allready assembled
        /// </remarks>
        public bool AssembleShip()
        {
            if (LocationId != DirectEve.Session.StationId && !DirectEve.Session.Structureid.HasValue)
                return false;

            if (CategoryId != (int)DirectEve.Const.CategoryShip)
                return false;

            if (IsSingleton)
                return false;

            PyObject AssembleShip = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("AssembleShip");
            return DirectEve.ThreadedCall(AssembleShip, new List<PyObject> { PyItem });
        }

        public bool ActivateSkillExtractor()
        {
            if (LocationId != DirectEve.Session.StationId && !DirectEve.Session.Structureid.HasValue)
                return false;

            if (CategoryId != (int)DirectEve.Const.CategoryShip)
                return false;

            if (IsSingleton)
                return false;

            PyObject AssembleShip = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("AssembleShip");
            return DirectEve.ThreadedCall(AssembleShip, new List<PyObject> { PyItem });
        }

        public double AveragePrice()
        {
            return (double)PySharp.Import("util").Call("GetAveragePrice", PyItem);
        }

        /// <summary>
        ///     Board this ship from a ship maintanance bay!
        /// </summary>
        /// <returns>false if entity is player or out of range</returns>
        public bool BoardShipFromShipMaintBay()
        {
            if (CategoryId != (int)DirectEve.Const.CategoryShip)
                return false;

            if (IsSingleton)
                return false;

            PyObject Board = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("Board");
            return DirectEve.ThreadedCall(Board, ItemId);
        }

        /// <summary>
        ///     Consume Booster
        /// </summary>
        /// <returns></returns>
        public bool ConsumeBooster()
        {
            if (GroupId != (int)Group.Booster)
                return false;

            //if ((!DirectEve.Session.StationId.HasValue || LocationId != DirectEve.Session.StationId) && !DirectEve.Session.Structureid.HasValue)
            //    return false;

            if (ItemId == 0 || !PyItem.IsValid)
                return false;

            PyObject consumeBooster = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("ConsumeBooster");
            return DirectEve.ThreadedCall(consumeBooster, new List<PyObject> { PyItem });
        }

        public bool PlugInImplant()
        {
            if (CategoryId != (int)CategoryID.Implant)
                return false;

            //if ((!DirectEve.Session.StationId.HasValue || LocationId != DirectEve.Session.StationId) && !DirectEve.Session.Structureid.HasValue)
            //    return false;

            if (ItemId == 0 || !PyItem.IsValid)
                return false;

            PyObject plugInImplant = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("PlugInImplant");
            return DirectEve.ThreadedCall(plugInImplant, new List<PyObject> { PyItem });
        }

        /// <summary>
        ///     Fit this item to your ship
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Fails if the selected item is not of CategoryModule
        /// </remarks>
        public bool FitToActiveShip()
        {
            if (CategoryId != (int)DirectEve.Const.CategoryModule)
                return false;

            List<PyObject> data = new List<PyObject>();
            data.Add(PyItem);

            return DirectEve.ThreadedLocalSvcCall("menu", "TryFit", data);
        }

        /// <summary>
        ///     Inject the skill into your brain
        /// </summary>
        /// <returns></returns>
        public bool InjectSkill()
        {
            if (CategoryId != (int)DirectEve.Const.CategorySkill)
                return false;

            if ((!DirectEve.Session.StationId.HasValue || LocationId != DirectEve.Session.StationId) && !DirectEve.Session.Structureid.HasValue)
                return false;

            if (ItemId == 0 || !PyItem.IsValid)
                return false;

            PyObject InjectSkillIntoBrain = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("InjectSkillIntoBrain");
            return DirectEve.ThreadedCall(InjectSkillIntoBrain, new List<PyObject> { PyItem });
        }

        public bool TrainNow()
        {
            if (CategoryId != (int)DirectEve.Const.CategorySkill)
                return false;

            if ((!DirectEve.Session.StationId.HasValue || LocationId != DirectEve.Session.StationId) && !DirectEve.Session.Structureid.HasValue)
                return false;

            if (ItemId == 0 || !PyItem.IsValid)
                return false;

            PyObject PyTrainNow = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("TrainNow");
            return DirectEve.ThreadedCall(PyTrainNow, new List<PyObject> { PyItem });
        }

        /// <summary>
        ///     Open container window
        /// </summary>
        /// <param name="containerToOpen"></param>
        /// <returns></returns>
        public bool OpenContainer()
        {
            //
            // See: eve\client\script\ui\services\menuSvcEctras\openFunctions.py\OpenCargoContainer(invItems):
            //
            if (ItemId == 0)
                return false;

            if (!IsContainerUsedToSortItemsInStations)
                return false;

            if (!IsSingleton)
                return false;

            if (!PyItem.IsValid)
                return false;

            if (!DirectEve.Session.IsInDockableLocation)
                return false;

            if (LocationId != DirectEve.Session.StationId)
                return false;

            if (Time.Instance.NextOpenCargoAction.AddSeconds(1) > DateTime.UtcNow)
                return false;

            PyObject pyOpenCargoContainer = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.openFunctions").Attribute("OpenCargoContainer");
            if (pyOpenCargoContainer.IsValid)
            {
                Time.Instance.NextOpenCargoAction = DateTime.UtcNow;
                return DirectEve.ThreadedCall(pyOpenCargoContainer, new List<PyObject> { PyItem });
            }

            return false;
        }

        public bool RepackageItem()
        {
            if ((!DirectEve.Session.StationId.HasValue || LocationId != DirectEve.Session.StationId) && !DirectEve.Session.Structureid.HasValue)
                return false;

            if (ItemId == 0 || !PyItem.IsValid || !IsSingleton)
                return false;

            PyObject PyRepackageItems = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("RepackageItem");
            return DirectEve.ThreadedCall(PyRepackageItems, new List<PyObject> { PyItem });
        }

        /// <summary>
        ///     Leave this ship
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Fails if the current location is not the same as the current station and if its not a CategoryShip
        /// </remarks>
        public bool LeaveShip()
        {
            if (ItemId != DirectEve.Session.ShipId)
                return false;

            if (Quantity > 0)
                return false;

            //if (LocationId != DirectEve.Session.StationId)
            //    return false;

            if (CategoryId != (int)DirectEve.Const.CategoryShip)
                return false;

            return DirectEve.ThreadedLocalSvcCall("station", "TryLeaveShip", PyItem);
        }

        public bool MoveToPlexVault()
        {
            if (TypeId != 29668 && TypeId != 44992)
                return false;

            PyObject redeemCurrency = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("RedeemCurrency");

            if (redeemCurrency == null || !redeemCurrency.IsValid)
                return false;

            return DirectEve.ThreadedCall(redeemCurrency, PyItem, Stacksize);
        }

        /// <summary>
        ///     Open up the quick-buy window to buy more of this item
        /// </summary>
        /// <returns></returns>
        public bool QuickBuy()
        {
            return DirectEve.ThreadedLocalSvcCall("marketutils", "Buy", TypeId, PyItem);
        }

        /// <summary>
        ///     Open up the quick-sell window to sell this item
        /// </summary>
        /// <returns></returns>
        public bool QuickSell()
        {
            return DirectEve.ThreadedLocalSvcCall("marketutils", "Sell", TypeId, PyItem);
        }

        public bool AssembleContainer()
        {
            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.IsInDockableLocation)
                return false;

            if (IsSingleton)
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "AssembleContainer", new List<PyObject> { PyItem }))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        ///     Set the name of an item.  Be sure to call DirectEve.ScatterEvent("OnItemNameChange") shortly after calling this
        ///     function.  Do not call ScatterEvent from the same frame!!
        /// </summary>
        /// <remarks>See menuSvc.SetName</remarks>
        /// <param name="name">The new name for this item.</param>
        /// <returns>true if successful.  false if not.</returns>
        public bool SetName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return false;

            if (CategoryId != (int)DirectEve.Const.CategoryShip && name.Length > 20)
                return false;

            if (CategoryId != (int)DirectEve.Const.CategoryStructure && name.Length > 32)
                return false;

            if (name.Length > 100)
                return false;

            if (ItemId == 0 || !PyItem.IsValid)
                return false;

            PyObject pyCall = DirectEve.GetLocalSvc("invCache").Call("GetInventoryMgr").Attribute("SetLabel");
            return DirectEve.ThreadedCall(pyCall, ItemId, name.Replace('\n', ' '));
        }

        /// <summary>
        ///     Drop items into People and Places
        /// </summary>
        /// <param name="directEve"></param>
        /// <param name="bookmarks"></param>
        /// <returns></returns>
        internal static bool DropInPlaces(DirectEve directEve, IEnumerable<DirectItem> bookmarks)
        {
            List<PyObject> data = new List<PyObject>();
            foreach (DirectItem bookmark in bookmarks)
                data.Add(directEve.PySharp.Import("uix").Call("GetItemData", bookmark.PyItem, "list"));

            return directEve.ThreadedLocalSvcCall("addressbook", "DropInPlaces", PySharp.PyNone, data);
        }

        internal static List<DirectItem> GetItems(DirectEve directEve, PyObject inventory, PyObject flag)
        {
            List<DirectItem> items = new List<DirectItem>();
            Dictionary<PyObject, PyObject> cachedItems = inventory.Attribute("cachedItems").ToDictionary();
            Dictionary<PyObject, PyObject>.ValueCollection pyItems = cachedItems.Values;

            foreach (PyObject pyItem in pyItems)
            {
                DirectItem item = new DirectItem(directEve);
                item.PyItem = pyItem;

                // Do not add the item if the flags do not coincide
                if (flag.IsValid && (int)flag != item.FlagId)
                    continue;

                items.Add(item);
            }

            return items;
        }

        internal static bool RefreshItems(DirectEve directEve, PyObject inventory, PyObject flag)
        {
            return directEve.ThreadedCall(inventory.Attribute("InvalidateCache"));
        }

        #endregion Methods

        //            if (TypeId != 29668)
        //                return false;
        //
        //            var ApplyPilotLicence = PySharp.Import("__builtin__").Attribute("sm").Call("RemoteSvc", "userSvc").Attribute("ApplyPilotLicence");
        //            return DirectEve.ThreadedCall(ApplyPilotLicence, ItemId);
        //        }
    }
}