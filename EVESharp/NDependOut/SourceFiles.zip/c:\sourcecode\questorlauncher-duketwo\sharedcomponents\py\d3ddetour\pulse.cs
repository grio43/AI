﻿namespace SharedComponents.Py.D3DDetour
{
    public static class Pulse
    {
        #region Fields

        //private static LocalHook _hook;
        //public static Magic Magic = new Magic();
        public static D3DHook Hook;

        #endregion Fields

        #region Methods

        public static void Initialize(D3DVersion ver)
        {
            switch (ver)
            {
                case D3DVersion.Direct3D9:
                    Hook = new D3D9();
                    break;

                case D3DVersion.Direct3D11:
                    Hook = new D3D11();
                    break;
            }

            if (Hook == null)
            {
            }

            Hook.Initialize();
        }

        public static void Shutdown()
        {
            Hook.Remove();
        }

        #endregion Methods
    }
}