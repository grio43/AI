﻿extern alias SC;

using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Lookup;
using SC::SharedComponents.EVE;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.IPC;
using System;
using System.Linq;
using System.Collections.Generic;

namespace EVESharpCore.Cache
{
    public class ModuleCache
    {
        #region Constructors

        public ModuleCache(DirectModule module)
        {
            _module = module;
        }

        #endregion Constructors

        #region Fields

        internal readonly DirectModule _module;

        private int ActivateCountThisFrame;

        private int ClickCountThisFrame;

        //private double? _damageMultiplier = null;

        #endregion Fields

        #region Properties

        public bool AutoReload => _module.AutoReload;
        public double? CapacitorNeed => _module.CapacitorNeed ?? 0;
        public DirectItem Charge => _module.Charge;
        public int ChargeQty => _module.ChargeQty;

        public double Damage => _module.Damage;
        public double DamagePercent => _module.DamagePercent;

        public bool DisableAutoReload
        {
            get
            {
                if (IsActivatable && !InLimboState)
                {
                    if (_module.AutoReload)
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("ModuleCache: DisableAutoReload: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (_module.SetAutoReload(false))
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            Log.WriteLine("ModuleCache: DisableAutoReload");
                            return false;
                        }

                        return false;
                    }

                    return true;
                }

                return true;
            }
        }

        public double Duration => _module.Duration ?? 0;

        public bool EnableAutoReload
        {
            get
            {
                if (IsActivatable && !InLimboState)
                {
                    if (!_module.AutoReload)
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("ModuleCache: DisableAutoReload: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (_module.SetAutoReload(true))
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            Log.WriteLine("ModuleCache: DisableAutoReload");
                            return false;
                        }

                        return false;
                    }

                    return true;
                }

                return true;
            }
        }

        public double FallOff => _module.FallOff ?? 0;

        public double FalloffEffectiveness => _module.FalloffEffectiveness ?? 0;
        public DirectModule GetDirectModule => _module;

        public bool IsHighAngleWeapon
        {
            get
            {
                if (IsTurret)
                {
                    // afaik: Missiles do not have a High Angle Weapon equivalent
                    //
                    // Projectile Autocannon HAW
                    if (TypeName.Contains("Quad 800mm Repeating"))
                        return true;

                    // Hybrid Blaster HAW
                    if (TypeName.Contains("Triple Neutron Blaster"))
                        return true;

                    // Laser Pulse HAW
                    if (TypeName.Contains("Quad Mega Pulse"))
                        return true;

                    // Missile Torpedo HAW
                    if (TypeName.Contains("Rapid Torpedo Launcher"))
                        return true;


                    return false;
                }

                return false;
            }
        }
        public int GroupId => _module.GroupId;
        public double Hp => _module.Hp;

        public bool InLimboState
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace)
                        return false;

                    if (ESCache.Instance.InStation)
                        return false;

                    if (!IsEnergyWeapon && Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(ItemId))
                        if (DateTime.UtcNow < Time.Instance.LastReloadedTimeStamp[ItemId].AddSeconds(2))
                            return true;

                    if (Time.Instance.LastWeaponHasNoAmmoTimeStamp != null && Time.Instance.LastWeaponHasNoAmmoTimeStamp.ContainsKey(ItemId))
                        if (DateTime.UtcNow < Time.Instance.LastWeaponHasNoAmmoTimeStamp[ItemId].AddSeconds(2) && !IsReloadingAmmo)
                            return true;

                    if (!IsOnline)
                        return true;

                    if (!IsActivatable)
                        return true;

                    if (IsReloadingAmmo)
                        return true;

                    if (IsDeactivating)
                        return true;

                    if (IsCloak && _module.ReactivationDelay > 0)
                        return true;

                    if (IsActive)
                        return false;

                    if (WeaponNeedsAmmo() &&
                        (Charge == null || ChargeQty == 0) &&
                        Time.Instance.LastWeaponHasNoAmmoTimeStamp.ContainsKey(ItemId))
                    {
                        Log.WriteLine("ActivateWeapons: deactivate: no ammo loaded? [" + TypeName + "][" + ItemId + "]");

                        AmmoType ammo = DirectModule.DefinedAmmoTypes.FirstOrDefault(a => Charge != null && a.TypeId == Charge.TypeId);

                        if (ammo == null)
                            if (DebugConfig.DebugActivateWeapons)
                                Log.WriteLine("ActivateWeapons: deactivate: ammo == null [" + TypeName + "][" + ItemId +
                                              "] someone manually loaded ammo we do not have defined as an AmmoType?");

                        //
                        // if we still have no ammo loaded and are not actively reloading after 6 seconds, refresh the timestamp so that we try to reload again
                        //
                        if (DateTime.UtcNow > Time.Instance.LastWeaponHasNoAmmoTimeStamp[ItemId].AddSeconds(6))
                            Time.Instance.LastWeaponHasNoAmmoTimeStamp[ItemId] = DateTime.UtcNow;

                        //
                        // if we still have no ammo loaded after waiting 2 seconds (above) then attempt to reload (ReloadAmmo only allows a reload every x seconds, it will not spam reload)
                        //
                        Combat.ReloadAmmo(this, ESCache.Instance.MyShipEntity, 0, true);
                        return true;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("InLimboState - Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsActivatable => _module.IsActivatable;
        public bool IsActive => _module.IsActive;

        public bool IsArmorRepairModule
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.ArmorRepairer;
                    result |= GroupId == (int)Group.AncillaryArmorBooster;
                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("IsEwarModule - Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsCivilianWeapon
        {
            get
            {
                if (TypeId == (int)TypeID.CivilianGatlingAutocannon)
                    return true;

                if (TypeId == (int)TypeID.CivilianGatlingPulseLaser)
                    return true;

                if (TypeId == (int)TypeID.CivilianGatlingRailgun)
                    return true;

                if (TypeId == (int)TypeID.CivilianLightElectronBlaster)
                    return true;

                return false;
            }
        }

        public bool IsDeactivating => _module.IsDeactivating;
        public bool IsEnergyWeapon => GroupId == (int)Group.EnergyWeapon;

        public bool IsEwarModule
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.WarpDisruptor;
                    result |= GroupId == (int)Group.StasisWeb;
                    result |= GroupId == (int)Group.TargetPainter;
                    result |= GroupId == (int)Group.TrackingDisruptor;
                    result |= GroupId == (int)Group.Neutralizer;
                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("IsEwarModule - Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsMiningModule
        {
            get
            {
                if (!IsHighSlotModule)
                    return false;

                if (GroupId == (int)Group.Miners)
                    return true;

                if (GroupId == (int)Group.StripMiners)
                    return true;

                if (GroupId == (int)Group.ModulatedStripMiners)
                    return true;

                return false;
            }
        }
        public bool IsHighSlotModule
        {
            get
            {
                if (GroupId == (int)Group.EnergyWeapon) return true;
                if (GroupId == (int)Group.ProjectileWeapon) return true;
                if (GroupId == (int)Group.HybridWeapon) return true;
                if (GroupId == (int)Group.PrecursorWeapon) return true;
                if (GroupId == (int)Group.AssaultMissileLaunchers) return true;
                if (GroupId == (int)Group.CruiseMissileLaunchers) return true;
                if (GroupId == (int)Group.DefenderMissileLaunchers) return true;
                if (GroupId == (int)Group.HeavyAssaultMissileLaunchers) return true;
                if (GroupId == (int)Group.HeavyMissileLaunchers) return true;
                if (GroupId == (int)Group.LightMissileLaunchers) return true;
                if (GroupId == (int)Group.RapidHeavyMissileLaunchers) return true;
                if (GroupId == (int)Group.StandardMissileLaunchers) return true;
                if (GroupId == (int)Group.TorpedoLaunchers) return true;
                if (GroupId == (int)Group.CitadelTorpLaunchers) return true;
                if (GroupId == (int)Group.CitadelCruiseLaunchers) return true;
                if (GroupId == (int)Group.RocketLaunchers) return true;
                if (GroupId == (int)Group.Neutralizer) return true;
                //if (GroupId == (int)Group.SmartBombs) return true;
                if (GroupId == (int)Group.ModulatedStripMiners) return true;
                if (GroupId == (int)Group.RemoteArmorRepairer) return true;
                if (GroupId == (int)Group.RemoteHullRepairer) return true;
                if (GroupId == (int)Group.RemoteShieldRepairer) return true;
                if (GroupId == (int)Group.StripMiners) return true;
                if (GroupId == (int)Group.Miners) return true;
                if (GroupId == (int)Group.GasCloudHarvester) return true;
                if (GroupId == (int)Group.Salvager) return true;
                if (GroupId == (int)Group.TractorBeam) return true;
                return false;
            }
        }

        public bool IsInLimboState => InLimboState;

        public bool IsLowSlotModule
        {
            get
            {
                if (GroupId == (int)Group.ArmorRepairer) return true;
                if (GroupId == (int)Group.ArmorHardeners) return true;
                if (GroupId == (int)Group.DamageControl) return true;
                //if (GroupId == (int)Group.TrackingLink) return true;
                return false;
            }
        }

        public bool IsMidSlotModule
        {
            get
            {
                if (GroupId == (int)Group.ShieldBoosters) return true;
                if (GroupId == (int)Group.ShieldHardeners) return true;
                if (GroupId == (int)Group.AncillaryShieldBooster) return true;
                if (GroupId == (int)Group.TrackingDisruptor) return true;
                if (GroupId == (int)Group.WarpDisruptor) return true;
                if (GroupId == (int)Group.StasisWeb) return true;
                if (GroupId == (int)Group.StasisGrappler) return true;
                if (GroupId == (int)Group.Afterburner) return true;
                if (GroupId == (int)Group.CapacitorInjector) return true;
                if (GroupId == (int)Group.SensorBooster) return true;
                if (GroupId == (int)Group.SensorDampener) return true;
                if (GroupId == (int)Group.TargetPainter) return true;
                if (GroupId == (int)Group.TrackingComputer) return true;
                return false;
            }
        }

        public bool IsMissileLauncher => _module.IsMissileLauncher;

        public bool IsOnline => _module.IsOnline;
        public bool IsOverloaded => _module.IsOverloaded;
        public bool IsPendingOverloading => _module.IsPendingOverloading;
        public bool IsPendingStopOverloading => _module.IsPendingStopOverloading;

        public bool IsReloadingAmmo
        {
            get
            {
                if (Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(ItemId))
                    if (DateTime.UtcNow < Time.Instance.LastReloadedTimeStamp[ItemId].AddSeconds(3))
                        return true;

                return _module.IsReloadingAmmo;
            }
        }

        public bool IsShieldRepairModule
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.ShieldBoosters;
                    result |= GroupId == (int)Group.AncillaryShieldBooster;
                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsArmorHardener
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.ArmorHardeners;
                    return result;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception: [" + ex + "]");
                    return false;
                }
            }
        }

        public bool IsShieldHardener
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.ShieldHardeners;
                    return result;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception: [" + ex + "]");
                    return false;
                }
            }
        }

        public bool IsTurret => _module.IsTurret;

        public long ItemId => _module.ItemId;

        public long LastTargetId
        {
            get
            {
                if (ESCache.Instance.LastModuleTargetIDs.ContainsKey(ItemId))
                    return ESCache.Instance.LastModuleTargetIDs[ItemId];

                return -1;
            }
        }

        public int MaxCharges => _module.MaxCharges;

        public double MaxRange
        {
            get
            {
                try
                {
                    double? _maxRange = null;
                    if (_maxRange == null || _maxRange == 0)
                    {
                        if (_module.GroupId == (int)Group.RemoteArmorRepairer || _module.GroupId == (int)Group.RemoteShieldRepairer ||
                            _module.GroupId == (int)Group.RemoteHullRepairer)
                            return Combat.RemoteRepairDistance;

                        if (_module.GroupId == (int)Group.NOS || _module.GroupId == (int)Group.Neutralizer)
                            return Combat.NosDistance;

                        if (_module.IsTurret)
                        {
                            //if (requiresAmmo)
                            if (Charge != null)
                            {
                                if (GroupId == (int)Group.PrecursorWeapon)
                                {
                                    if (DebugConfig.DebugReloadAll) Log.WriteLine("MaxRange: _module.OptimalRange;");
                                    return (double)_module.OptimalRange;
                                }
                            }
                        }

                        if (!_module.IsMissileLauncher)
                            return ChargeRange;

                        if (_module.OptimalRange != null && _module.OptimalRange > 0)
                            return (double)_module.OptimalRange;

                        return 0;
                    }

                    return (double)_maxRange;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [ " + ex + " ]");
                }

                return 0;
            }
        }

        public double ChargeRange => _module.ChargeRange;

        public bool OnlineModule => _module.OnlineModule();
        public double OptimalRange => _module.OptimalRange ?? 0;
        public double PowerTransferRange => _module.PowerTransferRange ?? 0;
        public long TargetId => _module.TargetId ?? -1;
        public double TrackingSpeed => _module.TrackingSpeed ?? 0;
        public int TypeId => _module.TypeId;

        public string TypeName => _module.TypeName;

        #endregion Properties

        /**
        public bool IsReloadingAmmo
        {
            get
            {
                int reloadDelayToUseForThisWeapon;
                if (IsEnergyWeapon)
                    reloadDelayToUseForThisWeapon = 1;
                else
                    reloadDelayToUseForThisWeapon = Time.Instance.ReloadWeaponDelayBeforeUsable_seconds;

                if (Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(ItemId))
                    if (DateTime.UtcNow < Time.Instance.LastReloadedTimeStamp[ItemId].AddSeconds(reloadDelayToUseForThisWeapon))
                    {
                        if (DebugConfig.DebugActivateWeapons)
                            Log.WriteLine("TypeName: [" + _module.TypeName + "] This module is likely still reloading! Last reload was [" +
                                          Math.Round(DateTime.UtcNow.Subtract(Time.Instance.LastReloadedTimeStamp[ItemId]).TotalSeconds, 0) + "sec ago]");
                        return true;
                    }

                return false;
            }
        }
        **/
        /**
        public bool IsChangingAmmo
        {
            get
            {
                int reloadDelayToUseForThisWeapon;
                if (IsEnergyWeapon)
                    reloadDelayToUseForThisWeapon = 1;
                else
                    reloadDelayToUseForThisWeapon = Time.Instance.ReloadWeaponDelayBeforeUsable_seconds;

                if (Time.Instance.LastChangedAmmoTimeStamp != null && Time.Instance.LastChangedAmmoTimeStamp.ContainsKey(ItemId))
                    if (DateTime.UtcNow < Time.Instance.LastChangedAmmoTimeStamp[ItemId].AddSeconds(reloadDelayToUseForThisWeapon))
                        return true;

                return false;
            }
        }
        **/

        #region Methods

        public bool Activate(EntityCache target)
        {
            try
            {
                if (IsActive)
                {
                    Log.WriteLine("Activate: Module [" + TypeName + "][" + ItemId + "] is already active. waiting...");
                    return false;
                }

                if (InLimboState) // || ActivateCountThisFrame > 0)
                {
                    if (DebugConfig.DebugDefense || DebugConfig.DebugActivateWeapons)
                        Log.WriteLine("if (InLimboState || ClickCountThisFrame > 0)");
                    return false;
                }

                if (!target.IsTarget)
                {
                    if (DebugConfig.DebugActivateWeapons)
                        Log.WriteLine("if (!target.IsTarget)");
                    return false;
                }

                if (IsEwarModule && target.IsEwarImmune)
                {
                    if (DebugConfig.DebugDefense)
                        Log.WriteLine("if (IsEwarModule && target.IsEwarImmune)");
                    return false;
                }

                if (Time.Instance.LastActivatedTimeStamp != null && Time.Instance.LastActivatedTimeStamp.ContainsKey(ItemId))
                {
                    if (DateTime.UtcNow < Time.Instance.LastActivatedTimeStamp[ItemId].AddMilliseconds(Settings.Instance.EnforcedDelayBetweenModuleClicks))
                    {
                        if (DebugConfig.DebugDefense)
                            Log.WriteLine(
                                "if (DateTime.UtcNow < Time.Instance.LastClickedTimeStamp[ItemId].AddMilliseconds(Settings.Instance.EnforcedDelayBetweenModuleClicks))");
                        return false;
                    }

                    if (_module.Duration != null)
                    {
                        double CycleTime = (double)_module.Duration + 500;
                        if (DateTime.UtcNow < Time.Instance.LastActivatedTimeStamp[ItemId].AddMilliseconds(CycleTime))
                        {
                            if (DebugConfig.DebugDefense)
                                Log.WriteLine("if (DateTime.UtcNow < Time.Instance.LastClickedTimeStamp[ItemId].AddMilliseconds(CycleTime))");
                            return false;
                        }
                    }
                }

                if (ESCache.Instance.Weapons.Any(i => i.ItemId == ItemId))
                    if (ChargeQty == 0 && WeaponNeedsAmmo())
                    {
                        Log.WriteLine("Activate: Weapon [" + TypeName + "][" + ItemId + "] needs ammo but currently has none. waiting...");
                        return false;
                    }

                if (!target.IsValid)
                    return false;

                ActivateCountThisFrame++;

                if (Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(ItemId))
                    if (DateTime.UtcNow < Time.Instance.LastReloadedTimeStamp[ItemId].AddSeconds(Time.Instance.ReloadWeaponDelayBeforeUsable_seconds))
                    {
                        if (DebugConfig.DebugActivateWeapons)
                            Log.WriteLine("TypeName: [" + _module.TypeName + "] This module is likely still reloading! aborting activating this module.");
                        return false;
                    }

                if (Time.Instance.LastChangedAmmoTimeStamp != null && Time.Instance.LastChangedAmmoTimeStamp.ContainsKey(ItemId))
                    if (DateTime.UtcNow < Time.Instance.LastChangedAmmoTimeStamp[ItemId].AddSeconds(Time.Instance.ReloadWeaponDelayBeforeUsable_seconds))
                    {
                        if (DebugConfig.DebugActivateWeapons)
                            Log.WriteLine("TypeName: [" + _module.TypeName +
                                          "] This module is likely still changing ammo! aborting activating this module.");
                        return false;
                    }

                if (!target.IsTarget)
                {
                    if (ESCache.Instance.InMission && MissionSettings.MyMission != null && MissionSettings.MyMission.Name.ToLower().Contains("Anomic".ToLower()))
                    {
                        if (!target.IsTargeting)
                        {
                            if (target.LockTarget("Activate"))
                            {
                                Log.WriteLine("Target [" + target.Name + "][" + Math.Round(target.Distance / 1000, 2) + "]IsTargeting[" + target.IsTargeting +
                                              "] was not locked, aborting activating module and attempting to lock this target.");
                                return false;
                            }

                            return false;
                        }

                        return false;
                    }

                    Log.WriteLine("Target [" + target.Name + "][" + Math.Round(target.Distance / 1000, 2) + "]IsTargeting[" + target.IsTargeting +
                                  "] was not locked, aborting activating module as we cant activate a module on something that is not locked!");
                    return false;
                }

                if (target.IsEwarImmune && IsEwarModule)
                {
                    Log.WriteLine("Target [" + target.Name + "][" + Math.Round(target.Distance / 1000, 2) + "]IsEwarImmune[" + target.IsEwarImmune +
                                  "] is EWar Immune and Module [" + _module.TypeName + "] isEwarModule [" + IsEwarModule + "]");
                    return false;
                }

                if (!_module.Activate(target.Id))
                {
                    Log.WriteLine("Attempt to activate [" + _module.TypeName + "] on [" + target.Name + "] at [" + Math.Round(target.Distance / 1000, 0) + "k] failed. if (!_module.Activate(target.Id))");
                    return false;
                }

                Time.Instance.LastActivatedTimeStamp[ItemId] = DateTime.UtcNow;
                ESCache.Instance.LastModuleTargetIDs[ItemId] = target.Id;
                return true;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Activate - Exception: [" + exception + "]");
                return false;
            }
        }

        public bool ChangeAmmo(DirectItem charge, int weaponNumber, double Range, EntityCache entity = null)
        {
            if (!IsReloadingAmmo)
            {
                if (!InLimboState)
                {
                    if (_module.Charge == null || _module.Charge != null && _module.Charge.TypeId != charge.TypeId)
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("ModuleCache: ChangeAmmo: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (Time.Instance.LastChangedAmmoTimeStamp != null && Time.Instance.LastChangedAmmoTimeStamp.ContainsKey(ItemId))
                        {
                            if (Time.Instance.LastChangedAmmoTimeStamp[ItemId].AddSeconds(125) > DateTime.UtcNow)
                            {
                                if (DebugConfig.DebugReloadAll) Log.WriteLine("ModuleCache: ChangeAmmo: We have changed ammo recently: ignoring request to change ammo again until 65 seconds have passed since the last ammo change");
                                return true;
                            }
                        }

                        if (Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(ItemId))
                        {
                            if (Time.Instance.LastReloadedTimeStamp[ItemId].AddSeconds(25) > DateTime.UtcNow)
                            {
                                if (DebugConfig.DebugReloadAll) Log.WriteLine("ModuleCache: ChangeAmmo: We have reloaded ammo recently: ignoring request to change ammo again until 65 seconds have passed since the last ammo change");
                                return true;
                            }
                        }

                        if (_module.ChangeAmmo(charge))
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            //if (entity != null) Log.WriteLine("Changing [" + weaponNumber + "][" + _module.TypeName + "] with [" + charge.TypeName + "][" +
                            //              Math.Round(Range / 1000, 0) +
                            //              "] so we can hit [" + entity.Name + "][" + Math.Round(entity.Distance / 1000, 0) + "k]");
                            Time.Instance.LastChangedAmmoTimeStamp[ItemId] = DateTime.UtcNow;

                            if (Time.Instance.ReloadTimePerModule.ContainsKey(ItemId))
                                Time.Instance.ReloadTimePerModule[ItemId] = Time.Instance.ReloadTimePerModule[ItemId] +
                                                                            Time.Instance.ReloadWeaponDelayBeforeUsable_seconds;
                            else
                                Time.Instance.ReloadTimePerModule[ItemId] = Time.Instance.ReloadWeaponDelayBeforeUsable_seconds;

                            return true;
                        }

                        return false;
                    }

                    Log.WriteLine("[" + weaponNumber + "][" + _module.TypeName + "] already has [" + charge.TypeName + "] TypeId [" + charge.TypeId + "] loaded.");
                    return true;
                }

                Log.WriteLine("[" + weaponNumber + "][" + _module.TypeName + "] is currently in a limbo state, waiting");
                return false;
            }

            Log.WriteLine("[" + weaponNumber + "][" + _module.TypeName + "] is already reloading, waiting");
            return false;
        }

        public bool IsCovOpsCloak
        {
            get
            {
                try
                {
                    if (TypeId == (int)TypeID.CovertOpsCloakingDevice)
                        return true;

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        public bool IsCloak
        {
            get
            {
                try
                {
                    if (IsCovOpsCloak)
                        return true;

                    //if (TypeId == TypeID.PrototypeCloak)

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        public bool Click()
        {
            try
            {
                if ((InLimboState || ClickCountThisFrame > 0) && !IsCloak)
                {
                    if (DebugConfig.DebugClick || DebugConfig.DebugDefense)
                        Log.WriteLine("if (InLimboState || ClickCountThisFrame > 0)");
                    return false;
                }

                if (Time.Instance.LastClickedTimeStamp != null && Time.Instance.LastClickedTimeStamp.ContainsKey(ItemId))
                {
                    if (DateTime.UtcNow < Time.Instance.LastClickedTimeStamp[ItemId].AddMilliseconds(Settings.Instance.EnforcedDelayBetweenModuleClicks))
                    {
                        if (DebugConfig.DebugClick || DebugConfig.DebugDefense)
                            Log.WriteLine(
                                "if (DateTime.UtcNow < Time.Instance.LastClickedTimeStamp[ItemId].AddMilliseconds(Settings.Instance.EnforcedDelayBetweenModuleClicks))");
                        return false;
                    }

                    if (_module.Duration != null)
                    {
                        double CycleTime = (double)_module.Duration + 500;
                        if (DateTime.UtcNow < Time.Instance.LastClickedTimeStamp[ItemId].AddMilliseconds(CycleTime))
                        {
                            if (DebugConfig.DebugClick || DebugConfig.DebugDefense)
                                Log.WriteLine("if (DateTime.UtcNow < Time.Instance.LastClickedTimeStamp[ItemId].AddMilliseconds(CycleTime))");
                            return false;
                        }
                    }
                }

                ClickCountThisFrame++;

                if (IsActivatable && ESCache.Instance.ActiveShip.Capacitor > CapacitorNeed)
                {
                    if (!IsActive)
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow && !IsCloak)
                        {
                            //if (DebugConfig.DebugInteractWithEve)
                            Log.WriteLine("ModuleCache: Click: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (_module.Click())
                        {
                            if (DebugConfig.DebugClick) Log.WriteLine("Module [" + TypeName + "][" + ItemId + "] Clicked to Activate");
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            if (Time.Instance.LastClickedTimeStamp != null) Time.Instance.LastActivatedTimeStamp[ItemId] = DateTime.UtcNow;
                            return true;
                        }

                        return false;
                    }

                    if (IsActive)
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            //if (DebugConfig.DebugInteractWithEve)
                            Log.WriteLine("ModuleCache: Click: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (_module.Click())
                        {
                            if (DebugConfig.DebugClick) Log.WriteLine("Module [" + TypeName + "][" + ItemId + "] Clicked to Deactivate");
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            if (Time.Instance.LastClickedTimeStamp != null) Time.Instance.LastClickedTimeStamp[ItemId] = DateTime.UtcNow;
                            return true;
                        }

                        return false;
                    }

                    if (Time.Instance.LastClickedTimeStamp != null) Time.Instance.LastClickedTimeStamp[ItemId] = DateTime.UtcNow;
                    return true;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("ModuleCache.Click - Exception: [" + exception + "]");
                return false;
            }
        }

        public bool ReloadAmmo(DirectItem charge, int weaponNumber, double Range)
        {
            if (!IsReloadingAmmo)
            {
                if (!InLimboState)
                {
                    if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                    {
                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("ModuleCache: ReloadAmmo: !OkToInteractWithEveNow");
                        return false;
                    }

                    if (_module.ReloadAmmo(charge))
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        Log.WriteLine("Reloading [" + weaponNumber + "] [" + _module.TypeName + "] with [" + charge.TypeName + "][" +
                                      Math.Round(Range / 1000, 0) + "]");
                        Time.Instance.LastReloadedTimeStamp[ItemId] = DateTime.UtcNow;
                        if (Time.Instance.ReloadTimePerModule.ContainsKey(ItemId))
                            Time.Instance.ReloadTimePerModule[ItemId] = Time.Instance.ReloadTimePerModule[ItemId] +
                                                                        Time.Instance.ReloadWeaponDelayBeforeUsable_seconds;
                        else
                            Time.Instance.ReloadTimePerModule[ItemId] = Time.Instance.ReloadWeaponDelayBeforeUsable_seconds;
                        return true;
                    }

                    return true;
                }

                Log.WriteLine("[" + weaponNumber + "][" + _module.TypeName + "] is currently in a limbo state, waiting");
                return false;
            }

            Log.WriteLine("[" + weaponNumber + "][" + _module.TypeName + "] is already reloading, waiting");
            return false;
        }

        public bool ToggleOverload()
        {
            return _module.ToggleOverload();
        }

        public bool WeaponNeedsAmmo()
        {
            try
            {
                if (TypeId == (int)TypeID.CivilianGatlingAutocannon)
                    return false;

                if (TypeId == (int)TypeID.CivilianGatlingPulseLaser)
                    return false;

                if (TypeId == (int)TypeID.CivilianGatlingRailgun)
                    return false;

                if (TypeId == (int)TypeID.CivilianLightElectronBlaster)
                    return false;

                //
                // only weapons require ammo, non-weapons (target painters, damps, ecm, etc) may take scripts but they do not require them.
                //
                if (ESCache.Instance.Weapons.Any(i => i.TypeId == TypeId))
                    return true;

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception: [" + exception + "]");
                return false;
            }
        }

        #endregion Methods
    }
}