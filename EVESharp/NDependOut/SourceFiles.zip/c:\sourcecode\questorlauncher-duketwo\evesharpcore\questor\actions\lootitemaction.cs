using EVESharpCore.Cache;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Framework;
using EVESharpCore.Questor.BackgroundTasks;
using Action = EVESharpCore.Questor.Actions.Base.Action;

namespace EVESharpCore.Questor.Actions
{
    public partial class ActionControl
    {
        #region Methods

        private static void LootItemAction(Action action, DirectAgentMission myMission, DirectAgent myAgent)
        {
            try
            {
                Salvage.CurrentlyShouldBeSalvaging = true;
                //Salvage.MissionLoot = true;
                List<string> targetContainerNames = null;
                List<string> targetContainerIds = null;
                long targetContainerId = 0;
                if (action.GetParameterValues("target") != null)
                    targetContainerNames = action.GetParameterValues("target");

                if ((targetContainerNames == null || !targetContainerNames.Any()) && Salvage.LootItemRequiresTarget)
                    Log.WriteLine(" *** No Target Was Specified In the LootItem Action! ***");

                if (action.GetParameterValues("containerid") != null)
                    targetContainerIds = action.GetParameterValues("containerid");
                if (targetContainerIds != null && targetContainerIds.Any())
                    targetContainerId = long.Parse(targetContainerIds.FirstOrDefault());

                List<string> typeIDOfItemsToLoot = null;
                string typeIDOfItemToLoot = null;
                if (action.GetParameterValues("typeIDOfItemToLoot") != null)
                    typeIDOfItemsToLoot = action.GetParameterValues("typeIDOfItemToLoot");

                DirectInvType invTypeToLoot = null;
                if (typeIDOfItemsToLoot != null && typeIDOfItemsToLoot.Any())
                {
                    typeIDOfItemToLoot = typeIDOfItemsToLoot.FirstOrDefault();
                    if (typeIDOfItemToLoot != null)
                        invTypeToLoot = ESCache.Instance.DirectEve.GetInvType(int.Parse(typeIDOfItemToLoot));
                }

                List<string> itemsToLoot = null;
                if (action.GetParameterValues("item") != null)
                    itemsToLoot = action.GetParameterValues("item");

                if (itemsToLoot == null && typeIDOfItemToLoot == null)
                {
                    Log.WriteLine(" *** No Item Was Specified In the LootItem Action! ***");
                    Nextaction(myMission, myAgent, true);
                }

                // if we are not generally looting we need to re-enable the opening of wrecks to
                // find this LootItems we are looking for
                Salvage.OpenWrecks = true;

                int quantity;
                if (!int.TryParse(action.GetParameterValue("quantity"), out quantity))
                    quantity = 1;

                if (ESCache.Instance.CurrentShipsCargo != null &&
                    ESCache.Instance.CurrentShipsCargo.Items.Any(i => itemsToLoot != null && itemsToLoot.Contains(i.TypeName, StringComparer.OrdinalIgnoreCase) && i.Quantity >= quantity))
                {
                    Log.WriteLine("We are done - we have the item(s)");

                    // now that we have completed this action revert OpenWrecks to false
                    if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
                    {
                        if (DebugConfig.DebugTargetWrecks) Log.WriteLine("Salvage.OpenWrecks = false;");
                        Salvage.OpenWrecks = false;
                    }

                    //Salvage.MissionLoot = false;
                    Salvage.CurrentlyShouldBeSalvaging = false;
                    Nextaction(myMission, myAgent, true);
                    return;
                }

                //
                // we re-sot by distance on every pulse. The order will be potentially different on each pulse as we move around the field. this is ok and desirable.
                //
                if (ESCache.Instance.Containers == null) return;
                IOrderedEnumerable<EntityCache> containers =
                    ESCache.Instance.Containers.Where(e => !ESCache.Instance.LootedContainers.Contains(e.Id))
                        .OrderByDescending(e => e.GroupId == (int)Group.CargoContainer)
                        .ThenBy(e => e.IsWreckEmpty)
                        .ThenBy(e => e.Distance);

                if (DebugConfig.DebugLootWrecks)
                {
                    int i = 0;
                    foreach (EntityCache _container in containers)
                    {
                        i++;
                        Log.WriteLine("[" + i + "] " + _container.Name + "[" + Math.Round(_container.Distance / 1000, 0) + "k] isWreckEmpty [" +
                                      _container.IsWreckEmpty +
                                      "] IsTarget [" + _container.IsTarget + "]");
                    }

                    i = 0;
                    foreach (string _targetContainer in targetContainerNames)
                    {
                        i++;
                        Log.WriteLine("TargetContainerName [" + i + "][ " + _targetContainer + " ]");
                    }
                }

                if (!containers.Any())
                {
                    Log.WriteLine("no containers left to loot, next action");

                    if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
                    {
                        if (DebugConfig.DebugTargetWrecks) Log.WriteLine("Salvage.OpenWrecks = false;");
                        Salvage.OpenWrecks = false;
                    }

                    //Salvage.MissionLoot = false;
                    Salvage.CurrentlyShouldBeSalvaging = false;
                    Nextaction(myMission, myAgent, true);
                    return;
                }

                if (targetContainerId != 0)
                    if (!ESCache.Instance.ListofContainersToLoot.Contains(targetContainerId))
                        ESCache.Instance.ListofContainersToLoot.Add(targetContainerId);

                //
                // add containers that we were told to loot into the ListofContainersToLoot so that they are prioritized by the background salvage routine
                //
                if (targetContainerNames != null && targetContainerNames.Any())
                    foreach (EntityCache continerToLoot in containers)
                        if (targetContainerNames.Any())
                            foreach (string targetContainerName in targetContainerNames)
                            {
                                if (continerToLoot.Name.ToLower().Contains(targetContainerName.ToLower()))
                                    if (!ESCache.Instance.ListofContainersToLoot.Contains(continerToLoot.Id))
                                        ESCache.Instance.ListofContainersToLoot.Add(continerToLoot.Id);
                            }
                        else
                            foreach (EntityCache _unlootedcontainer in ESCache.Instance.UnlootedContainers)
                            {
                                if (continerToLoot.Name == _unlootedcontainer.Name)
                                    if (!ESCache.Instance.ListofContainersToLoot.Contains(continerToLoot.Id))
                                        ESCache.Instance.ListofContainersToLoot.Add(continerToLoot.Id);
                            }

                if (invTypeToLoot != null)
                    if (!ESCache.Instance.ListofMissionCompletionItemsToLoot.Contains(invTypeToLoot.TypeName))
                        ESCache.Instance.ListofMissionCompletionItemsToLoot.Add(invTypeToLoot.TypeName);

                if (itemsToLoot != null && itemsToLoot.Any())
                    foreach (string _itemToLoot in itemsToLoot)
                        if (!ESCache.Instance.ListofMissionCompletionItemsToLoot.Contains(_itemToLoot.ToLower()))
                            ESCache.Instance.ListofMissionCompletionItemsToLoot.Add(_itemToLoot.ToLower());

                EntityCache container;
                if (targetContainerNames != null && targetContainerNames.Any())
                {
                    container = containers.FirstOrDefault(c => targetContainerNames.Contains(c.Name, StringComparer.OrdinalIgnoreCase) || targetContainerNames.Contains(c.TypeName, StringComparer.OrdinalIgnoreCase));
                    if (container == null)
                        foreach (string targetContainerName in targetContainerNames)
                            foreach (EntityCache _container in containers.Where(i => !i.IsWreckEmpty))
                                if (_container.Name.ToLower().Contains(targetContainerName.ToLower()))
                                    container = _container;

                    if (container == null)
                    {
                        Log.WriteLine("no containers exist with [" + targetContainerNames.FirstOrDefault() + "] in the name, assuming it is not a container.");
                        container = ESCache.Instance.Entities.FirstOrDefault(c => targetContainerNames.Contains(c.Name));
                        if (container == null)
                            Log.WriteLine("no entities exist with [" + targetContainerNames.FirstOrDefault() + "] in the name. failing.");
                    }
                }
                else
                {
                    container = containers.FirstOrDefault();
                    if (container == null)
                    {
                        Log.WriteLine("no containers exist with [" + targetContainerNames.FirstOrDefault() + "] in the name, assuming it is not a container.");
                        container = ESCache.Instance.Entities.FirstOrDefault(c => targetContainerNames.Contains(c.Name));
                        if (container == null)
                            Log.WriteLine("no entities exist with [" + targetContainerNames.FirstOrDefault() + "] in the name. failing.");
                    }
                }

                if (container != null)
                {
                    if (container.Distance > (int)Distances.SafeScoopRange)
                        NavigateOnGrid.NavigateToTarget(container, 0);
                }
                else
                {
                    Log.WriteLine("LootItem Action failed. container is null. we were trying to find [ " + targetContainerNames.FirstOrDefault() +
                                  " ] but it doesnt appear to be on grid");
                    Nextaction(myMission, myAgent, true);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception logged was [" + exception + "]");
            }
        }

        #endregion Methods
    }
}