﻿using System;
using System.ComponentModel;

namespace SharedComponents.EVE.ClientSettings
{
    [Serializable]
    public class QuestorMainSetting
    {
        #region Properties

        public string AgentName { get; set; } = "AgentName";
        public bool BuyAmmo { get; set; } = true;
        public int BuyAmmoDroneAmount { get; set; } = 200;
        public int BuyAmmoStationID { get; set; } = 60003760;
        public bool BuyPlex { get; set; } = true;
        public string CombatShipName { get; set; } = "CombatShipName";
        public bool DumpLoot { get; set; } = false;
        public QuestorDebugSetting QDS => QuestorDebugSetting;
        public QuestorSetting QS => QuestorSetting;

        [TabPage("Debug")]
        public QuestorDebugSetting QuestorDebugSetting { get; set; } = new QuestorDebugSetting();

        [TabPage("Settings")]
        public QuestorSetting QuestorSetting { get; set; } = new QuestorSetting();

        [Description("A non empty value defines a group to synchronize questor settings between multiple chars.\nA reload is required after modifying this value.")]
        public string QuestorSettingGroup { get; set; }

        public string TransportShipName { get; set; } = "Transportshipname";

        #endregion Properties
    }
}