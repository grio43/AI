using System.Xml.Linq;

namespace EVESharpCore.Lookup
{
    public static class DebugConfig
    {
        #region Methods

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            DebugAbyssalDeadspaceBehavior =
                (bool?)CharacterSettingsXml.Element("debugAbyssalDeadspaceBehavior") ??
                (bool?)CommonSettingsXml.Element("debugAbyssalDeadspaceBehavior") ?? false;
            DebugHighSecAnomalyBehavior =
                (bool?)CharacterSettingsXml.Element("debugHighSecAnomalyBehavior") ??
                (bool?)CommonSettingsXml.Element("debugHighSecAnomalyBehavior") ?? false;
            DebugActivateGate =
                (bool?)CharacterSettingsXml.Element("debugActivateGate") ??
                (bool?)CommonSettingsXml.Element("debugActivateGate") ?? false;
            DebugActivateBastion =
                (bool?)CharacterSettingsXml.Element("debugActivateBastion") ??
                (bool?)CommonSettingsXml.Element("debugActivateBastion") ?? false;
            DebugActivateWeapons =
                (bool?)CharacterSettingsXml.Element("debugActivateWeapons") ??
                (bool?)CommonSettingsXml.Element("debugActivateWeapons") ?? false;
            DebugAddDronePriorityTarget =
                (bool?)CharacterSettingsXml.Element("debugAddDronePriorityTarget") ??
                (bool?)CommonSettingsXml.Element("debugAddDronePriorityTarget") ?? false;
            DebugAddPrimaryWeaponPriorityTarget =
                (bool?)CharacterSettingsXml.Element("debugAddPrimaryWeaponPriorityTarget") ??
                (bool?)CommonSettingsXml.Element("debugAddPrimaryWeaponPriorityTarget") ?? false;
            DebugAgentInfo =
                (bool?)CharacterSettingsXml.Element("debugAgentInfo") ??
                (bool?)CommonSettingsXml.Element("debugAgentInfo") ?? false;
            DebugAgentInteraction =
                (bool?)CharacterSettingsXml.Element("debugAgentInteraction") ??
                (bool?)CommonSettingsXml.Element("debugAgentInteraction") ?? false;
            DebugAgentInteractionReplyToAgent =
                (bool?)CharacterSettingsXml.Element("debugAgentInteractionReplyToAgent") ??
                (bool?)CommonSettingsXml.Element("debugAgentInteractionReplyToAgent") ?? false;
            DebugArm =
                (bool?)CharacterSettingsXml.Element("debugArm") ??
                (bool?)CommonSettingsXml.Element("debugArm") ?? false;
            DebugBuyLpItem =
                (bool?)CharacterSettingsXml.Element("debugBuyLpItem") ??
                (bool?)CommonSettingsXml.Element("debugBuyLpItem") ?? false;
            DebugCheckSessionValid =
                (bool?)CharacterSettingsXml.Element("debugCheckSessionValid") ??
                (bool?)CommonSettingsXml.Element("debugCheckSessionValid") ?? false;
            DebugCleanup =
                (bool?)CharacterSettingsXml.Element("debugCleanup") ??
                (bool?)CommonSettingsXml.Element("debugCleanup") ?? false;
            DebugClearPocket =
                (bool?)CharacterSettingsXml.Element("debugClearPocket") ??
                (bool?)CommonSettingsXml.Element("debugClearPocket") ?? false;
            DebugClick =
                (bool?)CharacterSettingsXml.Element("debugClick") ??
                (bool?)CommonSettingsXml.Element("debugClick") ?? false;
            DebugCombat =
                (bool?)CharacterSettingsXml.Element("debugCombat") ??
                (bool?)CommonSettingsXml.Element("debugCombat") ?? false;
            DebugCombatController =
                (bool?)CharacterSettingsXml.Element("debugCombatController") ??
                (bool?)CommonSettingsXml.Element("debugCombatController") ?? false;
            DebugCombatMissionCtrl =
                (bool?)CharacterSettingsXml.Element("debugCombatMissionCtrl") ??
                (bool?)CommonSettingsXml.Element("debugCombatMissionCtrl") ?? false;
            DebugCombatMissionsBehavior =
                (bool?)CharacterSettingsXml.Element("debugCombatMissionsBehavior") ??
                (bool?)CommonSettingsXml.Element("debugCombatMissionsBehavior") ?? false;
            DebugControllerManager =
                (bool?)CharacterSettingsXml.Element("debugControllerManager") ??
                (bool?)CommonSettingsXml.Element("debugControllerManager") ?? false;
            DebugCourierMissions =
                (bool?)CharacterSettingsXml.Element("debugCourierMissions") ??
                (bool?)CommonSettingsXml.Element("debugCourierMissions") ?? false;
            DebugCurrentDamageType =
                (bool?)CharacterSettingsXml.Element("debugCurrentDamageType") ??
                (bool?)CommonSettingsXml.Element("debugCurrentDamageType") ?? false;
            DebugCourierContractController =
                (bool?)CharacterSettingsXml.Element("debugCourierContractController") ??
                (bool?)CommonSettingsXml.Element("debugCourierContractController") ?? false;
            DebugDecline =
                (bool?)CharacterSettingsXml.Element("debugDecline") ??
                (bool?)CommonSettingsXml.Element("debugDecline") ?? false;
            DebugDefense =
                (bool?)CharacterSettingsXml.Element("debugDefense") ??
                (bool?)CommonSettingsXml.Element("debugDefense") ?? false;
            DebugDirectionalScanner =
                (bool?)CharacterSettingsXml.Element("debugDirectionalScanner") ??
                (bool?)CommonSettingsXml.Element("debugDirectionalScanner") ?? false;
            DebugDisableDefense =
                (bool?)CharacterSettingsXml.Element("debugDisableDefense") ??
                (bool?)CommonSettingsXml.Element("debugDisableDefense") ?? false;
            DebugDisableIgnoreBookmarkedSignatures =
                (bool?)CharacterSettingsXml.Element("debugDisableIgnoreBookmarkedSignatures") ??
                (bool?)CommonSettingsXml.Element("debugDisableIgnoreBookmarkedSignatures") ?? false;
            DebugDisableTargetCombatants =
                (bool?)CharacterSettingsXml.Element("debugDisableTargetCombatants") ??
                (bool?)CommonSettingsXml.Element("debugDisableTargetCombatants") ?? false;
            DebugDisableCleanup =
                (bool?)CharacterSettingsXml.Element("debugDisableCleanup") ??
                (bool?)CommonSettingsXml.Element("debugDisableCleanup") ?? false;
            DebugDisableCombat =
                (bool?)CharacterSettingsXml.Element("debugDisableCombat") ??
                (bool?)CommonSettingsXml.Element("debugDisableCombat") ?? false;
            DebugDisableDrones =
                (bool?)CharacterSettingsXml.Element("debugDisableDrones") ??
                (bool?)CommonSettingsXml.Element("debugDisableDrones") ?? false;
            DebugDoneAction =
                (bool?)CharacterSettingsXml.Element("debugDoneAction") ??
                (bool?)CommonSettingsXml.Element("debugDoneAction") ?? false;
            DebugDrones =
                (bool?)CharacterSettingsXml.Element("debugDrones") ??
                (bool?)CommonSettingsXml.Element("debugDrones") ?? false;
            DebugDroneController =
                (bool?)CharacterSettingsXml.Element("debugDroneController") ??
                (bool?)CommonSettingsXml.Element("debugDroneController") ?? false;
            DebugEntityCache =
                (bool?)CharacterSettingsXml.Element("debugEntityCache") ??
                (bool?)CommonSettingsXml.Element("debugEntityCache") ?? false;
            DebugFactionWarfareComplexBehavior =
                (bool?)CharacterSettingsXml.Element("debugFactionWarfareComplexBehavior") ??
                (bool?)CommonSettingsXml.Element("debugFactionWarfareComplexBehavior") ?? false;
            DebugFittingMgr =
                (bool?)CharacterSettingsXml.Element("debugFittingMgr") ??
                (bool?)CommonSettingsXml.Element("debugFittingMgr") ?? false;
            DebugGetBestTarget =
                (bool?)CharacterSettingsXml.Element("debugGetBestTarget") ??
                (bool?)CommonSettingsXml.Element("debugGetBestTarget") ?? false;
            DebugGetBestDroneTarget =
                (bool?)CharacterSettingsXml.Element("debugGetBestDroneTarget") ??
                (bool?)CommonSettingsXml.Element("debugGetBestDroneTarget") ?? false;
            DebugGotobase =
                (bool?)CharacterSettingsXml.Element("debugGotobase") ??
                (bool?)CommonSettingsXml.Element("debugGotobase") ?? false;
            DebugCorrectAmmoTypeToUseByRange =
                (bool?)CharacterSettingsXml.Element("debugCorrectAmmoTypeToUseByRange") ??
                (bool?)CommonSettingsXml.Element("debugCorrectAmmoTypeToUseByRange") ?? false;
            DebugCorrectAmmoTypeInCargo =
                (bool?)CharacterSettingsXml.Element("debugCorrectAmmoTypeInCargo") ??
                (bool?)CommonSettingsXml.Element("debugCorrectAmmoTypeInCargo") ?? false;
            DebugCorrectAmmoTypeToUse =
                (bool?)CharacterSettingsXml.Element("debugCorrectAmmoTypeToUse") ??
                (bool?)CommonSettingsXml.Element("debugCorrectAmmoTypeToUse") ?? false;
            DebugHangars =
                (bool?)CharacterSettingsXml.Element("debugHangars") ??
                (bool?)CommonSettingsXml.Element("debugHangars") ?? false;
            DebugIgnoreBookmarkedSignatures =
                (bool?)CharacterSettingsXml.Element("debugIgnoreBookmarkedSignatures") ??
                (bool?)CommonSettingsXml.Element("debugIgnoreBookmarkedSignatures") ?? false;
            DebugInteractWithEve =
                (bool?)CharacterSettingsXml.Element("debugInteractWithEve") ??
                (bool?)CommonSettingsXml.Element("debugInteractWithEve") ?? false;
            DebugInSpace =
                (bool?)CharacterSettingsXml.Element("debugInSpace") ??
                (bool?)CommonSettingsXml.Element("debugInSpace") ?? false;
            DebugInStation =
                (bool?)CharacterSettingsXml.Element("debugInStation") ??
                (bool?)CommonSettingsXml.Element("debugInStation") ?? false;
            DebugKillTargets =
                (bool?)CharacterSettingsXml.Element("debugKillTargets") ??
                (bool?)CommonSettingsXml.Element("debugKillTargets") ?? false;
            DebugInventoryContainers =
                (bool?)CharacterSettingsXml.Element("debugInventoryContainers") ??
                (bool?)CommonSettingsXml.Element("debugInventoryContainers") ?? false;
            DebugKillAction =
                (bool?)CharacterSettingsXml.Element("debugKillAction") ??
                (bool?)CommonSettingsXml.Element("debugKillAction") ?? false;
            DebugLoadScripts =
                (bool?)CharacterSettingsXml.Element("debugLoadScripts") ??
                (bool?)CommonSettingsXml.Element("debugLoadScripts") ?? false;
            DebugLoadSettings =
                (bool?)CharacterSettingsXml.Element("debugLoadSettings") ??
                (bool?)CommonSettingsXml.Element("debugLoadSettings") ?? false;
            DebugLoginRewards =
                (bool?)CharacterSettingsXml.Element("debugLoginRewards") ??
                (bool?)CommonSettingsXml.Element("debugLoginRewards") ?? false;
            DebugLogOrderOfDroneTargets =
                (bool?)CharacterSettingsXml.Element("debugLogOrderOfDroneTargets") ??
                (bool?)CommonSettingsXml.Element("debugLogOrderOfDroneTargets") ?? false;
            DebugLogOrderOfKillTargets =
                (bool?)CharacterSettingsXml.Element("debugLogOrderOfKillTargets") ??
                (bool?)CommonSettingsXml.Element("debugLogOrderOfKillTargets") ?? false;
            DebugLogOrderOfNavigateOnGridTargets =
                (bool?)CharacterSettingsXml.Element("debugLogOrderOfNavigateOnGridTargets") ??
                (bool?)CommonSettingsXml.Element("debugLogOrderOfNavigateOnGridTargets") ?? false;
            DebugLootContainer =
                (bool?)CharacterSettingsXml.Element("debugLootContainer") ??
                (bool?)CommonSettingsXml.Element("debugLootContainer") ?? false;
            DebugLootCorpHangar =
                (bool?)CharacterSettingsXml.Element("debugLootCorpHangar") ??
                (bool?)CommonSettingsXml.Element("debugLootCorpHangar") ?? false;
            DebugLootWrecks =
                (bool?)CharacterSettingsXml.Element("debugLootWrecks") ??
                (bool?)CommonSettingsXml.Element("debugLootWrecks") ?? false;
            DebugMarketOrders =
                (bool?)CharacterSettingsXml.Element("debugMarketOrders") ??
                (bool?)CommonSettingsXml.Element("debugMarketOrders") ?? false;
            DebugMobileTractor =
                (bool?)CharacterSettingsXml.Element("debugMobileTractor") ??
                (bool?)CommonSettingsXml.Element("debugMobileTractor") ?? false;
            DebugMoveTo =
                (bool?)CharacterSettingsXml.Element("debugMoveTo") ??
                (bool?)CommonSettingsXml.Element("debugMoveTo") ?? false;
            DebugNavigateOnGrid =
                (bool?)CharacterSettingsXml.Element("debugNavigateOnGrid") ??
                (bool?)CommonSettingsXml.Element("debugNavigateOnGrid") ?? false;
            DebugOverLoadWeapons =
                (bool?)CharacterSettingsXml.Element("debugOverLoadWeapons") ??
                (bool?)CommonSettingsXml.Element("debugOverLoadWeapons") ?? false;
            DebugPanic =
                (bool?)CharacterSettingsXml.Element("debugPanic") ??
                (bool?)CommonSettingsXml.Element("debugPanic") ?? false;
            DebugPickTargets =
                (bool?)CharacterSettingsXml.Element("debugPickTargets") ??
                (bool?)CommonSettingsXml.Element("debugPickTargets") ?? false;
            DebugPreferredPrimaryWeaponTarget =
                (bool?)CharacterSettingsXml.Element("debugPreferredPrimaryWeaponTarget") ??
                (bool?)CommonSettingsXml.Element("debugPreferredPrimaryWeaponTarget") ?? false;
            DebugReduceGraphicsController =
                (bool?)CharacterSettingsXml.Element("debugReduceGraphicsController") ??
                (bool?)CommonSettingsXml.Element("debugReduceGraphicsController") ?? false;
            DebugReloadAll =
                (bool?)CharacterSettingsXml.Element("debugReloadAll") ??
                (bool?)CommonSettingsXml.Element("debugReloadAll") ?? false;
            DebugReloadorChangeAmmo =
                (bool?)CharacterSettingsXml.Element("debugReloadOrChangeAmmo") ??
                (bool?)CommonSettingsXml.Element("debugReloadOrChangeAmmo") ?? false;
            DebugDisableSalvage =
               (bool?)CharacterSettingsXml.Element("debugDisableSalvage") ??
               (bool?)CommonSettingsXml.Element("debugDisableSalvage") ?? false;
            DebugSalvage =
                (bool?)CharacterSettingsXml.Element("debugSalvage") ??
                (bool?)CommonSettingsXml.Element("debugSalvage") ?? false;
            DebugSalvageGridBehavior =
                (bool?)CharacterSettingsXml.Element("debugSalvageGridBehavior") ??
                (bool?)CommonSettingsXml.Element("debugSalvageGridBehavior") ?? false;
            DebugSignaturesController =
                (bool?)CharacterSettingsXml.Element("debugSignaturesController") ??
                (bool?)CommonSettingsXml.Element("debugSignaturesController") ?? false;
            DebugSkillQueue =
                (bool?)CharacterSettingsXml.Element("debugSkillQueue") ??
                (bool?)CommonSettingsXml.Element("debugSkillQueue") ?? false;
            DebugSlaveBehavior =
                (bool?)CharacterSettingsXml.Element("debugSlaveBehavior") ??
                (bool?)CommonSettingsXml.Element("debugSlaveBehavior") ?? false;
            DebugSpeedMod =
                (bool?)CharacterSettingsXml.Element("debugSpeedMod") ??
                (bool?)CommonSettingsXml.Element("debugSpeedMod") ?? false;
            DebugStorylineMissions =
                (bool?)CharacterSettingsXml.Element("debugStorylineMissions") ??
                (bool?)CommonSettingsXml.Element("debugStorylineMissions") ?? false;
            DebugSubscriptionEnd =
                (bool?)CharacterSettingsXml.Element("debugSubscriptionEnd") ??
                (bool?)CommonSettingsXml.Element("debugSubscriptionEnd") ?? false;
            DebugTargetCombatants =
                (bool?)CharacterSettingsXml.Element("debugTargetCombatants") ??
                (bool?)CommonSettingsXml.Element("debugTargetCombatants") ?? false;
            DebugTargetCombatantsController =
                (bool?)CharacterSettingsXml.Element("debugTargetCombatantsController") ??
                (bool?)CommonSettingsXml.Element("debugTargetCombatantsController") ?? false;
            DebugTargetPainters =
                (bool?)CharacterSettingsXml.Element("debugTargetPainters") ??
                (bool?)CommonSettingsXml.Element("debugTargetPainters") ?? false;
            DebugTargetWrecks =
                (bool?)CharacterSettingsXml.Element("debugTargetWrecks") ??
                (bool?)CommonSettingsXml.Element("debugTargetWrecks") ?? false;
            DebugTraveler =
                (bool?)CharacterSettingsXml.Element("debugTraveler") ??
                (bool?)CommonSettingsXml.Element("debugTraveler") ?? false;
            DebugTractorBeams =
                (bool?)CharacterSettingsXml.Element("debugTractorBeams") ??
                (bool?)CommonSettingsXml.Element("debugTractorBeams") ?? false;
            DebugUndockBookmarks =
                (bool?)CharacterSettingsXml.Element("debugUndockBookmarks") ??
                (bool?)CommonSettingsXml.Element("debugUndockBookmarks") ?? false;
            DebugDockBookmarks =
                (bool?)CharacterSettingsXml.Element("debugDockBookmarks") ??
                (bool?)CommonSettingsXml.Element("debugDockBookmarks") ?? false;
            DebugUnloadLoot =
                (bool?)CharacterSettingsXml.Element("debugUnloadLoot") ??
                (bool?)CommonSettingsXml.Element("debugUnloadLoot") ?? false;
            DebugOverLoadModules =
                (bool?)CharacterSettingsXml.Element("debugOverLoadModules") ??
                (bool?)CommonSettingsXml.Element("debugOverLoadModules") ?? false;
            DebugUnOverLoadModules =
                (bool?)CharacterSettingsXml.Element("debugUnOverLoadModules") ??
                (bool?)CommonSettingsXml.Element("debugUnOverLoadModules") ?? false;
            DebugWarpCloakyTrick =
                (bool?)CharacterSettingsXml.Element("debugWarpCloakyTrick") ??
                (bool?)CommonSettingsXml.Element("debugWarpCloakyTrick") ?? false;
            DebugWatchForActiveWars =
                (bool?)CharacterSettingsXml.Element("debugWatchForActiveWars") ??
                (bool?)CommonSettingsXml.Element("debugWatchForActiveWars") ?? false;
            DebugWindows =
                (bool?)CharacterSettingsXml.Element("debugWindows") ??
                (bool?)CommonSettingsXml.Element("debugWindows") ?? false;
        }

        #endregion Methods

        #region Properties

        public static bool DebugAbyssalDeadspaceBehavior { get; set; }
        public static bool DebugHighSecAnomalyBehavior { get; set; }
        public static bool DebugActivateBastion { get; set; }
        public static bool DebugActivateGate { get; set; }
        public static bool DebugActivateWeapons { get; set; }
        public static bool DebugAddDronePriorityTarget { get; set; }
        public static bool DebugAddPrimaryWeaponPriorityTarget { get; set; }
        public static bool DebugAgentInfo { get; set; }
        public static bool DebugAgentInteraction { get; set; }
        public static bool DebugAgentInteractionReplyToAgent { get; set; }
        public static bool DebugArm { get; set; }
        public static bool DebugBuyLpItem { get; set; }
        public static bool DebugCheckSessionValid { get; set; }
        public static bool DebugCleanup { get; set; }
        public static bool DebugClearPocket { get; set; }
        public static bool DebugClick { get; set; }
        public static bool DebugCombat { get; set; }
        public static bool DebugCombatController { get; set; }
        public static bool DebugCombatMissionCtrl { get; set; }
        public static bool DebugCombatMissionsBehavior { get; set; }
        public static bool DebugControllerManager { get; set; }
        public static bool DebugCourierContractController { get; set; }
        public static bool DebugCourierMissions { get; set; }
        public static bool DebugCurrentDamageType { get; set; }
        public static bool DebugDecline { get; set; }
        public static bool DebugDefense { get; set; }
        public static bool DebugDirectionalScanner { get; set; }
        public static bool DebugDisableCleanup { get; set; }
        public static bool DebugDisableCombat { get; set; }
        public static bool DebugDisableDefense { get; set; }
        public static bool DebugDisableIgnoreBookmarkedSignatures { get; set; }

        public static bool DebugDisableDrones { get; set; }
        public static bool DebugDisableTargetCombatants { get; set; }

        public static bool DebugDockBookmarks { get; set; }
        public static bool DebugDoneAction { get; set; }
        public static bool DebugDroneController { get; set; }
        public static bool DebugDrones { get; set; }
        public static bool DebugEntityCache { get; set; }
        public static bool DebugFactionWarfareComplexBehavior { get; set; }
        public static bool DebugFittingMgr { get; set; }
        public static bool DebugGetBestDroneTarget { get; set; }
        public static bool DebugGetBestTarget { get; set; }
        public static bool DebugGotobase { get; set; }
        public static bool DebugCorrectAmmoTypeToUseByRange { get; set; }
        public static bool DebugCorrectAmmoTypeInCargo { get; set; }
        public static bool DebugCorrectAmmoTypeToUse { get; set; }
        public static bool DebugHangars { get; set; }
        public static bool DebugIgnoreBookmarkedSignatures { get; set; }
        public static bool DebugIndustryBehavior { get; set; }
        public static bool DebugInSpace { get; set; }
        public static bool DebugInStation { get; set; }
        public static bool DebugInventoryContainers { get; set; }
        public static bool DebugInteractWithEve { get; set; }
        public static bool DebugKillAction { get; set; }
        public static bool DebugKillTargets { get; set; }
        public static bool DebugLoadScripts { get; set; }
        public static bool DebugLoadSettings { get; set; }
        public static bool DebugLoginRewards { get; set; }
        public static bool DebugLogOrderOfDroneTargets { get; set; }
        public static bool DebugLogOrderOfKillTargets { get; set; }
        public static bool DebugLogOrderOfNavigateOnGridTargets { get; set; }
        public static bool DebugLootContainer { get; set; }
        public static bool DebugLootCorpHangar { get; set; }
        public static bool DebugLootWrecks { get; set; }
        public static bool DebugMarketOrders { get; set; }
        public static bool DebugMiningBehavior { get; set; }
        public static bool DebugMobileTractor { get; set; }
        public static bool DebugMoveTo { get; set; }
        public static bool DebugNavigateOnGrid { get; set; }
        public static bool DebugOverLoadWeapons { get; set; }
        public static bool DebugPanic { get; set; }
        public static bool DebugPickTargets { get; set; }
        public static bool DebugPreferredPrimaryWeaponTarget { get; set; }
        public static bool DebugReduceGraphicsController { get; set; }
        public static bool DebugReloadAll { get; set; }
        public static bool DebugReloadorChangeAmmo { get; set; }

        public static bool DebugDisableSalvage { get; set; }
        public static bool DebugSalvage { get; set; }

        public static bool DebugSalvageGridBehavior { get; set; }
        public static bool DebugSignaturesController { get; set; }
        public static bool DebugSkillQueue { get; set; }
        public static bool DebugSlaveBehavior { get; set; }
        public static bool DebugSortBlueprintsBehavior { get; set; }
        public static bool DebugSpeedMod { get; set; }
        public static bool DebugStorylineMissions { get; set; }
        public static bool DebugSubscriptionEnd { get; set; }
        public static bool DebugTargetCombatants { get; set; }
        public static bool DebugTargetCombatantsController { get; set; }
        public static bool DebugTargetPainters { get; set; }
        public static bool DebugTargetWrecks { get; set; }
        public static bool DebugTractorBeams { get; set; }
        public static bool DebugTraveler { get; set; }
        public static bool DebugUndockBookmarks { get; set; }
        public static bool DebugUnloadLoot { get; set; }
        public static bool DebugUnOverLoadModules { get; set; }
        public static bool DebugOverLoadModules { get; set; }
        public static bool DebugWarpCloakyTrick { get; set; }
        public static bool DebugWatchForActiveWars { get; set; }
        public static bool DebugWindows { get; set; }
        public static bool DebugWSpaceScoutBehavior { get; set; }

        #endregion Properties
    }
}