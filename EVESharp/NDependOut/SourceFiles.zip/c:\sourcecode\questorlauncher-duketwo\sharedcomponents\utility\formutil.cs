﻿using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace SharedComponents.Utility
{
    public static class FormUtil
    {
        #region Properties

        public static Color Color { get; set; }
        public static Font Font { get; set; }

        #endregion Properties

        #region Methods

        public static void DrawItem(object sender, DrawListViewItemEventArgs e)
        {
            if (Color == null || Font == null)
                return;

            e.Graphics.SetClip(e.Bounds);
            using (SolidBrush br = new SolidBrush(Color))
            {
                e.Graphics.FillRectangle(br, e.Bounds);
            }

            Color timeColor = ColorTranslator.FromHtml("#666666");
            Color callingMethodColor = ColorTranslator.FromHtml("#0071BC");

            int textLeft = e.Bounds.Left;
            string[] subItems = e.Item.Text.Split(']');
            for (int i = 0; i < subItems.Length; ++i)
            {
                if (i != subItems.Length - 1)
                    subItems[i] += "]";
                int textWidth = TextRenderer.MeasureText(subItems[i], Font).Width;
                TextRenderer.DrawText(e.Graphics, subItems[i], Font,
                    new Rectangle(textLeft, e.Bounds.Top, textWidth, e.Bounds.Height),
                    i == 0 ? timeColor : i == 1 ? callingMethodColor : e.Item.ForeColor,
                    Color.Empty,
                    TextFormatFlags.VerticalCenter | TextFormatFlags.PreserveGraphicsClipping);
                textLeft += textWidth;
            }
            e.Graphics.ResetClip();
        }

        public static void SetDoubleBuffered(Control control)
        {
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        #endregion Methods
    }
}