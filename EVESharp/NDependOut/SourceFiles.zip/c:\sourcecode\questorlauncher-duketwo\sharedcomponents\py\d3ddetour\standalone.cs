﻿using SharedComponents.Py.Frameworks;
using System;

namespace SharedComponents.Py.D3DDetour
{
    public class StandaloneFramework : IFramework
    {
        #region Fields

        private EventHandler<EventArgs> _frameHook;

        #endregion Fields

        #region Properties

        private D3DVersion version { get; }

        #endregion Properties

        #region IDisposable Members

        public void Dispose()
        {
            D3DHook.OnFrame -= _frameHook;
            Pulse.Shutdown();
        }

        #endregion IDisposable Members

        #region Constructors

        public StandaloneFramework(D3DVersion version)
        {
            this.version = version;
        }

        private StandaloneFramework()
        {
        }

        #endregion Constructors

        #region Methods

        public void RegisterFrameHook(EventHandler<EventArgs> frameHook)
        {
            Pulse.Initialize(version);

            _frameHook = frameHook;
            D3DHook.OnFrame += _frameHook;
        }

        public void RegisterLogger(EventHandler<EventArgs> logger)
        {
        }

        #endregion Methods
    }
}