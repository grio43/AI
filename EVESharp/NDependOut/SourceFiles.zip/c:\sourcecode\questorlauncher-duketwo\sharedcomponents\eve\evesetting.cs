﻿/*
/*
 * ---------------------------------------
 * User: duketwo
 * Date: 24.12.2013
 * Time: 16:26
 *
 * ---------------------------------------
 */

using SharedComponents.SharpLogLite.Model;
using SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace SharedComponents.EVE
{
    /// <summary>
    ///     Description of EveAccountData.
    /// </summary>
    [Serializable]
    public class EveSetting : ViewModelBase
    {
        #region Fields

        private static double? _statisticsAllIsk;

        private static double? _statisticsAllItemHangar;

        private static double? _statisticsAllLp;

        private static double? _statisticsAllLpValue;

        private static double? _statisticsNetWorth;

        #endregion Fields

        #region Constructors

        public EveSetting(string eveDirectory, DateTime last24HourTS)
        {
            Last24HourTS = last24HourTS;
            Proxies = new ConcurrentBindingList<Proxy>();
            DatagridViewHiddenColumns = new List<int>();
            EveDirectory = eveDirectory;
        }

        public EveSetting()
        {
            Proxies = new ConcurrentBindingList<Proxy>();
        }

        #endregion Constructors

        #region Properties

        public static double StatisticsAllIsk
        {
            get
            {
                if (_statisticsAllIsk == null)
                {
                    _statisticsAllIsk = 0;
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                        _statisticsAllIsk = _statisticsAllIsk + eA.WalletBalance;

                    return _statisticsAllIsk ?? 0;
                }

                return _statisticsAllIsk ?? 0;
            }
        }

        public static double StatisticsAllItemHangar
        {
            get
            {
                if (_statisticsAllItemHangar != null)
                {
                    _statisticsAllItemHangar = 0;
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                    {
                        if (eA.IskPerLp == 0) eA.IskPerLp = 800;
                        _statisticsAllItemHangar = _statisticsAllItemHangar + eA.ItemHangarValue;
                    }

                    return _statisticsAllItemHangar ?? 0;
                }

                return _statisticsAllItemHangar ?? 0;
            }
        }

        public static double StatisticsAllLp
        {
            get
            {
                if (_statisticsAllLp != null)
                {
                    _statisticsAllLp = 0;
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                        _statisticsAllLp = _statisticsAllLp + eA.LoyaltyPoints;

                    return _statisticsAllLp ?? 0;
                }

                return _statisticsAllLp ?? 0;
            }
        }

        public static double StatisticsAllLpValue
        {
            get
            {
                if (_statisticsAllLpValue != null)
                {
                    _statisticsAllLpValue = 0;
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                        _statisticsAllLpValue = _statisticsAllLpValue + eA.LpValue;

                    return _statisticsAllLpValue ?? 0;
                }

                return _statisticsAllLpValue ?? 0;
            }
        }

        private static int? _eveSharpLauncherThreads;

        public static int? EveSharpLauncherThreads
        {
            get
            {
                if (_eveSharpLauncherThreads == null)
                {
                    _eveSharpLauncherThreads = Process.GetCurrentProcess().Threads.Count;
                    return _eveSharpLauncherThreads;
                }

                return _eveSharpLauncherThreads;
            }
        }

        public static double StatisticsNetWorth
        {
            get
            {
                if (_statisticsNetWorth != null)
                {
                    _statisticsNetWorth = 0;
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                        _statisticsNetWorth = _statisticsNetWorth + eA.LpValue + eA.WalletBalance + eA.ItemHangarValue;

                    return _statisticsNetWorth ?? 0;
                }

                return _statisticsNetWorth ?? 0;
            }
        }

        public int BackgroundFPS
        {
            get { return GetValue(() => BackgroundFPS); }
            set { SetValue(() => BackgroundFPS, value); }
        }

        public int BackgroundFPSMax => 20;

        public int BackgroundFPSMin => 12;

        public List<int> DatagridViewHiddenColumns
        {
            get { return GetValue(() => DatagridViewHiddenColumns); }
            set { SetValue(() => DatagridViewHiddenColumns, value); }
        }

        public string EveDirectory
        {
            get { return GetValue(() => EveDirectory); }
            set { SetValue(() => EveDirectory, value); }
        }

        public string FireFoxDirectory
        {
            get { return GetValue(() => FireFoxDirectory); }
            set { SetValue(() => FireFoxDirectory, value); }
        }

        public string GmailPassword
        {
            get { return GetValue(() => GmailPassword); }
            set { SetValue(() => GmailPassword, value); }
        }

        public string GmailUser
        {
            get { return GetValue(() => GmailUser); }
            set { SetValue(() => GmailUser, value); }
        }

        public bool? KillUnresponsiveEvEs
        {
            get { return GetValue(() => KillUnresponsiveEvEs); }
            set { SetValue(() => KillUnresponsiveEvEs, value); }
        }

        public DateTime Last24HourTS
        {
            get { return GetValue(() => Last24HourTS); }
            set { SetValue(() => Last24HourTS, value); }
        }

        public DateTime LastEmptyStandbyList
        {
            get { return GetValue(() => LastEmptyStandbyList); }
            set { SetValue(() => LastEmptyStandbyList, value); }
        }
        public DateTime LastBackupXMLTS
        {
            get { return GetValue(() => LastBackupXMLTS); }
            set { SetValue(() => LastBackupXMLTS, value); }
        }

        public DateTime LastHourTS
        {
            get { return GetValue(() => LastHourTS); }
            set { SetValue(() => LastHourTS, value); }
        }

        public string Pastebin
        {
            get { return GetValue(() => Pastebin); }
            set { SetValue(() => Pastebin, value); }
        }

        public ConcurrentBindingList<Proxy> Proxies
        {
            get { return GetValue(() => Proxies); }
            set { SetValue(() => Proxies, value); }
        }

        public string ReceiverEmailAddress
        {
            get { return GetValue(() => ReceiverEmailAddress); }
            set { SetValue(() => ReceiverEmailAddress, value); }
        }

        public bool SharpLogLite
        {
            get { return GetValue(() => SharpLogLite); }
            set { SetValue(() => SharpLogLite, value); }
        }

        public LogSeverity SharpLogLiteLogSeverity
        {
            get { return GetValue(() => SharpLogLiteLogSeverity); }
            set { SetValue(() => SharpLogLiteLogSeverity, value); }
        }

        public int TimeBetweenEVELaunchesMax
        {
            get { return GetValue(() => TimeBetweenEVELaunchesMax); }
            set { SetValue(() => TimeBetweenEVELaunchesMax, value); }
        }

        public int TimeBetweenEVELaunchesMin
        {
            get { return GetValue(() => TimeBetweenEVELaunchesMin); }
            set { SetValue(() => TimeBetweenEVELaunchesMin, value); }
        }

        public bool ToggleHideShowOnMinimize => false;

        public string UrlToPullEveSharpCode
        {
            get { return GetValue(() => UrlToPullEveSharpCode); }
            set { SetValue(() => UrlToPullEveSharpCode, value); }
        }

        public string WCFPipeName
        {
            get { return GetValue(() => WCFPipeName); }
            set { SetValue(() => WCFPipeName, value); }
        }

        #endregion Properties

        #region Methods

        public static void ClearEveSettingsStatistics()
        {
            _statisticsAllIsk = null;
            _statisticsAllItemHangar = null;
            _statisticsAllLp = null;
            _statisticsNetWorth = null;
        }

        public static void ClearEveSettingsStatisticsEveryFewSec()
        {
            _eveSharpLauncherThreads = null;
        }

        public static string FormatIsk(double iskToFormat)
        {
            string FormattedIsk = string.Empty;
            if (iskToFormat < 1000)
                FormattedIsk = iskToFormat.ToString("#,#");
            else if (iskToFormat < 1000000)
                FormattedIsk = iskToFormat.ToString("#,##0,K");
            else if (iskToFormat < 1000000000)
                FormattedIsk = iskToFormat.ToString("#,,.##M");
            else if (iskToFormat < 1000000000000)
                FormattedIsk = iskToFormat.ToString("#,,,.##B");
            else
                FormattedIsk = iskToFormat.ToString("#,,,,.##T");

            return FormattedIsk;
        }

        #endregion Methods
    }
}