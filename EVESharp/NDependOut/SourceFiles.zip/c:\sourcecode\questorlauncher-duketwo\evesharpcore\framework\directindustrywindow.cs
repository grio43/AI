﻿extern alias SC;

using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    public class DirectIndustryWindow : DirectWindow
    {
        #region Constructors

        internal DirectIndustryWindow(DirectEve directEve, PyObject pyWindow)
            : base(directEve, pyWindow)
        {
        }

        #endregion Constructors

        #region Properties

        /**
        //public bool AnyError => Controller.Attribute("errors").ToList().Any();
        public bool IsActivating => ActivationController.Attribute("isActivating").ToBool();

        public bool IsFinished => ActivationController.Attribute("isFinished").ToBool();
        public bool IsJumping => ActivationController.Attribute("isJumping").ToBool();
        public bool IsReady => ActivationController.Attribute("isReady").ToBool();
        public float Tier => Controller.Attribute("tier").ToFloat();
        public string TierDescription => Controller.Attribute("tierDescription").ToUnicodeString();
        public string TimerDescription => Controller.Attribute("timerDescription").ToUnicodeString();
        public int TypeId => Controller.Attribute("typeID").ToInt();
        public float Weather => Controller.Attribute("weather").ToInt();
        public string WeatherDescription => Controller.Attribute("weatherDescription").ToUnicodeString();
        public string WeatherName => Controller.Attribute("weatherName").ToUnicodeString();
        private PyObject ActivationController => Controller.Attribute("activationController");
        private PyObject Controller => PyWindow.Attribute("controller");
        **/

        #endregion Properties

        #region Methods

        /**
        public override string ToString()
        {
            return $"{nameof(Controller)}: {Controller}, {nameof(TypeId)}: {TypeId}, {nameof(Weather)}: {Weather}, {nameof(WeatherDescription)}: {WeatherDescription}, {nameof(WeatherName)}: {WeatherName}, {nameof(Tier)}: {Tier}, {nameof(TierDescription)}: {TierDescription}, {nameof(TimerDescription)}: {TimerDescription}, {nameof(IsReady)}: {IsReady}, {nameof(IsJumping)}: {IsJumping}, {nameof(IsFinished)}: {IsFinished}, {nameof(IsActivating)}: {IsActivating}";
        }
        **/
        #endregion Methods
    }
}