﻿using SharedComponents.SharpLogLite.Model;
using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Threading;

/*
 * User: duketwo - https://github.com/duketwo/
 * Date: 10.11.2016
 */

namespace SharedComponents.SharpLogLite
{
    public class SharpLogLite : IDisposable
    {
        #region Constructors

        public SharpLogLite(LogSeverity severity)
        {
            LogSeverity = severity;
        }

        #endregion Constructors

        #region Fields

        private static readonly ManualResetEvent ManualResetEvent = new ManualResetEvent(false);
        private readonly LogSeverity LogSeverity;
        private bool IsClosed;
        private Socket Listener;

        #endregion Fields

        #region Methods

        public void Dispose()
        {
            try
            {
                Listener.Close();
                IsClosed = true;
                ManualResetEvent.Set();
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
        }

        public void StartListening()
        {
            IPEndPoint localEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 3273);
            Debug.WriteLine("Local address and port : {0}", localEP.ToString());

            Listener = new Socket(localEP.Address.AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

            try
            {
                Listener.Bind(localEP);
                Listener.Listen(20);

                while (true && !IsClosed)
                    try
                    {
                        ManualResetEvent.Reset();
                        Debug.WriteLine("Waiting for a connection...");
                        Listener.BeginAccept(
                            new LogModelHandler(ManualResetEvent, LogSeverity).AcceptCallback,
                            Listener);
                        ManualResetEvent.WaitOne();
                    }
                    catch (Exception e)
                    {
                        Debug.WriteLine("Exception: {0}", e);
                        break;
                    }
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.ToString());
            }
            finally
            {
                if (Listener != null)
                    Listener.Close();
            }

            Debug.WriteLine("Closing the listener...");
        }

        #endregion Methods
    }
}