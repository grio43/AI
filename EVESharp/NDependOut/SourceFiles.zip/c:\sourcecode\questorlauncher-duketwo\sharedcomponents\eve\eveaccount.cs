﻿/*
/*
 * ---------------------------------------
 * User: duketwo
 * Date: 24.12.2013
 * Time: 16:26
 *
 * ---------------------------------------
 */

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Authentication;
using System.Windows.Forms;
using System.Xml.Serialization;
using EasyHook;
using HtmlAgilityPack;
using ImapX.Collections;
using SharedComponents.CurlUtil;
using SharedComponents.Events;
using SharedComponents.IMAP;
using SharedComponents.IPC;
using SharedComponents.Utility;

namespace SharedComponents.EVE
{
    /// <summary>
    ///     Description of EveAccountData.
    /// </summary>
    [Serializable]
    public class EveAccount : ViewModelBase //INotifyPropertyChanged, IDisposable, ILaunchTarget
    {
        public void TestImapEmail()
        {
            bool boolTesting = true;
            if (FindEmailedVerificationCodeViaImap(boolTesting) == null)
            {
                Cache.Instance.Log("TestImapEmail: if (FindEmailedVerificationCodeViaImap() == null)");
                return;
            }

            if ((bool)!FindEmailedVerificationCodeViaImap(boolTesting))
            {
                Cache.Instance.Log("TestImapEmail: if (!FindEmailedVerificationCodeViaImap())");
                return;
            }

            Cache.Instance.Log("TestImapEmail: if (FindEmailedVerificationCodeViaImap())");
            return;
        }

        public bool? FindEmailedVerificationCodeViaImap(bool boolTesting)
        {
            if (HWSettings.Proxy == null || !HWSettings.Proxy.IsValid)
            {
                Cache.Instance.Log("Proxy is null or Invalid. Is there a valid proxy selected in the Hardware Profile?");
                return null;
            }

            if (!HWSettings.Proxy.InternetConnectivityTest())
                return null;

            if (string.IsNullOrEmpty(Email))
            {
                Cache.Instance.Log("We need to login to [" + MaskedCharacterName + "]'s email via IMAP to pull the code CCP sent but the Email Address is missing from [" + MaskedCharacterName + "]'s EveSharp Launcher settings");
                return null;
            }

            if (string.IsNullOrEmpty(EmailPassword))
            {
                Cache.Instance.Log("We need to login to [" + MaskedCharacterName + "]'s email via IMAP to pull the code CCP sent but the Email password is missing from [" + MaskedCharacterName + "]'s EveSharp Launcher settings");
                return null;
            }

            if (string.IsNullOrEmpty(IMAPHost))
            {
                if (Email.ToLower().Contains("gmail.com"))
                    IMAPHost = "imap.gmail.com";

                if (Email.ToLower().Contains("outlook.com"))
                    IMAPHost = "imap-mail.outlook.com";

                //
                // if IMAPHost still blank then fail with error message, otherwise continue
                //
                if (string.IsNullOrEmpty(IMAPHost))
                {
                    Cache.Instance.Log("We need to login to [" + MaskedCharacterName + "]'s email via IMAP to pull the code CCP sent but the IMAPHost (server name) is missing from [" + MaskedCharacterName + "]'s EveSharp Launcher settings");
                    return null;
                }
            }

            int retryEmailSearch = 0;
            bool emailFound = false;
            while (!emailFound && 10 > retryEmailSearch)
            {
                try
                {
                    MessageCollection emails = null;
                    try
                    {
                        Cache.Instance.Log("Imap.GetInboxEmails: IMAPHost [" + IMAPHost + "] Port [ 993 ] SSLProtocols [" + SslProtocols.Tls12 + "] VerifySSLCerts " + true + "[] EmailAddress [" + Email + "] EmailPassword [" + EmailPassword + "]");
                        emails = Imap.GetInboxEmails(
                            IMAPHost, //IMAP Server Address
                            993, //IMAP Server Port
                            SslProtocols.Tls12, //IMAP Server SSL Protcols
                            true, //Verify SSL Certs?
                            Email, // Email Address (IMAP Username)
                            EmailPassword, // Email Password (IMAP Password)
                            string.Empty, //HWSettings.Proxy.Ip, // SOCKS5 Server Proxy Address
                            0, //Convert.ToInt32(HWSettings.Proxy.Socks5Port), // SOCKS5 Server Port
                            string.Empty, //HWSettings.Proxy.Username, //SOCKS5 Server Username (if any)
                            string.Empty); //HWSettings.Proxy.Password, //SOCKS5 Server Password (if any)
                    }
                    catch (AuthenticationException ex)
                    {
                        Cache.Instance.Log("IMAP AuthenticationException: The username [" + Email + "] and password [" + EmailPassword + "] did not allow us to authenticate to [" + IMAPHost + "] on port [" + 993 + "] via IMAP. Exception [" + ex + "]");
                        if (Email.ToLower().Contains("gmail.com".ToLower()))
                        {
                            Cache.Instance.Log("IMAP AuthenticationException: 1) Is Less Secure Apps On? see: https://support.google.com/accounts/answer/6010255?hl=en ");
                            Cache.Instance.Log("IMAP AuthenticationException: 2) Has IMAP access been enabled? see: https://support.google.com/mail/answer/7126229?hl=en ");
                            return null;
                        }

                        if (Email.ToLower().Contains("outlook.com".ToLower()))
                        {
                            Cache.Instance.Log("IMAP AuthenticationException: 1) For Outlook IMAP troubleshooting see: https://support.office.com/en-us/article/pop-imap-and-smtp-settings-for-outlook-com-d088b986-291d-42b8-9564-9c414e2aa040 ");
                            //Cache.Instance.Log("IMAP AuthenticationException: 2) Has IMAP access been enabled? see: https://support.google.com/mail/answer/7126229?hl=en ");
                            return null;
                        }

                        return null;
                    }
                    catch (Exception ex)
                    {
                        Cache.Instance.Log(string.Format("Exception [" + ex + "]"));
                        return null;
                    }
                    Cache.Instance.Log("Looking for email from CCP...");

                    foreach (ImapX.Message email in emails.Where(tempEmail => tempEmail.Subject.ToLower().Contains("Verification code".ToLower()) && (boolTesting || tempEmail.Date > DateTime.Now.AddHours(-1))))
                    {
                        Cache.Instance.Log("Found an email from CCP: Subject [" + email.Subject + "] Date [" + email.Date + "]");
                        Cache.Instance.Log("Debug: Email body as text:" + email.Body.Text);
                        Cache.Instance.Log("Debug: Email body as HTML:" + email.Body.Html);
                        try
                        {
                            HtmlAgilityPack.HtmlDocument htmlDoc = new HtmlAgilityPack.HtmlDocument();
                            htmlDoc.LoadHtml(email.Body.Html);
                            HtmlNodeCollection nodes = htmlDoc.DocumentNode.SelectNodes("//b");

                            if (nodes.Count > 0 && nodes.Count == 2)
                            {
                                Cache.Instance.Log("Found a node with the link. Nodes: " + nodes.Count);
                                HtmlNode node = nodes.FirstOrDefault();

                                if (node != null)
                                {
                                    VerificationCode = node.InnerText;
                                    Cache.Instance.Log(string.Format("Verification code found [" + VerificationCode + "] from email delivered at [" + email.Date + "]"));
                                    //HWSettings.Proxy.StartFireFoxInject(verificationUrl);
                                    emailFound = true;
                                    return true;
                                }

                                Cache.Instance.Log("Node is null.");
                                emailFound = false;
                                continue;
                            }

                            if (nodes.Any()) Cache.Instance.Log("[" + nodes.Count + "] nodes (expected 2) containing <b></b> html tags found in the email titled [" + email.Subject + "] Dated [" + email.Date + "] From [" + email.From + "]");
                            else Cache.Instance.Log("No nodes containing <b></b> html tag were found in the email titled [" + email.Subject + "] Dated [" + email.Date + "] From [" + email.From + "].");
                            emailFound = false;
                            continue;
                        }
                        catch (Exception ex)
                        {
                            Cache.Instance.Log("Exception: " + ex);
                            return null;
                        }
                    }

                    Cache.Instance.Log("There is not an email from CCP yet: waiting");
                    retryEmailSearch++;
                    Wait(2000);
                }
                catch (Exception exception)
                {
                    Cache.Instance.Log("Exception:" + exception);
                    return null;
                }
            }

            Cache.Instance.Log("Unable to find email from CCP. Aborting");
            return false;
        }

        private void Wait(int milliseconds)
        {
            Timer timer1 = new Timer();
            if (milliseconds == 0 || milliseconds < 0) return;
            //Console.WriteLine("start wait timer");
            timer1.Interval = milliseconds;
            timer1.Enabled = true;
            timer1.Start();
            timer1.Tick += (s, e) =>
            {
                timer1.Enabled = false;
                timer1.Stop();
                //Console.WriteLine("stop wait timer");
            };
            while (timer1.Enabled)
            {
                Application.DoEvents();
            }
        }

        public readonly int MAX_MEMORY = 1800;
        public readonly int MAX_STARTS = 12;

        #region Fields

        [Browsable(false)]
        [ReadOnly(true)]
        public double MAX_SERIALIZATION_ERRORS
        {
            get
            {
                try
                {
                    var tempMAX_SERIALIZATION_ERRORS = GetValue(() => MAX_SERIALIZATION_ERRORS);
                    if (tempMAX_SERIALIZATION_ERRORS <= 0)
                    {
                        return 3 * 4 + 1.5d;
                    }

                    return tempMAX_SERIALIZATION_ERRORS;
                }
                catch (Exception)
                {
                    return 0;
                }
            }
            set { SetValue(() => MAX_SERIALIZATION_ERRORS, value); }
        }

        public static List<string> AvailableControllers = new List<string> { "QuestorController", "CourierMissionsController", "CareerAgentController", "HighSecAnomalyController", "MiningController", "PinataController", "HydraController", "AbyssalDeadspaceController", "SortBlueprintsController" , "FleetAbyssalDeadspaceController", "MarketAdjustExistingOrdersController", "MonitorGridController", "WormHoleAnomalyController", "SalvageGridController", "CombatDontMoveController", "None" };
        [NonSerialized] public static ConcurrentDictionary<int, string> CharnameByPid = new ConcurrentDictionary<int, string>();
        [NonSerialized] public bool DoNotSessionChange = false;
        [NonSerialized] public bool ManuallyStarted = false;
        [NonSerialized] private static readonly Random rnd = new Random();
        [NonSerialized] private static DateTime lastEveInstanceKilled = DateTime.MinValue;
        [NonSerialized] private static int waitTimeBetweenEveInstancesKills = rnd.Next(15, 25);

        [NonSerialized] private DateTime? _lastResponding;
        [NonSerialized] private DateTime _nextAtWarLogMessage = DateTime.MinValue;
        [NonSerialized] private DateTime _nextOmegaCloneLogMessage = DateTime.MinValue;
        [NonSerialized] private IDuplexServiceCallback ClientCallback;

        #endregion Fields

        #region Constructors

        //private IsbelEveAccount thisIsbelEveAccount;

        public EveAccount(string accountName, string characterName, string password, DateTime startTime, DateTime endTime, bool isActive)
        {
            AccountName = accountName;
            CharacterName = characterName;
            Password = password;
            StartTime = startTime;
            EndTime = endTime;
            StartsPast24H = 0;
            LastStartTime = DateTime.MinValue;
            UseScheduler = isActive;
            Pid = 0;
        }

        public EveAccount()
        {
            if (string.IsNullOrEmpty(GUID))
            {
                GUID = Guid.NewGuid().ToString();
            }

            if (5 > NumOfAbyssalSitesBeforeRestarting)
                NumOfAbyssalSitesBeforeRestarting = 20;
            //thisIsbelEveAccount = new IsbelEveAccount();
            //thisIsbelEveAccount.SetEveAccount(this);
        }

        #endregion Constructors

        #region Properties

        public static string DefaultController => AvailableControllers[0];

        public int NumOfAbyssalSitesBeforeRestarting
        {
            get { return GetValue(() => NumOfAbyssalSitesBeforeRestarting); }
            set { SetValue(() => NumOfAbyssalSitesBeforeRestarting, value); }
        }

        [ReadOnly(true)]
        public int AbyssalPocketNumber
        {
            get { return GetValue(() => AbyssalPocketNumber); }
            set { SetValue(() => AbyssalPocketNumber, value); }
        }

        [XmlIgnore]
        [Browsable(false)]
        public bool ManuallyPausedViaUI
        {
            get { return GetValue(() => ManuallyPausedViaUI); }
            set { SetValue(() => ManuallyPausedViaUI, value); }
        }

        [Browsable(false)]
        public bool IgnoreSeralizationErrors
        {
            get { return GetValue(() => IgnoreSeralizationErrors); }
            set { SetValue(() => IgnoreSeralizationErrors, value); }
        }

        [Browsable(false)]
        public bool AllowInjectionIntoManuallyLaunchedEve
        {
            get { return GetValue(() => AllowInjectionIntoManuallyLaunchedEve); }
            set { SetValue(() => AllowInjectionIntoManuallyLaunchedEve, value); }
        }

        [Browsable(false)]
        public bool HardwareSpoofing
        {
            get { return GetValue(() => HardwareSpoofing); }
            set { SetValue(() => HardwareSpoofing, value); }
        }

        public string AccountName
        {
            get { return GetValue(() => AccountName); }
            set
            {
                if (Cache.IsServer && EveProcessExists())
                {
                    Cache.Instance.Log("Can't change the account name until the client has been stopped.");
                    return;
                }
                DeleteCurlCookie();
                SetValue(() => AccountName, value);
                UniqueID = string.Empty;
                ClearTokens();
            }
        }

        [ReadOnly(true)]
        public string Agent
        {
            get { return GetValue(() => Agent); }
            set { SetValue(() => Agent, value); }
        }

        [ReadOnly(true)]
        public string AgentCorp
        {
            get { return GetValue(() => AgentCorp); }
            set { SetValue(() => AgentCorp, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string AgentCorpId
        {
            get { return GetValue(() => AgentCorpId); }
            set { SetValue(() => AgentCorpId, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public float AgentCorpStandings
        {
            get { return GetValue(() => AgentCorpStandings); }
            set { SetValue(() => AgentCorpStandings, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string AgentDivision
        {
            get { return GetValue(() => AgentDivision); }
            set { SetValue(() => AgentDivision, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string AgentFaction
        {
            get { return GetValue(() => AgentFaction); }
            set { SetValue(() => AgentFaction, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string AgentFactionId
        {
            get { return GetValue(() => AgentFactionId); }
            set { SetValue(() => AgentFactionId, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public float AgentFactionStandings
        {
            get { return GetValue(() => AgentFactionStandings); }
            set { SetValue(() => AgentFactionStandings, value); }
        }

        [ReadOnly(true)]
        public string AgentLevel
        {
            get { return GetValue(() => AgentLevel); }
            set { SetValue(() => AgentLevel, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public float AgentStandings
        {
            get { return GetValue(() => AgentStandings); }
            set { SetValue(() => AgentStandings, value); }
        }

        [Browsable(false)]
        public DateTime AggressingTargetDate
        {
            get { return GetValue(() => AggressingTargetDate); }
            set { SetValue(() => AggressingTargetDate, value); }
        }

        [Browsable(false)]
        public long AggressingTargetId
        {
            get { return GetValue(() => AggressingTargetId); }
            set { SetValue(() => AggressingTargetId, value); }
        }

        [Browsable(false)]
        public int AmountErrorExceptionsCurrentSession
        {
            get { return GetValue(() => AmountErrorExceptionsCurrentSession); }
            set { SetValue(() => AmountErrorExceptionsCurrentSession, value); }
        }

        [Browsable(false)]
        public int AmountExceptionsCurrentSession
        {
            get { return GetValue(() => AmountExceptionsCurrentSession); }
            set { SetValue(() => AmountExceptionsCurrentSession, value); }
        }

        [Browsable(false)]
        public bool boolNewSignatureDetected
        {
            get { return GetValue(() => boolNewSignatureDetected); }
            set { SetValue(() => boolNewSignatureDetected, value); }
        }

        [ReadOnly(true)]
        public bool BotUsesHydra
        {
            get { return GetValue(() => BotUsesHydra); }
            set { SetValue(() => BotUsesHydra, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool ByPassLoginScreen
        {
            get { return GetValue(() => ByPassLoginScreen); }
            set { SetValue(() => ByPassLoginScreen, value); }
        }

        [Browsable(false)]
        public bool CareerAgentAmarr1MissionsComplete
        {
            get { return GetValue(() => CareerAgentAmarr1MissionsComplete); }
            set { SetValue(() => CareerAgentAmarr1MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentAmarr2MissionsComplete
        {
            get { return GetValue(() => CareerAgentAmarr2MissionsComplete); }
            set { SetValue(() => CareerAgentAmarr2MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentAmarr3MissionsComplete
        {
            get { return GetValue(() => CareerAgentAmarr3MissionsComplete); }
            set { SetValue(() => CareerAgentAmarr3MissionsComplete, value); }
        }


        [Browsable(false)]
        [ReadOnly(true)]
        public bool CareerAgentCaldari1MissionsComplete
        {
            get { return GetValue(() => CareerAgentCaldari1MissionsComplete); }
            set { SetValue(() => CareerAgentCaldari1MissionsComplete, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool CareerAgentCaldari2MissionsComplete
        {
            get { return GetValue(() => CareerAgentCaldari2MissionsComplete); }
            set { SetValue(() => CareerAgentCaldari2MissionsComplete, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool CareerAgentCaldari3MissionsComplete
        {
            get { return GetValue(() => CareerAgentCaldari3MissionsComplete); }
            set { SetValue(() => CareerAgentCaldari3MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentGallente1MissionsComplete
        {
            get { return GetValue(() => CareerAgentGallente1MissionsComplete); }
            set { SetValue(() => CareerAgentGallente1MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentGallente2MissionsComplete
        {
            get { return GetValue(() => CareerAgentGallente2MissionsComplete); }
            set { SetValue(() => CareerAgentGallente2MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentGallente3MissionsComplete
        {
            get { return GetValue(() => CareerAgentGallente3MissionsComplete); }
            set { SetValue(() => CareerAgentGallente3MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentMinmatar1MissionsComplete
        {
            get { return GetValue(() => CareerAgentMinmatar1MissionsComplete); }
            set { SetValue(() => CareerAgentMinmatar1MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentMinmatar2MissionsComplete
        {
            get { return GetValue(() => CareerAgentMinmatar2MissionsComplete); }
            set { SetValue(() => CareerAgentMinmatar2MissionsComplete, value); }
        }

        [Browsable(false)]
        public bool CareerAgentMinmatar3MissionsComplete
        {
            get { return GetValue(() => CareerAgentMinmatar3MissionsComplete); }
            set { SetValue(() => CareerAgentMinmatar3MissionsComplete, value); }
        }

        public string CharacterName
        {
            get { return GetValue(() => CharacterName); }
            set
            {
                if (Cache.IsServer && EveProcessExists())
                {
                    Cache.Instance.Log("Can't change the character name until the client has been stopped.");
                    return;
                }
                SetValue(() => CharacterName, value);
                UniqueID = string.Empty;
                ClearTokens();
            }
        }

        [XmlIgnore]
        [Browsable(false)]
        public string MaskedCharacterName => CharacterName.Substring(0, 3) + "*********";

        [Browsable(false)]
        public List<string> CharsOnAccount
        {
            get { return GetValue(() => CharsOnAccount); }
            set { SetValue(() => CharsOnAccount, value); }
        }

        [XmlIgnore]
        [Browsable(false)]
        public double ClientSettingsSerializationErrors => StartingTokenTimespan.TotalHours;

        //[Browsable(false)]
        //public ClientSetting ClientSetting
        //{
        //    get { return GetValue(() => ClientSetting); }
        //    set { SetValue(() => ClientSetting, value); }
        //}

        [ReadOnly(true)]
        public string CMBCtrlAction
        {
            get { return GetValue(() => CMBCtrlAction); }
            set { SetValue(() => CMBCtrlAction, value); }
        }

        public bool ConnectToTestServer
        {
            get { return GetValue(() => ConnectToTestServer); }
            set { SetValue(() => ConnectToTestServer, value); }
        }

        [Browsable(true)]
        public bool Console
        {
            get { return GetValue(() => Console); }
            set
            {
                SetValue(() => Console, value);
                if (value) ShowConsoleWindow();
                else HideConsoleWindow();
            }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public int CourierItemTypeId
        {
            get { return GetValue(() => CourierItemTypeId); }
            set { SetValue(() => CourierItemTypeId, value); }
        }

        //[Browsable(false)]
        //public ClientSetting CS => ClientSetting;

        [Browsable(false)]
        [ReadOnly(true)]
        public string CurrentFit
        {
            get { return GetValue(() => CurrentFit); }
            set { SetValue(() => CurrentFit, value); }
        }

        [Browsable(false)]
        public bool DisableHiding
        {
            get { return GetValue(() => DisableHiding); }
            set { SetValue(() => DisableHiding, value); }
        }

        public string AssistMyDronesTo
        {
            get { return GetValue(() => AssistMyDronesTo); }
            set { SetValue(() => AssistMyDronesTo, value); }
        }

        [Browsable(false)]
        public int DumpLootIterations
        {
            get { return GetValue(() => DumpLootIterations); }
            set { SetValue(() => DumpLootIterations, value); }
        }

        [Browsable(false)]
        public DateTime DumpLootTimestamp
        {
            get { return GetValue(() => DumpLootTimestamp); }
            set { SetValue(() => DumpLootTimestamp, value); }
        }

        [Browsable(false)]
        public bool DX11
        {
            get { return GetValue(() => DX11); }
            set { SetValue(() => DX11, value); }
        }

        [Browsable(false)]
        public string VerificationCode = string.Empty;

        [Browsable(false)]
        [ReadOnly(true)]
        public string Email
        {
            get { return GetValue(() => Email); }
            set { SetValue(() => Email, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string EmailPassword
        {
            get { return GetValue(() => EmailPassword); }
            set { SetValue(() => EmailPassword, value); }
        }

        public bool AutoSkillTraining
        {
            get { return GetValue(() => AutoSkillTraining); }
            set { SetValue(() => AutoSkillTraining, value); }
        }

        public DateTime EndTime
        {
            get { return GetValue(() => EndTime); }
            set { SetValue(() => EndTime, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime EndTimeII
        {
            get { return GetValue(() => EndTimeII); }
            set { SetValue(() => EndTimeII, value); }
        }

        [Browsable(false)]
        public string EveAccessToken
        {
            get { return GetValue(() => EveAccessToken); }
            set { SetValue(() => EveAccessToken, value); }
        }

        [Browsable(false)]
        public DateTime EveAccessTokenValidUntil
        {
            get { return GetValue(() => EveAccessTokenValidUntil); }
            set { SetValue(() => EveAccessTokenValidUntil, value); }
        }

        [Browsable(false)]
        public long EveHWnd
        {
            get { return GetValue(() => EveHWnd); }
            set { SetValue(() => EveHWnd, value); }
        }

        [Browsable(false)]
        public long EVESharpCoreFormHWnd
        {
            get { return GetValue(() => EVESharpCoreFormHWnd); }
            set { SetValue(() => EVESharpCoreFormHWnd, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string EveSsoServerName
        {
            get
            {
                if (ConnectToTestServer)
                    return "sisilogin.testeveonline.com";

                return "login.eveonline.com";
            }
        }

        [Browsable(false)]
        public string EveSSOToken
        {
            get { return GetValue(() => EveSSOToken); }
            set { SetValue(() => EveSSOToken, value); }
        }

        [Browsable(false)]
        public DateTime EveSSOTokenValidUntil
        {
            get { return GetValue(() => EveSSOTokenValidUntil); }
            set { SetValue(() => EveSSOTokenValidUntil, value); }
        }

        public string FleetName
        {
            get { return GetValue(() => FleetName); }
            set { SetValue(() => FleetName, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool OtherToonsAreStillLoggingIn
        {
            get { return GetValue(() => OtherToonsAreStillLoggingIn); }
            set { SetValue(() => OtherToonsAreStillLoggingIn, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool DoneLaunchingEveInstance
        {
            get { return GetValue(() => DoneLaunchingEveInstance); }
            set { SetValue(() => DoneLaunchingEveInstance, value); }
        }

        [Browsable(false)]
        public bool Hidden
        {
            get { return GetValue(() => Hidden); }
            set
            {
                SetValue(() => Hidden, value);
                if (value) HideWindows();
                else ShowWindows();
            }
        }

        [Browsable(false)]
        public long HookmanagerHWnd
        {
            get { return GetValue(() => HookmanagerHWnd); }
            set { SetValue(() => HookmanagerHWnd, value); }
        }

        public int HoursPerDay
        {
            get { return GetValue(() => HoursPerDay); }
            set
            {
                SetValue(() => HoursPerDay, value);
                GenerateNewTimeSpans();
            }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public int HoursPerDayII
        {
            get { return GetValue(() => HoursPerDayII); }
            set
            {
                SetValue(() => HoursPerDayII, value);
                GenerateNewTimeSpans();
            }
        }

        [Browsable(false)]
        public HWSettings HWSettings
        {
            get { return GetValue(() => HWSettings); }
            set { SetValue(() => HWSettings, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string IMAPHost
        {
            get { return GetValue(() => IMAPHost); }
            set { SetValue(() => IMAPHost, value); }
        }

        [Browsable(true)]
        [ReadOnly(true)]
        public bool InAbyssalDeadspace
        {
            get { return GetValue(() => InAbyssalDeadspace); }
            set { SetValue(() => InAbyssalDeadspace, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string GUID
        {
            get { return GetValue(() => GUID); }
            set { SetValue(() => GUID, value); }
        }

        private bool myEveAccountIsAlreadyLoggedIn
        {
            get
            {
                foreach (EveAccount thisEveAccount in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                {
                    if (thisEveAccount.GUID != GUID && thisEveAccount.AccountName == AccountName && thisEveAccount.Running)
                        return true;

                    continue;
                }

                return false;
            }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        [XmlIgnore]
        public bool IsValidForManualLogin
        {
            get
            {
                if (string.IsNullOrEmpty(AccountName))
                    return false;

                if (string.IsNullOrEmpty(Password))
                    return false;

                return true;
            }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        [XmlIgnore]
        public bool IsValidForAutoLogin
        {
            get
            {
                if (string.IsNullOrEmpty(CharacterName))
                    return false;

                if (string.IsNullOrEmpty(AccountName))
                    return false;

                if (string.IsNullOrEmpty(Password))
                    return false;

                return true;
            }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool AllowSimultaneousLogins
        {
            get { return GetValue(() => AllowSimultaneousLogins); }
            set { SetValue(() => AllowSimultaneousLogins, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string Info
        {
            get { return GetValue(() => Info); }
            set { SetValue(() => Info, value); }
        }

        [ReadOnly(true)]
        public bool InMission
        {
            get { return GetValue(() => InMission); }
            set { SetValue(() => InMission, value); }
        }

        public bool UseScheduler
        {
            get { return GetValue(() => UseScheduler); }
            set { SetValue(() => UseScheduler, value); }
        }

        [ReadOnly(true)]
        public bool IsAtWar
        {
            get { return GetValue(() => IsAtWar); }
            set { SetValue(() => IsAtWar, value); }
        }

        [ReadOnly(true)]
        public bool IsDocked
        {
            get { return GetValue(() => IsDocked); }
            set { SetValue(() => IsDocked, value); }
        }

        public bool AllLoggedInAccountsAreNotInLocalWhereIWillLogin
        {
            get
            {
                if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.Any(i => i.Running && !i.InAbyssalDeadspace && i.SolarSystem == SolarSystem))
                {
                    return false;
                }

                return true;
            }
        }

        public double IskPerLp
        {
            get { return GetValue(() => IskPerLp); }
            set { SetValue(() => IskPerLp, value); }
        }

        public bool IsLeader
        {
            get { return GetValue(() => IsLeader); }
            set { SetValue(() => IsLeader, value); }
        }

        public bool RequireOmegaClone
        {
            get { return GetValue(() => RequireOmegaClone); }
            set { SetValue(() => RequireOmegaClone, value); }
        }

        public bool IsOmegaClone
        {
            get { return GetValue(() => IsOmegaClone); }
            set { SetValue(() => IsOmegaClone, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool IsSafeInPOS
        {
            get { return GetValue(() => IsSafeInPOS); }
            set { SetValue(() => IsSafeInPOS, value); }
        }

        public double ItemHangarValue
        {
            get { return GetValue(() => ItemHangarValue); }
            set { SetValue(() => ItemHangarValue, value); }
        }

        public DateTime LastAmmoBuy
        {
            get { return GetValue(() => LastAmmoBuy); }
            set { SetValue(() => LastAmmoBuy, value); }
        }

        public DateTime LastAmmoBuyAttempt
        {
            get { return GetValue(() => LastAmmoBuyAttempt); }
            set { SetValue(() => LastAmmoBuyAttempt, value); }
        }

        public DateTime LastBuyLpItemAttempt
        {
            get { return GetValue(() => LastBuyLpItemAttempt); }
            set { SetValue(() => LastBuyLpItemAttempt, value); }
        }

        public DateTime LastBuyLpItems
        {
            get { return GetValue(() => LastBuyLpItems); }
            set { SetValue(() => LastBuyLpItems, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastConsumeBoosterSlot1
        {
            get { return GetValue(() => LastConsumeBoosterSlot1); }
            set { SetValue(() => LastConsumeBoosterSlot1, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastConsumeBoosterSlot10
        {
            get { return GetValue(() => LastConsumeBoosterSlot10); }
            set { SetValue(() => LastConsumeBoosterSlot10, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastConsumeBoosterSlot2
        {
            get { return GetValue(() => LastConsumeBoosterSlot2); }
            set { SetValue(() => LastConsumeBoosterSlot2, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastConsumeBoosterSlot255
        {
            get { return GetValue(() => LastConsumeBoosterSlot255); }
            set { SetValue(() => LastConsumeBoosterSlot255, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastConsumeBoosterSlot3
        {
            get { return GetValue(() => LastConsumeBoosterSlot3); }
            set { SetValue(() => LastConsumeBoosterSlot3, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastConsumeBoosterSlot4
        {
            get { return GetValue(() => LastConsumeBoosterSlot4); }
            set { SetValue(() => LastConsumeBoosterSlot4, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastConsumeBoosterSlotUnknown
        {
            get { return GetValue(() => LastConsumeBoosterSlotUnknown); }
            set { SetValue(() => LastConsumeBoosterSlotUnknown, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastCreateContract
        {
            get { return GetValue(() => LastCreateContract); }
            set { SetValue(() => LastCreateContract, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastCreateContractAttempt
        {
            get { return GetValue(() => LastCreateContractAttempt); }
            set { SetValue(() => LastCreateContractAttempt, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public long LastEntityIdEngaged
        {
            get { return GetValue(() => LastEntityIdEngaged); }
            set { SetValue(() => LastEntityIdEngaged, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime DateTimeLastEntityIdEngaged
        {
            get { return GetValue(() => DateTimeLastEntityIdEngaged); }
            set { SetValue(() => DateTimeLastEntityIdEngaged, value); }
        }

        [Browsable(false)]
        public List<long> EntityIdsEngagedByOthers
        {
            get
            {
                try
                {
                    List<long> tempListOfEntityIds = new List<long>();
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(i => i.SolarSystem == SolarSystem && !i.IsDocked && i.Running && i.DateTimeLastEntityIdEngaged != null && i.DateTimeLastEntityIdEngaged.AddMinutes(2) > DateTime.UtcNow && i.LastEntityIdEngaged != 0 && i.LastEntityIdEngaged > 0))
                    {
                        tempListOfEntityIds.Add(eA.LastEntityIdEngaged);
                    }

                    return tempListOfEntityIds;
                }
                catch (Exception)
                {
                    return new List<long>();
                }
            }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastInteractedWithEVE
        {
            get { return GetValue(() => LastInteractedWithEVE); }
            set { SetValue(() => LastInteractedWithEVE, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastInWarp
        {
            get { return GetValue(() => LastInWarp); }
            set { SetValue(() => LastInWarp, value); }
        }

        [ReadOnly(true)]
        public string LastMissionName
        {
            get { return GetValue(() => LastMissionName); }
            set { SetValue(() => LastMissionName, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string LastPcName
        {
            get { return GetValue(() => LastPcName); }
            set { SetValue(() => LastPcName, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastPcNameDateTime
        {
            get { return GetValue(() => LastPcNameDateTime); }
            set { SetValue(() => LastPcNameDateTime, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime LastPlexBuy
        {
            get { return GetValue(() => LastPlexBuy); }
            set { SetValue(() => LastPlexBuy, value); }
        }

        [Browsable(false)]
        public DateTime LastQuestorSessionReady
        {
            get { return GetValue(() => LastQuestorSessionReady); }
            set { SetValue(() => LastQuestorSessionReady, value); }
        }

        [Browsable(false)]
        public int LastEveProcessPidInject
        {
            get { return GetValue(() => LastEveProcessPidInject); }
            set { SetValue(() => LastEveProcessPidInject, value); }
        }

        public DateTime LastStartTime
        {
            get { return GetValue(() => LastStartTime); }
            set { SetValue(() => LastStartTime, value); }
        }

        [Browsable(false)]
        public string LeaderCharacterId
        {
            get { return GetValue(() => LeaderCharacterId); }
            set { SetValue(() => LeaderCharacterId, value); }
        }

        [Browsable(false)]
        public string LeaderCharacterName
        {
            get { return GetValue(() => LeaderCharacterName); }
            set { SetValue(() => LeaderCharacterName, value); }
        }

        [Browsable(false)]
        public long LeaderEntityId
        {
            get { return GetValue(() => LeaderEntityId); }
            set { SetValue(() => LeaderEntityId, value); }
        }

        [Browsable(false)]
        public long LeaderFleetID
        {
            get { return GetValue(() => LeaderFleetID); }
            set { SetValue(() => LeaderFleetID, value); }
        }

        [Browsable(false)]
        public long LeaderHomeStationId
        {
            get { return GetValue(() => LeaderHomeStationId); }
            set { SetValue(() => LeaderHomeStationId, value); }
        }

        [Browsable(false)]
        public long LeaderHomeSystemId
        {
            get { return GetValue(() => LeaderHomeSystemId); }
            set { SetValue(() => LeaderHomeSystemId, value); }
        }

        [Browsable(false)]
        public bool LeaderInSpace
        {
            get { return GetValue(() => LeaderInSpace); }
            set { SetValue(() => LeaderInSpace, value); }
        }

        [Browsable(false)]
        public bool LeaderInStation
        {
            get { return GetValue(() => LeaderInStation); }
            set { SetValue(() => LeaderInStation, value); }
        }

        [Browsable(false)]
        public long LeaderInStationId
        {
            get { return GetValue(() => LeaderInStationId); }
            set { SetValue(() => LeaderInStationId, value); }
        }

        [Browsable(false)]
        public bool LeaderInWarp
        {
            get { return GetValue(() => LeaderInWarp); }
            set { SetValue(() => LeaderInWarp, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public long LeaderIsAggressingTargetId
        {
            get { return GetValue(() => LeaderIsAggressingTargetId); }
            set { SetValue(() => LeaderIsAggressingTargetId, value); }
        }

        [Browsable(false)]
        public long LeaderIsInSystemId
        {
            get { return GetValue(() => LeaderIsInSystemId); }
            set { SetValue(() => LeaderIsInSystemId, value); }
        }

        [Browsable(false)]
        public string LeaderIsInSystemName
        {
            get { return GetValue(() => LeaderIsInSystemName); }
            set { SetValue(() => LeaderIsInSystemName, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId1
        {
            get { return GetValue(() => LeaderIsTargetingId1); }
            set { SetValue(() => LeaderIsTargetingId1, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId10
        {
            get { return GetValue(() => LeaderIsTargetingId10); }
            set { SetValue(() => LeaderIsTargetingId10, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId2
        {
            get { return GetValue(() => LeaderIsTargetingId2); }
            set { SetValue(() => LeaderIsTargetingId2, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId3
        {
            get { return GetValue(() => LeaderIsTargetingId3); }
            set { SetValue(() => LeaderIsTargetingId3, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId4
        {
            get { return GetValue(() => LeaderIsTargetingId4); }
            set { SetValue(() => LeaderIsTargetingId4, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId5
        {
            get { return GetValue(() => LeaderIsTargetingId5); }
            set { SetValue(() => LeaderIsTargetingId5, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId6
        {
            get { return GetValue(() => LeaderIsTargetingId6); }
            set { SetValue(() => LeaderIsTargetingId6, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId7
        {
            get { return GetValue(() => LeaderIsTargetingId7); }
            set { SetValue(() => LeaderIsTargetingId7, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId8
        {
            get { return GetValue(() => LeaderIsTargetingId8); }
            set { SetValue(() => LeaderIsTargetingId8, value); }
        }

        [Browsable(false)]
        public long? LeaderIsTargetingId9
        {
            get { return GetValue(() => LeaderIsTargetingId9); }
            set { SetValue(() => LeaderIsTargetingId9, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastActivate
        {
            get { return GetValue(() => LeaderLastActivate); }
            set { SetValue(() => LeaderLastActivate, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastAlign
        {
            get { return GetValue(() => LeaderLastAlign); }
            set { SetValue(() => LeaderLastAlign, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastApproach
        {
            get { return GetValue(() => LeaderLastApproach); }
            set { SetValue(() => LeaderLastApproach, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastDock
        {
            get { return GetValue(() => LeaderLastDock); }
            set { SetValue(() => LeaderLastDock, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdActivate
        {
            get { return GetValue(() => LeaderLastEntityIdActivate); }
            set { SetValue(() => LeaderLastEntityIdActivate, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdAlign
        {
            get { return GetValue(() => LeaderLastEntityIdAlign); }
            set { SetValue(() => LeaderLastEntityIdAlign, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdApproach
        {
            get { return GetValue(() => LeaderLastEntityIdApproach); }
            set { SetValue(() => LeaderLastEntityIdApproach, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdDock
        {
            get { return GetValue(() => LeaderLastEntityIdDock); }
            set { SetValue(() => LeaderLastEntityIdDock, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdJump
        {
            get { return GetValue(() => LeaderLastEntityIdJump); }
            set { SetValue(() => LeaderLastEntityIdJump, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdKeepAtRange
        {
            get { return GetValue(() => LeaderLastEntityIdKeepAtRange); }
            set { SetValue(() => LeaderLastEntityIdKeepAtRange, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdOrbit
        {
            get { return GetValue(() => LeaderLastEntityIdOrbit); }
            set { SetValue(() => LeaderLastEntityIdOrbit, value); }
        }

        [Browsable(false)]
        public long LeaderLastEntityIdWarp
        {
            get { return GetValue(() => LeaderLastEntityIdWarp); }
            set { SetValue(() => LeaderLastEntityIdWarp, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastJump
        {
            get { return GetValue(() => LeaderLastJump); }
            set { SetValue(() => LeaderLastJump, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastKeepAtRange
        {
            get { return GetValue(() => LeaderLastKeepAtRange); }
            set { SetValue(() => LeaderLastKeepAtRange, value); }
        }

        [Browsable(false)]
        public int LeaderLastKeepAtRangeDistance
        {
            get { return GetValue(() => LeaderLastKeepAtRangeDistance); }
            set { SetValue(() => LeaderLastKeepAtRangeDistance, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastOrbit
        {
            get { return GetValue(() => LeaderLastOrbit); }
            set { SetValue(() => LeaderLastOrbit, value); }
        }

        [Browsable(false)]
        public int LeaderLastOrbitDistance
        {
            get { return GetValue(() => LeaderLastOrbitDistance); }
            set { SetValue(() => LeaderLastOrbitDistance, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastRequestRegroup
        {
            get { return GetValue(() => LeaderLastRequestRegroup); }
            set { SetValue(() => LeaderLastRequestRegroup, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastStoppedShip
        {
            get { return GetValue(() => LeaderLastStoppedShip); }
            set { SetValue(() => LeaderLastStoppedShip, value); }
        }

        [Browsable(false)]
        public DateTime LeaderLastWarp
        {
            get { return GetValue(() => LeaderLastWarp); }
            set { SetValue(() => LeaderLastWarp, value); }
        }

        [Browsable(false)]
        public bool LeaderOnGridWithAsteroidBelt
        {
            get { return GetValue(() => LeaderOnGridWithAsteroidBelt); }
            set { SetValue(() => LeaderOnGridWithAsteroidBelt, value); }
        }

        [Browsable(false)]
        public long LeaderOnGridWithEntityIdAsteroidBelt
        {
            get { return GetValue(() => LeaderOnGridWithEntityIdAsteroidBelt); }
            set { SetValue(() => LeaderOnGridWithEntityIdAsteroidBelt, value); }
        }

        [Browsable(false)]
        public long LeaderOnGridWithEntityIdStargate
        {
            get { return GetValue(() => LeaderOnGridWithEntityIdStargate); }
            set { SetValue(() => LeaderOnGridWithEntityIdStargate, value); }
        }

        [Browsable(false)]
        public long LeaderOnGridWithEntityIdStation
        {
            get { return GetValue(() => LeaderOnGridWithEntityIdStation); }
            set { SetValue(() => LeaderOnGridWithEntityIdStation, value); }
        }

        [Browsable(false)]
        public bool LeaderOnGridWithStargate
        {
            get { return GetValue(() => LeaderOnGridWithStargate); }
            set { SetValue(() => LeaderOnGridWithStargate, value); }
        }

        [Browsable(false)]
        public bool LeaderOnGridWithStation
        {
            get { return GetValue(() => LeaderOnGridWithStation); }
            set { SetValue(() => LeaderOnGridWithStation, value); }
        }

        [Browsable(false)]
        public string LeaderRepairGroup
        {
            get { return GetValue(() => LeaderRepairGroup); }
            set { SetValue(() => LeaderRepairGroup, value); }
        }

        [Browsable(false)]
        public long LeaderTravelerDestinationSystemId
        {
            get { return GetValue(() => LeaderTravelerDestinationSystemId); }
            set { SetValue(() => LeaderTravelerDestinationSystemId, value); }
        }

        [Browsable(false)]
        public bool LeaderWarpDriveActive
        {
            get { return GetValue(() => LeaderWarpDriveActive); }
            set { SetValue(() => LeaderWarpDriveActive, value); }
        }

        public double LoyaltyPoints
        {
            get { return GetValue(() => LoyaltyPoints); }
            set { SetValue(() => LoyaltyPoints, value); }
        }

        [ReadOnly(true)]
        public double LpValue
        {
            get
            {
                double _lpValue = IskPerLp * LoyaltyPoints;
                return _lpValue;
            }
        }

        [ReadOnly(true)]
        public DateTime MissionStarted
        {
            get { return GetValue(() => MissionStarted); }
            set { SetValue(() => MissionStarted, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool MovingItemsThereAreNoMoreItemsToGrabAtPickup
        {
            get { return GetValue(() => MovingItemsThereAreNoMoreItemsToGrabAtPickup); }
            set { SetValue(() => MovingItemsThereAreNoMoreItemsToGrabAtPickup, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string myCharacterId
        {
            get { return GetValue(() => myCharacterId); }
            set { SetValue(() => myCharacterId, value); }
        }

        [ReadOnly(true)]
        public string myCorp
        {
            get { return GetValue(() => myCorp); }
            set { SetValue(() => myCorp, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string myCorpId
        {
            get { return GetValue(() => myCorpId); }
            set { SetValue(() => myCorpId, value); }
        }

        [Browsable(false)]
        public int myEntityMode
        {
            get { return GetValue(() => myEntityMode); }
            set { SetValue(() => myEntityMode, value); }
        }

        public string myNote1
        {
            get { return GetValue(() => myNote1); }
            set { SetValue(() => myNote1, value); }
        }

        public string myNote2
        {
            get { return GetValue(() => myNote2); }
            set { SetValue(() => myNote2, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public string myNote3
        {
            get { return GetValue(() => myNote3); }
            set { SetValue(() => myNote3, value); }
        }

        [ReadOnly(true)]
        public DateTime mySkillQueueEnds
        {
            get { return GetValue(() => mySkillQueueEnds); }
            set { SetValue(() => mySkillQueueEnds, value); }
        }

        [ReadOnly(true)]
        public bool TrainingNow
        {
            get { return GetValue(() => TrainingNow); }
            set { SetValue(() => TrainingNow, value); }
        }

        [ReadOnly(true)]
        public string mySkillTraining
        {
            get { return GetValue(() => mySkillTraining); }
            set { SetValue(() => mySkillTraining, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool needHumanIntervention
        {
            get { return GetValue(() => needHumanIntervention); }
            set { SetValue(() => needHumanIntervention, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool NeedRepair
        {
            get { return GetValue(() => NeedRepair); }
            set { SetValue(() => NeedRepair, value); }
        }

        [Browsable(false)]
        public DateTime NextCacheDeletion
        {
            get { return GetValue(() => NextCacheDeletion); }
            set { SetValue(() => NextCacheDeletion, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public DateTime NextWarCheck
        {
            get { return GetValue(() => NextWarCheck); }
            set { SetValue(() => NextWarCheck, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool notAllItemsCouldBeFitted
        {
            get { return GetValue(() => notAllItemsCouldBeFitted); }
            set { SetValue(() => notAllItemsCouldBeFitted, value); }
        }

        public int Num
        {
            get { return GetValue(() => Num); }
            set { SetValue(() => Num, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool OkToInteractWithEveNow
        {
            get
            {
                if (DateTime.UtcNow > LastInteractedWithEVE.AddMilliseconds(650))
                    return true;

                return false;
            }
        }

        public string Password
        {
            get { return GetValue(() => Password); }
            set
            {
                if (Cache.IsServer && EveProcessExists())
                {
                    Cache.Instance.Log("Can't change the password until the client has been stopped.");
                    return;
                }
                SetValue(() => Password, value);
                ClearTokens();
            }
        }

        [Browsable(false)]
        public int Pid
        {
            get { return GetValue(() => Pid); }
            set { SetValue(() => Pid, value); }
        }

        [Browsable(false)]
        public double RamUsage
        {
            get
            {
                if (Running)
                {
                    Process p = Process.GetProcessById(Pid);
                    return p.WorkingSet64 / 1024 / 1024;
                }
                return 0;
            }
        }

        public string RepairGroup
        {
            get { return GetValue(() => RepairGroup); }
            set { SetValue(() => RepairGroup, value); }
        }

        [Browsable(false)]
        [ReadOnly(true)]
        public bool ReplaceMissionsActions
        {
            get { return GetValue(() => ReplaceMissionsActions); }
            set { SetValue(() => ReplaceMissionsActions, value); }
        }

        //[Browsable(true)]
        //[ReadOnly(true)]
        public bool RestartOfEveClientNeeded
        {
            get { return GetValue(() => RestartOfEveClientNeeded); }
            set { SetValue(() => RestartOfEveClientNeeded, value); }
        }

        [Browsable(false)]
        public bool RestartOfQuestorNeeded
        {
            get { return GetValue(() => RestartOfQuestorNeeded); }
            set { SetValue(() => RestartOfQuestorNeeded, value); }
        }

        [Browsable(false)]
        public bool TestingEmergencyReLogin
        {
            get { return GetValue(() => TestingEmergencyReLogin); }
            set { SetValue(() => TestingEmergencyReLogin, value); }
        }

        [ReadOnly(true)]
        public bool Running
        {
            get
            {
                if (Pid == -1)
                {
                    SetValue(() => Running, false);
                }

                return GetValue(() => Running);
            }
            set { SetValue(() => Running, value); }
        }

        [Browsable(false)]
        public string Salt
        {
            get { return GetValue(() => Salt); }
            set { SetValue(() => Salt, value); }
        }

        [Browsable(false)]
        public string SelectedController
        {
            get
            {
                string ret = GetValue(() => SelectedController);
                if (string.IsNullOrEmpty(ret))
                {
                    SelectedController = DefaultController;
                    return DefaultController;
                }
                return ret;
            }
            set { SetValue(() => SelectedController, value); }
        }

        [ReadOnly(true)]
        public string ShipType
        {
            get { return GetValue(() => ShipType); }
            set { SetValue(() => ShipType, value); }
        }

        [Browsable(false)]
        public string ReasonThisEveAccountShouldBeRunning
        {
            get { return GetValue(() => ReasonThisEveAccountShouldBeRunning); }
            set { SetValue(() => ReasonThisEveAccountShouldBeRunning, value); }
        }

        [Browsable(false)]
        public bool ShouldBeRunning
        {
            get
            {
                if (myEveAccountIsAlreadyLoggedIn)
                {
                    ReasonThisEveAccountShouldBeRunning = string.Empty;
                    return false;
                }

                if (InMission) //&& LastInteractedWithEVE.AddMinutes(10) > DateTime.UtcNow)
                {
                    //Cache.Instance.Log("ShouldBeRunning [true] Account [" + AccountName + "] Character [" + CharacterName + "] if ((InAbyssalDeadspace || InMission) && LastInteractedWithEVE.AddMinutes(10) > DateTime.UtcNow)");
                    ReasonThisEveAccountShouldBeRunning = "InMission";
                    return true;
                }

                if (InAbyssalDeadspace) //&& LastInteractedWithEVE.AddMinutes(10) > DateTime.UtcNow)
                {
                    //Cache.Instance.Log("ShouldBeRunning [true] Account [" + AccountName + "] Character [" + CharacterName + "] if ((InAbyssalDeadspace || InMission) && LastInteractedWithEVE.AddMinutes(10) > DateTime.UtcNow)");
                    ReasonThisEveAccountShouldBeRunning = "InAbyssalDeadspace";
                    return true;
                }

                if (RestartOfEveClientNeeded)
                {
                    Cache.Instance.Log("RestartOfEveClientNeeded is [" + RestartOfEveClientNeeded + "] for [" + CharacterName + "]");
                    ReasonThisEveAccountShouldBeRunning = "RestartOfEveClientNeeded";
                    return true;
                }

                if (TestingEmergencyReLogin)
                {
                    //Cache.Instance.Log("TestingEmergencyReLogin is [" + TestingEmergencyReLogin + "]");
                    ReasonThisEveAccountShouldBeRunning = "TestingEmergencyReLogin";
                    return true;
                }

                if (!UseScheduler)
                {
                    //Cache.Instance.Log("ShouldBeRunning [false] Account [" + AccountName + "] Character [" + CharacterName + "] if (!UseScheduler)");
                    ReasonThisEveAccountShouldBeRunning = string.Empty;
                    return false;
                }

                if (StartsPast24H > MAX_STARTS)
                {
                    Cache.Instance.Log("ShouldBeRunning [false] Account [" + AccountName + "] Character [" + MaskedCharacterName + "] if (StartsPast24H [" + StartsPast24H + "] > MAX_STARTS [" + MAX_STARTS + "])");
                    ReasonThisEveAccountShouldBeRunning = string.Empty;
                    return false;
                }

                if (IsDocked || IsSafeInPOS)
                {
                    if (DateTime.UtcNow >= StartTime && DateTime.UtcNow <= EndTime)
                    {
                        ReasonThisEveAccountShouldBeRunning = " CurrentTime [" + DateTime.UtcNow.ToShortTimeString() + "] is between [" + StartTime.ToShortTimeString() + "] and [" + EndTime.ToShortTimeString() + "]";
                        return true;
                    }

                    if (DateTime.UtcNow > EndTime && DateTime.UtcNow >= StartTimeII && DateTime.UtcNow <= EndTimeII)
                    {
                        ReasonThisEveAccountShouldBeRunning = " CurrentTime [" + DateTime.UtcNow.ToShortTimeString() + "] is between [" + StartTimeII.ToShortTimeString() + "] and [" + EndTimeII.ToShortTimeString() + "]";
                        return true;
                    }

                }
                else
                {
                    if (DateTime.UtcNow >= StartTime && DateTime.UtcNow <= EndTime.AddHours(1))
                    {
                        ReasonThisEveAccountShouldBeRunning = " CurrentTime [" + DateTime.UtcNow.ToShortTimeString() + "] is between [" + StartTime.ToShortTimeString() + "] and [" + EndTime.AddHours(1).ToShortTimeString() + "]";
                        return true;
                    }

                    if (DateTime.UtcNow > EndTime && DateTime.UtcNow >= StartTimeII && DateTime.UtcNow <= EndTimeII.AddHours(1))
                    {
                        ReasonThisEveAccountShouldBeRunning = " CurrentTime [" + DateTime.UtcNow.ToShortTimeString() + "] is between [" + StartTimeII.ToShortTimeString() + "] and [" + EndTimeII.AddHours(1).ToShortTimeString() + "]";
                        return true;
                    }
                }

                ReasonThisEveAccountShouldBeRunning = string.Empty;
                return false;
            }
        }

        [Browsable(false)]
        public bool ShouldBeStarted
        {
            get
            {
                if (myEveAccountIsAlreadyLoggedIn)
                    return false;

                if (RestartOfEveClientNeeded)
                {
                    Cache.Instance.Log("RestartOfEveClientNeeded is [" + RestartOfEveClientNeeded + "]");
                    return true;
                }

                if (TestingEmergencyReLogin)
                {
                    Cache.Instance.Log("TestingEmergencyReLogin is [" + TestingEmergencyReLogin + "]");
                    return true;
                }

                //
                // if we have the schedule on (UseScheduler)
                //
                if (!UseScheduler) return false; //&& !RestartOfEveClientNeeded) return false;
                if (!CheckPrerequisitesBeforeStartingEveClient()) return false;

                bool shouldBeStarted = UseScheduler;
                if (!shouldBeStarted)
                {
                    //
                    // If we are inAbyssalDeadSpace or InMission and we were last connected less than 10 min ago: reconnect so that we dont go boom!
                    //
                    shouldBeStarted = (InAbyssalDeadspace || InMission); //&& LastInteractedWithEVE.AddMinutes(10) > DateTime.UtcNow;
                    Cache.Instance.Log("ShouldBeStarted: [" + shouldBeStarted + "] Account [" + AccountName + "] Character [" + MaskedCharacterName + "] UseScheduler [" + UseScheduler + "] InAbyssalDeadspace [" + InAbyssalDeadspace + "] InMission [" + InMission + "]");
                }

                //
                // If we are at war and its not yet time to check for wars again
                //
                if (IsAtWar && NextWarCheck > DateTime.UtcNow)
                {
                    shouldBeStarted = false;

                    if (DateTime.UtcNow > _nextAtWarLogMessage)
                    {
                        Cache.Instance.Log("ShouldBeStarted: [" + shouldBeStarted + "] Account [" + AccountName + "] Character [" + MaskedCharacterName + "] IsAtWar [" + IsAtWar + "] NextWarCheck [" + NextWarCheck + "]");
                        _nextAtWarLogMessage = DateTime.UtcNow.AddHours(8);
                    }
                }

                if (!IsOmegaClone && RequireOmegaClone)
                {
                    shouldBeStarted = false;

                    if (DateTime.UtcNow > _nextOmegaCloneLogMessage)
                    {
                        Cache.Instance.Log("ShouldBeStarted: [" + shouldBeStarted + "] Account [" + AccountName + "] Character [" + MaskedCharacterName + "] IsOmegaClone [" + IsOmegaClone + "] RequireOmegaClone [" + RequireOmegaClone + "]");
                        _nextOmegaCloneLogMessage = DateTime.UtcNow.AddHours(8);
                    }
                }

                if (shouldBeStarted)
                {
                    //
                    // is this account scheduled to start using the scheduler (Is_Scheduler_Active)
                    //
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                        if (eA.Running && eA.AccountName == AccountName && eA.CharacterName != CharacterName)
                            if (eA.LastInteractedWithEVE.AddMinutes(2) > DateTime.UtcNow)
                            {
                                //
                                // if we have another configured toon on the same account actually running...
                                //
                                shouldBeStarted = false;
                                Cache.Instance.Log("ShouldBeStarted: [" + shouldBeStarted + "] Account [" + AccountName + "] Character [" + MaskedCharacterName + "] another character [" + eA.CharacterName + "] on the same account has been logged in within the last 2 min! ");
                            }
                }

                return shouldBeStarted;
            }
        }

        [Browsable(false)]
        public string SlaveCharacter1RepairGroup
        {
            get { return GetValue(() => SlaveCharacter1RepairGroup); }
            set { SetValue(() => SlaveCharacter1RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter2RepairGroup
        {
            get { return GetValue(() => SlaveCharacter2RepairGroup); }
            set { SetValue(() => SlaveCharacter2RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter3RepairGroup
        {
            get { return GetValue(() => SlaveCharacter3RepairGroup); }
            set { SetValue(() => SlaveCharacter3RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter4RepairGroup
        {
            get { return GetValue(() => SlaveCharacter4RepairGroup); }
            set { SetValue(() => SlaveCharacter4RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter5RepairGroup
        {
            get { return GetValue(() => SlaveCharacter5RepairGroup); }
            set { SetValue(() => SlaveCharacter5RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter6RepairGroup
        {
            get { return GetValue(() => SlaveCharacter6RepairGroup); }
            set { SetValue(() => SlaveCharacter6RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter7RepairGroup
        {
            get { return GetValue(() => SlaveCharacter7RepairGroup); }
            set { SetValue(() => SlaveCharacter7RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter8RepairGroup
        {
            get { return GetValue(() => SlaveCharacter8RepairGroup); }
            set { SetValue(() => SlaveCharacter8RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter9RepairGroup
        {
            get { return GetValue(() => SlaveCharacter9RepairGroup); }
            set { SetValue(() => SlaveCharacter9RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter10RepairGroup
        {
            get { return GetValue(() => SlaveCharacter10RepairGroup); }
            set { SetValue(() => SlaveCharacter10RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter11RepairGroup
        {
            get { return GetValue(() => SlaveCharacter11RepairGroup); }
            set { SetValue(() => SlaveCharacter11RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter12RepairGroup
        {
            get { return GetValue(() => SlaveCharacter12RepairGroup); }
            set { SetValue(() => SlaveCharacter12RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter13RepairGroup
        {
            get { return GetValue(() => SlaveCharacter13RepairGroup); }
            set { SetValue(() => SlaveCharacter13RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter14RepairGroup
        {
            get { return GetValue(() => SlaveCharacter14RepairGroup); }
            set { SetValue(() => SlaveCharacter14RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacter15RepairGroup
        {
            get { return GetValue(() => SlaveCharacter15RepairGroup); }
            set { SetValue(() => SlaveCharacter15RepairGroup, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName1
        {
            get { return GetValue(() => SlaveCharacterName1); }
            set { SetValue(() => SlaveCharacterName1, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName2
        {
            get { return GetValue(() => SlaveCharacterName2); }
            set { SetValue(() => SlaveCharacterName2, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName3
        {
            get { return GetValue(() => SlaveCharacterName3); }
            set { SetValue(() => SlaveCharacterName3, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName4
        {
            get { return GetValue(() => SlaveCharacterName4); }
            set { SetValue(() => SlaveCharacterName4, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName5
        {
            get { return GetValue(() => SlaveCharacterName5); }
            set { SetValue(() => SlaveCharacterName5, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName6
        {
            get { return GetValue(() => SlaveCharacterName6); }
            set { SetValue(() => SlaveCharacterName6, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName7
        {
            get { return GetValue(() => SlaveCharacterName7); }
            set { SetValue(() => SlaveCharacterName7, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName8
        {
            get { return GetValue(() => SlaveCharacterName8); }
            set { SetValue(() => SlaveCharacterName8, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName9
        {
            get { return GetValue(() => SlaveCharacterName9); }
            set { SetValue(() => SlaveCharacterName9, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName10
        {
            get { return GetValue(() => SlaveCharacterName10); }
            set { SetValue(() => SlaveCharacterName10, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName11
        {
            get { return GetValue(() => SlaveCharacterName11); }
            set { SetValue(() => SlaveCharacterName11, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName12
        {
            get { return GetValue(() => SlaveCharacterName12); }
            set { SetValue(() => SlaveCharacterName12, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName13
        {
            get { return GetValue(() => SlaveCharacterName13); }
            set { SetValue(() => SlaveCharacterName13, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName14
        {
            get { return GetValue(() => SlaveCharacterName14); }
            set { SetValue(() => SlaveCharacterName14, value); }
        }

        [Browsable(false)]
        public string SlaveCharacterName15
        {
            get { return GetValue(() => SlaveCharacterName15); }
            set { SetValue(() => SlaveCharacterName15, value); }
        }

        [ReadOnly(true)]
        public string SolarSystem
        {
            get { return GetValue(() => SolarSystem); }
            set { SetValue(() => SolarSystem, value); }
        }

        [Browsable(false)]
        public float StandingUsedToAccessAgent
        {
            get { return GetValue(() => StandingUsedToAccessAgent); }
            set { SetValue(() => StandingUsedToAccessAgent, value); }
        }

        public int StartHour
        {
            get { return GetValue(() => StartHour); }
            set
            {
                SetValue(() => StartHour, value);
                GenerateNewTimeSpans();
            }
        }

        [Browsable(false)]
        public int StartHourII
        {
            get { return GetValue(() => StartHourII); }
            set
            {
                SetValue(() => StartHourII, value);
                GenerateNewTimeSpans();
            }
        }

        [Browsable(false)]
        public DateTime StartingTokenTime
        {
            get { return GetValue(() => StartingTokenTime); }
            set { SetValue(() => StartingTokenTime, value); }
        }

        [XmlIgnore]
        [Browsable(false)]
        public TimeSpan StartingTokenTimespan
        {
            get { return GetValue(() => StartingTokenTimespan); }
            set { SetValue(() => StartingTokenTimespan, value); }
        }

        [Browsable(false)]
        [XmlElement("StartingTokenTimespan")]
        public long StartingTokenTimespanWrapper
        {
            get => StartingTokenTimespan.Ticks;
            set => StartingTokenTimespan = TimeSpan.FromTicks(value);
        }

        [XmlIgnore]
        public int StartsPast24H
        {
            get { return GetValue(() => StartsPast24H); }
            set { SetValue(() => StartsPast24H, value); }
        }

        public DateTime StartTime
        {
            get { return GetValue(() => StartTime); }
            set { SetValue(() => StartTime, value); }
        }

        [Browsable(false)]
        public DateTime StartTimeII
        {
            get { return GetValue(() => StartTimeII); }
            set { SetValue(() => StartTimeII, value); }
        }

        /**
        public bool ManuallyLogin
        {
            get { return GetValue(() => ManuallyLogin); }
            set { SetValue(() => ManuallyLogin, value); }
        }
        **/

        //[Browsable(false)]
        //public bool AllowHideEveWindow = false;
        //{
        //    get { return GetValue(() => AllowHideEveWindow); }
        //    set { SetValue(() => AllowHideEveWindow, value); }
        //}

        public DateTime SubEnd
        {
            get { return GetValue(() => SubEnd); }
            set { SetValue(() => SubEnd, value); }
        }

        [ReadOnly(true)]
        public double TotalValue
        {
            get
            {
                double _totalValue = WalletBalance + LpValue + ItemHangarValue;
                return _totalValue;
            }
        }

        [Browsable(false)]
        public string UniqueID
        {
            get
            {
                string val = GetValue(() => UniqueID);
                if (string.IsNullOrEmpty(val))
                {
                    if (string.IsNullOrEmpty(Salt))
                        Salt = Path.GetRandomFileName().Replace(".", "");
                    val = Util.Sha256(Util.Sha256(CharacterName + AccountName) + Salt);
                    SetValue(() => UniqueID, val);
                }
                return val;
            }
            set { SetValue(() => UniqueID, value); }
        }

        public double WalletBalance
        {
            get { return GetValue(() => WalletBalance); }
            set { SetValue(() => WalletBalance, value); }
        }

        [Browsable(false)]
        public bool Use64BitEveClient
        {
            get { return GetValue(() => Use64BitEveClient); }
            set { SetValue(() => Use64BitEveClient, value); }
        }

        [Browsable(false)]
        private string ExeFileFullPath
        {
            get
            {
                string tempEveDirectory = Cache.Instance.EveSettings.EveDirectory;
                if (ConnectToTestServer)
                    tempEveDirectory = tempEveDirectory.Replace("tq", "sisi");

                if (Use64BitEveClient)
                {
                    tempEveDirectory = tempEveDirectory.Replace("bin", "bin64");
                    tempEveDirectory = tempEveDirectory.Replace("6464", "64");
                }

                return tempEveDirectory;
            }
        }

        #endregion Properties

        #region Methods

        public bool CheckEvents()
        {
            foreach (DirectEvents directEvent in Enum.GetValues(typeof(DirectEvents)))
            {
                int value = (int)directEvent;

                if (value < 0)
                    continue;

                if (!ManuallyPausedViaUI && HasLastDirectEvent(directEvent) && GetLastDirectEvent(directEvent).Value < DateTime.UtcNow.AddMinutes(-Math.Abs(value)))
                {
                    Cache.Instance.Log(string.Format("Stopping account [{0}] because DirectEvent [{1}] hasn't been received within [{2}] minutes.", AccountName,
                        directEvent, value));
                    return false;
                }
            }
            return true;
        }

        public void ClearCache()
        {
            Cache.Instance.Log($"Next cache deletion for character {MaskedCharacterName} set to {DateTime.MinValue}");
            NextCacheDeletion = DateTime.MinValue;
        }

        public void ClearTokens()
        {
            try
            {
                if (Cache.Instance == null)
                    return;
                Cache.Instance.Log("Clearing tokens.");
            }
            catch (Exception)
            {
            }
            EveSSOToken = string.Empty;
            EveSSOTokenValidUntil = DateTime.MinValue;
            EveAccessToken = string.Empty;
            EveAccessTokenValidUntil = DateTime.MinValue;
        }

        public void DeleteCurlCookie()
        {
            try
            {
                using (var curlWoker = new CurlWorker(AccountName))
                {
                    if (curlWoker.DeleteCurrentSessionCookie(true))
                    {
                        Cache.Instance.Log($"Cookies for Account [{AccountName}] deleted.");
                    }
                }
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception: [" + ex + "]");
            }
        }

        public bool EveProcessExists()
        {
            Process[] ps = Process.GetProcesses();
            return Pid != -1 && Pid != 0 && ps.Any(x => x.Id == Pid) && ps.FirstOrDefault(x => x.Id == Pid).ProcessName.ToLower().Contains("exefile");
        }

        public void GenerateNewTimeSpans()
        {
            try
            {
                StartsPast24H = 0;
                //
                // Schedule One
                //
                DateTime start = DateTime.UtcNow.Date.AddHours(StartHour).AddMinutes(rnd.Next(10, 50));
                StartTime = start;
                EndTime = start.AddHours(HoursPerDay).AddMinutes(rnd.Next(10, 50));
                //
                // Schedule Two
                //
                if (StartHourII != 0 && HoursPerDayII > 0)
                {
                    DateTime startII = DateTime.UtcNow.Date.AddHours(StartHourII).AddMinutes(rnd.Next(10, 50));
                    StartTimeII = startII;
                    EndTimeII = startII.AddHours(HoursPerDayII).AddMinutes(rnd.Next(10, 50));
                }
            }
            catch (Exception e)
            {
                Cache.Instance.Log("Exception " + e.StackTrace);
            }
        }

        public IDuplexServiceCallback GetClientCallback()
        {
            return ClientCallback;
        }

        private bool UseLocalInternetConnection()
        {
            if (HWSettings.Proxy.LocalEveServerPort == "0" || string.IsNullOrEmpty(HWSettings.Proxy.LocalEveServerPort))
            {
                if (HWSettings.Proxy.HttpProxyPort == "0" || string.IsNullOrEmpty(HWSettings.Proxy.HttpProxyPort))
                {
                    if (HWSettings.Proxy.Socks5Port == "0" || string.IsNullOrEmpty(HWSettings.Proxy.Socks5Port))
                    {
                        return true;
                    }

                    Cache.Instance.Log("[" + AccountName + "][" + CharacterName + "] has LocalEveServerPort and HttpProxyPort are set to 0, but Socks5Port is not 0: if you want to use a proxy set LocalEveServerPort and HttpProxyPort: If you want to use the local internet connection set: LocalEveServerPort, HttpProxyPort, Socks5Port to 0");
                    return false;
                }

                Cache.Instance.Log("[" + AccountName + "][" + CharacterName + "] has LocalEveServerPort set to 0, but HttpProxyPort is not 0: if you want to use a proxy set LocalEveServerPort: If you want to use the local internet connection set: LocalEveServerPort, HttpProxyPort, Socks5Port to 0");
                return false;
            }

            return false;
        }

        public string GetEveStartParameter(string ssoToken)
        {
            try
            {
                if (HWSettings.LauncherMachineHash.Length != 32)
                    return string.Empty;

                Cache.Instance.Log($"MD5 MachineHash: [{HWSettings.LauncherMachineHash}]");

                string ServerStartupSwitch = "/server:127.0.0.1:" + HWSettings.Proxy.LocalEveServerPort;

                if (UseLocalInternetConnection())
                {
                    Cache.Instance.Log("[" + AccountName + "][" + CharacterName + "] is configured to use the Local Internet Connection!");
                    ServerStartupSwitch = "/server:Tranquility";
                    Cache.Instance.Log("ServerStartupSwitch [" + ServerStartupSwitch + "] LocalEVEServerPort is [" + HWSettings.Proxy.LocalEveServerPort + "]");
                }
                else Cache.Instance.Log("ServerStartupSwitch [" + ServerStartupSwitch + "] LocalEVEServerPort is [" + HWSettings.Proxy.LocalEveServerPort + "]");


                //if (ConnectToTestServer)
                //    ServerStartupSwitch = "/server:Singularity";

                string startParams = string.Empty;
                string DXVersion = "dx9";
                if (DX11) DXVersion = "dx11";

                startParams += ServerStartupSwitch + " " + "/triPlatform=" + DXVersion + " " + "/machineHash=" + HWSettings.LauncherMachineHash + " ";

                //if (!ManuallyLogin)
                //{
                startParams += "/ssoToken=" + ssoToken + " ";

                if (!string.IsNullOrEmpty(myCharacterId) && ByPassLoginScreen)
                {
                    startParams += " /character=" + myCharacterId + " ";
                }
                //}

                return startParams;
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception " + ex);
                return string.Empty;
            }
        }

        public DateTime? GetLastDirectEvent(DirectEvents directEvent)
        {
            return DirectEventHandler.GetLastEventReceived(CharacterName, directEvent);
        }

        public bool HasLastDirectEvent(DirectEvents directEvent)
        {
            return DirectEventHandler.GetLastEventReceived(CharacterName, directEvent) != null;
        }

        public void HideConsoleWindow()
        {
            if (Running)
                foreach (KeyValuePair<IntPtr, string> w in Util.GetVisibleWindows(Pid))
                    if (w.Value.Contains("[CCP]"))
                        Util.ShowWindow(w.Key, Util.SW_HIDE);
        }

        public void HideWindows()
        {
            if (Running && !DisableHiding)
                foreach (KeyValuePair<IntPtr, string> w in Util.GetVisibleWindows(Pid))
                    Util.ShowWindow(w.Key, Util.SW_HIDE);
        }

        public bool ShouldWeKillEveIfProcessNotAlive
        {
            get
            {
                if (string.IsNullOrEmpty(CharacterName))
                    return false;

                if (InAbyssalDeadspace)
                    return true;

                if (!Cache.Instance.EveSettings.KillUnresponsiveEvEs ?? true)
                    return false;

                if (ManuallyPausedViaUI)
                    return false;

                if (ManuallyStarted)
                    return false;

                return true;
            }
        }

        public bool IsProcessAlive()
        {
            CheckEveAccountSettings();

            Process p = Process.GetProcesses().FirstOrDefault(x => x.Id == Pid);
            if (p != null)
            {
                //bool killUnresponsiveEvEs = Cache.Instance.EveSettings.KillUnresponsiveEvEs ?? true;
                if (!ManuallyPausedViaUI && !IsProcessResponding(p))
                {
                    Cache.Instance.Log("Account [" + AccountName + "] Character [" + MaskedCharacterName +  "] if (!IsProcessResponding(p))");
                    return false;
                }

                //
                // we have been logged in more than 10 sec and its been more than 10 sec since session was ready
                //

                if (DoneLaunchingEveInstance && DateTime.UtcNow > LastStartTime.AddSeconds(90))
                {
                    if (!ManuallyPausedViaUI && !CheckEvents())
                    {
                        Cache.Instance.Log("Account [" + AccountName + "] Character [" + MaskedCharacterName + "] if (!CheckEvents())");
                        return false;
                    }

                    int timeToWait = 17;
                    if (InAbyssalDeadspace)
                        timeToWait = 25;

                    if (!ManuallyPausedViaUI && DateTime.UtcNow > LastQuestorSessionReady.AddSeconds(timeToWait))
                    {
                        Cache.Instance.Log("Account [" + AccountName + "] Character [" + MaskedCharacterName + "] if (DateTime.UtcNow > LastQuestorSessionReady.AddSeconds(10))");
                        return false;
                    }
                }

                return true;
            }

            return false;
        }

        public bool IsProcessResponding(Process p)
        {
            if (p != null)
            {
                if (_lastResponding == null)
                    _lastResponding = DateTime.UtcNow;

                if (p.Responding)
                {
                    _lastResponding = DateTime.UtcNow;
                    return true;
                }

                if (!DoneLaunchingEveInstance || LastStartTime.AddSeconds(90) > DateTime.UtcNow)
                    return _lastResponding.Value.AddSeconds(90) > DateTime.UtcNow;

                return _lastResponding.Value.AddSeconds(20) > DateTime.UtcNow;
            }
            return false;
        }

        public bool KillEveProcess(bool force = false)
        {
            if (lastEveInstanceKilled.AddSeconds(waitTimeBetweenEveInstancesKills) < DateTime.UtcNow || !IsProcessAlive() || force)
            {
                lastEveInstanceKilled = DateTime.UtcNow;
                waitTimeBetweenEveInstancesKills = rnd.Next(7, 12);
                if (Running)
                {
                    //Process p = Process.GetProcessById(this.Pid);
                    //p.Kill();
                    try
                    {
                        Util.TaskKill(Pid, true);
                        Info = string.Empty;
                        Cache.Instance.Log(string.Format($"Stopping Eve process used by character {MaskedCharacterName} on account {AccountName} with pid {Pid}"));
                    }
                    catch
                    {
                        Cache.Instance.Log("Exception: Couldn't execute taskkill.");
                    }
                    return true;
                }
            }
            return false;
        }

        public void SetClientCallback(IDuplexServiceCallback s)
        {
            ClientCallback = s;
        }

        public void ShowConsoleWindow()
        {
            if (Running)
                foreach (KeyValuePair<IntPtr, string> w in Util.GetInvisibleWindows(Pid))
                    if (w.Value.Contains("[CCP]"))
                        Util.ShowWindow(w.Key, Util.SW_SHOWNOACTIVATE);
        }

        public void ShowWindows()
        {
            if (Running)
            {
                if (WinApiUtil.WinApiUtil.IsValidHWnd((IntPtr)EveHWnd))
                {
                    WinApiUtil.WinApiUtil.AddToTaskbar((IntPtr)EveHWnd);
                    WinApiUtil.WinApiUtil.SetWindowsPos((IntPtr)EveHWnd, 0, 0);
                    if (WinApiUtil.WinApiUtil.IsValidHWnd((IntPtr)Cache.Instance.MainFormHWnd))
                    {
                        WinApiUtil.WinApiUtil.SetHWndInsertAfter((IntPtr)EveHWnd, (IntPtr)Cache.Instance.MainFormHWnd);
                        WinApiUtil.WinApiUtil.SetHWndInsertAfter((IntPtr)HookmanagerHWnd, (IntPtr)Cache.Instance.MainFormHWnd);
                        WinApiUtil.WinApiUtil.SetHWndInsertAfter((IntPtr)EVESharpCoreFormHWnd, (IntPtr)Cache.Instance.MainFormHWnd);
                    }
                    Util.ShowWindow((IntPtr)EveHWnd, Util.SW_SHOWNOACTIVATE);
                }

                Dictionary<IntPtr, string> list = Util.GetInvisibleWindows(Pid);
                foreach (KeyValuePair<IntPtr, string> w in list)
                    if ((long)w.Key == HookmanagerHWnd
                        || (long)w.Key == EVESharpCoreFormHWnd
                        || w.Value.Contains("exefile.exe")
                        || w.Value.Contains("[CCP]") && Console)
                        Util.ShowWindow(w.Key, Util.SW_SHOWNOACTIVATE);

                if (WinApiUtil.WinApiUtil.IsValidHWnd((IntPtr)EveHWnd))
                {
                    WinApiUtil.WinApiUtil.SetWindowsPos((IntPtr)EveHWnd, 0, 0);
                    Util.ShowWindow((IntPtr)EveHWnd, Util.SW_SHOWNOACTIVATE);
                    WinApiUtil.WinApiUtil.ForcePaint((IntPtr)EveHWnd);
                    WinApiUtil.WinApiUtil.ForceRedraw((IntPtr)EveHWnd);
                }
            }
        }

        public bool CheckPrerequisitesBeforeStartingEveClient()
        {
            if (Running)
            {
                Cache.Instance.Log("[" + AccountName + "][" + MaskedCharacterName + "] already has an eve process running!");
                return false;
            }

            if (ClientSettingsSerializationErrors > MAX_SERIALIZATION_ERRORS && !IgnoreSeralizationErrors)
            {
                Cache.Instance.Log("[" + AccountName + "][" + MaskedCharacterName + "] Client settings serialization error!");
                UseScheduler = false;
                return false;
            }

            //if (ClientSetting == null)
            //    Cache.Instance.Log("ClientSetting == null. Error. continue anyway");

            if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.Any(i => i.Running && !i.DoneLaunchingEveInstance && i.myCharacterId != myCharacterId && !InAbyssalDeadspace && !RestartOfEveClientNeeded && !TestingEmergencyReLogin))
            {
                EveAccount accountCurrentlyStarting = Cache.Instance.EveAccountSerializeableSortableBindingList.List.FirstOrDefault(i => i.Running && !i.DoneLaunchingEveInstance && i.myCharacterId != myCharacterId);
                Cache.Instance.Log("We cannot start [ " + CharacterName.Substring(0, 2) + "*********" + " ]. We are still waiting for [" + accountCurrentlyStarting.CharacterName.Substring(0, 2) + "*********" + "] to finish launching eve");
                return false;
            }

            //
            // only check for a character name if Autostart is true. This allows us to have a blank character name while setting up a toon!
            //
            if (UseScheduler && string.IsNullOrEmpty(CharacterName))
            {
                UseScheduler = false;
                Cache.Instance.Log("[" + AccountName + "] A character name is required and was not found");
                return false;
            }

            if (string.IsNullOrEmpty(AccountName))
            {
                UseScheduler = false;
                Cache.Instance.Log("[" + Num + "] A account name is required and was not found.");
                return false;
            }

            if (string.IsNullOrEmpty(Password))
            {
                UseScheduler = false;
                Cache.Instance.Log("[" + Num + "] A password for the account required and was not found.");
                return false;
            }

            if (HWSettings == null || HWSettings.Proxy == null || !HWSettings.Proxy.IsValid)
            {
                UseScheduler = false;
                Cache.Instance.Log("[" + AccountName + "][" + MaskedCharacterName + "] HWSettings or HWSettings.Proxy == null. Error.");
                return false;
            }

            if (HWSettings == null || HWSettings != null && string.IsNullOrWhiteSpace(HWSettings.Computername) ||
                HWSettings != null && string.IsNullOrWhiteSpace(HWSettings.Computername))
            {
                UseScheduler = false;
                Cache.Instance.Log(
                    "[" + AccountName + "][" + MaskedCharacterName + "] Hardware profile usage is now required. Please setup a different hardware profile for each account or use the same profile for accounts you want to link together.");
                return false;
            }

            if (string.IsNullOrEmpty(HWSettings.LauncherMachineHash))
            {
                UseScheduler = false;
                Cache.Instance.Log("[" + AccountName + "][" + MaskedCharacterName + "] LauncherMachineHash missing. You need to open the HWProfile form once to generate a LauncherMachineHash.");
                return false;
            }

            if (string.IsNullOrEmpty(HWSettings.GpuManufacturer) || HWSettings.GpuDriverDate == null || HWSettings.GpuDriverDate == DateTime.MinValue)
            {
                UseScheduler = false;
                Cache.Instance.Log("[" + AccountName + "][" + MaskedCharacterName + "] You need to generate a new GPU profile for this account.");
                return false;
            }

            if (!HWSettings.Proxy.InternetConnectivityTest())
                return false;

            if (!HWSettings.Proxy.SafeToAttemptEveSso)
            {
                Cache.Instance.Log("[" + AccountName + "][" + MaskedCharacterName + "] if (LastGetSsoTokenTimeStamp.AddSeconds(15) > DateTime.UtcNow) aborting login attempt: slow down there buddy");
                return false;
            }

            return true;
        }

        public void StartEveInject()
        {
            try
            {
                if (!CheckPrerequisitesBeforeStartingEveClient()) return;

                IsbelEveAccount.Token ssoToken;
                IsbelEveAccount myIsbelEveAccount = new IsbelEveAccount();
                myIsbelEveAccount.SetEveAccount(this);
                HWSettings.Proxy.LastEveSsoAttempt = DateTime.UtcNow;
                if (UseLocalInternetConnection())
                    Cache.Instance.Log("GetSSOToken: [" + AccountName + "][" + CharacterName + "] is configured to use the Local Internet Connection!");
                else
                    Cache.Instance.Log("GetSSOToken: [" + AccountName + "][" + CharacterName + "] is configured to use the proxy connection [" + HWSettings.Proxy.Description + "]");

                Cache.Instance.Log("GetSSOToken: [" + AccountName + "][" + CharacterName + "] Attempt to retrieve ssoToken");
                LoginResult lr = myIsbelEveAccount.GetSSOToken(this, ConnectToTestServer, HWSettings.Proxy.Ip, HWSettings.Proxy.HttpProxyPort, out ssoToken);
                if (lr != LoginResult.Success)
                {
                    StartsPast24H++;
                    Cache.Instance.Log("LoginResult != Success: LoginResult [" + lr + "]");
                    return;
                }

                if (ssoToken == null)
                {
                    Cache.Instance.Log("ssoToken is empty. Error.");
                    StartsPast24H++;
                    //StartProxy();
                    return;
                }

                Cache.Instance.Log("ssoToken retrieved successfully [" + ssoToken + "]");

                /**
                if (!ConnectToTestServer && string.IsNullOrEmpty(TranquilityToken.TokenString))
                {
                    Cache.Instance.Log("TranquilityToken is empty. Error.");
                    StartsPast24H++;
                    //StartProxy();
                    return;
                }

                if (ConnectToTestServer && string.IsNullOrEmpty(SisiToken.TokenString))
                {
                    Cache.Instance.Log("SisiToken is empty. Error.");
                    StartsPast24H++;
                    //StartProxy();
                    return;
                }
                **/


                Util.CheckCreateDirectorys(HWSettings.WindowsUserLogin);

                string[] args = { CharacterName, WCFServer.Instance.GetPipeName };
                Pid = 0;
                int processId = -1;
                EVESharpCoreFormHWnd = -1;
                EveHWnd = -1;
                HookmanagerHWnd = -1;

                string myChacactersLogDirectoryName = CharacterName;
                if (string.IsNullOrEmpty(myChacactersLogDirectoryName))
                    myChacactersLogDirectoryName = AccountName;

                string currentAppDataFolder = GetAppDataFolder();
                string eveBasePath = GetEveUnderscorePath();
                string appDataCCPEveFolder = currentAppDataFolder + "CCP\\EVE\\";
                string eveSettingFolder = currentAppDataFolder + "CCP\\EVE\\" + eveBasePath + "\\";
                string crashDumpFolder = currentAppDataFolder + "CrashDumps";
                string defaultSettingsFolder = GetDefaultSettingsFolder(); // default settings folder to copy
                string eveCacheFolder = eveSettingFolder + "cache\\";
                string questorConsoleLogFolder = Path.Combine(Util.AssemblyPath, "Logs", myChacactersLogDirectoryName, "Console");
                string sharpLogLiteFolder = Path.Combine(Util.AssemblyPath, "Logs", myChacactersLogDirectoryName, "SharpLogLite");
                string logFolder = Path.Combine(Util.AssemblyPath, "Logs");

                try
                {
                    if (Directory.Exists(logFolder))
                        foreach (string file in Directory.GetFiles(logFolder, "*.log").Where(item => item.EndsWith(".log")))
                            if (File.Exists(file))
                            {
                                long fileSize = new FileInfo(file).Length;
                                if (fileSize > 1024 * 1024)
                                    File.Delete(file);
                            }

                    if (Directory.Exists(questorConsoleLogFolder))
                        foreach (string file in Directory.GetFiles(questorConsoleLogFolder, "*.log").Where(item => item.EndsWith(".log")))
                        {
                            DateTime fileLastwrite = File.GetLastWriteTimeUtc(file);
                            if (fileLastwrite.AddDays(15) < DateTime.UtcNow)
                                File.Delete(file);
                        }

                    if (Directory.Exists(sharpLogLiteFolder))
                        foreach (string file in Directory.GetFiles(sharpLogLiteFolder, "*.log").Where(item => item.EndsWith(".log")))
                        {
                            DateTime fileLastwrite = File.GetLastWriteTimeUtc(file);
                            long fileSize = new FileInfo(file).Length;
                            if (fileLastwrite.AddDays(90) < DateTime.UtcNow || fileSize > 1024 * 1024)
                                File.Delete(file);
                        }

                    if (Directory.Exists(crashDumpFolder))
                        foreach (string file in Directory.GetFiles(crashDumpFolder, "*.dmp").Where(item => item.EndsWith(".dmp")))
                            File.Delete(file);

                    if (Directory.Exists(crashDumpFolder))
                        foreach (string file in Directory.GetFiles(appDataCCPEveFolder, "*.crs").Where(item => item.EndsWith(".crs")))
                            File.Delete(file);

                    foreach (string file in Directory.GetFiles(appDataCCPEveFolder, "*.dmp").Where(item => item.EndsWith(".dmp")))
                        File.Delete(file);

                    if (Directory.Exists(eveSettingFolder))
                        Cache.Instance.Log($"Eve settings directory: {eveCacheFolder}");
                    else
                        Cache.Instance.Log($"Eve settings does not exist!");

                    if (Directory.Exists(eveCacheFolder))
                        Cache.Instance.Log($"Cache directory: {eveCacheFolder}");
                    else
                        Cache.Instance.Log($"Cache directory does not exist!");

                    if (Directory.Exists(eveCacheFolder) && NextCacheDeletion < DateTime.UtcNow)
                    {
                        NextCacheDeletion = DateTime.UtcNow.AddDays(Util.GetRandom(15, 45));
                        Cache.Instance.Log("Clearing EVE cache folder: " + eveCacheFolder + " Next cache deletion will be on: " + NextCacheDeletion);
                        Directory.Delete(eveCacheFolder, true);

                        if (Directory.Exists(GetPersonalFolder() + "Documents\\EVE\\logs\\"))
                            Directory.Delete(GetPersonalFolder() + "Documents\\EVE\\logs\\", true);
                    }
                }
                catch (Exception)
                {
                    Cache.Instance.Log("Couldn't clear cache, crs files, dmp files.");
                }

                if (!Directory.Exists(eveSettingFolder))
                {
                    Util.DirectoryCopy(defaultSettingsFolder, eveSettingFolder, true);
                    Cache.Instance.Log("EveSettingsFolder doesn't exist. Copying default settings");
                }
                else
                {
                    Cache.Instance.Log("EveSettingsFolder already exists. Not copying default settings");
                }

                if (!File.Exists(ExeFileFullPath))
                {
                    //Cache.Instance.Log("Exefile.exe is missing from [" + ExeFileFullPath + "]");
                    //return;
                }

                if (!ExeFileFullPath.ToLower().EndsWith("exefile.exe"))
                {
                    //Cache.Instance.Log("Exefile.exe filename not properly set? It has to end with exefile.exe");
                    //return;
                }

                string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string injectionFile = Path.Combine(path, "DomainHandler.dll");
                string ChannelName = null;

                Cache.Instance.Log("IpcCreateServer: Creating IPC server for Account [" + AccountName + "]");
                RemoteHooking.IpcCreateServer<EVESharpInterface>(ref ChannelName, WellKnownObjectMode.SingleCall);

                string startParams = GetEveStartParameter(ssoToken.TokenString);

                if (startParams.Length == 0)
                {
                    Cache.Instance.Log("Error: startParams.Length == 0.");
                    return;
                }

                Cache.Instance.Log("CreateAndInject: Starting EVE Client for Account [" + AccountName + "] using [" + ExeFileFullPath + " " + startParams + "]");
                RemoteHooking.CreateAndInject(ExeFileFullPath, startParams, (int)InjectionOptions.Default, injectionFile,
                    injectionFile, out processId, ChannelName, args);

                //RemoteHooking.CreateAndInject("C:\\Program Files (x86)\\PuTTY\\putty.exe", "", (int)InjectionOptions.Default, injectionFile,
                //    injectionFile, out processId, ChannelName, args);

                DoneLaunchingEveInstance = false;
                StartsPast24H++;
                LastQuestorSessionReady = DateTime.UtcNow;

                if (processId != -1 && processId != 0)
                {
                    AmountExceptionsCurrentSession = 0;
                    Pid = processId;
                    LastStartTime = DateTime.UtcNow;
                    Info = string.Empty;
                    DirectEventHandler.ClearEvents(CharacterName);
                    CharnameByPid.AddOrUpdate(processId, CharacterName, (key, oldValue) => CharacterName);
                }
                else
                {
                    Cache.Instance.Log("ProcessId is zero. Error.");
                }
            }
            catch (Exception e)
            {
                Cache.Instance.Log("Exception: " + e);
            }
        }

        public void StartExecuteable(string filename, string parameters = "")
        {
            string[] args = { CharacterName, WCFServer.Instance.GetPipeName };
            int processId = -1;
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string injectionFile = Path.Combine(path, "DomainHandler.dll");
            string ChannelName = null;
            RemoteHooking.IpcCreateServer<EVESharpInterface>(ref ChannelName, WellKnownObjectMode.SingleCall);

            if (!string.IsNullOrEmpty(filename) && File.Exists(filename))
            {
                RemoteHooking.CreateAndInject(filename, parameters, (int)InjectionOptions.Default, injectionFile, injectionFile, out processId, ChannelName,
                    args);
                return;
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = "c:\\";
            openFileDialog.Filter = "exe files | *.exe";
            openFileDialog.FilterIndex = 2;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
                RemoteHooking.CreateAndInject(openFileDialog.FileName, parameters, (int)InjectionOptions.Default, injectionFile, injectionFile, out processId,
                    ChannelName, args);
        }

        private void CheckEveAccountSettings()
        {
            //
            // Num
            //
            if (Num == 0)
            {
                int i = 0;
                foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                {
                    i++;
                    if (CharacterName == eA.CharacterName)
                    {
                        Num = i;
                        Cache.Instance.Log("Character [" + MaskedCharacterName + "] Num updated to [" + Num + "]");
                    }
                }
            }
        }

        #endregion Methods

        #region pathes

        /* personal folder example */
        // C:\Users\USERNAME\Documents\EVE
        // C:\Users\USERNAME\Documents\

        /* local appdata example */
        // C:\Users\USERNAME\AppData\Local\CCP\EVE\c_eveoffline
        // C:\Users\USERNAME\AppData\Local\

        //		public string GetEveSettingsFolder() {
        //			return "C:\\Users\\";
        //		}

        public EveAccount Clone()
        {
            using (MemoryStream stream = new MemoryStream())
            {
                if (GetType().IsSerializable)
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(stream, this);
                    stream.Position = 0;
                    return (EveAccount)formatter.Deserialize(stream);
                }
                return null;
            }
        }

        public string GetAppDataFolder()
        {
            return "C:\\Users\\" + HWSettings.WindowsUserLogin + "\\AppData\\Local\\";
        }

        public string GetDefaultSettingsFolder()
        {
            return Cache.Instance.AssemblyPath + "\\Resources\\EveSettings\\default\\";
        }

        public string GetEveRootPath()
        {
            return Directory.GetParent(GetEveTQPath()).ToString();
        }

        public string GetEveTQPath()
        {
            return Directory.GetParent(Directory.GetParent(ExeFileFullPath).ToString()).ToString();
        }

        public string GetEveUnderscorePath()
        {
            string eveBasePath = GetEveTQPath();
            eveBasePath = eveBasePath.Replace(":\\", "_");

            if (ConnectToTestServer)
                eveBasePath = eveBasePath.Replace("\\", "_").ToLower() + "_singularity";
            else
                eveBasePath = eveBasePath.Replace("\\", "_").ToLower() + "_tranquility";
            return eveBasePath;
        }

        public string GetPersonalFolder()
        {
            return "C:\\Users\\" + HWSettings.WindowsUserLogin + "\\Documents\\";
        }

        #endregion pathes
    }

    public class EVESharpInterface : MarshalByRefObject
    {
        #region Methods

        public void Ping()
        {
        }

        #endregion Methods
    }
}