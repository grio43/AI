﻿using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;

namespace SharedComponents.Socks5.Socks5Relay
{
    internal class DSocks
    {
        #region Fields

        private const int ver = 5;
        private readonly Socket socket;

        #endregion Fields

        #region Constructors

        public DSocks(string con)
        {
            GroupCollection match = new Regex("^(?:(.*?):(.*?)@)?(.*?)(?::(\\d+))?$").Match(con).Groups;

            xUser = match[1].Success ? match[1].Value : null;
            xPass = match[2].Success ? match[2].Value : null;
            xHost = match[3].Value;
            xPort = match[4].Success ? int.Parse(match[4].Value) : 1080;
        }

        public DSocks(Socket sock)
        {
            socket = sock;
        }

        public DSocks(DSocks mommy, Socket daddy)
        {
            xUser = mommy.xUser;
            xPass = mommy.xPass;
            xHost = mommy.xHost;
            xPort = mommy.xPort;
            socket = daddy;
        }

        #endregion Constructors

        #region Properties

        public string domain { private set; get; }
        public byte[] lastRequest { private set; get; }
        public int port { private set; get; }
        public int status { private set; get; }
        public string xHost { get; }
        public string xPass { get; }
        public int xPort { get; }
        public string xUser { get; }

        #endregion Properties

        #region Methods

        public bool ClientConnect(string domain, int port)
        {
            Write(new byte[] { ver, 1, 0, 3, (byte)domain.Length });
            Write(Encoding.ASCII.GetBytes(domain));
            Write(new[] { (byte)(port >> 8), (byte)(port & 255) });

            if (!ParseRequest() || status != 0)
                return false;

            return true;
        }

        public bool ClientInit(Socket sock)
        {
            if (xUser != null && xPass != null)
            {
                Write(new byte[] { ver, 1, 2 });
                byte[] buf = Read(2);

                if (buf == null || buf[0] != 5 || buf[1] != 2)
                    return false;

                Write(new byte[] { 1, (byte)xUser.Length });
                Write(Encoding.ASCII.GetBytes(xUser));
                Write(new[] { (byte)xPass.Length });
                Write(Encoding.ASCII.GetBytes(xPass));
            }
            else
            {
                Write(new byte[] { ver, 1, 0 });
            }

            return ParseInitReply();
        }

        public Socket Connect()
        {
            if (xHost == null)
                return null;

            return new TcpClient(xHost, xPort).Client;
        }

        public bool ParseRequest()
        {
            List<byte> body = new List<byte>();

            byte[] buf = Read(4);
            if (buf == null || buf[0] != ver)
                return false;

            body.AddRange(buf);

            status = buf[1];

            switch (buf[3])
            {
                case 1:
                    // dummy
                    buf = Read(4);
                    body.AddRange(buf);
                    break;

                case 3:
                    domain = ReadDNS(ref body);
                    if (domain == "")
                        return false;
                    break;

                case 4:
                    // dummy
                    buf = Read(16);
                    body.AddRange(buf);
                    break;
            }

            port = ReadPort(ref body);
            if (port == -1)
                return false;

            lastRequest = body.ToArray();
            return true;
        }

        public bool ServerInit()
        {
            byte[] buf = Read(3);
            Write(new byte[] { ver, 0 });

            return true;
        }

        public bool ServerReply(int status)
        {
            try
            {
                Write(new byte[] { ver, (byte)status, 0, 1, 0, 0, 0, 0, 0, 0 });
            }
            catch
            {
                return false;
            }

            return true;
        }

        private bool ParseInitReply()
        {
            byte[] buf = Read(2);
            if (buf != null && buf[1] == 0)
                return true;

            return false;
        }

        private byte[] Read(int len)
        {
            byte[] buf = new byte[len];
            try
            {
                socket.Receive(buf, len, SocketFlags.None);
            }
            catch
            {
                return null;
            }
            return buf;
        }

        private string ReadDNS(ref List<byte> rq)
        {
            try
            {
                byte[] len = Read(1);
                rq.Add(len[0]);
                byte[] buf = Read(len[0]);
                rq.AddRange(buf);
                return Encoding.ASCII.GetString(buf);
            }
            catch
            {
            }

            return "";
        }

        private int ReadPort(ref List<byte> rq)
        {
            byte[] buf = Read(2);
            rq.AddRange(buf);
            return buf == null ? -1 : (buf[0] << 8) | buf[1];
        }

        private void Write(byte[] buf)
        {
            try
            {
                socket.Send(buf);
            }
            catch
            {
            }
        }

        #endregion Methods
    }
}