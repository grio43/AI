﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.States;
using SC::SharedComponents.EVE.ClientSettings;

namespace EVESharpCore.Questor.Combat
{
    public static partial class Combat
    {
        #region Fields

        private static int _findAmmoAttempts;

        private static DateTime _lastFindAmmoAttempt = DateTime.UtcNow.AddHours(-1);

        private static DateTime _lastReloadAllIteration = DateTime.UtcNow;

        private static DateTime _lastReloadIteration = DateTime.UtcNow;

        private static EntityCache EntityToUseForAmmo { get; set; }

        #endregion Fields

        #region Properties

        public static bool OutOfAmmo
        {
            get
            {
                if (ESCache.Instance.ActiveShip == null)
                    return false;

                if (ESCache.Instance.ActiveShip.GroupId == (int)Group.Shuttle)
                    return false;

                if (ESCache.Instance.ActiveShip.GroupId == (int)Group.Industrial)
                    return false;

                if (ESCache.Instance.ActiveShip.GroupId == (int)Group.TransportShip)
                    return false;

                if (ESCache.Instance.ActiveShip.GroupId == (int)Group.Capsule)
                    return false;

                if (!ESCache.Instance.Weapons.Any())
                    return false;

                if (ESCache.Instance.Weapons.All(i => i.TypeId == (int)TypeID.CivilianGatlingAutocannon))
                    return false;

                if (ESCache.Instance.Weapons.All(i => i.TypeId == (int)TypeID.CivilianGatlingPulseLaser))
                    return false;

                if (ESCache.Instance.Weapons.All(i => i.TypeId == (int)TypeID.CivilianGatlingRailgun))
                    return false;

                if (ESCache.Instance.Weapons.All(i => i.TypeId == (int)TypeID.CivilianLightElectronBlaster))
                    return false;

                if (ESCache.Instance.CurrentShipsCargo == null)
                    return false;

                if (ESCache.Instance.CurrentShipsCargo.Items == null)
                    return false;

                if (DirectModule.DefinedAmmoTypes != null && DirectModule.DefinedAmmoTypes.Any())
                {
                    if (ESCache.Instance.CurrentShipsCargo.Items.Any())
                    {
                        foreach (AmmoType IndividualAmmo in DirectModule.DefinedAmmoTypes)
                            if (ESCache.Instance.CurrentShipsCargo.Items.Where(i => i.TypeId == IndividualAmmo.TypeId).Sum(i => i.Stacksize) > 50)
                                return false;

                        return true;
                    }

                    return true;
                }

                return false;
            }
        }

        private static List<AmmoType> correctAmmoTypeInCargo
        {
            get
            {
                try
                {
                    if (correctAmmoTypeToUse == null || !correctAmmoTypeToUse.Any())
                    {
                        if (DebugConfig.DebugCorrectAmmoTypeInCargo) Log.WriteLine("correctAmmoTypeInCargo: if (correctAmmoTypeToUse == null || !correctAmmoTypeToUse.Any())");
                        return null;
                    }

                    if (ESCache.Instance.CurrentShipsCargo != null)
                    {
                        //
                        // Look for the correct ammo for this mission
                        //

                        if (ESCache.Instance.CurrentShipsCargo == null)
                            return null;

                        if (ESCache.Instance.CurrentShipsCargo.Items == null)
                            return null;

                        List<AmmoType> tempCorrectAmmoTypesInCargo;
                        List<DirectItem> MatchingItems = null;
                        try
                        {
                            MatchingItems = ESCache.Instance.CurrentShipsCargo.Items.Where(i => DirectModule.DefinedAmmoTypes.Any(j => j.TypeId == i.TypeId && j.DamageType == MissionSettings.CurrentDamageType && j.Range > EntityToUseForAmmo.Distance)).OrderBy(x => x.OptimalRange).ToList();
                        }
                        catch (Exception)
                        {
                        }

                        if (MatchingItems != null)
                            tempCorrectAmmoTypesInCargo = correctAmmoTypeToUse.OrderByDescending(a => MatchingItems.Any(x => x.TypeId == a.TypeId)).ToList();
                        else
                            tempCorrectAmmoTypesInCargo = correctAmmoTypeToUse.ToList();

                        if (tempCorrectAmmoTypesInCargo.Any())
                            return tempCorrectAmmoTypesInCargo;

                        //
                        // Look for any valid ammo in our cargo
                        //
                        tempCorrectAmmoTypesInCargo = DirectModule.DefinedAmmoTypes.ToList().OrderByDescending(a => ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.Items.ToList().Any(c => c.TypeId == a.TypeId && c.Quantity >= MinimumAmmoCharges)).ToList();
                        if (tempCorrectAmmoTypesInCargo.Any())
                        {
                            int num = 0;
                            foreach (var tempCorrectAmmoTypeInCargo in tempCorrectAmmoTypesInCargo)
                            {
                                num++;
                                if (DebugConfig.DebugCorrectAmmoTypeInCargo) Log.WriteLine("CorrectAmmoTypeInCargo: [" + num + "][" + tempCorrectAmmoTypeInCargo.Description + "][" + tempCorrectAmmoTypeInCargo.TypeId + "][" + tempCorrectAmmoTypeInCargo.DamageType + "][" + tempCorrectAmmoTypeInCargo.Range + "]");
                            }
                            return tempCorrectAmmoTypesInCargo;
                        }
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        private static List<AmmoType> correctAmmoTypeToUse
        {
            get
            {
                try
                {
                    if (DirectModule.DefinedAmmoTypes == null)
                    {
                        if (DebugConfig.DebugReloadAll) Log.WriteLine("correctAmmoTypeToUse: if (DefinedAmmoTypes == null)");
                        return null;
                    }

                    if (!DirectModule.DefinedAmmoTypes.Any())
                    {
                        if (DebugConfig.DebugReloadAll) Log.WriteLine("correctAmmoTypeToUse: if (!DefinedAmmoTypes.Any())");
                        return null;
                    }

                    double targetDistance = 10000;
                    string targetName = "unknown";
                    if (EntityToUseForAmmo != null)
                    {
                        targetDistance = Math.Round(EntityToUseForAmmo.Distance/ 1000, 0);
                        targetName = EntityToUseForAmmo.Name;
                    }

                    List<AmmoType> tempCorrectAmmoTypesToUse = DirectModule.DefinedAmmoTypes.Where(a => a.Range > targetDistance).OrderByDescending(a => MissionSettings.CurrentDamageType != null && a.DamageType == MissionSettings.CurrentDamageType).ThenBy(a => a.Range).ToList();
                    if (tempCorrectAmmoTypesToUse.Any())
                    {
                        int num = 0;
                        foreach (var tempCorrectAmmoTypeToUse in tempCorrectAmmoTypesToUse)
                        {
                            num++;
                            if (DebugConfig.DebugCorrectAmmoTypeToUse) Log.WriteLine("CorrectAmmoTypeToUse [" + num + "][" + tempCorrectAmmoTypeToUse.Description + "][" + tempCorrectAmmoTypeToUse.TypeId + "][" + tempCorrectAmmoTypeToUse.DamageType + "] MaxRange [" + tempCorrectAmmoTypeToUse.Range + "] targetName [" + targetName + "] targetDistance [" + targetDistance + "k away]");
                        }

                        return tempCorrectAmmoTypesToUse;
                    }

                    if (DebugConfig.DebugCorrectAmmoTypeToUse) Log.WriteLine("Error. [ DefinedAmmoTypes.Where(a => a.DamageType == MissionSettings.CurrentDamageType).ToList(); ] resulted in null");
                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        private static AmmoType correctAmmoTypeToUseByRange
        {
            get
            {
                try
                {
                    AmmoType tempAmmo;
                    if (correctAmmoTypeInCargo == null || !correctAmmoTypeInCargo.Any())
                    {
                        if (DebugConfig.DebugCorrectAmmoTypeToUseByRange) Log.WriteLine("correctAmmoTypeToUseByRange: if (correctAmmoTypeInCargo == null || !correctAmmoTypeInCargo.Any())");
                        return null;
                    }

                    if (EntityToUseForAmmo != null)
                    {
                        tempAmmo = correctAmmoTypeInCargo.Where(a => a.Range > EntityToUseForAmmo.Distance).OrderBy(a => a.Range).FirstOrDefault();
                        if (tempAmmo != null)
                        {
                            if (DebugConfig.DebugCorrectAmmoTypeToUseByRange) Log.WriteLine("correctAmmoTypeToUseByRange [" + tempAmmo.Description + "][" + tempAmmo.TypeId + "][" + tempAmmo.DamageType + "] MaxRange [" + tempAmmo.Range + "][" + EntityToUseForAmmo.Name + "][" + Math.Round(EntityToUseForAmmo.Distance/1000, 0) + "k away]");
                            return tempAmmo;
                    	}

                        return null;
                    }

                    tempAmmo = correctAmmoTypeInCargo.FirstOrDefault();
                    if (tempAmmo != null)
                    {
                        if (DebugConfig.DebugCorrectAmmoTypeToUseByRange) Log.WriteLine("correctAmmoTypeToUseByRange: usingFirstAmmoFoundInCargo! [" + tempAmmo.Description + "][" + tempAmmo.TypeId + "][" + tempAmmo.DamageType + "] MaxRange [" + tempAmmo.Range + "][" + EntityToUseForAmmo.Name + "][" + Math.Round(EntityToUseForAmmo.Distance / 1000, 0) + "k away]");
                        return tempAmmo;
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        #endregion Properties

        #region Methods

        //
        // this will change ammo as needed, unlike the in game reload command
        //
        public static bool ReloadAll()
        {
            //const int reloadAllDelay = 30000;

            if (_lastReloadAllIteration.AddSeconds(1) > DateTime.UtcNow)
                return false;

            _lastReloadAllIteration = DateTime.UtcNow;

            //if (DateTime.UtcNow.Subtract(_lastReloadAll).TotalMilliseconds < reloadAllDelay)
            //{
            //    if (DebugConfig.DebugReloadAll) Log.WriteLine("DebugReloadAll: if (DateTime.UtcNow.Subtract(_lastReloadAll).TotalMilliseconds < reloadAllDelay)");
            //    return false;
            //}

            //if (!QCache.Instance.InMission)
            //{
            //    if (DebugConfig.DebugReloadAll) Log.WriteLine("DebugReloadAll: if (!QCache.Instance.InMission)");
            //    return true;
            //}

            if (ESCache.Instance.MyShipEntity.Name == Settings.Instance.TransportShipName)
            {
                if (DebugConfig.DebugReloadAll)
                    Log.WriteLine("You are in your TransportShip named [" + Settings.Instance.TransportShipName + "], no need to reload ammo!");
                return true;
            }

            if (ESCache.Instance.MyShipEntity.Name == Settings.Instance.StorylineTransportShipName)
            {
                if (DebugConfig.DebugReloadAll)
                    Log.WriteLine("You are in your StorylineTransportShip named [" + Settings.Instance.StorylineTransportShipName + "], no need to reload ammo!");
                return true;
            }

            if (ESCache.Instance.MyShipEntity.Name == Settings.Instance.TravelShipName)
            {
                if (DebugConfig.DebugReloadAll)
                    Log.WriteLine("You are in your TravelShipName named [" + Settings.Instance.TravelShipName + "], no need to reload ammo!");
                return true;
            }

            if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.Shuttle)
            {
                if (DebugConfig.DebugReloadAll) Log.WriteLine("You are in a Shuttle, no need to reload ammo!");
                return true;
            }

            if (ESCache.Instance.Weapons.All(i => !i.WeaponNeedsAmmo()))
            {
                if (DebugConfig.DebugReloadAll) Log.WriteLine("Civilian guns do not use ammo.");
                return true;
            }

            _weaponNumber = 0;
            if (DebugConfig.DebugReloadAll && ESCache.Instance.Weapons.All(i => i.GroupId != (int)Group.PrecursorWeapon))
                Log.WriteLine("Weapons (or stacks of weapons?): [" + ESCache.Instance.Weapons.Count() + "]");

            if (ESCache.Instance.InWormHoleSpace)
            {
                //ReloadAllWeaponsWithSameAmmoUsingCmdReloadAmmo();
                //return true;
            }


            if (ESCache.Instance.Weapons.Any())
            {
                foreach (ModuleCache weapon in ESCache.Instance.Weapons)
                {
                    _weaponNumber++;

                    if (Time.Instance.LastReloadAttemptTimeStamp != null && Time.Instance.LastReloadAttemptTimeStamp.ContainsKey(weapon.ItemId))
                        if (DateTime.UtcNow < Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId].AddSeconds(ESCache.Instance.RandomNumber(20, 30)))
                        {
                            if (DebugConfig.DebugReloadAll)
                                Log.WriteLine("Weapon [" + _weaponNumber + "] was just attempted to be reloaded [" +
                                              Math.Round(DateTime.UtcNow.Subtract(Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId]).TotalSeconds,
                                                  0) +
                                              "] seconds ago , moving on to next weapon");
                            continue;
                        }

                    if (Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(weapon.ItemId))
                        if (DateTime.UtcNow < Time.Instance.LastReloadedTimeStamp[weapon.ItemId].AddSeconds(ESCache.Instance.RandomNumber(20, 30)))
                        {
                            if (DebugConfig.DebugReloadAll)
                                Log.WriteLine("Weapon [" + _weaponNumber + "] was just reloaded [" +
                                              Math.Round(DateTime.UtcNow.Subtract(Time.Instance.LastReloadedTimeStamp[weapon.ItemId]).TotalSeconds,
                                                  0) +
                                              "] seconds ago , moving on to next weapon");
                            continue;
                        }

                    if (weapon.IsEnergyWeapon)
                    {
                        if (DebugConfig.DebugReloadAll)
                            Log.WriteLine("if (weapon.IsEnergyWeapon) continue (energy weapons do not need to reload)");
                        continue;
                    }

                    if (weapon.ChargeQty > 5 &&
                        (weapon.GroupId == (int)Group.RapidHeavyMissileLaunchers || weapon.GroupId == (int)Group.RapidLightMissileLaunchers) &&
                        PotentialCombatTargets.Any() &&
                        !ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                    {
                        if (DebugConfig.DebugReloadAll)
                            Log.WriteLine("[" + weapon.TypeName + "][" + _weaponNumber + "] if (weapon.ChargeQty > 10 && weapon.GroupId == Group.RapidHeavyMissileLaunchers && PotentialCombatTargets.Any())");
                        continue;
                    }

                    if (weapon.IsReloadingAmmo)
                    {
                        if (DebugConfig.DebugReloadAll)
                            Log.WriteLine("[" + weapon.TypeName + "][" + _weaponNumber + "] is still reloading, moving on to next weapon");
                        continue;
                    }

                    if (weapon.IsDeactivating)
                    {
                        if (DebugConfig.DebugReloadAll)
                            Log.WriteLine("[" + weapon.TypeName + "][" + _weaponNumber + "] is still Deactivating, moving on to next weapon");
                        continue;
                    }

                    if (weapon.IsActive)
                    {
                        if (DebugConfig.DebugReloadAll)
                            Log.WriteLine("[" + weapon.TypeName + "][" + _weaponNumber + "] is Active, moving on to next weapon");
                        continue;
                    }

                    if (ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.Items.Any())
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("ReloadAll: !OkToInteractWithEveNow");
                            return false;
                        }

                        ReloadAmmo(weapon, ESCache.Instance.MyShipEntity, _weaponNumber);
                        return true;
                    }
                }

                if (DebugConfig.DebugReloadAll) Log.WriteLine("ReloadAll: Reached the end");
                return true;
            }

            return true;
        }

        public static bool ReloadAllWeaponsWithSameAmmoUsingCmdReloadAmmo()
        {
            if (!ESCache.Instance.Weapons.Any()) return true;

            if (ESCache.Instance.Weapons.All(i => i.IsReloadingAmmo || i.IsActive || i.InLimboState)) return true;

            if (ESCache.Instance.Weapons.Any(i => i.Charge == null || i.ChargeQty == 0 || i.ChargeQty < i.MaxCharges))
                ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdReloadAmmo);

            return true;
        }

        public static bool ReloadAmmo(ModuleCache weapon, EntityCache entity, int weaponNumber, bool force = false)
        {
            return weapon.IsEnergyWeapon ? ReloadEnergyWeaponAmmo(weapon, entity, weaponNumber) : ReloadNormalAmmo(weapon, entity, weaponNumber, force);
        }

        private static bool? AreWeOutOfAmmo(EntityCache entity, int weaponNumber)
        {
            EntityToUseForAmmo = entity;

            if (killTarget != null)
                EntityToUseForAmmo = killTarget;

            if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name.Contains("Anomic"))
                return false;

            if (DateTime.UtcNow > _lastFindAmmoAttempt.AddSeconds(30))
                _findAmmoAttempts = 0;

            _lastFindAmmoAttempt = DateTime.UtcNow;
            _findAmmoAttempts++;

            if (_findAmmoAttempts > 40)
            {
                Log.WriteLine("ReloadNormalAmmo:: if (_findAmmoAttempts > 40)");
                State.CurrentCombatState = CombatState.OutOfAmmo;
                return true;
            }

            if (DirectModule.DefinedAmmoTypes.Any(a => a.DamageType == MissionSettings.CurrentDamageType))
            {
                if (correctAmmoTypeToUse == null)
                {
                    Log.WriteLine("ReloadNormalAmmo:: if (correctAmmoToUse == null)");
                    return true;
                }

                if (correctAmmoTypeToUse != null && !correctAmmoTypeToUse.Any())
                {
                    Log.WriteLine("ReloadNormalAmmo:: correctAmmoToUse was empty. MissionSettings.CurrentDamageType [" + MissionSettings.CurrentDamageType + "]");
                    foreach (AmmoType thisAmmo in DirectModule.DefinedAmmoTypes)
                        Log.WriteLine("ReloadNormalAmmo:: AmmoType: [" + thisAmmo.Description + "] TypeId [" + thisAmmo.TypeId + "] DamageType [" + thisAmmo.DamageType + "] Quantity [" + thisAmmo.Quantity + "] Range [" + thisAmmo.Range + "]");
                }

                if (correctAmmoTypeToUse != null && correctAmmoTypeToUse.Any())
                {
                    if (ESCache.Instance.CurrentShipsCargo == null || ESCache.Instance.CurrentShipsCargo.Items == null)
                    {
                        Log.WriteLine("ReloadNormalAmmo:: CurrentShipsCargo == null");
                        return null;
                    }

                    if (ESCache.Instance.CurrentShipsCargo.Items == null)
                    {
                        Log.WriteLine("ReloadNormalAmmo:: CurrentShipsCargo.Items == null");
                        return null;
                    }

                    if (!ESCache.Instance.CurrentShipsCargo.Items.Any())
                    {
                        Log.WriteLine("ReloadNormalAmmo:: !CurrentShipsCargo.Items.Any()");
                        return true;
                    }

                    if (correctAmmoTypeInCargo == null)
                    {
                        Log.WriteLine("ReloadNormalAmmo:: if (correctAmmoInCargo == null)");
                        return true;
                    }

                    if (correctAmmoTypeInCargo != null && !correctAmmoTypeInCargo.Any())
                    {
                        foreach (AmmoType individualCorrectAmmoType in correctAmmoTypeToUse)
                            Log.WriteLine("ReloadNormalAmmo:: missing individualCorrectAmmoType [" + individualCorrectAmmoType.Description + "][" + individualCorrectAmmoType.DamageType + "] Quantity [" + individualCorrectAmmoType.Quantity + "] MinimumAmmoCharges [" + MinimumAmmoCharges + "]");

                        if (MissionSettings.CurrentDamageType.HasValue && MissionSettings.AnyAmmoOfTypeLeft(MissionSettings.CurrentDamageType.Value))
                        {
                            Log.WriteLine($"No charges left in ships cargo, using the remaining charges in the launchers before swapping to the second best damage type.");
                            return true;
                        }

                        Log.WriteLine("ReloadNormalAmmo:: not enough [" + MissionSettings.CurrentDamageType + "] ammo in cargohold: MinimumCharges: [" +
                                      MinimumAmmoCharges +
                                      "] Note: CurrentDamageType [" + MissionSettings.CurrentDamageType + "]");
                        State.CurrentCombatState = CombatState.OutOfAmmo;
                        int itemnum = 0;
                        foreach (DirectItem ammoItem in ESCache.Instance.CurrentShipsCargo.Items.Where(i => i.CategoryId == (int)CategoryID.Charge))
                        {
                            itemnum++;
                            Log.WriteLine("[" + itemnum + "] CargoHoldItem: [" + ammoItem.TypeName + "] TypeId [" + ammoItem.TypeId + "] Quantity [" + ammoItem.Quantity + "]");
                        }

                        return true;
                    }
                }
            }
            else if (ESCache.Instance.CurrentShipsCargo == null)
            {
                Log.WriteLine("ReloadNormalAmmo: if Cache.Instance.CurrentShipsCargo == null");
                State.CurrentCombatState = CombatState.OutOfAmmo;
                return true;
            }

            if (correctAmmoTypeToUseByRange == null)
            {
                if (DebugConfig.DebugReloadAll)
                    Log.WriteLine("ReloadEnergyWeaponAmmo: We do not have any ammo left that can hit [" + entity.Name + "][" + Math.Round(entity.Distance / 1000, 0) + "]!");
                return true;
            }

            _findAmmoAttempts = 0;
            return false;
        }

        private static bool ReloadEnergyWeaponAmmo(ModuleCache weapon, EntityCache entity, int weaponNumber)
        {
            if (_lastReloadIteration.AddSeconds(1) > DateTime.UtcNow)
                return false;

            _lastReloadIteration = DateTime.UtcNow;

            if (Time.Instance.LastReloadAttemptTimeStamp != null && Time.Instance.LastReloadAttemptTimeStamp.ContainsKey(weapon.ItemId))
                if (DateTime.UtcNow < Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId].AddSeconds(ESCache.Instance.RandomNumber(2, 4)))
                {
                    if (DebugConfig.DebugReloadAll)
                        Log.WriteLine("Weapon [" + _weaponNumber + "] was just attempted to be reloaded [" +
                                      Math.Round(DateTime.UtcNow.Subtract(Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId]).TotalSeconds,
                                          0) +
                                      "] seconds ago");
                    return true;
                }

            if (Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(weapon.ItemId))
                if (DateTime.UtcNow < Time.Instance.LastReloadedTimeStamp[weapon.ItemId].AddSeconds(ESCache.Instance.RandomNumber(2, 4)))
                {
                    if (DebugConfig.DebugReloadAll)
                        Log.WriteLine("Weapon [" + _weaponNumber + "] was just reloaded [" +
                                      Math.Round(DateTime.UtcNow.Subtract(Time.Instance.LastReloadedTimeStamp[weapon.ItemId]).TotalSeconds,
                                          0) +
                                      "] seconds ago");
                    return true;
                }

            //if (!QCache.Instance.InMission) return true;
            if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.Any(i => i.TypeId == (int)TypeID.CivilianGatlingAutocannon
                                                  || i.TypeId == (int)TypeID.CivilianGatlingPulseLaser
                                                  || i.TypeId == (int)TypeID.CivilianGatlingRailgun
                                                  || i.TypeId == (int)TypeID.CivilianLightElectronBlaster))
                return true;

            IEnumerable<AmmoType> correctAmmo = DirectModule.DefinedAmmoTypes.Where(a => a.DamageType == MissionSettings.CurrentDamageType && a.Range > entity.Distance).ToList();

            IEnumerable<AmmoType> correctAmmoInCargo =
                correctAmmo.Where(a => ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.Items.Any(e => e.TypeId == a.TypeId))
                    .ToList();

            correctAmmoInCargo =
                correctAmmoInCargo.Where(
                        a =>
                            ESCache.Instance.CurrentShipsCargo != null &&
                            ESCache.Instance.CurrentShipsCargo.Items.Any(e => e.TypeId == a.TypeId && e.Quantity >= MinimumAmmoCharges))
                    .ToList();

            if (!correctAmmoInCargo.Any())
                if (MissionSettings.CurrentDamageType.HasValue && MissionSettings.AnyAmmoOfTypeLeft(MissionSettings.CurrentDamageType.Value))
                {
                    Log.WriteLine($"No charges left in ships cargo, using the remaining charges in the launchers before swapping to the second best damage type.");
                    return true;
                }
                else
                {
                    Log.WriteLine("ReloadEnergyWeapon: not enough [" + MissionSettings.CurrentDamageType + "] ammo in cargohold: MinimumCharges: [" +
                                  MinimumAmmoCharges + "]");
                    State.CurrentCombatState = CombatState.OutOfAmmo;
                    return false;
                }

            if (weapon.Charge != null)
            {
                IEnumerable<AmmoType> areWeMissingAmmo = correctAmmoInCargo.Where(a => a.TypeId == weapon.Charge.TypeId);
                if (!areWeMissingAmmo.Any())
                    Log.WriteLine("ReloadEnergyWeaponAmmo: We have ammo loaded that does not have a full reload available in the cargo.");
            }

            AmmoType ammoToUseToReload = correctAmmoInCargo.Where(a => a.Range > entity.Distance).OrderBy(a => a.Range).FirstOrDefault();

            if (ammoToUseToReload == null)
            {
                if (DebugConfig.DebugReloadorChangeAmmo)
                    Log.WriteLine("ReloadEnergyWeaponAmmo: best possible ammo: [ ammo == null]");
                return false;
            }

            if (DebugConfig.DebugReloadorChangeAmmo)
                Log.WriteLine("ReloadEnergyWeaponAmmo: best possible ammo: [" + ammoToUseToReload.TypeId + "][" + ammoToUseToReload.DamageType + "]");
            if (DebugConfig.DebugReloadorChangeAmmo)
                Log.WriteLine("ReloadEnergyWeaponAmmo: best possible ammo: [" + entity.Name + "][" + Math.Round(entity.Distance / 1000, 0) + "]");

            DirectItem charge = ESCache.Instance.CurrentShipsCargo.Items.OrderBy(e => e.Quantity).FirstOrDefault(e => e.TypeId == ammoToUseToReload.TypeId);

            if (charge == null)
            {
                if (DebugConfig.DebugReloadorChangeAmmo)
                    Log.WriteLine("ReloadEnergyWeaponAmmo: We do not have any ammo left that can hit [" + entity.Name + "][" + Math.Round(entity.Distance/1000, 0) + "]!");
                return false;
            }

            if (DebugConfig.DebugReloadorChangeAmmo)
                Log.WriteLine("ReloadEnergyWeaponAmmo: charge: [" + charge.TypeName + "][" + charge.TypeId + "]");

            if (weapon.Charge != null && weapon.Charge.TypeId == ammoToUseToReload.TypeId)
            {
                if (DebugConfig.DebugReloadorChangeAmmo)
                    Log.WriteLine("ReloadEnergyWeaponAmmo: We have DefinedAmmoTypes of that type Loaded Already");
                return true;
            }

            if (weapon.IsReloadingAmmo)
                return true;

            if (weapon.Charge != null && weapon.Charge.TypeId == charge.TypeId)
            {
                //
                // no need to change ammo if its the same type: lasers last a very long time before getting damage / being destroyed
                //
                return true;
            }

            //
            // if the weapon is active and the ammo type we want to use is different than what is in the gun (see above) deactivate the weapon
            //
            if (weapon.IsActive)
            {
                weapon.Click();
                return false;
            }

            if (weapon.ChangeAmmo(charge, weaponNumber, ammoToUseToReload.Range, entity))
                return true;

            return false;
        }

        private static bool ReloadNormalAmmo(ModuleCache weapon, EntityCache entity, int weaponNumber, bool force = false)
        {
            if (DebugConfig.DebugReloadAll) Log.WriteLine("ReloadNormalAmmo [" + weapon.TypeName + "][" + entity.Name + "][" + weaponNumber + "][" + force + "]");
            EntityToUseForAmmo = entity;

            if (killTarget != null)
                EntityToUseForAmmo = killTarget;

            if (_lastReloadIteration.AddSeconds(1) > DateTime.UtcNow)
            {
                if (DebugConfig.DebugReloadAll) Log.WriteLine("ReloadNormalAmmo: waiting");
                return false;
            }

            _lastReloadIteration = DateTime.UtcNow;

            //if (State.CurrentHydraState != HydraState.Combat && State.CurrentHydraState != HydraState.Leader)
            //    if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name != null && MissionSettings.MyMission.Name.Contains("Anomic"))
            //        return true;

            if (Time.Instance.LastReloadAttemptTimeStamp != null && Time.Instance.LastReloadAttemptTimeStamp.ContainsKey(weapon.ItemId))
                if (DateTime.UtcNow < Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId].AddSeconds(ESCache.Instance.RandomNumber(20, 30)))
                {
                    if (DebugConfig.DebugReloadAll)
                        Log.WriteLine("Weapon [" + _weaponNumber + "] was just attempted to be reloaded [" +
                                      Math.Round(DateTime.UtcNow.Subtract(Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId]).TotalSeconds,
                                          0) +
                                      "] seconds ago");
                    return true;
                }

            if (Time.Instance.LastReloadedTimeStamp != null && Time.Instance.LastReloadedTimeStamp.ContainsKey(weapon.ItemId))
                if (DateTime.UtcNow < Time.Instance.LastReloadedTimeStamp[weapon.ItemId].AddSeconds(ESCache.Instance.RandomNumber(20, 30)))
                {
                    if (DebugConfig.DebugReloadAll)
                        Log.WriteLine("Weapon [" + _weaponNumber + "] was just reloaded [" +
                                      Math.Round(DateTime.UtcNow.Subtract(Time.Instance.LastReloadedTimeStamp[weapon.ItemId]).TotalSeconds,
                                          0) +
                                      "] seconds ago");
                    return true;
                }

            //if (!QCache.Instance.InMission) return true;
            if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.Any(i => i.TypeId == (int)TypeID.CivilianGatlingAutocannon
                                                  || i.TypeId == (int)TypeID.CivilianGatlingPulseLaser
                                                  || i.TypeId == (int)TypeID.CivilianGatlingRailgun
                                                  || i.TypeId == (int)TypeID.CivilianLightElectronBlaster))
            {
                if (DebugConfig.DebugReloadAll) Log.WriteLine("ReloadNormalAmmo: Civilian weapons do not use ammo: and thus do not reload");
                return true;
            }

            if (entity == null)
                entity = ESCache.Instance.MyShipEntity;

            bool? areWeOutOfAmmoBool = AreWeOutOfAmmo(ESCache.Instance.MyShipEntity, weaponNumber);

            if (areWeOutOfAmmoBool == null)
                return false;
            if ((bool)areWeOutOfAmmoBool)
            {
                State.CurrentCombatState = CombatState.OutOfAmmo;
                if (DebugConfig.DebugReloadAll) Log.WriteLine("ReloadNormalAmmo: OutOfAmmo");
                return true;
            }

            //
            // if we made it this far we are not out of ammo.
            //

            if (weapon == null)
            {
                if (DebugConfig.DebugReloadAll) Log.WriteLine("weapon == null");
                return true;
            }

            /**
            if (weapon.GroupId == (int)Group.PrecursorWeapon)
                if (DateTime.UtcNow > Time.Instance.LastWeaponUnloadToCargo.AddSeconds(45))
                    if (weapon._module.UnloadToCargo())
                    {
                        Time.Instance.LastWeaponUnloadToCargo = DateTime.UtcNow;
                        return false;
                    }
            **/

            if (correctAmmoTypeToUseByRange == null)
            {
                if (DebugConfig.DebugCorrectAmmoTypeToUseByRange || DebugConfig.DebugReloadorChangeAmmo | DebugConfig.DebugReloadAll) Log.WriteLine("ReloadNormalAmmo: if (correctAmmoTypeToUseByRange == null) return true");
                return true;
            }

            if (DebugConfig.DebugReloadAll)
            {
                Log.WriteLine("DefinedAmmoTypes are currently:");
                int intAmmoType = 0;
                foreach (var definedAmmoType in DirectModule.DefinedAmmoTypes)
                {
                    intAmmoType++;
                    Log.WriteLine("[" + intAmmoType + "][" + definedAmmoType.Description + "][" + definedAmmoType.TypeId + "][" + definedAmmoType.Range + "][" + definedAmmoType.DamageType + "]");
                }
            }

            if (weapon.Charge != null && (long)weapon.ChargeQty >= MinimumAmmoCharges && weapon.Charge.TypeId == correctAmmoTypeToUseByRange.TypeId)
            {
                if (!force)
                {
                    if (DebugConfig.DebugReloadAll)
                        Log.WriteLine("[" + weaponNumber + "] MaxRange [ " + weapon.MaxRange + " ] if we have 0 charges MaxRange will be 0");
                    Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId] = DateTime.UtcNow;
                    return true;
                }

                if (DebugConfig.DebugReloadAll)
                    Log.WriteLine("[" + weaponNumber + "] MaxRange [ " + weapon.MaxRange + " ] if we have 0 charges MaxRange will be 0");
                Time.Instance.LastReloadAttemptTimeStamp[weapon.ItemId] = DateTime.UtcNow;
            }

            DirectItem chargeToLoadIntoWeapon = null;
            if (ESCache.Instance.CurrentShipsCargo != null)
            {
                if (ESCache.Instance.CurrentShipsCargo.Items.Any())
                {
                    chargeToLoadIntoWeapon = ESCache.Instance.CurrentShipsCargo.Items.FirstOrDefault(e => e.TypeId == correctAmmoTypeToUseByRange.TypeId && e.Quantity >= MinimumAmmoCharges);
                    if (chargeToLoadIntoWeapon == null)
                    {
                        if (DebugConfig.DebugReloadAll)
                            Log.WriteLine("We have no ammo matching typeID [" + correctAmmoTypeToUseByRange.TypeId + "] in cargo?! This should have shown up as out of ammo. Note: MinimumAmmoCharges [" + MinimumAmmoCharges + "]");
                        return true;
                    }
                }
                else
                {
                    if (DebugConfig.DebugReloadAll)
                        Log.WriteLine("We have no items in cargo at all?! This should have shown up as out of ammo");
                    return true;
                }
            }
            else
            {
                if (DebugConfig.DebugReloadAll) Log.WriteLine("CurrentShipsCargo is null?!");
                return true;
            }

            if (weapon.IsReloadingAmmo)
            {
                if (DebugConfig.DebugReloadAll)
                    Log.WriteLine("We are already reloading, wait - weapon.IsReloadingAmmo [" + weapon.IsReloadingAmmo + "]");
                return false;
            }

            try
            {
                if (weapon.Charge != null && DirectModule.DefinedAmmoTypes.Any() && DirectModule.DefinedAmmoTypes.All(i => i.TypeId != weapon.Charge.TypeId) && DirectModule.DefinedAmmoTypes.Any(i => i.TypeId == correctAmmoTypeToUseByRange.TypeId))
                {
                    Log.WriteLine("ReloadNormalAmmo: We have [" + weapon.Charge.TypeName + "] in the gun which is not a defined ammo type currently: change ammo to [" + correctAmmoTypeToUseByRange.Description + "]");
                    if (entity != null && weapon.ChangeAmmo(chargeToLoadIntoWeapon, weaponNumber, correctAmmoTypeToUseByRange.Range, entity))
                        return true;

                    return true;
                }

                if (weapon.Charge != null && weapon.Charge.TypeId == chargeToLoadIntoWeapon.TypeId)
                {
                    if (weapon.ReloadAmmo(chargeToLoadIntoWeapon, weaponNumber, correctAmmoTypeToUseByRange.Range))
                        return true;

                    Log.WriteLine("ReloadAmmo for [" + weapon.ItemId + "] failed.");
                    return true;
                }

                if (entity != null && weapon.ChangeAmmo(chargeToLoadIntoWeapon, weaponNumber, correctAmmoTypeToUseByRange.Range, entity))
                    return true;

                Log.WriteLine("ChangeAmmo for [" + weapon.ItemId + "] failed.");
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }

            return true;
        }

        #endregion Methods
    }
}