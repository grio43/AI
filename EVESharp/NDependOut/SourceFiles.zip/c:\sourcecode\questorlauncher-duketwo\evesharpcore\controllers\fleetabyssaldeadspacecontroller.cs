﻿/*
 * Created by SharpDevelop.
 * User: duketwo
 * Date: 28.05.2016
 * Time: 18:07
 *
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

extern alias SC;

using EVESharpCore.Cache;
using EVESharpCore.Controllers.Base;
using EVESharpCore.Framework;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Stats;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;
using System;

namespace EVESharpCore.Controllers
{
    public class FleetAbyssalDeadspaceController : BaseController
    {
        #region Constructors

        public FleetAbyssalDeadspaceController()
        {
            IgnorePause = false;
            IgnoreModal = false;
            Time.Instance.NextStartupAction = DateTime.UtcNow;
            Time.Instance.QuestorStarted_DateTime = DateTime.UtcNow;
            Settings.Instance.CharacterMode = "none";
            FleetAbyssalDeadspaceBehaviorInstance = new AbyssalDeadspaceBehavior();
        }

        #endregion Constructors

        #region Properties

        private AbyssalDeadspaceBehavior FleetAbyssalDeadspaceBehaviorInstance { get; }
        private bool RunOnceAfterStartupalreadyProcessed { get; set; }

        #endregion Properties

        #region Methods

        public static void ProcessState()
        {
            try
            {
                // Abyssal Deadspace Behavior
                AbyssalDeadspaceBehavior.Fleet_ProcessState();
            }
            catch (Exception ex)
            {
                Log("Exception [" + ex + "]");
            }
        }

        public override void DoWork()
        {
            try
            {
                if (!Settings.Instance.DefaultSettingsLoaded)
                {
                    if (DebugConfig.DebugCombatMissionsBehavior) Log("AbyssalDeadspaceController: Loading Settings");
                    Settings.Instance.LoadSettings();
                }

                if (!RunOnceAfterStartupalreadyProcessed &&
                    ESCache.Instance.DirectEve.Session.CharacterId != null && ESCache.Instance.DirectEve.Session.CharacterId > 0)
                    if (Settings.CharacterXMLExists && DateTime.UtcNow > Time.Instance.NextStartupAction)
                    {
                        try
                        {
                            if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                            {
                                if (DebugConfig.DebugInteractWithEve) Log("AbyssalDeadspaceController: RunOnce: OpenCargoHold: !OkToInteractWithEveNow");
                                return;
                            }

                            if (DebugConfig.DebugCombatMissionsBehavior) Log("AbyssalDeadspaceController: RunOnce");
                            ESCache.Instance.IterateShipTargetValues("RunOnceAfterStartup");
                            ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenCargoHoldOfActiveShip);
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        }
                        catch (Exception ex)
                        {
                            Log("Exception [" + ex + "]");
                        }

                        RunOnceAfterStartupalreadyProcessed = true;
                    }
                    else
                    {
                        Log("Settings.Instance.CharacterName is still null");
                        Time.Instance.NextStartupAction = DateTime.UtcNow.AddSeconds(10);
                        RunOnceAfterStartupalreadyProcessed = false;
                        return;
                    }

                if (DateTime.UtcNow.Subtract(Time.Instance.LastUpdateOfSessionRunningTime).TotalSeconds <
                    Time.Instance.SessionRunningTimeUpdate_seconds)
                {
                    Statistics.SessionRunningTime =
                        (int)DateTime.UtcNow.Subtract(Time.Instance.QuestorStarted_DateTime).TotalMinutes;
                    Time.Instance.LastUpdateOfSessionRunningTime = DateTime.UtcNow;
                }

                if (ESCache.Instance.InWarp)
                {
                    if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log("AbyssalDeadspaceController: if (QCache.Instance.InWarp)");
                    return;
                }

                if (ESCache.Instance.InStation && ESCache.Instance.PauseAfterNextDock)
                {
                    if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log("AbyssalDeadspaceController: if (QCache.Instance.InStation && QCache.Instance.PauseAfterNextDock)");
                    ControllerManager.Instance.SetPause(true);
                    ESCache.Instance.PauseAfterNextDock = false;
                    return;
                }

                ProcessState();
            }
            catch (Exception ex)
            {
                Log("Exception [" + ex + "]");
            }
        }

        public override bool EvaluateDependencies(ControllerManager cm)
        {
            return true;
        }

        #endregion Methods
    }
}