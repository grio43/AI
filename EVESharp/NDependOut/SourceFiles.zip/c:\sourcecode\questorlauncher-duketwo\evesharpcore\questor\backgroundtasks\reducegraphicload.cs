﻿using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using System;

namespace EVESharpCore.Questor.BackgroundTasks
{
    public class ReduceGraphicLoad
    {
        #region Fields

        private static int zoomOutIterations;

        #endregion Fields

        #region Properties

        public static bool ZoomLevelAlreadyProcessed { get; set; } = true;
        public static bool IsPaused { get; set; }

        #endregion Properties

        #region Methods

        public static void ClearPerPocketCache()
        {
            ClearPerSystemCache();
        }

        public static void ClearPerSystemCache()
        {
            ZoomLevelAlreadyProcessed = false;
            zoomOutIterations = 0;
        }

        public static void ProcessState()
        {
            if (DebugConfig.DebugReduceGraphicsController) Log.WriteLine("ReduceGraphicsLoad: ProcessState()");
            if (!ESCache.Instance.DirectEve.Session.IsReady)
                return;

            //
            // Graphics related changes / optimizations should processed while in space and in station!
            //
            if (ESCache.Instance.InSpace || ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugReduceGraphicsController) Log.WriteLine("ReduceGraphicsLoad: if (ESCache.Instance.InSpace || ESCache.Instance.InStation)");
                //
                // if paused enabled 3d, otherwise set 3d based on the state of the Disable3D setting
                //
                if (ESCache.Instance.EveAccount.ManuallyPausedViaUI && IsPaused)
                {
                    if (DebugConfig.DebugReduceGraphicsController) Log.WriteLine("ReduceGraphicsLoad: Paused");
                    if (ESCache.Instance.DirectEve.Rendering3D == false)
                    {
                        Log.WriteLine("ReduceGraphicsLoad: Paused: Enable 3D");
                        ESCache.Instance.DirectEve.Rendering3D = true;
                        return;
                    }

                    return;
                }

                if (ESCache.Instance.DirectEve.Rendering3D != !Settings.Instance.Disable3D)
                {
                    //true(on) != false(disable3d)
                    Log.WriteLine("ReduceGraphicsLoad: Disable3d");
                    ESCache.Instance.DirectEve.Rendering3D = !Settings.Instance.Disable3D;
                    return;
                }
            }

            if (ESCache.Instance.InSpace)
            {

                if (!ZoomLevelAlreadyProcessed &&
                    DateTime.UtcNow > Time.Instance.LastDockAction.AddSeconds(10) &&
                    DateTime.UtcNow > Time.Instance.LastJumpAction.AddSeconds(10) &&
                    DateTime.UtcNow > Time.Instance.NextStartupAction)
                    try
                    {
                        //
                        // if a station is on grid dont bother to zoom out as the camera will reset when we warp away
                        //
                        if (ESCache.Instance.ClosestStation != null && ESCache.Instance.ClosestStation.Distance < (double)Distances.OnGridWithMe)
                            return;

                        if (ESCache.Instance.ClosestStargate != null && ESCache.Instance.ClosestStargate.Distance < 10000)
                            return;

                        if (ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdZoomOut))
                        {
                            if (zoomOutIterations > 17)
                                ZoomLevelAlreadyProcessed = true;

                            zoomOutIterations++;
                            Time.Instance.NextStartupAction = DateTime.UtcNow.AddSeconds(2);
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLine("Exception [" + ex + "]");
                    }
            }
        }

        #endregion Methods
    }
}