﻿using System;

namespace SharedComponents.EVE.ClientSettings.Pinata.Main
{
    [Serializable]
    public class PinataMainSetting
    {
        #region Properties

        public Region Region { get; set; }

        #endregion Properties
    }
}