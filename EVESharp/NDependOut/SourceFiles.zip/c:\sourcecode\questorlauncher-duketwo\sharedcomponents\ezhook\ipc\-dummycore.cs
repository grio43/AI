﻿using System.Diagnostics;

namespace EasyHook.IPC
{
    /// <summary>
    ///     Represents EasyHook's (future) CoreClass/DomainManager/...
    /// </summary>
    public static class DummyCore
    {
        #region Constructors

        static DummyCore()
        {
            ConnectionManager = new ConnectionManager();
        }

        #endregion Constructors

        #region Properties

        public static ConnectionManager ConnectionManager { get; set; }

        #endregion Properties

        #region Methods

        public static void InitializeAsRemoteProcess(string channelUrl)
        {
            ConnectionManager.ConnectInterDomainConnection(channelUrl);
        }

        public static void StartRemoteProcess(string exe)
        {
            string channelUrl = ConnectionManager.InitializeInterDomainConnection();
            Process.Start(exe, channelUrl);
        }

        #endregion Methods
    }
}