﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 19.05.2018
 * Time: 14:20
 *
 * ---------------------------------------
 */

using EasyHook;
using SharedComponents.Py;
using SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace HookManager.Win32Hooks
{
    //BOOL WINAPI CryptEncrypt(
    //    _In_ HCRYPTKEY  hKey,
    //_In_ HCRYPTHASH hHash,
    //_In_ BOOL       Final,
    //_In_ DWORD      dwFlags,
    //_Inout_ BYTE       *pbData,
    //_Inout_ DWORD      *pdwDataLen,
    //_In_ DWORD      dwBufLen
    //);

    /// <summary>
    ///     Description of CryptEncryptController.
    /// </summary>
    public class CryptEncryptController : IDisposable, IHook
    {
        #region Delegates

        [UnmanagedFunctionPointer(CallingConvention.Winapi)]
        public delegate bool CryptEncryptDelegate(IntPtr hKey, IntPtr hHash, int Final, uint dwFlags, [In] [Out] IntPtr pbData, [In] [Out] IntPtr pdwDataLen, uint dwBufLen);

        #endregion Delegates

        #region Constructors

        public CryptEncryptController()
        {
            Name = typeof(CryptEncryptController).Name;
            try
            {
                _name = string.Format("CryptEncrypt{0:X}", LocalHook.GetProcAddress("advapi32.dll", "CryptEncrypt"));
                _hook = LocalHook.Create(LocalHook.GetProcAddress("advapi32.dll", "CryptEncrypt"), new CryptEncryptDelegate(CryptEncryptDetour), this);
                _hook.ThreadACL.SetExclusiveACL(new int[] { });
            }
            catch (Exception)
            {
                Error = true;
            }
        }

        #endregion Constructors

        #region Fields

        public const byte ZlibHeader = 0x78;

        private LocalHook _hook;

        private string _name;

        #endregion Fields

        #region Properties

        public bool Error { get; set; }

        public string Name { get; set; }

        private bool RcodeDumpLogged { get; set; }

        #endregion Properties

        #region Methods

        [DllImport("advapi32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool CryptEncrypt(IntPtr hKey, IntPtr hHash, int Final, uint dwFlags, [In] [Out] IntPtr pbData, [In] [Out] IntPtr pdwDataLen, uint dwBufLen);

        public void Dispose()
        {
            if (_hook == null)
                return;

            _hook.Dispose();
            _hook = null;
        }

        private bool CryptEncryptDetour(IntPtr hKey, IntPtr hHash, int Final, uint dwFlags, [In] [Out] IntPtr pbData, [In] [Out] IntPtr pdwDataLen, uint dwBufLen)
        {
            int size = Marshal.ReadInt32(pdwDataLen);
            try
            {
                if (!RcodeDumpLogged && size != 0 && pbData != null && pbData != IntPtr.Zero && Final == 1)
                    using (PySharp pySharp = new PySharp(false))
                    {
                        dynamic p = pySharp;
                        dynamic services = p.__builtin__.sm.services;
                        if (services.IsValid)
                        {
                            Dictionary<string, PyObject> serviceDict = ((PyObject) services).ToDictionary<string>();
                            if (serviceDict.ContainsKey("machoNet") && serviceDict["machoNet"].Attribute("state").ToInt() == 4)
                            {
                                bool zLib = false;
                                byte[] cbytes = new byte[size];
                                Marshal.Copy(pbData, cbytes, 0, size);
                                byte[] dbytes = cbytes;
                                if (cbytes[0] == ZlibHeader)
                                {
                                    dbytes = Zlib.Decompress(cbytes);
                                    zLib = true;
                                }
                                PyObject blueMarshal = pySharp.Import("blue").Attribute("marshal");
                                if (blueMarshal.IsValid)
                                {
                                    PyObject packet = blueMarshal.Call("Load", dbytes);
                                    if (packet.IsValid)
                                    {
                                        if (!zLib)
                                            if (packet.GetPyType() == PyType.TupleType)
                                            {
                                                PyObject pyDict = packet.Item(2);
                                                if (pyDict.IsValid && pyDict.GetPyType() == PyType.DictType)
                                                {
                                                    Dictionary<string, PyObject> dict = pyDict.ToDictionary<string>();
                                                    HookManagerImpl.Log($"Values ({dict.Count}) going to the server:");
                                                    RcodeDumpLogged = true;
                                                    if (dict.ContainsKey("cpu_sse2"))
                                                    {
                                                        int i = 0;
                                                        foreach (KeyValuePair<string, PyObject> kv in dict)
                                                        {
                                                            i++;
                                                            //HookManagerImpl.Log($"{i}: {kv.Value.GetPyType()}");
                                                            if (kv.Value.GetValue(out var obj, out _))
                                                            {
                                                                if (obj is long)
                                                                    obj = (long) obj;
                                                                if (obj is int)
                                                                    obj = (int) obj;
                                                                if (obj is bool)
                                                                    obj = (bool) obj;
                                                                if (obj is float)
                                                                    obj = (float) obj;
                                                                if (obj is string)
                                                                    obj = ((string) obj).Replace("\n", "");
                                                                if (obj == null)
                                                                {
                                                                    HookManagerImpl.Log($"[{i:D2}] {kv.Key} : ''");
                                                                    continue;
                                                                }
                                                                HookManagerImpl.Log($"[{i:D2}] {kv.Key} : '{obj}'");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        //HookManagerImpl.Log($"{packet.LogObject()}");
                                        HookManagerImpl.Log($"Packet sent. Size {size / 1024d} kb.");
                                    }
                                    else
                                    {
                                        HookManagerImpl.Log($"Warning: Packet could not be marshalled.");
                                    }
                                }
                            }
                        }
                    }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            bool result = CryptEncrypt(hKey, hHash, Final, dwFlags, pbData, pdwDataLen, dwBufLen);
            return result;
        }

        #endregion Methods
    }
}