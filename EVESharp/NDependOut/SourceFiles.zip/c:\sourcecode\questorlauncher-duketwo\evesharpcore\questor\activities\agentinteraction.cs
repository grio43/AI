﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Framework.Events;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.Stats;
using EVESharpCore.Questor.Storylines;
using EVESharpCore.States;
using SC::SharedComponents.Events;
using SC::SharedComponents.EVE;
using SC::SharedComponents.Extensions;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Questor.Activities
{
    public static class AgentInteraction
    {
        #region Constructors

        static AgentInteraction()
        {
        }

        #endregion Constructors

        #region Fields

        public const string strAccept = "Accept";
        public const string strClose = "Close";
        public const string strCompleteMission = "Complete Mission";
        public const string strDecline = "Decline";
        public const string strDelay = "Delay";
        public const string strLocateCharacter = "Locate Character";
        public const string strMyOfficesAreLocatedAt = "My offices are located at";
        public const string strNoJobsAvailable = "no jobs available";
        public const string strCareerAgentCompletedAllCareerMissions = "I'm deeply grateful for everything you've done, ";
        public const string strQuit = "Quit";
        public const string strReferral = "referral";
        public const string strRequestMission = "Request Mission";
        public const string strViewMission = "View Mission";
        public static DateTime _lastAgentWindowInteraction { get; set; }
        public static bool boolNoMissionsAvailable;
        public static bool boolSwitchAgents;
        private static readonly DateTime _lastMissionDecline = DateTime.UtcNow.AddDays(-1);

        private static bool _agentStandingsCheckFlag;
        private static DateTime _agentStandingsCheckTimeOut = DateTime.UtcNow.AddDays(1);
        private static DateTime _agentWindowLastReady = DateTime.UtcNow.AddDays(-1);
        private static DateTime _waitingOnMissionTimer = DateTime.UtcNow;
        private static bool _waitToDeclineThisMissionWaitUntilWeWillNotHarmStandings;
        private static DateTime _waitUntilThisTimeToTryToDeclineAnyOtherMissions = DateTime.UtcNow.AddDays(-1);

        #endregion Fields

        #region Properties

        public static bool ForceAccept { get; set; }

        public static DirectWindow JournalWindow { get; set; }

        //public static AgentInteractionButton LastButtonPushed { get; set; }

        public static Dictionary<long, ButtonType> LastButtonPushedPerAgentId { get; set; } = new Dictionary<long, ButtonType>();

        public static AgentInteractionPurpose Purpose { get; set; }

        #endregion Properties

        #region Methods

        public static bool AreStandingsHighEnoughToDeclineAnotherGreyListedMission(DirectAgentMission myMission)
        {
            if (myMission != null && myMission.Name.ToLower().Contains("Anomic"))
                return true;

            if (myMission == null)
            {
                Log.WriteLine("AreStandingsHighEnoughToDeclineAnotherGreyListedMission: if (MissionSettings.RegularMission == null)");
                return true;
            }

            //
            // personal standings to agent must be above -2.0 or we lose access
            // MaximumStandingUsedToAccessAgent (highest of personal, corp or faction standing) must be above the agent's access level or we lose access
            //
            if (AreStandingsHighEnoughToDeclineAnotherMissionWithoutLosingAccess(myMission))
                if (myMission.Agent.MaximumStandingUsedToAccessAgent > MissionSettings.MinAgentGreyListStandings)
                {
                    if (myMission.Agent.AgentEffectiveStandingtoMe > 1.5)
                        return true;

                    return false;
                }

            return false;
        }

        public static bool AreStandingsHighEnoughToDeclineAnotherMissionWithoutLosingAccess(DirectAgentMission myMission)
        {
            if (myMission != null && myMission.Name.ToLower().Contains("Anomic"))
                return true;

            if (myMission == null)
            {
                Log.WriteLine("AreStandingsHighEnoughToDeclineAnotherMissionWithoutLosingAccess: if (MissionSettings.RegularMission == null)");
                return true;
            }

            //
            // personal standings to agent must be above -2.0 or we lose access
            // MaximumStandingUsedToAccessAgent (highest of personal, corp or faction standing) must be above the agent's access level or we lose access
            //
            if (myMission.Agent.MaximumStandingUsedToAccessAgent - .3 > myMission.Agent.EffectiveStandingNeededToAccessAgent())
            {
                if (myMission.Agent.AgentEffectiveStandingtoMe < -0.8)
                    return false;

                return true;
            }

            return false;
        }

        public static bool ChangeAgentInteractionState(AgentInteractionState agentInteractionState, DirectAgent myAgent, bool wait = false)
        {
            try
            {
                if (State.CurrentAgentInteractionState != agentInteractionState)
                {
                    _waitingOnMissionTimer = DateTime.UtcNow;
                    State.CurrentAgentInteractionState = agentInteractionState;
                    Log.WriteLine("New AgentInteractionState [" + agentInteractionState + "]");

                    if (myAgent == null)
                        return true;

                    if (LastButtonPushedPerAgentId != null && LastButtonPushedPerAgentId.Any() && LastButtonPushedPerAgentId.ContainsKey(myAgent.AgentId))
                    {
                        ButtonType tempButton;
                        LastButtonPushedPerAgentId.TryGetValue(myAgent.AgentId, out tempButton);
                        if (tempButton == ButtonType.COMPLETE_MISSION)
                            LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.None);
                    }

                    if (wait)
                        return true;
                    ProcessState(myAgent);

                    return true;
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine(State.CurrentAgentInteractionState + ": Exception [" + ex + "]");
                return false;
            }
        }

        public static bool CloseAgentWindowIfRequestMissionButtonExists(string StateForLogs, DirectAgent myAgent)
        {
            if (myAgent == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: the Agent we were passed is null, how?");
                return true;
            }

            if (!myAgent.OpenAgentWindow(true)) return false;

            if (requestButton(myAgent) != null)
            {
                if (myAgent.Window.Close()) return true;
                return false;
            }

            //
            // if complete button doesnt exist or it does exist and we recently pushed it...
            //

            return true;
        }

        public static bool DoWeNeedHumanIntervention(DirectAgent myAgent)
        {
            try
            {
                if (ESCache.Instance.EveAccount.needHumanIntervention)
                {
                    Log.WriteLine("needHumanIntervention: Window Detected via CleanupController");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.needHumanIntervention), false);
                    myAgent.Mission.MissionCompletionErrors++;
                    myAgent.Mission.LastMissionCompletionError = DateTime.UtcNow;

                    Log.WriteLine("This window indicates an error completing a mission: [" + myAgent.Mission.MissionCompletionErrors +
                                  "] errors already we will stop questor and halt restarting when we reach 3");

                    if (myAgent.Mission.MissionCompletionErrors > 3 && ESCache.Instance.InStation)
                        if (MissionSettings.MissionXMLIsAvailable &&
                            !MissionSettings.DeclineMissionsWithTooManyMissionCompletionErrors)
                        {
                            Log.WriteLine("ERROR: Mission XML is available for [" + myAgent.Mission.Name +
                                          "] but we still did not complete the mission after 3 tries! - ERROR!");
                            Log.WriteLine("DeclineMissionsWithTooManyMissionCompletionErrors is [" +
                                          MissionSettings.DeclineMissionsWithTooManyMissionCompletionErrors + "] not Declining Mission");
                            ESCache.Instance.PauseAfterNextDock = true;
                            State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Error;
                            return true;
                        }
                        else if (!MissionSettings.MissionXMLIsAvailable &&
                                 !MissionSettings.DeclineMissionsWithTooManyMissionCompletionErrors)
                        {
                            Log.WriteLine("ERROR: Mission XML is missing for [" + myAgent.Mission.Name +
                                          "] and we we unable to complete the mission after 3 tries! - ERROR!");
                            Log.WriteLine("DeclineMissionsWithTooManyMissionCompletionErrors is [" +
                                          MissionSettings.DeclineMissionsWithTooManyMissionCompletionErrors + "] not Declining Mission");
                            ESCache.Instance.DeactivateScheduleAndCloseAfterNextDock = true;
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.DirectEve.Session.Character.Name, nameof(EveAccount.UseScheduler), false);
                            //we purposely disable autostart so that when we quit eve and questor here it stays closed until manually restarted as this error is fatal (and repeating)
                            State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Error;
                            return true;
                        }
                        else if (MissionSettings.DeclineMissionsWithTooManyMissionCompletionErrors)
                        {
                            Log.WriteLine("ERROR: [" + myAgent.Mission.Name + "] is not able to complete successfully after 3 tries! - ERROR!");
                            Log.WriteLine("DeclineMissionsWithTooManyMissionCompletionErrors is [" +
                                          MissionSettings.DeclineMissionsWithTooManyMissionCompletionErrors + "] Declining Mission");
                            ChangeAgentInteractionState(AgentInteractionState.DeclineMission, null, false);
                            return true;
                        }

                    ChangeAgentInteractionState(AgentInteractionState.Done, null, false);
                    return false;
                }

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            //
            // Verify settings and log errors as needed
            //

            try
            {
                Log.WriteLine("LoadSettings: AgentInteraction");
                if (MissionSettings.AgentToPullNextRegularMissionFrom == null || !MissionSettings.AgentToPullNextRegularMissionFrom.IsValid)
                    if (MissionSettings.AgentToPullNextRegularMissionFrom != null)
                    {
                        Log.WriteLine("if (Cache.Instance.Agent != null) - AgentInteraction.AgentId = (long)Cache.Instance.Agent.AgentId");

                        if (MissionSettings.AgentToPullNextRegularMissionFrom == null || !MissionSettings.AgentToPullNextRegularMissionFrom.IsValid)
                            Log.WriteLine("AgentInteraction.Agent == null || !AgentInteraction.Agent.IsValid");
                    }
                    else
                    {
                        Log.WriteLine("Cache.Instance.Agent == null");
                        Log.WriteLine("Unable to locate agent 2  [" + MissionSettings.strCurrentAgentName + "]");
                    }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception: " + ex);
            }
        }

        public static bool OpenJournalWindow(string module)
        {
            if (ESCache.Instance.InStation)
            {
                JournalWindow = ESCache.Instance.DirectEve.Windows.OfType<DirectJournalWindow>().FirstOrDefault();
                if (JournalWindow == null)
                {
                    if (DateTime.UtcNow < Time.Instance.NextWindowAction)
                        return false;

                    if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                    {
                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("AgentInteraction: OpenJournalWindow: !OkToInteractWithEveNow");
                        return false;
                    }

                    if (ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenJournal))
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        Statistics.LogWindowActionToWindowLog("JournalWindow", "Opening JournalWindow");
                        Time.Instance.NextWindowAction = DateTime.UtcNow.AddSeconds(ESCache.Instance.RandomNumber(1, 2));
                        Log.WriteLine("Opening Journal Window: waiting [" + Math.Round(Time.Instance.NextWindowAction.Subtract(DateTime.UtcNow).TotalSeconds, 0) + "sec]");
                    }

                    return false;
                }

                return true;
            }

            return false;
        }

        public static bool PressAcceptButtonIfItExists(string StateForLogs, DirectAgent myAgent)
        {
            if (!myAgent.OpenAgentWindow(true)) return false;

            if (myAgent.Window.Buttons.Any(i => i.Type == ButtonType.NO_JOBS_AVAILABLE))
            {
                myAgent.Window.Close();
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.RestartOfQuestorNeeded), true);
                ESCache.Instance.PauseAfterNextDock = true;
                return false;
            }

            if (ESCache.Instance.InStation)
            {
                if (myAgent.StationId == ESCache.Instance.DirectEve.Session.StationId)
                {
                    if (acceptButton(myAgent) != null && myAgent.Mission != null && DateTime.UtcNow > myAgent.Mission.LastAcceptMissionAttempt.AddSeconds(3))
                    {
                        Log.WriteLine("[" + StateForLogs + "]: Found [ Accept Mission ] button for Agent [" + myAgent.Name + "].");
                        //Are we in station with the agent? I dont think ANY agents allow pulling missions remotely.

                        Log.WriteLine("[" + StateForLogs + "]: Found [ Accept Mission ] button. We are in station with [" + myAgent.Name + "]. Pressing Accept");
                        if (PressAgentWindowButton(acceptButton(myAgent)))
                        {
                            LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.ACCEPT);
                            Log.WriteLine("Saying [Accept]");
                            myAgent.Mission.LastAcceptMissionAttempt = DateTime.UtcNow;
                            DirectEventManager.NewEvent(new DirectEvent(DirectEvents.ACCEPT_MISSION, "Accepting mission."));
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.MissionStarted), DateTime.UtcNow);
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LoyaltyPoints), myAgent.LoyaltyPoints);
                            //Statistics.WriteMissionAcceptDeclineStatsLog(false, true, AgentEffectiveStandingtoMe, AgentCorpEffectiveStandingtoMe, AgentFactionEffectiveStandingtoMe, _lastMissionDecline);
                            Statistics.StartedMission = DateTime.UtcNow;
                            Statistics.FinishedMission = DateTime.UtcNow;
                            return false;
                        }

                        Log.WriteLine("[" + StateForLogs + "]: Pressing [ Accept Mission ] Button Failed!");
                        return false;
                    }

                    if (completeButton(myAgent) != null)
                        return true;

                    return false;
                }

                Log.WriteLine("[" + StateForLogs + "]: [ Accept Mission ] Button Exists, but we are not in station with [" + myAgent.Name + "]");
                //ChangeAgentInteractionState(AgentInteractionState.Done, myAgent);
                return true;
            }

            //
            // if the accept button exists, but we recently pushed it, we should wait...
            //
            return false;
        }

        public static bool PressCompleteButtonIfItExists(string StateForLogs, DirectAgent myAgent)
        {
            if (myAgent == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: the Agent we were passed is null, how?");
                return false;
            }

            if (!myAgent.OpenAgentWindow(true)) return false;

            if (myAgent.Window.Buttons.Any(i => i.Type == ButtonType.NO_JOBS_AVAILABLE))
            {
                myAgent.Window.Close();
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.RestartOfQuestorNeeded), true);
                ESCache.Instance.PauseAfterNextDock = true;
                return false;
            }

            if (myAgent.Mission == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: we have no mission yet?!");
                if (!PressRequestButtonIfItExists(StateForLogs, myAgent)) return false;
                return true;
            }

            if (myAgent.Mission.IsMissionFinished != null && !(bool)myAgent.Mission.IsMissionFinished) return true;

            if (completeButton(myAgent) != null && myAgent.Mission != null && DateTime.UtcNow > myAgent.Mission.LastMissionCompletionError.AddSeconds(20) && DateTime.UtcNow > myAgent.Mission.LastCompleteMissionAttempt.AddSeconds(3))
            {
                ButtonType lastButtonPushed = ButtonType.None;
                if (LastButtonPushedPerAgentId.ContainsKey(myAgent.AgentId))
                    LastButtonPushedPerAgentId.TryGetValue(myAgent.AgentId, out lastButtonPushed);

                Log.WriteLine("[" + StateForLogs + "]: Found [ Complete Mission ] button: LastButtonPushed [" + lastButtonPushed + "]");
                if (lastButtonPushed == ButtonType.COMPLETE_MISSION)
                {
                    Log.WriteLine("[" + StateForLogs + "]: Attempted to complete the mission and failed: doing mission: return true");
                    myAgent.Mission.LastMissionCompletionError = DateTime.UtcNow;
                   // ChangeAgentInteractionState(AgentInteractionState.Done, myAgent);
                    return true;
                }

                if (PressAgentWindowButton(completeButton(myAgent)))
                {
                    Log.WriteLine("[" + StateForLogs + "]: Found [ Complete Mission ] button: Complete Button Pushed");
                    myAgent.Mission.LastCompleteMissionAttempt = DateTime.UtcNow;
                    LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.COMPLETE_MISSION);
                    ClearMissionSpecificSettings();
                    return false;
                }

                Log.WriteLine("[" + StateForLogs + "]: Pressing [ Complete Mission ] Button Failed!");
                return false;
            }

            //
            // if complete button doesnt exist or it does exist and we recently pushed it...
            //

            return true;
        }

        public static bool PressViewButtonIfItExists(string StateForLogs, DirectAgent myAgent)
        {
            if (myAgent == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: the Agent we were passed is null, how?");
                return false;
            }

            if (!myAgent.OpenAgentWindow(true)) return false;

            if (myAgent.Window.Buttons.Any(i => i.Type == ButtonType.NO_JOBS_AVAILABLE))
            {
                myAgent.Window.Close();
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.RestartOfQuestorNeeded), true);
                ESCache.Instance.PauseAfterNextDock = true;
                return false;
            }

            if (myAgent.Mission == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: we have no mission yet?!");
                if (!PressRequestButtonIfItExists(StateForLogs, myAgent)) return false;
                return true;
            }

            if (myAgent.Window.ViewMode == "SinglePaneView" && completeButton(myAgent) == null && quitButton(myAgent) == null && acceptButton(myAgent) == null && viewButton(myAgent) != null)
            {
                Log.WriteLine("[" + StateForLogs + "]: Found [ View ] button.");
                if (PressAgentWindowButton(viewButton(myAgent)))
                {
                    LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.VIEW_MISSION);
                    return false;
                }

                Log.WriteLine("[" + StateForLogs + "]: Pressing [ View ] Button Failed!");
                return false;
            }

            return true;
        }

        public static void ProcessState(DirectAgent myAgent)
        {
            try
            {
                if (!ESCache.Instance.InStation)
                    return;

                if (ESCache.Instance.InSpace)
                    return;

                if (myAgent == null)
                {
                    ChangeAgentInteractionState(AgentInteractionState.Done, null);
                    return;
                }

                if (DoWeNeedHumanIntervention(myAgent)) return;

                if (ESCache.Instance.EveAccount.BotUsesHydra && ESCache.Instance.EveAccount.IsLeader)
                    PushAgentInfo(myAgent);

                if (DateTime.UtcNow < _lastAgentWindowInteraction.AddMilliseconds(ESCache.Instance.RandomNumber(2500, 3000)))
                    return;

                if (!WaitOnAgentWindowButtonResponse(myAgent)) return;

                if (DebugConfig.DebugAgentInteraction) Log.WriteLine("State.CurrentAgentInteractionState [" + State.CurrentAgentInteractionState + "]");

                switch (State.CurrentAgentInteractionState)
                {
                    case AgentInteractionState.Idle:
                        break;

                    case AgentInteractionState.Done:
                        break;

                    //case AgentInteractionState.WaitingOnButtonPress:
                    //    if (LastButtonPushed == AgentInteractionButton.Complete)
                    //    {
                    //       State.CurrentAgentInteractionState = AgentInteractionState.Idle;
                    //      myAgent.RegularMission.ChangeCourierMissionCtrlState(CourierMissionCtrlState.Idle);
                    //        CourierMissionsController.ChangeCourierMissionBehaviorState(CourierMissionsBehaviorState.AcceptMission, false, myAgent);
                    //        return;
                    //    }
                    //
                    //    break;

                    case AgentInteractionState.StartConversation:
                        StartConversation(myAgent);
                        break;

                    case AgentInteractionState.ReplyToAgent:
                        ReplyToAgent(myAgent);
                        break;

                    case AgentInteractionState.WeHaveAMissionWaiting:
                        WeHaveAMissionWaiting("AgentInteraction.WaitForMission", myAgent);
                        break;

                    case AgentInteractionState.PrepareForOfferedMission:
                        PrepareForOfferedMission(myAgent);
                        break;

                    case AgentInteractionState.AcceptMission:
                        AcceptMission(myAgent);
                        break;

                    case AgentInteractionState.DeclineMission:
                        DeclineMission(myAgent);
                        break;

                    case AgentInteractionState.WaitForDeclineTimerToExpire:
                        if (DateTime.UtcNow > _waitUntilThisTimeToTryToDeclineAnyOtherMissions)
                            ChangeAgentInteractionState(AgentInteractionState.DeclineMission, myAgent, false);
                        break;

                    case AgentInteractionState.CloseConversation:
                        //CloseConversation();
                        break;

                    case AgentInteractionState.UnexpectedDialogOptions:
                        Log.WriteLine("UnexpectedDialogOptions AgentInteraction. Pausing.");
                        ControllerManager.Instance.SetPause(true);
                        break;
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        public static void PushAgentInfo(DirectAgent myAgent)
        {
            if (ESCache.Instance.EveAccount.LeaderHomeSystemId != myAgent.SolarSystemId)
            {
                if (DebugConfig.DebugAgentInteractionReplyToAgent) Log.WriteLine("AgentInteraction: PushAgentInfo: LeaderHomeSystemId [" + myAgent.SolarSystemId + "] ");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderHomeSystemId), myAgent.SolarSystemId);
            }

            if (ESCache.Instance.EveAccount.LeaderHomeStationId != myAgent.StationId)
            {
                if (DebugConfig.DebugAgentInteractionReplyToAgent) Log.WriteLine("AgentInteraction: PushAgentInfo: LeaderHomeStationId [" + myAgent.StationId + "] ");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderHomeStationId), myAgent.StationId);
            }
        }

        public static bool? ShouldWeDeclineThisMission(DirectAgent myAgent)
        {
            //
            // Do we want to decline this mission?
            //
            if (myAgent == null)
                return false;

            if (myAgent.Mission == null)
                return false;

            if (myAgent.Mission != null)
            {
                if (myAgent.Mission.State != MissionState.Offered)
                    if (!myAgent.Mission.Name.Contains("Anomic"))
                        return false;
            }

            //
            // LowSec?
            //

            //
            // at this point we have not yet accepted the mission, thus we do not have the bookmark in people and places
            // we cannot and should not accept the mission without checking the route first, declining after accepting incurs a much larger penalty to standings
            //
            bool? tempBool = IsThisMissionLocatedInLowSec(myAgent);
            if (tempBool == null) return null;
            if ((bool)tempBool)
            {
                Log.WriteLine("RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] would take us through low sec! Expires [" + myAgent.Mission.ExpiresOn + "]");
                MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] would take us through low sec!";
                return true;
            }

            //
            // Faction is on the Faction Blacklist?
            //
            if (MissionSettings.IsFactionBlacklisted(myAgent))
            {
                if (AreStandingsHighEnoughToDeclineAnotherMissionWithoutLosingAccess(myAgent.Mission))
                {
                    Log.WriteLine("Faction [" + myAgent.Mission.Faction.Name + "] is a faction we have blacklisted [" + Log.FilterPath(myAgent.Mission.Name) + "] Expires [" + myAgent.Mission.ExpiresOn + "]");
                    MissionSettings.LastReasonMissionAttemptedToBeDeclined = "Faction [" + myAgent.Mission.Faction.Name + "] is Blacklisted";
                    //ChangeAgentInteractionState(AgentInteractionState.DeclineMission, true);
                    return true;
                }

                Log.WriteLine("Faction [" + myAgent.Mission.Faction.Name + "] is a faction we have blacklisted [" + Log.FilterPath(myAgent.Mission.Name) + "] Expires [" + myAgent.Mission.ExpiresOn + "]");
                Log.WriteLine("We cannot safely decline another mission at the moment. Waiting for the 2 hour time since our last decline to expire. If we were to decline the mission youd likely lose access to this agent and we assume doing a blacklsited mission == bad.");
                MissionSettings.LastReasonMissionAttemptedToBeDeclined = "Faction [" + myAgent.Mission.Faction.Name + "] is Blacklisted";
                //ChangeAgentInteractionState(AgentInteractionState.DeclineMission, true);
                _waitToDeclineThisMissionWaitUntilWeWillNotHarmStandings = true;
                return true;
            }

            if (DebugConfig.DebugDecline) Log.WriteLine("Faction [" + myAgent.Mission.Faction.Name + "] is not on the faction blacklist");

            //
            // Mission is on the mission Blacklist?
            //
            if (MissionSettings.IsMissionBlacklisted(myAgent))
            {
                if (AreStandingsHighEnoughToDeclineAnotherMissionWithoutLosingAccess(myAgent.Mission))
                {
                    Log.WriteLine("RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is a mission we have blacklisted. Expires [" + myAgent.Mission.ExpiresOn + "]");
                    MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is on the mission Blacklist";
                    return true;
                }

                Log.WriteLine("RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is a mission we have blacklisted. Expires [" + myAgent.Mission.ExpiresOn + "]");
                Log.WriteLine("We cannot safely decline another mission at the moment. Waiting for the 2 hour timew since our last decline to expire. If we were to decline the mission youd likely lose access to this agent and we assume doing a blacklsited mission == bad.");
                MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is on the mission Blacklist";
                _waitToDeclineThisMissionWaitUntilWeWillNotHarmStandings = true;
                return true;
            }

            if (DebugConfig.DebugDecline) Log.WriteLine("[" + myAgent.Mission.Name + "] is not on the blacklist and might be on the GreyList we have not checked yet");

            //
            // GreyListed?
            //
            if (MissionSettings.MissionGreylist.Any(m => m.ToLower() == myAgent.Mission.Name.ToLower()))
            {
                if (AreStandingsHighEnoughToDeclineAnotherGreyListedMission(myAgent.Mission))
                {
                    Log.WriteLine("RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is a mission we have greylisted. Expires [" + myAgent.Mission.ExpiresOn + "]");
                    MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is on the mission Greylist";
                    return true;
                }

                Log.WriteLine("RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is a mission we have greylisted. Expires [" + myAgent.Mission.ExpiresOn + "]");
                Log.WriteLine("We cannot safely decline another mission at the moment. Waiting is not necessary since this mission is only greylisted we are going to accept this mission!");
                return false;
            }

            // If not forced to accept, decline non storyline mining, trade missions
            //if (!ForceAccept)
                if (myAgent.Mission.State == MissionState.Offered)
                {
                    Log.WriteLine("[" + myAgent.Mission.Name + "] is in MissionState [" + myAgent.Mission.State + "] Type [" + myAgent.Mission.Type + "]");
                    if (!myAgent.Mission.Important)
                    {
                        Log.WriteLine("[" + myAgent.Mission.Name + "] is Storyline [" + myAgent.Mission.Important + "] this should be false");
                        if (myAgent.Mission.Type.ToLower().Contains("Mining".ToLower())) //MissionSettings.RegularMission.Type.ToLower().Contains("Trade".ToLower())
                        {
                            Log.WriteLine("[" + myAgent.Mission.Name + "] is Type [" + myAgent.Mission.Type + "] - should be mining if we got here");
                            if (AreStandingsHighEnoughToDeclineAnotherMissionWithoutLosingAccess(myAgent.Mission))
                            {
                                Log.WriteLine("[" + myAgent.Mission.Name + "] is a [" + myAgent.Mission.Type + "] - non-storyline mission and will be declined based on this alone. ");
                                MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is in lowsec";
                                return true;
                            }

                            Log.WriteLine("[" + myAgent.Mission.Name + "] is a [" + myAgent.Mission.Type + "] - non-storyline mission and will be declined based on this alone. ");
                            MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is in lowsec";
                            _waitToDeclineThisMissionWaitUntilWeWillNotHarmStandings = true;
                            return true;
                        }

                        if (Settings.Instance.DoNotTryToDoEncounterMissions && myAgent.Mission.Type.ToLower().Contains("Encounter".ToLower()) && !myAgent.Mission.Name.Contains("Anomic")) //MissionSettings.RegularMission.Type.ToLower().Contains("Trade".ToLower())
                        {
                            Log.WriteLine("[" + myAgent.Mission.Name + "] is Type [" + myAgent.Mission.Type + "]");
                            if (AreStandingsHighEnoughToDeclineAnotherMissionWithoutLosingAccess(myAgent.Mission))
                            {
                                Log.WriteLine("[" + myAgent.Mission.Name + "] is a [" + myAgent.Mission.Type + "] - non-storyline mission and will be declined because it is an encounter mission");
                                MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] will be declined because it is an encounter mission";
                                return true;
                            }

                            Log.WriteLine("[" + myAgent.Mission.Name + "] is a [" + myAgent.Mission.Type + "] - non-storyline mission and will be declined based on this alone. ");
                            MissionSettings.LastReasonMissionAttemptedToBeDeclined = "RegularMission [" + Log.FilterPath(myAgent.Mission.Name) + "] is in lowsec";
                            _waitToDeclineThisMissionWaitUntilWeWillNotHarmStandings = true;
                            return true;
                        }
                    }
                }

            return false;
        }

        private static DirectAgentButton acceptButton(DirectAgent myAgent)
        {
            DirectAgentButton _acceptButton = FindAgentResponse(ButtonType.ACCEPT, myAgent);
            if (_acceptButton == null)
                ChangeLastButtonPushed(ButtonType.ACCEPT, ButtonType.None, myAgent);
            return _acceptButton;
        }

        private static void AcceptMission(DirectAgent myAgent)
        {
            try
            {
                if (!PressViewButtonIfItExists("AcceptMission", myAgent)) return;

                if (!PressRequestButtonIfItExists("AcceptMission", myAgent)) return;

                if (!PressCompleteButtonIfItExists("AcceptMission", myAgent)) return;

                if (!PressAcceptButtonIfItExists("AcceptMission", myAgent)) return;

                PrepareStatsWhenStartingNewMission(myAgent);
                Log.WriteLine("AcceptMission: [" + myAgent.Name + "] We must already have a mission and can't yet complete it. Setting AgentInteractionState to Done");
                ChangeAgentInteractionState(AgentInteractionState.Done, myAgent, false);
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static bool AgentStandingsCheck(DirectAgent myAgent)
        {
            try
            {
                if (myAgent == null) return true;
                if (myAgent.Level == 1) return true;

                //
                // Standings Check: if this is a totally new agent this check will timeout after 20 seconds
                //
                if (DateTime.UtcNow < _agentStandingsCheckTimeOut)
                {
                    if (myAgent.MaximumStandingUsedToAccessAgent == (float)0.00)
                    {
                        if (!_agentStandingsCheckFlag)
                        {
                            _agentStandingsCheckTimeOut = DateTime.UtcNow.AddSeconds(10);
                            _agentStandingsCheckFlag = true;
                        }

                        //_lastAgentWindowInteraction = DateTime.UtcNow;
                        Log.WriteLine(" Agent [" + myAgent.Name + "] Standings show as [" +
                                      myAgent.MaximumStandingUsedToAccessAgent + " and must not yet be available. retrying for [" +
                                      Math.Round(_agentStandingsCheckTimeOut.Subtract(DateTime.UtcNow).TotalSeconds, 0) + " sec]");
                        return false;
                    }

                    _agentStandingsCheckTimeOut = DateTime.UtcNow.AddMinutes(-1);
                    Log.WriteLine("MaximumStandingUsedToAccessAgent: " + Math.Round(myAgent.MaximumStandingUsedToAccessAgent, 2));
                    Log.WriteLine("[Personal]" + Math.Round(myAgent.AgentEffectiveStandingtoMe, 2) + " [Corp]" + Math.Round(myAgent.AgentCorpEffectiveStandingtoMe, 2) + " [Faction]" +
                                  Math.Round(myAgent.AgentFactionEffectiveStandingtoMe, 2));
                    return false;
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        private static bool boolGoToBaseNeeded(DirectAgent myAgent)
        {
            string textToLookForFromAgent = strMyOfficesAreLocatedAt;
            return FindAgentAgentSaysText(textToLookForFromAgent, myAgent);
        }

        private static void ChangeLastButtonPushed(ButtonType fromButton, ButtonType toButton, DirectAgent myAgent)
        {
            if (LastButtonPushedPerAgentId.ContainsKey(myAgent.AgentId))
                if (LastButtonPushedPerAgentId[myAgent.AgentId] == fromButton)
                {
                    Log.WriteLine("LastButtonPushed changed [" + fromButton + "] to [" + toButton + "]");
                    LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, toButton);
                }
        }

        private static bool CheckForAgentDeclineTimer(DirectAgent myAgent)
        {
            // Check for agent decline timer
            string briefingHtml = myAgent.Window.Briefing;
            try
            {
                if (!string.IsNullOrEmpty(briefingHtml) && myAgent != null && myAgent.Mission != null && myAgent.Mission.Faction != null)
                {
                    Statistics.SaveMissionHtmlDetails(briefingHtml, myAgent.Mission.Name + "-Briefing-", myAgent.Mission.Faction.Name);
                }
            }
            catch (Exception){}

            if (!string.IsNullOrEmpty(briefingHtml) && briefingHtml.Contains("Declining a mission from this agent within the next"))
            {
                Regex hourRegex = new Regex("\\s(?<hour>\\d+)\\shour");
                Regex minuteRegex = new Regex("\\s(?<minute>\\d+)\\sminute");
                Match hourMatch = hourRegex.Match(briefingHtml);
                Match minuteMatch = minuteRegex.Match(briefingHtml);
                int hours = 0;
                int minutes = 0;
                if (hourMatch.Success)
                {
                    string hourValue = hourMatch.Groups["hour"].Value;
                    hours = Convert.ToInt32(hourValue);
                }
                if (minuteMatch.Success)
                {
                    string minuteValue = minuteMatch.Groups["minute"].Value;
                    minutes = Convert.ToInt32(minuteValue);
                }

                //
                // standings are below the blacklist minimum
                // (any lower and we might lose access to this agent)
                // and no other agents are NOT available (or are also in cool-down)
                //
                if (MissionSettings.WaitDecline)
                {
                    //
                    // if true we ALWAYS wait (or switch agents?!?)
                    //
                    if (DateTime.UtcNow > _waitUntilThisTimeToTryToDeclineAnyOtherMissions)
                    {
                        _waitUntilThisTimeToTryToDeclineAnyOtherMissions = DateTime.UtcNow.AddMinutes(minutes);
                        _waitUntilThisTimeToTryToDeclineAnyOtherMissions = _waitUntilThisTimeToTryToDeclineAnyOtherMissions.AddHours(hours);
                        if (DateTime.UtcNow > _waitUntilThisTimeToTryToDeclineAnyOtherMissions)
                            _waitUntilThisTimeToTryToDeclineAnyOtherMissions = DateTime.UtcNow.AddMinutes(ESCache.Instance.RandomNumber(1, 4));
                    }

                    Log.WriteLine("Waiting [" + _waitUntilThisTimeToTryToDeclineAnyOtherMissions + "] minutes to before trying decline again because waitDecline setting is set to true (and we would have otherwise lost standing!)");
                    ChangeAgentInteractionState(AgentInteractionState.WaitForDeclineTimerToExpire, myAgent);
                    return false;
                }

                //Logging.Log("AgentInteraction.DeclineMission", "Current standings [" + Math.Round(Cache.Instance.StandingUsedToAccessAgent, 2) + "] is above our configured minimum [" + MissionSettings.MinAgentBlackListStandings + "].  Declining [" + MissionSettings.RegularMission.Name + "] note: WaitDecline is false", Logging.Yellow);
                return true;
            }

            return true;
        }

        private static void ClearMissionSpecificSettings()
        {
            Log.WriteLine("ClearMissionSpecificSettings");
            MissionSettings.ClearMissionSpecificSettings();
            _waitToDeclineThisMissionWaitUntilWeWillNotHarmStandings = false;
            //MissionSettings.AgentToPullNextRegularMissionFrom = null;
        }

        private static DirectAgentButton closeButton(DirectAgent myAgent)
        {
            //if (!IsAgentWindowReady()) return null;
            DirectAgentButton _closeButton = FindAgentResponse(ButtonType.CLOSE, myAgent);
            if (_closeButton == null)
                ChangeLastButtonPushed(ButtonType.CLOSE, ButtonType.None, myAgent);

            return _closeButton;
        }

        private static DirectAgentButton completeButton(DirectAgent myAgent)
        {
            //if (!IsAgentWindowReady()) return null;
            DirectAgentButton _completeButton = FindAgentResponse(ButtonType.COMPLETE_MISSION, myAgent);
            if (_completeButton == null)
            {
                if (LastButtonPushedPerAgentId.ContainsKey(myAgent.AgentId))
                {
                    ButtonType tempButton;
                    LastButtonPushedPerAgentId.TryGetValue(myAgent.AgentId, out tempButton);
                    if (tempButton == ButtonType.COMPLETE_MISSION)
                    {
                        GatherMissionStatistics(myAgent);
                        Log.WriteLine("Saying [Complete Mission] ISKMissionReward [" + Statistics.ISKMissionReward +
                                      "] LoyaltyPointsForCurrentMission [" +
                                      Statistics.LoyaltyPointsForCurrentMission + "]");
                        //DirectEvent
                        DirectEventManager.NewEvent(new DirectEvent(DirectEvents.COMPLETE_MISSION, "Completing mission."));
                        ChangeAgentInteractionState(AgentInteractionState.Done, null, false);
                        return null;
                    }
                }

                ChangeLastButtonPushed(ButtonType.COMPLETE_MISSION, ButtonType.None, myAgent);
                return null;
            }

            return _completeButton;
        }

        private static DirectAgentButton declineButton(DirectAgent myAgent)
        {
            //if (!IsAgentWindowReady()) return null;
            DirectAgentButton _declineButton = FindAgentResponse(ButtonType.DECLINE, myAgent);
            if (_declineButton == null)
                ChangeLastButtonPushed(ButtonType.DECLINE, ButtonType.None, myAgent);

            return _declineButton;
        }

        private static void DeclineMission(DirectAgent myAgent)
        {
            try
            {
                if (!OpenJournalWindow("DeclineMission")) return;

                if (_waitToDeclineThisMissionWaitUntilWeWillNotHarmStandings)
                    if (_waitUntilThisTimeToTryToDeclineAnyOtherMissions > DateTime.UtcNow)
                    {
                        Log.WriteLine("Waiting [" + _waitUntilThisTimeToTryToDeclineAnyOtherMissions + "] minutes to before trying decline again because waitDecline setting is set to true (and we would have otherwise lost standing!)");
                        ChangeAgentInteractionState(AgentInteractionState.WaitForDeclineTimerToExpire, myAgent);
                        return;
                    }

                if (!PressRequestButtonIfItExists("DeclineMission", myAgent)) return;

                if (!CheckForAgentDeclineTimer(myAgent)) return;

                if (!RemoveStorylineMission(myAgent)) return;

                if (!PressDeclineButtonIfItExists("DeclineMission", myAgent)) return;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static DirectAgentButton delayButton(DirectAgent myAgent)
        {
            //if (!IsAgentWindowReady()) return null;
            DirectAgentButton _delayButton = FindAgentResponse(ButtonType.DELAY, myAgent);
            if (_delayButton == null)
                ChangeLastButtonPushed(ButtonType.DELAY, ButtonType.None, myAgent);

            return _delayButton;
        }

        private static bool FindAgentAgentSaysText(string textToLookForFromAgent, DirectAgent myAgent)
        {
            if (myAgent != null)
            {
                if (myAgent.Window != null)
                {
                    bool? _tempResponse = myAgent.Window.AgentSays.Contains(textToLookForFromAgent);
                    if (_tempResponse != null)
                        return (bool)_tempResponse;

                    return false;
                }

                return false;
            }

            return false;
        }

        private static DirectAgentButton FindAgentResponse(ButtonType buttonToLookForInAgentWindow, DirectAgent myAgent)
        {
            if (DateTime.UtcNow < _lastAgentWindowInteraction.AddMilliseconds(ESCache.Instance.RandomNumber(400, 1000)))
                return null;

            if (myAgent != null)
            {
                if (myAgent.Window != null)
                {
                    DirectAgentButton _tempResponse = myAgent.Window.Buttons.FirstOrDefault(i => i.Type == buttonToLookForInAgentWindow);
                    if (_tempResponse != null)
                        return _tempResponse;
                }

                return null;
            }

            return null;
        }

        private static void GatherMissionStatistics(DirectAgent myAgent)
        {
            // let's try to get the isk and lp value here again
            int lpCurrentMission = 0;
            int iskFinishedMission = 0;
            Statistics.ISKMissionReward = 0;
            Statistics.LoyaltyPointsForCurrentMission = 0;
            Regex iskRegex = new Regex(@"([0-9]+)((\.([0-9]+))*) ISK", RegexOptions.Compiled);
            foreach (Match itemMatch in iskRegex.Matches(myAgent.Window.Objective))
            {
                int val = 0;
                int.TryParse(Regex.Match(itemMatch.Value.Replace(".", ""), @"\d+").Value, out val);
                iskFinishedMission += val;
            }

            Regex lpRegex = new Regex(@"([0-9]+) Loyalty Points", RegexOptions.Compiled);
            foreach (Match itemMatch in lpRegex.Matches(myAgent.Window.Objective))
            {
                int val = 0;
                int.TryParse(Regex.Match(itemMatch.Value, @"\d+").Value, out val);
                lpCurrentMission += val;
            }

            Statistics.LoyaltyPointsForCurrentMission = lpCurrentMission;
            Statistics.ISKMissionReward = iskFinishedMission;
        }

        private static bool IsThisBookmarkLocatedInHighSec(DirectBookmark bookmarkToCheck)
        {
            if (DebugConfig.DebugDecline) Log.WriteLine("bookmark: System: [" + bookmarkToCheck.SolarSystem.Name + "] Security [" + bookmarkToCheck.SolarSystem.Security + "] IsHighSecuritySpace [" + bookmarkToCheck.SolarSystem.IsHighSecuritySpace + "]");
            if (bookmarkToCheck.SolarSystem.IsHighSecuritySpace)
            {
                if (DebugConfig.DebugDecline) Log.WriteLine("bookmark: if (bookmarkToCheck.SolarSystem.IsHighSecuritySpace)");

                if (bookmarkToCheck.SolarSystem.Id == ESCache.Instance.DirectEve.Session.SolarSystem.Id)
                {
                    if (DebugConfig.DebugDecline) Log.WriteLine("bookmark: we are in high sec space and in local with the bookmark");
                    return true;
                }

                if (bookmarkToCheck.SolarSystem.Name == ESCache.Instance.DirectEve.Session.SolarSystem.Name)
                {
                    if (DebugConfig.DebugDecline) Log.WriteLine("bookmark: we are in high sec space and in local with the bookmark.");
                    return true;
                }

                if (bookmarkToCheck.SolarSystem.JumpsHighSecOnly > 0)
                {
                    if (DebugConfig.DebugDecline) Log.WriteLine("bookmark: the bookmark is in high sec space and our path to that system is all high sec [" + bookmarkToCheck.SolarSystem.JumpsHighSecOnly + "] jumps");
                    return true;
                }

                Log.WriteLine("bookmark: System: [" + bookmarkToCheck.SolarSystem.Name + "] Is High Sec but it would appear we have to travel through lowsec to get there!");
                //this would mean we had to travel through lowsec!
                return false;
            }

            Log.WriteLine("bookmark: System: [" + bookmarkToCheck.SolarSystem.Name + "] Is Low Sec!!!");
            return false;
        }

        private static bool? IsThisMissionLocatedInLowSec(DirectAgent myAgent)
        {
            try
            {
                if (myAgent != null && myAgent.Mission != null)
                {

                    //regular mission
                    if (!MissionSettings.CourierMission(myAgent))
                    {
                        if (DebugConfig.DebugDecline) Log.WriteLine("IsThisMissionLocatedInLowSec: This mission is a regular (non-courier) mission");
                        DirectBookmark missionBookmark = myAgent.Mission.Bookmarks.FirstOrDefault();
                        if (missionBookmark != null)
                            return !IsThisBookmarkLocatedInHighSec(missionBookmark);

                        if (DebugConfig.DebugDecline) Log.WriteLine("There are No Bookmarks Associated with [" + Log.FilterPath(myAgent.Mission.Name) + "] yet");
                    }

                    //courier mission
                    if (MissionSettings.CourierMission(myAgent))
                    {
                        Log.WriteLine("IsThisMissionLocatedInLowSec: This mission is a courier mission");

                        bool? tempBool = myAgent.Mission.RouteContainsLowSecuritySystems;
                        if (tempBool == null)
                            return null;

                        if (tempBool == true)
                            return tempBool;

                        tempBool = myAgent.Mission.LowSecWarning;
                        if (tempBool == null)
                            return null;

                        if (tempBool == true)
                            return tempBool;

                        return false;
                    }

                    if (ESCache.Instance.Windows.OfType<DirectAgentWindow>().FirstOrDefault(w => w.AgentId == myAgent.AgentId) == null)
                    {
                        Log.WriteLine("IsThisMissionLocatedInLowSec: if (Agent.Window == null)");
                        if (!myAgent.OpenAgentWindow(true)) return null;
                        return null;
                    }

                    if (ESCache.Instance.Windows.OfType<DirectAgentWindow>().FirstOrDefault(w => w.AgentId == myAgent.AgentId) != null && myAgent.Window.ObjectiveEmpty)
                    {
                        if (myAgent.Window.ViewMode == "SinglePaneView" && myAgent.Window.Buttons.Any(i => i.Type == ButtonType.VIEW_MISSION))
                            if (DateTime.UtcNow > Time.Instance.NextWindowAction)
                            {
                                if (myAgent.Window.Buttons.FirstOrDefault(button => button.Type == ButtonType.VIEW_MISSION).Click())
                                {
                                    Log.WriteLine("if (Agent.Window.Buttons.FirstOrDefault(button => button.Type == ButtonType.VIEW_MISSION).Click())");
                                    Time.Instance.NextWindowAction = DateTime.UtcNow.AddSeconds(1);
                                    return null;
                                }
                            }

                        return null;
                    }

                    Log.WriteLine(myAgent.Window.Objective);

                    if (myAgent.Window.Objective.Contains("The route generated by current autopilot settings contains low security systems!") || myAgent.Window.Objective.Contains("(Low Sec Warning!)") || myAgent.Window.Objective.Contains("Low Sec"))
                    {
                        if (Purpose != AgentInteractionPurpose.RemoteMissionAmmoCheck) Log.WriteLine("[" + myAgent.Mission.Name + "] is located in low security space!");
                        return true;
                    }

                    /**
                    if (!MissionSettings.CourierMission)
                    {
                        DirectBookmark missionBookmark = MissionSettings.RegularMission.Bookmarks.FirstOrDefault();
                        if (missionBookmark != null)
                            Log.WriteLine("mission bookmark: System: [" + missionBookmark.LocationId + "]");
                        else
                            Log.WriteLine("There are No Bookmarks Associated with [" + Log.FilterPath(MissionSettings.RegularMission.Name) + "] yet");

                        if (MissionSettings.RegularMission.Agent.Window.Objective.Contains("The route generated by current autopilot settings contains low security systems!") || MissionSettings.RegularMission.Agent.Window.Objective.Contains("(Low Sec Warning!)"))
                        {
                            if (Purpose != AgentInteractionPurpose.RemoteMissionAmmoCheck) Log.WriteLine("[" + MissionSettings.RegularMission.Name + "] is located in low security space!");
                            return true;
                        }

                        return false;
                    }
                    **/

                    return false;
                }

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        private static bool noMoreMissionsAvailable(DirectAgent myAgent)
        {
            bool tempNoMoreJobs = FindAgentAgentSaysText(strNoJobsAvailable, myAgent);
            if (tempNoMoreJobs) return true;

            tempNoMoreJobs = FindAgentAgentSaysText(strCareerAgentCompletedAllCareerMissions, myAgent);
            if (tempNoMoreJobs) return true;

            tempNoMoreJobs = FindAgentAgentSaysText(strReferral, myAgent);
            if (tempNoMoreJobs) return true;

            //
            // there are likely missions available
            //
            return false;
        }

        private static bool PleaseDropBy(DirectAgent myAgent)
        {
            string textToLookForFromAgent = "Please drop by";
            return FindAgentAgentSaysText(textToLookForFromAgent, myAgent);
        }

        private static void PrepareForOfferedMission(DirectAgent myAgent)
        {
            try
            {
                if (ESCache.Instance.InSpace)
                {
                    Log.WriteLine("PrepareForOfferedMission: InSpace [" + ESCache.Instance.InSpace + "] return");
                    return;
                }

                if (myAgent == null || !myAgent.IsValid)
                {
                    Log.WriteLine("if(Cache.Instance.Agent == null || Cache.Instance.Agent.IsValid)");
                    return;
                }

                if (myAgent.Mission != null)
                {
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastMissionName), myAgent.Mission.Name);
                    Log.WriteLine("[" + myAgent.Name + "] effective standing is [" + myAgent.MaximumStandingUsedToAccessAgent + "] and toward me is [" + myAgent.AgentEffectiveStandingtoMeText +
                                  "], minAgentGreyListStandings: [" +
                                  MissionSettings.MinAgentGreyListStandings + "]");

                    bool? tempBool = ShouldWeDeclineThisMission(myAgent);
                    if (tempBool == null) return;
                    if ((bool)tempBool)
                    {
                        ChangeAgentInteractionState(AgentInteractionState.DeclineMission, myAgent, false);
                        return;
                    }

                    if (!string.IsNullOrEmpty(myAgent.Mission.GetAgentMissionRawCsvHint()))
                    {
                        Log.WriteLine("PrepareForOfferedMission: --------------------------[" + Log.FilterPath(myAgent.Mission.Name) + "] Objective Info----------------------------");
                        Log.WriteLine("PrepareForOfferedMission: MissionSettings.RegularMission.State [" + myAgent.Mission.State + "]");
                        //if (!string.IsNullOrEmpty(agentConversation.Objective)) Logging.Log("PrepareForOfferedMission", "agentConversation.Objective. [" + agentConversation.Objective + "]");
                        Log.WriteLine(
                            "agentMissionInfo for [" + Log.FilterPath(myAgent.Mission.Name) + "] is [" + myAgent.Mission.GetAgentMissionRawCsvHint() + "] while we are still in station.");
                        Statistics.SaveMissionPocketObjectives(myAgent.Mission.GetAgentMissionRawCsvHint(), Log.FilterPath(myAgent.Mission.Name), 0);
                        Log.WriteLine("PrepareForOfferedMission: ---------------------------------------------------------------------------");
                    }

                    if (!MissionSettings.CourierMission(myAgent))
                    {
                        ClearMissionSpecificSettings();
                        // we want to clear this every time, not only if the xml exists. else we run into troubles with faction damagetype selection

                        if (File.Exists(MissionSettings.MissionXmlPath(myAgent.Mission)))
                        {
                            MissionSettings.LoadMissionXmlData(myAgent.Mission);
                        }
                        else
                        {
                            Log.WriteLine("Missing mission xml [" + myAgent.Mission.Name + "] from [" + MissionSettings.MissionXmlPath(myAgent.Mission) + "] !!!");
                            MissionSettings.MissionXMLIsAvailable = false;
                            if (MissionSettings.RequireMissionXML)
                            {
                                Log.WriteLine("Stopping Questor because RequireMissionXML is true in your character XML settings");
                                Log.WriteLine("You will need to create a mission XML for [" + myAgent.Mission.Name + "]");
                                State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Error;
                                ControllerManager.Instance.SetPause(true);
                                return;
                            }
                        }

                        if (Purpose == AgentInteractionPurpose.RemoteMissionAmmoCheck)
                        {
                            Purpose = AgentInteractionPurpose.StartMission;
                            Log.WriteLine("RemoteMissionAmmoCheck: Done");
                            ChangeAgentInteractionState(AgentInteractionState.Done, myAgent, false);
                            return;
                        }
                    }

                    Log.WriteLine("PrepareForOfferedMission: RegularMission State [" + myAgent.Mission.State + "]");

                    //
                    // do we need to check and make sure the agent is in the same station as us before we attempt to accept a mission?!
                    //
                    if (myAgent.Mission.State == MissionState.Offered)
                    {
                        if (MissionSettings.CourierMission(myAgent))
                        {
                            if (ESCache.Instance.CurrentShipsCargo == null) return;
                            if (MissionSettings.M3NeededForCargo(myAgent) == null) return;
                            if (ESCache.Instance.CurrentShipsCargo.Items.Any())
                            {
                                if (ESCache.Instance.CurrentShipsCargo.FreeCapacity != null && ESCache.Instance.CurrentShipsCargo.FreeCapacity > MissionSettings.M3NeededForCargo(myAgent))
                                {
                                    Log.WriteLine("Courier:  [" + Math.Round(ESCache.Instance.CurrentShipsCargo.FreeCapacity ?? 0, 0) + "] Cargo Capacity and the Courier Mission needs [" + MissionSettings.M3NeededForCargo(myAgent) + "]: Accepting [" + myAgent.Mission.Name + "]");
                                    ChangeAgentInteractionState(AgentInteractionState.AcceptMission, myAgent, false);
                                    return;
                                }

                                Log.WriteLine("Courier: [" + Math.Round(ESCache.Instance.CurrentShipsCargo.FreeCapacity ?? 0, 0) + "] Cargo Capacity and the Courier Mission needs [" + MissionSettings.M3NeededForCargo(myAgent) + "]: Deferring [" + myAgent.Mission.Name + "] until later");
                                CourierMissionCtrl.ChangeCourierMissionCtrlState(myAgent.Mission, CourierMissionCtrlState.NotEnoughCargoRoom);
                                ChangeAgentInteractionState(AgentInteractionState.Done, myAgent, false);
                                return;
                            }
                        }

                        Log.WriteLine("Accepting mission [" + myAgent.Mission.Name + "]");
                        ChangeAgentInteractionState(AgentInteractionState.AcceptMission, myAgent, false);
                        return;
                    }
                    // If we already accepted the mission, close the conversation

                    if (myAgent.Mission.State == MissionState.Accepted)
                    {
                        Log.WriteLine("PrepareForOfferedMission: Done with AgentInteraction");
                        ChangeAgentInteractionState(AgentInteractionState.Done, myAgent);
                        return;
                    }

                    if (myAgent.Mission.State == MissionState.OfferExpired)
                    {
                        Log.WriteLine("PrepareForOfferedMission: MissionState is OfferExpired: we should extend this to delete this mission from the journal");
                        ChangeAgentInteractionState(AgentInteractionState.Done, myAgent, false);
                        return;
                    }

                    return;
                }

                Log.WriteLine("PrepareForOfferedMission: RegularMission == null: Changing AgentInteractionState to Idle");
                ChangeAgentInteractionState(AgentInteractionState.Idle, myAgent, false);
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void PrepareStatsWhenStartingNewMission(DirectAgent myAgent)
        {
            // statsp
            int lpCurrentMission = 0;
            int iskFinishedMission = 0;
            Statistics.ISKMissionReward = 0;
            Statistics.LoyaltyPointsForCurrentMission = 0;
            Regex iskRegex = new Regex(@"([0-9]+)((\.([0-9]+))*) ISK", RegexOptions.Compiled);
            foreach (Match itemMatch in iskRegex.Matches(myAgent.Window.Objective))
            {
                int val = 0;
                string thousandsSeperator = ",";
                int.TryParse(Regex.Match(itemMatch.Value.Replace(thousandsSeperator, ""), @"\d+").Value, out val);
                iskFinishedMission += val;
            }

            Regex lpRegex = new Regex(@"([0-9]+) Loyalty Points", RegexOptions.Compiled);
            foreach (Match itemMatch in lpRegex.Matches(myAgent.Window.Objective))
            {
                int val = 0;
                int.TryParse(Regex.Match(itemMatch.Value, @"\d+").Value, out val);
                lpCurrentMission += val;
            }

            Statistics.LoyaltyPointsTotal = myAgent.LoyaltyPoints;
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LoyaltyPoints), myAgent.LoyaltyPoints);
            Statistics.LoyaltyPointsForCurrentMission = lpCurrentMission;
            Statistics.ISKMissionReward = iskFinishedMission;
            ESCache.Instance.Wealth = ESCache.Instance.DirectEve.Me.Wealth;
            Log.WriteLine("ISK finished mission [" + iskFinishedMission + "] LoyalityPoints [" + lpCurrentMission + "]");
        }

        //private static List<DirectAgentResponse> BeforeButtonPress_AgentWindowResponses = new List<DirectAgentResponse>();
        private static bool PressAgentWindowButton(DirectAgentButton ButtonToPress)
        {
            if (ButtonToPress.Click())
            {
                _lastAgentWindowInteraction = DateTime.UtcNow;
                return true;
            }

            return false;
        }

        private static bool PressDeclineButtonIfItExists(string StateForLogs, DirectAgent myAgent)
        {
            if (myAgent == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: the Agent we were passed is null, how?");
                return true;
            }

            if (!myAgent.OpenAgentWindow(true)) return false;

            if (myAgent.Mission == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: we have no mission yet?!");
                if (!PressRequestButtonIfItExists(StateForLogs, myAgent)) return false;
                return true;
            }

            bool boolIWeAreDecliningaStorylineMission = myAgent.Mission.Important;

            if (declineButton(myAgent) != null && myAgent.Mission != null && DateTime.UtcNow > myAgent.Mission.LastDeclineMissionAttempt.AddSeconds(5))
            {
                Log.WriteLine("[" + StateForLogs + "]: Found [ Decline Mission ] button.");
                if (PressAgentWindowButton(declineButton(myAgent)))
                {
                    LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.DECLINE);
                    myAgent.Mission.LastDeclineMissionAttempt = DateTime.UtcNow;
                    ClearMissionSpecificSettings();
                    _waitUntilThisTimeToTryToDeclineAnyOtherMissions = DateTime.UtcNow.AddMinutes(120);
                    //IsThisMissionLocatedInLowSec();
                    Statistics.WriteMissionAcceptDeclineStatsLog(true, false, myAgent.AgentEffectiveStandingtoMe, myAgent.AgentCorpEffectiveStandingtoMe, myAgent.AgentFactionEffectiveStandingtoMe, _lastMissionDecline, MissionSettings.LastReasonMissionAttemptedToBeDeclined);

                    //DirectEvent
                    DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DECLINE_MISSION, "Declining mission."));
                    if (boolIWeAreDecliningaStorylineMission)
                    {
                        MissionSettings.StorylineInstance.Reset();
                        State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Idle;
                        State.CurrentCourierMissionBehaviorState = CourierMissionsBehaviorState.Idle;
                        ChangeAgentInteractionState(AgentInteractionState.Done, myAgent, false);
                        return true;
                    }

                    ChangeAgentInteractionState(AgentInteractionState.StartConversation, myAgent, false);
                    return false;
                }

                Log.WriteLine("[" + StateForLogs + "]: Pressing [ Decline Mission ] Button Failed!");
                return false;
            }

            if (declineButton(myAgent) == null)
                return true;

            //
            // if the decine button still exists, but we have clocked the button in the last few seconds wait for the button to go away before attempting to proceed or push the button again
            //
            Log.WriteLine("Decline button exists: but could not be pushed yet: waiting");
            return false;
        }

        private static bool PressRequestButtonIfItExists(string StateForLogs, DirectAgent myAgent)
        {
            if (myAgent == null)
            {
                Log.WriteLine("[" + StateForLogs + "]: the Agent we were passed is null, how?");
                return false;
            }

            if (myAgent.Window.Buttons.Any(i => i.Type == ButtonType.NO_JOBS_AVAILABLE))
            {
                myAgent.Window.Close();
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.RestartOfQuestorNeeded), true);
                ESCache.Instance.PauseAfterNextDock = true;
                return false;
            }

            if (!ESCache.Instance.InStation || myAgent.StationId != ESCache.Instance.DirectEve.Session.StationId)
            {
                Log.WriteLine("We are not in station with the agent [" + myAgent.Name + "][" + myAgent.StationName + "]");
                if (ESCache.Instance.InStation) Log.WriteLine("We are in [" + ESCache.Instance.DirectEve.Session.Station.Name + "]");
                if (MissionSettings.SelectedControllerUsesCombatMissionsBehavior && State.CurrentCombatMissionBehaviorState != CombatMissionsBehaviorState.Storyline)
                {
                    CombatMissionsBehavior.ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                    ChangeAgentInteractionState(AgentInteractionState.Done, myAgent);
                    return false;
                }

                //we are trying to go do a storyline dont want to push any buttons... (right?)
                return true;
            }

            if (!myAgent.OpenAgentWindow(true)) return false;

            if (requestButton(myAgent) != null)
            {
                Log.WriteLine("[" + StateForLogs + "]: Found [ Request Mission ] button.");
                if (PressAgentWindowButton(requestButton(myAgent)))
                {
                    LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.REQUEST_MISSION);
                    return false;
                }

                Log.WriteLine("[" + StateForLogs + "]: Pressing [ Requesting Mission ] Button Failed!");
                return false;
            }

            return true;
        }

        private static DirectAgentButton quitButton(DirectAgent myAgent)
        {
            //if (!IsAgentWindowReady()) return null;
            DirectAgentButton _quitButton = FindAgentResponse(ButtonType.QUIT_MISSION, myAgent);
            if (_quitButton == null)
                ChangeLastButtonPushed(ButtonType.QUIT_MISSION, ButtonType.None, myAgent);

            return _quitButton;
        }

        private static bool RemoveStorylineMission(DirectAgent myAgent)
        {
            if (State.CurrentStorylineState == StorylineState.DeclineMission || State.CurrentStorylineState == StorylineState.AcceptMission)
            {
                /**
                DirectJournalWindow jw = ESCache.Instance.DirectEve.Windows.OfType<DirectJournalWindow>().FirstOrDefault();

                if (jw == null)
                {
                    Log.WriteLine("Opening journal.");
                    ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenJournal);
                    return false;
                }

                if (jw.SelectedTab != JournalTab.Missions)
                {
                    Log.WriteLine("Journal window mission tab is not selected. Switching the tab.");
                    jw.SwitchTab(JournalTab.Missions);
                    return false;
                }
                **/
                if (myAgent.Mission != null && myAgent.Mission.Important)
                {
                    Log.WriteLine("Storyline: Removing Storyline [" + myAgent.Mission.Name + "] from the mission journal");
                    myAgent.Mission.RemoveOffer();
                }

                Log.WriteLine("Storyline: Setting StorylineState.Done");
                State.CurrentStorylineState = StorylineState.Done;
                State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Storyline;
                ChangeAgentInteractionState(AgentInteractionState.Idle, myAgent, false);
                return false;
            }

            return true;
        }

        private static void ReplyToAgent(DirectAgent myAgent)
        {
            try
            {
                if (ESCache.Instance.InSpace)
                {
                    Log.WriteLine("ReplyToAgent: InSpace [" + ESCache.Instance.InSpace + "] return");
                    return;
                }

                if (!myAgent.OpenAgentWindow(true))
                {
                    Log.WriteLine("ReplyToAgent: if (!myAgent [" + myAgent.Name + "].OpenAgentWindow(true))");
                    return;
                }

                //
                // Read the possibly responses and make sure we are 'doing the right thing' - set AgentInteractionPurpose to fit the state of the agent window
                //
                if (PleaseDropBy(myAgent) || myAgent.Window.Html.Contains("Please drop by") || boolGoToBaseNeeded(myAgent))
                {
                    Log.WriteLine("agent [" + myAgent.Name + "] if (PleaseDropBy || MissionSettings.AgentToPullNextRegularMissionFrom.Window.Html.Contains(Please drop by) || boolGoToBaseNeeded)");
                    if (MissionSettings.SelectedControllerUsesCombatMissionsBehavior && State.CurrentCombatMissionBehaviorState != CombatMissionsBehaviorState.Storyline)
                        CombatMissionsBehavior.ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);

                    ChangeAgentInteractionState(AgentInteractionState.Idle, myAgent, false);
                    return;
                }

                if (noMoreMissionsAvailable(myAgent))
                {
                    if (ESCache.Instance.EveAccount.SelectedController == "CareerAgentController")
                    {
                        boolSwitchAgents = true;
                        boolNoMissionsAvailable = true;
                        Log.WriteLine("agent [" + myAgent.Name + "] has no missions available. Switching to next CareerAgent");
                        myAgent.Window.Close();
                        MissionSettings.TrackCareerAgentsWithNoMissionsAvailable(myAgent);
                        return;
                    }

                    if (myAgent.StorylineAgent)
                    {
                        Log.WriteLine("Storyline agent [" + myAgent.Name + "] has no more missions available for now. resetting to the use the normal agent.");
                        myAgent.Window.Close();
                        MissionSettings.ClearMissionSpecificSettings();
                        return;
                    }

                    Log.WriteLine("Pausing: agent [" + myAgent.Name + "] has no missions available. Define more / different agents in the character XML.");
                    myAgent.Window.Close();
                    ControllerManager.Instance.SetPause(true);
                    return;
                }

                if (requestButton(myAgent) == null &&
                    completeButton(myAgent) == null &&
                    viewButton(myAgent) == null &&
                    acceptButton(myAgent) == null &&
                    declineButton(myAgent) == null &&
                    delayButton(myAgent) == null &&
                    quitButton(myAgent) == null)
                    try
                    {
                        Log.WriteLine("Agent Name [" + myAgent.Name + "]");
                        Log.WriteLine("Agent.Window: WindowState [" + myAgent.Window.WindowState + "]");
                        Log.WriteLine("Agent.Window: IsReady [" + myAgent.Window.IsReady + "]");
                        Log.WriteLine("Agent.Window: Ready [" + myAgent.Window.Ready + "]");
                        Log.WriteLine("Agent.Window: Buttons Count [" + myAgent.Window.Buttons.Count + "]");
                        Log.WriteLine("Agent.Window: AgentSays [" + myAgent.Window.AgentSays + "]");
                        Log.WriteLine("Agent.Window: Briefing [" + myAgent.Window.Briefing + "]");
                        Log.WriteLine("Agent.Window: Objective [" + myAgent.Window.Objective + "]");
                        Log.WriteLine("Agent.Window: Caption [" + myAgent.Window.Caption + "]");
                        Log.WriteLine("Agent.Window: Html [" + myAgent.Window.Html + "]");
                        Log.WriteLine("Agent.Window: ViewMode [" + myAgent.Window.ViewMode + "]");
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLine("Exception [" + ex + "]");
                    }

                if (Purpose != AgentInteractionPurpose.RemoteMissionAmmoCheck) //do not change the AgentInteractionPurpose if we are checking which ammo type to use.
                {
                    if (DebugConfig.DebugAgentInteractionReplyToAgent)
                        Log.WriteLine(
                            "if (Purpose != AgentInteractionPurpose.AmmoCheck) //do not change the AgentInteractionPurpose if we are checking which ammo type to use.");

                    //
                    // if we arent checking the mission details for ammo purposes then
                    //
                    if (acceptButton(myAgent) != null && declineButton(myAgent) != null)
                        if (myAgent.StationId == ESCache.Instance.DirectEve.Session.StationId)
                        {
                            Log.WriteLine("Found accept and decline buttons: Changing to AgentInteractionState.WeHaveAMissionWaiting");
                            ChangeAgentInteractionState(AgentInteractionState.WeHaveAMissionWaiting, myAgent, false);
                            return;
                        }

                    /**
                    if (completeButton != null && quitButton != null && closeButton != null && Statistics.MissionCompletionErrors == 0)
                        if (Purpose != AgentInteractionPurpose.CompleteMission)
                        {
                            Log.WriteLine("ReplyToAgent: Found complete button, Changing Purpose to CompleteMission");

                            //we have a mission in progress here, attempt to complete it
                            if (DateTime.UtcNow > _agentWindowTimeStamp.AddSeconds(30))
                                Purpose = AgentInteractionPurpose.CompleteMission;
                        }
                    **/

                    //if (requestButton != null && closeButton != null)
                }

                if (!PressViewButtonIfItExists("ReplyToAgent: [" + myAgent.Name + "] ViewButton", myAgent)) return;

                if (!PressRequestButtonIfItExists("ReplyToAgent: [" + myAgent.Name + "] RequestButton", myAgent)) return;

                if (!PressCompleteButtonIfItExists("ReplyToAgent: [" + myAgent.Name + "] CompleteButton", myAgent)) return;

                //if (!PressAcceptButtonIfItExists("ReplyToAgent")) return;
                Log.WriteLine("ReplyToAgent: [" + myAgent.Name + "] We must be doing a mission and can't yet complete it. Setting AgentInteractionState to Done");
                if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.Storyline && State.CurrentStorylineState == StorylineState.AcceptMission)
                    Storyline.ChangeStorylineState(StorylineState.Arm);
                //if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.Storyline && State.CurrentStorylineState == StorylineState.CompleteMission)
                //    Storyline.ChangeStorylineState(StorylineState.Arm);
                ChangeAgentInteractionState(AgentInteractionState.Done, myAgent, true);
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static DirectAgentButton requestButton(DirectAgent myAgent)
        {
            //if (!IsAgentWindowReady()) return null;
            DirectAgentButton _requestButton = FindAgentResponse(ButtonType.REQUEST_MISSION, myAgent);
            if (_requestButton == null)
                ChangeLastButtonPushed(ButtonType.REQUEST_MISSION, ButtonType.None, myAgent);

            return _requestButton;
        }

        private static void StartConversation(DirectAgent myAgent)
        {
            try
            {
                if (ESCache.Instance.InSpace)
                {
                    Log.WriteLine("StartConversation: InSpace [" + ESCache.Instance.InSpace + "] return");
                    return;
                }

                if (!AgentStandingsCheck(myAgent)) return;

                if (Purpose == AgentInteractionPurpose.RemoteMissionAmmoCheck)
                {
                    Log.WriteLine("RemoteMissionAmmoCheck: Checking ammo type");
                    ChangeAgentInteractionState(AgentInteractionState.WeHaveAMissionWaiting, myAgent, false);
                }
                else
                {
                    Log.WriteLine("Replying to agent");
                    ChangeAgentInteractionState(AgentInteractionState.ReplyToAgent, myAgent, false);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static DirectAgentButton viewButton(DirectAgent myAgent)
        {
            //if (!IsAgentWindowReady()) return null;
            DirectAgentButton _viewButton = FindAgentResponse(ButtonType.VIEW_MISSION, myAgent);
            if (_viewButton == null)
                ChangeLastButtonPushed(ButtonType.VIEW_MISSION, ButtonType.None, myAgent);

            return _viewButton;
        }

        private static bool WaitOnAgentWindowButtonResponse(DirectAgent myAgent)
        {
            bool waitForButtonsToChange = true;
            bool buttonsHaveChanged = true;
            bool timeoutReached = true;

            if (DateTime.UtcNow > _lastAgentWindowInteraction.AddSeconds(5))
                return timeoutReached;

            ButtonType lastButtonPushed = ButtonType.None;
            if (LastButtonPushedPerAgentId.ContainsKey(myAgent.AgentId))
                LastButtonPushedPerAgentId.TryGetValue(myAgent.AgentId, out lastButtonPushed);

            if (DebugConfig.DebugAgentInteractionReplyToAgent) Log.WriteLine("LastButtonPushed [" + lastButtonPushed + "]");

            switch (lastButtonPushed)
            {
                case ButtonType.None:
                    if (!myAgent.OpenAgentWindow(true)) return false;

                    if (myAgent.Window.Buttons.Any())
                        return buttonsHaveChanged;

                    return false;

                case ButtonType.ACCEPT:
                    return waitForButtonsToChange;

                case ButtonType.COMPLETE_MISSION:
                    return waitForButtonsToChange;

                case ButtonType.DECLINE:
                    return waitForButtonsToChange;

                case ButtonType.REQUEST_MISSION:
                    return waitForButtonsToChange;

                case ButtonType.VIEW_MISSION:
                    return waitForButtonsToChange;
            }

            return false;
        }

        /**
        //
        // find the name of the station we are in so we can use it to align to the station if need be during a mission
        //
        private static string StationNameWeWereInWhenWeLastAcceptedaMission;
        private static void NoteWhichStationWeAreIn()
        {
            //StationNameWeWereInWhenWeLastAcceptedaMission =
            foreach (EntityCache station in QCache.Instance.Stations)
            {
                station.Id;
            }
        }
        **/

        private static void WeHaveAMissionWaiting(string module, DirectAgent myAgent)
        {
            try
            {
                if (ESCache.Instance.InSpace)
                {
                    Log.WriteLine("WeHaveAMissionWaiting: InSpace [" + ESCache.Instance.InSpace + "] return");
                    return;
                }

                if (!OpenJournalWindow(module)) return;

                if (!PressRequestButtonIfItExists("WaitForMission: RequestButton", myAgent)) return;
                if (!PressViewButtonIfItExists("WaitForMission: ViewButton", myAgent)) return;

                if (myAgent.Mission == null)
                {
                    if (DateTime.UtcNow.Subtract(_waitingOnMissionTimer).TotalSeconds > 30)
                    {
                        Log.WriteLine("WaitForMission: Unable to find mission from that agent (yet?) : AgentInteraction.AgentId [" +
                                      myAgent.AgentId + "]");
                        JournalWindow.Close();
                        if (DateTime.UtcNow.Subtract(_waitingOnMissionTimer).TotalSeconds > 120)
                        {
                            string msg =
                                "AgentInteraction: WaitforMission: Journal would not open/refresh - mission was null: restarting EVE Session";
                            Log.WriteLine(msg);
                            if (!ESCache.Instance.CloseQuestor(msg)) return;
                        }
                    }

                    return;
                }

                Log.WriteLine("RegularMission names [" + myAgent.Mission.Name + "] found in journal.");
                ChangeAgentInteractionState(AgentInteractionState.PrepareForOfferedMission, myAgent, false);
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        #endregion Methods
    }
}