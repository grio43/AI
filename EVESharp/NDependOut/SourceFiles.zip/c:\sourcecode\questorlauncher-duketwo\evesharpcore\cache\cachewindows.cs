﻿extern alias SC;

using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Stats;
using SC::SharedComponents.IPC;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Cache
{
    public partial class ESCache
    {
        #region Fields

        public DirectLoyaltyPointStoreWindow _lpStore;
        private DirectFittingManagerWindow _fittingManagerWindow;

        #endregion Fields

        #region Properties

        public DirectFittingManagerWindow FittingManagerWindow
        {
            get
            {
                try
                {
                    if (Instance.InStation && Settings.Instance.UseFittingManager)
                    {
                        if (_fittingManagerWindow == null)
                        {
                            if (!Instance.InStation || Instance.InSpace)
                            {
                                Log.WriteLine("Opening Fitting Manager: We are not in station?! There is no Fitting Manager in space, waiting...");
                                return null;
                            }

                            if (Instance.InStation)
                            {
                                if (Instance.Windows != null && Instance.Windows.Any())
                                {
                                    if (Instance.Windows.OfType<DirectFittingManagerWindow>().Any())
                                    {
                                        DirectFittingManagerWindow __fittingManagerWindow = Instance.Windows.OfType<DirectFittingManagerWindow>().FirstOrDefault();
                                        if (__fittingManagerWindow != null && __fittingManagerWindow.IsReady)
                                        {
                                            _fittingManagerWindow = __fittingManagerWindow;
                                            return _fittingManagerWindow;
                                        }
                                    }

                                    if (DateTime.UtcNow > Time.Instance.NextWindowAction)
                                    {
                                        Log.WriteLine("Opening Fitting Manager Window");
                                        Time.Instance.NextWindowAction = DateTime.UtcNow.AddSeconds(Instance.RandomNumber(1, 2));
                                        Instance.DirectEve.OpenFitingManager();
                                        Statistics.LogWindowActionToWindowLog("FittingManager", "Opening FittingManager");
                                        return null;
                                    }

                                    if (DebugConfig.DebugFittingMgr)
                                        Log.WriteLine("NextWindowAction is still in the future [" +
                                                      Time.Instance.NextWindowAction.Subtract(DateTime.UtcNow).TotalSeconds +
                                                      "] sec");
                                    return null;
                                }

                                return null;
                            }

                            return null;
                        }

                        return _fittingManagerWindow;
                    }

                    Log.WriteLine("Opening Fitting Manager: We are not in station?! There is no Fitting Manager in space, waiting...");
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Unable to define FittingManagerWindow [" + exception + "]");
                    return null;
                }
            }
            set => _fittingManagerWindow = value;
        }

        public DirectLoyaltyPointStoreWindow LPStore
        {
            get
            {
                try
                {
                    if (Instance.InStation)
                    {
                        if (_lpStore == null)
                        {
                            if (!Instance.InStation)
                            {
                                Log.WriteLine("Opening LP Store: We are not in station?! There is no LP Store in space, waiting...");
                                return null;
                            }

                            if (Instance.InStation)
                            {
                                if (Instance.Windows != null && Instance.Windows.Any())
                                {
                                    _lpStore = Instance.Windows.OfType<DirectLoyaltyPointStoreWindow>().FirstOrDefault();

                                    if (_lpStore == null)
                                    {
                                        if (DateTime.UtcNow > Time.Instance.NextLPStoreAction)
                                        {
                                            if (!Instance.EveAccount.OkToInteractWithEveNow)
                                            {
                                                if (DebugConfig.DebugInteractWithEve) Log.WriteLine("LPStore: !OkToInteractWithEveNow");
                                                return null;
                                            }

                                            if (Instance.DirectEve.ExecuteCommand(DirectCmd.OpenLpstore))
                                            {
                                                Log.WriteLine("Opening loyalty point store");
                                                Time.Instance.NextLPStoreAction = DateTime.UtcNow.AddSeconds(Instance.RandomNumber(30, 240));
                                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                                Statistics.LogWindowActionToWindowLog("LPStore", "Opening LPStore");
                                                return null;
                                            }

                                            return null;
                                        }

                                        return null;
                                    }

                                    return _lpStore;
                                }

                                return null;
                            }

                            return null;
                        }

                        return _lpStore;
                    }

                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Unable to define LPStore [" + exception + "]");
                    return null;
                }
            }
            private set => _lpStore = value;
        }

        private DirectFleetWindow _fleetWindow;

        public DirectFleetWindow FleetWindow
        {
            get
            {
                try
                {
                    if (_fleetWindow == null)
                    {
                        if (Instance.Windows != null && Instance.Windows.Any())
                        {
                            if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                                return null;

                            if (Time.Instance.QuestorStarted_DateTime.AddSeconds(45) > DateTime.UtcNow)
                                return null;

                            _fleetWindow = Instance.Windows.OfType<DirectFleetWindow>().FirstOrDefault();

                            if (_fleetWindow == null)
                            {
                                if (DateTime.UtcNow > Time.Instance.NextFleetWindowAction)
                                {
                                    if (!Instance.EveAccount.OkToInteractWithEveNow)
                                    {
                                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("FleetWindow: !OkToInteractWithEveNow");
                                        return null;
                                    }

                                    if (Instance.DirectEve.ExecuteCommand(DirectCmd.OpenFleet))
                                    {
                                        Log.WriteLine("Opening fleet window");
                                        Time.Instance.NextFleetWindowAction = DateTime.UtcNow.AddSeconds(Instance.RandomNumber(15, 60));
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                        Statistics.LogWindowActionToWindowLog("FleetWindow", "Opening FleetWindow");
                                        return null;
                                    }

                                    return null;
                                }

                                return null;
                            }

                            return _fleetWindow;
                        }

                        return null;
                    }

                    return _fleetWindow;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public DirectMarketWindow MarketWindow { get; set; }
        public DirectContainerWindow PrimaryInventoryWindow { get; set; }

        #endregion Properties

        #region Methods

        public bool CloseFittingManager(string module)
        {
            if (Settings.Instance.UseFittingManager)
            {
                if (DateTime.UtcNow < Time.Instance.NextOpenHangarAction)
                    return false;

                if (Instance.Windows.OfType<DirectFittingManagerWindow>().FirstOrDefault() != null)
                {
                    Log.WriteLine("Closing Fitting Manager Window");
                    Instance.FittingManagerWindow.Close();
                    Statistics.LogWindowActionToWindowLog("FittingManager", "Closing FittingManager");
                    Instance.FittingManagerWindow = null;
                    Time.Instance.NextOpenHangarAction = DateTime.UtcNow.AddSeconds(2);
                    return true;
                }

                return true;
            }

            return true;
        }

        public bool CloseLPStore(string module)
        {
            if (DateTime.UtcNow < Time.Instance.NextOpenHangarAction)
                return false;

            if (!Instance.InStation)
            {
                Log.WriteLine("Closing LP Store: We are not in station?!");
                return false;
            }

            if (Instance.InStation)
            {
                Instance.LPStore = Instance.Windows.OfType<DirectLoyaltyPointStoreWindow>().FirstOrDefault();
                if (Instance.LPStore != null)
                {
                    Log.WriteLine("Closing loyalty point store");
                    Instance.LPStore.Close();
                    Statistics.LogWindowActionToWindowLog("LPStore", "Closing LPStore");
                    return false;
                }

                return true;
            }

            return true;
        }

        public bool CloseMarket(string module)
        {
            if (DateTime.UtcNow < Time.Instance.NextWindowAction)
                return false;

            if (Instance.InStation)
            {
                Instance.MarketWindow = Instance.Windows.OfType<DirectMarketWindow>().FirstOrDefault();

                if (Instance.MarketWindow == null)
                    return true;

                Instance.MarketWindow.Close();
                Statistics.LogWindowActionToWindowLog("MarketWindow", "Closing MarketWindow");
                return true;
            }

            return true;
        }

        public bool ClosePrimaryInventoryWindow(string module)
        {
            if (DateTime.UtcNow < Time.Instance.NextOpenHangarAction)
                return false;
            try
            {
                foreach (DirectWindow window in Instance.Windows)
                    if (window.Type.Contains("form.Inventory"))
                    {
                        if (DebugConfig.DebugHangars)
                            Log.WriteLine("ClosePrimaryInventoryWindow: Closing Primary Inventory Window Named [" + window.Name + "]");
                        window.Close();
                        Statistics.LogWindowActionToWindowLog("Inventory (main)", "Close Inventory");
                        Time.Instance.NextOpenHangarAction = DateTime.UtcNow.AddMilliseconds(500);
                        return false;
                    }

                return true;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Unable to complete ClosePrimaryInventoryWindow [" + exception + "]");
                return false;
            }
        }

        public bool DebugInventoryWindows(string module)
        {
            Log.WriteLine("DebugInventoryWindows: *** Start Listing Inventory Windows ***");
            int windownumber = 0;
            foreach (DirectWindow window in Instance.Windows)
                if (window.Type.ToLower().Contains("inventory"))
                {
                    windownumber++;
                    Log.WriteLine("----------------------------  #[" + windownumber + "]");
                    Log.WriteLine("DebugInventoryWindows.Name:    [" + window.Name + "]");
                    Log.WriteLine("DebugInventoryWindows.Type:    [" + window.Type + "]");
                    Log.WriteLine("DebugInventoryWindows.Caption: [" + window.Caption + "]");
                }
            Log.WriteLine("DebugInventoryWindows: ***  End Listing Inventory Windows  ***");
            return true;
        }

        public DirectWindow GetWindowByCaption(string caption)
        {
            return Windows.FirstOrDefault(w => w.Caption.Contains(caption));
        }

        public DirectWindow GetWindowByName(string name)
        {
            DirectWindow WindowToFind = null;
            try
            {
                if (Instance.Windows == null || !Instance.Windows.Any())
                    return null;

                if (name == "Local")
                    WindowToFind = Windows.FirstOrDefault(w => w.Name.StartsWith("chatchannel_local"));

                if (WindowToFind == null)
                    WindowToFind = Windows.FirstOrDefault(w => w.Name == name);

                if (WindowToFind != null)
                    return WindowToFind;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }

            return null;
        }

        public bool ListInvTree(string module)
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.NextOpenHangarAction)
                {
                    if (DebugConfig.DebugHangars)
                        Log.WriteLine("Debug: if (DateTime.UtcNow < NextOpenHangarAction)");
                    return false;
                }

                if (DebugConfig.DebugHangars)
                    Log.WriteLine("Debug: about to: if (!Cache.Instance.OpenInventoryWindow");

                if (!Instance.OpenInventoryWindow(module)) return false;

                Instance.PrimaryInventoryWindow =
                    (DirectContainerWindow)Instance.Windows.FirstOrDefault(w => w.Type.Contains("form.Inventory") && w.Name.Contains("Inventory"));

                if (Instance.PrimaryInventoryWindow != null && Instance.PrimaryInventoryWindow.IsReady)
                {
                    List<long> idsInInvTreeView = Instance.PrimaryInventoryWindow.GetIdsFromTree(false);
                    if (DebugConfig.DebugHangars)
                        Log.WriteLine("Debug: IDs Found in the Inv Tree [" + idsInInvTreeView.Count() + "]");

                    if (Instance.PrimaryInventoryWindow.ExpandCorpHangarView())
                    {
                        Statistics.LogWindowActionToWindowLog("Corporate Hangar", "ExpandCorpHangar executed");
                        Log.WriteLine("ExpandCorpHangar executed");
                        Time.Instance.NextOpenHangarAction = DateTime.UtcNow.AddSeconds(4);
                        return false;
                    }

                    foreach (long itemInTree in idsInInvTreeView)
                        Log.WriteLine("ID: " + itemInTree);
                    return false;
                }

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        public bool OpenContainerInSpace(string module, EntityCache containerToOpen)
        {
            if (DateTime.UtcNow < Time.Instance.NextLootAction)
                return false;

            if (Instance.InSpace && containerToOpen.Distance <= (int)Distances.ScoopRange)
            {
                Instance.ContainerInSpace = Instance.DirectEve.GetContainer(containerToOpen.Id);

                if (Instance.ContainerInSpace != null)
                {
                    if (Instance.ContainerInSpace.Window == null)
                    {
                        if (containerToOpen.OpenCargo())
                        {
                            Time.Instance.NextLootAction = DateTime.UtcNow.AddMilliseconds(Time.Instance.LootingDelay_milliseconds);
                            Log.WriteLine("Opening Container: waiting [" +
                                          Math.Round(Time.Instance.NextLootAction.Subtract(DateTime.UtcNow).TotalSeconds, 0) + " sec]");
                            return false;
                        }

                        return false;
                    }

                    if (!Instance.ContainerInSpace.Window.IsReady)
                    {
                        Log.WriteLine("Container window is not ready");
                        return false;
                    }

                    if (Instance.ContainerInSpace.Window.IsPrimary())
                    {
                        Log.WriteLine("Opening Container window as secondary");
                        Instance.ContainerInSpace.Window.OpenAsSecondary();
                        Statistics.LogWindowActionToWindowLog("ContainerInSpace", "Opening ContainerInSpace");
                        Time.Instance.NextLootAction = DateTime.UtcNow.AddMilliseconds(Time.Instance.LootingDelay_milliseconds);
                        return true;
                    }
                }

                return true;
            }
            Log.WriteLine("Not in space or not in scoop range");
            return true;
        }

        public bool OpenInventoryWindow(string module)
        {
            if (Instance.Windows != null && Instance.Windows.Any())
            {
                Instance.PrimaryInventoryWindow =
                    (DirectContainerWindow)Instance.Windows.FirstOrDefault(w => w.Type.Contains("form.Inventory") && w.Name.Contains("Inventory"));

                if (Instance.PrimaryInventoryWindow == null)
                {
                    if (!Instance.EveAccount.OkToInteractWithEveNow)
                    {
                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("LPStore: !OkToInteractWithEveNow");
                        return false;
                    }

                    if (Instance.DirectEve.ExecuteCommand(DirectCmd.OpenInventory))
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("Cache.Instance.InventoryWindow is null, opening InventoryWindow");
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        Statistics.LogWindowActionToWindowLog("Inventory (main)", "Open Inventory");
                        Time.Instance.NextOpenHangarAction = DateTime.UtcNow.AddSeconds(Instance.RandomNumber(2, 3));
                        Log.WriteLine("Opening Inventory Window: waiting [" + Math.Round(Time.Instance.NextOpenHangarAction.Subtract(DateTime.UtcNow).TotalSeconds, 0) + "sec]");
                        return false;
                    }

                    return false;
                }

                if (Instance.PrimaryInventoryWindow != null)
                {
                    if (DebugConfig.DebugHangars) Log.WriteLine("Cache.Instance.InventoryWindow exists");
                    if (Instance.PrimaryInventoryWindow.IsReady)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("Cache.Instance.InventoryWindow exists and is ready");
                        return true;
                    }

                    return false;
                }

                return false;
            }

            return false;
        }

        public bool OpenMarket(string module)
        {
            if (DateTime.UtcNow < Time.Instance.NextWindowAction)
                return false;

            if (Instance.InStation)
            {
                Instance.MarketWindow = Instance.Windows.OfType<DirectMarketWindow>().FirstOrDefault();

                if (Instance.MarketWindow == null)
                {
                    if (!Instance.EveAccount.OkToInteractWithEveNow)
                    {
                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("OpenMarket: !OkToInteractWithEveNow");
                        return false;
                    }

                    if (Instance.DirectEve.ExecuteCommand(DirectCmd.OpenMarket))
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        Statistics.LogWindowActionToWindowLog("MarketWindow", "Opening MarketWindow");
                        Time.Instance.NextWindowAction = DateTime.UtcNow.AddSeconds(Instance.RandomNumber(2, 3));
                        Log.WriteLine("Opening Market Window: waiting [" + Math.Round(Time.Instance.NextWindowAction.Subtract(DateTime.UtcNow).TotalSeconds, 0) + "sec]");
                        return false;
                    }

                    return false;
                }

                return true;
            }

            return false;
        }

        #endregion Methods
    }
}