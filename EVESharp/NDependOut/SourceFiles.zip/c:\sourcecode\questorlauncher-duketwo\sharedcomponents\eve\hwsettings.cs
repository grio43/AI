﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 21.06.2014
 * Time: 11:00
 *
 * ---------------------------------------
 */

using SharedComponents.EVEAccountCreator;
using SharedComponents.IPC;
using SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;
using System.Xml.Serialization;

namespace SharedComponents.EVE
{
    /// <summary>
    ///     Description of HWSettings.
    /// </summary>
    [Serializable]
    public class HWSettings : ViewModelBase
    {
        #region Fields

        [NonSerialized] public static List<Tuple<string, string, string, string, string>> CPUProfiles = new List<Tuple<string, string, string, string, string>>
        {
            new Tuple<string, string, string, string, string>("Intel Core i5", "Intel64 Family 6 Model 158 Stepping 9, GenuineIntel", "9e09", "4", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i7 4790K", "Intel64 Family 6 Model 60 Stepping 3, GenuineIntel", "3c03", "8", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i5 3470", "Intel64 Family 6 Model 58 Stepping 9, GenuineIntel", "3a09", "4", "6"),
            new Tuple<string, string, string, string, string>("Intel Xeon v4", "Intel64 Family 6 Model 79 Stepping 1, GenuineIntel", "4f01", "3", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i7 2600K", "Intel64 Family 6 Model 42 Stepping 7, GenuineIntel", "2a07", "8", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i5 2400", "Intel64 Family 6 Model 42 Stepping 7, GenuineIntel", "2a07", "4", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i7 3930K", "Intel64 Family 6 Model 45 Stepping 7, GenuineIntel", "2d07", "12", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i5 6600", "Intel64 Family 6 Model 94 Stepping 3, GenuineIntel", "5e03", "4", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i7 3770K", "Intel64 Family 6 Model 58 Stepping 9, GenuineIntel", "3a09", "8", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i5 4670K", "Intel64 Family 6 Model 60 Stepping 3, GenuineIntel", "3c03", "4", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i5", "Intel64 Family 6 Model 78 Stepping 3, GenuineIntel", "4e03", "4", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i7 6700HQ", "Intel64 Family 6 Model 94 Stepping 3, GenuineIntel", "5e03", "8", "6"),
            new Tuple<string, string, string, string, string>("Intel Core i7 5820K", "Intel64 Family 6 Model 63 Stepping 2, GenuineIntel", "3f02", "12", "6"),
            new Tuple<string, string, string, string, string>("Intel Processor", "Intel64 Family 6 Model 79 Stepping 1, GenuineIntel", "4f01", "12", "6"),
            new Tuple<string, string, string, string, string>("AMD A10-6800K", "AMD64 Family 21 Model 19 Stepping 1, AuthenticAMD", "1301", "4", "21"),
            new Tuple<string, string, string, string, string>("AMD FX-8350", "AMD64 Family 21 Model 2 Stepping 0, AuthenticAMD", "0200", "8", "21"),
            new Tuple<string, string, string, string, string>("AMD FX-6300", "AMD64 Family 21 Model 2 Stepping 0, AuthenticAMD", "0200", "6", "21")
        };

        [NonSerialized] public static List<GPUDetail> GPUDetails = new List<GPUDetail>
        {
            new GPUDetail("AMD Radeon (TM) RX 570", "26591", "4098", "207", "23.20.15033.5003", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-249f-11cf-1360-bb0d74c2da35", "3/21/2018 5:00:00 PM"),
            new GPUDetail("AMD Radeon R7 Graphics", "39028", "4098", "204", "22.19.159.256", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-db34-11cf-9872-7d2770c2db35", "5/9/2017 7:00:00 PM"),
            new GPUDetail("AMD Radeon R9 200 Series", "26545", "4098", "0", "21.19.519.2", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-24f1-11cf-3075-92b0bcc2d835", "10/02/2017 00:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1050", "7297", "4318", "161", "23.21.13.8843", "11", "NVIDIA", "d7b71e3e-5fc1-11cf-e551-8c3c1bc2da35", "11/28/2017 02:55:41"),
            new GPUDetail("NVIDIA GeForce GTX 1050", "7297", "4318", "161", "23.21.13.9135", "11", "NVIDIA", "d7b71e3e-5fc1-11cf-c559-59041bc2da35", "3/26/2018 01:12:06"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "22.21.13.8569", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-135b-58341bc2db35", "16.09.2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "23.21.13.8813", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-8555-3f171bc2da35", "27.10.2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "22.21.13.8528", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-3e52-8f3c1bc2db35", "09.08.2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "22.21.13.8554", "11", "NVIDIA", "d7b71e3e-5fc2-11cf-b856-9bac1bc2db35", "9/2/2017 07:44:09"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "22.21.13.8569", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-135b-58341bc2db35", "16.09.2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "22.21.13.8569", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-135b-58341bc2db35", "16.09.2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "24.21.13.9907", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-417d-5c421bc2d535", "8/20/2018 5:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "22.21.13.8569", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-135b-58341bc2db35", "16.09.2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "23.21.13.9077", "12", "NVIDIA", "d7b71e3e-5fc2-11cf-bf57-53420fc2c535", "1/22/2018 7:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 1050 Ti", "7298", "4318", "161", "23.21.13.9077", "11", "NVIDIA", "d7b71e3e-5fc2-11cf-a754-9bac1bc2da35", "1/23/2018 19:19:35"),
            new GPUDetail("NVIDIA GeForce GTX 1060", "7264", "4318", "161", "21.21.13.7866", "12", "Intel Corporation", "d7b71e3e-5f20-11cf-226d-cd271bc2d835", "2/8/2017 7:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 1060 3GB", "7170", "4318", "161", "23.21.13.8813", "12", "NVIDIA", "d7b71e3e-5f42-11cf-8555-29171bc2da35", "10/26/2017 20:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1060 3GB", "7170", "4318", "161", "23.21.13.8813", "12", "NVIDIA", "d7b71e3e-5f42-11cf-8555-2c171bc2da35", "27.10.2017 3:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1060 6GB", "7171", "4318", "161", "22.21.13.8165", "11", "NVIDIA", "d7b71e3e-5f43-11cf-8b6c-da311bc2db35", "4/1/2017 05:20:54"),
            new GPUDetail("NVIDIA GeForce GTX 1060 6GB", "7171", "4318", "161", "22.21.13.8205", "12", "NVIDIA", "d7b71e3e-5f43-11cf-e557-1b171bc2db35", "01/05/2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1060 6GB", "7171", "4318", "161", "23.21.13.8859", "12", "NVIDIA", "d7b71e3e-5f43-11cf-4955-8c121bc2da35", "05.12.2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1060 6GB", "7171", "4318", "161", "23.21.13.9135", "12", "Intel Corporation", "d7b71e3e-5f43-11cf-3750-da311bc2da35", "3/22/2018 5:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 1060 6GB", "7171", "4318", "161", "24.21.13.9907", "12", "NVIDIA", "d7b71e3e-5f43-11cf-6151-8e121bc2d535", "8/21/2018 2:00:00 AM"),
            new GPUDetail("NVIDIA GeForce GTX 1060 6GB", "7171", "4318", "161", "23.21.13.9077", "12", "NVIDIA", "d7b71e3e-5f43-11cf-1b50-0e3c1bc2da35", "23.01.2018 01:00:00 Uhr"),
            new GPUDetail("NVIDIA GeForce GTX 1070", "7041", "4318", "161", "23.21.13.8871", "12", "NVIDIA", "d7b71e3e-58c1-11cf-5451-11a71bc2da35", "2017-12-15 01:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1070", "7073", "4318", "161", "23.21.13.9065", "12", "Intel Corporation", "d7b71e3e-58e1-11cf-f150-7c271bc2da35", "03.01.2018 01:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1070 Ti", "7042", "4318", "161", "24.21.13.9811", "12", "NVIDIA", "d7b71e3e-58c2-11cf-8151-0ee31bc2d535", "1/06/2018 2:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1070 Ti", "7042", "4318", "161", "23.21.13.9124", "12", "NVIDIA", "d7b71e3e-58c2-11cf-5750-13a61bc2da35", "2018-03-14 17:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1080", "7040", "4318", "161", "22.21.13.8205", "11", "NVIDIA", "d7b71e3e-58c0-11cf-ff7b-85421bc2db35", "5/2/2017 08:32:51"),
            new GPUDetail("NVIDIA GeForce GTX 1080", "7040", "4318", "161", "24.21.13.9811", "12", "NVIDIA", "d7b71e3e-58c0-11cf-a055-9fa51bc2d535", "1/06/2018 2:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1080", "7040", "4318", "161", "24.21.13.9882", "11", "NVIDIA", "d7b71e3e-58c0-11cf-687d-8b421bc2d535", "8/1/2018 05:47:14"),
            new GPUDetail("NVIDIA GeForce GTX 1080", "7040", "4318", "161", "22.21.13.8253", "12", "NVIDIA", "d7b71e3e-58c0-11cf-ef57-6f131bc2db35", "07-06-2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1080", "7040", "4318", "161", "22.21.13.8253", "12", "NVIDIA", "d7b71e3e-58c0-11cf-ef57-6f131bc2db35", "07-06-2017 02:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 1080 Ti", "6918", "4318", "161", "22.21.13.8205", "11", "NVIDIA", "d7b71e3e-5846-11cf-e557-5c171bc2db35", "5/1/2017 23:32:51"),
            new GPUDetail("NVIDIA GeForce GTX 1080 Ti", "6918", "4318", "161", "24.21.13.9836", "12", "NVIDIA", "d7b71e3e-5846-11cf-9e7d-9b461bc2d535", "6/23/2018 8:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 650", "4038", "4318", "161", "23.21.13.9101", "12", "NVIDIA", "d7b71e3e-4c86-11cf-5f54-04081bc2da35", "23.02.2018 7:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 745", "4994", "4318", "162", "23.21.13.8813", "12", "Intel Corporation", "d7b71e3e-50c2-11cf-0351-683018c2da35", "10/26/2017 7:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 745", "4994", "4318", "162", "23.21.13.8813", "12", "Intel Corporation", "d7b71e3e-50c2-11cf-0351-683018c2da35", "10/26/2017 7:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 760", "4487", "4318", "161", "21.21.13.7892", "11", "NVIDIA", "d7b71e3e-52c7-11cf-647d-0d201bc2d835", "3/17/2017 02:59:25"),
            new GPUDetail("NVIDIA GeForce GTX 770", "4484", "4318", "161", "21.21.13.7849", "11", "NVIDIA", "d7b71e3e-52c4-11cf-4169-0e161bc2d835", "1/20/2017 17:36:19"),
            new GPUDetail("NVIDIA GeForce GTX 960", "5121", "4318", "161", "23.21.13.8871", "12", "NVIDIA", "d7b71e3e-5741-11cf-5451-66a51bc2da35", "15.12.2017 01:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 960", "5121", "4318", "161", "23.21.13.8871", "12", "NVIDIA", "d7b71e3e-5741-11cf-5451-66a51bc2da35", "15.12.2017 01:00:00"),
            new GPUDetail("NVIDIA GeForce GTX 960", "5121", "4318", "161", "23.21.13.9135", "11", "NVIDIA", "d7b71e3e-5741-11cf-7d54-0c121bc2da35", "3/25/2018 12:12:06"),
            new GPUDetail("NVIDIA GeForce GTX 970", "5058", "4318", "161", "21.21.13.7878", "11", "NVIDIA", "d7b71e3e-5082-11cf-1469-6d111bc2d835", "2/23/2017 11:34:39"),
            new GPUDetail("NVIDIA GeForce GTX 970", "5058", "4318", "161", "23.21.13.8792", "11", "NVIDIA", "d7b71e3e-5082-11cf-8a55-6d111bc2da35", "10/6/2017 14:32:47"),
            new GPUDetail("NVIDIA GeForce GTX 970", "5058", "4318", "161", "23.21.13.9135", "12", "NVIDIA", "d7b71e3e-5082-11cf-4754-74161bc2da35", "3/22/2018 8:00:00 PM"),
            new GPUDetail("NVIDIA GeForce GTX 970", "5058", "4318", "161", "23.21.13.8813", "12", "NVIDIA", "d7b71e3e-5082-11cf-0758-6b331bc2da35", "10/27/2017 1:00:00 AM"),
            new GPUDetail("NVIDIA GeForce GTX 980", "5056", "4318", "161", "22.21.13.8233", "12", "NVIDIA", "d7b71e3e-5080-11cf-fb57-7d111bc2db35", "5/16/2017 8:00:00 PM"),
            new GPUDetail("Radeon 500 Series", "27039", "4098", "199", "22.19.147.0", "11", "Advanced Micro Devices, Inc.", "d7b71ee2-2adf-11cf-e877-60027bc2db35", "3/7/2017 01:07:26"),
            new GPUDetail("Radeon RX 550 Series", "27039", "4098", "199", "23.20.793.0", "11", "Advanced Micro Devices, Inc.", "d7b71ee2-2adf-11cf-d277-89a97cc2da35", "11/15/2017 21:46:04"),
            new GPUDetail("Radeon RX 550 Series", "27039", "4098", "199", "24.20.11001.5003", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-2adf-11cf-b966-a99f7cc2d535", "4/24/2018 6:00:00 PM"),
            new GPUDetail("Radeon RX 560 Series", "26607", "4098", "229", "23.20.15017.3010", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-24af-11cf-3178-e21f5ec2da35", "31.01.2018 1:00:00"),
            new GPUDetail("Radeon RX 560 Series", "26623", "4098", "207", "23.20.15017.3010", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-24bf-11cf-3178-981f74c2da35", "31.01.2018 3:00:00"),
            new GPUDetail("Radeon RX 560 Series", "26623", "4098", "207", "23.20.793.0", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-24bf-11cf-d277-88a974c2da35", "15.11.2017 3:00:00"),
            new GPUDetail("Radeon RX 560 Series", "26623", "4098", "207", "23.20.15007.1005", "11", "Advanced Micro Devices, Inc.", "d7b71ee2-24bf-11cf-3f74-0e9074c2da35", "12/18/2017 06:06:34"),
            new GPUDetail("Radeon RX 580 Series", "26591", "4098", "231", "24.20.11019.1004", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-249f-11cf-3e74-1c3f5cc2d535", "29.05.2018 02:00:00"),
            new GPUDetail("Radeon RX 580 Series", "26591", "4098", "231", "24.20.11021.1000", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-249f-11cf-d474-7a285cc2d535", "07.06.2018 3:00:00"),
            new GPUDetail("Radeon(TM) RX 460 Graphics", "26607", "4098", "207", "22.19.162.4", "12", "Advanced Micro Devices, Inc.", "d7b71ee2-24af-11cf-ec77-7f0273c2db35", "24.04.2017 3:00:00")
        };

        #endregion Fields

        #region Constructors

        public HWSettings(ulong totalPhysRam, string windowsUserLogin, string computername, string windowsKey, string networkAdapterGuid, string networkAddress,
            string macAddress, string processorIdent, string processorRev, string processorCoreAmount,
            string processorLevel, string gpuDescription, uint gpuDeviceId, uint gpuVendorId, uint gpuRevision,
            long gpuDriverversion, string gpuDriverversionInt, string gpuIdentifier, int proxyId,
            string machineGuid, ulong systemReservedMemory, string launcherMachineHash, DateTime gpuDriverDate, string gpuManufacturer)
        {
            TotalPhysRam = totalPhysRam;
            WindowsUserLogin = windowsUserLogin;
            Computername = computername;
            WindowsKey = windowsKey;
            NetworkAdapterGuid = networkAdapterGuid;
            MacAddress = macAddress;
            NetworkAddress = networkAddress;
            ProcessorIdent = processorIdent;
            ProcessorRev = processorRev;
            ProcessorCoreAmount = processorCoreAmount;
            ProcessorLevel = processorLevel;
            GpuDescription = gpuDescription;
            GpuDeviceId = gpuDeviceId;
            GpuVendorId = gpuVendorId;
            GpuRevision = gpuRevision;
            GpuDriverversion = gpuDriverversion;
            GpuDriverversionInt = gpuDriverversionInt;
            GpuIdentifier = gpuIdentifier;
            ProxyId = proxyId;
            MachineGuid = machineGuid;
            SystemReservedMemory = systemReservedMemory;
            LauncherMachineHash = launcherMachineHash;
            GpuDriverDate = gpuDriverDate;
            GpuManufacturer = gpuManufacturer;
        }

        public HWSettings()
        {
        }

        #endregion Constructors

        #region Properties

        public string Computername
        {
            get { return GetValue(() => Computername); }
            set { SetValue(() => Computername, value); }
        }

        public string GpuDescription
        {
            get { return GetValue(() => GpuDescription); }
            set { SetValue(() => GpuDescription, value); }
        }

        public uint GpuDeviceId
        {
            get { return GetValue(() => GpuDeviceId); }
            set { SetValue(() => GpuDeviceId, value); }
        }

        public DateTime GpuDriverDate
        {
            get { return GetValue(() => GpuDriverDate); }
            set { SetValue(() => GpuDriverDate, value); }
        }

        public long GpuDriverversion
        {
            get { return GetValue(() => GpuDriverversion); }
            set { SetValue(() => GpuDriverversion, value); }
        }

        public string GpuDriverversionInt
        {
            get { return GetValue(() => GpuDriverversionInt); }
            set
            {
                SetValue(() => GpuDriverversionInt, value);
                long currentVal = GpuDriverversion;
                try
                {
                    if (value.Contains("."))
                    {
                        long res = GPUDriverHelpers.ConvertGpuDriverStringToLong(value);
                        currentVal = res;
                        GpuDriverversion = currentVal;
                    }
                }
                catch (Exception ex)
                {
                    GpuDriverversion = currentVal;
                    Cache.Instance.Log("GpuDriverversionInt Exception: " + ex);
                }
            }
        }

        public string GpuIdentifier
        {
            get { return GetValue(() => GpuIdentifier); }
            set { SetValue(() => GpuIdentifier, value); }
        }

        public string GpuManufacturer
        {
            get { return GetValue(() => GpuManufacturer); }
            set { SetValue(() => GpuManufacturer, value); }
        }

        public uint GpuRevision
        {
            get { return GetValue(() => GpuRevision); }
            set { SetValue(() => GpuRevision, value); }
        }

        public uint GpuVendorId
        {
            get { return GetValue(() => GpuVendorId); }
            set { SetValue(() => GpuVendorId, value); }
        }

        public string LauncherMachineHash
        {
            get { return GetValue(() => LauncherMachineHash); }
            set { SetValue(() => LauncherMachineHash, value); }
        }

        public string MacAddress
        {
            get { return GetValue(() => MacAddress); }
            set { SetValue(() => MacAddress, value); }
        }

        public string MachineGuid
        {
            get { return GetValue(() => MachineGuid); }
            set { SetValue(() => MachineGuid, value); }
        }

        public string NetworkAdapterGuid
        {
            get { return GetValue(() => NetworkAdapterGuid); }
            set { SetValue(() => NetworkAdapterGuid, value); }
        }

        public string NetworkAddress
        {
            get { return GetValue(() => NetworkAddress); }
            set { SetValue(() => NetworkAddress, value); }
        }

        public string ProcessorCoreAmount
        {
            get { return GetValue(() => ProcessorCoreAmount); }
            set { SetValue(() => ProcessorCoreAmount, value); }
        }

        public string ProcessorIdent
        {
            get { return GetValue(() => ProcessorIdent); }
            set { SetValue(() => ProcessorIdent, value); }
        }

        public string ProcessorLevel
        {
            get { return GetValue(() => ProcessorLevel); }
            set { SetValue(() => ProcessorLevel, value); }
        }

        public string ProcessorRev
        {
            get { return GetValue(() => ProcessorRev); }
            set { SetValue(() => ProcessorRev, value); }
        }

        [XmlIgnore]
        public Proxy Proxy
        {
            get
            {
                if (Cache.IsServer)
                    return Cache.Instance.EveSettings.Proxies.FirstOrDefault(p => p.Id == ProxyId);
                return WCFClient.Instance.GetPipeProxy.GetProxy(ProxyId);
            }
            set
            {
                try
                {
                    ProxyId = value.Id;
                }
                catch (Exception e)
                {
                    Cache.Instance.Log("Exception: " + e);
                }
            }
        }

        public int ProxyId
        {
            get { return GetValue(() => ProxyId); }
            set { SetValue(() => ProxyId, value); }
        }

        public ulong SystemReservedMemory
        {
            get { return GetValue(() => SystemReservedMemory); }
            set { SetValue(() => SystemReservedMemory, value); }
        }

        public ulong TotalPhysRam
        {
            get { return GetValue(() => TotalPhysRam); }
            set { SetValue(() => TotalPhysRam, value); }
        }

        public string WindowsKey
        {
            get { return GetValue(() => WindowsKey); }
            set { SetValue(() => WindowsKey, value); }
        }

        public string WindowsUserLogin
        {
            get { return GetValue(() => WindowsUserLogin); }
            set { SetValue(() => WindowsUserLogin, value); }
        }

        #endregion Properties

        #region Methods

        public bool CheckEquality(object value, bool excludeProxies = false)
        {
            if (!(value is HWSettings))
                return false;

            HWSettings p = (HWSettings) value;

            if (WindowsUserLogin == p.WindowsUserLogin)
            {
                Debug.WriteLine($"{nameof(WindowsUserLogin)} equal.");
                return true;
            }

            if (Computername == p.Computername)
            {
                Debug.WriteLine($"{nameof(Computername)} equal.");
                return true;
            }

            if (WindowsKey == p.WindowsKey)
            {
                Debug.WriteLine($"{nameof(WindowsKey)} equal.");
                return true;
            }

            if (NetworkAdapterGuid == p.NetworkAdapterGuid)
            {
                Debug.WriteLine($"{nameof(NetworkAdapterGuid)} equal.");
                return true;
            }

            if (MacAddress == p.MacAddress)
            {
                Debug.WriteLine($"{nameof(MacAddress)} equal.");
                return true;
            }

            if (GpuIdentifier == p.GpuIdentifier)
            {
                Debug.WriteLine($"{nameof(GpuIdentifier)} equal.");
                return true;
            }

            if (MachineGuid == p.MachineGuid)
            {
                Debug.WriteLine($"{nameof(MachineGuid)} equal.");
                return true;
            }

            if (LauncherMachineHash == p.LauncherMachineHash)
            {
                Debug.WriteLine($"{nameof(LauncherMachineHash)} equal.");
                return true;
            }

            if (!excludeProxies && ProxyId > 0 && ProxyId == p.ProxyId)
            {
                Debug.WriteLine($"{nameof(ProxyId)} equal.");
                return true;
            }

            return false;
        }

        public HWSettings Clone()
        {
            using (MemoryStream stream = new MemoryStream())
            {
                if (GetType().IsSerializable)
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(stream, this);
                    stream.Position = 0;
                    return (HWSettings) formatter.Deserialize(stream);
                }
                return null;
            }
        }

        public void GenerateRandomGpuProfile()
        {
            Random rnd = new Random();
            GPUDetail gpuProfile = GPUDetails[rnd.Next(GPUDetails.Count)];
            GpuIdentifier = gpuProfile.DeviceIdentifier;
            GpuDescription = gpuProfile.CardName;
            GpuDeviceId = Convert.ToUInt32(gpuProfile.DeviceId);
            GpuVendorId = Convert.ToUInt32(gpuProfile.VendorId);
            GpuRevision = Convert.ToUInt32(gpuProfile.RevisionId);
            GpuDriverversionInt = gpuProfile.DriverVersion;
            GpuManufacturer = gpuProfile.Manufacturer;
            GpuDriverDate = gpuProfile.DriverDateTime.Value;
        }

        public void GenerateRandomProfile()
        {
            ConcurrentBindingList<EveAccount> list = Cache.Instance.EveAccountSerializeableSortableBindingList.List;
            bool first = true;
            Random rnd = new Random();
            while (first || list.Any(e => e != null && e.HWSettings != null && e.HWSettings != this && e.HWSettings.CheckEquality(this, true)))
            {
                first = false;
                string name = UserPassGen.Instance.GenerateFirstname();
                TotalPhysRam = Convert.ToUInt64(GenerateRamSize());
                WindowsUserLogin = name;
                Computername = name + "-PC";
                WindowsKey = GenerateWindowsKey();
                MachineGuid = Guid.NewGuid().ToString();
                NetworkAdapterGuid = Guid.NewGuid().ToString();
                NetworkAddress = GenerateIpAddress();
                MacAddress = GenerateMacAddress();
                SystemReservedMemory = (ulong) (2 * new Random().Next(8 / 2, 100 / 2));

                Tuple<string, string, string, string, string> cpuProfile = CPUProfiles[rnd.Next(CPUProfiles.Count)];

                ProcessorIdent = cpuProfile.Item2;
                ProcessorRev = cpuProfile.Item3;
                ProcessorCoreAmount = cpuProfile.Item4;
                ProcessorLevel = cpuProfile.Item5;
                LauncherMachineHash = LauncherHash.GetRandomLauncherHash().Item1;

                GPUDetail gpuProfile = GPUDetails[rnd.Next(GPUDetails.Count)];
                GpuIdentifier = gpuProfile.DeviceIdentifier;
                GpuDescription = gpuProfile.CardName;
                GpuDeviceId = Convert.ToUInt32(gpuProfile.DeviceId);
                GpuVendorId = Convert.ToUInt32(gpuProfile.VendorId);
                GpuRevision = Convert.ToUInt32(gpuProfile.RevisionId);
                GpuDriverversionInt = gpuProfile.DriverVersion;
                GpuManufacturer = gpuProfile.Manufacturer;
                GpuDriverDate = gpuProfile.DriverDateTime.Value;
            }
        }

        public void ParseCPUDetails(string content)
        {
            try
            {
                // google:  -inurl "piriform.com/results/"

                string PROCESSOR_LEVEL = string.Empty;
                string PROCESSOR_IDENTIFIER = string.Empty;
                string NUMBER_OF_PROCESSORS = string.Empty;
                string PROCESSOR_REVISION = string.Empty;
                string CPU_NAME = string.Empty;

                Match match;

                try
                {
                    match = Regex.Match(content, @"CPU[\r\n]+([^\r\n]+)");
                    if (match.Success)
                        CPU_NAME = match.NextMatch().Groups[1].Value;
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e);
                }

                match = Regex.Match(content, @"(?<=PROCESSOR_LEVEL: ).*");
                if (match.Success)
                    PROCESSOR_LEVEL = match.Value.Trim();

                match = Regex.Match(content, @"(?<=PROCESSOR_IDENTIFIER: ).*");
                if (match.Success)
                    PROCESSOR_IDENTIFIER = match.Value.Trim();

                match = Regex.Match(content, @"(?<=NUMBER_OF_PROCESSORS: ).*");
                if (match.Success)
                    NUMBER_OF_PROCESSORS = match.Value.Trim();

                match = Regex.Match(content, @"(?<=PROCESSOR_REVISION: ).*");
                if (match.Success)
                    PROCESSOR_REVISION = match.Value.Trim();

                //Debug.WriteLine($"{CPU_NAME} - {PROCESSOR_LEVEL} - {PROCESSOR_IDENTIFIER} - {NUMBER_OF_PROCESSORS} - {PROCESSOR_REVISION}");

                //                ProcessorIdent = "Intel64 Family 6 Model 26 Stepping 5, GenuineIntel";
                //                ProcessorRev = "6661";
                //                ProcessorCoreAmount = "8";
                //                ProcessorLevel = "6";

                Debug.WriteLine($"new Tuple<string, string, string, string, string>(\"{CPU_NAME}\", \"{PROCESSOR_IDENTIFIER}\", \"{PROCESSOR_REVISION}\", \"{NUMBER_OF_PROCESSORS}\", \"{PROCESSOR_LEVEL}\"),");
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ParseDXDiagFile Exception: " + ex);
            }
        }

        public void ParseDXDiagFile(string content)
        {
            try
            {
                GPUDetail gpuDetail = GPUDetail.ParseDXDiagFile(content);
                if (gpuDetail != null)
                {
                    GpuDescription = gpuDetail.CardName;
                    GpuDeviceId = Convert.ToUInt32(gpuDetail.DeviceId);
                    GpuVendorId = Convert.ToUInt32(gpuDetail.VendorId);
                    GpuRevision = Convert.ToUInt32(gpuDetail.RevisionId);
                    GpuDriverversionInt = gpuDetail.DriverVersion;
                    GpuIdentifier = gpuDetail.DeviceIdentifier;
                    GpuManufacturer = gpuDetail.Manufacturer;
                    GpuDriverDate = gpuDetail.DriverDateTime.Value;
                }
                else
                {
                    Cache.Instance.Log("ParseDXDiagFile Error.");
                }
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("ParseDXDiagFile Exception: " + ex);
            }
        }

        private string GenerateIpAddress()
        {
            Random random = new Random();
            string text = string.Concat("192.168.", random.Next(0, 255), ".", random.Next(1, 255));
            return text;
        }

        private string GenerateMacAddress()
        {
            Random random = new Random();
            byte[] array = new byte[6];
            random.NextBytes(array);
            string text = string.Concat((
                from byte_0 in array
                select string.Format("{0}-", byte_0.ToString("X2"))).ToArray());
            return text.TrimEnd('-');
        }

        private string GenerateRamSize()
        {
            Random random = new Random();
            string[] sizes = {"8192", "16384"};
            return sizes[random.Next(sizes.Length)];
        }

        private string GenerateWindowsKey()
        {
            Random random = new Random();
            string text = string.Concat("00", random.Next(100, 1000), "-OEM-", random.Next(1000000, 9999999), "-00", random.Next(100, 999));

            return text;
        }

        public bool IsItSafeToStartEve
        {
            get
            {
                if (Proxy == null)
                {
                    Cache.Instance.Log("HWSettings: Proxy == null. Error.");
                    return false;
                }

                if (Proxy == null || !Proxy.IsValid)
                {
                    Cache.Instance.Log("HWSettings: !Proxy.IsValid. Error.");
                    return false;
                }

                if (string.IsNullOrWhiteSpace(Computername))
                {
                    Cache.Instance.Log("HWSettings: Hardware profile usage is now required. Please setup a different hardware profile for each account or use the same profile for accounts you want to link together.");
                    return false;
                }

                if (string.IsNullOrEmpty(LauncherMachineHash))
                {
                    Cache.Instance.Log("HWSettings: LauncherMachineHash missing. You need to open the HWProfile form once to generate a LauncherMachineHash.");
                    return false;
                }

                if (string.IsNullOrEmpty(GpuManufacturer) || GpuDriverDate == null || GpuDriverDate == DateTime.MinValue)
                {
                    Cache.Instance.Log("HWSettings: You need to generate a new GPU profile for this account.");
                    return false;
                }

                return true;
            }
        }

        #endregion Methods
    }
}