extern alias SC;
using System;
using System.ServiceModel;
using System.Threading;
using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Controllers.ActionQueue.Actions;
using EVESharpCore.Logging;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.IPC;

namespace EVESharpCore
{
    [CallbackBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant, UseSynchronizationContext = false)]
    public class LauncherCallback : IDuplexServiceCallback
    {
        #region Methods

        public void GotoHomebaseAndIdle()
        {
            Log.WriteLine("Settings.Instance.AutoStart = false, CurrentCombatMissionBehaviorState  = CombatMissionsBehaviorState.GotoBase");
            ESCache.Instance.PauseAfterNextDock = true;
            string msg = string.Format("Set [{0}] going to homebase and idle.", ESCache.Instance.EveAccount.MaskedCharacterName);
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                msg = string.Format("Set [{0}] We are in AbyssalDeadspace: setting PauseAfterNextDock to true instead", ESCache.Instance.EveAccount.MaskedCharacterName);
                WCFClient.Instance.GetPipeProxy.RemoteLog(msg);
                return;
            }

            State.CurrentQuestorState = QuestorState.Start;
            State.CurrentTravelerState = TravelerState.Idle;
            State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.GotoBase;
            Traveler.Destination = null;
            WCFClient.Instance.GetPipeProxy.RemoteLog(msg);
        }

        public void GotoJita()
        {
            new Thread(() =>
            {
                try
                {
                    if (ControllerManager.Instance.GetController<ActionQueueController>().IsActionQueueEmpty)
                    {
                        string msg = string.Format("Set [{0}] going to Jita and pause.", ESCache.Instance.EveAccount.MaskedCharacterName);
                        WCFClient.Instance.GetPipeProxy.RemoteLog(msg);
                        Log.WriteLine("Adding GotoJitaAction");
                        new GotoJitaAction().Initialize().QueueAction();
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception:" + ex);
                }
            }).Start();
        }

        public void OnCallback()
        {
        }

        public void PauseAfterNextDock()
        {
            ESCache.Instance.PauseAfterNextDock = true;
            string msg = string.Format("Set [{0}] to pause after next station dock.", ESCache.Instance.EveAccount.MaskedCharacterName);
            WCFClient.Instance.GetPipeProxy.RemoteLog(msg);
        }

        #endregion Methods
    }
}