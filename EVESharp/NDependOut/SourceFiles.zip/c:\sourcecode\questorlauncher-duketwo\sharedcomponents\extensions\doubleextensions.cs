﻿using System;

namespace SharedComponents.Extensions
{
    public static class DoubleExtensions
    {
        #region Methods

        public static bool AlmostEqualsWithAbsTolerance(this double a, double b, double maxAbsoluteError)
        {
            double diff = Math.Abs(a - b);

            if (a.Equals(b))
                return true;

            return diff <= maxAbsoluteError;
        }

        #endregion Methods
    }
}