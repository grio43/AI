﻿extern alias SC;

using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Framework.Events;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Actions;
using EVESharpCore.Questor.Activities;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.Storylines;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.Events;
using SC::SharedComponents.IPC;
using SC::SharedComponents.Py.D3DDetour;
using SC::SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace EVESharpCore.Cache
{
    public partial class ESCache
    {
        #region Constructors

        private ESCache()
        {
            LastModuleTargetIDs = new Dictionary<long, long>();
            TargetingIDs = new Dictionary<long, DateTime>();
            _entitiesById = new Dictionary<long, EntityCache>();

            LootedContainers = new HashSet<long>();
        }

        #endregion Constructors

        #region Fields

        public static Random _random = new Random();
        public static DateTime NextSlotActivate = DateTime.UtcNow;
        public DirectContainer _fittedModules;
        //public bool _isCorpInWar = false;
        public int? _weaponRange;
        public HashSet<long> ListNeutralizingEntities = new HashSet<long>();
        public HashSet<long> ListofContainersToLoot = new HashSet<long>();
        public HashSet<long> ListOfDampenuingEntities = new HashSet<long>();
        public HashSet<long> ListofEntitiesToEcm = new HashSet<long>();
        public HashSet<long> ListofEntitiesToTrackingDisrupt = new HashSet<long>();
        public HashSet<long> ListOfJammingEntities = new HashSet<long>();
        public HashSet<string> ListofMissionCompletionItemsToLoot = new HashSet<string>();
        public HashSet<long> ListOfTargetPaintingEntities = new HashSet<long>();
        public HashSet<long> ListOfTrackingDisruptingEntities = new HashSet<long>();
        public HashSet<long> ListofWebbingEntities = new HashSet<long>();
        public bool MissionBookmarkTimerSet;
        public DirectLocation MissionSolarSystem;
        public bool NormalNavigation = true;
        public string OrbitEntityNamed;
        public bool RouteIsAllHighSecBool;
        private readonly Dictionary<long, EntityCache> _entitiesById;
        private List<EntityCache> _abyssalBigObjects;
        private List<EntityCache> _AbyssalDeadspaceBioluminescenceCloud;
        private List<EntityCache> _AbyssalDeadspaceCausticCloud;
        private List<EntityCache> _AbyssalDeadspaceDeviantAutomataSuppressor;
        private List<EntityCache> _AbyssalDeadspaceFilamentCloud;
        private List<EntityCache> _AbyssalDeadspaceMultibodyTrackingPylon;
        private List<EntityCache> _bigObjectsAndGates;
        private List<EntityCache> _containers;
        private DirectContainer _currentShipsCargo;
        private DirectContainer _currentShipsFleetHangar;
        private DirectContainer _currentShipsModules;
        private DirectContainer _currentShipsOreHold;
        private EveAccount _eveAccount;
        private EveSetting _eveSetting;
        private List<EntityCache> _gates;
        private bool? _inAbyssalDeadspace;
        private bool? _inMission;
        private bool? _insidePosForceField;
        private int? _maxLockedTargets;
        private List<ModuleCache> _modules;
        private DirectItem _myCurrentAmmoInWeapon;
        //private List<EntityCache> _objects;
        private List<DirectBookmark> _safeSpotBookmarks;
        private EntityCache _star;
        private EntityCache _stargate;
        private List<EntityCache> _stargates { get; set; }
        private List<EntityCache> _targeting;
        private List<EntityCache> _targets;
        private List<EntityCache> _unlootedContainers;
        private List<EntityCache> _unlootedWrecksAndSecureCans;
        private IEnumerable<ModuleCache> _weapons;
        private List<DirectWindow> _windows;
        public static bool LootAlreadyUnloaded { get; set; }

        #endregion Fields

        #region Properties

        public static D3DVersion D3DVersion { get; set; }
        public static ESCache Instance { get; } = new ESCache();

        public static Storyline Storyline { get; set; }
        public DirectActiveShip ActiveShip
        {
            get
            {
                if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                    return null;

                return Instance.DirectEve.ActiveShip;
            }
        }

        public bool AfterMissionSalvaging { get; set; }
        //public bool AttemptingToWarp { get; set; }
        public string CharName { get; set; }
        public DirectContainer ContainerInSpace { get; set; }
        public string CurrentPocketAction { get; set; }

        public DirectContainer CurrentShipsCargo
        {
            get
            {
                try
                {
                    if (Time.Instance.NextJumpAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsCargo: if (Time.Instance.NextJumpAction > DateTime.UtcNow) return");
                        return null;
                    }

                    if (Time.Instance.NextDockAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsCargo: if (Time.Instance.NextDockAction > DateTime.UtcNow) return;");
                        return null;
                    }

                    if (!InSpace && !InStation) return null;

                    if (Instance.Windows != null && Instance.Windows.Any())
                    {
                        if (_currentShipsCargo == null)
                        {
                            if (Time.Instance.NextOpenCargoAction > DateTime.UtcNow)
                            {
                                if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsCargo: if (Time.Instance.NextOpenCargoAction > DateTime.UtcNow)");
                                return null;
                            }

                            _currentShipsCargo = Instance.DirectEve.GetShipsCargo();
                        }

                        return _currentShipsCargo;
                    }

                    _currentShipsCargo = null;
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Unable to complete ReadyCargoHold [" + exception + "]");
                    return null;
                }
            }
        }

        public DirectContainer CurrentShipsFleetHangar
        {
            get
            {
                try
                {
                    if (Time.Instance.NextJumpAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsFleetHangar: if (Time.Instance.NextJumpAction > DateTime.UtcNow) return");
                        return null;
                    }

                    if (Time.Instance.NextDockAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsFleetHangar: if (Time.Instance.NextDockAction > DateTime.UtcNow) return;");
                        return null;
                    }

                    if (!InSpace && !InStation) return null;

                    if (Instance.Windows != null && Instance.Windows.Any())
                    {
                        if (_currentShipsFleetHangar == null)
                            _currentShipsFleetHangar = Instance.DirectEve.GetShipsFleetHangar();

                        return _currentShipsFleetHangar;
                    }

                    _currentShipsFleetHangar = null;
                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public DirectContainer CurrentShipsModules
        {
            get
            {
                try
                {
                    if (Time.Instance.LastInWarp.AddSeconds(3) > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsModules: if (Time.Instance.LastInWarp.AddSeconds(10) > DateTime.UtcNow) return;");
                        return null;
                    }

                    if (Time.Instance.NextJumpAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsModules: if (Time.Instance.NextJumpAction > DateTime.UtcNow) return");
                        return null;
                    }

                    if (Time.Instance.NextDockAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsModules: if (Time.Instance.NextDockAction > DateTime.UtcNow) return;");
                        return null;
                    }

                    if (!InSpace && !InStation) return null;

                    if (Instance.Windows != null && Instance.Windows.Any())
                    {
                        if (_currentShipsModules == null)
                        {
                            _currentShipsModules = Instance.DirectEve.GetShipsCargo();
                            return _currentShipsModules;
                        }

                        return _currentShipsModules;
                    }

                    _currentShipsModules = null;
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Unable to complete CurrentShipsModules [" + exception + "]");
                    return null;
                }
            }
        }

        public DirectContainer CurrentShipsOreHold
        {
            get
            {
                try
                {
                    if (Time.Instance.NextJumpAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsOreHold: if (Time.Instance.NextJumpAction > DateTime.UtcNow) return");
                        return null;
                    }

                    if (Time.Instance.NextDockAction > DateTime.UtcNow)
                    {
                        if (DebugConfig.DebugHangars) Log.WriteLine("CurrentShipsOreHold: if (Time.Instance.NextDockAction > DateTime.UtcNow) return;");
                        return null;
                    }

                    if (!InSpace && !InStation) return null;

                    if (Instance.Windows != null && Instance.Windows.Any())
                    {
                        if (_currentShipsOreHold == null)
                            _currentShipsOreHold = Instance.DirectEve.GetShipsOreHold();

                        return _currentShipsOreHold;
                    }

                    _currentShipsOreHold = null;
                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public DirectEve DirectEve { get; set; }

        public EveAccount EveAccount
        {
            get
            {
                if (_eveAccount == null)
                    try
                    {
                        _eveAccount = WCFClient.Instance.GetPipeProxy.GetEveAccount(CharName);
                        CancellationTokenSource eveAccountTokenSource = new CancellationTokenSource();
                        Task.Run(() =>
                        {
                            while (!eveAccountTokenSource.Token.IsCancellationRequested)
                            {
                                eveAccountTokenSource.Token.WaitHandle.WaitOne(2000);
                                try
                                {
                                    EveAccount r = WCFClient.Instance.GetPipeProxy.GetEveAccount(CharName);
                                    if (r != null)
                                        _eveAccount = r;
                                }
                                catch (Exception e)
                                {
                                    Log.WriteLine(e.ToString());
                                }
                            }
                        }, eveAccountTokenSource.Token);
                    }
                    catch (Exception ex)
                    {
                        if (InStation)
                        {
                            Instance.CloseQuestor("Exception in EveAccount");
                            Log.WriteLine("Exception [" + ex + "]");
                        }
                    }
                return _eveAccount;
            }
        }

        public EveSetting EveSetting
        {
            get
            {
                if (_eveSetting == null)
                    try
                    {
                        _eveSetting = WCFClient.Instance.GetPipeProxy.GetEVESettings();
                        CancellationTokenSource eveSettingTokenSource = new CancellationTokenSource();
                        Task.Run(() =>
                        {
                            while (!eveSettingTokenSource.Token.IsCancellationRequested)
                            {
                                eveSettingTokenSource.Token.WaitHandle.WaitOne(10000);
                                try
                                {
                                    EveSetting r = WCFClient.Instance.GetPipeProxy.GetEVESettings();
                                    if (r != null)
                                        _eveSetting = r;
                                }
                                catch (Exception e)
                                {
                                    Log.WriteLine(e.ToString());
                                }
                            }
                        }, eveSettingTokenSource.Token);
                    }
                    catch (Exception e)
                    {
                        Log.WriteLine(e.ToString());
                    }
                return _eveSetting;
            }
        }

        public DirectContainer FittedModules
        {
            get
            {
                try
                {
                    if (_fittedModules == null)
                        _fittedModules = Instance.DirectEve.GetShipsModules();

                    return _fittedModules;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public bool InWormHoleSpace
        {
            get
            {
                if (InStation && !InSpace)
                    return false;

                if (!InStation && !InSpace)
                    return false;

                if (ESCache.Instance.InAbyssalDeadspace)
                    return false;

                if (Stargates.Any())
                    return false;

                return true;
            }
        }

        public List<EntityCache> Planets
        {
            get
            {
                if (Entities == null || !Entities.Any())
                    return new List<EntityCache>();

                if (Entities.Any(i => i.GroupId == (int)Group.Planet))
                {
                    return Entities.Where(i => i.GroupId == (int)Group.Planet).ToList();
                }

                return new List<EntityCache>();
            }
        }

        public EntityCache ClosestPlanet
        {
            get
            {
                if (Planets == null || !Planets.Any())
                    return null;

                if (Planets.Any())
                    return Planets.OrderBy(i => i.Distance).FirstOrDefault();

                return null;
            }
        }

        public bool InAnomaly
        {
            get
            {
                if (InAbyssalDeadspace)
                    return false;

                if (Stargates.Any(i => i.IsOnGridWithMe))
                    return false;

                if (Entities.Any(i => i.IsStation && i.IsOnGridWithMe))
                    return false;

                if (Entities.Any(i => i.TypeId == (int)TypeID.Beacon && (long)Distances.FourAu > i.DistanceFromEntity(ClosestPlanet)))
                    return true;

                return false;
            }
        }

        public bool InAbyssalDeadspace
        {
            get
            {
                if (_inAbyssalDeadspace == null)
                {
                    if (Instance.InSpace)
                    {
                        //if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("We are In Space");
                        if (Instance.EntitiesNotSelf != null && Instance.EntitiesNotSelf.Any())
                        {
                            if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("We have [" + Instance.EntitiesNotSelf.Count() + "] entities on grid");
                            if (Instance.Stargates == null || !Instance.Stargates.Any())
                            {
                                if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("We have no stargates: this must be either w-Space or AbyssalDeadspace");
                                if (Instance.Star == null)
                                {
                                    //
                                    // this must be abyssal deadspace
                                    //
                                    if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("We have no star: this must be AbyssalDeadspace");
                                    _inAbyssalDeadspace = true;
                                    if (!EveAccount.InAbyssalDeadspace) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, nameof(EveAccount.InAbyssalDeadspace), _inAbyssalDeadspace);
                                    DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "InAbyssalDeadSpace"));
                                    return (bool)_inAbyssalDeadspace;
                                }

                                _inAbyssalDeadspace = false;
                                if (EveAccount.InAbyssalDeadspace)
                                {
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, "AbyssalPocketNumber", 0);
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, nameof(EveAccount.InAbyssalDeadspace), _inAbyssalDeadspace);
                                }

                                return (bool)_inAbyssalDeadspace;
                            }

                            _inAbyssalDeadspace = false;
                            if (EveAccount.InAbyssalDeadspace)
                            {
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, "AbyssalPocketNumber", 0);
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, nameof(EveAccount.InAbyssalDeadspace), _inAbyssalDeadspace);
                            }

                            return (bool)_inAbyssalDeadspace;
                        }

                        _inAbyssalDeadspace = false;
                        if (EveAccount.InAbyssalDeadspace)
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, "AbyssalPocketNumber", 0);
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, nameof(EveAccount.InAbyssalDeadspace), _inAbyssalDeadspace);
                        }

                        return (bool)_inAbyssalDeadspace;
                    }

                    _inAbyssalDeadspace = false;
                    if (EveAccount.InAbyssalDeadspace)
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, "AbyssalPocketNumber", 0);
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, nameof(EveAccount.InAbyssalDeadspace), _inAbyssalDeadspace);
                    }

                    return (bool)_inAbyssalDeadspace;
                }

                return _inAbyssalDeadspace ?? false;
            }
        }

        public bool InMission
        {
            get
            {
                try
                {
                    if (Time.Instance.QuestorStarted_DateTime.AddSeconds(45) > DateTime.UtcNow)
                        return false;

					if (_inMission != null) return _inMission ?? false;

                    if (InWarp)
                        SetInMissionState(false);

                    if (InStation)
                        SetInMissionState(false);

                    if (InAbyssalDeadspace)
                        SetInMissionState(InAbyssalDeadspace);

                    if (Instance.EveAccount.SelectedController.Contains("Courier"))
                        SetInMissionState(false);

                    EntityCache station = null;
                    if (Instance.Stations != null)
                        station = Instance.Stations.OrderBy(s => s.Distance).FirstOrDefault();

                    EntityCache stargate = null;
                    if (Instance.Stargates != null)
                        stargate = Instance.Stargates.OrderBy(s => s.Distance).FirstOrDefault();

                    EntityCache star = null;
                    if (Instance.Star != null)
                        star = Instance.Star;

                    EntityCache asteroidbelt = null;
                    if (Instance.Entities != null && Instance.Entities.Any(i => i.IsAsteroidBelt))
                        asteroidbelt = Instance.Entities.FirstOrDefault(i => i.IsAsteroidBelt);

                    if (_inMission == null && station != null && station.Distance < 8000000)
                        SetInMissionState(false);

                    if (_inMission == null && stargate != null && stargate.Distance < 1000000)
                        SetInMissionState(false);

                    if (_inMission == null && asteroidbelt != null && asteroidbelt.Distance < 100000)
                        SetInMissionState(false);

                    if (_inMission == null && star != null && star.Distance < 50000)
                        SetInMissionState(false);

                    if (_inMission == null && Weapons == null || Weapons != null && !Weapons.Any())
                        SetInMissionState(false);

                    if (_inMission == null && ESCache.Instance.AccelerationGates != null && ESCache.Instance.AccelerationGates.Any())
                        SetInMissionState(true);

                    if (_inMission == null) SetInMissionState(true);
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.InMission), _inMission);
                    return _inMission ?? true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

            //set => _inMission = value;
        }

        public bool InsidePosForceField
        {
            get
            {
                try
                {
                    if (_insidePosForceField == null)
                    {
                        _insidePosForceField = Instance.EntitiesOnGrid.Where(i => i.Distance < 60000).Any(b => b.GroupId == (int)Group.ForceField && b.Distance <= 0);
                        if (_insidePosForceField != null && (bool)_insidePosForceField)
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.IsSafeInPOS), true);
                        else if (EveAccount.IsSafeInPOS)
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.IsSafeInPOS), false);

                        return _insidePosForceField ?? false;
                    }

                    return _insidePosForceField ?? false;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public Dictionary<long, long> LastModuleTargetIDs { get; }

        public HashSet<long> LootedContainers { get; }

        private List<EntityCache> _myFleetMembersAsEntities;

        private List<EntityCache> _myCorpMatesAsEntities;

        public IEnumerable<EntityCache> MyCorpMatesAsEntities
        {
            get
            {
                if (_myCorpMatesAsEntities == null)
                {
                    _myCorpMatesAsEntities = new List<EntityCache>();
                    int intCorpmember = 0;
                    int intLocalmember = 0;
                    DirectCharacter myCharacterInLocal = Instance.DirectEve.Session.CharactersInLocal.FirstOrDefault(i => i.CharacterId.ToString() == Instance.EveAccount.myCharacterId);

                    // check for NPC corps and abort if this toon is in a NPC corp
                    //if (ESCache.Instance.DirectEve.Session.CharactersInLocal.Any(i => i.CorporationId == Instance.EveAccount.myCharacterId))
                    //    return;

                    foreach (DirectCharacter localMember in Instance.DirectEve.Session.CharactersInLocal.Where(i => i.CharacterId.ToString() != Instance.EveAccount.myCharacterId && i.CorporationId == myCharacterInLocal.CorporationId))
                    {
                        intLocalmember++;
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("localmember [" + localMember.Name + "]");
                        foreach (EntityCache thisPlayer in ESCache.Instance.EntitiesOnGrid.Where(i => i.CategoryId == (int)CategoryID.Ship))
                        {
                            intCorpmember++;
                            if (DebugConfig.DebugTargetCombatants) Log.WriteLine("PlayerEntity [" + thisPlayer + "][" + thisPlayer.Name + "] CategoryID [" + thisPlayer.CategoryId + "]");
                            if (thisPlayer.Name == localMember.Name)
                            {
                                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (thisPlayer.Name == localMember.Name)");
                                _myCorpMatesAsEntities.Add(thisPlayer);
                            }

                            continue;
                        }
                    }

                    return _myCorpMatesAsEntities ?? new List<EntityCache>();
                }

                return _myCorpMatesAsEntities;
            }
        }

        public IEnumerable<EntityCache> MyFleetMembersAsEntities
        {
            get
            {
                if (!ESCache.Instance.DirectEve.Session.InFleet)
                    return new List<EntityCache>();

                if (_myFleetMembersAsEntities == null)
                {
                    _myFleetMembersAsEntities = new List<EntityCache>();
                    int intFleetMember = 0;
                    foreach (DirectFleetMember fleetMember in ESCache.Instance.DirectEve.GetFleetMembers)
                    {
                        intFleetMember++;
                        if (DebugConfig.DebugDisableTargetCombatants) Log.WriteLine("FleetMember [" + intFleetMember + "][" + fleetMember.Name + "] Job [" + fleetMember.Job + "] Role [" + fleetMember.Role + "]");
                        if (ESCache.Instance.EntitiesOnGrid.Any(i => fleetMember.Name == i.Name))
                        {
                            if (DebugConfig.DebugDisableTargetCombatants) Log.WriteLine("FleetMember: if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsPlayer && fleetMember.Name == i.Name))");
                            _myFleetMembersAsEntities.Add(ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsPlayer && fleetMember.Name == i.Name));
                        }

                        continue;
                    }

                    return _myFleetMembersAsEntities ?? new List<EntityCache>();
                }

                return _myFleetMembersAsEntities;
            }
        }

        public IEnumerable<ModuleCache> Modules
        {
            get
            {
                try
                {
                    if (ActiveShip != null && ActiveShip.GroupId == (int)Group.Capsule)
                        return new List<ModuleCache>();

                    if (_modules == null || !_modules.Any())
                        _modules = Instance.DirectEve.Modules.Select(m => new ModuleCache(m)).ToList();

                    return _modules;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return new List<ModuleCache>();
                }
            }
        }

        public DirectItem myCurrentAmmoInWeapon
        {
            get
            {
                try
                {
                    if (_myCurrentAmmoInWeapon == null)
                    {
                        if (Instance.Weapons != null && Instance.Weapons.Any())
                        {
                            ModuleCache WeaponToCheckForAmmo = Instance.Weapons.FirstOrDefault();
                            if (WeaponToCheckForAmmo != null)
                            {
                                _myCurrentAmmoInWeapon = WeaponToCheckForAmmo.Charge;
                                return _myCurrentAmmoInWeapon;
                            }

                            return null;
                        }

                        return null;
                    }

                    return _myCurrentAmmoInWeapon;
                }
                catch (Exception ex)
                {
                    Log.WriteLine(ex.ToString());
                    return null;
                }
            }
        }

        public bool MyShipIsHealthy
        {
            get
            {
                if (Instance.Modules.Any(i => i.IsArmorRepairModule))
                {
                    if (Instance.ActiveShip.ArmorPercentage > 75 && Instance.ActiveShip.CapacitorPercentage > 75)
                        return true;

                    return false;
                }

                if (Instance.Modules.Any(i => i.IsShieldRepairModule))
                {
                    if (Instance.ActiveShip.ShieldPercentage > 75 && Instance.ActiveShip.CapacitorPercentage > 75)
                        return true;

                    return false;
                }

                return false;
            }
        }

        public double MyWalletBalance { get; set; }

        public bool PauseAfterNextDock { get; set; }

        public bool DeactivateScheduleAndCloseAfterNextDock { get; set; }

        public List<ShipTargetValue> ShipTargetValues { get; private set; }

        public Dictionary<long, DateTime> TargetingIDs { get; }

        public Dictionary<int, string> UnloadLootTheseItemsAreLootById { get; private set; }

        public double Wealth { get; set; }

        public double WealthatStartofPocket { get; set; }

        public int WeaponRange
        {
            get
            {
                if (_weaponRange != null) return _weaponRange ?? 0;

                IEnumerable<AmmoType> ammo = DirectModule.DefinedAmmoTypes.OrderByDescending(a => a.DamageType == MissionSettings.CurrentDamageType).ToList();

                try
                {
                    _weaponRange = 0;

                    if (Instance.Weapons.Any())
                    {
                        if (Instance.CurrentShipsCargo != null)
                        {
                            ammo = ammo.OrderByDescending(a => Instance.CurrentShipsCargo.Items.Any(i => Weapons != null && a.TypeId == i.TypeId)); //&& i.Quantity >= Weapons.FirstOrDefault().MaxCharges));
                        }
                        else
                        {
                            _weaponRange = Convert.ToInt32(Combat.MaxTargetRange);
                            return _weaponRange ?? 0;
                        }

                        if (!ammo.Any())
                        {
                            _weaponRange = Convert.ToInt32(Combat.MaxTargetRange);
                            return _weaponRange ?? 0;
                        }

                        double EffectiveMaxRange = 0;

                        if (Combat.DoWeCurrentlyHaveTurretsMounted())
                        {
                            if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.Any(i => i.GroupId == (int)Group.PrecursorWeapon))
                            {
                                EffectiveMaxRange = Math.Min(Instance.Weapons.FirstOrDefault().OptimalRange, Combat.MaxTargetRange);
                                //Log.WriteLine("Instance.Weapons.FirstOrDefault().OptimalRange is [" + Instance.Weapons.FirstOrDefault().OptimalRange + "]");
                                //Log.WriteLine("Combat.MaxTargetRange is [" + Combat.MaxTargetRange + "]");
                                double precursorAmmoRange = Math.Min(ammo.Max(a => a.Range), Combat.MaxTargetRange);
                                //Log.WriteLine("precursorAmmoRange is [" + precursorAmmoRange + "]");
                                _weaponRange = Math.Max((int)precursorAmmoRange, (int)EffectiveMaxRange);
                                //Log.WriteLine("_weaponRange is [" + _weaponRange + "]");
                                return _weaponRange ?? 0;
                            }

                            int OptimalRangeMultiplier = 2;
                            EffectiveMaxRange = Math.Min(Instance.Weapons.FirstOrDefault().FallOff * OptimalRangeMultiplier, Combat.MaxTargetRange);
                        }

                        double ammoRange = Math.Min(ammo.Max(a => a.Range), Combat.MaxTargetRange);

                        _weaponRange = Math.Max((int)ammoRange, (int)EffectiveMaxRange);
                    }

                    return _weaponRange ?? 0;
                }
                catch (Exception)
                {
                    if (Instance.ActiveShip != null)
                    {
                        _weaponRange = Convert.ToInt32(Combat.MaxTargetRange);
                        return _weaponRange ?? 0;
                    }

                    return 0;
                }
            }
        }

        public IEnumerable<ModuleCache> Weapons
        {
            get
            {
                if (_weapons == null)
                {
                    _weapons = Modules.Where(m =>
                            m.IsOnline &&
                            (m.GroupId == (int)Group.ProjectileWeapon ||
                             m.GroupId == (int)Group.EnergyWeapon ||
                             m.GroupId == (int)Group.HybridWeapon ||
                             m.GroupId == (int)Group.CruiseMissileLaunchers ||
                             m.GroupId == (int)Group.RocketLaunchers ||
                             m.GroupId == (int)Group.StandardMissileLaunchers ||
                             m.GroupId == (int)Group.TorpedoLaunchers ||
                             m.GroupId == (int)Group.AssaultMissileLaunchers ||
                             m.GroupId == (int)Group.LightMissileLaunchers ||
                             m.GroupId == (int)Group.DefenderMissileLaunchers ||
                             m.GroupId == (int)Group.CitadelCruiseLaunchers ||
                             m.GroupId == (int)Group.CitadelTorpLaunchers ||
                             m.GroupId == (int)Group.RapidHeavyMissileLaunchers ||
                             m.GroupId == (int)Group.RapidLightMissileLaunchers ||
                             m.GroupId == (int)Group.HeavyMissileLaunchers ||
                             m.GroupId == (int)Group.HeavyAssaultMissileLaunchers ||
                             m.GroupId == (int)Group.PrecursorWeapon ||
                             m.TypeId == (int)TypeID.CivilianGatlingAutocannon ||
                             m.TypeId == (int)TypeID.CivilianGatlingPulseLaser ||
                             m.TypeId == (int)TypeID.CivilianGatlingRailgun ||
                             m.TypeId == (int)TypeID.CivilianLightElectronBlaster))
                        .ToList();

                    if (Instance.InSpace)
                        if (false)
                        {
                            //int moduleNumber = 0;
                            //foreach (ModuleCache module in _weapons)
                            //{
                            //    moduleNumber++;
                            //    Log.WriteLine("Modules: [" + moduleNumber + "][" + module.TypeName + "] typeID [" + module.TypeId + "] groupID [" + module.GroupId + "]");
                            //}
                        }
                        else if (_weapons.Count() == 1 && !_weapons.Any(weapon => weapon.TypeId == (int)TypeID.CivilianGatlingAutocannon
                                                                                  || weapon.TypeId == (int)TypeID.CivilianGatlingPulseLaser
                                                                                  || weapon.TypeId == (int)TypeID.CivilianGatlingRailgun
                                                                                  || weapon.TypeId == (int)TypeID.CivilianLightElectronBlaster))
                        {
                            //Logging.Logging.Log("Cache.Weapons", "WARNING: You should not use stacked weapons, unstack them.");
                        }
                        else
                        {
                            if (_weapons != null && DateTime.UtcNow > Time.Instance.NextModuleDisableAutoReload)
                            {
                                int weaponNumber = 0;
                                foreach (ModuleCache weapon in _weapons)
                                    weaponNumber++;
                                //if (MissionSettings.MissionSpecificMissionFitting != null && !string.IsNullOrEmpty(MissionSettings.MissionSpecificMissionFitting.Ship) && Instance.ActiveShip.GivenName.ToLower() == MissionSettings.MissionSpecificMissionFitting.Ship.ToLower())
                                //{
                                //if (!weapon.AutoReload)
                                //{
                                //    Log.WriteLine("[" + weaponNumber + "][" + weapon.TypeName + "] Enable AutoReload [" + weapon.EnableAutoReload + "]");
                                //}
                                //}
                                /**
                                    if (weapon.AutoReload)
                                    {
                                        if (weapon.DisableAutoReload)
                                        {
                                            Time.Instance.NextModuleDisableAutoReload = DateTime.UtcNow.AddSeconds(2);
                                        }
                                    }
                                    **/

                                //Logging.Log("Cache.Weapons", "[" + weaponNumber + "][" + _module.TypeName + "] typeID [" + _module.TypeId + "] groupID [" + _module.GroupId + "]");
                            }
                        }
                }
                return _weapons ?? new List<ModuleCache>();
            }
        }

        public double? WebRange
        {
            get
            {
                ModuleCache webifier = null;
                if (Instance.Modules != null && Instance.Modules.Any(i => i.GroupId == (int)Group.StasisWeb))
                {
                    webifier = Instance.Modules.FirstOrDefault(i => i.GroupId == (int)Group.StasisWeb);
                    if (webifier != null)
                        return webifier.MaxRange;

                    return null;
                }

                return null;
            }
        }

        public List<DirectWindow> Windows
        {
            get
            {
                try
                {
                    if (_windows == null)
                    {
                        //if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation) return new List<DirectWindow>();

                        if (DirectEve.Windows != null && DirectEve.Windows.Any())
                        {
                            _windows = DirectEve.Windows;
                            return _windows;
                        }

                        return new List<DirectWindow>();
                    }

                    return _windows ?? new List<DirectWindow>();
                }
                catch (Exception)
                {
                    //if (DebugConfig.Windows) Log.WriteLine("Exception [" + ex + "]");
                    return new List<DirectWindow>();
                }
            }
        }

        public void ResetInStationSettingsWhenExitingStation()
        {
            Log.WriteLine("Exiting Station: LootAlreadyUnloaded is now false");
            LootAlreadyUnloaded = false;
        }

        #endregion Properties

        #region Methods

        public static int GetRandom(int minValue, int maxValue)
        {
            return _random.Next(minValue, maxValue);
        }

        public static bool LoadDirectEVEInstance(D3DVersion version)
        {
            Instance.DirectEve = new DirectEve(new StandaloneFramework(version));
            return Instance.DirectEve != null;
        }

        public DirectItem CheckCargoForItem(int typeIdToFind, int quantityToFind)
        {
            try
            {
                if (Instance.CurrentShipsCargo != null && Instance.CurrentShipsCargo.Items.Any())
                {
                    DirectItem item = Instance.CurrentShipsCargo.Items.FirstOrDefault(i => i.TypeId == typeIdToFind && i.Quantity >= quantityToFind);
                    return item;
                }

                return null;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }

            return null;
        }

        public bool CheckifRouteIsAllHighSec()
        {
            Instance.RouteIsAllHighSecBool = false;

            try
            {
                if (DirectEve.Navigation.GetDestinationPath() != null && DirectEve.Navigation.GetDestinationPath().Count > 0)
                {
                    List<long> currentPath = DirectEve.Navigation.GetDestinationPath();
                    if (currentPath == null || !currentPath.Any()) return false;
                    if (currentPath[0] == 0) return false;
                    Log.WriteLine("CheckIfRouteIsAllHighSec: Route has [" + currentPath.Count + "] Systems");
                    int systemCount = 0;
                    foreach (int _system in currentPath)
                    {
                        systemCount++;
                        if (_system < 60000000)
                        {
                            DirectSolarSystem solarSystemInRoute = Instance.DirectEve.SolarSystems[_system];
                            if (solarSystemInRoute != null)
                            {
                                if (solarSystemInRoute.Security < 0.45)
                                {
                                    Log.WriteLine("CheckIfRouteIsAllHighSec: [" + systemCount + "][" + solarSystemInRoute.Name + "] is [" + solarSystemInRoute.Security + "] security - lowsec!");
                                    Instance.RouteIsAllHighSecBool = false;
                                    return true;
                                }

                                Log.WriteLine("CheckIfRouteIsAllHighSec: [" + systemCount + "][" + solarSystemInRoute.Name + "] is [" + solarSystemInRoute.Security + "] security - highsec");
                                continue;
                            }

                            Log.WriteLine("Jump number [" + _system + "of" + currentPath.Count() +
                                          "] in the route came back as null, we could not get the system name or sec level");
                        }
                    }

                    Log.WriteLine("CheckIfRouteIsAllHighSec: Route has [" + currentPath.Count + "] Systems 0 of which are lowsec");
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }

            Instance.RouteIsAllHighSecBool = true;
            return true;
        }

        public void ClearPerPocketCache(string callingroutine)
        {
            try
            {
                if (DateTime.UtcNow > Time.NextClearPocketCache)
                {
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.needHumanIntervention), false);
                    AbyssalDeadspaceBehavior.ClearPerPocketCache();
                    Combat.ClearPerPocketCache();
                    Defense.ClearPerPocketCache();
                    Drones.ClearPerPocketCache();
                    MissionSettings.ClearPerPocketCache();
                    NavigateOnGrid.ClearPerPocketCache();
                    ReduceGraphicLoad.ClearPerPocketCache();
                    Salvage.ClearPerPocketCache();
                    State.CurrentInstaStationDockState = InstaStationDockState.Idle;
                    State.CurrentInstaStationUndockState = InstaStationUndockState.Idle;

                    ListOfJammingEntities.Clear();
                    ListOfTrackingDisruptingEntities.Clear();
                    ListNeutralizingEntities.Clear();
                    ListOfTargetPaintingEntities.Clear();
                    ListOfDampenuingEntities.Clear();
                    ListofWebbingEntities.Clear();
                    ListofContainersToLoot.Clear();
                    ListofMissionCompletionItemsToLoot.Clear();

                    ListOfUndockBookmarks = null;
                    ActionControl.IgnoreTargets.Clear();
                    EntityIsHighValueTarget.Clear();
                    EntityIsLowValueTarget.Clear();
                    EntityIsEntutyIShouldLeaveAlone.Clear();
                    Instance.LootedContainers.Clear();

                    if (EveAccount.SelectedController == "CourierMissionsController")
                        CourierMissionsController.ClearPerPocketCache();
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
            finally
            {
                Time.NextClearPocketCache = DateTime.UtcNow.AddSeconds(5);
            }
        }

        public void ClearPerSystemCache(string callingroutine)
        {
            Defense.ClearSystemSpecificSettings();
            SkillQueue.ClearSystemSpecificSettings();
            Instance.ClearPerPocketCache("Jump()");
            ReduceGraphicLoad.ClearPerSystemCache();
            Scanner.ClearPerSystemCache();
            HighSecAnomalyBehavior.ClearPerSystemCache();
        }

        public bool CloseQuestor(string Reason)
        {
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.CharName, nameof(EveAccount.RestartOfEveClientNeeded), true);
            if (ESCache.Instance.EveAccount.RestartOfEveClientNeeded)
            {
                Log.WriteLine("Closing EVESharp [" + Reason + "]");
                Util.TaskKill(Process.GetCurrentProcess().Id, false);
                return false;
            }

            return false;
        }

        public void DisableThisInstance()
        {
            string msg = string.Format("Set [{0}] disabled.", Instance.EveAccount.MaskedCharacterName);
            WCFClient.Instance.GetPipeProxy.RemoteLog(msg);
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.CharName, nameof(EveAccount.UseScheduler), false);
        }

        public bool GroupWeapons()
        {
            if (Time.Instance.TryGroupWeapons && Instance.InSpace && Instance.InWarp &&
                Time.Instance.LastGroupWeapons.AddSeconds(Time.Instance.Rnd.Next(15, 30)) < DateTime.UtcNow)
            {
                Time.Instance.LastGroupWeapons = DateTime.UtcNow;
                if (Instance.Weapons.Any() && Instance.Weapons.Count() > 1 &&
                    Instance.Weapons.All(w => w.IsOnline && !w.IsActive && !w.IsReloadingAmmo))
                    if (Instance.ActiveShip != null && Instance.ActiveShip.Entity != null)
                        if (Instance.ActiveShip.CanGroupAll())
                        {
                            Time.Instance.TryGroupWeapons = false; // will become true after docking
                            Instance.ActiveShip.GroupAllWeapons();
                            Log.WriteLine("Grouped weapons.");
                            return true;
                        }
            }

            return false;
        }

        public void InvalidateCache()
        {
            try
            {
                //Log.WriteLine("QCache.InvalidateCache()");
                Settings.InvalidateCache();
                //Log.InvalidateCache();
                HighSecAnomalyController.InvalidateCache();
                Arm.InvalidateCache();
                Drones.InvalidateCache();
                Combat.InvalidateCache();
                Salvage.InvalidateCache();
                MissionSettings.InvalidateCache();
                NavigateOnGrid.InvalidateCache();
                HydraController.InvalidateCache();
                AbyssalDeadspaceBehavior.InvalidateCache();
                InvalidateCache_Hangars();
                _inMission = null;
                _insidePosForceField = null;
                _inAbyssalDeadspace = null;
                _inSpace = null;
                _inStation = null;
                //Cache InSpace / InStation for this frame.
                if (Instance.InSpace && Instance.InStation) Log.WriteLine("Both InStation and InSpace were true. How?");
                _fittedModules = null;
                _allBookmarks = null;
                _bigObjectsAndGates = null;
                _abyssalBigObjects = null;
                _AbyssalDeadspaceDeviantAutomataSuppressor = null;
                _AbyssalDeadspaceMultibodyTrackingPylon = null;
                _AbyssalDeadspaceBioluminescenceCloud = null;
                _AbyssalDeadspaceCausticCloud = null;
                _AbyssalDeadspaceFilamentCloud = null;
                _chargeEntities = null;
                _currentShipsCargo = null;
                _currentShipsFleetHangar = null;
                _currentShipsModules = null;
                _currentShipsOreHold = null;
                _containers = null;
                _entities = null;
                _entitiesNotSelf = null;
                _entitiesOnGrid = null;
                _entitiesById.Clear();
                _fittingManagerWindow = null;
                _gates = null;
                _inWarp = null;
                _lpStore = null;
                _maxLockedTargets = null;
                _modules = null;
                _myAmmoInSpace = null;
                _myCorpMatesAsEntities = null;
                _myCurrentAmmoInWeapon = null;
                _myFleetMembersAsEntities = null;
                _myShipEntity = null;
                //_objects = null;
                _safeSpotBookmarks = null;
                _star = null;
                _stargate = null;
                _stargates = null;
                _wormholes = null;
                _targets = null;
                _targeting = null;
                _TotalTargetsandTargeting = null;
                _unlootedContainers = null;
                _unlootedWrecksAndSecureCans = null;
                _weapons = null;
                _weaponRange = null;
                _windows = null;
                _wrecks = null;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        public void IterateShipTargetValues(string module)
        {
            ShipTargetValues = new List<ShipTargetValue>();

            try
            {
                Log.WriteLine("IterateShipTargetValues - Loading [ShipTargetValuesXmlFile]");
                XDocument values = XDocument.Parse(Lookup.ShipTargetValues.GetShipTargetValuesXML);
                if (values.Root != null)
                    foreach (XElement value in values.Root.Elements("ship"))
                    {
                        ShipTargetValue stv = new ShipTargetValue(value);
                        ShipTargetValues.Add(stv);
                    }
            }
            catch (Exception exception)
            {
                Log.WriteLine("IterateShipTargetValues - Exception: [" + exception + "]");
            }
        }

        public void IterateUnloadLootTheseItemsAreLootItems(string module)
        {
            UnloadLootTheseItemsAreLootById = new Dictionary<int, string>();

            try
            {
                MissionSettings.UnloadLootTheseItemsAreLootItems = XDocument.Parse(UnloadLootTheseItemsAreLootItems.GetUnloadLootTheseItemsAreLootItemsXML);
                if (MissionSettings.UnloadLootTheseItemsAreLootItems.Root != null)
                    foreach (XElement element in MissionSettings.UnloadLootTheseItemsAreLootItems.Root.Elements("invtype"))
                    {
                        int key = -1;
                        int.TryParse(element.Attribute("id").Value, out key);
                        string name = element.Attribute("name").Value;
                        UnloadLootTheseItemsAreLootById.Add(key, name);
                    }
            }
            catch (Exception exception)
            {
                Log.WriteLine("IterateUnloadLootTheseItemsAreLootItems - Exception: [" + exception + "]");
            }
        }

        public bool LocalSafe(int maxBad, double stand)
        {
            return true;

            if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                return false;

            if (ESCache.Instance.InAbyssalDeadspace || ESCache.Instance.InWormHoleSpace)
                return false;

            int number = 0;

            if (Instance.DirectEve.Session.LocalChatChannel == null)
            {
                Log.WriteLine($"local == null?");
                return true;
            }

            try
            {
                foreach (DirectCharacter localMember in Instance.DirectEve.Session.CharactersInLocal.Where(i => i.CharacterId.ToString() != Instance.EveAccount.myCharacterId))
                {
                    float[] alliance =
                    {
                        DirectEve.Standings.GetPersonalRelationship(localMember.AllianceId),
                        DirectEve.Standings.GetCorporationRelationship(localMember.AllianceId),
                        DirectEve.Standings.GetAllianceRelationship(localMember.AllianceId)
                    };
                    float[] corporation =
                    {
                        DirectEve.Standings.GetPersonalRelationship(localMember.CorporationId),
                        DirectEve.Standings.GetCorporationRelationship(localMember.CorporationId),
                        DirectEve.Standings.GetAllianceRelationship(localMember.CorporationId)
                    };
                    float[] personal =
                    {
                        DirectEve.Standings.GetPersonalRelationship(localMember.CharacterId),
                        DirectEve.Standings.GetCorporationRelationship(localMember.CharacterId),
                        DirectEve.Standings.GetAllianceRelationship(localMember.CharacterId)
                    };

                    if (alliance.Min() <= stand || corporation.Min() <= stand || personal.Min() <= stand)
                    {
                        Log.WriteLine("Bad Standing Pilot Detected: [ " + localMember.Name + "] " + " [ " + number + " ] so far... of [ " + maxBad +
                                      " ] allowed");
                        number++;
                    }

                    if (number > maxBad)
                    {
                        Log.WriteLine("[" + number + "] Bad Standing pilots in local, We should stay in station");
                        return false;
                    }
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }

            return true;
        }

        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public void SetInfoAttribute(string info)
        {
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.Info), info);
        }

        #endregion Methods
    }
}