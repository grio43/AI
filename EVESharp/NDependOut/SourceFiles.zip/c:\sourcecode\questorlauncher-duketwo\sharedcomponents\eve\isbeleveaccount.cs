﻿//#define REFRESH_TOKENS

using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.IO;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Xml.Serialization;
using SharedComponents.ISBELExtensions;
using SharedComponents.Security;
using SharedComponents.Utility;
using SharedComponents.Web;

namespace SharedComponents.EVE
{
    /// <summary>
    /// An EVE Online account and related data
    /// </summary>
    public class IsbelEveAccount : ViewModelBase //INotifyPropertyChanged, IDisposable, ISBoxerEVELauncher.Launchers.ILaunchTarget
    {

        private Guid _challengeCodeSource = Guid.Empty;

        [XmlIgnore]
        public Guid ChallengeCodeSource
        {
            get
            {
                if (_challengeCodeSource == Guid.Empty)
                {
                    _challengeCodeSource = new Guid();
                    return _challengeCodeSource;
                }

                return _challengeCodeSource;
            }
        }

        [XmlIgnore] private byte[] _challengeCode = null;


        [XmlIgnore]
        private byte[] ChallengeCode
        {
            get
            {
                if (_challengeCode == null)
                {
                    _challengeCode = Encoding.UTF8.GetBytes(ChallengeCodeSource.ToString().Replace("-", ""));
                    return _challengeCode;
                }

                return _challengeCode;
            }
        }

        [XmlIgnore] private string _challengeHash = string.Empty;

        [XmlIgnore]
        public string ChallengeHash
        {
            get
            {
                if (string.IsNullOrEmpty(_challengeHash))
                {
                    _challengeHash = Base64UrlEncoder.Encode(Crypto.GenerateSHA256Hash(Base64UrlEncoder.Encode(ChallengeCode)));
                    return _challengeHash;
                }

                return _challengeHash;
            }
        }

        [XmlIgnore] private Guid _state = Guid.Empty;

        [XmlIgnore]
        private Guid State
        {
            get
            {
                if (_state == Guid.Empty)
                {
                    _state = Guid.NewGuid();
                    return _state;
                }

                return _state;
            }
        }

        [XmlIgnore]
        private string _code;

        private EveAccount cachedEveAccount = null;

        public void SetEveAccount(EveAccount myEveAccount)
        {
            cachedEveAccount = myEveAccount;
        }

        /// <summary>
        /// An Outh2 Access Token
        /// </summary>
        public class Token
        {
            private authObj _authObj;

            public Token()
            {

            }

            /// <summary>
            /// We usually just need to parse a Uri for the Access Token details. So here is the constructor that does it for us.
            /// </summary>
            /// <param name="fromUri"></param>
            [Browsable(false)]
            public Token(authObj resp)
            {
                _authObj = resp;
                TokenString = resp.access_token;
                Expiration = DateTime.Now.AddMinutes(resp.expires_in);
            }

            [Browsable(false)]
            public override string ToString()
            {
                return TokenString;
            }

            /// <summary>
            /// Determine if the Access Token is expired. If it is, we know we can't use it...
            /// </summary>
            [Browsable(false)]
            public bool IsExpired
            {
                get
                {
                    return DateTime.Now >= Expiration;
                }
            }

            /// <summary>
            /// The actual token data
            /// </summary>
            [Browsable(false)]
            public string TokenString { get; set; }
            /// <summary>
            /// When the token is good until...
            /// </summary>
            [Browsable(false)]
            public DateTime Expiration { get; set; }
        }

        [Browsable(false)]
        CookieContainer _Cookies;

        /// <summary>
        /// The EVE login process requires cookies; this will ensure we maintain the same cookies for the account
        /// </summary>

        [XmlIgnore]
        [Browsable(false)]
        CookieContainer Cookies
        {
            get
            {
                if (_Cookies == null)
                {
                    if (!string.IsNullOrEmpty(NewCookieStorage))
                    {
                        BinaryFormatter formatter = new BinaryFormatter();

                        using (Stream s = new MemoryStream(Convert.FromBase64String(NewCookieStorage)))
                        {
                            _Cookies = (CookieContainer)formatter.Deserialize(s);
                        }
                    }
                    else
                        _Cookies = new CookieContainer();
                }
                return _Cookies;
            }
            set
            {
                _Cookies = value;
            }
        }

        [Browsable(false)]
        public void UpdateCookieStorage()
        {
            if (Cookies == null)
            {
                NewCookieStorage = null;
                return;
            }

            using (MemoryStream ms = new MemoryStream())
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(ms, Cookies);
                ms.Flush();
                ms.Seek(0, SeekOrigin.Begin);

                NewCookieStorage = Convert.ToBase64String(ms.ToArray());
            }

        }

        [Browsable(false)]
        [XmlIgnore]
        public string NewCookieStorage
        {
            get => Web.CookieStorage.GetCookies(cachedEveAccount);
            set => Web.CookieStorage.SetCookies(cachedEveAccount, value);
        }

        [Browsable(false)]
        Token _TranquilityToken;
        /// <summary>
        /// AccessToken for Tranquility. Lasts up to 11 hours?
        /// </summary>
        [XmlIgnore]
        [Browsable(false)]
        public Token TranquilityToken { get { return _TranquilityToken; } set { _TranquilityToken = value; OnPropertyChanged("TranquilityToken"); } }

        [Browsable(false)]
        Token _SisiToken;

        /// <summary>
        /// AccessToken for Singularity. Lasts up to 11 hours?
        /// </summary>
        [XmlIgnore]
        [Browsable(false)]
        public Token SisiToken { get { return _SisiToken; } set { _SisiToken = value; OnPropertyChanged("SisiToken"); } }

        public LoginResult GetSecurityWarningChallenge(EveAccount myEveAccount, bool sisi, string responseBody, Uri referer, string proxyIp, string proxyHttpPort, out Token accessToken)
        {
            var uri = RequestResponse.GetSecurityWarningChallenge(sisi, State.ToString(), ChallengeHash);
            var req = RequestResponse.CreateGetRequest(uri, sisi, true, referer.ToString(), Cookies, proxyIp, proxyHttpPort);
            return GetAccessToken(myEveAccount, sisi, req, proxyIp, proxyHttpPort, out accessToken);
        }

        public LoginResult GetEmailChallenge(bool sisi, string responseBody, out Token accessToken)
        {
            Windows.EmailChallengeWindow emailWindow = new Windows.EmailChallengeWindow(responseBody);
            emailWindow.ShowDialog();
            if (!emailWindow.DialogResult.HasValue || !emailWindow.DialogResult.Value)
            {
                //SecurePassword = null;
                accessToken = null;
                return LoginResult.EmailVerificationRequired;
            }

            //SecurePassword = null;
            accessToken = null;
            return LoginResult.EmailVerificationRequired;
        }


        public LoginResult GetEULAChallenge(EveAccount myEveAccount, bool sisi, string responseBody, Uri referer, string proxyIp, string proxyHttpPort, out Token accessToken)
        {
            Windows.EVEEULAWindow eulaWindow = new Windows.EVEEULAWindow(responseBody);
            eulaWindow.ShowDialog();
            if (!eulaWindow.DialogResult.HasValue || !eulaWindow.DialogResult.Value)
            {
                //SecurePassword = null;
                accessToken = null;
                return LoginResult.EULADeclined;
            }

            var uri = RequestResponse.GetEulaUri(sisi, State.ToString(), ChallengeHash);
            HttpWebRequest req = RequestResponse.CreatePostRequest(uri, sisi, true, referer.ToString(), Cookies, proxyIp, proxyHttpPort);

            using (SecureBytesWrapper body = new SecureBytesWrapper())
            {
                string eulaHash = RequestResponse.GetEulaHashFromBody(responseBody);
                string returnUrl = RequestResponse.GetEulaReturnUrlFromBody(responseBody);

                string formattedString = String.Format("eulaHash={0}&returnUrl={1}&action={2}", Uri.EscapeDataString(eulaHash), Uri.EscapeDataString(returnUrl), "Accept");
                body.Bytes = Encoding.ASCII.GetBytes(formattedString);

                req.ContentLength = body.Bytes.Length;
                try
                {
                    using (Stream reqStream = req.GetRequestStream())
                    {
                        reqStream.Write(body.Bytes, 0, body.Bytes.Length);
                    }
                }
                catch (System.Net.WebException e)
                {
                    switch (e.Status)
                    {
                        case WebExceptionStatus.Timeout:
                        {
                            accessToken = null;
                            return LoginResult.Timeout;
                        }
                        default:
                            throw;
                    }
                }
            }
            LoginResult result;

            try
            {
                result = GetAccessToken(myEveAccount, sisi, req, proxyIp, proxyHttpPort, out accessToken);
            }
            catch (System.Net.WebException)
            {
                result = GetAccessToken(myEveAccount, sisi, proxyIp, proxyHttpPort, out accessToken);
            }

            result = GetAccessToken(myEveAccount, sisi, req, proxyIp, proxyHttpPort, out accessToken);
            if (result == LoginResult.Success)
            {
                // successful verification code challenge, make sure we save the cookies.
                //App.Settings.Store();
            }
            return result;
        }


        public LoginResult GetEmailCodeChallenge(EveAccount myEveAccount, bool sisi, string responseBody, string proxyIp, string proxyHttpPort, out Token accessToken)
        {
            Windows.VerificationCodeChallengeWindow acw = new Windows.VerificationCodeChallengeWindow(myEveAccount);
            acw.ShowDialog();
            if (!acw.DialogResult.HasValue || !acw.DialogResult.Value)
            {
                //SecurePassword = null;
                accessToken = null;
                return LoginResult.InvalidEmailVerificationChallenge;
            }

            var uri = RequestResponse.GetVerifyTwoFactorUri(sisi, State.ToString(), ChallengeHash);
            var req = RequestResponse.CreatePostRequest(uri, sisi, true, null, Cookies, proxyIp, proxyHttpPort);

            using (SecureBytesWrapper body = new SecureBytesWrapper())
            {
                //                body.Bytes = Encoding.ASCII.GetBytes(String.Format("Challenge={0}&IsPasswordBreached={1}&NumPasswordBreaches={2}&command={3}", Uri.EscapeDataString(acw.VerificationCode), IsPasswordBreached, NumPasswordBreaches, "Continue"));
                body.Bytes = Encoding.ASCII.GetBytes(String.Format("Challenge={0}&command={1}", Uri.EscapeDataString(acw.VerificationCode), "Continue"));

                req.ContentLength = body.Bytes.Length;
                try
                {
                    using (Stream reqStream = req.GetRequestStream())
                    {
                        reqStream.Write(body.Bytes, 0, body.Bytes.Length);
                    }
                }
                catch (System.Net.WebException e)
                {
                    switch (e.Status)
                    {
                        case WebExceptionStatus.Timeout:
                        {
                            accessToken = null;
                            return LoginResult.Timeout;
                        }
                        default:
                            throw;
                    }
                }
            }
            LoginResult result = GetAccessToken(myEveAccount, sisi, req, proxyIp, proxyHttpPort, out accessToken);
            if (result == LoginResult.Success)
            {
                // successful verification code challenge, make sure we save the cookies.
                //App.Settings.Store();
            }
            return result;
        }

        public LoginResult GetAuthenticatorChallenge(EveAccount myEveAccount, bool sisi, string proxyIp, string proxyHttpPort, out Token accessToken)
        {
            Windows.AuthenticatorChallengeWindow acw = new Windows.AuthenticatorChallengeWindow(myEveAccount);
            acw.ShowDialog();
            if (!acw.DialogResult.HasValue || !acw.DialogResult.Value)
            {
                //SecurePassword = null;
                accessToken = null;
                return LoginResult.InvalidAuthenticatorChallenge;
            }

            var uri = RequestResponse.GetAuthenticatorUri(sisi, State.ToString(), ChallengeHash);
            var req = RequestResponse.CreatePostRequest(uri, sisi, true, uri.ToString(), Cookies, proxyIp, proxyHttpPort);

            using (SecureBytesWrapper body = new SecureBytesWrapper())
            {
                body.Bytes = Encoding.ASCII.GetBytes(String.Format("Challenge={0}&RememberTwoFactor={1}&command={2}", Uri.EscapeDataString(acw.AuthenticatorCode), "true", "Continue"));

                req.ContentLength = body.Bytes.Length;
                try
                {
                    using (Stream reqStream = req.GetRequestStream())
                    {
                        reqStream.Write(body.Bytes, 0, body.Bytes.Length);
                    }
                }
                catch (System.Net.WebException e)
                {
                    switch (e.Status)
                    {
                        case WebExceptionStatus.Timeout:
                        {
                            accessToken = null;
                            return LoginResult.Timeout;
                        }
                        default:
                            throw;
                    }
                }
            }
            LoginResult result = GetAccessToken(myEveAccount, sisi, req, proxyIp, proxyHttpPort, out accessToken);
            if (result == LoginResult.Success)
            {
                // successful authenticator challenge, make sure we save the cookies.
                //App.Settings.Store();
            }
            return result;
        }

        public LoginResult GetCharacterChallenge(EveAccount myEveAccount, bool sisi, string proxyIp, string proxyHttpPort, out Token accessToken)
        {
            //Windows.CharacterChallengeWindow ccw = new Windows.CharacterChallengeWindow(this);
            //bool? result = ccw.ShowDialog();

            if (string.IsNullOrWhiteSpace(myEveAccount.CharacterName))
            {
                // CharacterName is required, sorry dude
                accessToken = null;
                //  SecurePassword = null;
                //SecureCharacterName = null;
                return LoginResult.InvalidCharacterChallenge;
            }

            System.Security.SecureString SecureCharacterName = new System.Security.SecureString();
            foreach (char c in myEveAccount.CharacterName)
            {
                SecureCharacterName.AppendChar(c);
            }
            SecureCharacterName.MakeReadOnly();

            var uri = RequestResponse.GetCharacterChallengeUri(sisi, State.ToString(), ChallengeHash);
            var req = RequestResponse.CreatePostRequest(uri, sisi, true, uri.ToString(), Cookies, proxyIp, proxyHttpPort);

            using (SecureBytesWrapper body = new SecureBytesWrapper())
            {
                byte[] body1 = Encoding.ASCII.GetBytes(String.Format("RememberCharacterChallenge={0}&Challenge=", "true"));
                using (SecureStringWrapper ssw = new SecureStringWrapper(SecureCharacterName, Encoding.ASCII))
                {
                    using (SecureBytesWrapper escapedCharacterName = new SecureBytesWrapper())
                    {
                        escapedCharacterName.Bytes = System.Web.HttpUtility.UrlEncodeToBytes(ssw.ToByteArray());

                        body.Bytes = new byte[body1.Length + escapedCharacterName.Bytes.Length];
                        System.Buffer.BlockCopy(body1, 0, body.Bytes, 0, body1.Length);
                        System.Buffer.BlockCopy(escapedCharacterName.Bytes, 0, body.Bytes, body1.Length, escapedCharacterName.Bytes.Length);
                    }
                }

                req.ContentLength = body.Bytes.Length;
                try
                {
                    using (Stream reqStream = req.GetRequestStream())
                    {
                        reqStream.Write(body.Bytes, 0, body.Bytes.Length);
                    }
                }
                catch (System.Net.WebException e)
                {
                    switch (e.Status)
                    {
                        case WebExceptionStatus.Timeout:
                        {
                            accessToken = null;
                            return LoginResult.Timeout;
                        }
                        default:
                            throw;
                    }
                }
            }
            return GetAccessToken(myEveAccount, sisi, req, proxyIp, proxyHttpPort, out accessToken);
        }

        public LoginResult GetAccessToken(EveAccount myEveAccount, bool sisi, HttpWebRequest req, string proxyIp, string proxyHttpPort, out Token accessToken)
        {
            accessToken = null;
            Response response = null;
            try
            {
                response = new Response(req, proxyIp, proxyHttpPort);

                string responseBody = response.Body;
                UpdateCookieStorage();

                if (responseBody.Contains("Incorrect character name entered"))
                {
                    accessToken = null;
                    //SecurePassword = null;
                    //SecureCharacterName = null;
                    return LoginResult.InvalidCharacterChallenge;
                }

                if (responseBody.Contains("Invalid username / password"))
                {
                    accessToken = null;
                    //SecurePassword = null;
                    return LoginResult.InvalidUsernameOrPassword;
                }

                // I'm just guessing on this one at the moment.
                if (responseBody.Contains("Invalid authenticat")
                    || (responseBody.Contains("Verification code mismatch") && responseBody.Contains("/account/authenticator"))
                )
                {
                    accessToken = null;
                    //SecurePassword = null;
                    return LoginResult.InvalidAuthenticatorChallenge;
                }
                //The 2FA page now has "Character challenge" in the text but it is hidden. This should fix it from
                //Coming up during 2FA challenge
                if (responseBody.Contains("Character challenge") && !responseBody.Contains("visuallyhidden"))
                {
                    return GetCharacterChallenge(myEveAccount, sisi, proxyIp, proxyHttpPort, out accessToken);
                }

                if (responseBody.Contains("Email verification required"))
                {
                    return GetEmailChallenge(sisi, responseBody, out accessToken);
                }

                if (responseBody.Contains("Authenticator is enabled"))
                {
                    return GetAuthenticatorChallenge(myEveAccount, sisi, proxyIp, proxyHttpPort, out accessToken);
                }

                if (responseBody.Contains("Please enter the verification code "))
                {
                    return GetEmailCodeChallenge(myEveAccount, sisi, responseBody, proxyIp, proxyHttpPort, out accessToken);
                }

                if (responseBody.Contains("Security Warning"))
                {
                    return GetSecurityWarningChallenge(myEveAccount, sisi, responseBody, response.ResponseUri, proxyIp, proxyHttpPort, out accessToken);
                }

                if (responseBody.ToLower().Contains("form action=\"/oauth/eula\""))
                {
                    return GetEULAChallenge(myEveAccount, sisi, responseBody, response.ResponseUri, proxyIp, proxyHttpPort, out accessToken);
                }

                try
                {
                    _code = HttpUtility.ParseQueryString(response.ResponseUri.ToString()).Get("code");
                    if (_code == null)
                    {

                        return LoginResult.Error;
                    }

                    GetAccessToken(sisi, _code, proxyIp, proxyHttpPort, out response);
                    accessToken = new Token(JsonConvert.DeserializeObject<authObj>(response.Body));
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Unrecognized Response: " + responseBody);
                    Cache.Instance.Log("Exception [" + ex + "]");
                    // can't get the token
                    accessToken = null;
                    return LoginResult.TokenFailure;
                }

                if (!sisi)
                {
                    TranquilityToken = accessToken;
                }
                else
                {
                    SisiToken = accessToken;
                }

                return LoginResult.Success;
            }
            catch (System.Net.WebException we)
            {
                switch (we.Status)
                {
                    case WebExceptionStatus.Timeout:
                        return LoginResult.Timeout;
                    default:
                        string responseBody = we.Response.GetResponseBody();
                        Cache.Instance.Log("Unrecognized Response: " + responseBody);
                        Cache.Instance.Log("Exception [" + we + "]");
                        return LoginResult.Error;
                }
            }
        }


        public class authObj
        {
            private int _expiresIn;
            public string access_token { get; set; }
            public int expires_in
            {
                get
                {
                    return _expiresIn;
                }
                set
                {
                    _expiresIn = value;
                    Expiration = DateTime.Now.AddMinutes(_expiresIn);
                }
            }
            public string token_type { get; set; }
            public string refresh_token { get; set; }

            public DateTime Expiration { get; private set; }

        }


        private LoginResult GetAccessToken(bool sisi, string code, string proxyIp, string proxyHttpPort, out Response response)
        {
            Cache.Instance.Log("Attempting to GetAccessToken: sisi [" + sisi + "] code [" + code + "]");
            HttpWebRequest req2 = RequestResponse.CreatePostRequest(new Uri(RequestResponse.token, UriKind.Relative), sisi, true, RequestResponse.refererUri, Cookies, proxyIp, proxyHttpPort);

            Cache.Instance.Log("Attempting to GetSsoTokenRequestBody: sisi [" + sisi + "] code [" + code + "] challengeCode [" + ChallengeCode + "]");
            req2.SetBody(RequestResponse.GetSsoTokenRequestBody(sisi, code, ChallengeCode));
            return RequestResponse.GetHttpWebResponse(req2, UpdateCookieStorage, proxyIp, proxyHttpPort, out response);
        }


        public LoginResult GetRequestVerificationToken(Uri uri, bool sisi, string proxyIp, string proxyHttpPort, out string verificationToken)
        {
            Response response;
            verificationToken = null;

            var req = RequestResponse.CreateGetRequest(uri, sisi, false, RequestResponse.refererUri, Cookies, proxyIp, proxyHttpPort);
            req.ContentLength = 0;

            var result = RequestResponse.GetHttpWebResponse(req, UpdateCookieStorage, proxyIp, proxyHttpPort, out response);

            if (result == LoginResult.Success)
            {
                verificationToken = RequestResponse.GetRequestVerificationTokenResponse(response);
            }

            return result;
        }


        public LoginResult GetAccessToken(EveAccount myEveAccount, bool sisi, string proxyIp, string proxyHttpPort, out Token accessToken)
        {
            Token checkToken = sisi ? SisiToken : TranquilityToken;
            if (checkToken != null && !checkToken.IsExpired)
            {
                accessToken = checkToken;
                return LoginResult.Success;
            }

            // need SecurePassword.

            System.Security.SecureString SecurePassword = new System.Security.SecureString();
            foreach (char c in myEveAccount.Password)
            {
                SecurePassword.AppendChar(c);
            }
            SecurePassword.MakeReadOnly();

            if (SecurePassword == null || SecurePassword.Length == 0)
            {
                // password is required, sorry dude
                accessToken = null;
                return LoginResult.InvalidUsernameOrPassword;
            }

            var uri = RequestResponse.GetLoginUri(sisi, State.ToString(), ChallengeHash);

            string RequestVerificationToken = string.Empty;
            var result = GetRequestVerificationToken(uri, sisi, proxyIp, proxyHttpPort, out RequestVerificationToken);

            var req = RequestResponse.CreatePostRequest(uri, sisi, true, RequestResponse.refererUri, Cookies, proxyIp, proxyHttpPort);

            using (SecureBytesWrapper body = new SecureBytesWrapper())
            {
                byte[] body1 = Encoding.ASCII.GetBytes(String.Format("__RequestVerificationToken={1}&UserName={0}&Password=", Uri.EscapeDataString(myEveAccount.AccountName), Uri.EscapeDataString(RequestVerificationToken)));
                //                byte[] body1 = Encoding.ASCII.GetBytes(String.Format("UserName={0}&Password=", Uri.EscapeDataString(Username)));
                using (SecureStringWrapper ssw = new SecureStringWrapper(SecurePassword, Encoding.ASCII))
                {
                    using (SecureBytesWrapper escapedPassword = new SecureBytesWrapper())
                    {
                        escapedPassword.Bytes = System.Web.HttpUtility.UrlEncodeToBytes(ssw.ToByteArray());

                        body.Bytes = new byte[body1.Length + escapedPassword.Bytes.Length];
                        System.Buffer.BlockCopy(body1, 0, body.Bytes, 0, body1.Length);
                        System.Buffer.BlockCopy(escapedPassword.Bytes, 0, body.Bytes, body1.Length, escapedPassword.Bytes.Length);
                        req.SetBody(body);
                    }
                }
            }

            return GetAccessToken(myEveAccount, sisi, req, proxyIp, proxyHttpPort, out accessToken);
        }

        public LoginResult GetSSOToken(EveAccount myEveAccount, bool sisi, string proxyIp, string proxyHttpPort, out Token ssoToken)
        {
            Token accessToken;
            LoginResult lr = GetAccessToken(myEveAccount, sisi, proxyIp, proxyHttpPort, out ssoToken);

            return lr;
        }

        /**
        public LoginResult Launch(string sharedCachePath, bool sisi, DirectXVersion dxVersion, long characterID)
        {
            Token ssoToken;
            LoginResult lr = GetSSOToken(sisi, out ssoToken);
            if (lr != LoginResult.Success)
                return lr;
            if (!App.Launch(sharedCachePath, sisi, dxVersion, characterID, ssoToken))
                return LoginResult.Error;

            return LoginResult.Success;
        }
        **/

        /**
        public LoginResult Launch(string gameName, string gameProfileName, bool sisi, DirectXVersion dxVersion, long characterID)
        {
            //string ssoToken;
            //LoginResult lr = GetSSOToken(sisi, out ssoToken);
            //if (lr != LoginResult.Success)
            //    return lr;
            if (!App.Launch(gameName, gameProfileName, sisi, dxVersion, characterID, TranquilityToken))
                return LoginResult.Error;

            return LoginResult.Success;
        }
        **/

        #region INotifyPropertyChanged
        public new event PropertyChangedEventHandler PropertyChanged;

        public void FirePropertyChanged(string value)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(value));
            }
        }
        public new void OnPropertyChanged(string value)
        {
            FirePropertyChanged(value);
        }
        #endregion
        public void Dispose()
        {
            //Web.CookieStorage.DeleteCookies(cachedEveAccount);
            //this.Cookies = null;
            //this.NewCookieStorage = null;
        }
    }
}
