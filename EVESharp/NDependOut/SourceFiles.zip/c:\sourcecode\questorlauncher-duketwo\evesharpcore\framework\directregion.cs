﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using SC::SharedComponents.Py;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectRegion : DirectObject
    {
        #region Fields

        private List<DirectConstellation> _constellations;

        #endregion Fields

        #region Constructors

        internal DirectRegion(DirectEve directEve, dynamic pyo)
            : base(directEve)
        {
            Id = (long) pyo.regionID;
            Name = (string) DirectEve.PySharp.Import("__builtin__").Attribute("cfg").Attribute("evelocations").Call("Get", Id).Attribute("name");
            FactionId = (long?) pyo.factionID;
        }

        #endregion Constructors

        #region Methods

        public static Dictionary<long, DirectRegion> GetRegions(DirectEve directEve)
        {
            Dictionary<long, DirectRegion> result = new Dictionary<long, DirectRegion>();

            dynamic ps = directEve.PySharp;
            Dictionary<long, PyObject> pyDict = ps.__builtin__.cfg.mapRegionCache.ToDictionary<long>();
            foreach (KeyValuePair<long, PyObject> pair in pyDict)
                result[pair.Key] = new DirectRegion(directEve, pair.Value);

            return result;
        }

        #endregion Methods

        #region Properties

        /// <summary>
        ///     List all constellations within this region
        /// </summary>
        public List<DirectConstellation> Constellations
        {
            get { return _constellations ?? (_constellations = DirectEve.Constellations.Values.Where(c => c.RegionId == Id).ToList()); }
        }

        /// <summary>
        ///     List all solarsystems within this region
        /// </summary>
        public List<DirectSolarSystem> SolarSystems
        {
            get
            {
                return Constellations.Select(k => k.SolarSystems).ToList().SelectMany(k => k).ToList();
            }
        }

        public string Description { get; private set; }
        public long? FactionId { get; }
        public long Id { get; }
        public string Name { get; }

        #endregion Properties
    }
}