﻿using EasyHook;
using SharedComponents.CurlUtil;
using SharedComponents.IPC;
using SharedComponents.Utility;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Text.RegularExpressions;
using System.Threading;
using SeasideResearch.LibCurlNet;

namespace SharedComponents.EVE
{
    [Serializable]
    public class Proxy : ViewModelBase
    {
        #region Constructors

        public Proxy(string ip, string port, string username, string password, ConcurrentBindingList<Proxy> list)
        {
            Id = list.Any() ? list.Max(p => p.Id) + 1 : 1;
            Ip = ip;
            Socks5Port = port;
            Username = username;
            Password = password;
            Description = Username + "@" + Ip;
        }

        public Proxy()
        {
        }

        #endregion Constructors

        #region Properties

        public string Description
        {
            get { return GetValue(() => Description); }
            set { SetValue(() => Description, value); }
        }

        [ReadOnly(true)]
        public string ExtIp
        {
            get { return GetValue(() => ExtIp); }
            set { SetValue(() => ExtIp, value); }
        }

        public string HttpProxyPort
        {
            get { return GetValue(() => HttpProxyPort); }
            set { SetValue(() => HttpProxyPort, value); }
        }

        [ReadOnly(true)]
        public int Id
        {
            get { return GetValue(() => Id); }
            set { SetValue(() => Id, value); }
        }

        public string Ip
        {
            get { return GetValue(() => Ip); }
            set { SetValue(() => Ip, value); }
        }

        [ReadOnly(true)]
        public bool IsAlive
        {
            get { return GetValue(() => IsAlive); }
            set { SetValue(() => IsAlive, value); }
        }

        public bool IsValid
        {
            get
            {
                try
                {
                    if (!Regex.Match(Ip, @"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b").Success)
                        return false;

                    if (string.IsNullOrEmpty(Socks5Port))
                    {
                        Cache.Instance.Log("Proxy: Socks5Port [" + Socks5Port + "] is empty! IsValid [" + IsValid + "]");
                        return false;
                    }

                    if (string.IsNullOrEmpty(HttpProxyPort))
                    {
                        Cache.Instance.Log("Proxy: HttpProxyPort [" + HttpProxyPort + "] is empty! IsValid [" + IsValid + "]");
                        return false;
                    }

                    //if (string.IsNullOrEmpty(LocalEveServerPort))
                    //{
                    //    Cache.Instance.Log("Proxy: LocalEveServerPort [" + LocalEveServerPort + "] is empty! IsValid [" + IsValid + "]");
                    //    return false;
                    //}

                    return true;
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception [" + ex + "]");
                    return true;
                }
            }

        }

        [ReadOnly(true)]
        public DateTime LastCheck
        {
            get { return GetValue(() => LastCheck); }
            set { SetValue(() => LastCheck, value); }
        }

        [ReadOnly(true)]
        public DateTime LastFail
        {
            get { return GetValue(() => LastFail); }
            set { SetValue(() => LastFail, value); }
        }

        [ReadOnly(true)]
        public string LinkedAccounts
        {
            get { return GetValue(() => LinkedAccounts); }
            set { SetValue(() => LinkedAccounts, value); }
        }

        [ReadOnly(true)]
        public string LinkedCharacters
        {
            get { return GetValue(() => LinkedCharacters); }
            set { SetValue(() => LinkedCharacters, value); }
        }

        public string Password
        {
            get { return GetValue(() => Password); }
            set { SetValue(() => Password, value); }
        }

        public string Socks5Port
        {
            get { return GetValue(() => Socks5Port); }
            set { SetValue(() => Socks5Port, value); }
        }

        public string LocalEveServerPort
        {
            get { return GetValue(() => LocalEveServerPort); }
            set { SetValue(() => LocalEveServerPort, value); }
        }

        public string Username
        {
            get { return GetValue(() => Username); }
            set { SetValue(() => Username, value); }
        }

        #endregion Properties

        #region Methods

        private DateTime LastInternetConnectivityCheck = DateTime.MinValue;

        private bool? _internetConnectivityTest = null;

        public bool InternetConnectivityTest()
        {
            if (DateTime.UtcNow > LastInternetConnectivityCheck.AddSeconds(6) || _internetConnectivityTest == null || !(bool)_internetConnectivityTest)
            {
                if (_internetConnectivityTest == null)
                {
                    if (!CheckSocks5InternetConnectivity())
                        _internetConnectivityTest = false;

                    if (!CheckHttpProxyInternetConnectivity())
                        _internetConnectivityTest = false;

                    if (_internetConnectivityTest == null)
                        _internetConnectivityTest = true;

                    return _internetConnectivityTest ?? true;
                }

                return _internetConnectivityTest ?? false;
            }

            return _internetConnectivityTest ?? false;
        }

        public bool CheckSocks5InternetConnectivity()
        {
            if (string.IsNullOrEmpty(Ip))
            {
                Cache.Instance.Log("Proxy IP [" + Ip + "] is blank. Fill it in with a valid IP address where your SOCKS5 proxy is listening");
                return false;
            }

            if (!IsValid)
            {
                Cache.Instance.Log("Proxy IP [" + Ip + "] is not in the correct format. IsValid [" + IsValid + "]");
                return false;
            }

            bool areWeConnected = CurlWorker.CheckInternetConnectivity(this, CURLproxyType.CURLPROXY_SOCKS5);
            if (!areWeConnected) Cache.Instance.Log("SOCKS5 Proxy [" + Description + "] Not Responding: Do you have the SOCKS5 server available on port [" + Socks5Port + "] of the host [" + Ip + "]? If using SSH and/or autossh is SSH connected?");
            return areWeConnected;
        }

        public bool CheckHttpProxyInternetConnectivity()
        {
            bool areWeConnected = IsValid && CurlWorker.CheckInternetConnectivity(this, CURLproxyType.CURLPROXY_HTTP);
            if (!areWeConnected) Cache.Instance.Log("Http Proxy [" + Description + "] Not Responding: Do you have the HTTP Proxy Server available on port [" + HttpProxyPort + "] of the host [" + Ip + "]? FYI: you can test this with FoxyProxy (Firefox addon) and add a HTTP Proxy with the appropriate IP/Port");
            return areWeConnected;
        }

        public void Clear()
        {
            IsAlive = false;
            LastCheck = DateTime.MinValue;
            LastFail = DateTime.MinValue;
            ExtIp = string.Empty;
            LinkedAccounts = string.Empty;
            LinkedCharacters = string.Empty;
        }

        public string GetExternalIp()
        {
            if (!IsValid)
                return string.Empty;

            using (CurlWorker cw = new CurlWorker())
            {
                return cw.GetPostPage("http://whoer.net/ip", string.Empty, GetSocks5IpPort(), GetUserPassword());
            }
        }

        public string GetFirefoxProfileCreationParameters()
        {
            string startParams = string.Empty;
            startParams = "-CreateProfile \"EveSharpLauncher c:\\eveoffline\\FirefoxProfile-EveSharpLauncher\" -no-remote";
            return startParams;
        }

        public string GetFirefoxStartParameter(string url = "whoer.net/ip")
        {
            string startParams = string.Empty;
            startParams += "\"-safe-mode -private -url " + url + "\"";
            //startParams = "-P evesharplauncher -no-remote -url " + url;
            return startParams;
        }

        public string GetHashcode()
        {
            return GetSocks5IpPort() + "@" + GetUserPassword();
        }

        public string GetSocks5IpPort()
        {
            return Ip + ":" + Socks5Port;
        }

        public string GetHttpProxyIpPort()
        {
            return Ip + ":" + Socks5Port;
        }

        public string GetUserPassword()
        {
            return Username + ":" + Password;
        }

        public void StartFireFoxInject(string url = "whoer.net/ip")
        {
            try
            {
                while (Process.GetProcesses().Any(x => x.ProcessName.ToLower().Contains("firefox")))
                    foreach (Process p in Process.GetProcesses().Where(x => x.ProcessName.ToLower().Contains("firefox")))
                    {
                        Cache.Instance.Log("Firefox cannot already be running. Killing process [" + p.Id + "][" + p.ProcessName + "]");
                        if (p != null)
                            Util.TaskKill(p.Id, false);
                        Thread.Sleep(1000);
                    }
            }
            catch (Exception)
            {
            }

            Cache.Instance.Log("Proxy: [ " + Description + " ][ " + Ip + ":" + Socks5Port + " ]");

            string[] args = {Id.ToString(), WCFServer.Instance.GetPipeName};
            int firefoxprocessId1 = -1;

            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            string injectionFile = Path.Combine(path, "DomainHandler.dll");
            string ChannelName = null;

            //if (!Cache.Instance.FirefoxLocation.ToLower().EndsWith("firefox.exe"))
            //{
            //    Cache.Instance.Log("firefox.exe filename not properly set? It has to end with firefox.exe");
            //    return;
            //}

            if (!File.Exists(injectionFile))
            {
                Cache.Instance.Log("[" + injectionFile + "] does not exist or correct file permissions are not set to allow this user to read it");
                return;
            }

            if (!File.Exists(Cache.Instance.FirefoxLocation))
            {
                Cache.Instance.Log("[" + Cache.Instance.FirefoxLocation + "] does not exist or correct file permissions are not set to allow this user to read it");
                return;
            }

            if (!Directory.Exists("C:\\eveoffline"))
                Directory.CreateDirectory("C:\\eveoffline");

            try
            {
                RemoteHooking.IpcCreateServer<EVESharpInterface>(ref ChannelName, WellKnownObjectMode.SingleCall);
                Cache.Instance.Log("Proxy: Launching Firefox [ " + Cache.Instance.FirefoxLocation + " " + GetFirefoxStartParameter() + " ]");
                RemoteHooking.CreateAndInject(Cache.Instance.FirefoxLocation, GetFirefoxStartParameter(), (int) InjectionOptions.Default, injectionFile, injectionFile, out firefoxprocessId1, ChannelName, args);

                if (firefoxprocessId1 != -1 && firefoxprocessId1 != 0)
                    Cache.Instance.Log("ProcessId: [" + firefoxprocessId1 + "] Started Firefox Successfully.");
                else
                    Cache.Instance.Log("ProcessId: [" + firefoxprocessId1 + "] Error.");
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception [" + ex + "]");
            }
        }

        public DateTime LastEveSsoAttempt = DateTime.MinValue;

        public bool SafeToAttemptEveSso
        {
            get
            {
                if (LastEveSsoAttempt.AddSeconds(15) > DateTime.UtcNow)
                    return false;

                return true;
            }
        }

        public void StartProxyScript(string ProxyStartupScriptPath, string ProxyDescription)
        {
            try
            {
                ProcessStartInfo processStartInfo = new ProcessStartInfo(ProxyStartupScriptPath);
                Process.Start(processStartInfo);
                Cache.Instance.Log("Starting [" + ProxyStartupScriptPath + "] for Proxy [" + ProxyDescription + "]");
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception [" + ex + "]");
            }
        }

        #endregion Methods
    }
}