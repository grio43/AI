﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using EVESharpCore.Cache;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using SC::SharedComponents.EVE;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.Extensions;
using SC::SharedComponents.IPC;
using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public enum MissionState
    {
        Offered = 1,
        Accepted = 2,
        OfferExpired = 3,
        Unknown4 = 4,
        Unknown5 = 5
    }

    public class DirectAgentMission : DirectObject
    {
        #region Fields

        private PyObject _pyAgentId;

        #endregion Fields

        #region Constructors

        internal DirectAgentMission(DirectEve directEve) : base(directEve)
        {
        }

        #endregion Constructors

        #region Properties

        public DateTime LastAcceptMissionAttempt = DateTime.MinValue;

        public DateTime LastCompleteMissionAttempt = DateTime.MinValue;

        public DateTime LastDeclineMissionAttempt = DateTime.MinValue;

        public DateTime LastMissionCompletionError = DateTime.MinValue;

        public int MissionCompletionErrors = 0;

        public int moveItemProcessRepititions;
        public int moveItemRetryCounter;

        private DirectAgent _agent;

        private DirectItem _courierMissionItemToMove;

        public DirectAgent Agent
        {
            get
            {
                if (_agent == null)
                {
                    _agent = DirectEve.GetAgentById(AgentId);
                    return _agent;
                }

                return _agent;
            }
        }

        public long AgentId { get; internal set; }

        public List<DirectAgentMissionBookmark> Bookmarks { get; internal set; }

        public List<DirectBookmark> _storylineBookmarks = new List<DirectBookmark>();

        public List<DirectBookmark> StorylineBookmarks
        {
            get
            {
                if (!_storylineBookmarks.Any())
                {
                    foreach (DirectBookmark tempBookmark in DirectEve.Bookmarks)
                    {
                        if (tempBookmark.CreatedOn.Value.Hour == ExpiresOn.Hour)
                        {
                            _storylineBookmarks.Add(tempBookmark);
                            continue;
                        }
                    }

                    return _storylineBookmarks;
                }

                return _storylineBookmarks;
            }
        }

        public DirectAgentMissionBookmark CourierMissionDropoffBookmark
        {
            get
            {
                if (Bookmarks == null)
                    return null;

                if (Bookmarks != null && Bookmarks.Any())
                    return Bookmarks.FirstOrDefault(i => i.Title.Contains("Objective (Drop Off)") && i.AgentId == AgentId);

                //if (StorylineBookmarks != null && StorylineBookmarks.Any())
                //    return new DirectAgentMissionBookmark(StorylineBookmarks.FirstOrDefault(i => i.Title.Contains("Objective (Drop Off)"));

                return null;
            }
        }

        public DirectItem CourierMissionItemToMove
        {
            get
            {
                try
                {
                    if (_courierMissionItemToMove == null)
                    {
                        if (DirectEve.DictCurrentCourierMissionCtrlState.ContainsKey(UniqueMissionId))
                        {
                            _courierMissionItemToMove = DirectEve.DictCurrentCourierMissionItemToMove[Agent.AgentId];
                            return _courierMissionItemToMove;
                        }

                        if (!DirectEve.DictCurrentCourierMissionItemToMove.Any())
                        {
                            DirectEve.Log("DictCurrentCourierMissionItemToMove was not found: DictCurrentCourierMissionCtrlState was empty!");
                            //DirectEve.DictCurrentCourierMissionItemToMove.AddOrUpdate(Agent.AgentId, CourierMissionCtrlState.Start);
                            return null;
                        }

                        DirectEve.Log("DictCurrentCourierMissionItemToMove has no value in the dictionary for Agent [" + Agent.Name + "]");
                        int tempStateNum = 0;
                        DirectEve.Log("--------------------------------------");
                        foreach (KeyValuePair<long, DirectItem> tempCurrentCourierMissionItemToMove in DirectEve.DictCurrentCourierMissionItemToMove)
                        {
                            tempStateNum++;
                            DirectEve.Log("[" + tempStateNum + "][" + tempCurrentCourierMissionItemToMove.Key + "][" + tempCurrentCourierMissionItemToMove.Value + "]");
                        }

                        DirectEve.Log("--------------------------------------");
                        //DirectEve.Log("Error!: !if (State.DictCurrentCourierMissionCtrlState.ContainsKey(Agent.AgentId))");
                        return null;
                    }

                    return _courierMissionItemToMove;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
            set
            {
                try
                {
                    //DirectEve.Log("Mission [" + Name + "] New CourierMissionCtrlState [" + courierMbStateToSet + "] Old CourierMissionCtrlState was [" + PreviousCourierMissionCtrlState + "] ");
                    if (DirectEve.DictCurrentCourierMissionItemToMove.ContainsKey(Agent.AgentId))
                    {
                        DirectEve.DictCurrentCourierMissionItemToMove[Agent.AgentId] = value;
                        return;
                    }

                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CourierItemTypeId), value);
                    DirectEve.DictCurrentCourierMissionItemToMove.Add(Agent.AgentId, value);
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                }
            }
        }

        public DirectAgentMissionBookmark CourierMissionPickupBookmark
        {
            get
            {
                if (Bookmarks == null)
                    return null;

                if (Bookmarks != null && Bookmarks.Any())
                    return Bookmarks.FirstOrDefault(i => i.Title.Contains("Objective (Pick Up)") && i.AgentId == AgentId);

                //if (StorylineBookmarks != null && StorylineBookmarks.Any())
                //    return StorylineBookmarks.FirstOrDefault(i => i.Title.Contains("Objective (Pick Up)"));

                return null;
            }
        }

        public CourierMissionCtrlState CurrentCourierMissionCtrlState
        {
            get
            {
                try
                {
                    if (DirectEve.DictCurrentCourierMissionCtrlState.ContainsKey(UniqueMissionId))
                        return DirectEve.DictCurrentCourierMissionCtrlState[UniqueMissionId];

                    if (!DirectEve.DictCurrentCourierMissionCtrlState.Any())
                    {
                        DirectEve.Log("CurrentCourierMissionCtrlState was not found: DictCurrentCourierMissionCtrlState was empty!");
                        DirectEve.DictCurrentCourierMissionCtrlState.AddOrUpdate(UniqueMissionId, CourierMissionCtrlState.Start);
                        return CourierMissionCtrlState.Start;
                    }
                    DirectEve.Log("CurrentCourierMissionCtrlState was blank: setting [" + CourierMissionCtrlState.Start + "] for Agent [" + Agent.Name + "]");
                    int tempStateNum = 0;
                    DirectEve.Log("--------------------------------------");
                    foreach (KeyValuePair<Tuple<long, string>, CourierMissionCtrlState> tempCourierMissionCtrlState in DirectEve.DictCurrentCourierMissionCtrlState)
                    {
                        tempStateNum++;
                        DirectEve.Log("[" + tempStateNum + "][" + tempCourierMissionCtrlState.Key + "][" + tempCourierMissionCtrlState.Value + "]");
                    }

                    DirectEve.Log("--------------------------------------");

                    DirectEve.DictCurrentCourierMissionCtrlState.AddOrUpdate(UniqueMissionId, CourierMissionCtrlState.Start);
                    if (DirectEve.DictCurrentCourierMissionCtrlState.ContainsKey(UniqueMissionId))
                        return DirectEve.DictCurrentCourierMissionCtrlState[UniqueMissionId];

                    //DirectEve.Log("Error!: !if (State.DictCurrentCourierMissionCtrlState.ContainsKey(Agent.AgentId))");
                    return CourierMissionCtrlState.Start;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return CourierMissionCtrlState.Idle;
                }
            }
        }

        public CourierMissionCtrlState PreviousCourierMissionCtrlState
        {
            get
            {
                try
                {
                    if (DirectEve.DictPreviousCourierMissionCtrlState.ContainsKey(UniqueMissionId))
                        return DirectEve.DictPreviousCourierMissionCtrlState[UniqueMissionId];

                    if (!DirectEve.DictPreviousCourierMissionCtrlState.Any())
                    {
                        DirectEve.Log("PreviousCourierMissionCtrlState was not found: DictPreviousCourierMissionCtrlState was empty!");
                        DirectEve.DictPreviousCourierMissionCtrlState.AddOrUpdate(UniqueMissionId, CourierMissionCtrlState.Start);
                        return CourierMissionCtrlState.Start;
                    }
                    DirectEve.Log("PreviousCourierMissionCtrlState was blank: setting [" + CourierMissionCtrlState.Start + "] for Agent [" + Agent.Name + "]");
                    int tempStateNum = 0;
                    DirectEve.Log("--------------------------------------");
                    foreach (KeyValuePair<Tuple<long, string>, CourierMissionCtrlState> tempCourierMissionCtrlState in DirectEve.DictCurrentCourierMissionCtrlState)
                    {
                        tempStateNum++;
                        DirectEve.Log("[" + tempStateNum + "][" + tempCourierMissionCtrlState.Key + "][" + tempCourierMissionCtrlState.Value + "]");
                    }

                    DirectEve.Log("--------------------------------------");

                    DirectEve.DictPreviousCourierMissionCtrlState.AddOrUpdate(UniqueMissionId, CourierMissionCtrlState.Start);
                    if (DirectEve.DictPreviousCourierMissionCtrlState.ContainsKey(UniqueMissionId))
                        return DirectEve.DictPreviousCourierMissionCtrlState[UniqueMissionId];

                    //DirectEve.Log("Error!: !if (State.DictCurrentCourierMissionCtrlState.ContainsKey(Agent.AgentId))");
                    return CourierMissionCtrlState.Start;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return CourierMissionCtrlState.Idle;
                }
            }
        }

        public DateTime ExpiresOn { get; internal set; }

        private Faction _faction { get; set; }
        public Faction Faction
        {
            get
            {
                if (_faction == null)
                {
                    try
                    {
                        if (DirectEve.DictCurrentMissionFaction.ContainsKey(UniqueMissionId))
                            return DirectEve.DictCurrentMissionFaction[UniqueMissionId];


                        //if (ESCache.Instance.InSpace)
                        //    return new Faction("Default", DamageType.EM, null, null, null);

                        if (Agent == null)
                        {
                            return null;
                        }

                        if (DirectEve.Windows.OfType<DirectAgentWindow>().FirstOrDefault(w => w.AgentId == AgentId) == null)
                        {
                            if (!DirectEve.Session.IsInSpace)
                            {
                                Log.WriteLine("DirectAgentMission: Faction: if (Agent.Window == null)");
                                if (!Agent.OpenAgentWindow(true)) return null;
                            }

                            return null;
                        }

                        if (Agent.Window != null && !Agent.Window.ObjectiveEmpty)
                        {
                            Log.WriteLine("Objective: " + Agent.Window.Objective);
                            if (Agent.Window.Objective.Contains("Anomic Team"))
                            {
                                Log.WriteLine("Faction: Anomic Team found in Objective");
                                if (Agent.Window.Objective.Contains("Destroy the Enyo")) //works
                                {
                                    Log.WriteLine("Faction: Destroy the Enyo found in Objective");
                                    _faction = new Faction("Enyo", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else if (Agent.Window.Objective.Contains("Destroy the Jaguar")) //works
                                {
                                    Log.WriteLine("Faction: Destroy the Jaguar found in Objective");
                                    _faction = new Faction("Jaguar", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else if (Agent.Window.Objective.Contains("Destroy the Vengeance"))
                                {
                                    Log.WriteLine("Faction: Destroy the Vengeance found in Objective");
                                    _faction = new Faction("Vengeance", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else if (Agent.Window.Objective.Contains("Destroy the Hawk"))
                                {
                                    Log.WriteLine("Faction: Destroy the Hawk found in Objective");
                                    _faction = new Faction("Hawk", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else
                                {
                                    DirectEve.Log("Mission [ Anomic Team ] - unable to find Faction Name: this mission flavor needs to be added. pausing");
                                    DirectEve.Log(Agent.Window.Objective);
                                    DirectEve.Log("Mission [ Anomic Team ] - unable to find Faction Name: this mission flavor needs to be added. pausing");
                                    ControllerManager.Instance.SetPause(true);
                                    return null;
                                }
                            }

                            if (Agent.Window.Objective.Contains("Anomic Agent"))
                            {
                                if (Agent.Window.Objective.Contains("Destroy the Guristas Burner"))
                                {
                                    Log.WriteLine("Faction: Destroy the Guristas Burner found in Objective"); //works
                                    _faction = new Faction("Worm", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else if (Agent.Window.Objective.Contains("Destroy the Blood Raiders Burner")) //works
                                {
                                    Log.WriteLine("Faction: Destroy the Blood Raiders found in Objective");
                                    _faction = new Faction("Cruor", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else if (Agent.Window.Objective.Contains("Destroy the Angel Cartel Burner"))
                                {
                                    Log.WriteLine("Faction: Destroy the Dramiel found in Objective");
                                    _faction = new Faction("Dramiel", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else if (Agent.Window.Objective.Contains("Destroy the Serpentis Burner"))
                                {
                                    Log.WriteLine("Faction: Destroy the Daredevil found in Objective");
                                    _faction = new Faction("Daredevil", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                                else if (Agent.Window.Objective.Contains("Destroy the Sansha's Nation Burner"))
                                {
                                    Log.WriteLine("Faction: Destroy the Sansha's Nation found in Objective");
                                    _faction = new Faction("Succubus", DamageType.EM, null, null, null, true);
                                    DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                    return _faction;
                                }
                            }

                            if (Agent.Window.Objective.Contains("Destroy the Rogue Drones") ||
                                Agent.Window.Objective.Contains("Rogue Drone Harassment Objectives") ||
                                Agent.Window.Objective.Contains("Air Show! Objectives") ||
                                Agent.Window.Objective.Contains("Alluring Emanations Objectives") ||
                                Agent.Window.Objective.Contains("Anomaly Objectives") ||
                                Agent.Window.Objective.Contains("Attack of the Drones Objectives") ||
                                Agent.Window.Objective.Contains("Drone Detritus Objectives") ||
                                Agent.Window.Objective.Contains("Drone Infestation Objectives") ||
                                Agent.Window.Objective.Contains("Evolution Objectives") ||
                                Agent.Window.Objective.Contains("Infected Ruins Objectives") ||
                                Agent.Window.Objective.Contains("Infiltrated Outposts Objectives") ||
                                Agent.Window.Objective.Contains("Mannar Mining Colony") ||
                                Agent.Window.Objective.Contains("Missing Convoy Objectives") ||
                                Agent.Window.Objective.Contains("Onslaught Objectives") ||
                                Agent.Window.Objective.Contains("Patient Zero Objectives") ||
                                Agent.Window.Objective.Contains("Persistent Pests Objectives") ||
                                Agent.Window.Objective.Contains("Portal to War Objectives") ||
                                Agent.Window.Objective.Contains("Rogue Eradication Objectives") ||
                                Agent.Window.Objective.Contains("Rogue Hunt Objectives") ||
                                Agent.Window.Objective.Contains("Rogue Spy Objectives") ||
                                Agent.Window.Objective.Contains("Roving Rogue Drones Objectives") ||
                                Agent.Window.Objective.Contains("Soothe The Salvage Beast") ||
                                Agent.Window.Objective.Contains("Wildcat Strike Objectives"))
                            {
                                _faction = DirectNpcInfo.RogueDronesFaction;
                                DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                return _faction;
                            }

                            if (Agent.Window.Objective.Contains("Silence The Informant Objectives"))
                            {
                                _faction = DirectNpcInfo.MercenariesFaction;
                                DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                return _faction;
                            }

                            if (Agent.Window.Objective.Contains("Gone Berserk Objectives"))
                            {
                                _faction = DirectNpcInfo.EoM;
                                DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                return _faction;
                            }

                            if (Agent.Window.Objective.Contains("In the Midst of Deadspace (1 of 5)")
                             || Agent.Window.Objective.Contains("In the Midst of Deadspace (2 of 5)")
                             || Agent.Window.Objective.Contains("In the Midst of Deadspace (3 of 5)")
                             || Agent.Window.Objective.Contains("In the Midst of Deadspace (4 of 5)"))
                            {
                                _faction = DirectNpcInfo.AmarrEmpireFaction;
                                DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                return _faction;
                            }

                            if (Agent.Window.Objective.Contains("In the Midst of Deadspace (5 of 5)"))
                            {
                                _faction = DirectNpcInfo.CaldariStateFaction;
                                DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                return _faction;
                            }

                            if (Agent.Window.Objective.Contains("The Damsel In Distress Objectives"))
                            {
                                _faction = DirectNpcInfo.EoM;
                                DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                return _faction;
                            }

                            if (Agent.Window.Objective.Contains("Worlds Collide Objectives"))
                            {
                                _faction = DirectNpcInfo.SanshasNationFaction;
                                DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                                return _faction;
                            }

                            _faction = DetermineFactionFromFactionLogo(Agent.Window.Objective);
                            if (_faction.Name.ToLower().Contains("Default".ToLower()))
                            {
                                DirectEve.Log("Unable to find the faction for [" + Name + "] when searching through the html (listed below)");
                                DirectEve.Log(Agent.Window.Objective);
                                return null;
                            }

                            DirectEve.DictCurrentMissionFaction.AddOrUpdate(UniqueMissionId, _faction);
                            return _faction;
                        }

                        Log.WriteLine("Unable to find the faction for [" + Name + "] the objectiveHtml was blank!");
                        if (DirectEve.Session.IsInDockableLocation && Agent.StationId == DirectEve.Session.StationId)
                        {
                            if (Agent.Window != null)
                                if (Agent.Window.ViewMode == "SinglePaneView" && Agent.Window.Buttons.Any(i => i.Type == ButtonType.VIEW_MISSION))
                                    if (DateTime.UtcNow > Time.Instance.NextWindowAction)
                                    {
                                        if (Agent.Window.Buttons.FirstOrDefault(button => button.Type == ButtonType.VIEW_MISSION).Click())
                                        {
                                            Log.WriteLine("if (Agent.Window.Buttons.FirstOrDefault(button => button.Type == ButtonType.VIEW_MISSION).Click())");
                                            Time.Instance.NextWindowAction = DateTime.UtcNow.AddSeconds(1);
                                            return null;
                                        }
                                    }
                        }

                        return null;
                    }
                    catch (Exception ex)
                    {
                        DirectEve.Log("Exception [" + ex + "]");
                        return DirectNpcInfo.DefaultFaction;
                    }
                }

                return _faction;
            }
        }

        public List<DamageType> BestDamagesTypesToShoot
        {
            get
            {
                if (Faction != null)
                {
                    if (Faction.Name.ToLower().Contains("Default".ToLower()))
                        return null;

                    if (Faction.BestDamageTypesToShoot != null && Faction.BestDamageTypesToShoot.Any())
                        return Faction.BestDamageTypesToShoot;
                }

                return new List<DamageType>();
            }
        }

        public long? MissionHint_TravelToLocationId
        {
            get
            {
                try
                {
                    string tempGetMissionInfo = GetAgentMissionRawCsvHint();
                    if (tempGetMissionInfo.Contains("TravelTo"))
                    {
                        string[] stringMissionHint = tempGetMissionInfo.Split(',');
                        foreach (string stringMissionHintElement in stringMissionHint)
                        {
                            if (stringMissionHintElement.Contains("TravelTo"))
                                continue;

                            long tempLocationId = long.Parse(stringMissionHintElement);
                            return tempLocationId;
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public long? MissionHint_ApproachItemId
        {
            get
            {
                try
                {
                    string tempGetMissionInfo = GetAgentMissionRawCsvHint();
                    if (tempGetMissionInfo.Contains("Approach"))
                    {
                        string[] stringMissionHint = tempGetMissionInfo.Split(',');
                        int intCount = 0;
                        foreach (string stringMissionHintElement in stringMissionHint)
                        {
                            //
                            //Approach                                  TypeID and ItemID
                            //
                            intCount++;
                            if (2 > intCount) continue;

                            if (intCount == 2)
                            {
                                long tempLocationId = long.Parse(stringMissionHintElement);
                                return tempLocationId;
                            }
                        }
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public int? MissionHint_MissionFetchTypeId
        {
            get
            {
                try
                {
                    string tempGetMissionInfo = GetAgentMissionRawCsvHint();
                    if (tempGetMissionInfo.Contains("MissionFetch"))
                    {
                        string[] stringMissionHint = tempGetMissionInfo.Split(',');
                        foreach (string stringMissionHintElement in stringMissionHint)
                        {
                            if (stringMissionHintElement.Contains("MissionFetch"))
                                continue;

                            int tempTypeId = int.Parse(stringMissionHintElement);
                            return tempTypeId;
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public int MissionHint_TransportItemMissingTypeId
        {
            get
            {
                try
                {
                    string tempGetMissionInfo = GetAgentMissionRawCsvHint();
                    if (tempGetMissionInfo.Contains("TransportItemsMissing"))
                    {
                        string[] stringMissionHint = tempGetMissionInfo.Split(',');
                        foreach (string stringMissionHintElement in stringMissionHint)
                        {
                            if (stringMissionHintElement.Contains("TransportItemsMissing"))
                                continue;

                            int tempTypeId = int.Parse(stringMissionHintElement);
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CourierItemTypeId), tempTypeId);
                            return tempTypeId;
                        }
                    }

                    return 0;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return 0;
                }
            }
        }


        public int? MissionHint_MissionFetchContainerTypeId
        {
            get
            {
                try
                {
                    string tempGetMissionInfo = GetAgentMissionRawCsvHint();
                    if (tempGetMissionInfo.Contains("MissionFetchContainer"))
                    {
                        string[] stringMissionHint = tempGetMissionInfo.Split(',');
                        int intCount = 0;
                        foreach (string stringMissionHintElement in stringMissionHint)
                        {
                            //
                            //MissionFetchContainer                     TypeID and ContainerID
                            //
                            intCount++;
                            if (2 > intCount) continue;

                            if (intCount == 2)
                            {
                                int? tempContainerTypeId = int.Parse(stringMissionHintElement);
                                return tempContainerTypeId;
                            }

                            continue;
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public long? MissionHint_MissionFetchContainerId
        {
            get
            {
                try
                {
                    string tempGetMissionInfo = GetAgentMissionRawCsvHint();
                    if (tempGetMissionInfo.Contains("MissionFetchContainer"))
                    {
                        string[] stringMissionHint = tempGetMissionInfo.Split(',');
                        long? tempContainerId = 0;
                        int intCount = 0;
                        foreach (string stringMissionHintElement in stringMissionHint)
                        {
                            //
                            //MissionFetchContainer                     TypeID and ContainerID
                            //
                            intCount++;
                            if (2 > intCount) continue;

                            if (intCount == 2)
                            {
                                tempContainerId = int.Parse(stringMissionHintElement);
                                return tempContainerId;
                            }

                            return null;
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public bool? IsMissionFinished
        {
            get
            {
                try
                {
                    if (ESCache.Instance.InSpace && ESCache.Instance.InMission && Name.ToLower().Contains("Anomic".ToLower()))
                        return false;

                    if (GetAgentMissionRawCsvHint().ToLower().Contains("AllObjectivesComplete".ToLower()))
                    {
                        //if (Name.ToLower().Contains("The Blockade".ToLower()))
                        //    return false;

                        return true;
                    }

                    if (GetAgentMissionRawCsvHint().ToLower().Contains("FetchObjectAcquiredDungeonDone".ToLower()))
                        return true;

                    if (ESCache.Instance.InStation)
                    {
                        if (Agent.Window == null) return false;
                        if (Agent.Window.Objective.Contains("Objectives Complete"))
                            return true;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        public string GetAgentMissionRawCsvHint()
        {
            //TravelTo                                  LocationID
            //MissionFetch                              TypeID
            //MissionFetchContainer                     TypeID and ContainerID
            //MissionFetchMine                          TypeID and Quantity
            //MissionFetchMineTrigger                   TypeID
            //MissionFetchTarget                        TypeID and TargetTypeID
            //AllObjectivesComplete                     AgentID
            //TransportItemsPresent                     TypeID and StationID
            //TransportItemsMissing                     TypeID
            //FetchObjectAcquiredDungeonDone            TypeID, AgentID, and StationID
            //GoToGate                                  ItemID
            //KillTrigger                               TypeID, ItemID, and EventTypeName
            //DestroyLCSAndAll                          TypeID and ItemID
            //Destroy                                   TypeID and ItemID
            //Attack                                    TypeID and ItemID
            //Approach                                  TypeID and ItemID
            //Hack                                      TypeID and ItemID
            //Salvage                                   TypeID and ItemID
            //DestroyAll                                None

            string ret = string.Empty;

            if (!Agent.IsValid) return ret;

            PyObject obj = DirectEve.GetLocalSvc("missionObjectivesTracker").Attribute("currentAgentMissionInfo");

            if (obj == null || !obj.IsValid) return ret;

            Dictionary<long, PyObject> dict = obj.ToDictionary<long>();

            if (dict.ContainsKey(AgentId))
                ret = dict[AgentId].ToUnicodeString();

            return ret ?? string.Empty;
        }
        public bool ObjectivesComplete
        {
            get
            {
                bool objectivesComplete = GetAgentMissionRawCsvHint().ToLower().Contains("FetchObjectAcquiredDungeonDone".ToLower())
                                          || GetAgentMissionRawCsvHint().ToLower().Contains("AllObjectivesComplete".ToLower());

                return objectivesComplete;
            }
        }

        public bool Important { get; internal set; }

        public int? JumpsToDropoffBookmark
        {
            get
            {
                if (CourierMissionDropoffBookmark != null)
                {
                    if (CourierMissionDropoffBookmark.SolarSystemId == DirectEve.Session.SolarSystemId)
                        return 0;

                    return CourierMissionDropoffBookmark.SolarSystem.JumpsHighSecOnly;
                }

                return null;
            }
        }

        public int? JumpsToPickupBookmark
        {
            get
            {
                if (CourierMissionPickupBookmark != null)
                {
                    if (CourierMissionPickupBookmark.SolarSystemId == DirectEve.Session.SolarSystemId)
                        return 0;

                    return CourierMissionPickupBookmark.SolarSystem.JumpsHighSecOnly;
                }

                return null;
            }
        }

        public int Level => Agent.Level;

        public bool MissionInfoNeverShowsMissionComplete
        {
            get
            {
                switch (Level)
                {
                    case 1:
                        break;

                    case 2:
                        switch (Name)
                        {
                            case "Recon (1 of 3)":
                                return true;
                        }
                        break;

                    case 3:
                        break;

                    case 4:
                        break;

                    case 5:
                        break;
                }

                return false;
            }
        }

        public string Name { get; internal set; }

        public MissionState State { get; internal set; }
        //public int State { get; internal set; }

        public string Type { get; internal set; }

        public Tuple<long, string> UniqueMissionId
        {
            get
            {
                if (!string.IsNullOrEmpty(Name))
                    return new Tuple<long, string>(Agent.AgentId, Name + ExpiresOn);

                return new Tuple<long, string>(0, string.Empty);
            }
        }

        public bool WeAreDockedAtDropOffLocation
        {
            get
            {
                if (CourierMissionDropoffBookmark != null)
                {
                    if (CourierMissionDropoffBookmark.Station.Name == DirectEve.Session.Station.Name)
                        return true;

                    return false;
                }

                return false;
            }
        }

        public bool WeAreDockedAtPickupLocation
        {
            get
            {
                if (CourierMissionPickupBookmark != null)
                {
                    if (CourierMissionPickupBookmark.Station.Name == DirectEve.Session.Station.Name)
                        return true;

                    return false;
                }

                return false;
            }
        }

        private DirectContainer _courierMissionFromContainer
        {
            get
            {
                if (CourierMissionFromContainerName.ToLower() == "ItemHangar".ToLower())
                    return DirectContainer.GetItemHangar(DirectEve);

                if (CourierMissionFromContainerName.ToLower() == "CargoHold".ToLower())
                    return DirectContainer.GetShipsCargo(DirectEve);

                return null;
            }
        }

        private DirectContainer _courierMissionToContainer
        {
            get
            {
                if (CourierMissionToContainerName.ToLower() == "ItemHangar".ToLower())
                    return DirectContainer.GetItemHangar(DirectEve);

                if (CourierMissionToContainerName.ToLower() == "CargoHold".ToLower())
                    return DirectContainer.GetShipsCargo(DirectEve);

                return null;
            }
        }

        public bool ChangeCourierMissionCtrlState(CourierMissionCtrlState courierMbStateToSet)
        {
            try
            {
                Dictionary<Tuple<long, string>, CourierMissionCtrlState> tempDictionary = DirectEve.DictCurrentCourierMissionCtrlState;
                foreach (KeyValuePair<Tuple<long, string>, CourierMissionCtrlState> kvp in tempDictionary)
                    //Do we have ANY mission matching the entry in the Dictionary
                    if (DirectEve.AgentMissions.All(i => i.AgentId != kvp.Key.Item1))
                        DirectEve.DictCurrentCourierMissionCtrlState.Remove(kvp.Key);

                if (CurrentCourierMissionCtrlState != courierMbStateToSet)
                {
                    DirectEve.DictPreviousCourierMissionCtrlState.AddOrUpdate(UniqueMissionId, CurrentCourierMissionCtrlState);
                    Log.WriteLine("Mission [" + Name + "] New CourierMissionCtrlState [" + courierMbStateToSet + "] Old CourierMissionCtrlState was [" + PreviousCourierMissionCtrlState + "] ");
                    DirectEve.DictCurrentCourierMissionCtrlState.AddOrUpdate(UniqueMissionId, courierMbStateToSet);
                    return true;
                }
            }
            catch (Exception ex)
            {
                DirectEve.Log("Exception [" + ex + "]");
                return false;
            }

            return true;
        }

        public DirectContainer CourierMissionFromContainer
        {
            get
            {
                if (_courierMissionFromContainer == null)
                {
                    if (Agent.Mission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.PickupItem ||
                        Agent.Mission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.TryToGrabPickupItemsFromHomeStation)
                    {
                        CourierMissionFromContainerName = "ItemHangar";
                        CourierMissionToContainerName = "CargoHold";
                        return _courierMissionFromContainer;
                    }

                    if (Agent.Mission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.DropOffItem) //otherwise you are dropping off
                    {
                        CourierMissionFromContainerName = "CargoHold";
                        CourierMissionToContainerName = "ItemHangar";
                        return _courierMissionFromContainer;
                    }

                    CourierMissionFromContainerName = string.Empty;
                    Log.WriteLine("CourierMissionFromContainer == null: CurrentCourierMissionCtrlState: [" + Agent.Mission.CurrentCourierMissionCtrlState + "]");
                    return null;
                }

                return _courierMissionFromContainer;
            }
        }

        public bool? LowSecWarning
        {
            get
            {
                if (Agent.Window == null) return false;
                return Agent.Window.LowSecWarning;
            }
        }

        public bool? RouteContainsLowSecuritySystems
        {
            get
            {
                if (Agent.Window == null) return false;
                return Agent.Window.RouteContainsLowSecuritySystems;
            }
        }

        public string CourierMissionToContainerName
        {
            get
            {
                if (DirectEve.DictCurrentCourierMissionToContainer.ContainsKey(Agent.AgentId))
                {
                    string tempHangarName = DirectEve.DictCurrentCourierMissionToContainer[Agent.AgentId];
                    return tempHangarName;
                }

                return string.Empty;
            }
            set
            {
                if (DirectEve.DictCurrentCourierMissionToContainer.ContainsKey(Agent.AgentId))
                    DirectEve.DictCurrentCourierMissionToContainer.Remove(Agent.AgentId);

                DirectEve.DictCurrentCourierMissionToContainer.Add(Agent.AgentId, value);
            }
        }

        public string CourierMissionFromContainerName
        {
            get
            {
                if (DirectEve.DictCurrentCourierMissionFromContainer.ContainsKey(Agent.AgentId))
                {
                    string tempHangarName = DirectEve.DictCurrentCourierMissionFromContainer[Agent.AgentId];
                    return tempHangarName;
                }

                return string.Empty;
            }
            set
            {
                if (DirectEve.DictCurrentCourierMissionFromContainer.ContainsKey(Agent.AgentId))
                    DirectEve.DictCurrentCourierMissionFromContainer.Remove(Agent.AgentId);

                DirectEve.DictCurrentCourierMissionFromContainer.Add(Agent.AgentId, value);
            }
        }

        public DirectContainer CourierMissionToContainer
        {
            get
            {
                if (_courierMissionToContainer == null)
                {
                    if (Agent.Mission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.PickupItem ||
                        Agent.Mission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.TryToGrabPickupItemsFromHomeStation)
                    {
                        CourierMissionToContainerName = "CargoHold";
                        CourierMissionFromContainerName = "ItemHangar";
                        return _courierMissionToContainer;
                    }

                    if (Agent.Mission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.DropOffItem) //otherwise you are dropping off
                    {
                        CourierMissionToContainerName = "ItemHangar";
                        CourierMissionFromContainerName = "CargoHold";
                        return _courierMissionToContainer;
                    }

                    CourierMissionToContainerName = string.Empty;
                    Log.WriteLine("CourierMissionToContainer == null: CurrentCourierMissionCtrlState: [" + Agent.Mission.CurrentCourierMissionCtrlState + "]");
                    return null;
                }

                return _courierMissionToContainer;
            }
        }

        private Faction DetermineFactionFromFactionLogo(string objectiveHtml)
        {
            //if (Agent.Window.ObjectiveEmpty)
            //{
            //    Agent.PressViewButtonIfItExists("GetFactionType");
            //    return null;
            //}

            Regex logoRegex = new Regex("img src=\"factionlogo:(?<factionlogo>\\d+)");
            Match logoMatch = logoRegex.Match(objectiveHtml);
            if (logoMatch.Success)
            {
                string factionid = logoMatch.Groups["factionlogo"].Value;
                Faction _faction = null;
                DirectNpcInfo.FactionIdsToFactions.TryGetValue(factionid, out _faction);
                if (_faction == null)
                    return new Faction("Default", DamageType.EM, null, null, null, true);

                return _faction;
            }

            return new Faction("Default", DamageType.EM, null, null, null, true);
        }

        public void Reset()
        {
            //if (DebugConfig.DebugCourierMissions) Log.WriteLine("CourierMissionCtrl: Reset: CourierMissionToContainer = null, CourierMissionFromContainer = null, _itemToMove = null");
            CourierMissionItemToMove = null;
            moveItemProcessRepititions = 0;
            moveItemRetryCounter = 0;
        }

        #endregion Properties

        #region Methods



        //public bool ObjectiveEmpty => Agent.Window.Objective?.Equals("<html><body></body></html>") ?? true;

        /// <summary>
        ///     Ensure the journal mission tab is open before RemoveOffer is called
        /// </summary>
        /// <returns></returns>
        public bool RemoveOffer()
        {
            if (State != (MissionState)(int)PySharp.Import("__builtin__").Attribute("const").Attribute("agentMissionStateOffered"))
                return false;

            return DirectEve.ThreadedLocalSvcCall("agents", "RemoveOfferFromJournal", _pyAgentId);
        }

        internal static List<DirectAgentMission> GetAgentMissions(DirectEve directEve)
        {
            List<DirectAgentMission> missions = new List<DirectAgentMission>();

            List<PyObject> pyMissions = directEve.GetLocalSvc("journal").Attribute("agentjournal").Item(0).ToList();

            foreach (PyObject pyMission in pyMissions)
            {
                DirectAgentMission mission = new DirectAgentMission(directEve)
                {
                    State = (MissionState)(int)pyMission.Item(0),
                    Important = (bool)pyMission.Item(1),
                    Type = (string)pyMission.Item(2),
                    _pyAgentId = pyMission.Item(4),
                    AgentId = (long)pyMission.Item(4),
                    ExpiresOn = (DateTime)pyMission.Item(5),
                    Bookmarks = pyMission.Item(6).ToList().Select(b => new DirectAgentMissionBookmark(directEve, b)).ToList()
                    //7 = False
                    //8 = False
                    //9 = 3 digit int
                };

                int messageId = (int)pyMission.Item(3);
                if (messageId > 0)
                {
                    mission.Name = directEve.GetLocalizationMessageById(messageId);
                }
                else
                {
                    mission.Name = "none";
                    continue;
                }

                missions.Add(mission);
            }

            return missions;
        }

        #endregion Methods
    }
}