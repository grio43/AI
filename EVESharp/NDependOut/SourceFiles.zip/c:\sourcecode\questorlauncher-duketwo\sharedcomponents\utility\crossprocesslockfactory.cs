﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 19.03.2014
 * Time: 20:51
 *
 * ---------------------------------------
 */

using System;
using System.Diagnostics;
using System.Threading;

namespace SharedComponents.Utility
{
    public class CrossProcessLockFactory
    {
        #region Methods

        public static IDisposable CreateCrossProcessLock()
        {
            return new ProcessLock(-1);
        }

        public static IDisposable CreateCrossProcessLock(int delayMs)
        {
            return new ProcessLock(delayMs);
        }

        public static IDisposable CreateCrossProcessLock(string uniqueString)
        {
            return new ProcessLock(-1, uniqueString);
        }

        public static IDisposable CreateCrossProcessLock(int delayMs, string uniqueString)
        {
            return new ProcessLock(delayMs, uniqueString);
        }

        #endregion Methods
    }

    public class CrossProcessLockFactoryMutexException : Exception
    {
        #region Constructors

        public CrossProcessLockFactoryMutexException()
        {
        }

        public CrossProcessLockFactoryMutexException(string message)
            : base(message)
        {
        }

        public CrossProcessLockFactoryMutexException(string message, Exception inner)
            : base(message, inner)
        {
        }

        #endregion Constructors
    }

    public class ProcessLock : IDisposable
    {
        #region Constructors

        public ProcessLock(int delayMs, string uniqueString = "default")
        {
            try
            {
                uniqueString = "FAA9569-7DFE-4D6D-874D-19123FB16CBC-8739827-[" + uniqueString + "]";
                _globalMutex = new Mutex(true, uniqueString, out _owned);
                if (_owned == false)
                {
                    // did not get the mutex, wait for it.
                    _owned = _globalMutex.WaitOne(delayMs);

                    if (_owned == false) throw new CrossProcessLockFactoryMutexException("Did not get the mutex after the specific wait time.");
                }
            }
            catch (Exception ex)
            {
                if (ex is AbandonedMutexException)
                {
                    // is thrown if another process is terminated, the process who receives this now owns the mutex.
                }
                else
                {
                    Trace.TraceError(ex.Message);
                    throw;
                }
            }
        }

        #endregion Constructors

        #region Properties

        public bool IsOwner => _owned;

        #endregion Properties

        #region Methods

        public void Dispose()
        {
            if (_owned)
                _globalMutex.ReleaseMutex();
            _globalMutex = null;
        }

        #endregion Methods

        // the name of the global mutex;
        //private const string MutexName = "FAA9569-7DFE-4D6D-874D-19123FB16CBC-8739827-[SystemSpecicString]";

        #region Fields

        private readonly bool _owned;
        private Mutex _globalMutex;

        #endregion Fields
    }
}