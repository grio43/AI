﻿extern alias SC;

using EVESharpCore.Logging;
using EVESharpCore.Questor.States;
using System;
using EVESharpCore.States;

namespace EVESharpCore.Questor.Behaviors
{
    public class GatherItemsBehavior
    {
        #region Constructors

        public GatherItemsBehavior()
        {
            _lastPulse = DateTime.MinValue;
            ResetStatesToDefaults();
        }

        #endregion Constructors

        #region Fields

        private static DateTime _lastPulse;
        private static DateTime _lastSalvageTrip = DateTime.MinValue;

        #endregion Fields

        #region Methods

        public static bool ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState _CMBStateToSet, bool wait = false, string LogMessage = null)
        {
            try
            {
                if (State.CurrentCombatMissionBehaviorState != _CMBStateToSet)
                {
                    if (_CMBStateToSet == CombatMissionsBehaviorState.GotoBase)
                        State.CurrentTravelerState = TravelerState.Idle;

                    Log.WriteLine("New CombatMissionsBehaviorState [" + _CMBStateToSet + "]");
                    State.CurrentCombatMissionBehaviorState = _CMBStateToSet;
                    if (!wait) ProcessState();
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }

            return true;
        }

        public static void ProcessState()
        {
            try
            {
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        private static bool ResetStatesToDefaults()
        {
            Log.WriteLine("CombatMissionsBehavior.ResetStatesToDefaults: start");
            State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Idle;
            State.CurrentAgentInteractionState = AgentInteractionState.Idle;
            State.CurrentArmState = ArmState.Idle;
            State.CurrentUnloadLootState = UnloadLootState.Idle;
            State.CurrentTravelerState = TravelerState.AtDestination;
            Log.WriteLine("CombatMissionsBehavior.ResetStatesToDefaults: done");
            return true;
        }

        #endregion Methods
    }
}