﻿/*
 * Created by huehue.
 * User: duketwo
 * Date: 01.05.2017
 * Time: 18:31
 *
 */

extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Controllers.Base;
using EVESharpCore.Framework;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.Stats;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Controllers
{
    public class LoginRewardsController : BaseController
    {
        #region Constructors

        public LoginRewardsController()
        {
            IgnorePause = false;
            IgnoreModal = true;
        }

        #endregion Constructors

        #region Fields

        private DateTime NextLoginRewardsControllerTimeStamp = DateTime.UtcNow;
        #endregion Fields

        #region Methods


        public void CheckOmegaClone()
        {
            if (ESCache.Instance.InStation && ESCache.Instance.EveAccount.RequireOmegaClone)
            {
                if (!ESCache.Instance.DirectEve.Me.IsOmegaClone.HasValue || (bool) ESCache.Instance.DirectEve.Me.IsOmegaClone)
                {

                }

                Log("RequireOmegaClone is true and IsOmegaClone is false! Pausing!");
                ControllerManager.Instance.SetPause(true);
            }

            if (ESCache.Instance.InStation && ESCache.Instance.DirectEve.Me.IsOmegaClone.HasValue && (bool)ESCache.Instance.DirectEve.Me.IsOmegaClone)
            {
                string TextToLog = "SubEnd: NotInitialized: SubTimeEnd [" + ESCache.Instance.DirectEve.Me.SubTimeEnd + "]";
                //
                // if saved value is in the past
                //
                if (ESCache.Instance.EveAccount.SubEnd > DateTime.UtcNow)
                    TextToLog = ESCache.Instance.EveAccount.SubEnd.ToString();
                else if (ESCache.Instance.DirectEve.Me.SubTimeEnd != ESCache.Instance.EveAccount.SubEnd)
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.SubEnd), ESCache.Instance.DirectEve.Me.SubTimeEnd);


                if (DateTime.UtcNow.AddDays(2) > ESCache.Instance.DirectEve.Me.SubTimeEnd)
                {
                    //
                    // if we havent checked in the last hour or so
                    //
                    if (DateTime.UtcNow > Time.Instance.LastSubscriptionTimeLeftCheckAttempt.AddMinutes(ESCache.Instance.RandomNumber(60, 120)))
                    {
                        if (ESCache.Instance.DirectEve.Me.SubTimeEnd != DateTime.MinValue)
                        {
                            Time.Instance.LastSubscriptionTimeLeftCheckAttempt = DateTime.UtcNow;
                            TextToLog = ESCache.Instance.DirectEve.Me.SubTimeEnd.ToString();
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.SubEnd), ESCache.Instance.DirectEve.Me.SubTimeEnd);
                        }
                    }
                }

                if (DebugConfig.DebugSubscriptionEnd) Log("SubEnd: " + TextToLog);
            }
        }

        public void CheckWindows()
        {
            if (DateTime.UtcNow < NextLoginRewardsControllerTimeStamp)
                return;

            //if (ESCache.Instance.DirectEve.Login.AtLogin || ESCache.Instance.DirectEve.Login.AtCharacterSelection)
            //    return;


            NextLoginRewardsControllerTimeStamp = DateTime.UtcNow.AddSeconds(3);

            if (Time.Instance.LastJumpAction.AddSeconds(5) > DateTime.UtcNow)
            {
                //if (DebugConfig.DebugCleanup) Log.WriteLine("if (DateTime.UtcNow > Time.Instance.LastJumpAction.AddSeconds(5))");
                return;
            }

            if (Time.Instance.LastUndockAction.AddSeconds(5) > DateTime.UtcNow)
            {
                //if (DebugConfig.DebugCleanup) Log.WriteLine("if (DateTime.UtcNow > Time.Instance.LastUndockAction.AddSeconds(5))");
                return;
            }

            if (Time.Instance.LastDockAction.AddSeconds(5) > DateTime.UtcNow)
            {
                //if (DebugConfig.DebugCleanup) Log.WriteLine("if (DateTime.UtcNow > Time.Instance.LastDockAction.AddSeconds(5))");
                return;
            }

            if (ESCache.Instance.InSpace) return;
            if (!ESCache.Instance.InStation) return;

            //Log("Checkmodal windows called.");
            if (ESCache.Instance.Windows == null || !ESCache.Instance.Windows.Any())
            {
                if (DebugConfig.DebugCleanup) Log("CheckModalWindows: Cache.Instance.Windows returned null or empty");
                return;
            }

            if (ESCache.Instance.EveAccount.ManuallyPausedViaUI) return;

            //if ()


            if (DebugConfig.DebugCleanup) Log("Checking Each window in Cache.Instance.Windows");
        }

        public bool OpenLoginRewardWindow(string module)
        {
            if (DateTime.UtcNow < Time.Instance.NextOpenHangarAction)
                return false;

            if (!ESCache.Instance.InStation)
            {
                Log("Closing loginRewardWindow: We are not in station?!");
                return false;
            }

            if (ESCache.Instance.InStation)
            {
                var loginRewardWindow = ESCache.Instance.Windows.OfType<DirectLoginRewardWindow>().FirstOrDefault();
                if (loginRewardWindow != null)
                {
                    Log("Opening Login Reward Window");
                    ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenLoginCampaignWindow);
                    return false;
                }

                return true;
            }

            return true;
        }

        public override void DoWork()
        {
            try
            {
                if (DebugConfig.DebugDisableCleanup)
                    return;

                CheckWindows();
                //CheckOmegaClone();
            }
            catch (Exception ex)
            {
                Log("Exception [" + ex + "]");
            }
        }

        public override bool EvaluateDependencies(ControllerManager cm)
        {
            return true;
        }

        #endregion Methods
    }
}