﻿extern alias SC;

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Xml.XPath;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Actions;
using EVESharpCore.Questor.Activities;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.States;
using EVESharpCore.Questor.Storylines;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.IPC;
using Group = EVESharpCore.Framework.Group;

namespace EVESharpCore.Cache
{
    public static class MissionSettings
    {
        #region Constructors

        static MissionSettings()
        {
            StorylineInstance = new Storyline();
            ChangeMissionShipFittings = false;
            DefaultFittingName = null;
            FactionBlacklist = new List<string>();
            ListOfAgents = new List<AgentsList>();
            ListofFactionFittings = new List<FactionFitting>();
            _listOfMissionFittings = new List<MissionFitting>();
            MissionBlacklist = new List<string>();
            MissionObjectivePhraseBlacklist = new List<string>();
            MissionGreylist = new List<string>();
            MissionItems = new List<string>();
            MissionUseDrones = null;
            _currentBestDamageTypes = new List<DamageType>();
            UseMissionShip = false;
        }

        #endregion Constructors

        #region Fields

        public static List<long> AgentBlacklist;
        //public static bool AttemptingToWarp;
        public static long IskReward = 0;
        public static string LastReasonMissionAttemptedToBeDeclined = string.Empty;
        public static HashSet<long> MissionBoosterTypes = new HashSet<long>();
        public static bool? MissionDronesKillHighValueTargets;
        public static double? MissionOptimalRange;
        public static double? MissionOrbitDistance;
        public static int MissionsThisSession = 0;
        public static Storyline StorylineInstance;
        public static XDocument UnloadLootTheseItemsAreLootItems;
        public static bool WaitDecline = false;
        private static readonly List<MissionFitting> _listOfMissionFittings;

        private static DirectAgent _agent { get; set; }

        private static string _agentName = string.Empty;

        //private static DamageType? _currentBestDamageType;
        private static List<DamageType> _currentBestDamageTypes;
        private static FactionFitting _defaultFitting;
        private static string _defaultFittingName;
        private static string _factionFittingNameForThisMissionsFaction;
        private static string _fittingToLoad;
        private static List<FactionFitting> _listofFactionFittings;
        private static IEnumerable<DirectAgentMission> _missionsInJournalFromNotBlacklistedAgents;
        private static string _missionXmlPath;
        private static List<DirectItem> _modulesInAllInGameFittings;
        private static DateTime _nextSecondBestDamageTypeSwap = DateTime.MinValue;
        private static DateTime _nextThirdBestDamageTypeSwap = DateTime.MinValue;
        private static List<DirectAgentMission> _storylineMissionsInJournal;
        private static IEnumerable<DirectAgentMission> _storylineMissionsInJournalThatQuestorKnowsHowToDo;
        private static IEnumerable<DirectAgentMission> _storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted;
        private static XDocument missionXml;

        #endregion Fields

        #region Properties

        private static DamageType? _previousDamageType;

        private static DateTime LastStoryLineMissionLogging = DateTime.UtcNow.AddHours(-1);

        private static DirectAgentMission regularMission;

        private static bool StorylineMissionsLogged;

        public static DirectAgentMission _storylineMission { get; private set; }

        public static DirectAgent AgentToPullNextRegularMissionFrom
        {
            get
            {
                try
                {
                    if (Settings.CharacterXMLExists)
                        try
                        {
                            if (ESCache.Instance.EveAccount.SelectedController.Contains("Abyssal"))
                            {
                                //Log.WriteLine("AgentToPullNextRegularMissionFrom: if (ESCache.Instance.EveAccount.SelectedController.Contains(Abyssal))");
                                return null;
                            }

                            if (!SelectedControllerUsesCombatMissionsBehavior && ESCache.Instance.DirectEve.AgentMissions.Any())
                            {
                                Log.WriteLine("AgentToPullNextRegularMissionFrom: if (!SelectedControllerUsesCombatMissionsBehavior && ESCache.Instance.DirectEve.AgentMissions.Any())");
                                return null;
                            }

                            try
                            {
                                //
                                // use storyline agent if we have a mission waiting
                                //
                                //if (ESCache.Instance.InStation)
                                    //if (StorylineMission != null && StorylineMission.Agent != null)
                                    //{
                                    //    _agent = StorylineMission.Agent;
                                    //    return _agent;
                                    //}
                            }
                            catch (Exception ex)
                            {
                                Log.WriteLine("Unable to process agent section of [" + Settings.CharacterSettingsPath +
                                              "] make sure you have a valid agent listed! Pausing so you can fix it");
                                Log.WriteLine("Exception [" + ex + "]");
                                ControllerManager.Instance.SetPause(true);
                            }

                            if (_agent == null)
                            {
                                Log.WriteLine("if (_agent == null)");
                                //
                                // use strCurrentAgentName to find the agent
                                //
                                if (!strCurrentAgentName.Equals(_agentName))
                                {
                                    _agent = ESCache.Instance.DirectEve.GetAgentByName(strCurrentAgentName);
                                    if (_agent == null)
                                        Log.WriteLine("Agent == null, strCurrentAgentName was set to [ " + strCurrentAgentName + " ] couldnt find this agent");

                                    if (ESCache.Instance.EveAccount.SelectedController.Contains("CareerAgentController"))
                                        PickAgentToUseNext();
                                }

                                //
                                // use _agentName to find the agent
                                //
                                if (_agent == null && strCurrentAgentName.Equals(_agentName))
                                    _agent = ESCache.Instance.DirectEve.GetAgentByName(_agentName);
                            }

                            if (_agent != null && !strCurrentAgentName.Equals(_agentName))
                            {
                                Log.WriteLine("New AgentToPullNextRegularMissionFrom [" + _agent.Name + "]");
                                _agentName = strCurrentAgentName;
                            }

                            //todo, fixme
                            if (_agent == null)
                            {
                                //...
                            }

                            return _agent;
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Unable to process agent section of [" + Settings.CharacterSettingsPath +
                                          "] make sure you have a valid agent listed! Pausing so you can fix it.");
                            Log.WriteLine("Exception [" + ex + "]");
                            ControllerManager.Instance.SetPause(true);
                        }
                    else
                        Log.WriteLine("if (!Settings.Instance.CharacterXMLExists)");
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
            set => _agent = value;
        }

        public static bool AllowNonStorylineCourierMissionsInLowSec { get; set; }

        public static bool AllowRemovingNoCompatibleStorylines { get; set; }

        public static bool ChangeMissionShipFittings { get; set; }

        private static bool AllowDamageTypeChanges
        {
            get
            {
                if (ESCache.Instance.InMission || ESCache.Instance.InWormHoleSpace)
                {
                    if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.Any(i => i.GroupId == (int) Group.RapidHeavyMissileLaunchers) ||
                        ESCache.Instance.Weapons.Any(i => i.GroupId == (int) Group.RapidLightMissileLaunchers))
                    {
                        //
                        // long reload times. wait to reload until the launchers are low on ammo already
                        // this probably works best with launchers in stack(s)
                        //
                        if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.All(i => i.ChargeQty > 7 && !i.IsReloadingAmmo))
                            return false;
                    }

                    return true;
                }

                return false;
            }
        }

        private static bool isBigEnoughTargetWeShouldSwapNow
        {
            get
            {
                if (Combat._pickPrimaryWeaponTarget != null && (Combat._pickPrimaryWeaponTarget.IsBattleship || Combat._pickPrimaryWeaponTarget.IsNPCBattleship))
                {
                    if (ESCache.Instance.Weapons.Any())
                    {
                        if (ESCache.Instance.Weapons.All(i => i.GroupId != (int)Group.RapidHeavyMissileLaunchers && i.GroupId != (int)Group.RapidLightMissileLaunchers))
                            return false;
                    }
                    return true;
                }

                return false;
            }
        }

        private static DamageType? _currentDamageType;

        public static DamageType? CurrentDamageType
        {
            get
            {
                try
                {
                    if (ESCache.Instance.InWormHoleSpace)
                        return DamageType.EM;

                    if (DirectEve.HasFrameChanged(nameof(CurrentDamageType)) || !_currentDamageType.HasValue)
                    {
                        _currentBestDamageTypes = GetBestDamageTypes;
                        var bestDamageType = _currentBestDamageTypes.FirstOrDefault();

                        if (bestDamageType != _previousDamageType)
                        {
                            if (AllowDamageTypeChanges && _previousDamageType.HasValue && _currentBestDamageTypes.Any())
                            {
                                // get the index of the previous damage type to choose when to swap the damage type
                                int indexPreviousDamageType = _currentBestDamageTypes.IndexOf(_previousDamageType.Value);
                                switch (indexPreviousDamageType)
                                {
                                    case 0: // don't swap
                                        if (DebugConfig.DebugCurrentDamageType) Log.WriteLine($"Index 0. (this case shouldn't happen at all)");
                                        break;

                                    case 1: // swap every 2 minutes?
                                        if (DebugConfig.DebugCurrentDamageType) Log.WriteLine($"Index 1. (2nd best)");
                                        if (_nextSecondBestDamageTypeSwap < DateTime.UtcNow)
                                        {
                                            //if (DebugConfig.DebugCurrentDamageType)
                                            if (ESCache.Instance.Weapons.Any(i => i.GroupId == (int) Group.RapidHeavyMissileLaunchers || i.GroupId == (int) Group.RapidLightMissileLaunchers))
                                            {
                                                _nextSecondBestDamageTypeSwap = DateTime.UtcNow.AddSeconds(360);
                                                Log.WriteLine("[bestDamageType][1] [" + bestDamageType + "] next 2nd best swap will in 6 minutes.");
                                            }
                                            else
                                            {
                                                _nextSecondBestDamageTypeSwap = DateTime.UtcNow.AddSeconds(120);
                                                Log.WriteLine("[bestDamageType][1] [" + bestDamageType + "] next 2nd best swap will in 2 minutes.");
                                            }
                                        }
                                        else
                                        {
                                            bestDamageType = _previousDamageType.Value;
                                            if (DebugConfig.DebugCurrentDamageType) Log.WriteLine($"Keeping previous damage type {bestDamageType}");
                                        }

                                        break;

                                    case 2: // swap every 1 minute?
                                        if (DebugConfig.DebugCurrentDamageType) Log.WriteLine($"Index 2. (3rd best)");
                                        if (_nextThirdBestDamageTypeSwap < DateTime.UtcNow || isBigEnoughTargetWeShouldSwapNow)
                                        {
                                            Log.WriteLine("[bestDamageType][2] [" + bestDamageType + "] next 3rd best swap: 60 seconds");
                                            _nextThirdBestDamageTypeSwap = DateTime.UtcNow.AddSeconds(60);
                                        }
                                        else
                                        {
                                            bestDamageType = _previousDamageType.Value;
                                            if (DebugConfig.DebugCurrentDamageType) Log.WriteLine($"Keeping previous damage type {bestDamageType}");
                                        }

                                        break;

                                    case 3: // swap now
                                        if (DebugConfig.DebugCurrentDamageType) Log.WriteLine($"Index 3. (4th best)");
                                        break;
                                }
                            }

                            _previousDamageType = bestDamageType;
                        }

                        if (ESCache.Instance.InSpace && !AnyAmmoOfTypeLeft(bestDamageType)) // pick the next best ammo if there is nothing left of the best ammo
                            if (_currentBestDamageTypes.Any())
                                for (var j = 0; j < _currentBestDamageTypes.Count; j++)
                                {
                                    var ammo = DirectModule.DefinedAmmoTypes.FirstOrDefault(a => a.DamageType == _currentBestDamageTypes[j]);
                                    if (ammo != null)
                                        if (AnyAmmoOfTypeLeft(ammo.DamageType))
                                        {
                                            bestDamageType = ammo.DamageType;
                                            _previousDamageType = bestDamageType;
                                            //Log.WriteLine($"We have enough ammo of type [{bestDamageType}] left in cargo / launchers.");
                                            break;
                                        }
                                        else
                                        {
                                            if (DebugConfig.DebugCurrentDamageType) Log.WriteLine(
                                                $"We DON'T have more ammo of type {ammo.DamageType} left in our cargo / launchers. Picking next best ammo.");
                                            continue;
                                        }
                                }

                        _currentDamageType = bestDamageType;
                    }

                    return _currentDamageType;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return DamageType.EM;
                }
            }
        }

        public static string CurrentFit
        {
            get => ESCache.Instance.EveAccount.CurrentFit;
            set => WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CurrentFit), value);
        }

        public static bool DeclineMissionsWithTooManyMissionCompletionErrors { get; set; }

        public static DamageType DefaultDamageType { get; set; } = DamageType.Kinetic;

        //public bool? DisableBlitz { get; set; }
        public static string DefaultFittingName
        {
            get
            {
                if (ListofFactionFittings != null && ListofFactionFittings.Any())
                {
                    _defaultFitting = ListofFactionFittings.Find(m => m.FactionName.ToLower() == "default");
                    _defaultFittingName = _defaultFitting.FittingName;
                    return _defaultFittingName;
                }

                Log.WriteLine("DefaultFittingName - no fitting found for the faction named [ default ], assuming a fitting name of [ default ] exists");
                return "default";
            }

            set => _defaultFittingName = value;
        }

        //public bool? DelayBlitzIfBattleshipOnGrid { get; set; }
        //public bool? DelayBlitzIfLargeWreckOnGrid { get; set; }
        public static List<string> DistributionAgentsAllowedCorporations { get; }

        //public FactionFitting DefaultFitting => FactionFittings.FirstOrDefault(f => f.FactionType == FactionType.Unknown);
        public static int? FactionActivateRepairModulesAtThisPerc { get; set; }

        public static List<string> FactionBlacklist { get; }

        public static int? FactionDroneTypeID { get; set; }

        //public string FittingToLoad => MissionFittingCurrentMission?.FittingName?.ToLower()
        //                               ?? FactionFittingCurrentMission?.FittingName?.ToLower()
        //                               ?? DefaultFitting.FittingName.ToLower();
        public static string MissionSpecificShipName { get; set; }
        public static string FactionSpecificShip { get; set; }

        //public List<FactionFitting> FactionFittings => ESCache.Instance.EveAccount.CS.QMS.QS.Factionfittings.ToList();
        public static DirectAgentMission FirstAgentMission { get; set; }

        //public List<QuestorFaction> FactionBlacklist => ESCache.Instance.EveAccount.CS.QMS.QS.Factionblacklist.ToList();
        //public FactionFitting FactionFittingCurrentMission =>
        //    FactionFittings.FirstOrDefault(f => f.FactionType == CurrentMissionFaction);

        private static List<DamageType> _defaultDamgeTypes;

        private static List<DamageType> DefaultDamageTypes
        {
            get
            {
                if (_defaultDamgeTypes == null)
                {
                    _defaultDamgeTypes = new List<DamageType>();
                    _defaultDamgeTypes.Add(DefaultDamageType);
                }

                return _defaultDamgeTypes;
            }
        }

        //
        // todo: go through each entity on grid and get BestDamageTypes + HP info so we can determine best damagetype for the grid
        //
        /**
        public static double? test_damageTypesOfResistedHpForGrid
        {
            get
            {
                double resistedHpEmForGrid = 0;
                double resistedHpExplosiveForGrid = 0;
                double resistedHpKineticForGrid = 0;
                double resistedHpThermalForGrid = 0;
                foreach (EntityCache potentialCombatTarget in Combat.PotentialCombatTargets.Where(i => i.IsOnGridWithMe))
                {
                    resistedHpEmForGrid = resistedHpEmForGrid + potentialCombatTarget.EffectiveHitpointsViaEM;
                    resistedHpExplosiveForGrid = resistedHpExplosiveForGrid + potentialCombatTarget.EffectiveHitpointsViaExplosive;
                    resistedHpKineticForGrid = resistedHpKineticForGrid + potentialCombatTarget.EffectiveHitpointsViaKinetic;
                    resistedHpThermalForGrid = resistedHpThermalForGrid + potentialCombatTarget.EffectiveHitpointsViaThermal;
                }

                List<double?> damageTypesOfResistedHpForGrid = new List<double?>()
                {
                    resistedHpEmForGrid,
                    resistedHpExplosiveForGrid,
                    resistedHpKineticForGrid,
                    resistedHpThermalForGrid
                };

                //switch (damageTypesOfResistedHpForGrid.Where(i => i.HasValue).OrderBy(i => i.Value).FirstOrDefault())
                //{
                    //case resistedHpEmForGrid:
                    //case resistedHpExplosiveForGrid:
                    //case resistedHpKineticForGrid:
                    //case resistedHpThermalForGrid:
                //        break;
                //}

                //if ( )

                return 0; //fixme
            }
        }
        **/

        public static List<DamageType> CalcBestDamageTypeForBattleshipTargets
        {
            get
            {
                var bestDamageTypes = Combat.PotentialCombatTargets.Where(i => i.IsTarget && !i.IsNPCFrigate && !i.IsNPCCruiser).FirstOrDefault(e => e.IsCurrentTarget)?.BestDamageTypes
                                      ?? Combat.PotentialCombatTargets.Where(i => i.IsTarget && !i.IsNPCFrigate && !i.IsNPCCruiser).OrderByDescending(i => i.IsBattleship || i.IsNPCBattleship).FirstOrDefault(e =>
                                                                                      e.BracketType == BracketType.NPC_Battlecruiser
                                                                                      || e.BracketType == BracketType.NPC_Battleship)?.BestDamageTypes
                                      ?? Combat.PotentialCombatTargets.OrderByDescending(i => i.IsBattleship || i.IsNPCBattleship).FirstOrDefault(e =>
                                                                                             e.BracketType == BracketType.NPC_Battlecruiser
                                                                                             || e.BracketType == BracketType.NPC_Battleship)?.BestDamageTypes
                                      ?? BestDamageTypesForCurrentMission ?? DefaultDamageTypes;
                return bestDamageTypes;
            }
        }

        public static List<DamageType> CalcBestDamageTypeForCruiserTargets
        {
            get
            {
                var bestDamageTypes = Combat.PotentialCombatTargets.Where(i => i.IsTarget).FirstOrDefault(e => e.IsCurrentTarget)?.BestDamageTypes
                                      ?? Combat.PotentialCombatTargets.Where(i => i.IsTarget).FirstOrDefault()?.BestDamageTypes
                                      ?? Combat.PotentialCombatTargets.FirstOrDefault()?.BestDamageTypes
                                      ?? BestDamageTypesForCurrentMission ?? DefaultDamageTypes;
                return bestDamageTypes;
            }
        }

        public static List<DamageType> CalcBestDamageTypeForFrigateTargets
        {
            get
            {
                var bestDamageTypes = Combat.PotentialCombatTargets.Where(i => i.IsTarget).FirstOrDefault(e => e.IsCurrentTarget)?.BestDamageTypes
                                      ?? Combat.PotentialCombatTargets.Where(i => i.IsTarget).FirstOrDefault()?.BestDamageTypes
                                      ?? Combat.PotentialCombatTargets.FirstOrDefault()?.BestDamageTypes
                                      ?? BestDamageTypesForCurrentMission ?? DefaultDamageTypes;
                return bestDamageTypes;
            }
        }

        public static List<DamageType> GetBestDamageTypes
        {
            get
            {
                if (ESCache.Instance.InStation)
                    return DefaultDamageTypes;

                if (!ESCache.Instance.InSpace)
                    return DefaultDamageTypes;

                if (ESCache.Instance.MyShipEntity == null)
                    return DefaultDamageTypes;

                if (ESCache.Instance.MyShipEntity.IsBattleship)
                    return CalcBestDamageTypeForBattleshipTargets ?? DefaultDamageTypes;

                if (ESCache.Instance.MyShipEntity.IsBattlecruiser)
                    return CalcBestDamageTypeForBattleshipTargets ?? DefaultDamageTypes;

                if (ESCache.Instance.MyShipEntity.IsCruiser)
                    return CalcBestDamageTypeForCruiserTargets ?? DefaultDamageTypes;

                if (ESCache.Instance.MyShipEntity.IsFrigate)
                    return CalcBestDamageTypeForFrigateTargets ?? DefaultDamageTypes;

                //if (ESCache.Instance.MyShipEntity.isDreadnaught)
                //    return CalcBestDamageTypeForDreadnaughtTargets ?? DefaultDamageTypes;

                return DefaultDamageTypes;
            }
        }

        public static DirectAgentMission _myMission;

        public static DirectAgentMission MyMission
        {
            get
            {
                if (_myMission == null)
                {
                    if (RegularMission != null)
                        _myMission = RegularMission;
                    if (StorylineMission != null && State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.Storyline)
                        _myMission = StorylineMission;

                    return _myMission;
                }

                return _myMission;
            }
        }

        public static List<DamageType> BestDamageTypesForCurrentMission
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace || ESCache.Instance.InWormHoleSpace)
                    return new List<DamageType>();

                if (ESCache.Instance.ActiveShip != null && Combat.CombatShipName == ESCache.Instance.ActiveShip.GivenName)
                {
                    if (MyMission != null && MyMission.State == MissionState.Accepted)
                    {
                        if (MyMission.Type.Contains("Courier") || MyMission.Type.Contains("Trade"))
                            return null;

                        return MyMission.BestDamagesTypesToShoot;
                    }
                }

                return null;
            }
        }

        public static bool IsMissionFinished
        {
            get
            {
                //if (AttemptingToWarp && Combat.PotentialCombatTargets.All(i => !i.IsWarpScramblingMe))
                //    return true;

                if (SelectedControllerUsesCombatMissionsBehavior && MyMission != null && MyMission.Agent != null)
                {
                    if (MyMission.Agent.IsValid)
                    {
                        if (MyMission.IsMissionFinished != null && (bool)MyMission.IsMissionFinished)
                        {
                            if (Salvage.LootEverything)
                                return false;

                            if (ESCache.Instance.MyShipIsHealthy && Combat.PotentialCombatTargets.Any(i => i.IsWarpScramblingMe || i.IsAttacking && i.IsInOptimalRange && i.IsNPCBattleship && i.WarpScrambleChance == 0))
                            {
                                if (MyMission != null && MyMission.Agent.Level == 4)
                                {
                                    switch (MyMission.Name)
                                    {
                                        case "Recon (1 of 3)":
                                        case "Recon (2 of 3)":
                                        case "Recon (3 of 3)":
                                        case "Cargo Delivery":
                                        case "Smash the Supplier":
                                            return true;
                                    }

                                    return false;
                                }

                                return false;
                            }

                            return true;
                        }

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        //public List<QuestorMission> MissionGreylist => ESCache.Instance.EveAccount.CS.QMS.QS.Greylist.Where(m => m.Name != null).ToList();
        public static List<AgentsList> ListOfAgents { get; set; }

        //public List<MissionFitting> MissionFittings => ESCache.Instance.EveAccount.CS.QMS.QS.Missionfittings.ToList();
        public static List<FactionFitting> ListofFactionFittings
        {
            get
            {
                try
                {
                    if (Settings.Instance.UseFittingManager)
                    {
                        if (_listofFactionFittings != null && _listofFactionFittings.Any())
                            return _listofFactionFittings;

                        _listofFactionFittings = new List<FactionFitting>();

                        XElement factionFittings = Settings.CharacterSettingsXml.Element("factionFittings") ??
                                                   Settings.CharacterSettingsXml.Element("factionfittings") ??
                                                   Settings.CommonSettingsXml.Element("factionFittings") ??
                                                   Settings.CommonSettingsXml.Element("factionfittings");

                        if (factionFittings != null)
                        {
                            string factionFittingXmlElementName = "";
                            if (factionFittings.Elements("factionFitting").Any())
                                factionFittingXmlElementName = "factionFitting";
                            else
                                factionFittingXmlElementName = "factionfitting";

                            int i = 0;
                            foreach (XElement factionfitting in factionFittings.Elements(factionFittingXmlElementName))
                            {
                                i++;
                                _listofFactionFittings.Add(new FactionFitting(factionfitting));
                                if (DebugConfig.DebugFittingMgr)
                                    Log.WriteLine("[" + i + "] Faction Fitting [" + factionfitting + "]");
                            }

                            return _listofFactionFittings;
                        }

                        if (Settings.Instance.UseFittingManager)
                        {
                            Log.WriteLine("No faction fittings specified. UseFittingManager is now false");
                            Settings.Instance.UseFittingManager = false;
                        }

                        return new List<FactionFitting>();
                    }

                    return new List<FactionFitting>();
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Faction Fittings Settings [" + exception + "]");
                    return new List<FactionFitting>();
                }
            }

            private set => _listofFactionFittings = value;
        }

        //public MissionFitting MissionFittingCurrentMission => MissionFittings.FirstOrDefault(f => f.RegularMission.ToLower().Equals(MissionName.ToLower()));
        public static List<MissionFitting> ListOfMissionFittings
        {
            get
            {
                try
                {
                    if (_listOfMissionFittings != null && _listOfMissionFittings.Any()) return _listOfMissionFittings;

                    XElement xmlElementMissionFittingsSection = Settings.CharacterSettingsXml.Element("missionfittings") ??
                                                                Settings.CommonSettingsXml.Element("missionfittings");
                    if (Settings.Instance.UseFittingManager)
                    {
                        if (xmlElementMissionFittingsSection != null)
                        {
                            if (xmlElementMissionFittingsSection.Elements("missionfitting").Any())
                                Log.WriteLine("Loading Mission Fittings");

                            int i = 0;
                            foreach (XElement missionfitting in xmlElementMissionFittingsSection.Elements("missionfitting"))
                            {
                                i++;
                                try
                                {
                                    Log.WriteLine("[" + i + "] Mission Fitting [" + missionfitting + "]");
                                    _listOfMissionFittings.Add(new MissionFitting(missionfitting));
                                }
                                catch (Exception ex)
                                {
                                    Log.WriteLine("Exception [" + ex + "]");
                                }
                            }

                            if (DebugConfig.DebugFittingMgr)
                                Log.WriteLine("        Mission Fittings now has [" + _listOfMissionFittings.Count + "] entries");
                            return _listOfMissionFittings;
                        }

                        return new List<MissionFitting>();
                    }

                    return new List<MissionFitting>();
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Mission Fittings Settings [" + exception + "]");
                    return new List<MissionFitting>();
                }
            }
        }

        //public List<QuestorMission> MissionBlacklist => ESCache.Instance.EveAccount.CS.QMS.QS.Blacklist.Where(m => m.Name != null).ToList();
        public static int MaterialsForWarOreID { get; set; }

        //public int? MissionActivateRepairModulesAtThisPerc { get; set; }
        public static int MaterialsForWarOreQty { get; set; }

        //public DirectAgentMission RegularMission => ESCache.Instance.Agent.RegularMission;
        public static float MinAgentGreyListStandings { get; set; }

        //public float MinAgentGreyListStandings => ESCache.Instance.EveAccount.CS.QMS.QS.MinAgentGreyListStandings;
        public static int? MinimumArmorPctMissionSetting { get; set; }

        //public bool IsBlackListedFaction => FactionBlacklist.Any(m => m.FactionType == CurrentMissionFaction);
        public static int? MinimumCapacitorPctMissionSetting { get; set; }

        public static int? MinimumShieldPctMissionSetting { get; set; }

        public static DirectAgentMission RegularMission
        {
            get
            {
                if (ESCache.Instance.DirectEve.AgentMissions.Any())
                {
                    if (AgentToPullNextRegularMissionFrom == null)
                    {
                        if (SelectedControllerUsesCombatMissionsBehavior) Log.WriteLine("RegularMission: AgentToPullNextRegularMissionFrom is null");
                        return null;
                    }
                    //
                    // purposely do not cache this beyond the frame we are in.
                    //
                    regularMission = ESCache.Instance.DirectEve.AgentMissions.FirstOrDefault(m => m.AgentId == AgentToPullNextRegularMissionFrom.AgentId);

                    if (regularMission != null)
                    {
                        if (regularMission.State != MissionState.Accepted)
                            return regularMission;

                        return regularMission;
                    }

                    //if (StorylineMission != null)
                    //    return StorylineMission;

                    //Log.WriteLine("RegularMission: null: AgentToPullNextRegularMissionFrom [" + AgentToPullNextRegularMissionFrom.Name + "] AgentId [" + AgentToPullNextRegularMissionFrom.AgentId + "]");
                    if (ESCache.Instance.DirectEve.AgentMissions.Any())
                    {
                        int intMissionNum = 0;
                        foreach (DirectAgentMission AgentMission in ESCache.Instance.DirectEve.AgentMissions)
                        {
                            intMissionNum++;
                            //Log.WriteLine("RegularMission: AgentMission [" + intMissionNum + "][" + AgentMission.Name + "] AgentId [" + AgentMission.Agent.Name + "] State [" + AgentMission.State + "]");
                        }
                    }

                    return null;
                }

                return null;
            }
        }

        public static int? MissionActivateRepairModulesAtThisPerc { get; set; }

        public static bool MissionAllowOverLoadOfEcm { get; set; }

        public static bool MissionAllowOverLoadOfReps { get; set; }

        public static bool MissionAllowOverLoadOfSpeedMod { get; set; }

        public static bool MissionAllowOverLoadOfWeapons { get; set; }

        public static bool MissionAllowOverLoadOfWebs { get; set; }

        public static bool MissionAlwaysActivateSpeedMod { get; set; }

        public static List<string> MissionBlacklist { get; }

        public static int? MissionCapacitorInjectorScript { get; set; }

        public static int? MissionDroneTypeID { get; set; }

        public static int? MissionEcmOverloadDamageAllowed { get; set; }

        public static List<string> MissionGreylist { get; }

        public static int? MissionInjectCapPerc { get; set; }

        public static List<string> MissionItems { get; }

        public static bool? MissionKillSentries { get; set; }

        public static bool? MissionLootEverything { get; set; }

        public static string MissionNameforLogging { get; set; }

        public static int? MissionNumberOfCapBoostersToLoad { get; set; }

        public static List<string> MissionObjectivePhraseBlacklist { get; }

        public static int? MissionSafeDistanceFromStructure { get; set; }

        public static string MissionsPath { get; set; }

        public static int? MissionSpeedModOverloadDamageAllowed { get; set; }

        public static int? MissionTooCloseToStructure { get; set; }

        public static bool? MissionUseDrones { get; set; }

        public static double MissionWarpAtDistanceRange { get; set; }

        //public static int MissionWeaponGroupId { get; set; }
        public static int? MissionWeaponOverloadDamageAllowed { get; set; }

        public static int? MissionWebOverloadDamageAllowed { get; set; }

        public static bool MissionXMLIsAvailable { get; set; }

        public static List<DirectItem> ModulesInAllInGameFittings
        {
            get
            {
                try
                {
                    if (!Settings.Instance.UseFittingManager)
                    {
                        _modulesInAllInGameFittings = new List<DirectItem>();
                        return _modulesInAllInGameFittings;
                    }

                    if (ESCache.Instance.InSpace) return null;

                    if (ESCache.Instance.InStation && ESCache.Instance.FittingManagerWindow != null)
                    {
                        if (_modulesInAllInGameFittings == null)
                        {
                            _modulesInAllInGameFittings = new List<DirectItem>();
                            foreach (DirectFitting fitting in ESCache.Instance.FittingManagerWindow.Fittings)
                                foreach (DirectItem moduleInFitting in fitting.Modules)
                                    if (!_modulesInAllInGameFittings.Any() || _modulesInAllInGameFittings.Any() && _modulesInAllInGameFittings.All(i => i.TypeId != moduleInFitting.TypeId))
                                        _modulesInAllInGameFittings.Add(moduleInFitting);

                            if (!_modulesInAllInGameFittings.Any())
                                return null;

                            return _modulesInAllInGameFittings ?? null;
                        }

                        return _modulesInAllInGameFittings ?? null;
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return new List<DirectItem>();
                }
            }
        }

        public static string MoveMissionItems { get; set; }

        public static int MoveMissionItemsQuantity { get; set; }

        public static int MoveOptionalMissionItemQuantity { get; set; }

        public static string MoveOptionalMissionItems { get; set; }

        public static bool OfflineModulesFound { get; set; }

        public static bool DamagedModulesFound { get; set; } = false;

        public static int? PocketActivateRepairModulesAtThisPerc { get; set; }

        public static int? PocketDroneTypeID { get; set; }

        public static bool? PocketKillSentries { get; set; }

        public static bool? PocketUseDrones { get; set; }

        public static bool RequireMissionXML { get; set; }

        public static bool SelectedControllerUsesCombatMissionsBehavior
        {
            get
            {
                if (ESCache.Instance.EveAccount.SelectedController == "AbyssalDeadspaceController")
                    return false;

                if (ESCache.Instance.EveAccount.SelectedController == "QuestorController")
                    return true;

                if (ESCache.Instance.EveAccount.SelectedController == "CourierMissionsController")
                    return true;

                if (ESCache.Instance.EveAccount.SelectedController == "CareerAgentController")
                    return true;

                //if (ESCache.Instance.EveAccount.SelectedController == "HighSecAnomalyController")
                //    return true;

                if (ESCache.Instance.EveAccount.SelectedController == "StandingsGrindController")
                    return true;

                if (MyMission == null)
                    return false;

                return false;
            }
        }

        public static DirectAgentMission StorylineMission
        {
            get
            {
                try
                {
                    if (_storylineMission != null && !ESCache.Instance.DirectEve.AgentMissions.Any(m => m.Important && m.UniqueMissionId == _storylineMission.UniqueMissionId))
                    {
                        _storylineMission = null;
                    }

                    if (_storylineMission == null)
                    {
                        if (ESCache.Instance.DirectEve.AgentMissions.Any(m => m.Important))
                        {
                            //
                            // do we need to grab the storyline mission?
                            //
                            if (DebugConfig.DebugStorylineMissions) Log.WriteLine("StorylineMission: if (ESCache.Instance.DirectEve.AgentMissions.Any(m => m.Important))");
                            if (StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted != null && StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted.Any())
                            {
                                if (DebugConfig.DebugStorylineMissions)
                                {
                                    int MissionNum = 0;
                                    foreach (DirectAgentMission _tempStorylineMission in StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted)
                                    {
                                        MissionNum++;
                                        if (DebugConfig.DebugStorylineMissions) Log.WriteLine("StorylineMission: in Journal: [ " + MissionNum + " ][ " + _tempStorylineMission.Name + " ][ " + _tempStorylineMission.Agent.Name + " ][ " + _tempStorylineMission.Type + " ] Jumps [ " + _tempStorylineMission.Agent.SolarSystem.JumpsHighSecOnly + " ][ " + _tempStorylineMission.Agent.StationName + " ]");
                                    }
                                }

                                foreach (DirectAgentMission tempMission in StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted)
                                {
                                    if (tempMission.Type.Contains("Trade") && Settings.Instance.StorylineDoNotTryToDoTradeMissions)
                                        continue;

                                    if (tempMission.Type.Contains("Mining") && Settings.Instance.StorylineDoNotTryToDoMiningMissions)
                                        continue;

                                    if (tempMission.Type.Contains("Courier") && Settings.Instance.StorylineDoNotTryToDoCourierMissions)
                                        continue;

                                    if (tempMission.Type.Contains("Encounter") && Settings.Instance.StorylineDoNotTryToDoEncounterMissions)
                                        continue;

                                    _storylineMission = tempMission;
                                    if (DebugConfig.DebugStorylineMissions) Log.WriteLine("StorylineMission: Closest Mission [ " + _storylineMission.Name + " ][ " + _storylineMission.Agent.Name + " ][ " + _storylineMission.Type + " ] Jumps [ " + _storylineMission.Agent.SolarSystem.JumpsHighSecOnly + " ][ " + _storylineMission.Agent.StationName + " ]");
                                    return _storylineMission;
                                }

                                if (DebugConfig.DebugStorylineMissions) Log.WriteLine("StorylineMission: if (!StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted.Any()).");
                                return null;
                            }

                            if (DebugConfig.DebugStorylineMissions) Log.WriteLine("StorylineMission: if (!StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted.Any())");
                            return null;
                        }

                        //if (DebugConfig.DebugStorylineMissions) Log.WriteLine("StorylineMission: if (!ESCache.Instance.DirectEve.AgentMissions.Any(m => m.Important))");
                        return null;
                    }

                    return _storylineMission;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public static IEnumerable<DirectAgentMission> StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted
        {
            get
            {
                try
                {
                    if (_storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted == null)
                        try
                        {
                            if (StorylineMissionsInJournalThatQuestorKnowsHowToDo != null && StorylineMissionsInJournalThatQuestorKnowsHowToDo.Any())
                            {
                                _storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted = StorylineMissionsInJournalThatQuestorKnowsHowToDo.Where(i => MissionBlacklist.All(j => i.Name != null && Log.FilterPath(i.Name).ToLower() != j.ToLower())).OrderBy(i => i.Agent.SolarSystem.JumpsHighSecOnly).ToList() ?? new List<DirectAgentMission>();
                                if (_storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted != null && _storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted.Any())
                                    return _storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted;

                                if (DebugConfig.DebugStorylineMissions)
                                    Log.WriteLine("if (_storylineMissionsInJournalThatQuestorKnowsHowToDo == null || !_storylineMissionsInJournalThatQuestorKnowsHowToDo.Any())");

                                return null;
                            }

                            if (DebugConfig.DebugStorylineMissions) Log.WriteLine("!if (StorylineMissionsInJournalThatQuestorKnowsHowToDo != null && StorylineMissionsInJournalThatQuestorKnowsHowToDo.Any())");
                            return null;
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                            return new List<DirectAgentMission>();
                        }

                    return _storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public static string strCurrentAgentName
        {
            get
            {
                try
                {
                    if (Settings.CharacterXMLExists)
                    {
                        if (string.IsNullOrEmpty(_currentAgent))
                            try
                            {
                                if (ListOfAgents != null && ListOfAgents.Any())
                                {
                                    _currentAgent = ListOfAgents.FirstOrDefault().Name;
                                    Log.WriteLine("Current Agent is [" + _currentAgent + "]");
                                }
                                else
                                {
                                    Log.WriteLine("MissionSettings.ListOfAgents == null ");
                                }
                            }
                            catch (Exception ex)
                            {
                                Log.WriteLine("Exception [" + ex + "]");
                                return string.Empty;
                            }

                        return _currentAgent;
                    }

                    Log.WriteLine("Unable to find an agent. CharacterXMLExists is [" + Settings.CharacterXMLExists + "]");
                    return string.Empty;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return "";
                }
            }
            set
            {
                try
                {
                    _currentAgent = value;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }
            }
        }

        public static bool UseMissionShip { get; set; }

        //public int CurrentDroneTypeId => MissionFittingCurrentMission?.DronetypeId
        //                                 ?? FactionFittingCurrentMission?.DronetypeId
        //                                 ?? ESCache.Instance.EveAccount.CS.QMS.QS.DroneTypeId;

        //public string CurrentFittingName
        //{
        //    get => ESCache.Instance.EveAccount.CurrentFit?.ToLower();
        //    set => WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.CharName, nameof(EveAccount.CurrentFit), value.ToLower());
        //}

        //public FactionType CurrentMissionFaction { get; set; }
        private static string _currentAgent { get; set; }

        private static MissionFitting _missionSpecificMissionFitting { get; set; }

        private static FactionFitting FactionFittingForThisMissionsFaction { get; set; }

        private static IEnumerable<DirectAgentMission> MissionsInJournalFromNotBlacklistedAgents
        {
            get
            {
                try
                {
                    if (_missionsInJournalFromNotBlacklistedAgents == null)
                        try
                        {
                            _missionsInJournalFromNotBlacklistedAgents = ESCache.Instance.DirectEve.AgentMissions.Where(m => !AgentBlacklist.Contains(m.AgentId)).ToList() ?? new List<DirectAgentMission>();
                            if (_missionsInJournalFromNotBlacklistedAgents != null && _missionsInJournalFromNotBlacklistedAgents.Any())
                                return _missionsInJournalFromNotBlacklistedAgents;

                            if (DebugConfig.DebugStorylineMissions)
                                Log.WriteLine("if (_missionsInJournalFromNotBlacklistedAgents == null || !_missionsInJournalFromNotBlacklistedAgents.Any())");

                            return new List<DirectAgentMission>();
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                            return new List<DirectAgentMission>();
                        }

                    return _missionsInJournalFromNotBlacklistedAgents;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        private static bool IsThisAStorylineMissionTypeWeDo(DirectAgentMission tempMissionInJournal)
        {
            if (!tempMissionInJournal.Important) return true;

            if (tempMissionInJournal.Type.Contains("Trade") && Settings.Instance.StorylineDoNotTryToDoTradeMissions)
            {
                if (DebugConfig.DebugStorylineMissions) Log.WriteLine("Removing [" + tempMissionInJournal + "] from the list of storyline missions because it is a [ Trade ] mission");
                return false;
            }

            if (tempMissionInJournal.Type.Contains("Mining") && Settings.Instance.StorylineDoNotTryToDoMiningMissions)
            {
                if (DebugConfig.DebugStorylineMissions) Log.WriteLine("Removing [" + tempMissionInJournal + "] from the list of storyline missions because it is a [ Mining ] mission");
                return false;
            }

            if (tempMissionInJournal.Type.Contains("Courier") && Settings.Instance.StorylineDoNotTryToDoCourierMissions)
            {
                if (DebugConfig.DebugStorylineMissions) Log.WriteLine("Removing [" + tempMissionInJournal + "] from the list of storyline missions because it is a [ Courier ] mission");
                return false;
            }

            if (tempMissionInJournal.Type.Contains("Encounter") && Settings.Instance.StorylineDoNotTryToDoEncounterMissions)
            {
                if (DebugConfig.DebugStorylineMissions) Log.WriteLine("Removing [" + tempMissionInJournal + "] from the list of storyline missions because it is a [ Encounter ] mission");
                return false;
            }

            return true;
        }

        private static IEnumerable<DirectAgentMission> StorylineMissionsInJournal
        {
            get
            {
                try
                {
                    if (_storylineMissionsInJournal == null)
                        try
                        {
                            if (MissionsInJournalFromNotBlacklistedAgents != null && MissionsInJournalFromNotBlacklistedAgents.Any())
                            {
                                _storylineMissionsInJournal = MissionsInJournalFromNotBlacklistedAgents.Where(m => m.Type.ToLower().Contains("Storyline".ToLower()) && !m.Name.Contains("Cash Flow for Capsuleers")).ToList() ?? new List<DirectAgentMission>();
                                IEnumerable<DirectAgentMission> tempMissions = null;
                                tempMissions = _storylineMissionsInJournal.Where(IsThisAStorylineMissionTypeWeDo);

                                if (tempMissions.Any())
                                    return tempMissions;

                                if (DebugConfig.DebugStorylineMissions)
                                    Log.WriteLine("StorylineMissionsInJournal: if (_storylineMissionsInJournal == null || !_storylineMissionsInJournal.Any())");

                                return null;
                            }

                            if (DebugConfig.DebugStorylineMissions)
                                Log.WriteLine("StorylineMissionsInJournal: if (MissionsInJournalFromNotBlacklistedAgents == null || !MissionsInJournalFromNotBlacklistedAgents.Any())");

                            return null;
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                            return null;
                        }

                    return _storylineMissionsInJournal;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        private static IEnumerable<DirectAgentMission> StorylineMissionsInJournalThatQuestorKnowsHowToDo
        {
            get
            {
                try
                {
                    if (_storylineMissionsInJournalThatQuestorKnowsHowToDo == null)
                        try
                        {
                            if (StorylineMissionsInJournal != null)
                            {
                                if (StorylineMissionsInJournal.Any(m => StorylineInstance._storylines.ContainsKey(Log.FilterPath(m.Name.ToLower()))))
                                {
                                    _storylineMissionsInJournalThatQuestorKnowsHowToDo = StorylineMissionsInJournal.Where(m => StorylineInstance._storylines.ContainsKey(Log.FilterPath(m.Name.ToLower()))).ToList() ?? new List<DirectAgentMission>();
                                    if (_storylineMissionsInJournalThatQuestorKnowsHowToDo != null && _storylineMissionsInJournalThatQuestorKnowsHowToDo.Any())
                                        return _storylineMissionsInJournalThatQuestorKnowsHowToDo;

                                    if (DebugConfig.DebugStorylineMissions)
                                        Log.WriteLine("if (_storylineMissionsInJournalThatQuestorKnowsHowToDo == null || !_storylineMissionsInJournalThatQuestorKnowsHowToDo.Any())");

                                    return null;
                                }

                                int StorylineNum = 0;
                                foreach (DirectAgentMission StorylineMissionInJournal in StorylineMissionsInJournal)
                                {
                                    StorylineNum++;
                                    if (DebugConfig.DebugStorylineMissions && !StorylineMissionsLogged)
                                        Log.WriteLine("StorylineMissionsInJournalThatQuestorKnowsHowToDo: [" + StorylineNum + "][" + StorylineMissionInJournal.Name + "] Agent [" + StorylineMissionInJournal.Agent.Name + "]");
                                }
                                StorylineMissionsLogged = true;

                                return new List<DirectAgentMission>();
                            }

                            return new List<DirectAgentMission>();
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                            return new List<DirectAgentMission>();
                        }

                    return _storylineMissionsInJournalThatQuestorKnowsHowToDo;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public static bool CourierMission(DirectAgent myAgent)
        {
            if (myAgent != null && myAgent.Mission != null)
            {
                if (!string.IsNullOrEmpty(myAgent.Mission.Type))
                {
                    if (DebugConfig.DebugCourierMissions) Log.WriteLine("Mission.Type [" + myAgent.Mission.Type + "]");

                    if (myAgent.Mission.Type.ToLower().Contains("Encounter".ToLower()))
                        return false;

                    if (myAgent.Mission.Type.ToLower().Contains("Mining".ToLower()))
                        return false;

                    if (myAgent.Mission.Type.ToLower().Contains("Courier".ToLower()))
                        return true;

                    //if (myAgent.RegularMission.GetAgentMissionRawCsvHint().ToLower().Contains("TransportItemsMissing".ToLower()))
                    //    return true;

                    //if (myAgent != null && myAgent.DivisionName.Contains("Distribution") && myAgent != StorylineMission.Agent)
                    //    return true;

                    return false;
                }

                if (DebugConfig.DebugCourierMissions) Log.WriteLine("myAgent.RegularMission.Type is [ null ]");
                return false;
            }

            //if (AgentToPullNextRegularMissionFrom != null && AgentToPullNextRegularMissionFrom.DivisionName.Contains("Distribution"))
            //    return true;

            if (DebugConfig.DebugCourierMissions) Log.WriteLine("myAgent is [ null ]");
            return false;
        }

        public static string FactionFittingNameForThisMissionsFaction(DirectAgentMission myMission)
        {
            if (_factionFittingNameForThisMissionsFaction == null)
            {
                if (myMission.Faction == null)
                    return null;

                if (ListofFactionFittings.Any(i => myMission.Faction != null && i.FactionName.ToLower() == myMission.Faction.Name.ToLower()))
                {
                    if (ListofFactionFittings.FirstOrDefault(m => myMission.Faction != null && m.FactionName.ToLower() == myMission.Faction.Name.ToLower()) != null)
                    {
                        FactionFittingForThisMissionsFaction = ListofFactionFittings.FirstOrDefault(m => myMission.Faction.Name != null && m.FactionName.ToLower() == myMission.Faction.Name.ToLower());
                        if (FactionFittingForThisMissionsFaction != null)
                        {
                            _factionFittingNameForThisMissionsFaction = FactionFittingForThisMissionsFaction.FittingName;
                            if (FactionFittingForThisMissionsFaction.Dronetype != 0)
                            {
                                Drones.FactionDroneTypeID = (int)FactionFittingForThisMissionsFaction.Dronetype;
                                FactionDroneTypeID = (int)FactionFittingForThisMissionsFaction.Dronetype;
                            }

                            Log.WriteLine("Faction fitting [" + FactionFittingForThisMissionsFaction.FactionName + "] DroneTypeID [" + Drones.DroneTypeID +
                                          "]");
                            return _factionFittingNameForThisMissionsFaction;
                        }

                        return null;
                    }

                    return null;
                }

                if (ListofFactionFittings.Any(i => i.FactionName.ToLower() == "Default".ToLower()))
                    if (ListofFactionFittings.FirstOrDefault(m => m.FactionName.ToLower() == "Default".ToLower()) != null)
                    {
                        FactionFittingForThisMissionsFaction = ListofFactionFittings.FirstOrDefault(m => m.FactionName.ToLower() == "Default".ToLower());
                        if (FactionFittingForThisMissionsFaction != null)
                        {
                            _factionFittingNameForThisMissionsFaction = FactionFittingForThisMissionsFaction.FittingName;
                            if (FactionFittingForThisMissionsFaction.Dronetype != 0)
                            {
                                Drones.FactionDroneTypeID = (int)FactionFittingForThisMissionsFaction.Dronetype;
                                FactionDroneTypeID = (int)FactionFittingForThisMissionsFaction.Dronetype;
                            }

                            Log.WriteLine("Faction fitting [" + FactionFittingForThisMissionsFaction.FactionName + "] Using DroneTypeID [" +
                                          Drones.DroneTypeID + "]");
                            return _factionFittingNameForThisMissionsFaction;
                        }

                        return null;
                    }

                return null;
            }

            return _factionFittingNameForThisMissionsFaction;

            //set => _factionFittingNameForThisMissionsFaction = value;
        }

        public static string FittingToTryToLoad(DirectAgentMission myMission)
        {
            try
            {
                if (!string.IsNullOrEmpty(_fittingToLoad))
                {
                    //Log.WriteLine("[FittingToLoad] Using _fittingToLoad [" + _fittingToLoad + "] MissionFittingNameForThisMissionName [" + MissionFittingNameForThisMissionName(myMission) + "] FactionFittingNameForThisMissionsFaction [" + FactionFittingNameForThisMissionsFaction(myMission) + "]");
                    return _fittingToLoad;
                }

                if (State.CurrentQuestorState == QuestorState.CombatMissionsBehavior)
                {
                    if (MyMission.Name.Contains("Anomic"))
                        return myMission.Name;

                    if (string.IsNullOrEmpty(MissionFittingNameForThisMissionName(myMission)))
                    {
                        if (string.IsNullOrEmpty(FactionFittingNameForThisMissionsFaction(myMission)))
                        {
                            Log.WriteLine("[FittingToLoad] Using DefaultFittingName [" + DefaultFittingName + "] MissionFittingNameForThisMissionName [" + MissionFittingNameForThisMissionName(myMission) + "] FactionFittingNameForThisMissionsFaction [" + FactionFittingNameForThisMissionsFaction(myMission) + "]");
                            //Log.WriteLine("[FittingToLoad] Not Using MissionFittingNameForThisMissionName [" + MissionFittingNameForThisMissionName + "] or FactionFittingNameForThisMissionsFaction [" + FactionFittingNameForThisMissionsFaction + "]");
                            _fittingToLoad = DefaultFittingName.ToLower();
                        }

                        Log.WriteLine("[FittingToLoad] Using FactionFittingNameForThisMissionsFaction [" + FactionFittingNameForThisMissionsFaction(myMission) + "]");
                        //Log.WriteLine("[FittingToLoad] Not Using MissionFittingNameForThisMissionName [" + MissionFittingNameForThisMissionName + "] or DefaultFittingName [" + DefaultFittingName + "]");
                        _fittingToLoad = FactionFittingNameForThisMissionsFaction(myMission);
                        return _fittingToLoad;
                    }

                    Log.WriteLine("[FittingToLoad] Using MissionFittingNameForThisMissionName [" + MissionFittingNameForThisMissionName(myMission) + "]");
                    //Log.WriteLine("[FittingToLoad] Not Using FactionFittingNameForThisMissionsFaction [" + FactionFittingNameForThisMissionsFaction + "] or DefaultFittingName [" + DefaultFittingName + "]");
                    _fittingToLoad = MissionFittingNameForThisMissionName(myMission);
                    return _fittingToLoad;
                }

                if (State.CurrentAbyssalDeadspaceBehaviorState == AbyssalDeadspaceBehaviorState.Arm)
                {
                    //Settings.Instance.
                }

                return string.Empty;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return null;
            }
        }

        public static bool HasStoryline()
        {
            // Do we have a registered storyline?
            if (StorylineMission != null)
            {
                if (DateTime.UtcNow > LastStoryLineMissionLogging.AddSeconds(30))
                {
                    LastStoryLineMissionLogging = DateTime.UtcNow;
                    Log.WriteLine("---------------------------- Storyline Mission Info --------------------------");
                    Log.WriteLine("[" + ESCache.Instance.DirectEve.AgentMissions.Count() + "] missions available.");
                    Log.WriteLine("[" + MissionsInJournalFromNotBlacklistedAgents.Count() + "] missions available that are not from blacklisted agents");
                    Log.WriteLine("[" + StorylineMissionsInJournal.Count() + "] storyline missions available");
                    int intStorylineMissionNum = 0;
                    foreach (DirectAgentMission mission in StorylineMissionsInJournal)
                    {
                        intStorylineMissionNum++;
                        Log.WriteLine("[" + intStorylineMissionNum + "] Storyline Mission Name [" + Log.FilterPath(mission.Name) + "] Type [" + mission.Type + "]");
                    }

                    Log.WriteLine("[" + StorylineMissionsInJournalThatQuestorKnowsHowToDo.Count() + "] storyline missions questor knows how to do");
                    Log.WriteLine("[" + StorylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted.Count() + "] storyline missions questor knows how to do and are not blacklisted");
                    Log.WriteLine("---------------------------- Storyline Mission Info. -------------------------");
                    return true;
                }

                return true;
            }

            return false;
        }

        public static string MissionFittingNameForThisMissionName(DirectAgentMission myMission)
        {
            try
            {
                if (MissionSpecificMissionFitting(myMission) != null && !string.IsNullOrEmpty(MissionSpecificMissionFitting(myMission).FittingName))
                    return MissionSpecificMissionFitting(myMission).FittingName;

                if (DebugConfig.DebugFittingMgr) Log.WriteLine("DebugFittingMgr: [MissionFittingNameForThisMissionName] failed: if (MissionSpecificMissionFitting != null && !string.IsNullOrEmpty(MissionSpecificMissionFitting.Ship))");
                return null;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return null;
            }
        }

        public static MissionFitting MissionSpecificMissionFitting(DirectAgentMission myMission)
        {
            if (_missionSpecificMissionFitting == null)
            {
                if (myMission != null)
                    return null;

                if (myMission != null && myMission.Faction == null)
                    return null;

                if (myMission != null && !string.IsNullOrEmpty(myMission.Name))
                {
                    //if (UseMissionSpecificShip)
                    {
                        MissionFitting tempFittingWeFound = null;
                        string lookForFittingNamed = string.Empty;
                        if (ListOfMissionFittings != null && ListOfMissionFittings.Any())
                        {
                            if (!string.IsNullOrEmpty(myMission.Faction.Name))
                            {
                                lookForFittingNamed = Log.FilterPath(myMission.Name.ToLower() + "-" + Log.FilterPath(myMission.Faction.Name).ToLower() + "-" + Log.FilterPath(ESCache.Instance.EveAccount.CharacterName).ToLower());
                                tempFittingWeFound = LookForFitting(lookForFittingNamed.ToLower());
                                if (tempFittingWeFound != null)
                                {
                                    _missionSpecificMissionFitting = tempFittingWeFound;
                                    return _missionSpecificMissionFitting;
                                }

                                lookForFittingNamed = Log.FilterPath(myMission.Name.ToLower() + "-" + Log.FilterPath(myMission.Faction.Name).ToLower());
                                tempFittingWeFound = LookForFitting(lookForFittingNamed.ToLower());
                                if (tempFittingWeFound != null)
                                {
                                    _missionSpecificMissionFitting = tempFittingWeFound;
                                    return _missionSpecificMissionFitting;
                                }

                                lookForFittingNamed = Log.FilterPath(myMission.Name.ToLower() + "-" + myMission.Faction.Name.ToLower());
                                tempFittingWeFound = LookForFitting(lookForFittingNamed.ToLower());
                                if (tempFittingWeFound != null)
                                {
                                    _missionSpecificMissionFitting = tempFittingWeFound;
                                    return _missionSpecificMissionFitting;
                                }
                            }

                            lookForFittingNamed = Log.FilterPath(myMission.Name.ToLower() + "-" + Log.FilterPath(ESCache.Instance.EveAccount.CharacterName).ToLower());
                            tempFittingWeFound = LookForFitting(lookForFittingNamed);
                            if (tempFittingWeFound != null)
                            {
                                _missionSpecificMissionFitting = tempFittingWeFound;
                                return _missionSpecificMissionFitting;
                            }

                            lookForFittingNamed = Log.FilterPath(myMission.Name.ToLower());
                            tempFittingWeFound = LookForFitting(lookForFittingNamed);
                            if (tempFittingWeFound != null)
                            {
                                _missionSpecificMissionFitting = tempFittingWeFound;
                                return _missionSpecificMissionFitting;
                            }

                            lookForFittingNamed = myMission.Name.ToLower();
                            tempFittingWeFound = LookForFitting(lookForFittingNamed);
                            if (tempFittingWeFound != null)
                            {
                                _missionSpecificMissionFitting = tempFittingWeFound;
                                return _missionSpecificMissionFitting;
                            }

                            return null;
                        }

                        return null;
                    }

                    //return null;
                }

                return null;
            }

            //Log.WriteLine("MissionSpecificMissionFitting [" + _missionSpecificMissionFitting.Ship + "] MissionName [" + _missionSpecificMissionFitting.MissionName + "] FittingName [" + _missionSpecificMissionFitting.FittingName + "]");
            return _missionSpecificMissionFitting;
        }

        //public static DirectAgentMission missionDetailsForMissionItems = QCache.Instance.GetAgentMission(MissionSettings.Agent.AgentId, false);
        public static string MissionXmlPath(DirectAgentMission myMission)
        {
            try
            {
                if (_missionXmlPath != null) return _missionXmlPath;

                if (myMission == null) return string.Empty;

                if (myMission.Faction == null)
                    return null;

                if (!string.IsNullOrEmpty(myMission.Faction.Name))
                {
                    _missionXmlPath = Path.Combine(MissionsPath, Log.FilterPath(myMission.Name) + "-" + Log.FilterPath(ESCache.Instance.EveAccount.CharacterName) + ".xml");
                    if (!File.Exists(_missionXmlPath))
                    {
                        _missionXmlPath = Path.Combine(MissionsPath, Log.FilterPath(myMission.Name) + "-" + Log.FilterPath(myMission.Faction.Name) + ".xml");
                        if (!File.Exists(_missionXmlPath))
                        {
                            _missionXmlPath = Path.Combine(MissionsPath, Log.FilterPath(myMission.Name) + "-" + myMission.Faction.Name + ".xml");
                            if (!File.Exists(_missionXmlPath))
                            {
                                Log.WriteLine("[" + _missionXmlPath + "] not found.");
                                _missionXmlPath = Path.Combine(MissionsPath, Log.FilterPath(myMission.Name) + ".xml");
                                if (!File.Exists(_missionXmlPath)) Log.WriteLine("[" + _missionXmlPath + "] not found");
                                if (File.Exists(_missionXmlPath)) Log.WriteLine("[" + _missionXmlPath + "] found!");
                                return _missionXmlPath;
                            }

                            if (File.Exists(_missionXmlPath)) Log.WriteLine("[" + _missionXmlPath + "] found!");
                            return _missionXmlPath;
                        }

                        if (File.Exists(_missionXmlPath)) Log.WriteLine("[" + _missionXmlPath + "] found!");
                        return _missionXmlPath;
                    }

                    if (File.Exists(_missionXmlPath)) Log.WriteLine("[" + _missionXmlPath + "] found!");
                    return _missionXmlPath;
                }

                Log.WriteLine("MissionXMLpath: if (!string.IsNullOrEmpty(myMission.Faction.Name)) myMission.Name [" + myMission.Name + "]");
                _missionXmlPath = Path.Combine(MissionsPath, Log.FilterPath(Log.FilterPath(myMission.Name)) + ".xml");
                if (File.Exists(_missionXmlPath)) Log.WriteLine("[" + _missionXmlPath + "] found!");
                return _missionXmlPath;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return string.Empty;
            }
        }

        public static bool StorylineMissionDetected()
        {
            if (Settings.Instance.EnableStorylines)
            {
                if (HasStoryline())
                {
                    Log.WriteLine("EnableStorylines [" + Settings.Instance.EnableStorylines + "]: Storyline detected");
                    return true;
                }

                if (DebugConfig.DebugStorylineMissions) Log.WriteLine("EnableStorylines [" + Settings.Instance.EnableStorylines + "]: No storyline missions detected");
                return false;
            }

            if (DebugConfig.DebugStorylineMissions) Log.WriteLine("EnableStorylines [" + Settings.Instance.EnableStorylines + "]");
            return false;
        }

        public static bool SwitchAgents(string agentShortDescription, string agentToAttemptToSwitchTo, string nameOfEveAccountSetting = "")
        {
            DirectAgent tempAgent = null;
            Log.WriteLine("Attempting to use agent [" + agentShortDescription + "][" + agentToAttemptToSwitchTo + "]");
            try
            {
                tempAgent = ESCache.Instance.DirectEve.GetAgentByName(agentToAttemptToSwitchTo);
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }

            if (tempAgent != null)
            {
                Log.WriteLine("SwitchAgents: Agent [" + tempAgent.Name + "] AgentID [" + tempAgent.AgentId + "] Faction [" + tempAgent.FactionName + "]");
                AgentToPullNextRegularMissionFrom = null;
                strCurrentAgentName = tempAgent.Name;
                _agent = tempAgent;
                //State.CurrentQuestorState = QuestorState.CombatMissionsBehavior;
                return true;
            }

            if (string.IsNullOrEmpty(nameOfEveAccountSetting))
            {
                Log.WriteLine("Marking Agent [" + strCurrentAgentName + "] done: we could find no agent with that name!");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameOfEveAccountSetting, true);
                return false;
            }

            if (tempAgent == null)
            {
                Log.WriteLine("Marking Agent [" + strCurrentAgentName + "] done: we could find no agent with that name! tempagent == null");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameOfEveAccountSetting, true);
                return false;
            }

            return false;
        }

        #endregion Properties

        #region Methods

        public static bool AnyAmmoOfTypeLeft(DamageType t)
        {
            AmmoType ammo = DirectModule.DefinedAmmoTypes.FirstOrDefault(a => a.DamageType == t);
            if (ammo != null)
                if (ESCache.Instance.CurrentShipsCargo?.Items.Any(i =>
                        !i.IsSingleton && i.TypeId == ammo.TypeId && i.Quantity > Combat.MinimumAmmoCharges) ?? false
                    || ESCache.Instance.Weapons.Where(w => w.Charge != null && w.Charge.TypeId == ammo.TypeId).Sum(w => w.ChargeQty) > 0)
                    return true;
            return false;
        }

        public static void ClearFactionSpecificSettings()
        {
            FactionActivateRepairModulesAtThisPerc = null;
            FactionDroneTypeID = null;
            _listofFactionFittings.Clear();
        }

        private const string constCareerAgentAmarr1 = "Chakh Madafe";
        private const string constCareerAgentAmarr2 = "Zafarara Fari";
        private const string constCareerAgentAmarr3 = "Joas Alathema";
        private const string constCareerAgentCaldari1 = "Ikonaiki Ebora";
        private const string constCareerAgentCaldari2 = "Yamonen Petihainen";
        private const string constCareerAgentCaldari3 = "Ranta Tarumo";
        private const string constCareerAgentGallente1 = "Berlimaute Remintgarnes";
        private const string constCareerAgentGallente2 = "Hasier Parcie";
        private const string constCareerAgentGallente3 = "Seville Eyron";
        private const string constCareerAgentMinmatar1 = "Fykalia Adaferid";
        private const string constCareerAgentMinmatar2 = "Arninald Beinarakur";
        private const string constCareerAgentMinmatar3 = "Stird Odetlef";

        public static void TrackCareerAgentsWithNoMissionsAvailable(DirectAgent myAgent)
        {
            //
            // confirm agent has no missions?
            //
            if (AgentInteraction.boolNoMissionsAvailable)
            {
                //Caldari Agents
                if (myAgent != null && myAgent.Name == constCareerAgentCaldari1)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentCaldari1MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentCaldari1MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Caldari Agents
                if (myAgent != null && myAgent.Name == constCareerAgentCaldari2)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentCaldari2MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentCaldari2MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Caldari Agents
                if (myAgent != null && myAgent.Name == constCareerAgentCaldari3)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentCaldari3MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentCaldari3MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Minmatar Agents
                if (myAgent != null && myAgent.Name == constCareerAgentMinmatar1)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentMinmatar1MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentMinmatar1MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Minmatar Agents
                if (myAgent != null && myAgent.Name == constCareerAgentMinmatar2)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentMinmatar2MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentMinmatar2MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Minmatar Agents
                if (myAgent != null && myAgent.Name == constCareerAgentMinmatar3)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentMinmatar3MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentMinmatar3MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Gallente Agents
                if (myAgent != null && myAgent.Name == constCareerAgentGallente1)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentGallente1MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentGallente1MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Gallente Agents
                if (myAgent != null && myAgent.Name == constCareerAgentGallente2)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentGallente2MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentGallente2MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Gallente Agents
                if (myAgent != null && myAgent.Name == constCareerAgentGallente3)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentGallente3MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentGallente3MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Amarr Agents
                if (myAgent != null && myAgent.Name == constCareerAgentAmarr1)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentAmarr1MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentAmarr1MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Amarr Agents
                if (myAgent != null && myAgent.Name == constCareerAgentAmarr2)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentAmarr2MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentAmarr2MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                    return;
                }

                //Amarr Agents
                if (myAgent != null && myAgent.Name == constCareerAgentAmarr3)
                {
                    Log.WriteLine("Marking Agent [" + myAgent.Name + "] complete as they have no more missions available to us.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.CareerAgentAmarr3MissionsComplete), true);
                    //why would this be necessary?!
                    ESCache.Instance.EveAccount.CareerAgentAmarr3MissionsComplete = true;
                    AgentInteraction.boolNoMissionsAvailable = false;
                }
            }
        }

        public static void PickAgentToUseNext()
        {
            //TrackCareerAgentsWithNoMissionsAvailable();
            Log.WriteLine("PickAgentToUseNext: Start");
            if (!ESCache.Instance.EveAccount.CareerAgentCaldari1MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentCaldari1MissionsComplete) use [" + constCareerAgentCaldari1 + "]");
                if (SwitchAgents("C1", constCareerAgentCaldari1, nameof(EveAccount.CareerAgentCaldari1MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentCaldari2MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentCaldari2MissionsComplete) use [" + constCareerAgentCaldari2 + "]");
                if (SwitchAgents("C2", constCareerAgentCaldari2, nameof(EveAccount.CareerAgentCaldari2MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentCaldari3MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentCaldari3MissionsComplete) use [" + constCareerAgentCaldari3 + "]");
                if (SwitchAgents("C3", constCareerAgentCaldari3, nameof(EveAccount.CareerAgentCaldari3MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentMinmatar1MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentMinmatar1MissionsComplete) use [" + constCareerAgentMinmatar1 + "]");
                if (SwitchAgents("M1", constCareerAgentMinmatar1, nameof(EveAccount.CareerAgentMinmatar1MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentMinmatar2MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentMinmatar2MissionsComplete) use [" + constCareerAgentMinmatar2 + "]");
                if (SwitchAgents("M2", constCareerAgentMinmatar2, nameof(EveAccount.CareerAgentMinmatar2MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentMinmatar3MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentMinmatar3MissionsComplete) use [" + constCareerAgentMinmatar3 + "]");
                if (SwitchAgents("M3", constCareerAgentMinmatar3, nameof(EveAccount.CareerAgentMinmatar3MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentGallente1MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentGallente1MissionsComplete) use [" + constCareerAgentGallente1 + "]");
                if (SwitchAgents("G1", constCareerAgentGallente1, nameof(EveAccount.CareerAgentGallente1MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentGallente2MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentGallente2MissionsComplete) use [" + constCareerAgentGallente2 + "]");
                if (SwitchAgents("G2", constCareerAgentGallente2, nameof(EveAccount.CareerAgentGallente2MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentGallente3MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentGallente3MissionsComplete) use [" + constCareerAgentGallente3 + "]");
                if (SwitchAgents("G3", constCareerAgentGallente3, nameof(EveAccount.CareerAgentGallente3MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentAmarr1MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentAmarr1MissionsComplete) use [" + constCareerAgentAmarr1 + "]");
                if (SwitchAgents("A1", constCareerAgentAmarr1, nameof(EveAccount.CareerAgentAmarr1MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentAmarr2MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentAmarr2MissionsComplete) use [" + constCareerAgentAmarr2 + "]");
                if (SwitchAgents("A2", constCareerAgentAmarr2, nameof(EveAccount.CareerAgentAmarr2MissionsComplete))) return;
            }

            if (!ESCache.Instance.EveAccount.CareerAgentAmarr3MissionsComplete)
            {
                Log.WriteLine("PickAgentToUseNext: if (!ESCache.Instance.EveAccount.CareerAgentAmarr3MissionsComplete) use [" + constCareerAgentAmarr3 + "]");
                if (SwitchAgents("A3", constCareerAgentAmarr3, nameof(EveAccount.CareerAgentAmarr3MissionsComplete))) return;
            }

            ControllerManager.Instance.SetPause(true);
            Log.WriteLine("Pausing: There are no more career agents left to process.");
        }

        public static void ClearMissionSpecificSettings()
        {
            try
            {
                strCurrentAgentName = null;

                AgentToPullNextRegularMissionFrom = null;
                //if (State.CurrentStorylineState != StorylineState.Idle)
                //{
                //    CombatMissionsBehavior.ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                //    _storylineMission = null;
                //    StorylineInstance.Reset();
                //}
                Combat.LoadAmmoSettings(Settings.CharacterSettingsXml, Settings.CommonSettingsXml);
                ClearFactionSpecificSettings();
                _myMission = null;
                _missionXmlPath = null;
                _missionSpecificMissionFitting = null;
                MissionDronesKillHighValueTargets = null;
                MissionWarpAtDistanceRange = 0;
                MissionXMLIsAvailable = true;
                MissionDroneTypeID = null;
                MissionKillSentries = null;
                MissionUseDrones = null;
                MissionOrbitDistance = null;
                MissionOptimalRange = null;
                _factionFittingNameForThisMissionsFaction = null;
                FactionFittingForThisMissionsFaction = null;
                _fittingToLoad = null;
                LastReasonMissionAttemptedToBeDeclined = string.Empty;
                Defense.ActivateRepairModulesAtThisPercMissionSetting = null;
                Defense.ActivateSecondRepairModulesAtThisPercMissionSetting = null;
                Defense.DeactivateRepairModulesAtThisPercMissionSetting = null;
                Defense.attemptOverloadRackHigh = false;
                Defense.attemptOverloadRackMedium = false;
                Defense.attemptOverloadRackLow = false;
                Defense.attemptOverloadHighSlot1 = false;
                Defense.attemptOverloadHighSlot2 = false;
                Defense.attemptOverloadHighSlot3 = false;
                Defense.attemptOverloadHighSlot4 = false;
                Defense.attemptOverloadHighSlot5 = false;
                Defense.attemptOverloadHighSlot6 = false;
                Defense.attemptOverloadHighSlot7 = false;
                Defense.attemptOverloadHighSlot8 = false;
                Defense.attemptOverloadMidSlot1 = false;
                Defense.attemptOverloadMidSlot2 = false;
                Defense.attemptOverloadMidSlot3 = false;
                Defense.attemptOverloadMidSlot4 = false;
                Defense.attemptOverloadMidSlot5 = false;
                Defense.attemptOverloadMidSlot6 = false;
                Defense.attemptOverloadMidSlot7 = false;
                Defense.attemptOverloadMidSlot8 = false;
                Defense.attemptOverloadLowSlot1 = false;
                Defense.attemptOverloadLowSlot2 = false;
                Defense.attemptOverloadLowSlot3 = false;
                Defense.attemptOverloadLowSlot4 = false;
                Defense.attemptOverloadLowSlot5 = false;
                Defense.attemptOverloadLowSlot6 = false;
                Defense.attemptOverloadLowSlot7 = false;
                Defense.attemptOverloadLowSlot8 = false;
                MinimumShieldPctMissionSetting = null;
                MinimumArmorPctMissionSetting = null;
                MinimumCapacitorPctMissionSetting = null;
                NavigateOnGrid.SpeedTankMissionSetting = null;
                MissionNumberOfCapBoostersToLoad = 0;
                MissionCapacitorInjectorScript = 0;
                MissionAllowOverLoadOfWeapons = false;
                MissionAllowOverLoadOfReps = false;
                ActionControl.IgnoreTargets.Clear();
                _modulesInAllInGameFittings = null;
                MissionSpecificShipName = string.Empty;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static void ClearPerPocketCache()
        {
            PocketActivateRepairModulesAtThisPerc = null;
            PocketKillSentries = null;
            PocketUseDrones = null;
        }

        public static DirectAgentMissionBookmark GetMissionBookmark(DirectAgent myAgent, string startsWith)
        {
            try
            {
                if (myAgent == null)
                {
                    Log.WriteLine("GetMissionBookmark: myAgent == null");
                    return null;
                }

                if (string.IsNullOrEmpty(startsWith))
                {
                    Log.WriteLine("GetMissionBookmark: if (string.IsNullOrEmpty(startsWith))");
                    return null;
                }

                DirectAgentMission missionForBookmarkInfo = ESCache.Instance.DirectEve.AgentMissions.FirstOrDefault(m => m.Agent.AgentId == myAgent.AgentId);
                if (missionForBookmarkInfo == null)
                {
                    Log.WriteLine("missionForBookmarkInfo == null - No Mission found: myAgent [" + myAgent.Name + "] startswith [" + startsWith + "]");
                    int intMission = 0;
                    foreach (DirectAgentMission mission in ESCache.Instance.DirectEve.AgentMissions)
                    {
                        intMission++;
                        Log.WriteLine("[" + intMission + "][" + mission.Name + "][" + mission.Agent.Name + "] lvl [" + mission.Agent.Level + "] Type [" + mission.Type + "] Important [" + mission.Important + "]");
                    }

                    return null;
                }

                if (missionForBookmarkInfo.State != MissionState.Accepted)
                {
                    Log.WriteLine("missionForBookmarkInfo.State: [" + missionForBookmarkInfo.State + "]");
                    if (missionForBookmarkInfo.State != MissionState.Offered)
                    {
                        Log.WriteLine("MissionState is [" + MissionState.Offered + "] resetting AgentInteractionState to Idle to try to accept the offered mission! (this is a bug!)");
                        AgentInteraction.ChangeAgentInteractionState(AgentInteractionState.Idle, myAgent);
                        if (ESCache.Instance.EveAccount.SelectedController == "Questor")
                            CombatMissionsBehavior.ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, false, null);
                    }
                }

                if (missionForBookmarkInfo.Agent.AgentId != myAgent.AgentId)
                {
                    Log.WriteLine("missionForBookmarkInfo.Agent.Name: [" + missionForBookmarkInfo.Agent.Name + "] ID [" + missionForBookmarkInfo.Agent.AgentId + "] and myAgent [" + myAgent.Name + "][" + myAgent.AgentId + "]");
                    return null;
                }

                if (missionForBookmarkInfo.Bookmarks != null && missionForBookmarkInfo.Bookmarks.Any(b => b.Title.ToLower().StartsWith(startsWith.ToLower())))
                {
                    Log.WriteLine("MissionBookmark Found");
                    return missionForBookmarkInfo.Bookmarks.FirstOrDefault(b => b.Title.ToLower().StartsWith(startsWith.ToLower()));
                }

                if (ESCache.Instance.DirectEve.Bookmarks != null && ESCache.Instance.DirectEve.Bookmarks.Any(b => b.Title.ToLower().StartsWith(startsWith.ToLower())))
                {
                    Log.WriteLine("MissionBookmark From your Agent Not Found, but we did find a bookmark for a mission");
                    return (DirectAgentMissionBookmark)ESCache.Instance.DirectEve.Bookmarks.FirstOrDefault(b => b.Title.ToLower().StartsWith(startsWith.ToLower()));
                }

                Log.WriteLine("MissionBookmark From your Agent Not Found: and as a fall back we could not find any bookmark starting with [" + startsWith +
                              "] either... ");
                return null;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return null;
            }
        }

        public static void InvalidateCache()
        {
            //_agentMissionInfo = string.Empty;
            _missionsInJournalFromNotBlacklistedAgents = null;
            _storylineMissionsInJournal = null;
            _storylineMissionsInJournalThatQuestorKnowsHowToDo = null;
            _storylineMissionsInJournalThatQuestorKnowsHowToDoNotBlacklisted = null;
        }

        public static bool IsFactionBlacklisted(DirectAgent myAgent)
        {
            try
            {
                if (myAgent == null) return false;
                if (myAgent.Mission == null) return false;

                if (myAgent.Mission.Type.Contains("Trade"))
                    return false;

                if (myAgent.Mission.Type.Contains("Courier"))
                    return false;

                if (myAgent.Mission.Faction == null)
                    return false;

                if (FactionBlacklist.Any(m => m.ToLower().Contains(myAgent.Mission.Faction.Name.ToLower())))
                    return true;

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public static bool IsMissionBlacklisted(DirectAgent myAgent)
        {
            if (myAgent == null)
                return false;

            if (myAgent.Mission == null)
                return false;

            if (CourierMission(myAgent))
                return false;

            if (MissionBlacklist == null)
                return false;

            if (!MissionBlacklist.Any())
                return false;

            if (MissionBlacklist != null && !string.IsNullOrEmpty(myAgent.Mission.Name) && MissionBlacklist.Any(m => myAgent.Mission.Name.ToLower().Contains(m.ToLower())))
                return true;

            foreach (string phrase in MissionObjectivePhraseBlacklist)
                if (!string.IsNullOrEmpty(phrase) && !string.IsNullOrWhiteSpace(phrase))
                    if (myAgent.Window.Objective.ToLower().Contains(phrase.ToLower()))
                    {
                        Log.WriteLine("IsMissionBlacklisted found phrase [" + phrase + "] in the mission objective.");
                        Log.WriteLine(myAgent.Window.Objective);
                        Log.WriteLine("IsMissionBlacklisted found phrase [" + phrase + "] in the mission objective.");
                        return true;
                    }

            return false;
        }

        public static void LoadDistributionAgentsAllowedCorporations(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                DistributionAgentsAllowedCorporations.Clear();
                XElement xmlDistributionAgentsAllowedCorporationSection = CharacterSettingsXml.Element("distributionAgentsAllowedCorporations") ?? CommonSettingsXml.Element("distributionAgentsAllowedCorporations");
                if (xmlDistributionAgentsAllowedCorporationSection != null)
                {
                    Log.WriteLine("Loading DistributionAgents Allowed Corporation List");
                    int i = 1;
                    foreach (XElement xmlDistributionAgentsAllowedCorporation in xmlDistributionAgentsAllowedCorporationSection.Elements("distributionAgentsAllowedCorporation"))
                        if (DistributionAgentsAllowedCorporations.All(m => m != xmlDistributionAgentsAllowedCorporation.Value))
                        {
                            Log.WriteLine("   Any Corporation containing [" + Log.FilterPath(xmlDistributionAgentsAllowedCorporation.Value) + "] in the name will be included in the list of corporations we look for agents");
                            DistributionAgentsAllowedCorporations.Add(Log.FilterPath(xmlDistributionAgentsAllowedCorporation.Value));
                            i++;
                        }

                    Log.WriteLine("DistributionAgents Allowed Corporation List now has [" + MissionBlacklist.Count + "] entries");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception: [" + ex + "]");
            }
        }

        public static void LoadFactionBlacklist(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                FactionBlacklist.Clear();
                XElement factionblacklist = CharacterSettingsXml.Element("factionblacklist") ?? CommonSettingsXml.Element("factionblacklist");
                if (factionblacklist != null)
                {
                    Log.WriteLine("Loading Faction Blacklist");
                    foreach (XElement faction in factionblacklist.Elements("faction"))
                    {
                        Log.WriteLine("        Missions against the faction [" + (string)faction + "] will be declined");
                        FactionBlacklist.Add((string)faction);
                    }

                    Log.WriteLine(" Faction Blacklist now has [" + FactionBlacklist.Count + "] entries");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception: [" + ex + "]");
            }
        }

        public static void LoadMissionBlackList(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                MissionBlacklist.Clear();
                XElement xmlElementBlackListSection = CharacterSettingsXml.Element("blacklist") ?? CommonSettingsXml.Element("blacklist");
                if (xmlElementBlackListSection != null)
                {
                    Log.WriteLine("Loading Mission Blacklist");
                    int i = 1;
                    foreach (XElement xmlBlacklistedMission in xmlElementBlackListSection.Elements("mission"))
                        if (MissionBlacklist.All(m => m != xmlBlacklistedMission.Value))
                        {
                            Log.WriteLine("   Any Mission containing [" + Log.FilterPath(xmlBlacklistedMission.Value) + "] in the name will be declined");
                            MissionBlacklist.Add(Log.FilterPath(xmlBlacklistedMission.Value));
                            i++;
                        }

                    Log.WriteLine("Mission Blacklist now has [" + MissionBlacklist.Count + "] entries");
                }

                MissionObjectivePhraseBlacklist.Clear();
                XElement xmlElementObjectivePhraseBlackListSection = CharacterSettingsXml.Element("objectivePhraseBlacklist") ?? CommonSettingsXml.Element("objectivePhraseBlacklist");
                if (xmlElementObjectivePhraseBlackListSection != null)
                {
                    Log.WriteLine("Loading Mission Objective Phrase Blacklist");
                    int i = 1;
                    foreach (XElement xmlPhrase in xmlElementObjectivePhraseBlackListSection.Elements("phraseToNotAllow"))
                        if (MissionObjectivePhraseBlacklist.All(m => m != xmlPhrase.Value && !string.IsNullOrEmpty(xmlPhrase.Value) && !string.IsNullOrWhiteSpace(xmlPhrase.Value)))
                        {
                            Log.WriteLine("   Any Mission containing [" + Log.FilterPath(xmlPhrase.Value) + "] in the objective will be declined");
                            MissionObjectivePhraseBlacklist.Add(Log.FilterPath(xmlPhrase.Value));
                            i++;
                        }

                    Log.WriteLine("Mission Objective Phrase Blacklist now has [" + MissionObjectivePhraseBlacklist.Count + "] entries");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception: [" + ex + "]");
            }
        }

        public static void LoadMissionGreyList(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                MissionGreylist.Clear();
                XElement xmlElementGreyListSection = CharacterSettingsXml.Element("greylist") ?? CommonSettingsXml.Element("greylist");

                if (xmlElementGreyListSection != null)
                {
                    Log.WriteLine("Loading Mission GreyList");
                    int i = 1;
                    foreach (XElement GreylistedMission in xmlElementGreyListSection.Elements("mission"))
                    {
                        Log.WriteLine("   Any Mission containing [" + Log.FilterPath(GreylistedMission.Value) + "] in the name will be declined if our standings are high enough");
                        MissionGreylist.Add(Log.FilterPath((string)GreylistedMission));
                        i++;
                    }
                    Log.WriteLine("        Mission GreyList now has [" + MissionGreylist.Count + "] entries");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception: [" + ex + "]");
            }
        }

        public static void LoadMissionXmlData(DirectAgentMission myMission)
        {
            Log.WriteLine("Loading mission xml [" + myMission.Name + "] from [" + MissionXmlPath(myMission) + "]");
            ClearMissionSpecificSettings();

            try
            {
                missionXml = XDocument.Load(MissionXmlPath(myMission));

                if (missionXml.Root != null)
                {
                    Defense.LoadMissionXmlData(missionXml);

                    IEnumerable<string> items =
                        ((IEnumerable)
                            missionXml.XPathEvaluate(
                                "//action[(translate(@name, 'LOT', 'lot')='loot') or (translate(@name, 'LOTIEM', 'lotiem')='lootitem')]/parameter[translate(@name, 'TIEM', 'tiem')='item']/@value")
                        )
                        .Cast<XAttribute>()
                        .Select(a => ((string)a ?? string.Empty).ToLower());
                    MissionItems.AddRange(items);

                    MissionCapacitorInjectorScript = (int?)missionXml.Root.Element("capacitorInjectorScript") ?? null;
                    MissionNumberOfCapBoostersToLoad = (int?)missionXml.Root.Element("numberOfCapBoostersToLoad") ?? (int?)missionXml.Root.Element("capacitorInjectorToLoad") ?? null;
                    MissionUseDrones = (bool?)missionXml.Root.Element("useDrones") ?? (bool?)missionXml.Root.Element("UseDrones") ?? (bool?)missionXml.Root.Element("usedrones") ?? (bool?)missionXml.Root.Element("missionUseDrones") ?? null;
                    MissionDronesKillHighValueTargets = (bool?)missionXml.Root.Element("dronesKillHighValueTargets") ?? null;
                    MissionKillSentries = (bool?)missionXml.Root.Element("killSentries") ?? null;
                    MissionWarpAtDistanceRange = (int?)missionXml.Root.Element("missionWarpAtDistanceRange") ?? 0;
                    MissionDroneTypeID = (int?)missionXml.Root.Element("droneTypeId") ?? (int?)missionXml.Root.Element("DroneTypeId") ?? null;
                    MissionSpecificShipName = (string)missionXml.Root.Element("missionSpecificShipName") ?? string.Empty;
                    MissionAllowOverLoadOfWeapons = (bool?)missionXml.Root.Element("missionAllowOverLoadOfWeapons") ?? false;
                    MissionAllowOverLoadOfEcm = (bool?)missionXml.Root.Element("missionAllowOverLoadOfEcm") ?? false;
                    MissionAllowOverLoadOfSpeedMod = (bool?)missionXml.Root.Element("missionAllowOverLoadOfSpeedMod") ?? false;
                    MissionAllowOverLoadOfWebs = (bool?)missionXml.Root.Element("missionAllowOverLoadOfWebs") ?? false;
                    MissionAllowOverLoadOfReps = (bool?)missionXml.Root.Element("missionAllowOverLoadOfReps") ?? false;
                    NavigateOnGrid.SpeedTankMissionSetting = (bool?)missionXml.Root.Element("speedTank") ?? (bool?)missionXml.Root.Element("speedtank") ?? null;
                    MissionOrbitDistance = (double?)missionXml.Root.Element("orbitdistance") ?? (double?)missionXml.Root.Element("orbitDistance") ?? null;
                    MissionOptimalRange = (double?)missionXml.Root.Element("optimalrange") ?? (double?)missionXml.Root.Element("optimalRange") ?? null;
                    MinimumShieldPctMissionSetting = (int?)missionXml.Root.Element("minimumShieldPct") ?? null;
                    MinimumArmorPctMissionSetting = (int?)missionXml.Root.Element("minimumArmorPct") ?? null;
                    MinimumCapacitorPctMissionSetting = (int?)missionXml.Root.Element("minimumCapacitorPct") ?? null;
                    MissionAlwaysActivateSpeedMod = (bool?)missionXml.Root.Element("missionAlwaysActivateSpeedMod") ?? false;
                    MissionInjectCapPerc = (int?)missionXml.Root.Element("missionInjectCapPerc") ?? null;
                    MissionTooCloseToStructure = (int?)missionXml.Root.Element("missionTooCloseToStructure") ?? null;
                    MissionSafeDistanceFromStructure = (int?)missionXml.Root.Element("missionSafeDistanceFromStructure") ?? null;
                    MissionWeaponOverloadDamageAllowed = (int?)missionXml.Root.Element("missionWeaponOverloadDamageAllowed") ?? null;
                    MissionEcmOverloadDamageAllowed = (int?)missionXml.Root.Element("missionEcmOverloadDamageAllowed") ?? null;
                    MissionSpeedModOverloadDamageAllowed = (int?)missionXml.Root.Element("missionSpeedModOverloadDamageAllowed") ?? null;
                    MissionWebOverloadDamageAllowed = (int?)missionXml.Root.Element("missionWebOverloadDamageAllowed") ?? null;
                    MissionLootEverything = (bool?)missionXml.Root.Element("missionLootEverything") ?? null;

                    MoveMissionItems = (string)missionXml.Root.Element("bring") ?? string.Empty;
                    MoveMissionItems = MoveMissionItems.ToLower();
                    if (!string.IsNullOrEmpty(MoveMissionItems))
                        Log.WriteLine("bring XML [" + missionXml.Root.Element("bring") + "] BringMissionItem [" + MoveMissionItems + "]");

                    MoveMissionItemsQuantity = (int?)missionXml.Root.Element("bringquantity") ?? 1;
                    if (MoveMissionItemsQuantity > 0)
                        Log.WriteLine("bringquantity XML [" + missionXml.Root.Element("bringquantity") + "] BringMissionItemQuantity [" + MoveMissionItemsQuantity + "]");

                    MoveOptionalMissionItems = (string)missionXml.Root.Element("trytobring") ?? string.Empty;
                    MoveOptionalMissionItems = MoveOptionalMissionItems.ToLower();
                    if (!string.IsNullOrEmpty(MoveOptionalMissionItems))
                        Log.WriteLine("trytobring XML [" + missionXml.Root.Element("trytobring") + "] BringOptionalMissionItem [" + MoveOptionalMissionItems + "]");

                    MoveOptionalMissionItemQuantity = (int?)missionXml.Root.Element("trytobringquantity") ?? 1;
                    if (MoveOptionalMissionItemQuantity > 0)
                        Log.WriteLine("trytobringquantity XML [" + missionXml.Root.Element("trytobringquantity") + "] BringOptionalMissionItemQuantity [" + MoveOptionalMissionItemQuantity + "]");


                    try
                    {
                        XElement ammoTypes = missionXml.Root.Element("ammoTypes");
                        if (ammoTypes != null)
                        {
                            DirectModule.DefinedAmmoTypes = new List<AmmoType>();
                            foreach (XElement ammo in ammoTypes.Elements("ammoType"))
                            {
                                AmmoType ammoToAdd = new AmmoType(ammo);
                                Log.WriteLine("Adding DefinedAmmoTypes [" + ammoToAdd.Description + "] TypeId [" + ammoToAdd.TypeId + "][" + ammoToAdd.DamageType + "] Range [" + ammoToAdd.Range + "] Quantity [" + ammoToAdd.Quantity + "]");
                                DirectModule.DefinedAmmoTypes.Add(ammoToAdd);
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        Log.WriteLine("Error Loading Mission Ammo Settings [" + exception + "]");
                    }

                    try
                    {
                        MissionBoosterTypes = new HashSet<long>();
                        XElement missionBoostersToInjectXml = missionXml.Root.Element("missionBoosterTypes") ?? missionXml.Root.Element("boosterTypes");

                        if (missionBoostersToInjectXml != null)
                            foreach (XElement xmlBoosterToInject in missionBoostersToInjectXml.Elements("boosterType"))
                                if (xmlBoosterToInject.Value != "0")
                                {
                                    long booster = int.Parse(xmlBoosterToInject.Value);
                                    DirectInvType boosterInvType = ESCache.Instance.DirectEve.GetInvType(int.Parse(xmlBoosterToInject.Value));
                                    Log.WriteLine("Adding booster [" + boosterInvType.TypeName + "] to the list of boosters that will attempt to be injected during arm.");
                                    MissionBoosterTypes.Add(booster);
                                }
                    }
                    catch (Exception exception)
                    {
                        Log.WriteLine("Error Loading Booster Settings [" + exception + "]");
                    }

                    if (MissionSpecificMissionFitting(myMission) != null)
                        Log.WriteLine("MissionSettings.MissionSpecificFitting.Ship is [" + MissionSpecificMissionFitting(myMission).ShipName.ToLower() + "]");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Error in mission (not pocket) specific XML tags [" + myMission.Name + "], " + ex);
            }
            finally
            {
                missionXml = null;
            }
        }

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            //
            // Agent Standings and Mission Settings
            //
            try
            {
                Log.WriteLine("LoadSettings: MissionSettings");
                MinAgentGreyListStandings = (float?)CharacterSettingsXml.Element("minAgentGreyListStandings") ??
                                            (float?)CommonSettingsXml.Element("minAgentGreyListStandings") ?? (float)0.0;
                Log.WriteLine("LoadSettings: MissionSettings: MinAgentGreyListStandings [" + MinAgentGreyListStandings + "]");
                string relativeMissionsPath = (string)CharacterSettingsXml.Element("missionsPath") ??
                                              (string)CommonSettingsXml.Element("missionsPath") ?? "Caldari L4";
                Log.WriteLine("LoadSettings: MissionSettings: relativeMissionsPath [" + relativeMissionsPath + "]");
                MissionsPath = Path.Combine(Settings.Instance.Path, "QuestorMissions", relativeMissionsPath);
                Log.WriteLine("MissionsPath is: [" + MissionsPath + "]");

                RequireMissionXML = (bool?)CharacterSettingsXml.Element("requireMissionXML") ??
                                    (bool?)CommonSettingsXml.Element("requireMissionXML") ?? false;
                Log.WriteLine("LoadSettings: MissionSettings: RequireMissionXML [" + RequireMissionXML + "]");
                DeclineMissionsWithTooManyMissionCompletionErrors =
                    (bool?)CharacterSettingsXml.Element("DeclineMissionsWithTooManyMissionCompletionErrors") ??
                    (bool?)CommonSettingsXml.Element("DeclineMissionsWithTooManyMissionCompletionErrors") ?? false;
                Log.WriteLine("LoadSettings: MissionSettings: DeclineMissionsWithTooManyMissionCompletionErrors [" + DeclineMissionsWithTooManyMissionCompletionErrors + "]");
                AllowNonStorylineCourierMissionsInLowSec = (bool?)CharacterSettingsXml.Element("LowSecMissions") ??
                                                           (bool?)CommonSettingsXml.Element("LowSecMissions") ?? false;
                Log.WriteLine("LoadSettings: MissionSettings: AllowNonStorylineCourierMissionsInLowSec [" + AllowNonStorylineCourierMissionsInLowSec + "]");
                MaterialsForWarOreID = (int?)CharacterSettingsXml.Element("MaterialsForWarOreID") ??
                                       (int?)CommonSettingsXml.Element("MaterialsForWarOreID") ?? 20;
                Log.WriteLine("LoadSettings: MissionSettings: MaterialsForWarOreID [" + MaterialsForWarOreID + "]");
                MaterialsForWarOreQty = (int?)CharacterSettingsXml.Element("MaterialsForWarOreQty") ??
                                        (int?)CommonSettingsXml.Element("MaterialsForWarOreQty") ?? 8000;
                Log.WriteLine("LoadSettings: MissionSettings: MaterialsForWarOreQty [" + MaterialsForWarOreQty + "]");
                AllowRemovingNoCompatibleStorylines = (bool?)CharacterSettingsXml.Element("AllowRemovingNoCompatibleStorylines") ??
                                                      (bool?)CommonSettingsXml.Element("AllowRemovingNoCompatibleStorylines") ?? true;
                Log.WriteLine("LoadSettings: MissionSettings: AllowRemovingNoCompatibleStorylines [" + AllowRemovingNoCompatibleStorylines + "]");
                DefaultDamageType =
                    (DamageType)
                    Enum.Parse(typeof(DamageType),
                        (string)CharacterSettingsXml.Element("defaultDamageType") ?? (string)CommonSettingsXml.Element("defaultDamageType") ?? "Explosive",
                        true);
                //
                // Loading Mission Blacklists/GreyLists
                //
                try
                {
                    LoadMissionBlackList(CharacterSettingsXml, CommonSettingsXml);
                    LoadMissionGreyList(CharacterSettingsXml, CommonSettingsXml);
                    LoadFactionBlacklist(CharacterSettingsXml, CommonSettingsXml);
                    if (Settings.Instance.CharacterMode == "Courier")
                        LoadDistributionAgentsAllowedCorporations(CharacterSettingsXml, CommonSettingsXml);
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Mission Blacklists/GreyLists [" + exception + "]");
                }

                try
                {
                    if (Settings.Instance.CharacterMode == "Courier")
                        LoadDistributionAgentsAllowedCorporations(CharacterSettingsXml, CommonSettingsXml);
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading DistributionAgentsAllowedCorporations [" + exception + "]");
                }

                //
                // List of Agents we should use
                //
                try
                {
                    //if (Settings.Instance.CharacterMode.ToLower() == "Combat Missions".ToLower())
                    //{
                    ListOfAgents = new List<AgentsList>();
                    XElement agentList = CharacterSettingsXml.Element("agentsList") ?? CommonSettingsXml.Element("agentsList");

                    if (agentList != null)
                        if (agentList.HasElements)
                            foreach (XElement agent in agentList.Elements("agentList"))
                            {
                                Log.WriteLine("Add agent [" + agent + "]");
                                ListOfAgents.Add(new AgentsList(agent));
                            }
                        else
                            Log.WriteLine("agentList exists in your characters config but no agents were listed.");
                    else
                        Log.WriteLine("Error! No Agents List specified.");
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Agent Settings [" + exception + "]");
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Error Loading Agent Standings and Mission Settings: Exception [" + exception + "]");
            }
        }

        public static long? M3NeededForCargo(DirectAgent myAgent)
        {
            if (myAgent.Window == null) return null;

            Regex m3Regex = new Regex(@"([0-9]+)((\.([0-9]+))*) m", RegexOptions.Compiled);
            int m3 = 0;
            foreach (Match itemMatch in m3Regex.Matches(myAgent.Window.Objective))
            {
                string thousandsSeperator = ",";
                int.TryParse(Regex.Match(itemMatch.Value.Replace(thousandsSeperator, ""), @"\d+").Value, out m3);
            }

            return m3;
        }

        public static void ResetInStationSettingsWhenExitingStation()
        {
            MissionNameforLogging = "none";
            if (MyMission != null)
                MissionNameforLogging = MyMission.Name;
        }

        public static bool ThisMissionIsNotWorthSalvaging(DirectAgentMission myMission)
        {
            if (myMission.Name != null)
            {
                if (myMission.Name.ToLower().Contains("Attack of the Drones".ToLower()))
                {
                    Log.WriteLine("Do not salvage a drones mission as they are crap now");
                    return true;
                }

                if (myMission.Name.ToLower().Contains("Infiltrated Outposts".ToLower()))
                {
                    Log.WriteLine("Do not salvage a drones mission as they are crap now");
                    return true;
                }

                if (myMission.Name.ToLower().Contains("Rogue Drone Harassment".ToLower()))
                {
                    Log.WriteLine("Do not salvage a drones mission as they are crap now");
                    return true;
                }

                return false;
            }

            return false;
        }

        private static MissionFitting LookForFitting(string lookForFittingNamed)
        {
            if (DebugConfig.DebugFittingMgr)
                Log.WriteLine("MissionSpecificMissionFitting: looking for a (filtered) fitting matching [" + lookForFittingNamed.ToLower() + "]");

            if (ListOfMissionFittings.Any(i => Log.FilterPath(i.MissionName.ToLower()) == lookForFittingNamed.ToLower()))
            {
                _missionSpecificMissionFitting = ListOfMissionFittings.FirstOrDefault(i => Log.FilterPath(i.MissionName.ToLower()) == lookForFittingNamed.ToLower());
                if (_missionSpecificMissionFitting != null)
                {
                    Log.WriteLine("MissionSpecificMissionFitting [" + _missionSpecificMissionFitting.ShipName.ToLower() + "] MissionName [" + _missionSpecificMissionFitting.MissionName.ToLower() + "] FittingName [" + _missionSpecificMissionFitting.FittingName.ToLower() + "]");
                    return _missionSpecificMissionFitting;
                }

                return null;
            }

            return null;
        }

        #endregion Methods
    }
}