﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;
using EVESharpCore.Logging;
using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    public class DirectCharacter : DirectObject
    {
        #region Constructors

        internal DirectCharacter(DirectEve directEve) : base(directEve)
        {
        }

        #endregion Constructors

        #region Properties

        public long AllianceId { get; internal set; }
        public long CharacterId { get; internal set; }
        public long CorporationId { get; internal set; }
        public string Name => DirectEve.GetOwner(CharacterId).Name;
        public long WarFactionId { get; internal set; }
        public bool IsInFleetWithMe
        {
            get
            {
                if (DirectEve.Session.InFleet)
                {
                    foreach (DirectFleetMember FleetMember in DirectEve.GetFleetMembers)
                    {
                        if (FleetMember.CharacterId == CharacterId)
                            return true;
                    }

                    return false;
                }

                return false;
            }
        }

        #endregion Properties

        
        public bool InviteToFleet()
        {
            if (CorporationId != DirectEve.Session.CorporationId)
                return false;

            return false; //Does not work - needs debugging
            PyObject pyInviteToFleet = null;
            if (DirectEve.Session.FleetId == null)
            {
                pyInviteToFleet = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("FormFleetWith");
            }
            else
            {
                pyInviteToFleet = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("InvitePilotToFleet");
            }

            if (pyInviteToFleet == null || !pyInviteToFleet.IsValid)
            {
                Log.WriteLine("InviteToFleet: if (pyInviteToFleet == null || !pyInviteToFleet.IsValid)");
                return false;
            }

            return DirectEve.ThreadedCall(pyInviteToFleet, CharacterId);
        }
    }
}