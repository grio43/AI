﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 21.06.2014
 * Time: 17:20
 *
 * ---------------------------------------
 */

using HookManager.Win32Hooks;
using SharedComponents.EVE;
using SharedComponents.Utility;
using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace HookManager
{
    public static class StringExtensions
    {
        #region Methods

        public static string Replace(this string originalString, string oldValue, string newValue, StringComparison comparisonType)
        {
            int startIndex = 0;
            while (true)
            {
                startIndex = originalString.IndexOf(oldValue, startIndex, comparisonType);
                if (startIndex == -1)
                    break;

                originalString = originalString.Substring(0, startIndex) + newValue + originalString.Substring(startIndex + oldValue.Length);

                startIndex += newValue.Length;
            }

            return originalString;
        }

        #endregion Methods
    }

    /// <summary>
    ///     Description of Enviroment.
    /// </summary>
    public class EnvVars
    {
        #region Methods

        public static void PrintEnvVars()
        {
            foreach (DictionaryEntry env in Environment.GetEnvironmentVariables()) HookManagerImpl.Log(env.Key + " " + env.Value);
        }

        public static void SetEnvironment(HWSettings settings)
        {
            IntPtr myUsernamePointer = getenv("USERNAME");
            string myUsername = Marshal.PtrToStringAnsi(myUsernamePointer);

            Util.CheckCreateDirectorys(settings.WindowsUserLogin);

            _putenv("COMPUTERNAME=" + settings.Computername.ToUpper());
            _putenv("USERDOMAIN=" + settings.Computername.ToUpper());
            _putenv("USERDOMAIN_ROAMINGPROFILE=" + settings.Computername.ToUpper());
            _putenv("USERNAME=" + settings.WindowsUserLogin);
            _putenv(@"TMP=C:\Users\" + settings.WindowsUserLogin + @"\AppData\Local\Temp");
            _putenv("VISUALSTUDIODIR=");

            if (settings.ProcessorIdent != null && settings.ProcessorIdent != null && settings.ProcessorCoreAmount != null && settings.ProcessorLevel != null)
            {
                _putenv("PROCESSOR_IDENTIFIER=" + settings.ProcessorIdent);
                _putenv("PROCESSOR_REVISION=" + settings.ProcessorRev);
                _putenv("NUMBER_OF_PROCESSORS=" + settings.ProcessorCoreAmount);
                _putenv("PROCESSOR_LEVEL=" + settings.ProcessorLevel);
            }

            _putenv(@"USERPROFILE=C:\Users\" + settings.WindowsUserLogin);
            _putenv(@"HOMEPATH=C:\Users\" + settings.WindowsUserLogin);
            _putenv(@"LOCALAPPDATA=C:\Users\" + settings.WindowsUserLogin + @"\AppData\Local");
            _putenv(@"TEMP=C:\Users\" + settings.WindowsUserLogin + @"\AppData\Local\Temp");
            _putenv(@"APPDATA=C:\Users\" + settings.WindowsUserLogin + @"\AppData\Roaming");

            IntPtr pathPointer = getenv("PATH");
            string path = Marshal.PtrToStringAnsi(pathPointer);
            path = path.Replace(myUsername, settings.WindowsUserLogin, StringComparison.InvariantCultureIgnoreCase);
            _putenv("PATH=" + path);
        }

        [DllImport("msvcr100.dll", SetLastError = true)]
        private static extern bool _putenv(string lpName);

        [DllImport("msvcr100.dll", SetLastError = true)]
        private static extern IntPtr getenv(string lpName);

        #endregion Methods
    }
}