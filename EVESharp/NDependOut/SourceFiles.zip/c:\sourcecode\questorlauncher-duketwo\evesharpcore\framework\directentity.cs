﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using EVESharpCore.Framework.Events;
using EVESharpCore.Lookup;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.Events;
using SC::SharedComponents.Py;
using SC::SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public partial class DirectEntity : DirectInvType
    {

        #region Fields

        private static int? _prevKeepAtRangeDist;

        private static int? _prevOrbitDist;

        private readonly PyObject _ballpark;

        private readonly PyObject _slimItem;

        //
        // see: http://games.chruker.dk/eve_online/item.php?type_id=11900&debug=1
        //
        private int? _allianceId;

        private double? _angularVelocity;

        private double? _armorPct;

        private List<DamageType> _bestDamageTypes;

        private int? _charId;

        private int? _corpId;

        private double? _currentrmor;

        private double? _currentShield;

        private double? _currentStructure;

        private double? _distance;

        private double? _emEhp;

        private double? _entityArmorDelayChanceLarge;

        private double? _entityArmorRepairAmount;

        private double? _entityArmorRepairDuration;

        private double? _entityAttackRange;

        private int? _entityMissileTypeId;

        private double? _entityShieldBoostAmount;

        private double? _entityShieldBoostDelayChance;

        private double? _entityShieldBoostDuration;

        private double? _entityShieldRechargeRate;

        private double? _expEhp;

        private double? _explosiveDamage;

        private long? _followId;

        private string _givenName;

        private bool? _hasExploded;

        private bool? _hasReleased;

        private bool? _isCloaked;

        private bool? _isDockable;

        private bool? _isEmpty;

        private double? _kinEhp;

        private int? _mode;

        private string _name;

        private double? _npcBehaviorEnergyNeutralizerDischarge;

        //private double? _npcArmorUniformity;
        private double? _npcDamageMultiplier;

        private double? _npcEmMissileDamage;

        private double? _npcEmMissileDps;

        private double? _npcEmTurretDamage;

        private double? _npcEmTurretDps;

        private double? _npcExplosiveDps;

        private double? _npcExplosiveMissileDamage;

        private double? _npcExplosiveMissileDps;

        private double? _npcKineticMissileDamage;

        private double? _npcKineticMissileDps;

        private double? _npcKineticTurretDamage;

        private double? _npcKineticTurretDps;

        private DirectItem _npcMissileAmmoType;

        private double? _npcMissileDamageMultiplier;

        private double? _npcMissileEntityAoeCloudSizeMultiplier;

        //private double? _npcMissileDps;
        private double? _npcMissileEntityAoeVelocityMultiplier;

        private double? _npcMissileEntityFlightTime;

        private double? _npcMissileEntityFlightTimeMultiplier;

        private double? _npcMissileEntityVelocity;

        private double? _npcMissileEntityVelocityMultiplier;

        private double? _npcMissileRateOfFire;

        private double? _npcRateOfFire;

        private double? _npcRemoteArmorRepairChance;

        private double? _npcRemoteShieldRepairChance;

        private double? _npcShieldRechargeRate;

        private double? _npcShieldUniformity;

        //private double? _npcShieldResistanceThermal;
        private double? _npcThermalMissileDamage;

        //private double? _npcShieldResistanceKinetic;
        private double? _npcThermalMissileDps;

        //private double? _npcShieldResistanceExplosive;
        private double? _npcThermalTurretDamage;

        //private double? _npcShieldResistanceEm;
        private double? _npcThermalTurretDps;

        private double? _npcTurretDps;

        private int? _ownerId;

        private double? _radius;

        private double? _rawEhp;

        private double? _shieldPct;

        private double? _signatureRadius;

        private double? _structurePct;

        private double? _structureUniformity;

        private double? _trackingSpeed;

        private double? _transversalVelocity;

        private double? _triglavianDamage;

        private double? _triglavianDps;

        private double? _trmEhp;

        private double? _velocity;

        private double? _vx;

        private double? _vy;

        private double? _vz;

        private double? _warpScrambleChance;

        private double? _wormholeAge;

        private double? _wormholeSize;

        private double? _x;

        private double? _y;

        private double? _z;

        #endregion Fields

        #region Constructors

        internal DirectEntity(DirectEve directEve, PyObject ballpark, PyObject ball, PyObject slimItem, long id)
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            : base(directEve)
        {
            _ballpark = ballpark;
            Ball = ball;
            _slimItem = slimItem;

            Id = id;
            TypeId = (int)slimItem.Attribute("typeID");

            Attacks = new List<string>();
            ElectronicWarfare = new List<string>();
        }

        #endregion Constructors

        #region Properties

        public int? AllianceId
        {
            get
            {
                if (!_allianceId.HasValue)
                    _allianceId = (int)Ball.Attribute("allianceID");

                return _allianceId.Value;
            }
        }

        public string AllianceTicker => DirectEve.GetOwner(AllianceId ?? -1).shortName;

        public double AngularVelocity
        {
            get
            {
                if (IsValid)
                {
                    if (_angularVelocity == null)
                        _angularVelocity = TransversalVelocity / Math.Max(1, Distance);

                    return _angularVelocity.Value;
                }

                return 0;
            }
        }

        public double ArmorPct
        {
            get
            {
                if (IsValid)
                {
                    if (!_armorPct.HasValue)
                        GetDamageState();

                    return _armorPct ?? 0;
                }

                return 0;
            }
        }

        public List<string> Attacks { get; }
        public PyObject Ball { get; }

        public List<DamageType> BestDamageTypes
        {
            get
            {
                if (IsValid)
                {
                    if (_bestDamageTypes == null)
                    {
                        try
                        {
                            _bestDamageTypes = new List<DamageType>();
                            ulong emEhp = double.IsInfinity(EmEhp.Value) || double.IsNaN(EmEhp.Value) ? ulong.MaxValue : (ulong)EmEhp;
                            ulong expEhp = double.IsInfinity(ExpEhp.Value) || double.IsNaN(ExpEhp.Value) ? ulong.MaxValue : (ulong)ExpEhp;
                            ulong kinEhp = double.IsInfinity(KinEHP.Value) || double.IsNaN(KinEHP.Value) ? ulong.MaxValue : (ulong)KinEHP;
                            ulong trmEhp = double.IsInfinity(TrmEHP.Value) || double.IsNaN(TrmEHP.Value) ? ulong.MaxValue : (ulong)TrmEHP;

                            Dictionary<DamageType, ulong> dict = new Dictionary<DamageType, ulong>();
                            dict.Add(DamageType.EM, emEhp);
                            dict.Add(DamageType.Explosive, expEhp);
                            dict.Add(DamageType.Kinetic, kinEhp);
                            dict.Add(DamageType.Thermal, trmEhp);
                            //_bestDamageType = dict.FirstOrDefault(e => e.Value == Math.Min(Math.Min(Math.Min(emEHP, expEHP), kinEHP), trmEHP)).Key;
                            _bestDamageTypes = dict.OrderBy(e => e.Value).Select(e => e.Key).ToList();
                        }
                        catch (Exception ex)
                        {
                            Logging.Log.WriteLine("Exception [" + ex + "] Entity [" + Name + "] Defaulting to EM as bestdamagetype (wrong?)");
                            Dictionary<DamageType, ulong> dict = new Dictionary<DamageType, ulong>();
                            dict.Add(DamageType.EM, 1000);
                            _bestDamageTypes = dict.OrderBy(e => e.Value).Select(e => e.Key).ToList();
                        }
                    }

                    return _bestDamageTypes;
                }

                return new List<DamageType>();
            }
        }

        public int CharId
        {
            get
            {
                if (IsNpc) return 0;

                if (!_charId.HasValue)
                    _charId = (int)_slimItem.Attribute("charID");

                return _charId.Value;
            }
        }

        public Vector3 Coord => new Vector3(X, Y, Z);

        public int CorpId
        {
            get
            {
                if (IsNpc) return 0;

                if (!_corpId.HasValue)
                    _corpId = (int)_slimItem.Attribute("corpID");

                return _corpId.Value;
            }
        }

        public string CorpTicker => DirectEve.GetOwner(CorpId).shortName;

        public double? CurrentArmor
        {
            get
            {
                if (IsValid)
                {
                    if (!_currentrmor.HasValue)
                        _currentrmor = TotalArmor * ArmorPct;
                    return _currentrmor ?? 0;
                }

                return 0;
            }
        }

        public double? CurrentShield
        {
            get
            {
                if (IsValid)
                {
                    if (!_currentShield.HasValue)
                        _currentShield = TotalShield * ShieldPct;
                    return _currentShield ?? 0;
                }

                return 0;
            }
        }

        public double? CurrentStructure
        {
            get
            {
                if (IsValid)
                {
                    if (!_currentStructure.HasValue)
                        _currentStructure = TotalStructure * _structurePct;
                    return _currentStructure ?? 0;
                }

                return 0;
            }
        }

        public double Distance
        {
            get
            {
                if (!IsValid)
                {
                    Logging.Log.WriteLine("DirectEntity [" + Name + "] if (!IsValid) Distance will be 0");
                    return 0;
                }

                if (!_distance.HasValue)
                    _distance = (double)Ball.Attribute("surfaceDist");

                if (!_distance.HasValue)
                {
                    if (DirectEve.ActiveShip != null)
                    {
                        double deltaX = X - DirectEve.ActiveShip.Entity.X;
                        double deltaY = Y - DirectEve.ActiveShip.Entity.Y;
                        double deltaZ = Z - DirectEve.ActiveShip.Entity.Z;

                        return Math.Sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
                    }

                    Logging.Log.WriteLine("DirectEntity [" + Name + "] if (DirectEve.ActiveShip == null) Distance will be 0");
                    return 0;
                }

                return _distance.Value;
            }
        }

        public List<string> ElectronicWarfare { get; }

        public double? EmEhp => _emEhp ?? (_emEhp = 1 / (1 - ShieldResistanceEM) * CurrentShield + 1 / (1 - ArmorResistanceEm) * CurrentArmor + CurrentStructure);

        public bool EntitiesMissilesAreInEffectiveRangeOfMe
        {
            get
            {
                try
                {
                    if (IsValid)
                    {
                        if (!IsNpc) return false;

                        if (NpcMissileEntityFlightTimeMultiplier * NpcMissileEntityFlightTime + NpcMissileEntityVelocityMultiplier * NpcMissileEntityVelocity > Distance)
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception)
                {
                    //Log.WriteLine("Exception [" + ex + "]");
                    return true;
                }
            }
        }

        public bool EntitiesTurretsAreInEffectiveRangeOfMe
        {
            get
            {
                if (IsValid)
                {
                    if (!IsNpc) return false;

                    if (OptimalRange + Falloff >= Distance)
                        return true;

                    return false;
                }

                return false;
            }
        }

        public double? EntityArmorRepairAmount
        {
            get
            {
                if (IsValid)
                {
                    if (!IsNpc) return 0;

                    if (_entityArmorRepairAmount == null)
                        _entityArmorRepairAmount = (int)Ball.Attribute("entityArmorRepairAmount");

                    return _entityArmorRepairAmount.Value;
                }

                return 0;
            }
        }

        public double? EntityArmorRepairDelayChanceLarge
        {
            get
            {
                if (IsValid)
                {
                    if (!IsNpc) return 0;

                    if (_entityArmorRepairAmount == null)
                        _entityArmorRepairAmount = (int)Ball.Attribute("entityArmorRepairAmount");

                    if (!IsNpc) return 0;

                    if (_entityArmorDelayChanceLarge == null)
                        _entityArmorDelayChanceLarge = (int)Ball.Attribute("entityArmorRepairDelayChanceLarge");
                    return _entityArmorDelayChanceLarge.Value;
                }

                return 0;
            }
        }

        public double? EntityArmorRepairDuration
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_entityArmorRepairDuration == null)
                    _entityArmorRepairDuration = (int)Ball.Attribute("entityArmorRepairDuration");
                return _entityArmorRepairDuration.Value;
            }
        }

        public double? EntityAttackRange
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_entityAttackRange == null)
                    _entityAttackRange = (int)Ball.Attribute("entityAttackRange");

                return _entityAttackRange.Value;
            }
        }

        //
        // ToDo: fix me to calc damage types (kinetic, therm, em, exp) and thus dps of each type, etc.
        // for example for Zor: http://games.chruker.dk/eve_online/item.php?type_id=12256&debug=1
        //
        public int? EntityMissileTypeId
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_entityMissileTypeId == null)
                    _entityMissileTypeId = (int)Ball.Attribute("entityMissileTypeID");
                return _entityMissileTypeId.Value;
            }
        }

        public double? EntityShieldBoostAmount
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_entityShieldBoostAmount == null)
                    _entityShieldBoostAmount = (float)Ball.Attribute("entityShieldBoostAmount");

                return _entityShieldBoostAmount.Value;
            }
        }

        public double? EntityShieldBoostDelayChanceLarge
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_entityShieldBoostDelayChance == null)
                    _entityShieldBoostDelayChance = (int)Ball.Attribute("entityShieldBoostDelayChanceLarge");

                return _entityShieldBoostDelayChance.Value;
            }
        }

        public double? EntityShieldBoostDuration
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_entityShieldBoostDuration == null)
                    _entityShieldBoostDuration = (int)Ball.Attribute("entityShieldBoostDuration");

                return _entityShieldBoostDuration.Value;
            }
        }

        public double? EntityShieldRechargeRate
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_entityShieldRechargeRate == null)
                    _entityShieldRechargeRate = (int)Ball.Attribute("entityShieldRechargeRate");

                return _entityShieldRechargeRate.Value;
            }
        }

        public double? EntitySignatureRadius
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_signatureRadius == null)
                    _signatureRadius = (float)Ball.Attribute("signatureRadius");

                if (_signatureRadius != null && !double.IsNaN(_signatureRadius.Value) && !double.IsInfinity(_signatureRadius.Value))
                    return _signatureRadius.Value;

                return 0;
            }
        }

        public double? ExpEhp => _expEhp ?? (_expEhp = 1 / (1 - ShieldResistanceExplosive) * CurrentShield + 1 / (1 - ArmorResistanceExplosive) * CurrentArmor + CurrentStructure);

        public double? ExplosiveRawTurretDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_explosiveDamage == null)
                {
                    _explosiveDamage = (float)Ball.Attribute("explosiveDamage");
                    if (_explosiveDamage.HasValue)
                        return _explosiveDamage.Value;

                    return 0;
                }

                return _explosiveDamage.Value;
            }
        }

        public long FollowId
        {
            get
            {
                if (!IsValid) return 0;
                if (!_followId.HasValue)
                    _followId = (long)Ball.Attribute("followId");

                return _followId.Value;
            }
        }

        public string GivenName
        {
            get
            {
                if (_givenName == null)
                    _givenName = DirectEve.GetLocationName(Id);

                return _givenName;
            }
        }

        public bool HasExploded
        {
            get
            {
                if (!_hasExploded.HasValue)
                    _hasExploded = Ball.Attribute("exploded").ToBool();

                return _hasExploded.Value;
            }
        }

        public bool HasReleased
        {
            get
            {
                if (!_hasReleased.HasValue)
                    _hasReleased = Ball.Attribute("released").ToBool();

                return _hasReleased.Value;
            }
        }

        public long Id { get; internal set; }

        public bool InMyFleet
        {
            get
            {
                if (DirectEve.Session.InFleet)
                {
                    foreach (DirectFleetMember FleetMember in DirectEve.GetFleetMembers)
                    {
                        if (FleetMember.Name == Name)
                            return true;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool IsActiveTarget { get; internal set; }

        public bool IsAligning => Mode == 0;

        public bool IsAnchorableObject
        {
            get
            {
                if (GroupId == (int)Group.MobileWarpDisruptor) return true;
                return false;
            }
        }

        public bool IsAnchorableStructure
        {
            get
            {
                if (GroupId == (int)Group.POSControlTower) return true;
                return false;
            }
        }

        public bool IsApproachedOrKeptAtRangeByActiveShip => DirectEve.ActiveShip != null &&
                                                                             DirectEve.ActiveShip.Entity != null &&
                                                             DirectEve.ActiveShip.Entity.FollowId == Id
                                                             && DirectEve.ActiveShip.Entity.IsApproachingOrKeptAtRange
                                                             && DirectEve.GetEntityById(Id) != null;

        public bool IsApproachingOrKeptAtRange => Mode == 1;

        public bool IsAttacking { get; internal set; }

        public bool IsCloaked
        {
            get
            {
                if (!IsValid) return false;
                if (!_isCloaked.HasValue)
                    _isCloaked = (int)Ball.Attribute("isCloaked") != 0;

                return _isCloaked.Value;
            }
        }

        public bool IsDockable
        {
            get
            {
                try
                {
                    //
                    // we can dock with all stations now right? Any 0.0 situation would be a citadel iirc...
                    //
                    if (GroupId == (int)Group.Station)
                        return true;

                    if (GroupId == (int)Group.Citadel)
                    {
                        if (_isDockable == null)
                        {
                            bool? tempIsDockable = null;
                            try
                            {
                                tempIsDockable = (bool)DirectEve.GetLocalSvc("structureProximityTracker").Call("IsStructureDockable", Id);
                            }
                            catch (Exception ex)
                            {
                                Logging.Log.WriteLine("Exception [" + ex + "]");
                                return false;
                            }

                            _isDockable = tempIsDockable;
                            return _isDockable ?? false;
                        }

                        return _isDockable ?? false;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    Logging.Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        public bool IsEmpty
        {
            get
            {
                if (!_isEmpty.HasValue)
                    _isEmpty = (bool?)_slimItem.Attribute("isEmpty") ?? true;

                return _isEmpty.Value;
            }
        }

        public bool IsItWorthTheTimeToChangeToBestAmmo
        {
            get
            {
                //
                // reload time,
                // Current DPS with resists,
                // Total Damage Lost to reload,
                // New DPS with resists,
                // Total time it would take to make up for lost DPS
                //

                return false;
            }
        }

        public bool IsJammingMe { get; private set; }

        public bool IsKeepingAtRange => IsApproachingOrKeptAtRange;

        public bool IsNeutralizingMe { get; private set; }

        public bool IsNpc => (bool?)PySharp.Import("util").Call("IsNPC", OwnerId) ?? false;

        public bool IsOrbitedByActiveShip => DirectEve.ActiveShip.Entity.FollowId == Id
                                             && DirectEve.ActiveShip.Entity.IsOrbiting
                                             && DirectEve.GetEntityById(Id) != null;

        public bool IsOrbiting => Mode == 4;

        public bool IsPlayer
        {
            get
            {
                if (DirectEve.Session.IsAbyssalDeadspace) //Can we detect the proving grounds by the gates available?
                    return false;

                if (GroupId == (int)Group.AbyssalSpaceshipEntities)
                    return false;

                if (GroupId == (int)Group.AbyssalDeadspaceDroneEntities)
                    return false;

                if (GroupId == (int)Group.InvadingPrecursorEntities)
                    return false;

                if (CharId > 0)
                    return true;

                return false;
            }
        }

        public bool IsPotentialCombatTarget
        {
            get
            {
                if (CategoryId == (int)CategoryID.Entity &&
                    (!IsSentry || IsSentry && IsEwarTarget) &&
                    (IsNpcByGroupID || IsAttacking) &&
                    !IsContainer &&
                    !IsFactionWarfareNPC &&
                    !IsEntityIShouldLeaveAlone &&
                    !IsBadIdea &&
                    (!IsPlayer || IsPlayer && IsAttacking) &&
                    !IsMiscJunk &&
                    !IsLargeCollidable)
                {
                    return true;
                }

                return false;
            }
        }

        public bool IsSensorDampeningMe { get; private set; }

        public bool IsTarget { get; internal set; }

        public bool IsTargetedBy { get; internal set; }

        public bool IsTargeting { get; internal set; }

        public bool IsTargetPaintingMe { get; private set; }

        public bool IsTrackingDisruptingMe { get; private set; }

        /// <summary>
        ///     Is it a valid entity?
        /// </summary>
        public bool IsValid
        {
            get
            {
                if (!Ball.IsValid)
                {
                    Logging.Log.WriteLine("[" + Name + "][" + Id + "] if (!Ball.IsValid)");
                    return false;
                }

                if (!_slimItem.IsValid)
                {
                    Logging.Log.WriteLine("[" + Name + "][" + Id + "] if (!_slimItem.IsValid)");
                    return false;
                }

                if (Id <= 0)
                {
                    Logging.Log.WriteLine("[" + Name + "][" + Id + "] if (Id <= 0)");
                    return false;
                }

                if (HasReleased)
                {
                    Logging.Log.WriteLine("[" + Name + "][" + Id + "] if (HasReleased)");
                    return false;
                }

                if (HasExploded)
                {
                    Logging.Log.WriteLine("[" + Name + "][" + Id + "] if (HasExploded)");
                    return false;
                }

                if (DirectEve.IsTargetBeingRemoved(Id))
                {
                    //Logging.Log.WriteLine("[" + Name + "][" + Id + "] if (DirectEve.IsTargetBeingRemoved(Id);");
                    return false;
                }

                return true;
            }
        }

        public bool IsWarping => Mode == 3;

        public bool IsWarpScramblingMe { get; private set; }

        public bool IsWebbingMe { get; private set; }

        public double? KinEHP => _kinEhp ?? (_kinEhp = 1 / (1 - ShieldResistanceKinetic) * CurrentShield + 1 / (1 - ArmorResistanceKinetic) * CurrentArmor + CurrentStructure);

        public double? MissileRange
        {
            get
            {
                try
                {
                    if (!IsNpc) return 0;

                    double? tempMissileRange = NpcMissileEntityFlightTimeMultiplier * NpcMissileEntityFlightTime + NpcMissileEntityVelocityMultiplier * NpcMissileEntityVelocity;
                    if (tempMissileRange.HasValue && tempMissileRange.Value > 0)
                        return tempMissileRange;

                    return null;
                }
                catch (Exception)
                {
                    //Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public int Mode
        {
            get
            {
                if (!IsValid) return 0;
                if (!_mode.HasValue)
                    _mode = (int)Ball.Attribute("mode");

                return _mode.Value;
            }
        }

        public string Name
        {
            get
            {
                //if (!IsValid) return string.Empty;

                if (string.IsNullOrEmpty(_name))
                    _name = (string)PySharp.Import("uix").Call("GetSlimItemName", _slimItem);

                return _name;
            }
        }

        public double? NpcDamageMultiplier
        {
            get
            {
                if (!IsValid) return 1;
                if (!IsNpc) return 1;

                if (_npcDamageMultiplier == null)
                    _npcDamageMultiplier = (float)Ball.Attribute("damageMultiplier");

                if (_npcDamageMultiplier.HasValue)
                    return _npcDamageMultiplier;

                return 1;
            }
        }

        public double? NpcEffectiveDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;
                //
                // What about triglavianDPS?
                //
                return NpcEffectiveMissileDps + NpcEffectiveTurretDps;
            }
        }

        public double? NpcEffectiveMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                return NpcEmEffectiveMissileDps + NpcThermalEffectiveMissileDps + NpcKineticEffectiveMissileDps + NpcExplosiveEffectiveMissileDps;
            }
        }

        public double? NpcEffectiveTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                return NpcEmEffectiveTurretDps + NpcThermalEffectiveTurretDps + NpcKineticEffectiveTurretDps + NpcExplosiveEffectiveTurretDps;
            }
        }

        public double? NpcEmEffectiveMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;
                return NpcEmRawMissileDps * DirectEve.ActiveShip.Entity.ShieldResistanceEM;
            }
        }

        public double? NpcEmEffectiveTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;
                return NpcEmRawTurretDps * DirectEve.ActiveShip.Entity.ShieldResistanceEM;
            }
        }

        public double? NpcEmRawMissileDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcEmMissileDamage == null)
                {
                    _npcEmMissileDamage = (int)Ball.Attribute("emDamage");
                    if (_npcEmMissileDamage.HasValue)
                        return _npcEmMissileDamage.Value;

                    return 0;
                }

                return _npcEmMissileDamage;
            }
        }

        public double? NpcEmRawMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcEmMissileDps == null)
                {
                    if (NpcEmRawMissileDamage != null && NpcMissileDamageMultiplier != null && NpcMissileRateOfFire != null)
                    {
                        _npcEmMissileDps = (double)NpcEmRawMissileDamage * (double)NpcMissileDamageMultiplier / (double)NpcMissileRateOfFire;
                        if (_npcEmMissileDps != null && !double.IsNaN(_npcEmMissileDps.Value) && !double.IsInfinity(_npcEmMissileDps.Value))
                            return _npcEmMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _npcEmMissileDps;
            }
        }

        public double? NpcEmRawTurretDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcEmTurretDamage == null)
                {
                    _npcEmTurretDamage = (int)Ball.Attribute("emDamage");

                    if (_npcEmTurretDamage.HasValue)
                        return _npcEmTurretDamage.Value;

                    return 0;
                }

                return _npcEmTurretDamage.Value;
            }
        }

        public double? NpcEmRawTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcEmTurretDps == null)
                {
                    if (NpcEmRawMissileDamage != null && NpcDamageMultiplier != null && NpcRateOfFire != null)
                    {
                        _npcEmTurretDps = (double)NpcEmRawMissileDamage * (double)NpcDamageMultiplier / (double)NpcRateOfFire;
                        return _npcEmTurretDps.Value;
                    }

                    return 0;
                }

                return _npcEmTurretDps;
            }
        }

        public double? NpcExplosiveEffectiveMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;
                return NpcExplosiveRawMissileDps * DirectEve.ActiveShip.Entity.ShieldResistanceExplosive;
            }
        }

        public double? NpcExplosiveEffectiveTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;
                return NpcExplosiveRawTurretDps * DirectEve.ActiveShip.Entity.ShieldResistanceExplosive;
            }
        }

        public double? NpcExplosiveRawMissileDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcExplosiveMissileDamage == null)
                {
                    _npcExplosiveMissileDamage = (double)Ball.Attribute("explosiveDamage");

                    if (_npcExplosiveMissileDamage.HasValue)
                        return _npcExplosiveMissileDamage.Value;

                    return 0;
                }

                return _npcExplosiveMissileDamage;
            }
        }

        public double? NpcExplosiveRawMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcExplosiveMissileDps == null)
                {
                    if (NpcExplosiveRawMissileDamage != null && NpcExplosiveRawMissileDamage != 0 && NpcMissileDamageMultiplier != null && NpcMissileRateOfFire != null)
                    {
                        _npcExplosiveMissileDps = (double)NpcExplosiveRawMissileDamage * (double)NpcMissileDamageMultiplier / (double)NpcMissileRateOfFire;
                        if (_npcExplosiveMissileDps != null && !double.IsNaN(_npcExplosiveMissileDps.Value) && !double.IsInfinity(_npcExplosiveMissileDps.Value))
                            return _npcExplosiveMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _npcExplosiveMissileDps;
            }
        }

        public double? NpcExplosiveRawTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcExplosiveDps == null)
                {
                    if (ExplosiveRawTurretDamage != null && NpcDamageMultiplier != null && NpcRateOfFire != null)
                    {
                        _npcExplosiveDps = (double)ExplosiveRawTurretDamage * (double)NpcDamageMultiplier / (double)NpcRateOfFire;
                        if (_npcExplosiveDps != null && !double.IsNaN(_npcExplosiveDps.Value) && !double.IsInfinity(_npcExplosiveDps.Value))
                            return _npcExplosiveDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _npcExplosiveDps;
            }
        }

        public bool NpcHasNeutralizers
        {
            get
            {
                if (!IsValid) return false;
                if (!IsNpc) return false;

                if (!_npcBehaviorEnergyNeutralizerDischarge.HasValue)
                    _npcBehaviorEnergyNeutralizerDischarge = (double)Ball.Attribute("behaviorEnergyNeutralizerDischarge");

                if (_npcBehaviorEnergyNeutralizerDischarge.Value > 0)
                    return true;

                return false;
            }
        }

        public double? NpcKineticEffectiveMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;
                return NpcKineticRawMissileDps * DirectEve.ActiveShip.Entity.ShieldResistanceKinetic;
            }
        }

        public double? NpcKineticEffectiveTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;
                return NpcKineticRawTurretDps * DirectEve.ActiveShip.Entity.ShieldResistanceKinetic;
            }
        }

        public double? NpcKineticRawMissileDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcKineticMissileDamage == null)
                {
                    _npcKineticMissileDamage = (double)Ball.Attribute("kineticDamage");
                    if (_npcKineticMissileDamage.HasValue)
                        return _npcKineticMissileDamage.Value;

                    return 0;
                }

                return _npcKineticMissileDamage.Value;
            }
        }

        public double? NpcKineticRawMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcKineticMissileDps == null)
                {
                    if (NpcKineticRawMissileDamage != null && NpcKineticRawMissileDamage != 0 && NpcMissileDamageMultiplier != null && NpcMissileRateOfFire != null)
                    {
                        _npcKineticMissileDps = (double)NpcKineticRawMissileDamage * (double)NpcMissileDamageMultiplier / (double)NpcMissileRateOfFire;
                        if (_npcKineticMissileDps != null && !double.IsNaN(_npcKineticMissileDps.Value) && !double.IsInfinity(_npcKineticMissileDps.Value))
                            return _npcKineticMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _npcKineticMissileDps;
            }
        }

        public double? NpcKineticRawTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcKineticTurretDps == null)
                {
                    if (NpcKineticTurretDamage != null && NpcDamageMultiplier != null && NpcRateOfFire != null)
                    {
                        _npcKineticTurretDps = (double)NpcKineticTurretDamage * (double)NpcDamageMultiplier / (double)NpcRateOfFire;
                        if (_npcKineticTurretDps != null && !double.IsNaN(_npcKineticTurretDps.Value) && !double.IsInfinity(_npcKineticTurretDps.Value))
                            return _npcKineticTurretDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _npcKineticTurretDps;
            }
        }

        public double? NpcKineticTurretDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcKineticTurretDamage == null)
                {
                    _npcKineticTurretDamage = (float)Ball.Attribute("kineticDamage");

                    if (_npcKineticTurretDamage.HasValue)
                        return _npcKineticTurretDamage.Value;

                    return 0;
                }

                return _npcKineticTurretDamage.Value;
            }
        }

        public DirectItem NpcMissileAmmoType
        {
            get
            {
                if (_npcMissileAmmoType == null)
                {
                    if (EntityMissileTypeId != null)
                    {
                        _npcMissileAmmoType = new DirectItem(DirectEve);
                        _npcMissileAmmoType.TypeId = (int)EntityMissileTypeId;
                        if (_npcMissileAmmoType.TypeId != 0)
                            return _npcMissileAmmoType;

                        return null;
                    }

                    return null;
                }

                return _npcMissileAmmoType;
            }
        }

        public double? NpcMissileDamageMultiplier
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileDamageMultiplier == null)
                    _npcMissileDamageMultiplier = (float)Ball.Attribute("missileDamageMultiplier");

                return _npcMissileDamageMultiplier.Value;
            }
        }

        public double? NpcMissileEntityAoeCloudSizeMultiplier
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileEntityAoeCloudSizeMultiplier == null)
                    _npcMissileEntityAoeCloudSizeMultiplier = (float)Ball.Attribute("missileEntityAoeCloudSizeMultiplier");

                return _npcMissileEntityAoeCloudSizeMultiplier.Value;
            }
        }

        public double? NpcMissileEntityAoeVelocityMultiplier
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileEntityAoeVelocityMultiplier == null)
                    _npcMissileEntityAoeVelocityMultiplier = (float)Ball.Attribute("missileEntityAoeVelocityMultiplier");

                return _npcMissileEntityAoeVelocityMultiplier.Value;
            }
        }

        public double? NpcMissileEntityFlightTime
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileEntityFlightTime == null)
                {
                    if (NpcMissileAmmoType != null && NpcMissileAmmoType.TypeId != 0)
                    {
                        //this is correct - the explosionDelay attribute is the missiles flight time (can you say wtf?!)
                        _npcMissileEntityFlightTime = NpcMissileAmmoType.Attributes.TryGet<double>("explosionDelay");
                        return _npcMissileEntityFlightTime.Value;
                    }

                    return null;
                }

                return _npcMissileEntityFlightTime.Value;
            }
        }

        public double? NpcMissileEntityFlightTimeMultiplier
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileEntityFlightTimeMultiplier == null)
                    _npcMissileEntityFlightTimeMultiplier = (float)Ball.Attribute("missileEntityFlightTimeMultiplier");

                if (_npcMissileEntityFlightTimeMultiplier != null && !double.IsNaN(_npcMissileEntityFlightTimeMultiplier.Value) && !double.IsInfinity(_npcMissileEntityFlightTimeMultiplier.Value))
                    return _npcMissileEntityFlightTimeMultiplier.Value;

                return 0;
            }
        }

        public double? NpcMissileEntityVelocity
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileEntityVelocity == null)
                    _npcMissileEntityVelocity = NpcMissileAmmoType.Attributes.TryGet<double>("maxVelocity");

                return _npcMissileEntityVelocity.Value;
            }
        }

        public double? NpcMissileEntityVelocityMultiplier
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileEntityVelocityMultiplier == null)
                    _npcMissileEntityVelocityMultiplier = (float)Ball.Attribute("missileEntityVelocityMultiplier");

                return _npcMissileEntityVelocityMultiplier.Value;
            }
        }

        public double? NpcMissileRateOfFire
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcMissileRateOfFire == null)
                    _npcMissileRateOfFire = (float)Ball.Attribute("missileLaunchDuration");

                return _npcMissileRateOfFire.Value;
            }
        }

        public double? NpcRateOfFire
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcRateOfFire == null)
                    _npcRateOfFire = (float)Ball.Attribute("speed");

                return _npcRateOfFire.Value / 1000;
            }
        }

        public double NpcRawTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcTurretDps == null)
                {
                    _npcTurretDps = NpcEmRawTurretDps ?? 0 + NpcExplosiveRawTurretDps ?? 0 + NpcKineticRawTurretDps ?? 0 + NpcThermalRawTurretDps ?? 0;
                    if (_npcTurretDps != null && !double.IsNaN(_npcTurretDps.Value) && !double.IsInfinity(_npcTurretDps.Value))
                        return _npcTurretDps.Value;

                    return 0;
                }

                return (double)_npcTurretDps;
            }
        }

        public double NpcRemoteArmorRepairChance
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (!_npcRemoteArmorRepairChance.HasValue)
                    _npcRemoteArmorRepairChance = (float)Ball.Attribute("npcRemoteArmorRepairChance");

                if (_npcRemoteArmorRepairChance == null)
                    _npcRemoteArmorRepairChance = (float)Ball.Attribute("behaviorRemoteArmorRepairDischarge");

                return _npcRemoteArmorRepairChance.Value;
            }
        }

        public double NpcRemoteShieldRepairChance
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (!_npcRemoteShieldRepairChance.HasValue)
                    _npcRemoteShieldRepairChance = (float)Ball.Attribute("npcRemoteShieldRepairChance");

                if (_npcRemoteShieldRepairChance == null)
                    _npcRemoteShieldRepairChance = (float)Ball.Attribute("behaviorRemoteShieldRepairDischarge");

                return _npcRemoteShieldRepairChance.Value;
            }
        }

        public double? NpcShieldRechargeRate
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcShieldRechargeRate == null)
                    _npcShieldRechargeRate = (float)Ball.Attribute("shieldRechargeRate");

                if (_npcShieldRechargeRate != null && !double.IsNaN(_npcShieldRechargeRate.Value) && !double.IsInfinity(_npcShieldRechargeRate.Value))
                    return _npcShieldRechargeRate.Value;

                return 0;
            }
        }

        public double? NpcShieldUnifirmity
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcShieldUniformity == null)
                    _npcShieldUniformity = (float)Ball.Attribute("shieldUnifirmity");

                if (_npcShieldUniformity != null && !double.IsNaN(_npcShieldUniformity.Value) && !double.IsInfinity(_npcShieldUniformity.Value))
                    return _npcShieldUniformity.Value;

                return 0;
            }
        }

        public double? NpcThermalEffectiveMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                return NpcThermalRawMissileDps * DirectEve.ActiveShip.Entity.ShieldResistanceThermal;
            }
        }

        public double? NpcThermalEffectiveTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                return NpcThermalRawTurretDps * DirectEve.ActiveShip.Entity.ShieldResistanceThermal;
            }
        }

        public double? NpcThermalRawMissileDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcThermalMissileDamage == null)
                {
                    _npcThermalMissileDamage = (float)Ball.Attribute("npcRemoteArmorRepairChance");

                    if (_npcThermalMissileDamage.HasValue)
                        return _npcThermalMissileDamage.Value;

                    return 0;
                }

                return _npcThermalMissileDamage;
            }
        }

        public double? NpcThermalRawMissileDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcThermalMissileDps == null)
                {
                    if (NpcThermalRawMissileDamage != null && NpcThermalRawMissileDamage != 0 && NpcMissileDamageMultiplier != null && NpcMissileRateOfFire != null)
                    {
                        _npcThermalMissileDps = (double)NpcThermalRawMissileDamage * (double)NpcMissileDamageMultiplier / (double)NpcMissileRateOfFire;
                        if (_npcThermalMissileDps != null && !double.IsNaN(_npcThermalMissileDps.Value) && !double.IsInfinity(_npcThermalMissileDps.Value))
                            return _npcThermalMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _npcThermalMissileDps;
            }
        }

        public double? NpcThermalRawTurretDamage
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcThermalTurretDamage == null)
                {
                    _npcThermalTurretDamage = (float)Ball.Attribute("thermalDamage");
                    if (_npcThermalTurretDamage.HasValue)
                        return _npcThermalTurretDamage.Value;

                    return 0;
                }

                return _npcThermalTurretDamage.Value;
            }
        }

        public double? NpcThermalRawTurretDps
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_npcThermalTurretDps == null)
                {
                    if (NpcThermalRawTurretDamage != null && NpcDamageMultiplier != null && NpcRateOfFire != null)
                    {
                        _npcThermalTurretDps = (double)NpcThermalRawTurretDamage * (double)NpcDamageMultiplier / (double)NpcRateOfFire;
                        if (_npcThermalTurretDps != null && !double.IsNaN(_npcThermalTurretDps.Value) && !double.IsInfinity(_npcThermalTurretDps.Value))
                            return _npcThermalTurretDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _npcThermalTurretDps;
            }
        }

        public int OwnerId
        {
            get
            {
                if (!_ownerId.HasValue)
                    _ownerId = (int)_slimItem.Attribute("ownerID");

                return _ownerId.Value;
            }
        }

        public Vector3 PointInSpaceAwayNSEWUD
        {
            get
            {
                Vector3 tempPointInSpace = Coord;
                if (WeAreWestOfThisEntity)
                    tempPointInSpace = PointInSpaceDirectlyWest;

                if (WeAreEastOfThisEntity)
                    tempPointInSpace = PointInSpaceDirectlyEast;

                if (WeAreAboveThisEntity)
                    tempPointInSpace = new Vector3(tempPointInSpace.X + PointInSpaceDirectlyUp.X, tempPointInSpace.Y + PointInSpaceDirectlyUp.Y, tempPointInSpace.Z + PointInSpaceDirectlyUp.Z);

                if (WeAreBelowThisEntity)
                    tempPointInSpace = new Vector3(tempPointInSpace.X + PointInSpaceDirectlyDown.X, tempPointInSpace.Y + PointInSpaceDirectlyDown.Y, tempPointInSpace.Z + PointInSpaceDirectlyDown.Z);

                return tempPointInSpace;
            }
        }

        public Vector3 PointInSpaceDirectlyDown => new Vector3(X + 10000000, Y, Z);
        public Vector3 PointInSpaceDirectlyEast => new Vector3(X, Y - 10000000, Z);
        public Vector3 PointInSpaceDirectlyNorth => new Vector3(X, Y, Z + 10000000);
        public Vector3 PointInSpaceDirectlySouth => new Vector3(X, Y, Z - 10000000);
        public Vector3 PointInSpaceDirectlyUp => new Vector3(X - 10000000, Y, Z);
        public Vector3 PointInSpaceDirectlyWest => new Vector3(X, Y + 10000000, Z);
        public Vector3 Position => new Vector3(X, Y, Z);

        public new double Radius
        {
            get
            {
                try
                {
                    if (!IsValid) return 0;

                    if (!_radius.HasValue)
                        _radius = (double)Ball.Attribute("radius");

                    if (!_radius.HasValue || _radius == 0)
                        _radius = (double)Ball.Attribute("Radius");

                    return _radius.Value;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        public double? RawEhp => _rawEhp ?? (_rawEhp = CurrentShield + CurrentArmor + CurrentStructure);

        public bool ScoopToCargoHold
        {
            get
            {
                if (!IsValid)
                    return false;

                if (GroupId != (int)Group.MobileTractor && GroupId != (int)Group.MobileDepot)
                    return false;

                if (!DirectEve.Interval(4000, 6000))
                    return false;

                return DirectEve.ThreadedLocalSvcCall("menu", "Scoop", Id, TypeId);
            }
        }

        public bool ScoopToFighterBay
        {
            get
            {
                if (!IsValid)
                    return false;

                if (GroupId != (int)Group.MobileTractor && GroupId != (int)Group.MobileDepot)
                    return false;

                if (!DirectEve.Interval(4000, 6000))
                    return false;

                return DirectEve.ThreadedLocalSvcCall("menu", "ScoopToFighterBay", Id, TypeId);
            }
        }

        public bool ScoopToFleetHangar
        {
            get
            {
                if (!IsValid)
                    return false;

                if (GroupId != (int)Group.MobileTractor && GroupId != (int)Group.MobileDepot)
                    return false;

                if (!DirectEve.Interval(4000, 6000))
                    return false;

                return DirectEve.ThreadedLocalSvcCall("menu", "ScoopToFleetHangar", Id, TypeId);
            }
        }

        public bool ShieldArmorHullAllAt0
        {
            get
            {
                try
                {
                    if (IsPotentialCombatTarget && IsTarget && (_shieldPct == null || _shieldPct == 0) && (_armorPct == null || _armorPct == 0) && (_structurePct == null || _structurePct == 0))
                    {
                        return true;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    Logging.Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        public double ShieldPct
        {
            get
            {
                if (!IsValid) return 0;

                if (!_shieldPct.HasValue)
                    GetDamageState();

                return _shieldPct ?? 0;
            }
        }

        public double StructurePct
        {
            get
            {
                if (!IsValid) return 0;

                if (!_structurePct.HasValue)
                    GetDamageState();

                return _structurePct ?? 0;
            }
        }

        public double? StructureUnifirmity
        {
            get
            {
                if (!IsValid) return 0;

                if (_structureUniformity == null)
                    _structureUniformity = (float)Ball.Attribute("structureUnifirmity");

                if (_structureUniformity != null && !double.IsNaN(_structureUniformity.Value) && !double.IsInfinity(_structureUniformity.Value))
                    return _structureUniformity.Value;

                return 0;
            }
        }

        public double? TrackingSpeed
        {
            get
            {
                if (!IsValid) return 0;

                if (_trackingSpeed == null)
                    _trackingSpeed = (float)Ball.Attribute("trackingSpeed");

                if (_trackingSpeed != null && !double.IsNaN(_trackingSpeed.Value) && !double.IsInfinity(_trackingSpeed.Value))
                    return _trackingSpeed.Value;

                return 0;
            }
        }

        public double TransversalVelocity
        {
            get
            {
                if (!IsValid) return 0;
                if (!IsNpc) return 0;

                if (_transversalVelocity == null)
                {
                    DirectEntity myBall = DirectEve.ActiveShip.Entity;
                    List<double> CombinedVelocity = new List<double> { Vx - myBall.Vx, Vy - myBall.Vy, Vz - myBall.Vz };
                    List<double> Radius = new List<double> { X - myBall.X, Y - myBall.Y, Z - myBall.Z };
                    List<double> RadiusVectorNormalized = Radius.Select(i => i / Math.Sqrt(Radius[0] * Radius[0] + Radius[1] * Radius[1] + Radius[2] * Radius[2]))
                        .ToList();
                    double RadialVelocity = CombinedVelocity[0] * RadiusVectorNormalized[0] + CombinedVelocity[1] * RadiusVectorNormalized[1] +
                                            CombinedVelocity[2] * RadiusVectorNormalized[2];
                    List<double> ScaledRadiusVector = RadiusVectorNormalized.Select(i => i * RadialVelocity).ToList();
                    _transversalVelocity =
                        Math.Sqrt((CombinedVelocity[0] - ScaledRadiusVector[0]) * (CombinedVelocity[0] - ScaledRadiusVector[0]) +
                                  (CombinedVelocity[1] - ScaledRadiusVector[1]) * (CombinedVelocity[1] - ScaledRadiusVector[1]) +
                                  (CombinedVelocity[2] - ScaledRadiusVector[2]) * (CombinedVelocity[2] - ScaledRadiusVector[2]));
                }

                return _transversalVelocity.Value;
            }
        }

        public double? TriglavianDamage
        {
            get
            {
                if (!IsValid) return 0;

                if (_triglavianDamage == null)
                    _triglavianDamage = (float)Ball.Attribute("damage");

                if (_triglavianDamage.HasValue)
                    return _triglavianDamage;

                return null;
            }
        }

        public double? TriglavianDPS
        {
            get
            {
                if (!IsValid) return 0;

                if (TriglavianDamage != null && TriglavianDamage != 0)
                    _triglavianDps = TriglavianDamage / 5; //Where can we retrieve the acurate rate of fire for these guns?!

                if (_triglavianDps > 0)
                    return _triglavianDps;

                return 0;
            }
        }

        public double? TrmEHP => _trmEhp ?? (_trmEhp = 1 / (1 - ShieldResistanceThermal) * CurrentShield + 1 / (1 - ArmorResistanceThermal) * CurrentArmor + CurrentStructure);

        public double Velocity
        {
            get
            {
                if (!IsValid) return 0;

                if (_velocity == null)
                    _velocity = (double)Ball.Call("GetVectorDotAt", PySharp.Import("blue").Attribute("os").Call("GetSimTime")).Call("Length");

                return _velocity.Value;
            }
        }

        public double Vx
        {
            get
            {
                if (!IsValid) return 0;

                if (!_vx.HasValue)
                    _vx = (double)Ball.Attribute("vx");

                return _vx.Value;
            }
        }

        public double Vy
        {
            get
            {
                if (!IsValid) return 0;

                if (!_vy.HasValue)
                    _vy = (double)Ball.Attribute("vy");

                return _vy.Value;
            }
        }

        public double Vz
        {
            get
            {
                if (!IsValid) return 0;

                if (!_vz.HasValue)
                    _vz = (double)Ball.Attribute("vz");

                return _vz.Value;
            }
        }

        public double WarpScrambleChance
        {
            get
            {
                if (!IsValid) return 0;

                if (!_warpScrambleChance.HasValue)
                    _warpScrambleChance = (float)Ball.Attribute("entityWarpScrambleChance");

                if (_warpScrambleChance != null && !double.IsNaN(_warpScrambleChance.Value) && !double.IsInfinity(_warpScrambleChance.Value))
                    return _warpScrambleChance.Value;

                return 0;
            }
        }

        public bool WeAreAboveThisEntity
        {
            get
            {
                if (!IsValid) return false;

                if (DirectEve.ActiveShip.Entity.X > Coord.X)
                    return true;

                return false;
            }
        }

        public bool WeAreBelowThisEntity
        {
            get
            {
                if (!IsValid) return false;

                if (DirectEve.ActiveShip.Entity.X > Coord.X)
                    return false;

                return true;
            }
        }

        public bool WeAreEastOfThisEntity
        {
            get
            {
                if (!IsValid) return false;

                if (DirectEve.ActiveShip.Entity.Y > Coord.Y)
                    return true;

                return false;
            }
        }

        public bool WeAreNorthOfThisEntity
        {
            get
            {
                if (!IsValid) return false;

                if (DirectEve.ActiveShip.Entity.Z > Coord.Z)
                    return true;

                return false;
            }
        }

        public bool WeAreSouthOfThisEntity
        {
            get
            {
                if (!IsValid) return false;

                if (DirectEve.ActiveShip.Entity.Z > Coord.Z)
                    return false;

                return true;
            }
        }

        public bool WeAreWestOfThisEntity
        {
            get
            {
                if (!IsValid) return false;

                if (DirectEve.ActiveShip.Entity.Y > Coord.Y)
                    return false;

                return true;
            }
        }

        public double? WormholeAge
        {
            get
            {
                if (_wormholeAge == null)
                    _wormholeAge = (double)_slimItem.Attribute("wormholeAge");

                return _wormholeAge.Value;
            }
        }

        // 0 = entityIdle
        // 1 = Approaching or entityCombat
        // 2 = entityMining
        // 3 = Warping (is this correct? entityApproaching)
        // 4 = Orbiting (is this correct? entityDeparting)
        // 5 = entityDeparting2
        // 6 = entityPursuit
        // 7 = entityFleeing
        // 8 =
        // 9 = entityOperating
        // 10 = entityEngage
        // 18 = entitySalvaging
        public double? WormholeSize
        {
            get
            {
                if (_wormholeSize == null)
                    _wormholeSize = (double)_slimItem.Attribute("wormholeSize");

                return _wormholeSize.Value;
            }
        }

        public double X
        {
            get
            {
                if (!IsValid) return 0;

                if (!_x.HasValue)
                    _x = (double)Ball.Attribute("x");

                return _x.Value;
            }
        }

        public double Y
        {
            get
            {
                if (!IsValid) return 0;

                if (!_y.HasValue)
                    _y = (double)Ball.Attribute("y");

                return _y.Value;
            }
        }

        public double Z
        {
            get
            {
                if (!IsValid) return 0;

                if (!_z.HasValue)
                    _z = (double)Ball.Attribute("z");

                return _z.Value;
            }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        ///     Abandons all wrecks. Make sure to only call this on a wreck.
        /// </summary>
        /// <returns>false if entity is not a wreck</returns>
        public bool AbandonAllWrecks()
        {
            if (GroupId != (int)DirectEve.Const.GroupWreck)
                return false;

            PyObject AbandonAllLoot = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("AbandonAllLoot");
            return DirectEve.ThreadedCall(AbandonAllLoot, Id);
        }

        /// <summary>
        ///     Activate (Acceleration Gates only)
        /// </summary>
        /// <returns></returns>
        public bool Activate()
        {
            if (!IsValid)
                return false;

            if (!DirectEve.Interval(8000, 12000))
                return false;

            PyObject DockOrJumpOrActivateGate = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions")
                .Attribute("DockOrJumpOrActivateGate");

            if (DirectEve.ThreadedCall(DockOrJumpOrActivateGate, Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Activating."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            return false;
        }

        /// <summary>
        ///     Activate Abyssal Gate
        /// </summary>
        /// <returns></returns>
        public bool ActivateAbyssalAccelerationGate()
        {
            if (!IsValid)
                return false;

            if (TypeId != (int)TypeID.AbyssEncounterGate)
            {
                Logging.Log.WriteLine("ActivateAbyssalAccelerationGate: [" + Name + "] TypeId [" + TypeId + "] was expected to be [" + TypeID.AbyssEncounterGate + "]: Failed");
                return false;
            }

            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "ActivateAbyssalAccelerationGate", Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Jumping."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            Logging.Log.WriteLine("ActivateAbyssalAccelerationGate: failed");
            return false;
        }

        /// <summary>
        ///     Activate Abyssal Gate
        /// </summary>
        /// <returns></returns>
        public bool ActivateAbyssalEndGate()
        {
            if (!IsValid)
                return false;

            if (TypeId != (int)TypeID.AbyssExitGate)
            {
                Logging.Log.WriteLine("ActivateAbyssalEndGate: Name [" + Name + "] TypeId [" + TypeId + "] was expected to be [" + TypeID.AbyssExitGate + "]: Failed");
                return false;
            }

            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "ActivateAbyssalEndGate", Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Jumping."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            Logging.Log.WriteLine("ActivateAbyssalEndGate: failed");
            return false;
        }

        //
        // Abyssal Frigate fleet gate?
        //
        public bool ActivateAbyssalEntranceAccelerationGate()
        {
            if (!IsValid)
                return false;

            if (TypeId != (int)TypeID.AbyssEntranceGate)
                return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "ActivateAbyssalEntranceAccelerationGate", Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Jumping."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            return false;
        }

        public bool ActivateAbyssalPvPGate()
        {
            if (!IsValid)
                return false;

            if (TypeId != (int)TypeID.AbyssPvPGate)
                return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "ActivateAbyssalPvPGate", Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Jumping."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            return false;
        }

        /// <summary>
        ///     Warp to target
        /// </summary>
        /// <returns></returns>
        public bool AlignTo()
        {
            if (!DirectEve.Interval(4000, 6000))
                return false;

            DirectEve.Log("AlignTo called.");

            if (IsValid)
                return DirectEve.ThreadedLocalSvcCall("menu", "AlignTo", Id);
            return false;
        }

        public bool AnchorObject()
        {
            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.IsInSpace)
                return false;

            if (Distance >= 5000)
                return false;

            if (!IsValid)
                return false;

            if (!IsAnchorableObject)
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "AnchorObject", Id))
                return true;

            return false;
        }

        public bool AnchorStructure()
        {
            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.IsInSpace)
                return false;

            if (Distance >= 5000)
                return false;

            if (!IsValid)
                return false;

            if (!IsAnchorableStructure)
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "AnchorStructure", Id))
                return true;

            return false;
        }

        /// <summary>
        ///     Approach target
        /// </summary>
        /// <returns></returns>
        public bool Approach()
        {
            if (!IsValid)
                return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            //if (IsApproachedOrKeptAtRangeByActiveShip)
            //    return true;

            if (IsValid)
            {
                //DirectEve.Log("Approach called.");
                PyObject Approach = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions").Attribute("Approach");
                return DirectEve.ThreadedCall(Approach, Id);
            }
            return false;
        }

        /// <summary>
        ///     Board this ship
        /// </summary>
        /// <returns>false if entity is player or out of range</returns>
        public bool BoardShip()
        {
            if (!IsValid)
                return false;

            if (IsPlayer)
                return false;

            if (Distance > 6500)
                return false;

            PyObject Board = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.menuFunctions").Attribute("Board");
            return DirectEve.ThreadedCall(Board, Id);
        }

        public double? DistanceTo(DirectEntity entity)
        {
            return Math.Round(Math.Sqrt((entity.X - X) * (entity.X - X) + (entity.Y - Y) * (entity.Y - Y) + (entity.Z - Z) * (entity.Z - Z)), 2);
        }

        public double? DistanceTo(double entityX, double entityY, double entityZ)
        {
            return Math.Round(Math.Sqrt((entityX - X) * (entityX - X) + (entityY - Y) * (entityY - Y) + (entityZ - Z) * (entityZ - Z)), 2);
        }

        /**
        public double? NpcArmorResistanceEm
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcArmorResistanceEm.HasValue)
                    _npcArmorResistanceEm = Math.Round(1.0d - (int) Ball.Attribute("armorEmDamageResonance"), 2);

                return _npcArmorResistanceEm.Value;
            }
        }

        public double? NpcArmorResistanceExplosive
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcArmorResistanceExplosion.HasValue)
                    _npcArmorResistanceExplosion = Math.Round(1.0d - (int) Ball.Attribute("armorExplosiveDamageResonance"), 2);

                return _npcArmorResistanceExplosion.Value;
            }
        }

        public double? NpcArmorResistanceKinetic
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcArmorResistanceKinetic.HasValue)
                    _npcArmorResistanceKinetic = Math.Round(1.0d - (float) Ball.Attribute("armorKineticDamageResonance"), 2);

                return _npcArmorResistanceKinetic;
            }
        }

        public double? NpcArmorResistanceThermal
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcArmorResistanceThermal.HasValue)
                    _npcArmorResistanceThermal = Math.Round(1.0d - (float) Ball.Attribute("armorThermalDamageResonance"), 2);

                return _npcArmorResistanceThermal;
            }
        }
        **/
        /**
        public double? NpcShieldResistanceEM
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcShieldResistanceEm.HasValue)
                    _npcShieldResistanceEm = Math.Round(1.0d - (float) Ball.Attribute("shieldEmDamageResonance"), 2);
                return _npcShieldResistanceEm;
            }
        }

        public double? NpcShieldResistanceExplosive
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcShieldResistanceExplosive.HasValue)
                    _npcShieldResistanceExplosive = Math.Round(1.0d - (double) Ball.Attribute("shieldExplosiveDamageResonance"), 2);
                return _npcShieldResistanceExplosive;
            }
        }

        public double? NpcShieldResistanceKinetic
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcShieldResistanceKinetic.HasValue)
                    _npcShieldResistanceKinetic = Math.Round(1.0d - (double) Ball.Attribute("shieldKineticDamageResonance"), 2);
                return _npcShieldResistanceKinetic;
            }
        }

        public double? NpcShieldResistanceThermal
        {
            get
            {
                if (!IsNpc) return 0;

                if (!_npcShieldResistanceThermal.HasValue)
                    _npcShieldResistanceThermal = Math.Round(1.0d - (double) Ball.Attribute("shieldThermalDamageResonance"), 2);
                return _npcShieldResistanceThermal;
            }
        }
        **/
        /**
        public double? EntityFactionLoss
        {
            get
            {
                if (!IsNpc) return 0;

                if (_entityFactionLoss == null)
                    _entityFactionLoss = (float)Ball.Attribute("entityFactionLoss");

                return _entityFactionLoss.Value;
            }
        }
        **/
        /// <summary>
        ///     Warp to target and dock
        /// </summary>
        /// <returns></returns>
        public bool Dock()
        {
            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.IsInSpace)
                return false;

            if (!IsValid)
                return false;
            PyObject DockOrJumpOrActivateGate = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions")
                .Attribute("DockOrJumpOrActivateGate");

            if (DirectEve.ThreadedCall(DockOrJumpOrActivateGate, Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Docking."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            return false;
        }

        public double GetBounty()
        {
            PyObject bountyRow = DirectEve.GetLocalSvc("godma")
                .Call("GetType", TypeId)
                .Attribute("displayAttributes")
                .ToList()
                .FirstOrDefault(i => i.Attribute("attributeID").ToInt() == (int)DirectEve.Const.AttributeEntityKillBounty);
            if (bountyRow == null || !bountyRow.IsValid)
                return 0;

            return (double)bountyRow.Attribute("value");
        }

        public string GetResistInfo()
        {
            return $"Name [{Name}] ShieldHitPoints [{TotalShield}] " +
                   $" ArmorHitPoints [{TotalArmor}]" +
                   $" StructureHitPoints[{TotalStructure}]" +
                   $" Shield-Res-EM/EXP/KIN/TRM [{ShieldResistanceEM}%," +
                   $" {ShieldResistanceExplosive}%," +
                   $" {ShieldResistanceKinetic}%," +
                   $" {ShieldResistanceThermal}%]" +
                   $" Armor-Res-EM/EXP/KIN/TRM [{ArmorResistanceEm}%," +
                   $" {ArmorResistanceExplosive}%," +
                   $" {ArmorResistanceKinetic}%," +
                   $" {ArmorResistanceThermal}%]";
        }

        /// <summary>
        ///     Jump (Stargates only)
        /// </summary>
        /// <returns></returns>
        public bool Jump()
        {
            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.IsInSpace)
                return false;

            if (Distance >= 2500)
                return false;

            if (!IsValid)
                return false;

            PyObject DockOrJumpOrActivateGate = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions")
                .Attribute("DockOrJumpOrActivateGate");

            if (DirectEve.ThreadedCall(DockOrJumpOrActivateGate, Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Jumping."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            return false;
        }

        /// <summary>
        ///     Jump Wormhole (Wormholes only)
        /// </summary>
        /// <returns></returns>
        public bool JumpWormhole()
        {
            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.IsInSpace)
                return false;

            if (Distance >= 5000)
                return false;

            if (!IsValid)
                return false;

            if (DirectEve.ThreadedLocalSvcCall("menu", "EnterWormhole", Id))
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.DOCK_JUMP_ACTIVATE, "Jumping."));
                DirectSession.SetSessionNextSessionReady();
                return true;
            }

            return false;
        }

        /// <summary>
        ///     KeepAtRange target
        /// </summary>
        /// <param name="range"></param>
        /// <returns></returns>
        public bool KeepAtRange(int range, bool force = false)
        {
            if (!DirectEve.Interval(8000, 10000) && !force)
                return false;

            if (!DirectEve.Session.IsInSpace)
                return false;

            if (!IsValid)
                return false;

            if (IsApproachedOrKeptAtRangeByActiveShip && _prevKeepAtRangeDist.HasValue && _prevKeepAtRangeDist == range && !force)
                return true;

            _prevKeepAtRangeDist = range;

            if (range < 50) // min keep at range
                range = 50;

            DirectEve.Log("KeepAtRange called.");

            PyObject KeepAtRange = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions").Attribute("KeepAtRange");
            if (IsValid)
                return DirectEve.ThreadedCall(KeepAtRange, Id, range);
            return false;
        }

        /// <summary>
        ///     Lock target
        /// </summary>
        /// <returns></returns>
        public bool LockTarget()
        {
            if (!IsValid) return false;

            // It's already a target!
            if (IsTarget || IsTargeting)
                return false;

            // We can't target this entity yet!
            if (!DirectEve.CanTarget(Id))
                return false;

            // Set target timer
            DirectEve.SetTargetTimer(Id);

            if (IsValid)
            {
                //DirectEvent
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.LOCK_TARGET, "Targeting [" + Id + "]"));

                return DirectEve.ThreadedLocalSvcCall("menu", "LockTarget", Id);
            }

            return false;
        }

        /// <summary>
        ///     Make this your active target
        /// </summary>
        /// <returns></returns>
        public bool MakeActiveTarget()
        {
            if (!IsValid)
                return false;

            if (DirectEve.IsTargetBeingRemoved(Id))
                return false;

            if (HasExploded)
                return false;

            if (HasReleased)
                return false;

            if (IsActiveTarget)
                return true;

            if (!IsTarget)
                return false;

            // Even though we uthread the thing, expect it to be instant
            DirectEntity currentActiveTarget = DirectEve.Entities.FirstOrDefault(t => t.IsActiveTarget);
            if (currentActiveTarget != null)
                currentActiveTarget.IsActiveTarget = false;

            // Switch active targets
            PyObject activeTarget = PySharp.Import("eve.client.script.parklife.states").Attribute("activeTarget");
            return IsActiveTarget = DirectEve.ThreadedLocalSvcCall("stateSvc", "SetState", Id, activeTarget, 1);
        }

        public bool MoveTo()
        {
            if (!IsValid) return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            return DirectEve.ActiveShip.MoveTo(this);
        }

        /// <summary>
        ///     Open cargo window (only valid on containers in space, or own ship)
        /// </summary>
        /// <returns></returns>
        public bool OpenCargo()
        {
            if (!DirectEve.Interval(2000, 3000))
                return false;

            if (IsValid)
                return DirectEve.ThreadedLocalSvcCall("menu", "OpenCargo", Id);
            return false;
        }

        // align: mode 0 / no following entity
        // stop: mode 2 / no following entity
        // warp: mode 3 / ??
        // approach: 1 / has a following entity
        // keep at range: 1 / has a following entity
        // orbit: 4 / has a following entity

        /// <summary>
        ///     Orbit target at 5000m
        /// </summary>
        /// <returns></returns>
        public bool Orbit()
        {
            if (!IsValid) return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            return Orbit(5000);
        }

        /// <summary>
        ///     Orbit target
        /// </summary>
        /// <param name="range"></param>
        /// <returns></returns>
        public bool Orbit(int range)
        {
            if (!IsValid) return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (IsOrbitedByActiveShip && _prevOrbitDist.HasValue && range == _prevOrbitDist)
                return true;

            _prevOrbitDist = range;

            PyObject Orbit = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions").Attribute("Orbit");

            DirectEve.Log("Orbit called.");

            if (IsValid)
                return DirectEve.ThreadedCall(Orbit, Id, range);
            return false;
        }

        public bool SendDroneToEngageActiveTarget()
        {
            if (!IsValid)
                return false;

            if (CategoryId != (int)CategoryID.Drone)
                return false;

            if (!DirectEve.ActiveDrones.Any())
                return false;

            if (DirectEve.ActiveDrones.Any(i => i.Id == Id))
            {
                // this engages the drone on whatever the ActiveTarget is (locked and selected target in the hud)
                // this is only dealing with one drone at a time!
                PyObject pySendDroneToEngageActiveTarget = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.droneFunctions").Attribute("EngageTarget");
                return DirectEve.ThreadedCall(pySendDroneToEngageActiveTarget, Id);
            }

            return false;
        }

        public bool SendDroneToMineRepeatedlyActiveTarget()
        {
            if (!IsValid)
                return false;

            if (CategoryId != (int)CategoryID.Drone)
                return false;

            if (!DirectEve.ActiveDrones.Any())
                return false;

            if (DirectEve.ActiveDrones.Any(i => i.Id == Id))
            {
                // this engages the drone on whatever the ActiveTarget is (locked and selected target in the hud)
                // this is only dealing with one drone at a time!
                PyObject pySendDroneToMineRepeatedlyActiveTarget = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.droneFunctions").Attribute("MineRepeatedly");
                return DirectEve.ThreadedCall(pySendDroneToMineRepeatedlyActiveTarget, Id);
            }

            return false;
        }

        public bool SendDroneToSalvageActiveTarget()
        {
            if (!IsValid)
                return false;

            if (CategoryId != (int)CategoryID.Drone)
                return false;

            if (!DirectEve.ActiveDrones.Any())
                return false;

            if (DirectEve.ActiveDrones.Any(i => i.Id == Id))
            {
                // this engages the drone on whatever the ActiveTarget is (locked and selected target in the hud)
                // this is only dealing with one drone at a time!
                PyObject pySendDroneToSalvageActiveTarget = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.droneFunctions").Attribute("Salvage");
                return DirectEve.ThreadedCall(pySendDroneToSalvageActiveTarget, Id);
            }

            return false;
        }


        /// <summary>
        ///     Unlock target
        /// </summary>
        /// <returns></returns>
        public bool UnlockTarget()
        {
            if (!IsValid) return false;
            // Its not a target, why are you unlocking?!?!
            if (!IsTarget)
                return false;

            // Clear target information
            if (IsValid)
            {
                DirectEve.ClearTargetTimer(Id);
                return DirectEve.ThreadedLocalSvcCall("menu", "UnlockTarget", Id);
            }

            return false;
        }

        /// <summary>
        ///     Warp fleet to target, make sure you have the fleetposition to warp the fleet
        /// </summary>
        /// <returns></returns>
        public bool WarpFleetTo()
        {
            if (!IsValid) return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.InFleet)
                return false;

            DirectFleetMember myDirectFleetMember = DirectEve.GetFleetMembers.FirstOrDefault(i => i.CharacterId == DirectEve.Session.CharacterId);
            if (myDirectFleetMember.Role == DirectFleetMember.FleetRole.Member)
                return false;

            return DirectEve.ThreadedLocalSvcCall("menu", "WarpFleet", Id);
        }

        /// <summary>
        ///     Warp fleet to target at range, make sure you have the fleetposition to warp the fleet
        /// </summary>
        /// <returns></returns>
        public bool WarpFleetTo(double range)
        {
            if (!IsValid) return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            if (!DirectEve.Session.InFleet)
                return false;

            DirectFleetMember myDirectFleetMember = DirectEve.GetFleetMembers.FirstOrDefault(i => i.CharacterId == DirectEve.Session.CharacterId);
            if (myDirectFleetMember.Role == DirectFleetMember.FleetRole.Member)
                return false;

            return DirectEve.ThreadedLocalSvcCall("menu", "WarpFleet", Id, range);
        }

        /// <summary>
        ///     Warp to target at range
        /// </summary>
        /// <returns></returns>
        public bool WarpTo(double range = 0)
        {
            if (!IsValid)
                return false;

            if (!DirectEve.Session.IsInSpace)
                return false;

            if (Distance > (long)Distances.HalfOfALightYearInAu)
                return false;

            if (Distance <= (int)Distances.WarptoDistance)
                return false;

            if (!DirectEve.Interval(4000, 6000))
                return false;

            //DirectEvent
            DirectEventManager.NewEvent(new DirectEvent(DirectEvents.WARP, "Warping."));
            PyObject WarpToItem = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions").Attribute("WarpToItem");
            return range == 0 ? DirectEve.ThreadedCall(WarpToItem, Id) : DirectEve.ThreadedCall(WarpToItem, Id, range);
        }

        internal static long GetBallparkCount(DirectEve directEve)
        {
            PyObject ballpark = directEve.GetLocalSvc("michelle").Call("GetBallpark");
            if (ballpark.IsValid && ballpark.Attribute("balls").IsValid) return ballpark.Attribute("balls").Call("keys").Size();
            return 0;
        }

        internal static Dictionary<long, DirectEntity> GetEntities(DirectEve directEve)
        {
            PySharp pySharp = directEve.PySharp;
            Dictionary<long, DirectEntity> entitiesById = new Dictionary<long, DirectEntity>();

            // Used by various loops, etc
            PyObject ballpark = directEve.GetLocalSvc("michelle").Call("GetBallpark");
            List<long> balls = ballpark.Attribute("balls").Call("keys").ToList<long>();
            PyObject target = directEve.GetLocalSvc("target");
            PyObject targetsBeingRemoved = target.Attribute("deadShipsBeingRemoved");

            if (!targetsBeingRemoved.IsValid)
            {
                Logging.Log.WriteLine($"Target.deadShipsBeingRemoved is not valid!");
                return entitiesById;
            }

            Dictionary<long, bool> targetsBeingRemovedDict = targetsBeingRemoved.ToList<long>().ToDictionary(x => x, y => true);
            foreach (long id in balls)
            {
                if (id < 0)
                    continue;

                // Get slim item
                PyObject slimItem = ballpark.Call("GetInvItem", id);

                // Get ball
                PyObject ball = ballpark.Call("GetBall", id);

                // Create the entity
                if (slimItem.IsValid && ball.IsValid
                    && !targetsBeingRemovedDict.ContainsKey(id)
                    && !directEve.GetTargetsBeingRemoved().ContainsKey(id)
                    && !(bool)ball.Attribute("exploded")
                    && !(bool)ball.Attribute("released"))
                    entitiesById[id] = new DirectEntity(directEve, ballpark, ball, slimItem, id);
            }

            // Mark active target
            PyObject activeTarget = pySharp.Import("eve.client.script.parklife.states").Attribute("activeTarget");
            long activeTargetId = (long)directEve.GetLocalSvc("stateSvc").Call("GetExclState", activeTarget);
            if (entitiesById.TryGetValue(activeTargetId, out var entity))
                entity.IsActiveTarget = true;

            Dictionary<PyObject, PyObject>.KeyCollection targets = target.Attribute("targetsByID").ToDictionary().Keys;
            foreach (PyObject targetId in targets)
            {
                if (!entitiesById.TryGetValue((long)targetId, out entity))
                    continue;

                entity.IsTarget = true;
            }

            Dictionary<long, PyObject>.KeyCollection targeting = target.Attribute("targeting").ToDictionary<long>().Keys;
            foreach (long targetId in targeting)
            {
                if (!entitiesById.TryGetValue(targetId, out entity))
                    continue;

                entity.IsTargeting = true;
            }

            List<long> targetedBy = target.Attribute("targetedBy").ToList<long>();
            foreach (long targetId in targetedBy)
            {
                if (!entitiesById.TryGetValue(targetId, out entity))
                    continue;

                entity.IsTargetedBy = true;
            }

            Dictionary<long, PyObject> attackers = directEve.GetLocalSvc("tactical").Attribute("attackers").ToDictionary<long>();
            foreach (KeyValuePair<long, PyObject> attacker in attackers)
            {
                if (!entitiesById.TryGetValue(attacker.Key, out entity))
                    continue;

                entity.IsAttacking = true;

                List<PyObject> attacks = attacker.Value.ToList();
                foreach (string attack in attacks.Select(a => (string)a.Item(1)))
                {
                    entity.IsWarpScramblingMe |= attack == "effects.WarpScramble";
                    entity.IsWebbingMe |= attack == "effects.ModifyTargetSpeed";
                    entity.Attacks.Add(attack);
                }
            }

            Dictionary<long, PyObject> jammers = directEve.GetLocalSvc("tactical").Attribute("jammers").ToDictionary<long>();
            foreach (KeyValuePair<long, PyObject> jammer in jammers)
            {
                if (!entitiesById.TryGetValue(jammer.Key, out entity))
                    continue;

                Dictionary<string, PyObject>.KeyCollection ews = jammer.Value.ToDictionary<string>().Keys;
                foreach (string ew in ews)
                {
                    entity.IsNeutralizingMe |= ew == "ewEnergyNeut";
                    entity.IsJammingMe |= ew == "electronic";
                    entity.IsSensorDampeningMe |= ew == "ewRemoteSensorDamp";
                    entity.IsTargetPaintingMe |= ew == "ewTargetPaint";
                    entity.IsTrackingDisruptingMe |= ew == "ewTrackingDisrupt";
                    entity.ElectronicWarfare.Add(ew);
                }
            }

            return entitiesById;
        }

        internal void GetDamageState()
        {
            _shieldPct = null;
            _armorPct = null;
            _structurePct = null;

            // Get damage state properties
            List<PyObject> damageState = _ballpark.Call("GetDamageState", Id).ToList();
            if ((damageState.Count == 3) ^ (damageState.Count == 5))
            {
                _shieldPct = (double)damageState[0];
                _armorPct = (double)damageState[1];
                _structurePct = (double)damageState[2];
            }
        }

        #endregion Methods

    }
}