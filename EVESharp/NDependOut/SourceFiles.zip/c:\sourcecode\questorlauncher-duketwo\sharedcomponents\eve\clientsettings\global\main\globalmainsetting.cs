﻿using System;

namespace SharedComponents.EVE.ClientSettings.Global.Main
{
    [Serializable]
    public class GlobalMainSetting
    {
        #region Properties

        public bool Disable3D { get; set; } = true;

        #endregion Properties
    }
}