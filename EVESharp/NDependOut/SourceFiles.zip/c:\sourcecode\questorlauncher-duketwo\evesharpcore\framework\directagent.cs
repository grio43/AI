﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using EVESharpCore.Logging;
using SC::SharedComponents.EVE;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.Extensions;
using SC::SharedComponents.IPC;
using SC::SharedComponents.Py;
using SC::SharedComponents.Utility;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectAgent : DirectObject
    {
        #region Constructors

        internal DirectAgent(DirectEve directEve) : base(directEve)
        {
        }

        #endregion Constructors

        #region Fields

        public static DateTime _agentWindowLastReady;
        public static DateTime _lastAgentWindowInteraction;

        public static Dictionary<long, string> Divisions = new Dictionary<long, string>
        {
            {1, "Accounting"},
            {2, "Administration"},
            {3, "Advisory"},
            {4, "Archives"},
            {5, "Astrosurveying"},
            {6, "Command"},
            {7, "Distribution"},
            {8, "Financial"},
            {9, "Intelligence"},
            {10, "Internal Security"},
            {11, "Legal"},
            {12, "Manufacturing"},
            {13, "Marketing"},
            {14, "Mining"},
            {15, "Personnel"},
            {16, "Production"},
            {17, "Public Relations"},
            {18, "R&D"},
            {19, "Security"},
            {20, "Storage"},
            {21, "Surveillance"},
            {22, "Distribution"},
            {23, "Mining"},
            {24, "Security"},
            {25, "Business"},
            {26, "Exploration"},
            {27, "Industry"},
            {28, "Military"},
            {29, "Advanced Military"}
        };

        public Dictionary<long, string> AgentTypes = new Dictionary<long, string>
        {
            {1, "agentTypeNonAgent"},
            {2, "agentTypeBasicAgent"},
            {3, "agentTypeTutorialAgent"},
            {4, "agentTypeResearchAgent"},
            {6, "agentTypeGenericStorylineMissionAgent"},
            {7, "agentTypeStorylineMissionAgent"},
            {8, "agentTypeEventMissionAgent"},
            {9, "agentTypeFactionalWarfareAgent"},
            {10, "agentTypeGenagentTypeEpicArcAgentericStorylineMissionAgent"},
            {11, "agentTypeAura"},
            {12, "agentTypeCareerAgent"}
        };

        private static readonly Dictionary<string, long> AgentLookupDict = new Dictionary<string, long>();

        private readonly bool DebugAgentInfo = false;

        private readonly bool DebugSkillQueue = false;

        public bool CloseConversation()
        {
            //if (!MissionSettings.SelectedControllerUsesCombatMissionsBehavior)
            //    return;

            if (IsValid)
            {
                DirectEve.Log("DirectAgent: CloseConversation: if(IsValid)");
                return true;
            }

            //if (Window == null)
            //    if (DirectEve.Session.IsInDockableLocation != null && (bool)DirectEve.Session.IsInDockableLocation)
            //    {
            //        Log.WriteLine("Done");
            //        ChangeAgentInteractionState(AgentInteractionState.Done, false);
            //        return;
            //    }

            if (Window != null && Window.IsReady)
            {
                if (Window.Close())
                {
                    _lastAgentWindowInteraction = DateTime.MinValue;
                    DirectEve.Log("DirectAgent: CloseConversation: Closing Agent Window");
                    return true;
                }

                return false;
            }

            return false;
        }

        #endregion Fields

        #region Properties

        public static readonly Dictionary<int, double> AGENT_LEVEL_REQUIRED_STANDING = new Dictionary<int, double>
        {
            {1, -11.0},
            {2, 1.0},
            {3, 3.0},
            {4, 5.0},
            {5, 7.0}
        };

        public bool DebugAgentInteractionReplyToAgent = false;
        private float? _agentCorpEffectiveStandingtoMe;
        private float? _agentEffectiveStandingtoMe;
        private float? _agentFactionEffectiveStandingtoMe;
        private float? _maximumStandingUsedToAccessAgent;
        public static float StandingsNeededToAccessLevel1Agent { get; set; } = -11;

        public static float StandingsNeededToAccessLevel2Agent { get; set; } = 1;

        public static float StandingsNeededToAccessLevel3Agent { get; set; } = 3;

        public static float StandingsNeededToAccessLevel4Agent { get; set; } = 5;

        public static float StandingsNeededToAccessLevel5Agent { get; set; } = 7;

        public float AgentCorpEffectiveStandingtoMe
        {
            get
            {
                try
                {
                    if (_agentCorpEffectiveStandingtoMe == null)
                    {
                        _agentCorpEffectiveStandingtoMe = DirectEve.Standings.EffectiveStanding(CorpId, (long)DirectEve.Session.CharacterId);
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentCorpStandings), _agentCorpEffectiveStandingtoMe);
                    }

                    return (float)_agentCorpEffectiveStandingtoMe;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        public float AgentEffectiveStandingtoMe
        {
            get
            {
                try
                {
                    if (_agentEffectiveStandingtoMe == null)
                    {
                        _agentEffectiveStandingtoMe = DirectEve.Standings.EffectiveStanding(AgentId, (long)DirectEve.Session.CharacterId);
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentStandings), _agentEffectiveStandingtoMe);
                    }

                    return (float)_agentEffectiveStandingtoMe;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        public string AgentEffectiveStandingtoMeText => MaximumStandingUsedToAccessAgent.ToString("0.00");

        public float AgentFactionEffectiveStandingtoMe
        {
            get
            {
                try
                {
                    if (_agentFactionEffectiveStandingtoMe == null)
                    {
                        _agentFactionEffectiveStandingtoMe = DirectEve.Standings.EffectiveStanding(FactionId, (long)DirectEve.Session.CharacterId);
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentFactionStandings), _agentFactionEffectiveStandingtoMe);
                    }

                    return (float)_agentFactionEffectiveStandingtoMe;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        public long AgentId { get; private set; }

        public long AgentTypeId { get; private set; }

        public string AgentTypeName
        {
            get
            {
                try
                {
                    string _agentTypeName = string.Empty;
                    AgentTypes.TryGetValue(AgentTypeId, out _agentTypeName);
                    if (!string.IsNullOrEmpty(_agentTypeName))
                        return _agentTypeName;

                    return "unknown";
                }
                catch (Exception)
                {
                    return "unknown.";
                }
            }
        }

        public long BloodlineId { get; private set; }

        public bool CanAccessAgent
        {
            get
            {
                if (AGENT_LEVEL_REQUIRED_STANDING.TryGetValue(Level, out var s))
                {
                    if (Level == 1)
                        return true;
                    double min = MinEffectiveStanding;
                    double max = MaxEffectiveStanding;

                    if (min < -1.99)
                        return false;

                    return max > s;
                }
                return false;
            }
        }

        public long CorpId { get; private set; }
        public long DivisionId { get; private set; }

        public string DivisionName { get; set; }

        public double EffectiveAgentStanding => DirectEve.Standings.EffectiveStanding(AgentId, DirectEve.Session.CharacterId ?? -1);
        public double EffectiveCorpStanding => DirectEve.Standings.EffectiveStanding(CorpId, DirectEve.Session.CharacterId ?? -1);
        public double EffectiveFactionStanding => DirectEve.Standings.EffectiveStanding(FactionId, DirectEve.Session.CharacterId ?? -1);
        public long FactionId { get; private set; }

        public string FactionName
        {
            get
            {
                try
                {
                    string _factionName = string.Empty;
                    DirectNpcInfo.FactionIdsToFactionNames.TryGetValue(FactionId.ToString(), out _factionName);
                    if (!string.IsNullOrEmpty(_factionName))
                        return _factionName;

                    return "unknown";
                }
                catch (Exception)
                {
                    return "unknown.";
                }
            }
        }

        public Faction FactionOfAgent
        {
            get
            {
                try
                {
                    Faction _faction = null;
                    DirectNpcInfo.FactionIdsToFactions.TryGetValue(FactionId.ToString(), out _faction);
                    return _faction;
                }
                catch (Exception)
                {
                    return new Faction("Default", DamageType.EM, null, null, null, true);
                }
            }
        }

        public bool Gender { get; private set; }

        public bool HaveStandingsToAccessToThisAgent
        {
            get
            {
                if (MaximumStandingUsedToAccessAgent > EffectiveStandingNeededToAccessAgent())
                    return true;

                return false;
            }
        }

        public bool IsAgentMissionAccepted
        {
            get
            {
                if (DirectEve.AgentMissions.Any(i => i.Agent.AgentId == AgentId && i.State == MissionState.Accepted))
                    return true;

                return false;
            }
        }

        public bool IsAgentMissionExists
        {
            get
            {
                if (DirectEve.AgentMissions.Any(i => i.Agent.AgentId == AgentId))
                    return true;

                return false;
            }
        }

        public bool IsValid { get; private set; }

        public int Level { get; private set; }

        public int LoyaltyPoints
        {
            get
            {
                return 0;
                int ret = -1;
                if ((bool)DirectEve.GetLocalSvc("journal").Attribute("outdatedCorpLP"))
                {
                    DirectEve.Log("OutdatedCorpLP = true");
                    DirectJournalWindow jw = DirectEve.Windows.OfType<DirectJournalWindow>().FirstOrDefault();
                    if (jw == null)
                    {
                        DirectEve.Log("Opening journal.");
                        DirectEve.ExecuteCommand(DirectCmd.OpenJournal);
                        return ret;
                    }

                    if (jw.SelectedTab != JournalTab.LPs)
                    {
                        DirectEve.Log("Switching journal tab to LPs.");
                        //jw.SwitchTab(JournalTab.LPs);
                    }

                    // Update loyalty points if their outdated
                    //DirectEve.ThreadedLocalSvcCall("journal", "GetMyLoyaltyPoints");
                    //DirectEve.Log("GetMyLoyaltyPoints was called.");
                }
                else
                {
                    List<PyObject> mappings = DirectEve.GetLocalSvc("journal").Attribute("lpMapping").ToList();
                    foreach (PyObject mapping in mappings)
                    {
                        if ((int)mapping.Item(0) != CorpId)
                            continue;

                        return (int)mapping.Item(1);
                    }
                }
                return ret;
            }
        }

        public double MaxEffectiveStanding => Math.Max(Math.Max(EffectiveAgentStanding, EffectiveCorpStanding), EffectiveFactionStanding);

        public float MaximumStandingUsedToAccessAgent
        {
            get
            {
                try
                {
                    if (_maximumStandingUsedToAccessAgent == null)
                    {
                        if (AgentCorpEffectiveStandingtoMe < -2)
                            return Math.Min(AgentCorpEffectiveStandingtoMe, AgentFactionEffectiveStandingtoMe);

                        if (AgentFactionEffectiveStandingtoMe < -2)
                            return Math.Min(AgentCorpEffectiveStandingtoMe, AgentFactionEffectiveStandingtoMe);

                        _maximumStandingUsedToAccessAgent = Math.Max(AgentEffectiveStandingtoMe, Math.Max(AgentCorpEffectiveStandingtoMe, AgentFactionEffectiveStandingtoMe));
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.StandingUsedToAccessAgent), _maximumStandingUsedToAccessAgent);
                    }

                    return (float)_maximumStandingUsedToAccessAgent;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        public double MinEffectiveStanding => Math.Min(Math.Min(EffectiveAgentStanding, EffectiveCorpStanding), EffectiveFactionStanding);

        public DirectAgentMission Mission
        {
            get
            {
                if (DirectEve.AgentMissions != null && DirectEve.AgentMissions.Any())
                {
                    /**
                    if (DebugCourierMissions)
                    {
                        int intMissionNum = 0;
                        foreach (DirectAgentMission myAgentMission in DirectEve.AgentMissions)
                        {
                            intMissionNum++;
                            DirectEve.Log("Mission: [" + intMissionNum + "][" + myAgentMission.Name + "] AgentId [" + myAgentMission.AgentId + "] CourierMissionCtrlState [" + myAgentMission.CurrentCourierMissionCtrlState + "]");
                        }
                    }
                    **/

                    if (DirectEve.AgentMissions.Any(i => i.AgentId == AgentId))
                    {
                        DirectAgentMission thisAgentMission = DirectEve.AgentMissions.FirstOrDefault(i => i.AgentId == AgentId);
                        /**
                        if (DebugCourierMissions)
                            DirectEve.Log("Chosen Mission:[" + thisAgentMission.Name + "] AgentId [" + thisAgentMission.AgentId + "] CourierMissionCtrlState [" + thisAgentMission.CurrentCourierMissionCtrlState + "]");
                        **/

                        return thisAgentMission;
                    }

                    return null;
                }

                return null;
            }
        }

        public string Name
        {
            get
            {
                DirectOwner owner = DirectOwner.GetOwner(DirectEve, AgentId);
                if (owner == null)
                    return string.Empty;

                return owner.Name;
            }
        }

        public int Quality { get; private set; }

        public DirectSolarSystem SolarSystem => DirectEve.SolarSystems[(int)SolarSystemId];

        public long SolarSystemId { get; private set; }

        public DirectStation Station
        {
            get
            {
                if (DirectEve.Stations.Any())
                {
                    DirectStation _station = null;
                    DirectEve.Stations.TryGetValue((int)StationId, out _station);
                    if (_station != null) return _station;
                    return null;
                }

                return null;
            }
        }

        public long StationId { get; private set; }

        public string StationName => DirectEve.GetLocationName(StationId);
        public DirectSolarSystem System => DirectEve.SolarSystems[(int)SolarSystemId];

        public DirectAgentWindow Window
        {
            get { return DirectEve.Windows.OfType<DirectAgentWindow>().FirstOrDefault(w => w.AgentId == AgentId && w.IsReady); }
        }

        private PyObject PyAgentId { get; set; }

        public double EffectiveStandingNeededToAccessAgent()
        {
            switch (Level)
            {
                case 1: //lvl1 agent
                    return StandingsNeededToAccessLevel1Agent;

                case 2: //lvl2 agent
                    return StandingsNeededToAccessLevel2Agent;

                case 3: //lvl3 agent
                    return StandingsNeededToAccessLevel3Agent;

                case 4: //lvl4 agent
                    return StandingsNeededToAccessLevel4Agent;

                case 5: //lvl5 agent
                    return StandingsNeededToAccessLevel5Agent;
            }

            return StandingsNeededToAccessLevel4Agent;
        }

        public DirectAgentMissionBookmark GetMissionBookmark(string startsWith)
        {
            return this?.Mission?.Bookmarks.FirstOrDefault(b => b.Title.ToLower().StartsWith(startsWith.ToLower()));
        }

        public bool OpenAgentWindow(bool WeWantToBeInStation)
        {
            if (!IsValid)
            {
                Log.WriteLine("if (!IsValid)");
                return false;
            }

            if (WeWantToBeInStation && !DirectEve.Session.IsInDockableLocation)
                return true;

            //int _delayInSeconds = 0;

            if (Window == null)
            {
                if (DateTime.UtcNow < _lastAgentWindowInteraction.AddMilliseconds(Util.GetRandom(1500, 1700))) // was 3000 ms
                {
                    if (DebugAgentInteractionReplyToAgent)
                        DirectEve.Log("if (DateTime.UtcNow < _lastAgentAction.AddSeconds(3))");
                    return false;
                }

                if (DebugAgentInteractionReplyToAgent)
                    DirectEve.Log("Attempting to Interact with the agent named [" + Name + "] in [" + SolarSystem.Name + "]");

                if (InteractWith())
                {
                    _lastAgentWindowInteraction = DateTime.UtcNow;
                    Log.WriteLine("Agent [" + Name + "]: Opening AgentWindow");
                    return false;
                }

                return false;
            }

            if (!Window.IsReady && !string.IsNullOrEmpty(Window.AgentSays))
            {
                _agentWindowLastReady = DateTime.UtcNow;
                //DirectEve.Log("Agent: [" + Name + "] Window !isReady: AgentSays is not empty");
                PassAgentInfoToEveSharpLauncher(this);
                return true;
            }

            if (!Window.IsReady && Window.Buttons.Any())
            {
                _agentWindowLastReady = DateTime.UtcNow;
                //DirectEve.Log("Agent: [" + Name + "] Window !isReady: We have [" + Window.Buttons.Count + "] responses");
                PassAgentInfoToEveSharpLauncher(this);
                return true;
            }

            if (!Window.IsReady)
            {
                Log.WriteLine("if (!Window.IsReady)");
                return false;
            }

            if (Window.IsReady) //&& DateTime.UtcNow > _agentWindowLastReady.AddSeconds(_delayInSeconds + 2))
            {
                if (!Window.Buttons.Any() && !string.IsNullOrEmpty(Window.AgentSays))
                {
                    _agentWindowLastReady = DateTime.UtcNow;
                    //DirectEve.Log("Agent: [" + Name + "] Window isReady: AgentSays is not empty");
                    PassAgentInfoToEveSharpLauncher(this);
                    return true;
                }

                if (Window.Buttons.Any())
                {
                    _agentWindowLastReady = DateTime.UtcNow;
                    //DirectEve.Log("Agent: [" + Name + "] Window isReady: We have [" + Window.Buttons.Count + "] responses");
                    PassAgentInfoToEveSharpLauncher(this);
                    return true;
                }

                Log.WriteLine("Agent: [" + Name + "] Window isReady: There are no Buttons and logic flaw?");
                return false;
            }

            Log.WriteLine("Agent: [" + Name + "] logic flaw?");
            return false;
        }

        public void PassAgentInfoToEveSharpLauncher(DirectAgent agent)
        {
            try
            {
                if (DebugAgentInfo) DirectEve.Log("AgentName [" + agent.Name + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.Agent), agent.Name);
                if (DebugAgentInfo) DirectEve.Log("Agent Level [" + agent.Level + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentLevel), agent.Level.ToString());
                if (DebugAgentInfo) DirectEve.Log("Agent CorpId [" + agent.CorpId + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentCorpId), agent.CorpId.ToString());
                try
                {
                    string agentCorpName;
                    DirectNpcInfo.NpcCorpIdsToNames.TryGetValue(agent.CorpId.ToString(), out agentCorpName);
                    if (!string.IsNullOrEmpty(agentCorpName))
                    {
                        if (DebugAgentInfo) DirectEve.Log("Agent CorpName [" + agentCorpName + "]");
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentCorp), agentCorpName);
                    }
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                }
                if (DebugAgentInfo) DirectEve.Log("Agent FactionId [" + agent.FactionId + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentFactionId), agent.FactionId.ToString());
                try
                {
                    if (DebugAgentInfo) DirectEve.Log("Agent Faction [" + agent.FactionName + "]");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentFaction), agent.FactionName);
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                }

                if (agent.LoyaltyPoints > 0)
                {
                    if (DebugAgentInfo) DirectEve.Log("Agent LoyaltyPoints [" + agent.LoyaltyPoints + "]");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.LoyaltyPoints), (double)agent.LoyaltyPoints);
                }

                if (DebugAgentInfo) DirectEve.Log("Agent Division [" + agent.DivisionName + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.AgentDivision), agent.DivisionName);
                try
                {
                    TimeSpan mySkillQueueLengthTimespan = DirectEve.Skills.SkillQueueLength;
                    //if (DebugConfig.DebugSkillQueue)
                    if (DebugSkillQueue) DirectEve.Log("AgentInteraction: mySkillQueueLengthTimespan [" + Math.Round(mySkillQueueLengthTimespan.TotalHours, 0) + "] hours from now");
                    DateTime mySkillQueueEnds = DateTime.UtcNow.Add(mySkillQueueLengthTimespan);
                    //if (DebugConfig.DebugSkillQueue)
                    if (DebugSkillQueue) DirectEve.Log("AgentInteraction: mySkillQueueEnds [" + mySkillQueueEnds + "]");
                    if (DateTime.UtcNow > mySkillQueueEnds)
                    {
                        if (DebugSkillQueue) DirectEve.Log("AgentInteraction: mySkillQueueEnds [" + mySkillQueueEnds + "] is in the past.");
                        mySkillQueueEnds = DateTime.MinValue;
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.mySkillQueueEnds), mySkillQueueEnds);
                    }
                    else if (DateTime.UtcNow != mySkillQueueEnds)
                    {
                        if (DebugSkillQueue) DirectEve.Log("AgentInteraction: mySkillQueueEnds [" + mySkillQueueEnds + "].");
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.mySkillQueueEnds), mySkillQueueEnds);
                    }
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                }

                try
                {
                    if (DirectEve.Skills.MySkillQueue != null && DirectEve.Skills.MySkillQueue.Any())
                    {
                        DirectSkill mySkillTraining = DirectEve.Skills.MySkillQueue.FirstOrDefault();
                        if (mySkillTraining != null)
                        {
                            if (DebugSkillQueue) DirectEve.Log("AgentInteraction: mySkillTraining [" + mySkillTraining.TypeName + "] ");
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, nameof(EveAccount.mySkillTraining), mySkillTraining.TypeName);
                        }
                    }
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                }
            }
            catch (Exception ex)
            {
                DirectEve.Log("Exception [" + ex + "]");
            }
        }

        #endregion Properties

        #region Methods

        public bool StorylineAgent
        {
            get
            {
                if (AgentTypeName.Contains("Storyline"))
                    return true;

                return false;
            }
        }

        public static Dictionary<string, long> GetAllAgents(DirectEve directEve)
        {
            Dictionary<string, long> ret = new Dictionary<string, long>();

            Dictionary<long, PyObject> agentsById = directEve.GetLocalSvc("agents").Attribute("allAgentsByID").Attribute("items").ToDictionary<long>();
            foreach (KeyValuePair<long, PyObject> agent in agentsById)
            {
                DirectOwner owner = DirectOwner.GetOwner(directEve, agent.Key);
                if (ret.ContainsKey(owner.Name))
                    continue;
                ret.AddOrUpdate(owner.Name, agent.Key);
            }
            return ret;
        }

        public static bool IsAgentsByIdDictionaryPopulated(DirectEve directEve)
        {
            return directEve.GetLocalSvc("agents").Attribute("allAgents").IsValid;
        }

        public static void PopulateAgentsByIdDictionary(DirectEve directEve)
        {
            if (!IsAgentsByIdDictionaryPopulated(directEve))
                directEve.ThreadedLocalSvcCall("agents", "GetAgentsByID");
        }

        public bool InteractWith()
        {
            if (!DirectEve.Interval(1200, 2000))
                return false;

            return DirectEve.ThreadedLocalSvcCall("agents", "InteractWith", PyAgentId);
        }

        internal static DirectAgent GetAgentById(DirectEve directEve, long id)
        {
            PyObject pyAgent = directEve.GetLocalSvc("agents").Attribute("allAgentsByID").Attribute("items").DictionaryItem(id);

            DirectAgent agent = new DirectAgent(directEve);
            agent.IsValid = pyAgent.IsValid;
            agent.PyAgentId = pyAgent.Item(0);
            agent.AgentId = (long)pyAgent.Item(0);
            agent.AgentTypeId = (long)pyAgent.Item(1);
            agent.DivisionId = (long)pyAgent.Item(2); //`crpNPCDivisions` VALUES (1,'Accounting','DEPRECATED DIVISION - DO NOT USE','CFO'),(2,'Administration','DEPRECATED DIVISION - DO NOT USE','CFO'),(3,'Advisory','DEPRECATED DIVISION - DO NOT USE','Chief Advisor'),(4,'Archives','DEPRECATED DIVISION - DO NOT USE','Chief Archivist'),(5,'Astrosurveying','DEPRECATED DIVISION - DO NOT USE','Survey Manager'),(6,'Command','DEPRECATED DIVISION - DO NOT USE','COO'),(7,'Distribution','DEPRECATED DIVISION - DO NOT USE','Distribution Manager'),(8,'Financial','DEPRECATED DIVISION - DO NOT USE','CFO'),(9,'Intelligence','DEPRECATED DIVISION - DO NOT USE','Chief Operative'),(10,'Internal Security','DEPRECATED DIVISION - DO NOT USE','Commander'),(11,'Legal','DEPRECATED DIVISION - DO NOT USE','Principal Clerk'),(12,'Manufacturing','DEPRECATED DIVISION - DO NOT USE','Assembly Manager'),(13,'Marketing','DEPRECATED DIVISION - DO NOT USE','Market Manager'),(14,'Mining','DEPRECATED DIVISION - DO NOT USE','Mining Coordinator'),(15,'Personnel','DEPRECATED DIVISION - DO NOT USE','Chief of Staff'),(16,'Production','DEPRECATED DIVISION - DO NOT USE','Production Manager'),(17,'Public Relations','DEPRECATED DIVISION - DO NOT USE','Chief Coordinator'),(18,'R&D','Research and development division','Chief Researcher'),(19,'Security','DEPRECATED DIVISION - DO NOT USE','Commander'),(20,'Storage','DEPRECATED DIVISION - DO NOT USE','Storage Facilitator'),(21,'Surveillance','DEPRECATED DIVISION - DO NOT USE','Chief Scout'),(22,'Distribution','New distribution division','Distribution Manager'),(23,'Mining','New mining division','Mining Coordinator'),(24,'Security','New security division','Commander'),(25,'Business','Business career','Chief Advisor'),(26,'Exploration','Exploration career','Chief Advisor'),(27,'Industry','Industry career','Chief Advisor'),(28,'Military','Military career','Chief Advisor'),(29,'Advanced Military','Advanced Military career','Chief Advisor');
            if (Divisions != null && Divisions.Any(x => x.Key == agent.DivisionId))
                agent.DivisionName = Divisions.FirstOrDefault(x => x.Key == agent.DivisionId).Value;
            agent.Level = int.Parse(pyAgent.Item(3).Repr);
            agent.BloodlineId = long.Parse(pyAgent.Item(5).Repr);
            agent.Quality = int.Parse(pyAgent.Item(6).Repr);
            agent.CorpId = long.Parse(pyAgent.Item(7).Repr);
            agent.Gender = bool.Parse(pyAgent.Item(8).Repr);
            agent.FactionId = long.Parse(pyAgent.Item(10).Repr);
            agent.SolarSystemId = long.Parse(pyAgent.Item(11).Repr);
            try
            {
                //
                // ignore exceptions for agents that arent in stations
                //
                if (!string.IsNullOrEmpty(pyAgent.Item(4).Repr))
                    agent.StationId = long.Parse(pyAgent.Item(4).Repr);
            }
            catch (Exception)
            {
                //Log.WriteLine("Agent [" + agent.Name + "] must be an agent in space");
                //Log.WriteLine("Exception [" + ex + "]");
            }

            /**
            try
            {
                for (int a=1; a < 12; a++)
                {
                    Log.WriteLine("Key [ pyAgent.Item(" + a + ") ] Value [" + pyAgent.Item(a).ToString() + "] pyType [" + pyAgent.Item(a).GetPyType() + "][" + pyAgent.Item(a).Repr.ToString() + "]");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
            **/

            return agent;
        }

        internal static DirectAgent GetAgentByName(DirectEve directEve, string name)
        {
            if (AgentLookupDict.Count == 0)
            {
                Dictionary<long, PyObject> agentsById = directEve.GetLocalSvc("agents").Attribute("allAgentsByID").Attribute("items").ToDictionary<long>();
                foreach (KeyValuePair<long, PyObject> agent in agentsById)
                {
                    DirectOwner owner = DirectOwner.GetOwner(directEve, agent.Key);
                    AgentLookupDict[owner.Name.ToLower()] = agent.Key;
                }
            }

            if (AgentLookupDict.TryGetValue(name.ToLower(), out var id))
                return GetAgentById(directEve, id);
            directEve.Log("AgentLookupDict error. Agent not found?");
            return null;
        }

        #endregion Methods
    }
}