﻿extern alias SC;

using SC::SharedComponents.Py;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Framework
{
    public enum DurationComboValue
    {
        IMMEDIATE = 0,
        DAY = 1,
        THREEDAYS = 3,
        WEEK = 7,
        TWOWEEKS = 14,
        MONTH = 30,
        THREEMONTHS = 90
    }

    public class DirectMultiSellWindow : DirectWindow
    {
        #region Fields

        private List<double> _getSums;

        #endregion Fields

        #region Constructors

        internal DirectMultiSellWindow(DirectEve directEve, PyObject pyWindow) : base(directEve, pyWindow)
        {
        }

        #endregion Constructors

        #region Properties

        public bool AddingItemsThreadRunning => !PyWindow.Attribute("addItemsThread").Attribute("endTime").IsValid;
        public long BaseStationId => PyWindow.Attribute("baseStationID").ToLong();

        public double BrokersFee => GetSums()[0];

        public double SalesTax => GetSums()[1];
        public double TotalSum => GetSums()[2];

        #endregion Properties

        #region Methods

        public void Cancel()
        {
            DirectEve.ThreadedCall(PyWindow.Attribute("Cancel"));
        }

        public DurationComboValue GetDurationComboValue()
        {
            int val = PyWindow.Attribute("durationCombo").Attribute("selectedValue").ToInt();
            return (DurationComboValue) val;
        }

        public List<DirectMultiSellWindowItem> GetSellItems()
        {
            List<DirectMultiSellWindowItem> ret = new List<DirectMultiSellWindowItem>();
            List<PyObject> list = PyWindow.Attribute("itemList").ToList();
            foreach (PyObject item in list)
                ret.Add(new DirectMultiSellWindowItem(DirectEve, item));
            return ret;
        }

        public void PerformTrade()
        {
            if (GetSellItems().All(i => !i.HasBid))
            {
                DirectEve.Log($"Can't perform trade, only items without a bid are within the sell list.");
                return;
            }
            DirectEve.ThreadedCall(PyWindow.Attribute("PerformTrade"));
        }

        public void SetDurationCombovalue(DurationComboValue v)
        {
            PyWindow.Attribute("durationCombo").Call("SetValue", (int) v);
        }

        private List<double> GetSums()
        {
            if (_getSums == null)
            {
                List<double> obj = PyWindow.Call("GetSums").ToList<double>();
                if (obj.Count > 2)
                    obj[2] = obj[2] - obj[1] - obj[0];
                _getSums = obj;
            }
            return _getSums;
        }

        #endregion Methods
    }
}