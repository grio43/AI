﻿using System;

namespace SharedComponents.Py.Frameworks
{
    public interface IFramework : IDisposable
    {
        #region Methods

        void RegisterFrameHook(EventHandler<EventArgs> frameHook);

        void RegisterLogger(EventHandler<EventArgs> logger);

        #endregion Methods
    }
}