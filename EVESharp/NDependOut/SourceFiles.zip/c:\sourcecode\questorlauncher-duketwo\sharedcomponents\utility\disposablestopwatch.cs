﻿using System;
using System.Diagnostics;

namespace SharedComponents.Utility
{
    public class DisposableStopwatch : IDisposable
    {
        #region Constructors

        public DisposableStopwatch(Action<TimeSpan> f)
        {
            this.f = f;
            sw = Stopwatch.StartNew();
        }

        #endregion Constructors

        #region Methods

        public void Dispose()
        {
            sw.Stop();
            f(sw.Elapsed);
        }

        #endregion Methods

        #region Fields

        private readonly Action<TimeSpan> f;
        private readonly Stopwatch sw;

        #endregion Fields
    }
}

//using (new DisposableStopwatch(t =>
//{
//Console.WriteLine($"{1000000 * t.Ticks / Stopwatch.Frequency} ns elapsed.");
//Console.WriteLine($"{(1000000 * t.Ticks / Stopwatch.Frequency) / 1000} ms elapsed.");
//}))
//{
//int a = 3;
//int b = 1;
//    for (int i = 0; i< 1000 * 1000; i++)
//{
//    var k = a == b;
//}

//}