using EVESharpCore.Cache;
using EVESharpCore.Logging;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Lookup;
using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Framework;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.Stats;
using Action = EVESharpCore.Questor.Actions.Base.Action;

namespace EVESharpCore.Questor.Actions
{
    public partial class ActionControl
    {
        #region Methods

        private static void AbyssalLootAction_WeAreDoneLooting(string WeAreDoneLootingLogMessage)
        {
            Log.WriteLine(WeAreDoneLootingLogMessage);

            // now that we are done with this action revert OpenWrecks to false

            if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
            {
                if (DebugConfig.DebugTargetWrecks) Log.WriteLine("Salvage.OpenWrecks = false;");
                Salvage.OpenWrecks = false;
            }

            //Salvage.MissionLoot = false;
            Salvage.CurrentlyShouldBeSalvaging = false;
            Nextaction(null, null);
            return;
        }

        private static void AbyssalLootAction(Action action)
        {
            try
            {
                // if we are not generally looting we need to re-enable the opening of wrecks to
                // find this LootItems we are looking for
                Salvage.OpenWrecks = true;
                Salvage.CurrentlyShouldBeSalvaging = true;

                // unlock targets count
                //Salvage.MissionLoot = true;

                //
                // sorting by distance is bad if we are moving (we'd change targets unpredictably)... sorting by ID should be better and be nearly the same(?!)
                //
                if (ESCache.Instance.Containers == null) return;
                IOrderedEnumerable<EntityCache> containers = ESCache.Instance.Containers.Where(e => !ESCache.Instance.LootedContainers.Contains(e.Id))
                    .OrderBy(i => i.IsWreck)
                    .ThenBy(e => e.IsWreckEmpty)
                    .ThenBy(e => e.Distance);

                if (DebugConfig.DebugLootWrecks)
                {
                    int i = 0;
                    foreach (EntityCache _container in containers)
                    {
                        i++;
                        Log.WriteLine("[" + i + "] " + _container.Name + "[" + Math.Round(_container.Distance / 1000, 0) + "k] isWreckEmpty [" +
                                      _container.IsWreckEmpty +
                                      "] IsTarget [" + _container.IsTarget + "]");
                    }

                    i = 0;
                    foreach (long _containerToLoot in ESCache.Instance.ListofContainersToLoot)
                    {
                        i++;
                        Log.WriteLine("_containerToLoot [" + i + "] ID[ " + _containerToLoot + " ]");
                    }
                }

                if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway)
                {
                    AbyssalLootAction_WeAreDoneLooting("LootAction: We are in the room with tons of BSs, gate should be unlocked: skip looting");
                    return;
                }

                //
                // in Abyssal Deadspace if we have no Triglavian Bioadaptive Cache Wreck yet, wait: they are indestructable, so if we dont have one we arent ready yet
                //
                string NameofWreck = "Wreck";
                if (!ESCache.Instance.Wrecks.Any())
                {
                    Log.WriteLine("LootAction: There are no wrecks on grid yet, waiting");
                    return;
                }

                if (DateTime.UtcNow > _currentActionStarted.AddSeconds(Salvage.SecondsWaitForLootAction))
                {
                    if (Salvage.TractorBeams.All(i => !i.IsActive) || DateTime.UtcNow > _currentActionStarted.AddSeconds(Salvage.SecondsWaitForLootAction + 30))
                    {
                        try
                        {
                            Statistics.WriteWreckOutOfRangeLootSkipLog();
                        }
                        catch (Exception){} //swallow any exceptions writing the log

                        AbyssalLootAction_WeAreDoneLooting("LootAction: We must be stuck: skipping loot! secondsWaitForLootAction [" + Salvage.SecondsWaitForLootAction + "] sec have passed and all tractors are off");
                        return;
                    }
                }

                if (containers.Any(i => i.Name.ToLower() == NameofWreck.ToLower() && !i.IsTarget && !i.IsTargeting))
                    if (!Salvage.TargetWrecks(containers.Where(i => i.Name.ToLower() == NameofWreck.ToLower() && !i.IsTarget && !i.IsTargeting))) return;

                if (!containers.Any() || containers.All(i => i.GroupId != (int)Group.SpawnContainer && i.IsWreckEmpty))
                {
                    AbyssalLootAction_WeAreDoneLooting("LootAction: We are done looting");
                }

                //
                // add containers that we were told to loot into the ListofContainersToLoot so that they are prioritized by the background salvage routine
                //

                foreach (EntityCache continerToLoot in containers)
                    if (continerToLoot.Name == NameofWreck)
                        if (!ESCache.Instance.ListofContainersToLoot.Contains(continerToLoot.Id))
                            ESCache.Instance.ListofContainersToLoot.Add(continerToLoot.Id);

                EntityCache wreckToLoot = null;
                if (ESCache.Instance.Containers == null) return;
                if (ESCache.Instance.Containers.Any(i => i.GroupId != (int)Group.SpawnContainer && !i.IsWreckEmpty))
                {
                    wreckToLoot = ESCache.Instance.Containers.FirstOrDefault(i => i.GroupId != (int)Group.SpawnContainer && !i.IsWreckEmpty);
                    if (wreckToLoot != null)
                    {
                        if (Salvage.TractorBeams.Any() && Salvage.TractorBeamRange != null)
                        {
                            if (wreckToLoot.Distance > Salvage.TractorBeamRange - 1000)
                            {
                                if (Salvage.TractorBeams.All(i => !i.IsActive) && DateTime.UtcNow > Time.Instance.NextTractorBeamAction.AddSeconds(3))
                                {
                                    NavigateOnGrid.NavigateToTarget(wreckToLoot, 500);
                                    return;
                                }
                            }
                        }
                        else if (wreckToLoot.Distance > (int)Distances.ScoopRange)
                        {
                            NavigateOnGrid.NavigateToTarget(wreckToLoot, 500);
                        }

                        Salvage.TargetWrecks(ESCache.Instance.Containers.Where(i => i.IsWreck && !i.IsWreckEmpty));
                        Salvage.LootWrecks();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        #endregion Methods
    }
}