﻿using System;
using System.Collections.Generic;

namespace SharedComponents.FastPriorityQueue
{
    public class PriorityQueue<T>
    {
        // I'm using an unsorted array for this example, but ideally this
        // would be a binary heap. Find a binary heap class:
        // * https://bitbucket.org/BlueRaja/high-speed-priority-queue-for-c/wiki/Home
        // * http://visualstudiomagazine.com/articles/2012/11/01/priority-queues-with-c.aspx
        // * http://xfleury.github.io/graphsearch.html
        // * http://stackoverflow.com/questions/102398/priority-queue-in-net

        #region Fields

        private readonly List<Tuple<T, double>> elements = new List<Tuple<T, double>>();

        #endregion Fields

        #region Properties

        public int Count => elements.Count;

        #endregion Properties

        #region Methods

        public T Dequeue()
        {
            int bestIndex = 0;

            for (int i = 0; i < elements.Count; i++)
                if (elements[i].Item2 < elements[bestIndex].Item2)
                    bestIndex = i;

            T bestItem = elements[bestIndex].Item1;
            elements.RemoveAt(bestIndex);
            return bestItem;
        }

        public void Enqueue(T item, double priority)
        {
            elements.Add(Tuple.Create(item, priority));
        }

        #endregion Methods
    }
}