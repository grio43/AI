extern alias SC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.Stats;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Questor.BackgroundTasks
{
    public static class NavigateOnGrid
    {
        #region Fields

        public static DateTime AvoidBumpingThingsTimeStamp = Time.Instance.QuestorStarted_DateTime;
        public static bool AvoidBumpingThingsWarningSent;
        public static DateTime LastWarpScrambled = DateTime.UtcNow;
        public static int SafeDistanceFromStructureMultiplier = 1;
        public static long? StationIdToGoto;
        private static DateTime _nextWarpScrambledWarning = DateTime.UtcNow;
        private static int? _orbitDistance;
        private static int? _orbitDistanceToUse;
        private static EntityCache _stationToGoTo;
        public static DateTime NextAvoidBumpingThings { get; set; } = DateTime.UtcNow;
        public static DateTime NextNavigateIntoRange { get; set; } = DateTime.UtcNow;

        #endregion Fields

        #region Properties

        private static bool? _abyssalLargeAvoidBumpingThingsBool;

        private static bool? _abyssalMediumAvoidBumpingThingsBool;

        //private static bool? _avoidBumpingThingsBool;
        private static bool? _abyssalSmallAvoidBumpingThingsBool;

        private static int _intWeAreMovingSlowlyAgainAbyssalLarge;
        private static int _intWeAreMovingSlowlyAgainAbyssalMedium;
        private static int _intWeAreMovingSlowlyAgainAbyssalSmall;
        private static DateTime _nextAvoidBumpingThingsReset = DateTime.UtcNow;

        public static bool GlobalAvoidBumpingThingsBool { get; set; }

        public static int OptimalRange
        {
            get
            {
                try
                {
                    if (MissionSettings.MissionOptimalRange != null)
                        return (int) MissionSettings.MissionOptimalRange;

                    //
                    // This must mean we have drones only?!
                    //
                    if (Drones.UseDrones && Drones.DronesKillHighValueTargets)
                    {
                        _optimalRange = (int) Drones.MaxDroneRange;
                        _optimalRange = (int) Math.Min(Drones.MaxDroneRange, ESCache.Instance.ActiveShip.MaxTargetRange);
                        if (ESCache.Instance.WebRange != null)
                            _optimalRange = (int) Math.Min((double) _optimalRange, (double) ESCache.Instance.WebRange);

                        _optimalRange = (int)Math.Min((double)_optimalRange, (double)ESCache.Instance.WeaponRange);
                        return _optimalRange ?? 10000;
                    }

                    if (ESCache.Instance.Weapons != null && ESCache.Instance.Weapons.Any())
                    {
                        ModuleCache weapon = ESCache.Instance.Weapons.FirstOrDefault();
                        if (weapon != null)
                        {
                            if (weapon.OptimalRange != 0)
                            {
                                if (Combat.Combat.DoWeCurrentlyProjectilesMounted())
                                {
                                    _optimalRange = (int) weapon.OptimalRange + (int) (weapon.FallOff * .50);
                                    _optimalRange = (int) Math.Min((double) _optimalRange, ESCache.Instance.ActiveShip.MaxTargetRange);
                                    if (ESCache.Instance.WebRange != null)
                                        _optimalRange = (int) Math.Min((double) _optimalRange, (double) ESCache.Instance.WebRange);

                                    _optimalRange = (int)Math.Min((double)_optimalRange, (double)ESCache.Instance.WeaponRange);
                                    return _optimalRange ?? 10000;
                                }

                                //
                                // any type of turret: hybrid or lasers in this case
                                //
                                if (Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                                {
                                    _optimalRange = (int) weapon.OptimalRange + (int) (weapon.FallOff * .50);
                                    _optimalRange = (int) Math.Min((double) _optimalRange, ESCache.Instance.ActiveShip.MaxTargetRange);
                                    if (ESCache.Instance.WebRange != null)
                                        _optimalRange = (int) Math.Min((double) _optimalRange, (double) ESCache.Instance.WebRange);

                                    _optimalRange = (int)Math.Min((double)_optimalRange, (double)ESCache.Instance.WeaponRange);
                                    return _optimalRange ?? 10000;
                                }
                            }

                            //
                            // If we have any weapons this means we have missiles: return 0 for missiles
                            //
                            return 0;
                        }

                        return 0;
                    }

                    return _optimalRange ?? 0;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return 10000;
                }
            }
        }

        public static int OrbitDistance
        {
            get => _orbitDistance ?? 2000;
            set => _orbitDistance = value;
        }

        public static int OrbitDistanceToUse
        {
            get
            {
                _orbitDistanceToUse = OrbitDistance;

                if (MissionSettings.MissionOrbitDistance != null)
                    _orbitDistanceToUse = (int) MissionSettings.MissionOrbitDistance;

                if (_orbitDistanceToUse == 0)
                    _orbitDistanceToUse = 1000;

                if (!ESCache.Instance.InAbyssalDeadspace)
                    if (_orbitDistanceToUse > ESCache.Instance.WeaponRange)
                        _orbitDistanceToUse = Math.Min(4000, ESCache.Instance.WeaponRange - 1000);

                if (!Combat.Combat.PotentialCombatTargets.Any())
                    _orbitDistanceToUse = 500;

                //if (Combat.Combat.DoWeCurrentlyHaveTurretsMounted() && QCache.Instance.Targets.FirstOrDefault(i => i.IsFrigate) != null)
                //{
                //    Log.WriteLine("Target is a frigate and we have turrets mounted, using three times the usual orbit distance.");
                //    _orbitDistanceToUse = OrbitDistanceToUse * 3;
                //}

                return _orbitDistanceToUse ?? 2000;
            }
        }

        public static bool GlobalOrbitStructure { get; set; }

        public static bool OrbitStructure
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    if (ESCache.Instance.MyShipEntity.IsFrigate && Combat.Combat.PotentialCombatTargets.Any())
                    {
                        return false;
                    }

                    if (SpeedTank && Combat.Combat.PotentialCombatTargets.Any())
                    {
                        return false;
                    }

                    return true;
                }

                return GlobalOrbitStructure;
            }
        }

        public static bool SpeedTank
        {
            get
            {
                if (SpeedTankMissionSetting != null)
                    return (bool) SpeedTankMissionSetting;

                if (SpeedTankGlobalSetting != null)
                    return (bool) SpeedTankGlobalSetting;

                return false;
            }
        }

        public static bool? SpeedTankGlobalSetting { get; set; }

        public static bool? SpeedTankMissionSetting { get; set; }

        public static EntityCache StationToGoTo
        {
            get
            {
                try
                {
                    if (StationIdToGoto == null)
                    {
                        if (DebugConfig.DebugTraveler) Log.WriteLine("stationToGoTo: if (stationIDToGoto == null)");
                        return null;
                    }

                    if (!ESCache.Instance.Stations.Any())
                    {
                        if (DebugConfig.DebugTraveler) Log.WriteLine("stationToGoTo: No Stations");
                        return null;
                    }

                    if (ESCache.Instance.Stations.Any())
                    {
                        if (ESCache.Instance.Stations.Any(i => i.Id == StationIdToGoto))
                        {
                            if (DebugConfig.DebugTraveler) Log.WriteLine("stationToGoTo: if (QCache.Instance.Stations.Any(i => i.Id == stationIDToGoto))");
                            _stationToGoTo = ESCache.Instance.Stations.FirstOrDefault(i => i.Id == StationIdToGoto);
                            return _stationToGoTo;
                        }

                        if (DebugConfig.DebugTraveler) Log.WriteLine("stationToGoTo: if (QCache.Instance.Stations.All(i => i.Id != stationIDToGoto))");
                        return null;
                    }

                    if (DebugConfig.DebugTraveler) Log.WriteLine("stationToGoTo: No Stations?!");
                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public static int TooCloseToStructure
        {
            get
            {
                if (!ESCache.Instance.InAbyssalDeadspace && MissionSettings.MissionTooCloseToStructure != null)
                    return (int) MissionSettings.MissionTooCloseToStructure;

                return (int) Distances.TooCloseToStructure;
            }
        }

        private static int? _optimalRange { get; set; }

        private static int SafeDistanceFromStructure
        {
            get
            {
                if (!ESCache.Instance.InAbyssalDeadspace && MissionSettings.MissionSafeDistanceFromStructure != null)
                    return (int) MissionSettings.MissionSafeDistanceFromStructure;

                return (int) Distances.SafeDistancefromStructure;
            }
        }

        public static bool AbyssalLargeAvoidBumpingThingsBool(bool avoidBumpingThingsOnlyIfGoingSlow)
        {
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (!avoidBumpingThingsOnlyIfGoingSlow)
                    return true;

                if (DateTime.UtcNow > _nextAvoidBumpingThingsReset)
                {
                    AvoidBumpingThingsTimeStamp = DateTime.UtcNow;
                    lastTooCloseToEntity = DateTime.UtcNow.AddHours(-5);
                    SafeDistanceFromStructureMultiplier = 1;
                    AvoidBumpingThingsWarningSent = false;
                    _intWeAreMovingSlowlyAgainAbyssalLarge = 0;
                    _abyssalLargeAvoidBumpingThingsBool = null;
                    return false;
                }

                if (_abyssalLargeAvoidBumpingThingsBool == null)
                {
                    if (WeAreMovingVerySlowly)
                    {
                        Log.WriteLine("Abyssal_AvoidBumpingIntoThings: We are moving less than Max Velocity [" + Math.Round(ESCache.Instance.ActiveShip.MaxVelocity, 0) + "m/s] * .30 [" + Math.Round(ESCache.Instance.MyShipEntity.Velocity, 0) + "m/s]: _intWeAreMovingSlowlyAgainAbyssalMedium [" + _intWeAreMovingSlowlyAgainAbyssalMedium + "]");
                        _intWeAreMovingSlowlyAgainAbyssalLarge++;
                        if (_intWeAreMovingSlowlyAgainAbyssalLarge >= 2)
                        {
                            _nextAvoidBumpingThingsReset = DateTime.UtcNow.AddSeconds(60);
                            _abyssalLargeAvoidBumpingThingsBool = true;
                            return (bool) _abyssalLargeAvoidBumpingThingsBool;
                        }
                    }

                    return false;
                }

                return (bool) _abyssalLargeAvoidBumpingThingsBool;
            }

            return GlobalAvoidBumpingThingsBool;
        }

        public static bool AbyssalMediumAvoidBumpingThingsBool(bool avoidBumpingThingsOnlyIfGoingSlow)
        {
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (!avoidBumpingThingsOnlyIfGoingSlow)
                    return true;

                if (_abyssalMediumAvoidBumpingThingsBool != null && (bool) _abyssalMediumAvoidBumpingThingsBool && DateTime.UtcNow > _nextAvoidBumpingThingsReset)
                {
                    Log.WriteLine("AbyssalMediumAvoidBumpingThingsBool: It has been 60 sec: resetting _abyssalMediumAvoidBumpingThingsBool to false");
                    AvoidBumpingThingsTimeStamp = DateTime.UtcNow;
                    lastTooCloseToEntity = DateTime.UtcNow.AddHours(-5);
                    SafeDistanceFromStructureMultiplier = 1;
                    AvoidBumpingThingsWarningSent = false;
                    _intWeAreMovingSlowlyAgainAbyssalMedium = 0;
                    _abyssalMediumAvoidBumpingThingsBool = null;
                    return false;
                }

                if (_abyssalMediumAvoidBumpingThingsBool == null)
                {
                    if (WeAreMovingVerySlowly)
                    {
                        _intWeAreMovingSlowlyAgainAbyssalMedium++;
                        if (_intWeAreMovingSlowlyAgainAbyssalMedium >= 2)
                        {
                            Log.WriteLine("AbyssalMediumAvoidBumpingThingsBool: Is now true: _intWeAreMovingSlowlyAgainAbyssalMedium [" + _intWeAreMovingSlowlyAgainAbyssalMedium + "]");
                            _nextAvoidBumpingThingsReset = DateTime.UtcNow.AddSeconds(60);
                            _abyssalMediumAvoidBumpingThingsBool = true;
                            return (bool) _abyssalMediumAvoidBumpingThingsBool;
                        }

                        Log.WriteLine("AbyssalMediumAvoidBumpingThingsBool: We are moving less than Max Velocity [" + Math.Round(ESCache.Instance.ActiveShip.MaxVelocity, 0) + "m/s] * .30 [" + Math.Round(ESCache.Instance.MyShipEntity.Velocity, 0) + "m/s]: _intWeAreMovingSlowlyAgainAbyssalMedium [" + _intWeAreMovingSlowlyAgainAbyssalMedium + "]");
                        return false;
                    }

                    return false;
                }

                return (bool) _abyssalMediumAvoidBumpingThingsBool;
            }

            return GlobalAvoidBumpingThingsBool;
        }

        public static bool AbyssalSmallAvoidBumpingThingsBool(bool avoidBumpingThingsOnlyIfGoingSlow)
        {
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (!avoidBumpingThingsOnlyIfGoingSlow)
                    return true;

                if (DateTime.UtcNow > _nextAvoidBumpingThingsReset)
                {
                    AvoidBumpingThingsTimeStamp = DateTime.UtcNow;
                    lastTooCloseToEntity = DateTime.UtcNow.AddHours(-5);
                    SafeDistanceFromStructureMultiplier = 1;
                    AvoidBumpingThingsWarningSent = false;
                    _intWeAreMovingSlowlyAgainAbyssalSmall = 0;
                    _abyssalSmallAvoidBumpingThingsBool = null;
                    return false;
                }

                if (_abyssalSmallAvoidBumpingThingsBool == null)
                {
                    if (WeAreMovingVerySlowly)
                    {
                        Log.WriteLine("Abyssal_AvoidBumpingIntoThings: We are moving less than Max Velocity [" + Math.Round(ESCache.Instance.ActiveShip.MaxVelocity, 0) + "m/s] * .30 [" + Math.Round(ESCache.Instance.MyShipEntity.Velocity, 0) + "m/s]: _intWeAreMovingSlowlyAgainAbyssalMedium [" + _intWeAreMovingSlowlyAgainAbyssalMedium + "]");
                        _intWeAreMovingSlowlyAgainAbyssalSmall++;
                        if (_intWeAreMovingSlowlyAgainAbyssalSmall >= 2)
                        {
                            _nextAvoidBumpingThingsReset = DateTime.UtcNow.AddSeconds(60);
                            _abyssalSmallAvoidBumpingThingsBool = true;
                            return (bool) _abyssalSmallAvoidBumpingThingsBool;
                        }
                    }

                    return false;
                }

                return (bool) _abyssalSmallAvoidBumpingThingsBool;
            }

            return GlobalAvoidBumpingThingsBool;
        }

        public static bool AvoidBumpingThingsBool()
        {
            if (ESCache.Instance.InMission && MissionSettings.SelectedControllerUsesCombatMissionsBehavior)
            {
                if (MissionSettings.MyMission != null && MissionSettings.MyMission.Agent.Level == 1)
                    return true;

                if (MissionSettings.MyMission != null && MissionSettings.MyMission.Agent.Level == 2)
                    return true;

                if (MissionSettings.MyMission != null && MissionSettings.MyMission.Agent.Level == 3)
                    return true;

                if (MissionSettings.MyMission != null && MissionSettings.MyMission.Agent.Level == 4)
                {
                    switch (MissionSettings.MyMission.Name)
                    {
                        case "Cargo Delivery":
                        case "The Damsel In Distress":
                            return false;
                    }

                    if (MissionSettings.MyMission.Name.Contains("Anomic"))
                        return false;
                }

                if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name.ToLower() == "Worlds Collide".ToLower())
                    if (ESCache.Instance.EntitiesOnGrid != null && ESCache.Instance.EntitiesOnGrid.Any(i => i.Name.ToLower().Contains("Damaged Heron".ToLower())))
                        return false;
            }

            return GlobalAvoidBumpingThingsBool;
        }

        public static void ClearPerPocketCache()
        {
            AvoidBumpingThingsTimeStamp = DateTime.UtcNow;
            SafeDistanceFromStructureMultiplier = 1;
        }

        #endregion Properties

        #region Methods

        private static IOrderedEnumerable<EntityCache> _navigateOnGridTargets;
        private static readonly bool AvoidBumpingThingsOnlyIfGoingSlow = true;
        private static DateTime lastTooCloseToEntity = DateTime.UtcNow;
        private static DateTime NextLogWhereAmIOnGrid = DateTime.UtcNow;

        public static IOrderedEnumerable<EntityCache> ChooseNavigateOnGridTargets
        {
            get
            {
                try
                {
                    if (Combat.Combat.PotentialCombatTargets.Any())
                    {
                        if (ESCache.Instance.InWormHoleSpace)
                        {
                            if (ESCache.Instance.ActiveShip.GroupId == (int) Group.Dreadnaught)
                            {
                                //do not even try to move in a dread, siege or not its just a bad idea.
                                return null;
                            }

                            //do not move regardless (maybe we want this to orbit the anchor?
                            return null;
                        }

                        if (ESCache.Instance.InAbyssalDeadspace)
                        {
                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("ChooseNavigateOnGridTargets: if (ESCache.Instance.InAbyssalDeadspace)");
                            if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs)
                            {
                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("ChooseNavigateOnGridTargets: if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs)");
                                if (AbyssalDeadspace_14BsSpawn_NavigateOnGridTargets.Any())
                                    return AbyssalDeadspace_14BsSpawn_NavigateOnGridTargets;
                            }

                            if (ESCache.Instance.MyShipEntity.IsFrigate)
                            {
                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("ChooseNavigateOnGridTargets: if (ESCache.Instance.ActiveShip.GroupId == (int)Group.AssaultShip)");
                                if (AbyssalDeadspace_FrigateNavigateOnGridTargets.Any())
                                    return AbyssalDeadspace_FrigateNavigateOnGridTargets;

                                return null;
                            }

                            if (AbyssalDeadspace_NavigateOnGridTargets.Any())
                                return AbyssalDeadspace_NavigateOnGridTargets;

                            return null;
                        }

                        if (ESCache.Instance.InMission)
                            if (ESCache.Instance.MyShipEntity != null)
                            {
                                if (ESCache.Instance.MyShipEntity.IsFrigate)
                                {
                                    if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsFrigate)");
                                    if (PickNavigateOnGridTarget_BasedOnTargetsForAFrigate.Any())
                                        return PickNavigateOnGridTarget_BasedOnTargetsForAFrigate;

                                    return null;
                                }

                                if (ESCache.Instance.MyShipEntity.IsCruiser)
                                {
                                    if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsCruiser)");
                                    if (PickNavigateOnGridTarget_BasedOnTargetsForACruiser.Any())
                                        return PickNavigateOnGridTarget_BasedOnTargetsForACruiser;

                                    return null;
                                }

                                if (ESCache.Instance.MyShipEntity.IsBattleship)
                                {
                                    if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsBattleship)");
                                    if (PickNavigateOnGridTarget_BasedOnTargetsForABattleship.Any())
                                        return PickNavigateOnGridTarget_BasedOnTargetsForABattleship;

                                    return null;
                                }

                                //
                                // Default to picking targets for a battleship sized ship
                                //
                                if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) MyShipEntity class unknown");
                                if (PickNavigateOnGridTarget_BasedOnTargetsForABattleship.Any())
                                    return PickNavigateOnGridTarget_BasedOnTargetsForABattleship;

                                return null;
                            }

                        return null;
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public static IOrderedEnumerable<EntityCache> PickNavigateOnGridTarget_BasedOnTargetsForABattleship
        {
            get
            {
                IOrderedEnumerable<EntityCache> _navigateOnGridTargets = Combat.Combat.PotentialCombatTargets.Where(i => !i.IsContainer && !i.IsBadIdea && !i.IsNPCDrone)
                    .OrderByDescending(k => k.isPreferredPrimaryWeaponTarget)
                    .ThenByDescending(i => i.IsTargetedBy)
                    .ThenByDescending(i => i.IsAttacking)
                    .ThenByDescending(i => i.IsNPCBattleship && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser)
                    .ThenByDescending(i => i.IsNPCCruiser && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWebbingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWebbingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate);

                if (DebugConfig.DebugLogOrderOfNavigateOnGridTargets)
                    LogOrderOfNavigateOnGridTargets(_navigateOnGridTargets);

                return _navigateOnGridTargets;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickNavigateOnGridTarget_BasedOnTargetsForACruiser
        {
            get
            {
                IOrderedEnumerable<EntityCache> _navigateOnGridTargets = Combat.Combat.PotentialCombatTargets.Where(i => !i.IsContainer && !i.IsBadIdea && !i.IsNPCDrone)
                    .OrderByDescending(k => k.isPreferredPrimaryWeaponTarget)
                    .ThenByDescending(i => i.IsTargetedBy)
                    .ThenByDescending(i => i.IsAttacking)
                    .ThenByDescending(i => i.IsNPCFrigate && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWebbingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate)
                    .ThenByDescending(i => i.IsNPCCruiser && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWebbingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser)
                    .ThenByDescending(i => i.IsNPCBattleship && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship);

                if (DebugConfig.DebugLogOrderOfNavigateOnGridTargets)
                    LogOrderOfNavigateOnGridTargets(_navigateOnGridTargets);

                return _navigateOnGridTargets;
            }
        }

        public static IOrderedEnumerable<EntityCache> PickNavigateOnGridTarget_BasedOnTargetsForAFrigate
        {
            get
            {
                IOrderedEnumerable<EntityCache> _navigateOnGridTargets = Combat.Combat.PotentialCombatTargets.Where(i => !i.IsContainer && !i.IsBadIdea && !i.IsNPCDrone)
                    .OrderByDescending(k => k.isPreferredPrimaryWeaponTarget)
                    .ThenByDescending(i => i.IsTargetedBy)
                    .ThenByDescending(i => i.IsAttacking)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisWebbingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCFrigate)
                    .ThenByDescending(i => i.IsNPCCruiser && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWebbingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCCruiser)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCBattlecruiser)
                    .ThenByDescending(i => i.IsNPCBattleship && i.StructurePct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.ArmorPct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.ShieldPct < 90)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisNeutralizingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisWarpScramblingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisJammingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisSensorDampeningNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTrackingDisruptingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTargetPaintingNpc)
                    .ThenByDescending(i => i.IsNPCBattleship);

                if (DebugConfig.DebugLogOrderOfNavigateOnGridTargets)
                    LogOrderOfNavigateOnGridTargets(_navigateOnGridTargets);

                return _navigateOnGridTargets;
            }
        }

        public static List<ModuleCache> tractorBeams
        {
            get
            {
                if (ESCache.Instance.InSpace && ESCache.Instance.Modules != null)
                    return ESCache.Instance.Modules.Where(m => m.GroupId == (int) Group.TractorBeam).ToList();

                return new List<ModuleCache>();
            }
        }

        public static bool WeAreMovingVerySlowly
        {
            get
            {
                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.MyShipEntity != null)
                    if (ESCache.Instance.ActiveShip.MaxVelocity * .3 > ESCache.Instance.MyShipEntity.Velocity)
                        return true;

                return false;
            }
        }

        private static IOrderedEnumerable<EntityCache> AbyssalDeadspace_14BsSpawn_NavigateOnGridTargets
        {
            get
            {
                _navigateOnGridTargets = ESCache.Instance.Entities.Where(i => (i.IsPotentialCombatTarget || i.IsAccelerationGate || i.IsWreck && !i.IsWreckEmpty || i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache) && !i.IsBadIdea && !i.IsNPCDrone)
                    .OrderByDescending(l => l.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway)
                    .ThenByDescending(l => l.IsWreck && !l.IsWreckEmpty && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway)
                    .ThenByDescending(l => l.IsAccelerationGate);

                if (DebugConfig.DebugLogOrderOfNavigateOnGridTargets)
                    LogOrderOfNavigateOnGridTargets(_navigateOnGridTargets);

                if (!Combat.Combat.PotentialCombatTargets.Any())
                    return null;

                return _navigateOnGridTargets;
            }
        }

        private static IOrderedEnumerable<EntityCache> AbyssalDeadspace_EverythingIsInRange
        {
            get
            {
                IOrderedEnumerable<EntityCache> _abyssalDeadspace_EverythingIsInRange = ESCache.Instance.Entities.Where(i => (i.IsAccelerationGate || i.IsWreck && !i.IsWreckEmpty || i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache) && !i.IsBadIdea && !i.IsNPCDrone)
                    .OrderByDescending(l => (!Salvage.TractorBeams.Any() || (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway) && l.IsAbyssalDeadspaceTriglavianBioAdaptiveCache))
                    .ThenByDescending(l => (!Salvage.TractorBeams.Any() || (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway) && l.IsWreck && !l.IsWreckEmpty))
                    .ThenByDescending(l => l.IsAccelerationGate);

                if (DebugConfig.DebugLogOrderOfNavigateOnGridTargets)
                    LogOrderOfNavigateOnGridTargets(_abyssalDeadspace_EverythingIsInRange);

                return _abyssalDeadspace_EverythingIsInRange;
            }
        }

        private static IOrderedEnumerable<EntityCache> AbyssalDeadspace_NavigateOnGridTargets
        {
            get
            {
                _navigateOnGridTargets = ESCache.Instance.Entities.Where(i => (i.IsPotentialCombatTarget || i.IsAccelerationGate || i.IsWreck && !i.IsWreckEmpty || i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache) && !i.IsBadIdea && !i.IsNPCDrone)
                    .OrderByDescending(i => Drones.DronesKillHighValueTargets && i.Distance > Drones.MaxDroneRange && !Drones.DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive)
                    .ThenByDescending(i => !Drones.DronesKillHighValueTargets && i.Distance > Combat.Combat.MaxRange)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCFrigate && Drones.DronesKillHighValueTargets && j.IsNeutralizingMe && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600)
                    .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(j => j.IsNPCBattleship)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasRemoteRepair)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsSensorDampeningMe)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsWebbingMe)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasNeutralizers)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(k => k.IsNPCBattlecruiser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted() && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule) && n.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted() && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(i => i.IsEntityIShouldKeepShooting && i.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                    .ThenByDescending(l => l.IsWreck && !l.IsWreckEmpty)
                    .ThenByDescending(l => l.IsAccelerationGate);

                if (DebugConfig.DebugLogOrderOfNavigateOnGridTargets)
                    LogOrderOfNavigateOnGridTargets(_navigateOnGridTargets);

                if (!Combat.Combat.PotentialCombatTargets.Any())
                    return null;

                return _navigateOnGridTargets;
            }
        }

        private static IOrderedEnumerable<EntityCache> AbyssalDeadspace_FrigateNavigateOnGridTargets
        {
            get
            {
                _navigateOnGridTargets = ESCache.Instance.Entities.Where(i => (i.IsPotentialCombatTarget || i.IsAccelerationGate || i.IsWreck && !i.IsWreckEmpty || i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache) && !i.IsBadIdea && !i.IsNPCDrone)
                    .OrderByDescending(i => Drones.DronesKillHighValueTargets && i.Distance > Drones.MaxDroneRange && !Drones.DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive)
                    .ThenByDescending(i => !Drones.DronesKillHighValueTargets && i.Distance > Combat.Combat.MaxRange)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCFrigate && Drones.DronesKillHighValueTargets && j.IsNeutralizingMe && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600)
                    .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule) && n.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted() && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCFrigate)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted() && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsNPCCruiser)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasRemoteRepair)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsSensorDampeningMe)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsWebbingMe)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasNeutralizers)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(k => k.IsNPCBattlecruiser)
                    .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(j => j.IsNPCBattleship)
                    .ThenByDescending(i => i.IsEntityIShouldKeepShooting && i.IsSomethingICouldKillFasterIfIWereCloser)
                    .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                    .ThenByDescending(l => l.IsWreck && !l.IsWreckEmpty)
                    .ThenByDescending(l => l.IsAccelerationGate);

                if (DebugConfig.DebugLogOrderOfNavigateOnGridTargets)
                    LogOrderOfNavigateOnGridTargets(_navigateOnGridTargets);

                if (!Combat.Combat.PotentialCombatTargets.Any())
                    return null;

                return _navigateOnGridTargets;
            }
        }

        public static bool Abyssal_AvoidBumpingIntoThings()
        {
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                try
                {
                    if (!OrbitBioAdaptiveCacheOrGateIfWeStrayTooFarAway()) return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                try
                {
                    //
                    // always avoid Asteroids and such
                    //
                    EntityCache bigObjectToAvoid = null;

                    if (ESCache.Instance.AbyssalBigObjects.Any(i => i.Name.ToLower().Contains("Large Asteroid Environment".ToLower())))
                    {
                        bigObjectToAvoid = ESCache.Instance.AbyssalBigObjects.Where(i => i.Name.ToLower().Contains("Large Asteroid Environment".ToLower()) && 22500 > i.Distance).OrderBy(i => i.Distance).FirstOrDefault();
                        if (bigObjectToAvoid != null)
                        {
                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("Abyssal_AvoidBumpingIntoThings: [" + bigObjectToAvoid.Name + "] found on grid [" + Math.Round(bigObjectToAvoid.Distance / 1000, 0) + "]k away");
                            if (!AvoidBumpingThings(bigObjectToAvoid, "NavigateOnGrid: NavigateIntoRange", 22500, AbyssalLargeAvoidBumpingThingsBool(AvoidBumpingThingsOnlyIfGoingSlow))) return false;
                            return true;
                        }
                    }

                    if (ESCache.Instance.AbyssalBigObjects.Any(i => i.Name.ToLower().Contains("Medium Asteroid Environment".ToLower())))
                    {
                        bigObjectToAvoid = ESCache.Instance.AbyssalBigObjects.Where(i => i.Name.ToLower().Contains("Medium Asteroid Environment".ToLower()) && 20500 > i.Distance).OrderBy(i => i.Distance).FirstOrDefault();
                        if (bigObjectToAvoid != null)
                        {
                            bool tempBool = AbyssalMediumAvoidBumpingThingsBool(AvoidBumpingThingsOnlyIfGoingSlow);
                            Log.WriteLine("Abyssal_AvoidBumpingIntoThings: myVelocity [" + Math.Round(ESCache.Instance.MyShipEntity.Velocity, 0) + "] m/s [" + bigObjectToAvoid.Name + "] found on grid [" + Math.Round(bigObjectToAvoid.Distance / 1000, 0) + "]k away which is too close: AvoidBumpingThingsBool [" + tempBool + "]");
                            if (!AvoidBumpingThings(bigObjectToAvoid, "NavigateOnGrid: NavigateIntoRange", 20500, tempBool)) return false;
                            return true;
                        }
                    }

                    if (ESCache.Instance.AbyssalBigObjects.Any(i => i.Name.ToLower().Contains("Small Asteroid Environment".ToLower())))
                    {
                        bigObjectToAvoid = ESCache.Instance.AbyssalBigObjects.Where(i => i.Name.ToLower().Contains("Small Asteroid Environment".ToLower()) && 6500 > i.Distance && WeAreMovingVerySlowly).OrderBy(i => i.Distance).FirstOrDefault();
                        if (bigObjectToAvoid != null)
                        {
                            bool tempBool = AbyssalSmallAvoidBumpingThingsBool(AvoidBumpingThingsOnlyIfGoingSlow);
                            Log.WriteLine("Abyssal_AvoidBumpingIntoThings: [" + bigObjectToAvoid.Name + "] found on grid [" + Math.Round(bigObjectToAvoid.Distance / 1000, 0) + "]k away which is too close: AvoidBumpingThingsBool [" + tempBool + "]");
                            if (!AvoidBumpingThings(bigObjectToAvoid, "NavigateOnGrid: NavigateIntoRange", 6500, tempBool)) return false;
                            return true;
                        }
                    }

                    if (Combat.Combat.PotentialCombatTargets.Any(i => i.IsTarget || i.IsTargeting))
                    {
                        //if (ESCache.Instance.EntitiesOnGrid.Any(i => i.Distance < TooCloseToStructure && i.GroupId == 1975)) AvoidBumpingThings(ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.GroupId == 1975), "NavigateOnGrid: NavigateIntoRange avoid Asteroid Environments", TooCloseToStructure);

                        //clouds... what are the ranges for each size cloud? we do not currently account for that!
                        int TooClose = 5000;
                        if (AbyssalDeadspaceBehavior.AbyssalDeadspaceAvoidCausticClouds)
                        {
                            TooClose = Math.Max((int) ESCache.Instance.AbyssalDeadspaceCausticCloud.FirstOrDefault().OptimalRange, 20000);
                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("AvoidBumpingThings: AbyssalDeadspaceCausticCloud [" + ESCache.Instance.AbyssalDeadspaceCausticCloud.FirstOrDefault().Distance + "]k  TooClose [" + TooClose + "]");
                            if (!AvoidBumpingThings(ESCache.Instance.AbyssalDeadspaceCausticCloud.FirstOrDefault(), "NavigateOnGrid: NavigateIntoRange avoid Clouds", TooClose, AvoidBumpingThingsBool())) return false;
                        }

                        if (AbyssalDeadspaceBehavior.AbyssalDeadspaceAvoidBioluminescenceClouds)
                        {
                            TooClose = Math.Max((int) ESCache.Instance.AbyssalDeadspaceBioluminesenceCloud.FirstOrDefault().OptimalRange, 20000);
                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("AvoidBumpingThings: AbyssalDeadspaceBioluminesenceCloud [" + ESCache.Instance.AbyssalDeadspaceBioluminesenceCloud.FirstOrDefault().Distance + "]k  TooClose [" + TooClose + "]");
                            if (!AvoidBumpingThings(ESCache.Instance.AbyssalDeadspaceBioluminesenceCloud.FirstOrDefault(), "NavigateOnGrid: NavigateIntoRange avoid Clouds", TooClose, AvoidBumpingThingsBool())) return false;
                        }

                        if (AbyssalDeadspaceBehavior.AbyssalDeadspaceAvoidFilamentClouds)
                        {
                            TooClose = Math.Max((int) ESCache.Instance.AbyssalDeadspaceFilamentCloud.FirstOrDefault().OptimalRange, 20000);
                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("AvoidBumpingThings: AbyssalDeadspaceFilamentCloud [" + ESCache.Instance.AbyssalDeadspaceFilamentCloud.FirstOrDefault().Distance + "]k  TooClose [" + TooClose + "]");
                            if (!AvoidBumpingThings(ESCache.Instance.AbyssalDeadspaceFilamentCloud.FirstOrDefault(), "NavigateOnGrid: NavigateIntoRange avoid Clouds", TooClose, AvoidBumpingThingsBool())) return false;
                        }

                        //towers...
                        if (AbyssalDeadspaceBehavior.AbyssalDeadspaceAvoidDeviantAutomataSuppressorTowers) if (!AvoidBumpingThings(ESCache.Instance.AbyssalDeadspaceDeviantAutomataSuppressor.FirstOrDefault(), "NavigateOnGrid: NavigateIntoRange avoid Aoe Weapons", (int) ESCache.Instance.AbyssalDeadspaceDeviantAutomataSuppressor.FirstOrDefault().OptimalRange, false)) return false; //these have a 15k in tiers 1-3 and a 40k range in tier 4 and 5
                        if (AbyssalDeadspaceBehavior.AbyssalDeadspaceAvoidMultibodyTrackingPylonTowers) if (!AvoidBumpingThings(ESCache.Instance.AbyssalDeadspaceMultibodyTrackingPylon.FirstOrDefault(), "NavigateOnGrid: NavigateIntoRange avoid Aoe Weapons", (int) ESCache.Instance.AbyssalDeadspaceMultibodyTrackingPylon.FirstOrDefault().OptimalRange, false)) return false; //these have a 15k in tiers 1-3 and a 40k range in tier 4 and 5
                    }

                    return true;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return true;
                }
            }

            return true;
        }

        public static void AbyssalLogWhereAmIOnGrid()
        {
            try
            {
                if (!ESCache.Instance.InAbyssalDeadspace) return;

                EntityCache TriglavianGate = ESCache.Instance.AccelerationGates.FirstOrDefault(i => i.Name.Contains("Triglavian"));
                EntityCache BioadaptiveCacheOrWreck = null;
                int numBattleshipsLeft = 0;
                int numBattlecruisersLeft = 0;
                int numCruisersLeft = 0;
                int numFrigatesLeft = 0;
                int numPotentialCombatTargetsLeft = 0;

                if (Combat.Combat.PotentialCombatTargets.Any())
                {
                    numPotentialCombatTargetsLeft = Combat.Combat.PotentialCombatTargets.Count();
                    numBattleshipsLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsNPCBattleship);
                    numBattlecruisersLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsBattlecruiser);
                    numCruisersLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsNPCCruiser);
                    numFrigatesLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsNPCFrigate);
                }

                if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache))
                    BioadaptiveCacheOrWreck = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache);

                if (ESCache.Instance.Wrecks.Any())
                    BioadaptiveCacheOrWreck = ESCache.Instance.Wrecks.FirstOrDefault();

                if (BioadaptiveCacheOrWreck != null && DateTime.UtcNow > NextLogWhereAmIOnGrid)
                {
                    NextLogWhereAmIOnGrid = DateTime.UtcNow.AddMinutes(1);
                    EntityCache ClosestEntity = ESCache.Instance.EntitiesNotSelf.OrderBy(i => i.Distance).FirstOrDefault();
                    Log.WriteLine("TimeInPocket [" + Math.Round(Math.Abs(DateTime.UtcNow.Subtract(Statistics.StartedPocket).TotalMinutes), 0) + "min] Triglavian Gate [" + Math.Round(TriglavianGate.Distance / 1000, 0) + "k] BioAdaptiveCacheorWreck [" + Math.Round(BioadaptiveCacheOrWreck.Distance / 1000, 0) + "k] speed [" + Math.Round(ESCache.Instance.MyShipEntity.Velocity, 0) + " m/s] BS [" + numBattleshipsLeft + "] BC [" + numBattlecruisersLeft + "] Cruisers [" + numCruisersLeft + "] Frigates [" + numFrigatesLeft + "] PotentialCombatTargets [" + numPotentialCombatTargetsLeft + "] DronesInSpace [" + Drones.ActiveDroneCount + "] Targets [" + ESCache.Instance.Targets.Count() + "] IsAttacking [" + Combat.Combat.PotentialCombatTargets.Count(i => i.IsAttacking) + "] Closest Entity [" + ClosestEntity.Name + "] @ [" + Math.Round(ClosestEntity.Distance / 1000, 0) + "k] AbyssalTimerInSec [" + Math.Round(ESCache.Instance.DirectEve.Me.AbyssalContentExpirationRemainingSeconds, 0) + "]");
                    LogMyCurrentHealth();
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static void LogMyCurrentHealth(string module = "")
        {
            if (ESCache.Instance.ActiveShip != null) Log.WriteLine("MyHealth: [" + module + "] S[" + ESCache.Instance.ActiveShip.ShieldPercentage + "] A[" + ESCache.Instance.ActiveShip.ArmorPercentage + "] H[" + ESCache.Instance.ActiveShip.StructurePercentage + "] C[" + ESCache.Instance.ActiveShip.CapacitorPercentage + "]");
            return;
        }

        public static bool AvoidBumpingThings(EntityCache thisBigObject, string module, int tooCloseToEntity, bool avoidBumpingThingsBool)
        {
            try
            {
                if (!ESCache.Instance.InSpace || ESCache.Instance.InWarp || ESCache.Instance.ActiveShip.Entity.IsCloaked)
                    return true;

                if (DateTime.UtcNow < NextAvoidBumpingThings)
                    return false;

                //bool weHaveInitiatedWarp = QCache.Instance.InSpace && QCache.Instance.MyShipEntity != null && QCache.Instance.MyShipEntity.HasInitiatedWarp;

                bool tempAvoidBumpingThingsBool = false;
                tempAvoidBumpingThingsBool = avoidBumpingThingsBool;
                if (tempAvoidBumpingThingsBool)
                {
                    //we cant move in bastion mode, do not try
                    if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile) return false;

                    if (!ESCache.Instance.InAbyssalDeadspace)
                    {
                        if (ESCache.Instance.ClosestStargate != null && ESCache.Instance.ClosestStargate.Distance < 9000)
                            return false;

                        if (ESCache.Instance.ClosestStation != null && ESCache.Instance.ClosestStation.Distance < 11000)
                            return false;
                    }

                    if (thisBigObject != null)
                    {
                        //
                        // if we are "too close" to the bigObject move away... (is orbit the best thing to do here?)
                        //
                        if (lastTooCloseToEntity.AddSeconds(90) > DateTime.UtcNow && thisBigObject.Distance >= tooCloseToEntity)
                        {
                            //we are no longer "too close" and can proceed.
                            if (AvoidBumpingThingsWarningSent)
                                if (!ESCache.Instance.InAbyssalDeadspace)
                                    StopMyShip("We are no longer too close to structure");

                            Log.WriteLine("AvoidBumpingThings: We are further than tooCloseToEntity[" + tooCloseToEntity + "] from [" + thisBigObject.Name + "] @ [" + Math.Round(thisBigObject.Distance / 1000, 0) + "k]");
                            AvoidBumpingThingsReset();
                            return true;
                        }

                        if (tooCloseToEntity > thisBigObject.Distance)
                        {
                            Log.WriteLine("AvoidBumpingThings: [" + thisBigObject.Name + "] is Distance [" + Math.Round(thisBigObject.Distance / 1000, 0) + "k] away which is less than [tooCloseToEntity][" + Math.Round((double) tooCloseToEntity / 1000, 0) + "k]: we are too close!");
                            lastTooCloseToEntity = DateTime.UtcNow;

                            if (ESCache.Instance.InAbyssalDeadspace)
                            {
                                //
                                // When extremely close move directly away with keep at range
                                //
                                //if (tooCloseToEntity - 5000 > thisBigObject.Distance)
                                //{
                                EntityCache AccelGate = ESCache.Instance.AccelerationGates.FirstOrDefault();
                                    if (AccelGate.Orbit((int)AccelGate.Distance + 2000))
                                    {
                                        Log.WriteLine("[" + module + "] Initiating Orbit [" + AccelGate.Name + "][" + Math.Round(AccelGate.Distance / 1000, 0) + "k] @ [" + Math.Round((AccelGate.Distance + 2000) / 1000, 0) + "] SafeDistanceFromStructure [" + SafeDistanceFromStructure + "] tooCloseToEntity - 5000 [" + (tooCloseToEntity - 5000) + "]");
                                        NextAvoidBumpingThings = DateTime.UtcNow.AddSeconds(35);
                                        return false;
                                    }

                                    return false;
                                //}

                                //if (ESCache.Instance.ActiveShip.MoveTo(thisBigObject._directEntity.PointInSpaceAwayNSEWUD))
                                //{
                                //    Log.WriteLine("[" + module + "] Initiating Movement away from [" + thisBigObject.Name + "][" + Math.Round(thisBigObject.Distance / 1000, 0) + "k] SafeDistanceFromStructure [" + SafeDistanceFromStructure + "] tooCloseToEntity [" + tooCloseToEntity + "] WeAreLeft [" + thisBigObject._directEntity.WeAreWestOfThisEntity + "] WeAreRight[" + thisBigObject._directEntity.WeAreEastOfThisEntity + "] WeAreAbove[" + thisBigObject._directEntity.WeAreAboveThisEntity + "] WeAreBelow[" + thisBigObject._directEntity.WeAreBelowThisEntity + "]");
                                //    NextAvoidBumpingThings = DateTime.UtcNow.AddSeconds(35);
                                //    return false;
                                //}

                                //return false;
                            }

                            if (DateTime.UtcNow > AvoidBumpingThingsTimeStamp.AddSeconds(30) && !ESCache.Instance.InAbyssalDeadspace)
                            {
                                if (SafeDistanceFromStructureMultiplier <= 1)
                                {
                                    AvoidBumpingThingsTimeStamp = DateTime.UtcNow;
                                    SafeDistanceFromStructureMultiplier++;
                                }

                                if (DateTime.UtcNow > AvoidBumpingThingsTimeStamp.AddMinutes(5) && !AvoidBumpingThingsWarningSent)
                                {
                                    Log.WriteLine("AvoidBumpingThings: We are stuck on a object and have been trying to orbit away from it for over 5 min");
                                    AvoidBumpingThingsWarningSent = true;
                                }

                                if (DateTime.UtcNow > AvoidBumpingThingsTimeStamp.AddMinutes(15))
                                    if (Combat.Combat.PotentialCombatTargets == null ||
                                        Combat.Combat.PotentialCombatTargets != null && !Combat.Combat.PotentialCombatTargets.Any() ||
                                        Combat.Combat.PotentialCombatTargets != null && Combat.Combat.PotentialCombatTargets.All(i => i.Distance > ESCache.Instance.WeaponRange))
                                    {
                                        string msg = "AvoidBumpingThings: We have been stuck on an object for over 15 min and have nothing left to shoot";
                                        if (!ESCache.Instance.CloseQuestor(msg)) return false;
                                        return false;
                                    }
                                    else
                                    {
                                        Log.WriteLine("AvoidBumpingThings: We are stuck on a object and have been trying to orbit away from it for over 15 min: waiting for combat to clear NPCs");
                                    }
                            }

                            int distanceForAvoidBumpingThingsToOrbit = Math.Max(SafeDistanceFromStructure, tooCloseToEntity + 3000);
                            if (thisBigObject.Orbit(distanceForAvoidBumpingThingsToOrbit, false, "[" + module + "] Initiating Orbit of [" + thisBigObject.Name + "][" + Math.Round(thisBigObject.Distance / 1000, 0) + "k] orbiting at [" + distanceForAvoidBumpingThingsToOrbit + "] SafeDistanceFromStructure [" + SafeDistanceFromStructure + "] tooCloseToEntity [" + tooCloseToEntity + "]"))
                            {
                                NextAvoidBumpingThings = DateTime.UtcNow.AddSeconds(15);
                                return false;
                            }

                            return false;
                            //we are still too close, do not continue through the rest until we are not "too close" anymore
                        }

                        if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("Debug AvoidBumpingThings: [" + thisBigObject.Name + "] is Distance [" + Math.Round(thisBigObject.Distance / 1000, 0) + "k] [tooCloseToEntity][" + Math.Round((double) tooCloseToEntity / 1000, 0) + "k]");
                        AvoidBumpingThingsReset();
                        return true;
                    }

                    return true;
                }

                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("AvoidBumpingThings: AvoidBumpingThingsBool [" + tempAvoidBumpingThingsBool + "] AvoidBumpingThingsOnlyIfGoingSlow [" + AvoidBumpingThingsOnlyIfGoingSlow + "]");
                AvoidBumpingThingsReset();
                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }
        }

        public static bool GlobalAvoidBumpingIntoThings()
        {
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (!Abyssal_AvoidBumpingIntoThings()) return false;
                return true;
            }

            Mission_AvoidBumpingIntoThings();
            return true;
        }

        public static void InvalidateCache()
        {
            _stationToGoTo = null;
            _navigateOnGridTargets = null;
            _orbitThisTarget = null;
        }

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                Log.WriteLine("LoadSettings: NavigateOnGrid");
                GlobalAvoidBumpingThingsBool =
                    (bool?) CharacterSettingsXml.Element("avoidBumpingThings") ??
                    (bool?) CommonSettingsXml.Element("avoidBumpingThings") ?? true;
                Log.WriteLine("LoadSettings: NavigateOnGrid: avoidBumpingThings [" + GlobalAvoidBumpingThingsBool + "]");
                SpeedTankGlobalSetting =
                    (bool?) CharacterSettingsXml.Element("speedTank") ??
                    (bool?) CommonSettingsXml.Element("speedTank") ?? false;
                Log.WriteLine("LoadSettings: NavigateOnGrid: speedTank [" + SpeedTankGlobalSetting + "]");
                OrbitDistance =
                    (int?) CharacterSettingsXml.Element("orbitDistance") ??
                    (int?) CommonSettingsXml.Element("orbitDistance") ?? 0;
                Log.WriteLine("LoadSettings: NavigateOnGrid: orbitDistance [" + OrbitDistance + "]");
                GlobalOrbitStructure =
                    (bool?) CharacterSettingsXml.Element("orbitStructure") ??
                    (bool?) CommonSettingsXml.Element("orbitStructure") ?? true;
                Log.WriteLine("LoadSettings: NavigateOnGrid: orbitStructure [" + GlobalOrbitStructure + "]");
            }
            catch (Exception exception)
            {
                Log.WriteLine("Error Loading Speed and Movement Settings [" + exception + "]");
            }
        }

        public static void LogWhereAmIOnGrid()
        {
            try
            {
                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    AbyssalLogWhereAmIOnGrid();
                    return;
                }

                MissionLogWhereAmIOnGrid();
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static bool Mission_AvoidBumpingIntoThings()
        {
            if (!ESCache.Instance.InMission) return true;
            if (ESCache.Instance.Stargates.Any(i => i.IsOnGridWithMe)) return true;
            if (ESCache.Instance.Stations.Any(i => i.IsOnGridWithMe)) return true;

            //
            // Avoid Asteroids and such all the time
            //
            EntityCache bigObjectToAvoid = ESCache.Instance.BigObjects.OrderBy(i => i.Distance).FirstOrDefault();
            if (!AvoidBumpingThings(bigObjectToAvoid, "NavigateOnGrid: NavigateIntoRange", TooCloseToStructure, AvoidBumpingThingsBool())) return false;
            return true;
        }

        public static void MissionLogWhereAmIOnGrid()
        {
            if (ESCache.Instance.InMission)
            {
                int numBattleshipsLeft = 0;
                int numBattlecruisersLeft = 0;
                int numCruisersLeft = 0;
                int numFrigatesLeft = 0;
                int numPotentialCombatTargetsLeft = 0;

                if (Combat.Combat.PotentialCombatTargets.Any())
                {
                    numPotentialCombatTargetsLeft = Combat.Combat.PotentialCombatTargets.Count();
                    numBattleshipsLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsNPCBattleship);
                    numBattlecruisersLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsBattlecruiser);
                    numCruisersLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsNPCCruiser);
                    numFrigatesLeft = Combat.Combat.PotentialCombatTargets.Count(i => i.IsNPCFrigate);
                }

                if (DateTime.UtcNow > NextLogWhereAmIOnGrid)
                {
                    NextLogWhereAmIOnGrid = DateTime.UtcNow.AddMinutes(1);
                    Log.WriteLine("TimeInPocket [" + Math.Round(Math.Abs(DateTime.UtcNow.Subtract(Statistics.StartedPocket).TotalMinutes), 0) + "min] speed [" + Math.Round(ESCache.Instance.MyShipEntity.Velocity, 0) + " m/s] BS [" + numBattleshipsLeft + "] BC [" + numBattlecruisersLeft + "] Cruisers [" + numCruisersLeft + "] Frigates [" + numFrigatesLeft + "] PotentialCombatTargets [" + numPotentialCombatTargetsLeft + "] DronesInSpace [" + Drones.ActiveDroneCount + "] Targets [" + ESCache.Instance.Targets.Count() + "]");
                }
            }
        }

        public static bool NavigateInAbyssalDeadspace()
        {
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (SpeedTank)
                {
                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: if (SpeedTank)");
                    NavigateOnGridUsingSpeedTank(ChooseNavigateOnGridTargets.FirstOrDefault(), "Navigate");
                    return true;
                }

                NavigateInAbyssalDeadspaceSlowBoat();
                return true;
            }

            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: if (!ESCache.Instance.InAbyssalDeadspace)");
            return false;
        }

        public static bool NavigateInFactionWarfareComplex()
        {
            //if (ESCache.Instance.InFactionWarfareComplex)
            {
                if (SpeedTank)
                {
                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: if (SpeedTank)");
                    NavigateOnGridUsingSpeedTank(ChooseNavigateOnGridTargets.FirstOrDefault(), "Navigate");
                    return true;
                }

                NavigateInAbyssalDeadspaceSlowBoat();
                return true;
            }

            //if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: if (!ESCache.Instance.InAbyssalDeadspace)");
            //return false;
        }


        public static bool NavigateInAbyssalDeadspaceSlowBoat()
        {
            if (ChooseNavigateOnGridTargets != null && ChooseNavigateOnGridTargets.Any(i => !Drones.DronesKillHighValueTargets && !i.IsReadyToShoot || Drones.DronesKillHighValueTargets && !i.IsReadyForDronesToShoot && !Drones.DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive || !i.IsInWebRange))
            {
                //
                // we have SOMETHING that isnt in range
                //

                //if optimalrange is set - use it to determine engagement range
                if (OptimalRange != 0)
                {
                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("if (OptimalRange != 0): NavigateOnGridUsingOptimalRange");
                    NavigateOnGridUsingOptimalRange(ChooseNavigateOnGridTargets.FirstOrDefault(), "Navigate");
                }
                else //if optimalrange is not set use MaxRange (shorter of weapons range and targeting range)
                {
                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("if (OptimalRange == 0): NavigateOnGridUsingMaxRange");
                    NavigateOnGridUsingMaxRange(ChooseNavigateOnGridTargets.FirstOrDefault(), "Navigate");
                }

                return true;
            }

            //
            // Everything is in range!
            //

            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: Everything is in range");
            EntityCache correctTargetToBeApproaching = AbyssalDeadspace_EverythingIsInRange.FirstOrDefault();

            if (correctTargetToBeApproaching != null)
            {
                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: Orbit [" + correctTargetToBeApproaching.Name + "] at [500m]");
                correctTargetToBeApproaching.Orbit(500);
                return true;
            }

            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: CorrectTargetToBeApproaching == null");
            return true;
        }

        public static bool NavigateInAbyssalDeadspaceSpeedtank()
        {
            if (ChooseNavigateOnGridTargets != null && ((ChooseNavigateOnGridTargets.Any() && ESCache.Instance.MyShipEntity.IsFrigate) || (ChooseNavigateOnGridTargets.Any(i => !Drones.DronesKillHighValueTargets && !i.IsReadyToShoot || Drones.DronesKillHighValueTargets && !i.IsReadyForDronesToShoot && !Drones.DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive || !i.IsInWebRange))))
            {
                //
                // we have SOMETHING that isnt in range
                //

                //if optimalrange is set - use it to determine engagement range
                NavigateOnGridUsingSpeedTank(ChooseNavigateOnGridTargets.FirstOrDefault(), "Navigate");
                return true;
            }

            //
            // Everything is in range!
            //

            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: Everything is in range");
            EntityCache correctTargetToBeApproaching = AbyssalDeadspace_EverythingIsInRange.FirstOrDefault();

            if (correctTargetToBeApproaching != null)
            {
                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: Orbit [" + correctTargetToBeApproaching.Name + "] at [500m]");
                correctTargetToBeApproaching.Orbit(500);
                return true;
            }

            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateInAbyssalDeadspace: CorrectTargetToBeApproaching == null");
            return true;
        }

        //
        // Goals
        // Navigate the ship on the grid so that:
        // 1) we respect BastionAndSiegeModules Mode if active and do not try to move while bastion is active
        // 2) You are always avoiding bumping into large objects in space like LCOs / Gates / etc.
        // 3) You are speed tanking or Not Speed tanking depending on the speedtank setting
        // 4) You are moving into:
        //        a) targeting range
        //        b) weapons range * 0.8
        //        c) optimal range (if you have guns fitted)
        //
        public static void NavigateIntoRange(EntityCache target, string module, bool moveMyShip)
        {
            if (!ESCache.Instance.InSpace || ESCache.Instance.InWarp || ESCache.Instance.InSpace && ESCache.Instance.MyShipEntity.HasInitiatedWarp || !moveMyShip)
                return;

            if (DateTime.UtcNow < NextNavigateIntoRange)
                return;

            if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile)
                return;

            NextNavigateIntoRange = DateTime.UtcNow.AddSeconds(ESCache.Instance.RandomNumber(2, 4));

            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateIntoRange Started");

            //if (Cache.Instance.OrbitDistance != 0)
            //    Logging.Log("CombatMissionCtrl", "Orbit Distance is set to: " + (Cache.Instance.OrbitDistance / 1000).ToString(CultureInfo.InvariantCulture) + "k");

            LogWhereAmIOnGrid();
            if (!GlobalAvoidBumpingIntoThings())
            {
                Log.WriteLine("NavigteOnGrid: NavigateIntoRange: Waiting to proceed until AvoidBumpingThings returns true;");
                return;
            }

            if (ESCache.Instance.InWormHoleSpace)
            {
                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigteOnGrid: NavigateIntoRange: NavigateInWSpace: Do not move");
                return;
            }

            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigteOnGrid: NavigateIntoRange: NavigateInAbyssalDeadspace");
                if (!NavigateInAbyssalDeadspace()) return;
                return;
            }

            if (target == null)
            {
                Log.WriteLine($"Target is null.");
                return;
            }

            if (!target.IsValid)
            {
                Log.WriteLine($"Target is not valid.");
                return;
            }

            if (SpeedTank)
            {
                NavigateOnGridUsingSpeedTank(target, module);
            }
            else
                //if we are not speed tanking then check optimalrange setting, if that is not set use the less of targeting range and weapons range to dictate engagement range
            {
                if (DateTime.UtcNow > Time.Instance.NextApproachAction)
                {
                    if (MissionSettings.MyMission != null && !string.IsNullOrEmpty(MissionSettings.MyMission.Name) && MissionSettings.MyMission.Name.Contains("Anomic"))
                    {
                        target.KeepAtRange(OptimalRange);
                        return;
                    }

                    //if (ESCache.Instance.MyShipEntity.IsFrigate)
                    //{
                    //    target.KeepAtRange(OrbitDistanceToUse);
                    //    return;
                    //}

                    //if optimalrange is set - use it to determine engagement range
                    if (ESCache.Instance.Weapons.Any(i => i.IsTurret))
                        NavigateOnGridUsingOptimalRange(target, module);
                    else //if optimalrange is not set use MaxRange (shorter of weapons range and targeting range)
                        NavigateOnGridUsingMaxRange(target, module);
                }
            }
        }

        public static bool NavigateToTarget(EntityCache target, int distanceFromTarget)
        {
            if (!ESCache.Instance.InSpace || ESCache.Instance.InWarp || ESCache.Instance.InSpace && ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                return false;

            if (ESCache.Instance.DirectEve.Me.IsJumpCloakActive && Traveler.cloak != null && Traveler.cloak._module.ReactivationDelay > 0)
                return false;

            if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile) return false;

            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateToTarget: target [" + target.Name + "] distance [" + target.Nearest5kDistance + "] GroupID [" + target.GroupId + "]");

            LogWhereAmIOnGrid();
            if (!GlobalAvoidBumpingIntoThings())
            {
                Log.WriteLine("NavigateToTarget: Waiting to proceed until AvoidBumpingThings returns true;");
                return false;
            }

            // if we are inside warpto range you need to approach (you cant warp from here)
            if (target.Distance < (int) Distances.WarptoDistance)
            {
                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateToTarget: if (target.Distance < (int) Distances.WarptoDistance)");

                /**
                if (false && orbit && target.GroupId != (int) Group.Station && target.GroupId != (int) Group.Stargate)
                {
                    if (target.Distance < distanceFromTarget)
                        return true;

                    if (DateTime.UtcNow > Time.Instance.NextOrbit)
                    {
                        //we cant move in bastion mode, do not try
                        List<ModuleCache> bastionModules = null;
                        bastionModules = ESCache.Instance.Modules.Where(m => m.GroupId == (int) Group.BastionAndSiegeModules && m.IsOnline).ToList();
                        if (bastionModules.Any(i => i.UseScheduler)) return false;

                        //Log.WriteLine("StartOrbiting: Target in range");
                        if (!target.IsApproachedByActiveShip && !target.IsOrbitedByActiveShip || target.Distance > distanceFromTarget)
                        {
                            //Log.WriteLine("We are not approaching nor orbiting");
                            target.Orbit(distanceFromTarget - 1500);
                            return false;
                        }
                    }
                }
                **/

                if (DateTime.UtcNow > Time.Instance.NextApproachAction)
                {
                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateToTarget: if (DateTime.UtcNow > Time.Instance.NextApproachAction)");

                    if (target.Distance < distanceFromTarget)
                        return true;

                    //if (target.KeepAtRange(distanceFromTarget - 1500))
                    if (!target.Approach()) return false;
                    return false;
                }

                return false;

                //
                // do nothing here. If we havent approached or orbited its because we are waiting before spamming the commands again.
                //
            }
            if (target.Distance > (int) Distances.WarptoDistance)
            {
                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateToTarget: if (target.Distance > (int) Distances.WarptoDistance)");

                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateToTarget: target.AlignTo()");
                target.AlignTo();

                if (Drones.DronePriorityEntities.Any(pt => pt.IsWarpScramblingMe) ||
                    Combat.Combat.PrimaryWeaponPriorityEntities.Any(pt => pt.IsWarpScramblingMe))
                {
                    EntityCache WarpScrambledBy = Drones.DronePriorityEntities.FirstOrDefault(pt => pt.IsWarpScramblingMe) ??
                                                  Combat.Combat.PrimaryWeaponPriorityEntities.FirstOrDefault(pt => pt.IsWarpScramblingMe);
                    if (WarpScrambledBy != null && DateTime.UtcNow > _nextWarpScrambledWarning)
                    {
                        _nextWarpScrambledWarning = DateTime.UtcNow.AddSeconds(20);
                        Log.WriteLine("We are scrambled by: [" + WarpScrambledBy.Name + "][" +
                                      Math.Round(WarpScrambledBy.Distance, 0) + "][" + WarpScrambledBy.Id +
                                      "]");
                        LastWarpScrambled = DateTime.UtcNow;
                    }

                    return false;
                }

                if (target.WarpTo())
                {
                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateToTarget: if (target.WarpTo())");
                    return false;
                }

                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateToTarget: if (!target.WarpTo())");
            }

            return false;
        }

        public static bool OrbitBioAdaptiveCacheOrGateIfWeStrayTooFarAway()
        {
            if (!ESCache.Instance.InSpace)
                return true;

            if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile) return false;

            EntityCache target = null;
            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (target == null && (!Salvage.TractorBeams.Any() || (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway)))
                    target = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache);

                if (target == null && (!Salvage.TractorBeams.Any() || (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway)))
                    target = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsWreck && !i.IsWreckEmpty);
            }

            if (target == null)
                target = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsAccelerationGate);

            if (target == null)
                return true;

            double AbyssalDangerDistanceFromGate = 50000;

            if (target.Distance > AbyssalDangerDistanceFromGate || (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway))
            {
                target.Orbit(500, false, "Orbit BioAdaptiveCache or Gate [" + target.Name + "][" + Math.Round(target.Distance / 1000, 0) + "k away]@[500m] we are more than [" + Math.Round(AbyssalDangerDistanceFromGate/1000, 0) + "k] away");
                return false;
            }

            return true;
        }

        public static EntityCache _orbitThisTarget;
        public static EntityCache OrbitThisTarget
        {
            get
            {

                //
                // this is not yet in use: work in progress: to replace the mess that is the structure var in OrbitGateorTarget
                //

                if (_orbitThisTarget == null)
                {
                    _orbitThisTarget = ESCache.Instance.EntitiesOnGrid.Where(i => !i.IsWreck && !i.IsBadIdea && i.IsTarget && !i.IsNPCDrone && i.IsInRangeOfWeapons)
                        .OrderByDescending(i => !string.IsNullOrEmpty(ESCache.Instance.OrbitEntityNamed) && i.Name.Contains(ESCache.Instance.OrbitEntityNamed))
                        .ThenByDescending(i => (!Salvage.TractorBeams.Any() || (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway)) && i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                        .ThenByDescending(i => !ESCache.Instance.InAbyssalDeadspace && Salvage.LootEverything && i.IsWreck && !i.IsWreckEmpty && i.HaveLootRights)
                        .ThenByDescending(i => i.IsMobileTractor)
                        .ThenByDescending(i => i.IsAccelerationGate)

                        .ThenByDescending(i => i.Distance)
                        .FirstOrDefault();
                }

                return _orbitThisTarget;
            }
        }

        public static void OrbitGateorTarget(EntityCache target, string module)
        {
            if (!ESCache.Instance.InSpace || ESCache.Instance.InWarp || ESCache.Instance.InSpace && ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                return;

            if (DateTime.UtcNow > Time.Instance.NextOrbit)
            {
                //we cant move in bastion mode, do not try
                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile) return;

                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("OrbitGateorTarget Started");

                if (target.Distance < Combat.Combat.MaxRange - 5000)
                {
                    if (DebugConfig.DebugNavigateOnGrid)
                        Log.WriteLine("if (target.Distance + Cache.Instance.OrbitDistance < Combat.MaxRange - 5000)");

                    //Logging.Log("CombatMissionCtrl." + _pocketActions[_currentAction] ,"StartOrbiting: Target in range");
                    if (!target.IsOrbitedByActiveShip && !target.IsApproachedByActiveShip)
                    {
                        if (DebugConfig.DebugNavigateOnGrid)
                            Log.WriteLine("We are not approaching nor orbiting");

                        //
                        // Prefer to orbit the last structure defined in
                        // Cache.Instance.OrbitEntityNamed
                        //
                        EntityCache structure = null;
                        if (OrbitStructure)
                        {
                            //
                            // set the structure we should orbit
                            //
                            if (!string.IsNullOrEmpty(ESCache.Instance.OrbitEntityNamed))
                                structure =
                                    ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.Contains(ESCache.Instance.OrbitEntityNamed))
                                        .OrderBy(t => t.Distance)
                                        .FirstOrDefault();

                            if (!Salvage.TractorBeams.Any() || (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway))
                                if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache))
                                    structure = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache);

                            if (structure == null)
                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.IsAbyssalDeadspaceTriglavianBioAdaptiveCache).OrderBy(t => t.Distance).FirstOrDefault();

                            if (structure == null)
                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.IsMobileTractor).OrderBy(t => t.Distance).FirstOrDefault();

                            if (structure == null && !ESCache.Instance.InAbyssalDeadspace && Salvage.LootEverything)
                            {
                                structure = ESCache.Instance.EntitiesOnGrid.Where(i =>  i.IsWreck && !i.IsWreckEmpty && i.HaveLootRights).OrderBy(t => t.Distance).FirstOrDefault();
                                if (DebugConfig.DebugNavigateOnGrid && structure != null) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                            }

                            if (structure == null)
                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.IsAccelerationGate).OrderBy(t => t.Distance).FirstOrDefault();

                            if (!ESCache.Instance.InAbyssalDeadspace)
                                if (MissionSettings.SelectedControllerUsesCombatMissionsBehavior && ESCache.Instance.InMission && MissionSettings.MyMission != null)
                                {
                                    switch (MissionSettings.MyMission.Name.ToLower())
                                    {
                                        case "dread pirate scarlet":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            if (structure == null && ESCache.Instance.EntitiesOnGrid != null && ESCache.Instance.EntitiesOnGrid.Any(i => i.IsAccelerationGate))
                                            {
                                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.IsAccelerationGate).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            Defense.AlwaysActivateSpeedModForThisGridOnly = true;
                                            break;

                                        case "duo of death":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            if (Combat.Combat.PotentialCombatTargets != null && Combat.Combat.PotentialCombatTargets.Any(i => i.Name.Contains("Gist Seraphim")))
                                            {
                                                structure = Combat.Combat.PotentialCombatTargets.Where(i => i.Name.Contains("Gist Seraphim")).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            Defense.AlwaysActivateSpeedModForThisGridOnly = true;
                                            break;

                                        case "smuggler interception":
                                        case "unauthorized military presence":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            if (structure == null)
                                            {
                                                structure = Combat.Combat.PotentialCombatTargets.Where(i => i.Name.Contains("Personnel Transport")).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            if (structure == null)
                                            {
                                                structure = ESCache.Instance.UnlootedWrecksAndSecureCans.Where(i => i.Name.Contains("Personnel Transport Wreck")).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            break;

                                        case "the damsel in distress":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            if (structure == null && ESCache.Instance.EntitiesOnGrid != null && ESCache.Instance.EntitiesOnGrid.Any(i => i.Name.ToLower().Contains("Pleasure Gardens".ToLower())))
                                            {
                                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.ToLower().Contains("Pleasure Gardens".ToLower())).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }
                                            if (structure == null)
                                            {
                                                structure = ESCache.Instance.UnlootedWrecksAndSecureCans.Where(i => i.Name.ToLower().Contains("Cargo Container".ToLower())).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }
                                            break;

                                        case "the right hand of zazzmatazz":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            if (ESCache.Instance.EntitiesOnGrid != null && ESCache.Instance.EntitiesOnGrid.Any(i => i.Name.ToLower().Contains("Outpost Headquarters".ToLower())))
                                            {
                                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.ToLower().Contains("Outpost Headquarters".ToLower())).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }
                                            if (structure == null)
                                            {
                                                structure = ESCache.Instance.UnlootedWrecksAndSecureCans.Where(i => i.Name.ToLower().Contains("Outpost Headquarters Wreck".ToLower())).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }
                                            Defense.AlwaysActivateSpeedModForThisGridOnly = true;
                                            break;

                                        case "the rogue slave trader (1 of 2)":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            if (ESCache.Instance.EntitiesOnGrid != null && ESCache.Instance.EntitiesOnGrid.Any(i => i.Name.ToLower().Contains("Slave Pen".ToLower())))
                                            {
                                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.ToLower().Contains("Slave Pen".ToLower())).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            if (structure == null)
                                            {
                                                structure = ESCache.Instance.UnlootedWrecksAndSecureCans.Where(i => i.Name.ToLower().Contains("Cargo Container".ToLower())).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }
                                            break;

                                        case "In the Midst of Deadspace (1 of 5)":
                                        case "In the Midst of Deadspace (3 of 5)":
                                        case "In the Midst of Deadspace (4 of 5)":
                                        case "In the Midst of Deadspace (5 of 5)":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            structure = null;
                                            if (ESCache.Instance.EntitiesOnGrid != null && DetermineWhichWrecksToApproach.Any(i => i.IsLargeWreck))
                                            {
                                                structure = DetermineWhichWrecksToApproach.Where(i => i.IsLargeWreck).OrderBy(i => i.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            if (structure == null)
                                            {
                                                structure = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsLargeCollidableWeAlwaysWantToBlowupFirst);
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            if (structure == null)
                                            {
                                                structure = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsLargeCollidableWeAlwaysWantToBlowupLast);
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }
                                            break;

                                        case "silence the informant":
                                        case "rogue drone harassment":
                                            if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: [" + MissionSettings.MyMission.Name + "] detected");
                                            if (ESCache.Instance.EntitiesNotSelf.All(i => !i.IsMobileTractor))
                                            {
                                                if (Combat.Combat.PotentialCombatTargets.Any(i => i.Name.Contains("Elite Drone Parasite")))
                                                {
                                                    structure = Combat.Combat.PotentialCombatTargets.Where(i => i.Name.Contains("Elite Drone Parasite")).OrderBy(t => t.Distance).FirstOrDefault();
                                                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                                }

                                                if (structure == null)
                                                {
                                                    structure = ESCache.Instance.UnlootedWrecksAndSecureCans.Where(i => i.Name.Contains("Elite Drone Parasite Wreck")).OrderBy(t => t.Distance).FirstOrDefault();
                                                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                                }
                                            }

                                            if (structure == null)
                                            {
                                                structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.IsAccelerationGate).OrderBy(t => t.Distance).FirstOrDefault();
                                                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                            }

                                            break;
                                    }

                                    if (structure == null)
                                    {
                                        structure = ESCache.Instance.EntitiesOnGrid.Where(i => i.IsWreck && !i.IsWreckEmpty && i.HaveLootRights).OrderBy(t => t.Distance).FirstOrDefault();
                                        if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateOnGrid: OrbitGateOrTarget: structure [" + structure.Name + "]");
                                    }
                                }

                            //
                            // if we have a structure to orbit do so
                            //
                            if (structure != null)
                            {
                                if (structure.Distance > 50000 && ESCache.Instance.ActiveShip.MaxVelocity > 600)
                                    if (structure.Orbit(30000, false, "Initiating Orbit [" + structure.Name + "][" + Math.Round(structure.Distance / 1000, 0) + "k] at [" + Math.Round((double) OrbitDistanceToUse / 1000, 0) + "k][" + structure.MaskedId + "]"))
                                        return;

                                if (structure.Distance > 40000 && ESCache.Instance.ActiveShip.MaxVelocity > 600)
                                    if (structure.Orbit(20000, false, "Initiating Orbit [" + structure.Name + "][" + Math.Round(structure.Distance / 1000, 0) + "k] at [" + Math.Round((double) OrbitDistanceToUse / 1000, 0) + "k][" + structure.MaskedId + "]"))
                                        return;

                                if (structure.Distance > 30000 && ESCache.Instance.ActiveShip.MaxVelocity > 600)
                                    if (structure.Orbit(15000, false, "Initiating Orbit [" + structure.Name + "][" + Math.Round(structure.Distance / 1000, 0) + "k] at [" + Math.Round((double) OrbitDistanceToUse / 1000, 0) + "k][" + structure.MaskedId + "]"))
                                        return;

                                if (structure.Distance > 20000 && ESCache.Instance.ActiveShip.MaxVelocity > 600)
                                    if (structure.Orbit(10000, false, "Initiating Orbit [" + structure.Name + "][" + Math.Round(structure.Distance / 1000, 0) + "k] at [" + Math.Round((double) OrbitDistanceToUse / 1000, 0) + "k][" + structure.MaskedId + "]"))
                                        return;

                                if (structure.Orbit(500, false, "Initiating Orbit [" + structure.Name + "][" + Math.Round(structure.Distance / 1000, 0) + "k] at [" + Math.Round((double) OrbitDistanceToUse / 1000, 0) + "k][" + structure.MaskedId + "]"))
                                    return;

                                return;
                            }
                        }

                        //
                        // OrbitStructure is false
                        //
                        if (SpeedTank)
                        {
                            if (target.Orbit(OrbitDistanceToUse, false, "Initiating Orbit [" + target.Name + "] at [" + Math.Round((double) OrbitDistanceToUse / 1000, 0) + "k][ID: " + target.MaskedId + "]"))
                                return;

                            return;
                        }

                        //
                        // OrbitStructure is false
                        // SpeedTank is false
                        //
                        if (ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.Velocity < 300 && (target.IsNPCFrigate || target.IsFrigate)) //this will spam a bit until we know what "mode" our active ship is when aligning
                            if (Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                                if (ESCache.Instance.Star.AlignTo())
                                    Log.WriteLine("Aligning to the Star so we might possibly hit [" + target.Name + "][ID: " + target.MaskedId +
                                                  "][ActiveShip.Entity.Mode:[" + ESCache.Instance.ActiveShip.Entity.Mode + "]");

                        if (target.Orbit(OrbitDistanceToUse, false, "Initiating Orbit [" + target.Name + "] at [" + Math.Round((double) OrbitDistanceToUse / 1000, 0) + "k][ID: " + target.MaskedId + "] speedtank == false && orbitstructure == false"))
                            return;
                    }
                }
                else
                {
                    if (target.Orbit(OrbitDistanceToUse, false, "Target [" + target.Name + "]@[" + Math.Round(target.Distance / 1000, 0) + "k] outside MaxRange [" + Math.Round(Combat.Combat.MaxRange / 1000, 0) + "k]. orbiting @ [" + OrbitDistanceToUse + "]"))
                        return;
                }
            }
        }

        public static IEnumerable<EntityCache> DetermineWhichWrecksToApproach
        {
            get
            {
                try
                {
                    IEnumerable<EntityCache> WrecksToApproach = LargeWrecksToApproach.Concat(MediumWrecksToApproach);
                    WrecksToApproach = WrecksToApproach.Concat(SmallWrecksToApproach);
                    return WrecksToApproach;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return new List<EntityCache>();
                }
            }
        }

        public static IEnumerable<EntityCache> LargeWrecksToApproach
        {
            get
            {
                IEnumerable<EntityCache> _largeWrecksToApproach = new List<EntityCache>();
                _largeWrecksToApproach = ESCache.Instance.UnlootedContainers.Where(i => !i.IsInTractorRange && i.IsLargeWreck && !i.IsWreckEmpty && i.HaveLootRights)
                .OrderBy(i => i.Distance);

                return _largeWrecksToApproach;
            }
        }

        public static IEnumerable<EntityCache> MediumWrecksToApproach
        {
            get
            {
                IEnumerable<EntityCache> _mediumWrecksToApproach = new List<EntityCache>();
                _mediumWrecksToApproach = ESCache.Instance.UnlootedContainers.Where(i => !i.IsInTractorRange && !i.IsLargeWreck && !i.IsSmallWreck && !i.IsWreckEmpty && i.HaveLootRights)
                .OrderBy(i => i.Distance);

                return _mediumWrecksToApproach;
            }
        }

        public static IEnumerable<EntityCache> SmallWrecksToApproach
        {
            get
            {
                IEnumerable<EntityCache> _smallWrecksToApproach = new List<EntityCache>();
                _smallWrecksToApproach = ESCache.Instance.UnlootedContainers.Where(i => !i.IsInTractorRange && !i.IsLargeWreck && !i.IsMediumWreck && !i.IsWreckEmpty && i.HaveLootRights)
                .OrderBy(i => i.Distance);

                return _smallWrecksToApproach;
            }
        }

        public static void Reset()
        {
            StationIdToGoto = null;
        }

        public static bool StopMyShip(string reason)
        {
            if (DateTime.UtcNow > Time.Instance.NextStopAction)
            {
                if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                {
                    if (DebugConfig.DebugInteractWithEve) Log.WriteLine("NavigateOnGrid: StopMyShip: !OkToInteractWithEveNow");
                    return false;
                }

                if (ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdStopShip))
                {
                    Log.WriteLine("NavigateOnGrid: StopMyShip: [" + reason + "]");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                    if (ESCache.Instance.EveAccount.IsLeader)
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastStoppedShip), DateTime.UtcNow);

                    Time.Instance.NextStopAction = DateTime.UtcNow.AddSeconds(ESCache.Instance.RandomNumber(10, 15));
                    return true;
                }

                return false;
            }

            return false;
        }

        internal static bool PerformFinalDestinationTask(long stationId, string stationName)
        {
            try
            {
                if (TravelerDestination.NextTravelerDestinationAction > DateTime.UtcNow)
                    return false;

                StationIdToGoto = stationId;

                if (ESCache.Instance.InStation && ESCache.Instance.DirectEve.Session.StationId == stationId ||
                    ESCache.Instance.DirectEve.Session.Structureid == stationId)
                {
                    Log.WriteLine("Arrived in station.");
                    return true;
                }

                if (ESCache.Instance.InStation)
                {
                    // We are in a station, but not the correct station!
                    if (DateTime.UtcNow > Time.Instance.NextUndockAction)
                    {
                        if (TravelerDestination.Undock())
                            return false;

                        return false;
                    }

                    // We are not there yet
                    return false;
                }

                if (!ESCache.Instance.InSpace)
                    return false;

                TravelerDestination.UndockAttempts = 0;

                if (!ESCache.Instance.Stations.Any())
                {
                    if (DebugConfig.DebugTraveler) Log.WriteLine("PerformFinalDestinationTask: No Stations?!");
                    return false;
                }

                if (DebugConfig.DebugTraveler) Log.WriteLine("PerformFinalDestinationTask: Looking for station named [ " + stationName + " ] ID [" + stationId + "]");

                if (StationToGoTo == null)
                {
                    if (DebugConfig.DebugTraveler)
                        Log.WriteLine("if (stationToGoTo == null)");

                    return false;
                }

                if (StationToGoTo.Distance <= (int) Distances.DockingRange)
                {
                    if (StationToGoTo.Dock())
                    {
                        Log.WriteLine("Dock at [" + StationToGoTo.Name + "] which is [" + Math.Round(StationToGoTo.Distance / 1000, 0) +
                                      "k away]");
                        TravelerDestination.NextTravelerDestinationAction = DateTime.UtcNow.AddSeconds(15);
                        return false; //we do not return true until we actually appear in the destination (station in this case)
                    }

                    return false;
                }

                if (StationToGoTo.Distance < (int) Distances.WarptoDistance)
                {
                    if (StationToGoTo.Approach())
                        Log.WriteLine("Approaching [" + StationToGoTo.Name + "] which is [" + Math.Round(StationToGoTo.Distance / 1000, 0) + "k away]");

                    return false;
                }

                EntityCache bigObject = ESCache.Instance.BigObjects.FirstOrDefault();
                AvoidBumpingThings(bigObject, "NavigateOnGrid: PerformFinalDestinationTask", SafeDistanceFromStructure, AvoidBumpingThingsBool());

                if (!AvoidBumpingThingsBool() || bigObject != null && bigObject.Distance > 2000 || bigObject == null)
                {
                    try
                    {
                        if (Settings.Instance.UseDockBookmarks)
                            if (State.CurrentInstaStationDockState != InstaStationDockState.Done &&
                                State.CurrentInstaStationUndockState != InstaStationUndockState.WaitForTraveler)
                            {
                                InstaStationDock.ProcessState();
                                if (State.CurrentInstaStationDockState != InstaStationDockState.Done &&
                                    State.CurrentInstaStationDockState != InstaStationDockState.WaitForTraveler)
                                    return false;
                            }
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLine("Exception [" + ex + "]");
                    }

                    if (StationToGoTo != null && StationToGoTo.WarpTo())
                    {
                        if (DebugConfig.DebugTraveler) Log.WriteLine("if (station.WarpTo())");
                        return false;
                    }
                }

                if (DebugConfig.DebugTraveler) Log.WriteLine("BigObject.Distance less than 2000m?");
                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        private static void AvoidBumpingThingsReset()
        {
            AvoidBumpingThingsTimeStamp = DateTime.UtcNow;
            lastTooCloseToEntity = DateTime.UtcNow.AddHours(-5);
            SafeDistanceFromStructureMultiplier = 1;
            //NextNavigateIntoRange = DateTime.UtcNow;
            AvoidBumpingThingsWarningSent = false;
        }

        private static void LogOrderOfNavigateOnGridTargets(IOrderedEnumerable<EntityCache> navOnGridTargets)
        {
            int targetnum = 0;
            Log.WriteLine("----------------[ navongridtargets ]------------------");
            if (navOnGridTargets == null || navOnGridTargets != null && !navOnGridTargets.Any())
                foreach (EntityCache myNavOnGridTarget in navOnGridTargets)
                {
                    targetnum++;
                    Log.WriteLine(targetnum + ";" + myNavOnGridTarget.Name + ";" + Math.Round(myNavOnGridTarget.Distance / 1000, 0) + "k;" + myNavOnGridTarget.IsBattleship + ";BC;" + myNavOnGridTarget.IsBattlecruiser + ";C;" + myNavOnGridTarget.IsCruiser + ";F;" + myNavOnGridTarget.IsFrigate + ";isAttacking;" + myNavOnGridTarget.IsAttacking + ";IsTargetedBy;" + myNavOnGridTarget.IsTargetedBy + ";IsWarpScramblingMe;" + myNavOnGridTarget.IsWarpScramblingMe + ";IsNeutralizingMe;" + myNavOnGridTarget.IsNeutralizingMe + ";Health;" + myNavOnGridTarget.HealthPct + ";ShieldPct;" + myNavOnGridTarget.ShieldPct + ";ArmorPct;" + myNavOnGridTarget.ArmorPct + ";StructurePct;" + myNavOnGridTarget.StructurePct);
                }

            Log.WriteLine("----------------------------------------------");
        }

        private static void NavigateOnGridUsingMaxRange(EntityCache target, string module)
        {
            {
                if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("Debug: NavigateIntoRange: OptimalRange == 0 using MaxRange [" + Combat.Combat.MaxRange + "] target is [" + target.Name + "][" + target.Distance + "] what weapon systems cause this? drones only?");

                if (target.Distance > Combat.Combat.MaxRange)
                    if (ESCache.Instance.FollowingEntity == null || ESCache.Instance.FollowingEntity.Id != target.Id ||
                        ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.Velocity < 50)
                    {
                        if (target.IsNPCFrigate && Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                        {
                            OrbitGateorTarget(target, module);
                            return;
                        }

                        if (target.Approach())
                            Log.WriteLine("Target [" + target.Name + "][ID: " + target.MaskedId + "] is outside MaxRange [" +
                                          Math.Round(target.Distance / 1000, 0) + "k ] Approach");

                        return;
                    }

                if (target.Distance <= Combat.Combat.MaxRange - 5000)
                {
                    if (ESCache.Instance.InAbyssalDeadspace && ESCache.Instance.FollowingEntity != null && ESCache.Instance.FollowingEntity.Velocity != 0 && ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.Velocity != 0)
                        if (Drones.DronesKillHighValueTargets && tractorBeams.Any() && Combat.Combat.PotentialCombatTargets.All(i => i.Distance < Drones.DroneControlRange) || !Drones.DronesKillHighValueTargets && tractorBeams.Any() && Combat.Combat.PotentialCombatTargets.All(i => i.Distance < Combat.Combat.MaxRange) && ESCache.Instance.AccelerationGates != null && ESCache.Instance.AccelerationGates.Any() && ESCache.Instance.AccelerationGates.FirstOrDefault().DistanceFromEntity(target) + 1000 < OptimalRange)
                        {
                            if (ESCache.Instance.AccelerationGates != null && ESCache.Instance.AccelerationGates.Any())
                            {
                                if (DateTime.UtcNow > Time.Instance.NextOrbit)
                                {
                                    ESCache.Instance.AccelerationGates.FirstOrDefault().Orbit(500);
                                    Time.Instance.NextOrbit = DateTime.UtcNow.AddSeconds(ESCache.Instance.RandomNumber(10, 15));
                                    return;
                                }
                            }
                        }

                    if (DebugConfig.DebugNavigateOnGrid) Log.WriteLine("NavigateIntoRange: target is NPC Frigate [" + target.Name + "][" + target.Distance + "]");
                    OrbitGateorTarget(target, module);
                }
            }
        }

        private static void NavigateOnGridUsingOptimalRange(EntityCache target, string module)
        {
            if (DebugConfig.DebugNavigateOnGrid)
                Log.WriteLine("NavigateIntoRange: OptimalRange [ " + OptimalRange + "] Current Distance to [" + target.Name + "] is [" +
                              Math.Round(target.Distance / 1000, 0) + "]");

            if (!target.IsInOptimalRange || !target.IsInWebRange)
                if (ESCache.Instance.FollowingEntity == null || ESCache.Instance.FollowingEntity.Id != target.Id ||
                    ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.Velocity < 50)
                {
                    //if (NavigateInAbyssalDeadspace()) return;

                    if (!ESCache.Instance.InAbyssalDeadspace && target.IsNPCFrigate && Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                    {
                        if (DebugConfig.DebugNavigateOnGrid)
                            Log.WriteLine("NavigateIntoRange: target is NPC Frigate [" + target.Name + "][" +
                                          Math.Round(target.Distance / 1000, 0) + "]");

                        OrbitGateorTarget(target, module);
                        return;
                    }

                    int tempOrbitDistance = 1000;
                    int tempKeepAtRangeDistance = 8000;
                    if (target.IsAccelerationGate)
                    {
                        tempOrbitDistance = 1000;
                        tempKeepAtRangeDistance = 1000;
                    }

                    if (Combat.Combat.PotentialCombatTargets.Any(i => i.IsNPCBattleship || i.TriglavianDamage > 0))
                    {
                        if (target.Orbit(tempOrbitDistance, false, "Using Optimal Range: Orbiting target [" + target.Name + "][ID: " + target.MaskedId + "][" + Math.Round(target.Distance / 1000, 0) + "k away]"))
                            return;
                    }
                    else
                    {
                        if (target.KeepAtRange(tempKeepAtRangeDistance))
                            Log.WriteLine("Using Optimal Range: KeepAtRange target [" + target.Name + "][ID: " + target.MaskedId + "][" +
                                          Math.Round(target.Distance / 1000, 0) + "k away] myOptimalRange [" + Math.Round((double) OptimalRange / 1000, 0) + "]");
                    }

                    return;
                }

            if (target.IsInOptimalRange)
                if (target.IsNPCFrigate && Combat.Combat.DoWeCurrentlyHaveTurretsMounted())
                {
                    //if (NavigateInAbyssalDeadspace()) return;

                    if (ESCache.Instance.FollowingEntity == null || ESCache.Instance.FollowingEntity.Id != target.Id ||
                        ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.Velocity < 50)
                        if (target.KeepAtRange(OptimalRange))
                        {
                            Log.WriteLine("Target is NPC Frigate and we got Turrets. Keeping target at Range to hit it.");
                            Log.WriteLine("Initiating KeepAtRange [" + target.Name + "] at [" + Math.Round((double) OptimalRange / 1000, 0) +
                                          "k][ID: " + target.MaskedId + "]");
                        }
                }
                else if (ESCache.Instance.FollowingEntity != null && ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.Velocity != 0)
                {
                    //if (NavigateInAbyssalDeadspace()) return;

                    //
                    // Approaching something
                    //
                    if (target.IsNPCFrigate && Combat.Combat.DoWeCurrentlyHaveTurretsMounted()) return;

                    if (ESCache.Instance.FollowingEntity.Velocity != 0)
                    {
                        if (Drones.DronesKillHighValueTargets && tractorBeams.Any() && Combat.Combat.PotentialCombatTargets.All(i => i.Distance < Drones.DroneControlRange) || !Drones.DronesKillHighValueTargets && tractorBeams.Any() && Combat.Combat.PotentialCombatTargets.All(i => i.Distance < Combat.Combat.MaxRange) && ESCache.Instance.AccelerationGates != null && ESCache.Instance.AccelerationGates.Any() && ESCache.Instance.AccelerationGates.FirstOrDefault().DistanceFromEntity(target) + 1000 < OptimalRange)
                        {
                            if (DateTime.UtcNow > Time.Instance.NextOrbit)
                            {
                                ESCache.Instance.AccelerationGates.FirstOrDefault().Orbit(500);
                                Time.Instance.NextOrbit = DateTime.UtcNow.AddSeconds(ESCache.Instance.RandomNumber(10, 15));
                                return;
                            }

                            return;
                        }

                        if (!StopMyShip("Using Optimal Range: Stop ship, target at [" + Math.Round(target.Distance / 1000, 0) +
                                        "k away] Approaching [" + ESCache.Instance.FollowingEntity.Name + "]@[" + Math.Round(ESCache.Instance.FollowingEntity.Distance / 1000, 0) + "k][" + ESCache.Instance.FollowingEntity.Velocity + "m/s] and is inside optimal")) return;
                    }
                }
                else if (ESCache.Instance.FollowingEntity == null && ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.Velocity != 0)
                {
                    //if (NavigateInAbyssalDeadspace()) return;

                    //
                    // moving but not approaching anything, where are we going?!
                    //
                    if (Drones.DronesKillHighValueTargets && tractorBeams.Any() && Combat.Combat.PotentialCombatTargets.All(i => i.Distance < Drones.DroneControlRange) || !Drones.DronesKillHighValueTargets && tractorBeams.Any() && Combat.Combat.PotentialCombatTargets.All(i => i.Distance < Combat.Combat.MaxRange) && ESCache.Instance.AccelerationGates != null && ESCache.Instance.AccelerationGates.Any() && ESCache.Instance.AccelerationGates.FirstOrDefault().DistanceFromEntity(target) + 1000 < OptimalRange)
                    {
                        if (DateTime.UtcNow > Time.Instance.NextOrbit)
                        {
                            ESCache.Instance.AccelerationGates.FirstOrDefault().Orbit(500);
                            Time.Instance.NextOrbit = DateTime.UtcNow.AddSeconds(ESCache.Instance.RandomNumber(10, 15));
                            return;
                        }

                        return;
                    }

                    if (!StopMyShip("Using Optimal Range: Stop ship, target at [" + Math.Round(target.Distance / 1000, 0) +
                                    "k away] is inside optimal and we were motoring off into space")) return;
                }
        }

        private static void NavigateOnGridUsingSpeedTank(EntityCache target, string module)
        {
            int rangeToApproach = OptimalRange;
            if (rangeToApproach == 0) rangeToApproach = (int) Combat.Combat.MaxRange - 5000;

            if (target.Orbit(OrbitDistanceToUse))
                if (DebugConfig.DebugNavigateOnGrid)
                    Log.WriteLine("NavigateIntoRange: SpeedTank: orbit");

            return;
        }

        #endregion Methods
    }
}