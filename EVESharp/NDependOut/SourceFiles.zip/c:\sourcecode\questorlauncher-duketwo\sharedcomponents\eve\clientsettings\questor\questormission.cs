﻿using System;

namespace SharedComponents.EVE.ClientSettings
{
    [Serializable]
    public class QuestorMission
    {
        #region Properties

        public string Name { get; set; }

        #endregion Properties
    }
}