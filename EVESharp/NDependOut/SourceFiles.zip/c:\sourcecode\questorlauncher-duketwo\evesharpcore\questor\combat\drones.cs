﻿extern alias SC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Actions;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.States;
using EVESharpCore.Questor.Stats;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Questor.Combat
{
    public static class Drones
    {
        #region Constructors

        static Drones()
        {
        }

        #endregion Constructors

        #region Fields

        public static int DefaultDroneTypeID;
        public static bool IsRecoverLostDronesAlreadyProcessedInThisPocket;
        public static int MinimumNumberOfDronesBeforeWeGoBuyMore = 100;
        private static IEnumerable<EntityCache> _activeDrones;
        private static double _activeDronesArmorPercentageOnLastPulse;
        private static double _activeDronesArmorTotalOnLastPulse;
        private static double _activeDronesShieldPercentageOnLastPulse;
        private static double _activeDronesShieldTotalOnLastPulse;
        private static double _activeDronesStructurePercentageOnLastPulse;
        private static double _activeDronesStructureTotalOnLastPulse;
        private static DirectContainer _droneBay;
        private static IEnumerable<EntityCache> _dronePriorityEntities;
        private static bool _dronesKillHighValueTargets;
        private static int _droneTypeID;
        private static int _lastDroneCount { get; set; }
        private static DateTime _lastLaunch;
        private static DateTime _lastRecall;
        private static DateTime _lastRecallCommand;

        private static DateTime _launchTimeout;
        private static int _launchTries;
        private static double? _maxDroneRange;
        private static DateTime _nextDroneAction { get; set; } = DateTime.UtcNow;
        private static DateTime _nextWarpScrambledWarning = DateTime.MinValue;
        private static EntityCache _preferredDroneTarget;
        public static EntityCache _cachedDroneTarget { get; set; }
        private static EntityCache _pickDroneTargetBasedOnTargetsForBurners;
        private static int _recallCount;
        private static DateTime LastDroneFightCmd = DateTime.MinValue;

        #endregion Fields

        #region Properties

        public static int ActiveDroneCount
        {
            get
            {
                if (ActiveDrones != null && ActiveDrones.Any())
                    return ActiveDrones.Count();

                return 0;
            }
        }

        public static IEnumerable<EntityCache> ActiveDrones
        {
            get
            {
                if (_activeDrones == null)
                {
                    if (ESCache.Instance.DirectEve.ActiveDrones.Any())
                    {
                        _activeDrones = ESCache.Instance.DirectEve.ActiveDrones.Select(d => new EntityCache(d)).ToList();
                        if (_activeDrones != null)
                            return _activeDrones;

                        return new List<EntityCache>();
                    }

                    return new List<EntityCache>();
                }

                return _activeDrones ?? new List<EntityCache>();
            }
        }

        public static bool AddDampenersToDronePriorityTargetList { get; set; }
        public static bool AddECMsToDroneTargetList { get; set; }
        public static bool AddNeutralizersToDronePriorityTargetList { get; set; }
        public static bool AddTargetPaintersToDronePriorityTargetList { get; set; }
        public static bool AddTrackingDisruptorsToDronePriorityTargetList { get; set; }
        public static bool AddWarpScramblersToDronePriorityTargetList { get; set; }
        public static bool AddWebifiersToDronePriorityTargetList { get; set; }
        public static int BelowThisHealthLevelRemoveFromDroneBay { get; set; }
        public static int BuyAmmoDroneAmmount { get; set; }
        public static bool DefaultUseDrones { get; set; }

        public static DirectContainer DroneBay
        {
            get
            {
                try
                {
                    if (_droneBay != null) return _droneBay;

                    if (!ESCache.Instance.InSpace && ESCache.Instance.InStation)
                        if (ESCache.Instance.Windows != null && ESCache.Instance.Windows.Any())
                        {
                            _droneBay = ESCache.Instance.DirectEve.GetShipsDroneBay();
                            return _droneBay;
                        }

                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public static int DroneControlRange { get; set; }
        public static int DroneMinimumArmorPct { get; set; }
        public static int DroneMinimumCapacitorPct { get; set; }
        public static int DroneMinimumShieldPct { get; set; }

        public static IEnumerable<EntityCache> DronePriorityEntities
        {
            get
            {
                try
                {
                    if (_dronePriorityEntities == null)
                    {
                        if (DronePriorityTargets != null && DronePriorityTargets.Any())
                        {
                            _dronePriorityEntities =
                                DronePriorityTargets.OrderByDescending(pt => pt.DronePriority).ThenBy(pt => pt.Entity.Nearest5kDistance).Select(pt => pt.Entity);
                            return _dronePriorityEntities;
                        }

                        _dronePriorityEntities = new List<EntityCache>();
                        return _dronePriorityEntities;
                    }

                    return _dronePriorityEntities;
                }
                catch (NullReferenceException)
                {
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public static List<PriorityTarget> DronePriorityTargets
        {
            get
            {
                try
                {
                    if (_dronePriorityTargets != null && _dronePriorityTargets.Any())
                    {
                        foreach (PriorityTarget dronePriorityTarget in _dronePriorityTargets)
                            if (ESCache.Instance.EntitiesOnGrid.All(i => i.Id != dronePriorityTarget.EntityID))
                            {
                                _dronePriorityTargets.Remove(dronePriorityTarget);
                                break;
                            }

                        return _dronePriorityTargets;
                    }

                    _dronePriorityTargets = new List<PriorityTarget>();
                    return _dronePriorityTargets;
                }
                catch (NullReferenceException)
                {
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public static int DroneRecallArmorPct { get; set; }
        public static int DroneRecallCapacitorPct { get; set; }
        public static int DroneRecallShieldPct { get; set; }
        public static bool DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive { get; set; }

        public static bool DronesKillHighValueTargets
        {
            get
            {
                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.GroupId == (int) Group.Dreadnaught)
                    return false;

                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsShipWithNoDroneBay)
                    return false;

                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Gila)
                    return true;

                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Worm)
                    return true;

                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Rattlesnake)
                    return true;

                if (MissionSettings.MissionDronesKillHighValueTargets != null)
                    return (bool) MissionSettings.MissionDronesKillHighValueTargets;

                return _dronesKillHighValueTargets;
            }
            set => _dronesKillHighValueTargets = value;
        }

        public static int DroneTypeID
        {
            get
            {
                if (MissionSettings.MissionDroneTypeID != null && MissionSettings.MissionDroneTypeID != 0)
                {
                    _droneTypeID = (int) MissionSettings.MissionDroneTypeID;
                    return _droneTypeID;
                }

                if (MissionSettings.PocketDroneTypeID != null && MissionSettings.PocketDroneTypeID != 0)
                {
                    _droneTypeID = (int) MissionSettings.PocketDroneTypeID;
                    return _droneTypeID;
                }

                if (MissionSettings.FactionDroneTypeID != null && MissionSettings.FactionDroneTypeID != 0)
                {
                    _droneTypeID = (int) MissionSettings.FactionDroneTypeID;
                    return _droneTypeID;
                }

                _droneTypeID = DefaultDroneTypeID;
                return _droneTypeID;
            }
        }

        public static int FactionDroneTypeID { get; set; }
        public static bool DronesShouldBePulled { get; set; }

        public static long? _lastTargetIDDronesEngaged { get; set; }

        public static long? LastTargetIDDronesEngaged
        {
            get
            {
                if (ESCache.Instance.EntitiesOnGrid.Any(i => i.Id == _lastTargetIDDronesEngaged))
                    return _lastTargetIDDronesEngaged;

                _lastTargetIDDronesEngaged = null;
                return null;
            }
            set
            {
                _lastTargetIDDronesEngaged = value;
            }
        }

        public static int LongRangeDroneRecallArmorPct { get; set; }
        public static int LongRangeDroneRecallCapacitorPct { get; set; }
        public static int LongRangeDroneRecallShieldPct { get; set; }

        public static double MaxDroneRange
        {
            get
            {
                if (_maxDroneRange == null)
                {
                    _maxDroneRange = Math.Min(DroneControlRange, Combat.MaxTargetRange);
                    return (double) _maxDroneRange;
                }

                return (double) _maxDroneRange;
            }
        }

        public static EntityCache PreferredDroneTarget
        {
            get
            {
                if (_preferredDroneTarget == null)
                {
                    if (PreferredDroneTargetID != null)
                    {
                        if (ESCache.Instance.EntitiesOnGrid.Any(i => i.Id == PreferredDroneTargetID))
                        {
                            _preferredDroneTarget = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.Id == PreferredDroneTargetID);
                            return _preferredDroneTarget;
                        }

                        return null;
                    }

                    return null;
                }

                return _preferredDroneTarget;
            }
            set
            {
                if (value == null)
                {
                    if (_preferredDroneTarget != null)
                    {
                        _preferredDroneTarget = null;
                        PreferredDroneTargetID = null;
                        Log.WriteLine("[ null ]");
                    }
                }
                else
                {
                    if (_preferredDroneTarget != null && _preferredDroneTarget.Id != value.Id)
                    {
                        _preferredDroneTarget = value;
                        PreferredDroneTargetID = value.Id;
                        if (DebugConfig.DebugGetBestTarget)
                            Log.WriteLine(value + " [" + value.MaskedId + "]");
                    }
                }
            }
        }

        public static long? PreferredDroneTargetID { get; set; }

        public static bool UseDrones
        {
            get
            {
                try
                {
                    //
                    // if we have the character set to not use drones we dont care what the mission XML wants us to do...
                    //
                    if (DefaultUseDrones == false || ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsShipWithNoDroneBay) return false;

                    if (MissionSettings.PocketUseDrones != null)
                    {
                        if (DebugConfig.DebugDrones)
                            Log.WriteLine("We are using PocketDrones setting [" + MissionSettings.PocketUseDrones + "]");
                        return (bool) MissionSettings.PocketUseDrones;
                    }

                    if (MissionSettings.MissionUseDrones != null)
                    {
                        if (DebugConfig.DebugDrones)
                            Log.WriteLine("We are using MissionDrones setting [" + MissionSettings.MissionUseDrones + "]");
                        return (bool) MissionSettings.MissionUseDrones;
                    }

                    return DefaultUseDrones;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return true;
                }
            }
        }

        private static List<PriorityTarget> _dronePriorityTargets { get; set; }

        private static bool OurDronesHaveAHugeBonusToHitPoints
        {
            get
            {
                if (ESCache.Instance.InSpace)
                {
                    if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Rattlesnake)
                        return true;

                    if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.TypeId == (int) TypeID.Gila)
                        return true;

                    if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Worm)
                        return true;

                    if (ActiveDrones.Any() && ActiveDrones.Any(drone => drone.TypeId == (int) TypeID.Gecko))
                        return true;

                    return false;
                }

                return false;
            }
        }

        public static void ClearPerPocketCache()
        {
            LastTargetIDDronesEngaged = null;
            IsRecoverLostDronesAlreadyProcessedInThisPocket = false;
        }

        public static void ResetInSpaceSettingsWhenEnteringStation()
        {
            DronesShouldBePulled = false;
        }

        #endregion Properties

        #region Methods

        private static bool SpamDronesEngage
        {
            get
            {
                if (Combat.PotentialCombatTargets.Any())
                {
                    if (MissionSettings.SelectedControllerUsesCombatMissionsBehavior)
                        if (ESCache.Instance.InMission)
                            if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name.Contains("Anomic"))
                                if (DateTime.UtcNow > LastDroneFightCmd.AddSeconds(22))
                                    return true;

                    if (DronesKillHighValueTargets)
                    {
                        if (ActiveDrones.Any(e => 0 == e.Velocity))
                            return true;

                        if (ActiveDrones.Any(x => 4000 > x.Distance))
                            return true;

                        if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsNPCDrone && i.Velocity != 0))
                            return true;

                        if (Combat.PotentialCombatTargets.Any(i => i.Name == "Harrowing Vedmak"))
                            return true;

                        if (Combat.PotentialCombatTargets.Any(i => i.Name == "Starving Vedmak"))
                            return true;

                        if (Combat.PotentialCombatTargets.Any(i => i.Name == "Karybdis Tyrannos"))
                            return true;
                    }

                    return false;
                }

                return false;
            }
        }

        public static void AddDronePriorityTarget(EntityCache ewarEntity, DronePriority priority, string module, bool AddEwarTypeToPriorityTargetList = true)
        {
            try
            {
                if (AddEwarTypeToPriorityTargetList && UseDrones)
                {
                    if (ewarEntity.IsIgnored || DronePriorityTargets.Any(p => p.EntityID == ewarEntity.Id))
                    {
                        if (DebugConfig.DebugAddDronePriorityTarget)
                            Log.WriteLine("if ((target.IsIgnored) || DronePriorityTargets.Any(p => p.Id == target.Id))");
                        return;
                    }

                    if (DronePriorityTargets.All(i => i.EntityID != ewarEntity.Id))
                    {
                        int DronePriorityTargetCount = 0;
                        if (DronePriorityTargets.Any())
                            DronePriorityTargetCount = DronePriorityTargets.Count();
                        Log.WriteLine("Adding [" + ewarEntity.Name + "] Speed [" + Math.Round(ewarEntity.Velocity, 2) + " m/s] Distance [" +
                                      Math.Round(ewarEntity.Distance / 1000, 2) + "] [ID: " + ewarEntity.MaskedId + "] as a drone priority target [" +
                                      priority +
                                      "] we have [" + DronePriorityTargetCount + "] other DronePriorityTargets");
                        _dronePriorityTargets.Add(new PriorityTarget {Name = ewarEntity.Name, EntityID = ewarEntity.Id, DronePriority = priority});
                    }

                    return;
                }

                if (DebugConfig.DebugAddDronePriorityTarget)
                    Log.WriteLine("UseDrones is [" + UseDrones + "] AddWarpScramblersToDronePriorityTargetList is [" +
                                  AddWarpScramblersToDronePriorityTargetList + "] [" + ewarEntity.Name +
                                  "] was not added as a Drone PriorityTarget (why did we even try?)");
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static void AddDronePriorityTargets(IEnumerable<EntityCache> ewarEntities, DronePriority priority, string module,
            bool AddEwarTypeToPriorityTargetList = true)
        {
            try
            {
                ewarEntities = ewarEntities.ToList();
                if (ewarEntities.Any())
                    foreach (EntityCache ewarEntity in ewarEntities)
                        AddDronePriorityTarget(ewarEntity, priority, module, AddEwarTypeToPriorityTargetList);
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static void AddDronePriorityTargetsByName(string stringEntitiesToAdd)
        {
            try
            {
                IEnumerable<EntityCache> entitiesToAdd = ESCache.Instance.EntitiesByPartialName(stringEntitiesToAdd).ToList();
                if (entitiesToAdd.Any())
                {
                    foreach (EntityCache entityToAdd in entitiesToAdd)
                    {
                        Log.WriteLine("adding [" + entityToAdd.Name + "][" + Math.Round(entityToAdd.Distance / 1000, 0) + "k][" + entityToAdd.MaskedId +
                                      "] to the PWPT List");
                        AddDronePriorityTarget(entityToAdd, DronePriority.PriorityKillTarget, "AddDPTByName");
                    }

                    return;
                }

                Log.WriteLine("[" + stringEntitiesToAdd + "] was not found on grid");
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static bool ChangeDroneState(DroneState state, bool wait = true)
        {
            try
            {
                if (State.CurrentDroneState != state)
                {
                    if (DebugConfig.DebugDrones) Log.WriteLine("New DroneState [" + state + "]");
                    State.CurrentDroneState = state;
                    if (wait)
                        _nextDroneAction = DateTime.UtcNow.AddMilliseconds(250);
                    else
                        ProcessState();
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        public static EntityCache FindDronePriorityTarget(EntityCache currentTarget, DronePriority priorityType, bool AddECMTypeToDronePriorityTargetList,
            double Distance, bool FindAUnTargetedEntity = true)
        {
            if (AddECMTypeToDronePriorityTargetList)
            {
                try
                {
                    EntityCache target = null;
                    try
                    {
                        if (DronePriorityEntities.Any(pt => pt.DronePriorityLevel == priorityType))
                            target =
                                DronePriorityEntities.Where(
                                        pt =>
                                            (FindAUnTargetedEntity || pt.IsReadyForDronesToShoot) && currentTarget != null && pt.Id == currentTarget.Id &&
                                            pt.Distance < Distance && pt.IsActiveDroneEwarType == priorityType
                                            ||
                                            (FindAUnTargetedEntity || pt.IsReadyForDronesToShoot) && pt.Distance < Distance && pt.IsActiveDroneEwarType == priorityType)
                                    .OrderByDescending(pt => pt.IsNPCFrigate)
                                    .ThenByDescending(pt => pt.IsLastTargetDronesWereShooting)
                                    .ThenByDescending(pt => pt.IsInDroneRange)
                                    .ThenBy(pt => pt.IsEntityIShouldKeepShootingWithDrones)
                                    .ThenBy(pt => pt.ShieldPct + pt.ArmorPct + pt.StructurePct)
                                    .ThenBy(pt => pt.Nearest5kDistance)
                                    .FirstOrDefault();
                    }
                    catch (NullReferenceException)
                    {
                    }

                    if (target != null)
                    {
                        if (!FindAUnTargetedEntity)
                        {
                            PreferredDroneTarget = target;
                            Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                            return target;
                        }

                        return target;
                    }

                    return null;
                }
                catch (NullReferenceException)
                {
                }

                return null;
            }

            return null;
        }

        public static bool GetBestDroneTarget(double distance, bool highValueFirst, string callingroutine, List<EntityCache> _potentialTargets = null)
        {
            if (!UseDrones)
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("!Cache.Instance.UseDrones - drones are disabled currently");
                return true;
            }

            if (DebugConfig.DebugGetBestDroneTarget)
                Log.WriteLine("Attempting to get Best Drone Target");

            if (DateTime.UtcNow < Time.Instance.NextGetBestDroneTarget)
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("Cant GetBest yet....Too Soon!");
                return false;
            }

            Time.Instance.NextGetBestDroneTarget = DateTime.UtcNow.AddMilliseconds(2000);

            EntityCache currentDroneTarget = null;

            if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsLastTargetDronesWereShooting))
                currentDroneTarget = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(i => i.IsLastTargetDronesWereShooting);

            if (DateTime.UtcNow < Time.Instance.LastPreferredDroneTargetDateTime.AddSeconds(6) && PreferredDroneTarget != null &&
                ESCache.Instance.EntitiesOnGrid.Any(t => t.Id == PreferredDroneTarget.Id))
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("We have a PreferredDroneTarget [" + PreferredDroneTarget.Name +
                                  "] that was chosen less than 6 sec ago, and is still alive.");
                return true;
            }

            if (currentDroneTarget != null)
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("Checking Low Health");
                if (currentDroneTarget.IsEntityIShouldKeepShootingWithDrones)
                {
                    if (DebugConfig.DebugGetBestDroneTarget)
                        Log.WriteLine("currentDroneTarget [" + currentDroneTarget.Name + "][" + Math.Round(currentDroneTarget.Distance / 1000, 2) +
                                      "k][" +
                                      currentDroneTarget.MaskedId + " GroupID [" + currentDroneTarget.GroupId +
                                      "]] has less than 80% shields, keep killing this target");
                    PreferredDroneTarget = currentDroneTarget;
                    Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                    return true;
                }
            }

            if (currentDroneTarget != null && currentDroneTarget.IsReadyForDronesToShoot && currentDroneTarget.IsLowValueTarget)
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("We have a currentTarget [" + currentDroneTarget.Name + "][" + currentDroneTarget.MaskedId + "][" +
                                  Math.Round(currentDroneTarget.Distance / 1000, 2) + "k], testing conditions");

                #region Is our current target any other drone priority target?

                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("Checking Priority");
                if (DronePriorityEntities.Any(pt => pt.IsReadyForDronesToShoot
                                                    && pt.Nearest5kDistance < MaxDroneRange
                                                    && pt.Id == currentDroneTarget.Id
                                                    && !currentDroneTarget.IsHigherPriorityPresent))
                {
                    if (DebugConfig.DebugGetBestDroneTarget)
                        Log.WriteLine("CurrentTarget [" + currentDroneTarget.Name + "][" + Math.Round(currentDroneTarget.Distance / 1000, 2) + "k][" +
                                      currentDroneTarget.MaskedId + "] GroupID [" + currentDroneTarget.GroupId + "]");
                    PreferredDroneTarget = currentDroneTarget;
                    Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                    return true;
                }

                #endregion Is our current target any other drone priority target?

                #region Is our current target already in armor? keep shooting the same target if so...

                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("Checking Low Health");
                if (currentDroneTarget.IsEntityIShouldKeepShootingWithDrones)
                {
                    if (DebugConfig.DebugGetBestDroneTarget)
                        Log.WriteLine("currentDroneTarget [" + currentDroneTarget.Name + "][" + Math.Round(currentDroneTarget.Distance / 1000, 2) +
                                      "k][" +
                                      currentDroneTarget.MaskedId + " GroupID [" + currentDroneTarget.GroupId +
                                      "]] has less than 80% shields, keep killing this target");
                    PreferredDroneTarget = currentDroneTarget;
                    Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                    return true;
                }

                #endregion Is our current target already in armor? keep shooting the same target if so...

                #region If none of the above matches, does our current target meet the conditions of being hittable and in range

                if (!currentDroneTarget.IsHigherPriorityPresent)
                {
                    if (DebugConfig.DebugGetBestDroneTarget)
                        Log.WriteLine("Does the currentTarget exist? Can it be hit?");
                    if (currentDroneTarget.IsReadyForDronesToShoot && currentDroneTarget.Nearest5kDistance < MaxDroneRange)
                    {
                        if (DebugConfig.DebugGetBestDroneTarget)
                            Log.WriteLine("if  the currentDroneTarget exists and the target is the right size then continue shooting it;");
                        if (DebugConfig.DebugGetBestDroneTarget)
                            Log.WriteLine("currentDroneTarget is [" + currentDroneTarget.Name + "][" + Math.Round(currentDroneTarget.Distance / 1000, 2) +
                                          "k][" +
                                          currentDroneTarget.MaskedId + "] GroupID [" + currentDroneTarget.GroupId + "]");

                        PreferredDroneTarget = currentDroneTarget;
                        Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                        return true;
                    }
                }

                #endregion If none of the above matches, does our current target meet the conditions of being hittable and in range
            }

            if (FindDronePriorityTarget(currentDroneTarget, DronePriority.WarpScrambler, AddWarpScramblersToDronePriorityTargetList, distance) != null)
                return true;

            if (FindDronePriorityTarget(currentDroneTarget, DronePriority.Webbing, AddECMsToDroneTargetList, distance) != null)
                return true;

            if (FindDronePriorityTarget(currentDroneTarget, DronePriority.PriorityKillTarget, AddTrackingDisruptorsToDronePriorityTargetList, distance) != null)
                return true;

            if (FindDronePriorityTarget(currentDroneTarget, DronePriority.PriorityKillTarget, AddNeutralizersToDronePriorityTargetList, distance) != null)
                return true;

            if (FindDronePriorityTarget(currentDroneTarget, DronePriority.PriorityKillTarget, AddTargetPaintersToDronePriorityTargetList, distance) != null)
                return true;

            if (FindDronePriorityTarget(currentDroneTarget, DronePriority.PriorityKillTarget, AddDampenersToDronePriorityTargetList, distance) != null)
                return true;

            if (FindDronePriorityTarget(currentDroneTarget, DronePriority.PriorityKillTarget, AddWebifiersToDronePriorityTargetList, distance) != null)
                return true;

            #region Get the closest drone priority target

            if (DebugConfig.DebugGetBestDroneTarget)
                Log.WriteLine("Checking Closest DronePriorityTarget");
            EntityCache dronePriorityTarget = null;
            try
            {
                dronePriorityTarget = DronePriorityEntities.Where(p => p.Nearest5kDistance < MaxDroneRange
                                                                       && !p.IsIgnored
                                                                       && p.IsReadyForDronesToShoot)
                    .OrderBy(pt => pt.DronePriorityLevel)
                    .ThenByDescending(pt => pt.IsEwarTarget)
                    .ThenByDescending(pt => pt.IsTargetedBy)
                    .ThenBy(pt => pt.Nearest5kDistance)
                    .FirstOrDefault();
            }
            catch (NullReferenceException)
            {
            }

            if (dronePriorityTarget != null)
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("dronePriorityTarget is [" + dronePriorityTarget.Name + "][" + Math.Round(dronePriorityTarget.Distance / 1000, 2) +
                                  "k][" +
                                  dronePriorityTarget.MaskedId + "] GroupID [" + dronePriorityTarget.GroupId + "]");
                PreferredDroneTarget = dronePriorityTarget;
                Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                return true;
            }

            #endregion Get the closest drone priority target

            #region did our calling routine (CombatMissionCtrl?) pass us targets to shoot?

            if (DebugConfig.DebugGetBestDroneTarget)
                Log.WriteLine("Checking Calling Target");
            if (_potentialTargets != null && _potentialTargets.Any())
            {
                EntityCache callingDroneTarget = null;
                try
                {
                    callingDroneTarget = _potentialTargets.OrderBy(t => t.Nearest5kDistance).FirstOrDefault();
                }
                catch (NullReferenceException)
                {
                }

                if (callingDroneTarget != null && callingDroneTarget.IsReadyForDronesToShoot)
                {
                    if (DebugConfig.DebugGetBestDroneTarget)
                        Log.WriteLine("if (callingDroneTarget != null && !callingDroneTarget.IsIgnored)");
                    if (DebugConfig.DebugGetBestDroneTarget)
                        Log.WriteLine("callingDroneTarget is [" + callingDroneTarget.Name + "][" + Math.Round(callingDroneTarget.Distance / 1000, 2) +
                                      "k][" +
                                      callingDroneTarget.MaskedId + "] GroupID [" + callingDroneTarget.GroupId + "]");
                    AddDronePriorityTarget(callingDroneTarget, DronePriority.PriorityKillTarget, " GetBestDroneTarget: callingDroneTarget");
                    PreferredDroneTarget = callingDroneTarget;
                    Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                    return true;
                }
            }

            #endregion did our calling routine (CombatMissionCtrl?) pass us targets to shoot?

            #region Get the closest Low Value Target

            if (DebugConfig.DebugGetBestDroneTarget)
                Log.WriteLine("Checking Closest Low Value");
            EntityCache lowValueTarget = null;

            if (Combat.PotentialCombatTargets.Any())
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("get closest: if (potentialCombatTargets.Any())");

                lowValueTarget = Combat.PotentialCombatTargets.Where(t => t.IsLowValueTarget && t.IsReadyForDronesToShoot)
                    .OrderBy(t => t.IsEwarTarget)
                    .ThenByDescending(t => t.IsNPCFrigate)
                    .ThenByDescending(t => t.IsTargetedBy)
                    .ThenBy(ESCache.Instance.OrderByLowestHealth())
                    .ThenBy(t => t.Nearest5kDistance)
                    .FirstOrDefault();
            }

            #endregion Get the closest Low Value Target

            #region Get the closest high value target

            if (DebugConfig.DebugGetBestDroneTarget)
                Log.WriteLine("Checking closest Low Value");
            EntityCache highValueTarget = null;
            if (Combat.PotentialCombatTargets.Any())
                highValueTarget = Combat.PotentialCombatTargets.Where(t => t.IsHighValueTarget && t.IsReadyForDronesToShoot)
                    .OrderByDescending(t => !t.IsNPCFrigate)
                    .ThenByDescending(t => t.IsTargetedBy)
                    .ThenBy(ESCache.Instance.OrderByLowestHealth())
                    .ThenBy(t => t.Nearest5kDistance)
                    .FirstOrDefault();

            #endregion Get the closest high value target

            #region prefer to grab a lowvaluetarget, if none avail use a high value target

            if (lowValueTarget != null || highValueTarget != null)
            {
                if (DebugConfig.DebugGetBestDroneTarget)
                    Log.WriteLine("Checking use High Value");
                if (DebugConfig.DebugGetBestDroneTarget)
                    if (highValueTarget != null)
                        Log.WriteLine("highValueTarget is [" + highValueTarget.Name + "][" + Math.Round(highValueTarget.Distance / 1000, 2) + "k][" +
                                      highValueTarget.MaskedId + "] GroupID [" + highValueTarget.GroupId + "]");
                    else
                        Log.WriteLine("highValueTarget is [ null ]");
                PreferredDroneTarget = lowValueTarget ?? highValueTarget ?? null;
                Time.Instance.LastPreferredDroneTargetDateTime = DateTime.UtcNow;
                return true;
            }

            #endregion prefer to grab a lowvaluetarget, if none avail use a high value target

            if (DebugConfig.DebugGetBestDroneTarget)
                Log.WriteLine("Could not determine a suitable Drone target");

            #region If we did not find anything at all (wtf!?!?)

            if (DebugConfig.DebugGetBestDroneTarget)
            {
                if (ESCache.Instance.Targets.Any())
                {
                    Log.WriteLine(".");
                    Log.WriteLine("*** ALL LOCKED/LOCKING TARGETS LISTED BELOW");
                    int LockedTargetNumber = 0;
                    foreach (EntityCache __target in ESCache.Instance.Targets)
                    {
                        LockedTargetNumber++;
                        Log.WriteLine("*** Target: [" + LockedTargetNumber + "][" + __target.Name + "][" + Math.Round(__target.Distance / 1000, 2) +
                                      "k][" +
                                      __target.MaskedId + "][isTarget: " + __target.IsTarget + "][isTargeting: " + __target.IsTargeting + "] GroupID [" +
                                      __target.GroupId +
                                      "]");
                    }

                    Log.WriteLine("*** ALL LOCKED/LOCKING TARGETS LISTED ABOVE");
                    Log.WriteLine(".");
                }

                if (Combat.PotentialCombatTargets.Any(t => !t.IsTarget && !t.IsTargeting))
                {
                    if (ActionControl.IgnoreTargets.Any())
                    {
                        int IgnoreCount = ActionControl.IgnoreTargets.Count;
                        Log.WriteLine("Ignore List has [" + IgnoreCount + "] Entities in it.");
                    }

                    Log.WriteLine("***** ALL [" + Combat.PotentialCombatTargets.Count() +
                                  "] potentialCombatTargets LISTED BELOW (not yet targeted or targeting)");
                    int potentialCombatTargetNumber = 0;
                    foreach (EntityCache potentialCombatTarget in Combat.PotentialCombatTargets)
                    {
                        potentialCombatTargetNumber++;
                        Log.WriteLine("***** Unlocked [" + potentialCombatTargetNumber + "]: [" + potentialCombatTarget.Name + "][" +
                                      Math.Round(potentialCombatTarget.Distance / 1000, 2) + "k][" + potentialCombatTarget.MaskedId + "][isTarget: " +
                                      potentialCombatTarget.IsTarget + "] GroupID [" + potentialCombatTarget.GroupId + "]");
                    }

                    Log.WriteLine("***** ALL [" + Combat.PotentialCombatTargets.Count() +
                                  "] potentialCombatTargets LISTED ABOVE (not yet targeted or targeting)");
                    Log.WriteLine(".");
                }
            }

            #endregion If we did not find anything at all (wtf!?!?)

            Time.Instance.NextGetBestDroneTarget = DateTime.UtcNow;
            return false;
        }

        public static void InvalidateCache()
        {
            try
            {
                _droneTypeID = 0;
                _activeDrones = null;
                _droneBay = null;
                _dronePriorityEntities = null;
                _maxDroneRange = null;
                _cachedDroneTarget = null;
                _preferredDroneTarget = null;
                _pickDroneTargetBasedOnTargetsForBurners = null;
                _pickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets = null;
                _pickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos = null;
                _pickDroneTarget_DronesKillHighValueTargets = null;

                if (_dronePriorityTargets != null && _dronePriorityTargets.Any())
                    _dronePriorityTargets.ForEach(pt => pt.ClearCache());
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                Log.WriteLine("LoadSettings: Drones");
                AddDampenersToDronePriorityTargetList =
                    (bool?) CharacterSettingsXml.Element("addDampenersToDronePriorityTargetList") ??
                    (bool?) CommonSettingsXml.Element("addDampenersToDronePriorityTargetList") ?? true;
                AddECMsToDroneTargetList =
                    (bool?) CharacterSettingsXml.Element("addECMsToDroneTargetList") ??
                    (bool?) CommonSettingsXml.Element("addECMsToDroneTargetList") ?? true;
                AddNeutralizersToDronePriorityTargetList =
                    (bool?) CharacterSettingsXml.Element("addNeutralizersToDronePriorityTargetList") ??
                    (bool?) CommonSettingsXml.Element("addNeutralizersToDronePriorityTargetList") ?? true;
                AddTargetPaintersToDronePriorityTargetList =
                    (bool?) CharacterSettingsXml.Element("addTargetPaintersToDronePriorityTargetList") ??
                    (bool?) CommonSettingsXml.Element("addTargetPaintersToDronePriorityTargetList") ?? true;
                AddTrackingDisruptorsToDronePriorityTargetList =
                    (bool?) CharacterSettingsXml.Element("addTrackingDisruptorsToDronePriorityTargetList") ??
                    (bool?) CommonSettingsXml.Element("addTrackingDisruptorsToDronePriorityTargetList") ?? true;
                AddWarpScramblersToDronePriorityTargetList =
                    (bool?) CharacterSettingsXml.Element("addWarpScramblersToDronePriorityTargetList") ??
                    (bool?) CommonSettingsXml.Element("addWarpScramblersToDronePriorityTargetList") ?? true;
                AddWebifiersToDronePriorityTargetList =
                    (bool?) CharacterSettingsXml.Element("addWebifiersToDronePriorityTargetList") ??
                    (bool?) CommonSettingsXml.Element("addWebifiersToDronePriorityTargetList") ?? true;
                DefaultUseDrones =
                    (bool?) CharacterSettingsXml.Element("useDrones") ??
                    (bool?) CommonSettingsXml.Element("useDrones") ?? true;
                Log.WriteLine("LoadSettings: Drones: useDrones [" + DefaultUseDrones + "]");
                DefaultDroneTypeID =
                    (int?) CharacterSettingsXml.Element("droneTypeId") ??
                    (int?) CommonSettingsXml.Element("droneTypeId") ?? 0;
                Log.WriteLine("LoadSettings: Drones: droneTypeId [" + DefaultDroneTypeID + "]");
                BuyAmmoDroneAmmount =
                    (int?) CharacterSettingsXml.Element("buyAmmoDroneAmount") ??
                    (int?) CommonSettingsXml.Element("buyAmmoDroneAmount") ?? 200;
                Log.WriteLine("LoadSettings: Drones: buyAmmoDroneAmount [" + BuyAmmoDroneAmmount + "]");
                MinimumNumberOfDronesBeforeWeGoBuyMore =
                    (int?) CharacterSettingsXml.Element("minimumNumberOfDronesBeforeWeGoBuyMore") ??
                    (int?) CommonSettingsXml.Element("minimumNumberOfDronesBeforeWeGoBuyMore") ?? 100;
                Log.WriteLine("LoadSettings: Drones: minimumNumberOfDronesBeforeWeGoBuyMore [" + MinimumNumberOfDronesBeforeWeGoBuyMore + "]");
                DroneControlRange =
                    (int?) CharacterSettingsXml.Element("droneControlRange") ??
                    (int?) CommonSettingsXml.Element("droneControlRange") ?? 25000;
                Log.WriteLine("LoadSettings: Drones: droneControlRange [" + DroneControlRange + "]");
                DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive =
                    (bool?) CharacterSettingsXml.Element("dronesDontNeedTargetsBecauseWehaveThemSetOnAggressive") ??
                    (bool?) CommonSettingsXml.Element("dronesDontNeedTargetsBecauseWehaveThemSetOnAggressive") ?? false;
                Log.WriteLine("LoadSettings: Drones: dronesDontNeedTargetsBecauseWehaveThemSetOnAggressive [" + DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive + "]");
                DroneMinimumShieldPct =
                    (int?) CharacterSettingsXml.Element("droneMinimumShieldPct") ??
                    (int?) CommonSettingsXml.Element("droneMinimumShieldPct") ?? 50;
                DroneMinimumArmorPct =
                    (int?) CharacterSettingsXml.Element("droneMinimumArmorPct") ??
                    (int?) CommonSettingsXml.Element("droneMinimumArmorPct") ?? 50;
                DroneMinimumCapacitorPct =
                    (int?) CharacterSettingsXml.Element("droneMinimumCapacitorPct") ??
                    (int?) CommonSettingsXml.Element("droneMinimumCapacitorPct") ?? 0;
                DroneRecallShieldPct =
                    (int?) CharacterSettingsXml.Element("droneRecallShieldPct") ??
                    (int?) CommonSettingsXml.Element("droneRecallShieldPct") ?? 0;
                DroneRecallArmorPct =
                    (int?) CharacterSettingsXml.Element("droneRecallArmorPct") ??
                    (int?) CommonSettingsXml.Element("droneRecallArmorPct") ?? 0;
                DroneRecallCapacitorPct =
                    (int?) CharacterSettingsXml.Element("droneRecallCapacitorPct") ??
                    (int?) CommonSettingsXml.Element("droneRecallCapacitorPct") ?? 0;
                LongRangeDroneRecallShieldPct =
                    (int?) CharacterSettingsXml.Element("longRangeDroneRecallShieldPct") ??
                    (int?) CommonSettingsXml.Element("longRangeDroneRecallShieldPct") ?? 0;
                LongRangeDroneRecallArmorPct =
                    (int?) CharacterSettingsXml.Element("longRangeDroneRecallArmorPct") ??
                    (int?) CommonSettingsXml.Element("longRangeDroneRecallArmorPct") ?? 0;
                LongRangeDroneRecallCapacitorPct =
                    (int?) CharacterSettingsXml.Element("longRangeDroneRecallCapacitorPct") ??
                    (int?) CommonSettingsXml.Element("longRangeDroneRecallCapacitorPct") ?? 0;
                DronesKillHighValueTargets =
                    (bool?) CharacterSettingsXml.Element("dronesKillHighValueTargets") ??
                    (bool?) CommonSettingsXml.Element("dronesKillHighValueTargets") ?? false;
                //Log.WriteLine("LoadSettings: Drones: dronesKillHighValueTargets [" + DronesKillHighValueTargets + "]");
                BelowThisHealthLevelRemoveFromDroneBay =
                    (int?) CharacterSettingsXml.Element("belowThisHealthLevelRemoveFromDroneBay") ??
                    (int?) CommonSettingsXml.Element("belowThisHealthLevelRemoveFromDroneBay") ?? 150;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Error Loading Weapon and targeting Settings [" + exception + "]");
            }
        }

        public static void ShootTheBestIndividualNPCOfTheSameTypeWeChoose()
        {
            if (_cachedDroneTarget != null && Combat.PotentialCombatTargets != null && Combat.PotentialCombatTargets.Any())
            {
                if (Combat.PotentialCombatTargets.Any(i => i.IsEntityDronesAreShooting && i.IsInDroneRange && i.IsTarget && i.Name == _cachedDroneTarget.Name && !i.WeShouldFocusFire))
                {
                    _cachedDroneTarget = Combat.PotentialCombatTargets.FirstOrDefault(i => i.IsEntityDronesAreShooting && i.IsInDroneRange && i.IsTarget && i.Name == _cachedDroneTarget.Name && !i.WeShouldFocusFire);
                    return;
                }

                if (ActiveDrones != null && ActiveDrones.Any() && Combat.PotentialCombatTargets.Any(i => i.IsReadyForDronesToShoot && i.Name == _cachedDroneTarget.Name && !i.WeShouldFocusFire))
                {
                    _cachedDroneTarget = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot && i.Name == _cachedDroneTarget.Name && !i.WeShouldFocusFire).OrderBy(x => x.DistanceFromEntity(ActiveDrones.FirstOrDefault())).FirstOrDefault();
                    return;
                }
            }
        }

        public static EntityCache PickDroneTarget()
        {
            if (_cachedDroneTarget != null)
                return _cachedDroneTarget;

            if (ESCache.Instance.InWormHoleSpace)
            {
                if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.Dreadnaught)
                {
                    return null;
                }

                //return PickPrimaryWeaponTargetWSpace.FirstOrDefault();
            }

            if (ESCache.Instance.InAbyssalDeadspace)
            {
                if (DronesKillHighValueTargets)
                {
                    if (ESCache.Instance.Modules.Any(i => i.GroupId == (int) Group.Afterburner) && NavigateOnGrid.SpeedTank)
                    {
                        //if (Combat.PotentialCombatTargets.Any(i => i.Name.ToLower() == "karybdis tyrannos".ToLower()))
                        //{
                        //    _cachedDroneTarget = PickDroneTarget_AbyssalDeadSpace_KarybdisTyrannosWhileSpeedTank();
                        //    if (_cachedDroneTarget != null)
                        //    {
                        //        PreferredDroneTargetID = _cachedDroneTarget.Id;
                        //        if (DebugConfig.DebugTargetCombatants)
                        //            Log.WriteLine("DebugTargetCombatants: PickDroneTarget: Abyssal: DronesKillHIghValueTargets: KarybdisTyrannos: SpeedTank:  _pickDroneTarget [" + _cachedDroneTarget.Name + "] as KillTarget for drones");
                        //
                        //        ShootNPCWeAreAlreadyEngagingIfSameName();
                        //        return _cachedDroneTarget;
                        //    }
                        //}

                        _cachedDroneTarget = PickDroneTarget_AbyssalDeadSpaceWhileSpeedTank();
                        if (_cachedDroneTarget != null)
                        {
                            PreferredDroneTargetID = _cachedDroneTarget.Id;
                            ShootTheBestIndividualNPCOfTheSameTypeWeChoose();
                            if (DebugConfig.DebugTargetCombatants)
                                Log.WriteLine("DebugTargetCombatants: PickDroneTarget: Abyssal: DronesKillHIghValueTargets: SpeedTank:  _pickDroneTarget [" + _cachedDroneTarget.Name + "] as KillTarget for drones");
                            return _cachedDroneTarget;
                        }
                    }

                    //if (Combat.PotentialCombatTargets.Any(i => i.Name.ToLower() == "karybdis tyrannos".ToLower()))
                    //{
                    //    _cachedDroneTarget = PickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos();
                    //    if (_cachedDroneTarget != null)
                    //    {
                    //        PreferredDroneTargetID = _cachedDroneTarget.Id;
                    //        ShootNPCWeAreAlreadyEngagingIfSameName();
                    //        if (DebugConfig.DebugTargetCombatants)
                    //            Log.WriteLine("DebugTargetCombatants: PickDroneTarget: Abyssal: DronesKillHIghValueTargets: KarybdisTyrannos:  _pickDroneTarget [" + _cachedDroneTarget.Name + "] as KillTarget for drones");
                    //        return _cachedDroneTarget;
                    //    }
                    //}

                    _cachedDroneTarget = PickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets();
                    if (_cachedDroneTarget != null)
                    {
                        ShootTheBestIndividualNPCOfTheSameTypeWeChoose();
                        PreferredDroneTargetID = _cachedDroneTarget.Id;
                        if (DebugConfig.DebugTargetCombatants)
                            Log.WriteLine("DebugTargetCombatants: PickDroneTarget: Abyssal: DronesKillHIghValueTargets:  _pickDroneTarget [" + _cachedDroneTarget.Name + "] as KillTarget for drones");
                        return _cachedDroneTarget;
                    }

                    return null;
                }

                _cachedDroneTarget = PickDroneTarget_AbyssalDeadSpace();
                if (_cachedDroneTarget != null)
                {
                    ShootTheBestIndividualNPCOfTheSameTypeWeChoose();
                    PreferredDroneTargetID = _cachedDroneTarget.Id;
                    if (DebugConfig.DebugTargetCombatants)
                        Log.WriteLine("DebugTargetCombatants: PickDroneTarget: Abyssal: DronesKillHIghValueTargets: _pickDroneTarget [" + _cachedDroneTarget.Name + "] as KillTarget for drones");
                    return _cachedDroneTarget;
                }

                return null;
            }

            if (State.CurrentHydraState == HydraState.Combat)
            {
                if (ESCache.Instance.Targets.Any(i => i.Id == ESCache.Instance.EveAccount.LeaderIsAggressingTargetId))
                    _cachedDroneTarget = ESCache.Instance.Targets.FirstOrDefault(i => i.Id == ESCache.Instance.EveAccount.LeaderIsAggressingTargetId);
                return _cachedDroneTarget;
            }

            if (ESCache.Instance.InMission)
                if (ESCache.Instance.MyShipEntity != null)
                {
                    if (ESCache.Instance.MyShipEntity.IsFrigate)
                    {
                        if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name.Contains("Anomic"))
                        {
                            _cachedDroneTarget = PickDroneTargetBasedOnTargetsForBurners();
                            ShootTheBestIndividualNPCOfTheSameTypeWeChoose();
                            return _cachedDroneTarget;
                        }

                        //if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsFrigate)");
                        //droneTarget = PickPrimaryWeaponTargetBasedOnTargetsForAFrigate.FirstOrDefault();
                        //if (droneTarget != null)
                        //    return droneTarget;
                        //
                        //return null;
                    }

                    if (ESCache.Instance.MyShipEntity.IsCruiser)
                    {
                        //if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsCruiser)");
                        //droneTarget = PickPrimaryWeaponTargetBasedOnTargetsForACruiser.FirstOrDefault();
                        //if (droneTarget != null)
                        //    return droneTarget;
                        //
                        //return null;
                    }

                    if (ESCache.Instance.MyShipEntity.IsBattleship)
                    {
                    //    if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) if (ESCache.Instance.MyShipEntity.IsBattleship)");
                    //    droneTarget = PickPrimaryWeaponTargetBasedOnTargetsForABattleship.FirstOrDefault();
                    //    if (droneTarget != null)
                    //        return droneTarget;
                    //
                    //    return null;
                    }
                    //
                    //
                    // Default to picking targets for a battleship sized ship
                    //
                    //if (DebugConfig.DebugKillTargets) Log.WriteLine("if (ESCache.Instance.InMission) MyShipEntity class unknown");
                    //droneTarget = PickPrimaryWeaponTargetBasedOnTargetsForABattleship.FirstOrDefault();
                    //if (droneTarget != null)
                    //    return droneTarget;
                    //

                    if (_cachedDroneTarget == null && ESCache.Instance.Targets.Any())
                    {
                        _cachedDroneTarget = ESCache.Instance.Targets.Where(i => !i.IsBadIdea).OrderBy(i => 100 > i.HealthPct).FirstOrDefault();
                        ShootTheBestIndividualNPCOfTheSameTypeWeChoose();
                        if (DebugConfig.DebugDrones || DebugConfig.DebugTargetCombatants) Log.WriteLine("droneTarget was still null: chosing the first non-badidea target [" + _cachedDroneTarget.Name + "][" + _cachedDroneTarget.Distance + "]");
                        return _cachedDroneTarget;
                    }
                }


            if (DronesKillHighValueTargets)
            {
                _cachedDroneTarget = PickDroneTarget_DronesKillHighValueTargets();
                PreferredDroneTargetID = _cachedDroneTarget.Id;
                ShootTheBestIndividualNPCOfTheSameTypeWeChoose();
                if (DebugConfig.DebugTargetCombatants)
                    Log.WriteLine("DebugTargetCombatants: PickDroneTarget: DronesKillHIghValueTargets: _pickDroneTarget [" + _cachedDroneTarget.Name + "] as KillTarget for drones");
                return _cachedDroneTarget;
            }

            IOrderedEnumerable<EntityCache> droneTargets = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot && !i.IsIgnored)
                .OrderByDescending(a => a.IsWarpScramblingMe && 100 > a.HealthPct)
                .ThenByDescending(b => b.IsWarpScramblingMe)
                .ThenByDescending(b => b.WarpScrambleChance > 0 && 100 > b.HealthPct)
                .ThenByDescending(b => b.WarpScrambleChance)
                .ThenByDescending(c => c.isPreferredDroneTarget && 100 > c.HealthPct)
                .ThenByDescending(c => c.isPreferredDroneTarget)
                //.ThenByDescending(j => !j.IsTrigger)
                .ThenByDescending(g => (g.IsFrigate || g.IsNPCFrigate) && 100 > g.HealthPct && g.IsLastTargetDronesWereShooting)
                .ThenByDescending(g => (g.IsFrigate || g.IsNPCFrigate) && 100 > g.HealthPct)
                .ThenByDescending(e => e.IsTargetedBy)
                .ThenByDescending(f => f.IsAttacking)
                .ThenByDescending(g => g.IsFrigate || g.IsNPCFrigate)
                .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                .ThenByDescending(o => Combat._pickPrimaryWeaponTarget != null && o != Combat._pickPrimaryWeaponTarget && o.IsNPCFrigate && !o.IsWarpScramblingMe)
                .ThenByDescending(c => c.IsLargeCollidableWeAlwaysWantToBlowupFirst)
                .ThenByDescending(c => c.IsLargeCollidableWeAlwaysWantToBlowupLast)
                .ThenBy(p => p.HealthPct)
                .ThenBy(s => s.Nearest5kDistance);

            if (DebugConfig.DebugLogOrderOfDroneTargets)
                LogOrderOfDroneTargets(droneTargets);

            PreferredDroneTargetID = droneTargets.FirstOrDefault().Id;
            ShootTheBestIndividualNPCOfTheSameTypeWeChoose();
            if (DebugConfig.DebugTargetCombatants)
                Log.WriteLine("DebugTargetCombatants: PickDroneTarget: _pickDroneTarget [" + _cachedDroneTarget.Name + "] as KillTarget for drones");
            _cachedDroneTarget = droneTargets.FirstOrDefault();
            return _cachedDroneTarget;
        }

        public static EntityCache PickDroneTargetBasedOnTargetsForBurners()
        {
            if (_pickDroneTargetBasedOnTargetsForBurners == null)
            {
                _pickDroneTargetBasedOnTargetsForBurners = ESCache.Instance.Targets.Where(i => !i.IsWreck && !i.IsBadIdea && i.IsTarget && !i.IsNPCDrone)
                    .OrderByDescending(j => j.IsPrimaryWeaponPriorityTarget)
                    .ThenByDescending(j => j.IsDronePriorityTarget)
                    .ThenByDescending(j => j.IsBurnerMainNPC).FirstOrDefault() ;

                if (_pickDroneTargetBasedOnTargetsForBurners != null)
                {
                    return _pickDroneTargetBasedOnTargetsForBurners;
                }

                return null;
            }

            return null;
        }

        public static EntityCache PickDroneTarget_AbyssalDeadSpace()
        {
            IOrderedEnumerable<EntityCache> droneTargets = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot)
                .OrderByDescending(l => l.IsNPCBattlecruiser && !l.IsAttacking)
                .ThenByDescending(k => k.IsNPCBattlecruiser)
                .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWithinOptimalOfDrones)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsCloseToDrones)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted()).ThenByDescending(o => Combat._pickPrimaryWeaponTarget != null &&  Combat._pickPrimaryWeaponTarget != null && o != Combat._pickPrimaryWeaponTarget && o.IsNPCFrigate)
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWithinOptimalOfDrones)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsCloseToDrones)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsTrackable)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsInOptimalRange)
                .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && !ESCache.Instance.Weapons.Any())
                .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianExtractionNode && !ESCache.Instance.Weapons.Any())
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(l => l.IsNPCBattleship && 100 > l.HealthPct)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(i => i.IsEntityIShouldKeepShooting);

            if (droneTargets != null && droneTargets.Any())
            {
                if (DebugConfig.DebugLogOrderOfDroneTargets)
                    LogOrderOfDroneTargets(droneTargets);

                return droneTargets.FirstOrDefault();
            }

            return null;
        }

        public static EntityCache PickDroneTarget_AbyssalDeadSpaceWhileSpeedTank()
        {
            IOrderedEnumerable<EntityCache> droneTargets = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot)
                //.OrderByDescending(l => !l.WeShouldFocusFire && !l.IsKillTarget)
                .OrderByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800)
                .ThenByDescending(l => l.IsNPCBattleship && l.StructurePct < 90)
                .ThenByDescending(l => l.IsNPCBattleship && l.ArmorPct < 90)
                .ThenByDescending(l => l.IsNPCBattleship && l.ShieldPct < 90)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsHighDps)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCBattlecruiser && l.StructurePct < 90)
                .ThenByDescending(l => l.IsNPCBattlecruiser && l.ArmorPct < 90)
                .ThenByDescending(l => l.IsNPCBattlecruiser && l.ShieldPct < 90)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasRemoteRepair)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsSensorDampeningMe)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsHighDps)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(k => k.IsNPCBattlecruiser)
                .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.StructurePct < 90)
                .ThenByDescending(l => l.IsNPCCruiser && l.ArmorPct < 90)
                .ThenByDescending(l => l.IsNPCCruiser && l.ShieldPct < 90)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsHighDps)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && 100 > l.HealthPct && l.IsLastTargetDronesWereShooting) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && 100 > l.HealthPct) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && !l.NpcHasALotOfRemoteRepair) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.StructurePct < 90)
                .ThenByDescending(l => l.IsNPCFrigate && l.ArmorPct < 90)
                .ThenByDescending(l => l.IsNPCFrigate && l.ShieldPct < 90)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsMissileDisruptingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsHighDps)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);

            if (droneTargets != null && droneTargets.Any())
            {
                if (DebugConfig.DebugLogOrderOfDroneTargets)
                    LogOrderOfDroneTargets(droneTargets);

                return droneTargets.FirstOrDefault();
            }

            return null;
        }

        public static EntityCache _pickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets = null;

        public static EntityCache PickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets()
        {
            if (_pickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets != null)
                return _pickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets;

            IOrderedEnumerable<EntityCache> droneTargets = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot)
                //.OrderByDescending(l => l.WeShouldFocusFire)
                .OrderByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && ESCache.Instance.ActiveShip.IsActiveTanked)
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && 100 > l.HealthPct && l.IsLastTargetDronesWereShooting) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && 100 > l.HealthPct) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && !l.NpcHasALotOfRemoteRepair) //kill things shooting drones!
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.ActiveShip.IsActiveTanked && 100 > j.HealthPct)
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.ActiveShip.IsActiveTanked && !j.IsAttacking)
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.ActiveShip.IsActiveTanked)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && l.IsLastTargetDronesWereShooting)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.WeShouldFocusFire)
                .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCCruiser && l.WeShouldFocusFire)
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking) //kill things shooting drones!
                .ThenByDescending(i => !i.Name.ToLower().Contains("karybdis tyrannos".ToLower()))
                .ThenByDescending(l => l.IsNPCBattleship && 100 > l.HealthPct)
                //.ThenByDescending(l => l.IsNPCBattleship && l.IsWithinOptimalOfDrones)
                //.ThenByDescending(l => l.IsNPCBattleship && l.IsCloseToDrones)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && Combat.DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(l => l.IsNPCBattlecruiser && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCBattlecruiser && !l.IsAttacking)
                .ThenByDescending(k => k.IsNPCBattlecruiser)
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking) // dont kill all non-attacking frigates until we have dealt with BCs (see above)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.IsWebbingMe && l.IsLastTargetDronesWereShooting)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && l.IsLastTargetDronesWereShooting)
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWithinOptimalOfDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsCloseToDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && !l.IsKillTarget)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps && !j.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && !l.IsKillTarget)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsTrackable && !i.IsKillTarget)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsInOptimalRange && !i.IsKillTarget)
                .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && !ESCache.Instance.Weapons.Any())
                .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianExtractionNode && !ESCache.Instance.Weapons.Any())
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWithinOptimalOfDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsCloseToDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe  && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && !l.IsKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate)
                .ThenByDescending(i => i.IsEntityIShouldKeepShooting);

            if (DebugConfig.DebugLogOrderOfDroneTargets)
                LogOrderOfDroneTargets(droneTargets);

            if (Combat.PotentialCombatTargets != null && Combat.PotentialCombatTargets.Any())
                if (Combat.PotentialCombatTargets.Any(i => i.IsEntityDronesAreShooting))
                    if (Combat.PotentialCombatTargets.Where(i => i.IsEntityDronesAreShooting).FirstOrDefault().Name == droneTargets.FirstOrDefault().Name)
                        return Combat.PotentialCombatTargets.Where(i => i.IsEntityDronesAreShooting).FirstOrDefault();
            _pickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets = droneTargets.FirstOrDefault();
            return _pickDroneTarget_AbyssalDeadspace_DronesKillHighValueTargets;
        }

        public static EntityCache _pickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos = null;

        public static EntityCache PickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos()
        {
            if (_pickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos != null)
                return _pickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos;

            IOrderedEnumerable<EntityCache> droneTargets = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot)
                .OrderByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(l => l.IsNPCCruiser && 100 > l.HealthPct && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking && !l.IsKillTarget) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWithinOptimalOfDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsCloseToDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && !l.IsKillTarget)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps && !j.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && !l.IsKillTarget)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsTrackable && !i.IsKillTarget)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsInOptimalRange && !i.IsKillTarget)
                .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && !ESCache.Instance.Weapons.Any())
                .ThenByDescending(l => l.IsAbyssalDeadspaceTriglavianExtractionNode && !ESCache.Instance.Weapons.Any())
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && 100 > l.HealthPct && l.IsLastTargetDronesWereShooting) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && 100 > l.HealthPct) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && !l.NpcHasALotOfRemoteRepair) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWithinOptimalOfDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsCloseToDrones && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && !l.IsKillTarget) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && !l.IsKillTarget && Combat.DoWeCurrentlyHaveTurretsMounted()).ThenByDescending(o => Combat._pickPrimaryWeaponTarget != null && o != Combat._pickPrimaryWeaponTarget && o.IsNPCFrigate)
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsKillTarget)
                .ThenByDescending(l => l.IsNPCFrigate)
                .ThenByDescending(i => !i.Name.ToLower().Contains("karybdis tyrannos".ToLower()))
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(i => i.IsEntityIShouldKeepShooting);

            if (DebugConfig.DebugLogOrderOfDroneTargets)
                LogOrderOfDroneTargets(droneTargets);

            _pickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos = droneTargets.FirstOrDefault();
            return _pickDroneTarget_AbyssalDeadSpace_KarybdisTyrannos;
        }

        public static EntityCache PickDroneTarget_AbyssalDeadSpace_KarybdisTyrannosWhileSpeedTank()
        {
            IOrderedEnumerable<EntityCache> droneTargets = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot)
                //.OrderByDescending(l => !l.WeShouldFocusFire && !l.IsKillTarget)
                .OrderByDescending(j => j.IsNPCFrigate && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                .ThenByDescending(j => j.IsNPCFrigate && DronesKillHighValueTargets && j.IsNeutralizingMe && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                .ThenByDescending(k => k.IsAbyssalPrecursorCache)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps && 100 > j.HealthPct)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsHighDps)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe && 100 > l.HealthPct)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsTrackable && 100 > i.HealthPct)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsTrackable)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsInOptimalRange && 100 > i.HealthPct)
                .ThenByDescending(i => i.IsNPCCruiser && i.IsInOptimalRange)
                .ThenByDescending(k => k.IsNPCCruiser && 100 > k.HealthPct)
                .ThenByDescending(k => k.IsNPCCruiser)
                .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && 100 > l.HealthPct && l.IsLastTargetDronesWereShooting) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && 100 > l.HealthPct) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking && !l.NpcHasALotOfRemoteRepair) //kill things shooting drones!
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.StructurePct < 90)
                .ThenByDescending(l => l.IsNPCFrigate && l.ArmorPct < 90)
                .ThenByDescending(l => l.IsNPCFrigate && l.ShieldPct < 90)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps)
                .ThenByDescending(i => i.IsNPCFrigate && i.IsTrackable)
                .ThenByDescending(i => i.IsNPCFrigate && i.IsInOptimalRange)
                .ThenByDescending(i => !i.Name.ToLower().Contains("karybdis tyrannos".ToLower()))
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);

            if (DebugConfig.DebugLogOrderOfDroneTargets)
                LogOrderOfDroneTargets(droneTargets);

            return droneTargets.FirstOrDefault();
        }

        public static EntityCache _pickDroneTarget_DronesKillHighValueTargets = null;

        public static EntityCache PickDroneTarget_DronesKillHighValueTargets()
        {
            if (_pickDroneTarget_DronesKillHighValueTargets != null)
                return _pickDroneTarget_DronesKillHighValueTargets;

            IOrderedEnumerable<EntityCache> droneTargets = Combat.PotentialCombatTargets.Where(i => i.IsReadyForDronesToShoot)
                .OrderByDescending(l => !l.WeShouldFocusFire && l.IsKillTarget)
                .ThenByDescending(a => a.IsWarpScramblingMe)
                .ThenByDescending(b => b.WarpScrambleChance)
                .ThenByDescending(d => d.isPreferredPrimaryWeaponTarget)
                .ThenByDescending(e => e.IsLargeCollidableWeAlwaysWantToBlowupFirst)
                .ThenByDescending(e => e.IsTargetedBy)
                .ThenByDescending(f => f.IsAttacking)
                .ThenByDescending(h => h.IsHighValueTarget)
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(k => k.IsNPCBattlecruiser)
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                .ThenByDescending(o => Combat._pickPrimaryWeaponTarget != null && o != Combat._pickPrimaryWeaponTarget && o.IsNPCFrigate && !o.IsWarpScramblingMe)
                .ThenByDescending(e => e.IsLargeCollidableWeAlwaysWantToBlowupLast)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct)
                .ThenBy(s => s.Nearest5kDistance);

            if (DebugConfig.DebugLogOrderOfDroneTargets)
                LogOrderOfDroneTargets(droneTargets);

            _pickDroneTarget_DronesKillHighValueTargets = droneTargets.FirstOrDefault();
            return _pickDroneTarget_DronesKillHighValueTargets;
        }

        public static void ProcessState()
        {
            try
            {
                if (!OnEveryDroneProcessState()) return;

                switch (State.CurrentDroneState)
                {
                    case DroneState.WaitingForTargets:
                        if (!WaitingForTargetsDroneState()) break;
                        break;

                    case DroneState.Launch:
                        if (!LaunchDronesState()) break;
                        break;

                    case DroneState.Launching:
                        if (!LaunchingDronesState()) break;
                        break;

                    case DroneState.OutOfDrones:
                        if (!OutOfDronesDronesState()) break;
                        break;

                    case DroneState.Fighting:
                        if (!FightingDronesState()) break;
                        break;

                    case DroneState.Recalling:
                        if (!RecallDrones()) break;

                        if (!ActiveDrones.Any())
                        {
                            _lastRecall = DateTime.UtcNow;
                            _nextDroneAction = DateTime.UtcNow.AddSeconds(3);
                            _lastDroneCount = 0;
                            if (!UseDrones)
                            {
                                ChangeDroneState(DroneState.Idle);
                                break;
                            }

                            ChangeDroneState(DroneState.WaitingForTargets);
                            break;
                        }

                        break;

                    case DroneState.Idle:
                        if (!IdleDroneState()) break;
                        break;
                }

                _activeDronesShieldTotalOnLastPulse = GetActiveDroneShieldTotal();
                _activeDronesArmorTotalOnLastPulse = GetActiveDroneArmorTotal();
                _activeDronesStructureTotalOnLastPulse = GetActiveDroneStructureTotal();
                _activeDronesShieldPercentageOnLastPulse = GetActiveDroneShieldPercentage();
                _activeDronesArmorPercentageOnLastPulse = GetActiveDroneArmorPercentage();
                _activeDronesStructurePercentageOnLastPulse = GetActiveDroneStructurePercentage();
                _lastDroneCount = ActiveDrones.Count();
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static bool RecallDrones()
        {
            if (!ActiveDrones.Any())
            {
                _lastDroneCount = 0;
                return true;
            }

            if (DateTime.UtcNow.Subtract(_lastRecallCommand).TotalSeconds > Time.Instance.RecallDronesDelayBetweenRetries + ESCache.Instance.RandomNumber(0, 2))
            {
                if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                {
                    if (DebugConfig.DebugInteractWithEve) Log.WriteLine("Drones.RecallingDronesState: !OkToInteractWithEveNow");
                    return false;
                }

                if (ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdDronesReturnToBay))
                    try
                    {
                        double FarthestDroneDistance = 0;
                        if (ActiveDrones.Any())
                        {
                            FarthestDroneDistance = Math.Round(ActiveDrones.OrderByDescending(i => i.Distance).FirstOrDefault().Distance / 1000, 0);
                        }

                        Log.WriteLine("[" + ActiveDrones.Count() + "] Drones Returning to Bay from [" + FarthestDroneDistance + "] k away");
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        //LastTargetIDDronesEngaged = null;
                        _lastRecallCommand = DateTime.UtcNow;
                        return true;
                    }
                    catch (Exception)
                    {
                    }

                return false;
            }

            return true;
        }

        public static void RemovedDronePriorityTargetsByName(string stringEntitiesToRemove)
        {
            try
            {
                List<EntityCache> entitiesToRemove = ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.ToLower() == stringEntitiesToRemove.ToLower()).ToList();
                if (entitiesToRemove.Any())
                {
                    Log.WriteLine("removing [" + stringEntitiesToRemove + "] from the DPT List");
                    RemoveDronePriorityTargets(entitiesToRemove);
                    return;
                }

                Log.WriteLine("[" + stringEntitiesToRemove + "] was not found on grid");
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static bool RemoveDronePriorityTargets(List<EntityCache> targets)
        {
            try
            {
                targets = targets.ToList();

                if (targets.Any() && _dronePriorityTargets != null && _dronePriorityTargets.Any() &&
                    _dronePriorityTargets.Any(pt => targets.Any(t => t.Id == pt.EntityID)))
                {
                    _dronePriorityTargets.RemoveAll(pt => targets.Any(t => t.Id == pt.EntityID));
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        private static bool ShouldWeSendDronesToAssist()
        {
            if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController")
            {
                if (!ESCache.Instance.ActiveShip.ManageMyOwnDroneTargets)
                {
                    if (DebugConfig.DebugDrones) Log.WriteLine("ShouldWeSendDronesToAssist: ManageMyOwnDroneTargets [" + ESCache.Instance.ActiveShip.ManageMyOwnDroneTargets + "]");
                    if (ActiveDrones.Any(i => 1700 > i.Distance) && Combat.PotentialCombatTargets.Any())
                    {
                        if (DebugConfig.DebugDrones) Log.WriteLine("ShouldWeSendDronesToAssist: ActiveDrones are within 1.7k of my ship (assumed to be not assisting)");
                        if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.AssistMyDronesTo))
                        {
                            //
                            // AssistDrones Here
                            //
                            if (ESCache.Instance.MyFleetMembersAsEntities.Any(i => i.Name == ESCache.Instance.EveAccount.AssistMyDronesTo))
                            {
                                string NameOfToonToAssistDronesTo = ESCache.Instance.MyFleetMembersAsEntities.FirstOrDefault(i => i.Name == ESCache.Instance.EveAccount.AssistMyDronesTo).Name;
                                foreach (DirectFleetMember fleetMember in ESCache.Instance.DirectEve.GetFleetMembers)
                                {
                                    if (DebugConfig.DebugDrones) Log.WriteLine("ShouldWeSendDronesToAssist: FleetMember [" + fleetMember.Name + "]");
                                    if (fleetMember.Name == NameOfToonToAssistDronesTo)
                                    {
                                        if (DebugConfig.DebugDrones) Log.WriteLine("ShouldWeSendDronesToAssist: FleetMember [" + fleetMember.Name + "] == [" + NameOfToonToAssistDronesTo + "]");
                                        if (DateTime.UtcNow > LastDroneFightCmd.AddSeconds(ESCache.Instance.RandomNumber(12, 16)))
                                        {
                                            Log.WriteLine("ShouldWeSendDronesToAssist: Attempt to Assist drones to [" + ESCache.Instance.EveAccount.AssistMyDronesTo + "]");
                                            if (fleetMember.SendDronesToAssist())
                                            {
                                                Log.WriteLine("ShouldWeSendDronesToAssist: Assisting Drones to [" + ESCache.Instance.EveAccount.AssistMyDronesTo + "] success");
                                                LastDroneFightCmd = DateTime.UtcNow;
                                            }
                                        }

                                        return true;
                                    }
                                }

                                return true;
                            }
                            else
                            {
                                Log.WriteLine("ShouldWeSendDronesToAssist: No fleetmembers found via MyFleetMembersAsEntities");
                                int intFleetMember = 0;
                                foreach (DirectFleetMember fleetMember in ESCache.Instance.DirectEve.GetFleetMembers)
                                {
                                    intFleetMember++;
                                    Log.WriteLine("ShouldWeSendDronesToAssist: [" + intFleetMember + "] FleetMember [" + fleetMember.Name + "] CharId [" + fleetMember.CharacterId + "] ShipTypeId [" + fleetMember.ShipTypeID + "] Job [" + fleetMember.Job + "] Role [" + fleetMember.Role + "]");
                                }
                            }
                            return true;
                        }

                        return true;
                    }

                    return true;
                }
            }

            return false;
        }

        private static void EngageTarget()
        {
            try
            {
                if (DebugConfig.DebugDrones) Log.WriteLine("Entering EngageTarget()");

                if (DebugConfig.DebugDrones && State.CurrentQuestorState != QuestorState.CombatMissionsBehavior)
                    Log.WriteLine("MaxDroneRange [" + MaxDroneRange + "] lowValueTargetTargeted [" + Combat.LowValueTargetsTargeted.Count() +
                                  "] LVTT InDroneRange [" +
                                  Combat.LowValueTargetsTargeted.Count(i => i.Distance < MaxDroneRange) + "] highValueTargetTargeted [" +
                                  Combat.HighValueTargetsTargeted.Count() + "] HVTT InDroneRange [" +
                                  Combat.HighValueTargetsTargeted.Count(i => i.Distance < MaxDroneRange) + "]");

                if (ShouldWeSendDronesToAssist()) return;

                //if (_pickDroneTarget != null && (!_pickDroneTarget.Exists || !_pickDroneTarget.IsTarget || !_pickDroneTarget.IsInDroneRange || !_pickDroneTarget.IsCloseToDrones || Time.Instance.LastJumpAction.AddSeconds(45) > DateTime.UtcNow))
                //    _pickDroneTarget = null;

                if (State.CurrentHydraState == HydraState.Combat)
                    if (ESCache.Instance.EveAccount.LeaderIsAggressingTargetId != 0)
                        foreach (EntityCache entity in ESCache.Instance.Targets)
                            if (entity.Id == ESCache.Instance.EveAccount.LeaderIsAggressingTargetId)
                            {
                                _cachedDroneTarget = entity;
                                break;
                            }

                if (!ESCache.Instance.InAbyssalDeadspace)
                    if (_cachedDroneTarget == null && !DronesKillHighValueTargets)
                    {
                        if (PreferredDroneTarget == null || !PreferredDroneTarget.IsFrigate || !PreferredDroneTarget.IsNPCFrigate)
                            GetBestDroneTarget(MaxDroneRange, !DronesKillHighValueTargets, "Drones");

                        _cachedDroneTarget = PreferredDroneTarget;
                    }
                    else if (_cachedDroneTarget == null && DronesKillHighValueTargets)
                    {
                        _cachedDroneTarget = Combat.PreferredPrimaryWeaponTarget;
                    }

                if (_cachedDroneTarget == null || _cachedDroneTarget != null && !_cachedDroneTarget.IsTarget)
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("PreferredDroneTarget is null, picking a target using a simple rule set...MaxDroneRange [" + MaxDroneRange + "]");
                    if (ESCache.Instance.Targets.Any(i => i.IsReadyForDronesToShoot))
                        PickDroneTarget();

                    //if (droneTarget == null && Combat.PotentialCombatTargets.Any())
                    //    Log.WriteLine("DroneToShoot is Null and we still have PotentialCombatTargets on grid.");
                }

                if (_cachedDroneTarget != null)
                {
                    if (_cachedDroneTarget.IsReadyForDronesToShoot)
                    {
                        if (DebugConfig.DebugDrones)
                            Log.WriteLine(
                                "if (DroneToShoot != null && DroneToShoot.IsReadyToShoot && DroneToShoot.Distance < Cache.Instance.MaxDroneRange)");

                        // if there are not any NPC drones of high damage cruisers that may pull aggro (like Abyssal sites!) keep us from spamming engage drones too often!
                        if (!SpamDronesEngage)
                            if (LastTargetIDDronesEngaged != null)
                                if (LastTargetIDDronesEngaged == _cachedDroneTarget.Id &&
                                    ActiveDrones.All(i => i.FollowId == PreferredDroneTargetID && (i.Mode == 1 || i.Mode == 6 || i.Mode == 10)))
                                {
                                    if (DebugConfig.DebugDrones)
                                        Log.WriteLine("if (LastDroneTargetID [" + LastTargetIDDronesEngaged + "] == droneTarget.Id [" + _cachedDroneTarget.Id +
                                                      "] && Cache.Instance.ActiveDrones.Any(i => i.FollowId != Cache.Instance.PreferredDroneTargetID) [" +
                                                      ActiveDrones.Any(i => i.FollowId != PreferredDroneTargetID) + "]) - no need to send other drone commands right now.");

                                    if (!ActiveDrones.All(i => i.DistanceFromEntity(_cachedDroneTarget) > i.OptimalRange * 1.5))
                                    {
                                        if (DebugConfig.DebugDrones) Log.WriteLine("if (!ActiveDrones.All(i => i.DistanceFromEntity(droneTarget) > (i.OptimalRange * 1.5)))");
                                        return;
                                    }

                                    if (DebugConfig.DebugDrones) Log.WriteLine("if (ActiveDrones.Any(i => i.DistanceFromEntity(droneTarget) > (i.OptimalRange * 1.5)))");
                                }

                        try
                        {
                            int activedronenum = 0;
                            foreach (EntityCache activedrone in ActiveDrones)
                            {
                                activedronenum++;
                                if (activedrone.FollowId == 0)
                                {
                                    if (DebugConfig.DebugDrones) Log.WriteLine("activedrone [" + activedronenum + "] FollowID is 0");
                                    LastDroneFightCmd = DateTime.MinValue;
                                }
                                else if (activedrone.Mode == 0)
                                {
                                    if (DebugConfig.DebugDrones) Log.WriteLine("activedrone [" + activedronenum + "] Mode is [" + activedrone.Mode + "].");
                                    LastDroneFightCmd = DateTime.MinValue;
                                }
                                else if (activedrone.Mode != 1 && activedrone.Mode != 4 && activedrone.Mode != 6 && activedrone.Mode != 10)
                                {
                                    if (DebugConfig.DebugDrones) Log.WriteLine("activedrone [" + activedronenum + "] Mode is [" + activedrone.Mode + "]");
                                    LastDroneFightCmd = DateTime.MinValue;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                        }

                        if (_cachedDroneTarget.IsActiveTarget)
                        {
                            if (DebugConfig.DebugDrones) Log.WriteLine("if(droneTarget.IsActiveTarget)");
                            // if there are not any NPC drones of high damage cruisers that may pull aggro (like Abyssal sites!) keep us from spamming engage drones too often!
                            if (LastTargetIDDronesEngaged == null || LastTargetIDDronesEngaged != _cachedDroneTarget.Id || SpamDronesEngage)
                            {
                                if (DebugConfig.DebugDrones) Log.WriteLine("if (LastTargetIDDronesEngaged == null || LastTargetIDDronesEngaged != droneTarget.Id)");
                                if (DateTime.UtcNow > LastDroneFightCmd.AddMilliseconds(3000))
                                {
                                    if (DebugConfig.DebugDrones) Log.WriteLine("if (LastDroneFightCmd.AddSeconds(10) < DateTime.UtcNow)");
                                    if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                                    {
                                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("Drones.EngageTarget: !OkToInteractWithEveNow");
                                        return;
                                    }

                                    if (ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdDronesEngage))
                                    {
                                        if (DronesKillHighValueTargets)
                                        {
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(ESCache.Instance.EveAccount.LastEntityIdEngaged), _cachedDroneTarget.Id);
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(ESCache.Instance.EveAccount.DateTimeLastEntityIdEngaged), DateTime.UtcNow);
                                        }

                                        Log.WriteLine("Engaging [ " + ActiveDrones.Count() + " ] drones on [" + _cachedDroneTarget.Name + "] TypeId [" + _cachedDroneTarget.TypeId + "] GroupId [" + _cachedDroneTarget.GroupId + "][ID: " +
                                                      _cachedDroneTarget.MaskedId + "]" +
                                                      Math.Round(_cachedDroneTarget.Distance / 1000, 0) + "k away]");
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                        LastDroneFightCmd = DateTime.UtcNow;
                                        LastTargetIDDronesEngaged = _cachedDroneTarget.Id;
                                    }
                                }
                            }
                        }
                        else if (_cachedDroneTarget.MakeActiveTarget())
                        {
                            Log.WriteLine("[" + _cachedDroneTarget.Name + "][ID: " + _cachedDroneTarget.MaskedId + "]IsActiveTarget[" +
                                          _cachedDroneTarget.IsActiveTarget + "][" +
                                          Math.Round(_cachedDroneTarget.Distance / 1000, 0) +
                                          "k away] has been made the ActiveTarget (needed for drones)");
                        }
                        else if (DebugConfig.DebugDrones)
                        {
                            Log.WriteLine("if (!droneTarget.IsActiveTarget) && if (!droneTarget.MakeActiveTarget()) - ugh");
                        }

                        return;
                    }

                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("DroneToShoot.IsReadyForDronesToShoot [" + _cachedDroneTarget.IsReadyForDronesToShoot + "] droneTarget.Distance [" + _cachedDroneTarget.Distance + "] < Cache.Instance.MaxDroneRange)");
                    return;
                }

                if (DebugConfig.DebugDrones)
                    Log.WriteLine("if (droneTarget != null)");
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        private static DateTime LastRecallDrones = DateTime.UtcNow;
        private static bool FightingDronesState()
        {
            if (DebugConfig.DebugDrones)
                Log.WriteLine("Should we recall our drones? This is a possible list of reasons why we should");

            if (!ActiveDrones.Any())
            {
                _lastDroneCount = 0;
                Log.WriteLine("Apparently we have lost all our drones");
                ChangeDroneState(DroneState.Idle);
                return false;
            }

            if (Combat.PotentialCombatTargets.Any(pt => pt.IsWarpScramblingMe))
            {
                EntityCache WarpScrambledBy = ESCache.Instance.Targets.OrderBy(d => d.Nearest5kDistance).ThenByDescending(i => i.IsWarpScramblingMe).FirstOrDefault();
                if (WarpScrambledBy != null && DateTime.UtcNow > _nextWarpScrambledWarning)
                {
                    _nextWarpScrambledWarning = DateTime.UtcNow.AddSeconds(20);
                    Log.WriteLine("We are scrambled by: [" + WarpScrambledBy.Name + "][" +
                                  Math.Round(WarpScrambledBy.Distance, 0) + "][" + WarpScrambledBy.Id +
                                  "]");
                }
            }

            if (ShouldWeRecallDrones())
            {
                Statistics.DroneRecalls++;
                LastRecallDrones = DateTime.UtcNow;
                ChangeDroneState(DroneState.Recalling);
                return true;
            }

            if (DebugConfig.DebugDrones) Log.WriteLine("EngageTarget(); - before");

            EngageTarget();

            if (DebugConfig.DebugDrones) Log.WriteLine("EngageTarget(); - after");
            if (ActiveDrones.Count() < _lastDroneCount || ActiveDrones.Count() == 1 || !ActiveDrones.Any())
                ChangeDroneState(DroneState.Launch);

            return true;
        }

        private static double GetActiveDroneArmorPercentage()
        {
            if (!ActiveDrones.Any())
                return 0;

            return ActiveDrones.Sum(d => d.ArmorPct * 100);
        }

        private static double GetActiveDroneArmorTotal()
        {
            if (!ActiveDrones.Any())
                return 0;

            if (ActiveDrones.Any(i => i.ArmorPct * 100 < 100))
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), true);

            return ActiveDrones.Sum(d => d.ArmorHitPoints);
        }

        private static double GetActiveDroneShieldPercentage()
        {
            if (!ActiveDrones.Any())
                return 0;

            return ActiveDrones.Sum(d => d.ShieldPct * 100);
        }

        private static double GetActiveDroneShieldTotal()
        {
            if (!ActiveDrones.Any())
                return 0;

            return ActiveDrones.Sum(d => d.ShieldHitPoints);
        }

        private static double GetActiveDroneStructurePercentage()
        {
            if (!ActiveDrones.Any())
                return 0;

            return ActiveDrones.Sum(d => d.StructurePct * 100);
        }

        private static double GetActiveDroneStructureTotal()
        {
            if (!ActiveDrones.Any())
                return 0;

            if (ActiveDrones.Any(i => i.StructurePct * 100 < 100))
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), true);

            return ActiveDrones.Sum(d => d.StructureHitPoints);
        }

        private static bool IdleDroneState()
        {
            try
            {
                if (ESCache.Instance.InSpace &&
                    ESCache.Instance.ActiveShip.Entity != null &&
                    !ESCache.Instance.ActiveShip.Entity.IsCloaked &&
                    (ESCache.Instance.InAbyssalDeadspace || ESCache.Instance.ActiveShip.GivenName.ToLower().Equals(Combat.CombatShipName.ToLower()) || State.CurrentHydraState == HydraState.Combat) &&
                    UseDrones &&
                    !ESCache.Instance.InWarp)
                {
                    //if (!WeHaveDronesInDroneBay())
                    //    return false;

                    ChangeDroneState(DroneState.WaitingForTargets, false);
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        private static bool LaunchDronesState()
        {
            //if (!WeHaveDronesInDroneBay())
            //{
            //    Log.WriteLine("No Drones in DroneBay?!");
            //    ChangeDroneState(DroneState.Idle, false);
            //    return false;
            //}

            if (SendCommandToLaunchDrones())
            {
                Log.WriteLine("LaunchAllDrones");
                _launchTimeout = DateTime.UtcNow;
                ChangeDroneState(DroneState.Launching, false);
                return true;
            }

            return false;
        }

        private static bool UseThermalDrones
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    if (Combat.PotentialCombatTargets.Any(i => i.Name.ToLower().Contains("karybdis tyrannos".ToLower())))
                        return true;
                }

                return false;
            }
        }

        private static Dictionary<int, string> ThermalDrones = new Dictionary<int, string>
        {
            //{ 1, "Hobgoblin II" },
            //{ 2, "Hobgoblin I" },
            //{ 1, "Hammerhead II" },
            //{ 2, "Hammerhead I" },
            //{ 1, "Ogre II" },
            //{ 2, "Ogre I" },
        };

        private static Dictionary<int, string> ExplosiveDrones = new Dictionary<int, string>
        {
            //{ 1, "Warrior II" },
            //{ 2, "Warrior I" },
            //{ 1, "Valkyrie II" },
            //{ 2, "Valkyrie I" },
            //{ 1, "Berserker II" },
            //{ 2, "Berserker I" },
        };

        private static Dictionary<int, string> KineticDrones = new Dictionary<int, string>
        {
            //{ 1, "Hornet II" },
            //{ 2, "Hornet I" },
            //{ 1, "Vespa II" },
            //{ 2, "Vespa I" },
            //{ 1, "Wasp II" },
            //{ 2, "Wasp I" },
        };

        private static Dictionary<int, string> EmDrones = new Dictionary<int, string>
        {
            //{ 1, "Acolyte II" },
            //{ 2, "Acolyte I" },
            //{ 1, "Infiltrator II" },
            //{ 2, "Infiltrator I" },
            //{ 1, "Praetor II" },
            //{ 2, "Praetor I" },
        };

        /**
        private static List<DirectItem> ThermalDronesInDroneBay
        {
            get
            {
                if (DroneBay != null)
                {
                    if (DroneBay.Items != null && DroneBay.Items.Any())
                    {
                        List<DirectItem> _thermalDronesInDroneBay = new List<DirectItem>();
                        _thermalDronesInDroneBay = DroneBay.Items.Where(droneItem => ThermalDrones.ContainsKey(droneItem.TypeId)).ToList();
                        if (_thermalDronesInDroneBay != null && _thermalDronesInDroneBay.Any())
                        {
                            return _thermalDronesInDroneBay;
                        }
                    }

                    return new List<DirectItem>();
                }

                return new List<DirectItem>();
            }
        }
        **/

        private static bool UseKineticDrones
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    //if (Combat.PotentialCombatTargets.Any(i => i.Name.ToLower().Contains("karybdis tyrannos".ToLower())))
                    //    return true;
                }

                return false;
            }
        }

        private static bool UseExplosiveDrones
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    //if (Combat.PotentialCombatTargets.Any(i => i.Name.ToLower().Contains("karybdis tyrannos".ToLower())))
                    //    return true;
                }

                return false;
            }
        }

        private static bool UseEmDrones
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    //if (Combat.PotentialCombatTargets.Any(i => i.Name.ToLower().Contains("karybdis tyrannos".ToLower())))
                    //    return true;
                }

                return false;
            }
        }
        private static bool SendCommandToLaunchDrones()
        {
            if (ESCache.Instance.ActiveShip == null) return false;
            if (Time.Instance.NextActivateAction > DateTime.UtcNow)
                return false;

            if (Time.Instance.LastJumpAction.AddSeconds(6) > DateTime.UtcNow)
                return false;

            //if (UseThermalDrones && ThermalDronesInDroneBay.Any())
            //{
            //    ESCache.Instance.ActiveShip.LaunchDrones(ThermalDronesInDroneBay)
            //    return true;
            //}

            if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
            {
                if (DebugConfig.DebugInteractWithEve) Log.WriteLine("Drones.ReconnectToDrones: !OkToInteractWithEveNow");
                return false;
            }

            if (!ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdLaunchFavoriteDrones)) return false;
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue( ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);

            return true;
        }

        private static bool FightToTheDeath
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace)
                    return true;

                if (ESCache.Instance.InWormHoleSpace)
                    return true;

                return false;
            }
        }

        private static bool PullDronesForDamage
        {
            get
            {
                if (ESCache.Instance.InAbyssalDeadspace && OurDronesHaveAHugeBonusToHitPoints)
                {
                    return false;
                }

                return true;
            }
        }

        private static bool PullDronesForDamageWhenADroneDies
        {
            get
            {
                //if (ESCache.Instance.InAbyssalDeadspace && OurDronesHaveAHugeBonusToHitPoints && Combat.PotentialCombatTargets.Any(i => !i.NpcHasRemoteRepair && !i.IsAttacking))
                //{
                //    return false;
                //}

                return true;
            }
        }

        private static bool LaunchingDronesState()
        {
            Log.WriteLine("Entering Launching State...");
            if (!ActiveDrones.Any())
            {
                _lastDroneCount = 0;
                Log.WriteLine("No Drones in space yet. waiting. _launchTries [" + _launchTries + "]");
                if (DateTime.UtcNow.Subtract(_launchTimeout).TotalSeconds >= 4)
                {
                    if (_launchTries < 5 || FightToTheDeath)
                    {
                        _launchTries++;
                        ChangeDroneState(DroneState.Launch);
                        return true;
                    }

                    ChangeDroneState(DroneState.OutOfDrones);
                }

                return true;
            }

            Log.WriteLine("[" + ActiveDrones.Count() + "] Drones Launched");
            ChangeDroneState(DroneState.Fighting, false);
            return true;
        }

        private static void LogOrderOfDroneTargets(IOrderedEnumerable<EntityCache> droneTargets)
        {
            int targetnum = 0;
            Log.WriteLine("----------------droneTargets------------------");
            foreach (EntityCache myDroneTarget in droneTargets)
            {
                targetnum++;
                Log.WriteLine(targetnum + ";" + myDroneTarget.Name + ";" + Math.Round(myDroneTarget.Distance / 1000, 0) + "k;" + myDroneTarget.IsBattleship + ";BC;" + myDroneTarget.IsBattlecruiser + ";C;" + myDroneTarget.IsCruiser + ";F;" + myDroneTarget.IsFrigate + ";isAttacking;" + myDroneTarget.IsAttacking + ";IsTargetedBy;" + myDroneTarget.IsTargetedBy + ";IsWarpScramblingMe;" + myDroneTarget.IsWarpScramblingMe + ";IsNeutralizingMe;" + myDroneTarget.IsNeutralizingMe + ";Health;" + myDroneTarget.HealthPct + ";ShieldPct;" + myDroneTarget.ShieldPct + ";ArmorPct;" + myDroneTarget.ArmorPct + ";StructurePct;" + myDroneTarget.StructurePct);
            }

            Log.WriteLine("----------------------------------------------");
        }

        private static bool OnEveryDroneProcessState()
        {
            try
            {
                if (_nextDroneAction > DateTime.UtcNow)
                    return false;

                if (DebugConfig.DebugDrones) Log.WriteLine("Entering Drones.ProcessState");
                _nextDroneAction = DateTime.UtcNow.AddMilliseconds(1200);

                if (ESCache.Instance.InStation ||
                    !ESCache.Instance.InSpace ||
                    ESCache.Instance.MyShipEntity == null ||
                    ESCache.Instance.ActiveShip.Entity.IsCloaked ||
                    ESCache.Instance.InsidePosForceField ||
                    ESCache.Instance.ActiveShip.IsShipWithNoDroneBay
                )
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("InStation [" + ESCache.Instance.InStation + "] InSpace [" + ESCache.Instance.InSpace + "] - doing nothing");
                    ChangeDroneState(DroneState.Idle);
                    return false;
                }

                if (!ESCache.Instance.InAbyssalDeadspace && ESCache.Instance.InWarp) return false;

                //if (!UseDrones && ActiveDrones.Any())
                //{
                //    Log.WriteLine("UseDrones [" + UseDrones + "] - Recalling Drones");
                //    if (!RecallingDronesState()) return false;
                //    return false;
                //}

                if (!ESCache.Instance.InAbyssalDeadspace && ActiveDrones == null)
                {
                    Log.WriteLine("ActiveDrones == null");
                    ChangeDroneState(DroneState.Idle);
                    return false;
                }

                if (ESCache.Instance.ActiveShip.IsShipWithNoDroneBay)
                {
                    Log.WriteLine("IsShipWithNoDronesBay - Setting useDrones to false.");
                    ChangeDroneState(DroneState.Idle);
                    return false;
                }

                if (!UseDrones)
                {
                    if (DebugConfig.DebugDrones) Log.WriteLine("UseDrones [" + UseDrones + "].");
                    return false;
                }

                if (Combat.PotentialCombatTargets.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe))
                {
                    if (DebugConfig.DebugDrones) Log.WriteLine("We are still scrambled!");
                    DronesShouldBePulled = false;
                    return true;
                }

                if (!ESCache.Instance.InAbyssalDeadspace && !ActiveDrones.Any() && ESCache.Instance.InWarp || ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("No Active Drones in space and we are InWarp - doing nothing");
                    RemoveDronePriorityTargets(DronePriorityEntities.ToList());
                    ChangeDroneState(DroneState.Idle);
                    return false;
                }

                if (!ActiveDrones.Any() && State.CurrentDroneState != DroneState.Launching && State.CurrentDroneState != DroneState.Launch)
                {
                    ShouldWeLaunchDrones();
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        private static bool OutOfDronesDronesState()
        {
            if (UseDrones &&
                State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.ExecuteMission)
            {
                if (Statistics.OutOfDronesCount >= 3)
                {
                    Log.WriteLine("We are Out of Drones! AGAIN - Headed back to base to stay!");
                    State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.GotoBase;
                    if (MissionSettings.MyMission != null)
                        MissionSettings.MyMission.MissionCompletionErrors = 10;
                    Statistics.OutOfDronesCount++;
                }

                Log.WriteLine("We are Out of Drones! - Headed back to base to Re-Arm");
                State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.GotoBase;
                Statistics.OutOfDronesCount++;
                return true;
            }

            return true;
        }

        private static DateTime _lastDronesInSpace;
        private static DateTime LastDronesInSpace
        {
            get
            {
                if (ActiveDrones.Any())
                    _lastDronesInSpace = DateTime.UtcNow;

                return _lastDronesInSpace;
            }
        }

        private static bool ShouldWeLaunchDrones()
        {
            if (LastDronesInSpace.AddSeconds(2) > DateTime.UtcNow) return false;

            if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.Capsule) return false;

            if (6 > Math.Round(Math.Abs(DateTime.UtcNow.Subtract(Statistics.StartedPocket).TotalSeconds))) return false;

            if (UseDrones)
                if (State.CurrentPanicState != PanicState.Normal && State.CurrentPanicState != PanicState.Idle)
                    return true;

            if (Time.Instance.NextActivateAction > DateTime.UtcNow)
            {
                if (DebugConfig.DebugDrones)
                    Log.WriteLine("ShouldWeLaunchDrones: if (DateTime.UtcNow > Time.Instance.NextActivateAction)");
                return false;
            }

            if (Time.Instance.LastJumpAction.AddSeconds(25) > DateTime.UtcNow)
            {
                if (DebugConfig.DebugDrones)
                    Log.WriteLine("ShouldWeLaunchDrones: if (DateTime.UtcNow > Time.Instance.LastJumpAction)");
                return false;
            }

            if (Combat.PotentialCombatTargets.All(pt => !pt.IsWarpScramblingMe))
            {
                if (!UseDrones)
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("UseDrones is [" + UseDrones + "] Not Launching Drones");
                    return false;
                }

                /**
                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    if (Combat.PotentialCombatTargets.Any(i => i.IsNPCBattlecruiser))
                    {
                        if (Combat.PotentialCombatTargets.Any(i => i.IsNPCBattlecruiser && !i.WillYellowBoxButPosesLittleThreatToDrones && (!i.IsAttacking || !i.IsTargetedBy)))
                        {
                            if (DebugConfig.DebugDrones)
                                Log.WriteLine("ShouldWeLaunchDrones: if (Combat.PotentialCombatTargets.Where(i => i.IsNPCBattlecruiser && !i.WillYellowBoxButPosesLittleThreatToDrones).Any(i => !i.IsAttacking || !i.IsTargetedBy))");
                            return false;
                        }
                    }

                    if (Combat.PotentialCombatTargets.Any(i => i.IsNPCCruiser && i.WeShouldFocusFire))
                    {
                        if (Combat.PotentialCombatTargets.Count(i => i.IsNPCCruiser && i.WeShouldFocusFire && (!i.IsAttacking || !i.IsTargetedBy)) > 1)
                        {
                            if (DebugConfig.DebugDrones)
                                Log.WriteLine("ShouldWeLaunchDrones: if (Combat.PotentialCombatTargets.Where(i => i.IsNPCCruiser && i.WeShouldFocusFire).Count(i => !i.IsAttacking || !i.IsTargetedBy) > 1)");
                            return false;
                        }
                    }

                    if (Combat.PotentialCombatTargets.Any() && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs)
                    {
                        if (Combat.PotentialCombatTargets.Count(j => !j.WillYellowBoxButPosesLittleThreatToDrones && (!j.IsAttacking || !j.IsTargetedBy)) > 4)
                        {
                            if (DebugConfig.DebugDrones)
                                Log.WriteLine("ShouldWeLaunchDrones: if (Combat.PotentialCombatTargets.Where(j => !j.WillYellowBoxButPosesLittleThreatToDrones).Count(i => !i.IsAttacking || !i.IsTargetedBy) > 4)");
                            return false;
                        }
                    }
                }
                **/

                //if (MissionSettings.Agent != null && MissionSettings.Agent.IsValid && MissionSettings.Agent.IsMissionFinished) return false;

                //
                // The AOE explosion of the Pleasure Gardens in Damsel in Distress kills drones
                //
                if (ESCache.Instance.Targets.Where(i => i.Name.Contains("Pleasure Gardens")).Any(i => .5 > i.StructurePct))
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("if (ESCache.Instance.Targets.Where(i => i.Name.Contains(Pleasure Gardens)).Any(i => .5 > i.StructurePct))");
                    return false;
                }

                if (ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.Contains("Patient Zero") && 60000 > i.Distance).Any())
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("if (ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.Contains(Patient Zero)).Any())");
                    return false;
                }

                if (DronesShouldBePulled)
                {
                    if (DebugConfig.DebugDrones) Log.WriteLine("DronesShouldBePulled [" + DronesShouldBePulled + "] Not Launching Drones");
                    return false;
                }

                if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.GotoBase && !ESCache.Instance.InAbyssalDeadspace)
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("We are not scrambled and CurrentCombatMissionBehaviorState [" + State.CurrentCombatMissionBehaviorState + "] Not Launching Drones");
                    return false;
                }

                if (!Combat.PotentialCombatTargets.Any())
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("We have no PotentialCombatTargets on grid");
                    return false;
                }

                if (Combat.PotentialCombatTargets.All(i => i.Distance > MaxDroneRange) && !ESCache.Instance.InAbyssalDeadspace)
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("All PotentialCombatTargets are outside of your max drone range [" + Math.Round(MaxDroneRange / 1000, 0) + "k]");
                    return false;
                }

                if (State.CurrentHydraState == HydraState.Combat && !ESCache.Instance.Targets.Any() && !ESCache.Instance.Targeting.Any())
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("if (State.CurrentHydraState == HydraState.Combat && !QCache.Instance.Targets.Any() && !QCache.Instance.Targeting.Any())");

                    return false;
                }

                if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController" && !ESCache.Instance.Targets.Any() && !ESCache.Instance.Targeting.Any())
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("if (ESCache.Instance.EveAccount.SelectedController == CombatDontMoveController &&  !ESCache.Instance.Targets.Any() && !ESCache.Instance.Targeting.Any()");

                    return false;
                }

                if (!Combat.Aggressed.Any(e => !e.IsSentry || e.IsSentry && e.KillSentries || e.IsSentry && e.IsEwarTarget && e.Distance < MaxDroneRange) &&
                    State.CurrentHydraState != HydraState.Combat && !ESCache.Instance.InAbyssalDeadspace && ESCache.Instance.EveAccount.SelectedController != "CombatDontMoveController")
                {
                    if (DebugConfig.DebugDrones)
                        Log.WriteLine("We have nothing Aggressed; MaxDroneRange [" + MaxDroneRange + "] DroneControlrange [" + DroneControlRange +
                                      "] TargetingRange [" +
                                      Combat.MaxTargetRange + "]");
                    return false;
                }

                if (State.CurrentQuestorState != QuestorState.CombatMissionsBehavior && State.CurrentHydraState != HydraState.Combat && State.CurrentAbyssalDeadspaceBehaviorState != AbyssalDeadspaceBehaviorState.ExecuteMission && ESCache.Instance.EveAccount.SelectedController != "CombatDontMoveController")
                    if (
                        !ESCache.Instance.EntitiesOnGrid.All(
                            e =>
                                (!e.IsSentry && !e.IsBadIdea && e.CategoryId == (int) CategoryID.Entity && e.IsNpc && !e.IsContainer && !e.IsLargeCollidable ||
                                 e.IsAttacking) && e.Distance < MaxDroneRange))
                    {
                        if (DebugConfig.DebugDrones)
                            Log.WriteLine("QuestorState is [" + State.CurrentQuestorState + "] We have nothing to shoot;");
                        return false;
                    }

                if (!ESCache.Instance.InAbyssalDeadspace)
                {
                    if (ESCache.Instance.InWarp || ESCache.Instance.MyShipEntity.HasInitiatedWarp) return false;

                    //if (ESCache.Instance.AttemptingToWarp) return false;
                }

                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    //if (ESCache.Instance.MyShipEntity.IsFrigate && !OurDronesHaveAHugeBonusToHitPoints && ESCache.Instance.Entities.Any(i => i.IsAbyssalDeadspaceDeviantAutomataSuppressor && 15000 > i.Distance))


                    if (!OurDronesHaveAHugeBonusToHitPoints && ESCache.Instance.Entities.Any(i => i.IsAbyssalDeadspaceDeviantAutomataSuppressor && 40000 > i.Distance))
                        return false;

                    if (!Combat.PotentialCombatTargets.Any())
                        return false;

                    if (Time.Instance.NextActivateAction.AddSeconds(20) > DateTime.UtcNow && Combat.PotentialCombatTargets.Where(i => !i.NpcHasRemoteRepair && !i.IsAttacking).Count() >= 5)
                        return false;
                }

                if (Combat.PotentialCombatTargets.All(i => i.IsTargetedBy))
                    return true;

                if (_lastLaunch < _lastRecall && _lastRecall.Subtract(_lastLaunch).TotalSeconds < 30)
                {
                    if (_lastRecall.AddSeconds(_recallCount + 1) < DateTime.UtcNow)
                    {
                        _recallCount++;

                        if (_recallCount > 4)
                            _recallCount = 4;

                        return true;
                    }

                    Log.WriteLine("Drones: ShouldWeLaunchDrones: We are still in _lastRecall delay.");
                    return false;
                }

                _recallCount = 0;
                return true;
            }

            return true;
        }

        private static bool ShouldWeRecallDrones()
        {
            try
            {
                int lowShieldWarning = LongRangeDroneRecallShieldPct;
                int lowArmorWarning = LongRangeDroneRecallArmorPct;
                int lowCapWarning = LongRangeDroneRecallCapacitorPct;

                if (ActiveDrones.Average(d => d.Distance) < MaxDroneRange / 2d)
                {
                    lowShieldWarning = DroneRecallShieldPct;
                    lowArmorWarning = DroneRecallArmorPct;
                    lowCapWarning = DroneRecallCapacitorPct;
                }

                if (!UseDrones)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: UseDrones is [" + UseDrones + "]");
                    return true;
                }

                if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsWarpScramblingMe) && !ESCache.Instance.InAbyssalDeadspace)
                {
                    if (DebugConfig.DebugDrones) Log.WriteLine("Not recalling drones because we are scrambled");
                    return false;
                }

                if (State.CurrentHydraState != HydraState.Combat)
                    if (MissionSettings.IsMissionFinished) return true;

                if (ESCache.Instance.InAbyssalDeadspace && (Combat.PotentialCombatTargets == null || !Combat.PotentialCombatTargets.Any()))
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: No PotentialCombatTargets on grid");
                    return true;
                }

                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    if (Combat.PotentialCombatTargets.Any(i => i.IsNPCBattlecruiser))
                    {
                        if (Combat.PotentialCombatTargets.Count(i => i.IsNPCBattlecruiser && !i.WillYellowBoxButPosesLittleThreatToDrones  && i.HealthPct > 10 && i.IsValid && (!i.IsAttacking || !i.IsTargetedBy)) >= AbyssalDeadspaceBehavior.NumOfYellowBoxingAbyssalBCsToPullDrones)
                        {
                            Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We have [" + AbyssalDeadspaceBehavior.NumOfYellowBoxingAbyssalBCsToPullDrones + "]+ BCs (mean ones!) yellow boxing us");
                            return true;
                        }
                    }

                    //if (Combat.PotentialCombatTargets.Any(i => i.IsNPCCruiser && i.WeShouldFocusFire))
                    //{
                        //if (Combat.PotentialCombatTargets.Count(i => i.IsNPCCruiser && i.WeShouldFocusFire && i.HealthPct > 10 && i.IsValid && (!i.IsAttacking || !i.IsTargetedBy)) > 1)
                        //{
                        //    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We have 2+ Cruiser NPCs that WeShouldFocusFire on yellow boxing us");
                        //    return true;
                        //}
                    //}

                    if (Combat.PotentialCombatTargets.Any(i => i.IsNPCFrigate))
                    {
                        if (Time.Instance.NextActivateAction.AddSeconds(20) > DateTime.UtcNow && Combat.PotentialCombatTargets.Count(i => i.IsNPCFrigate && !i.NpcHasALotOfRemoteRepair && i.HealthPct > 10 && i.IsValid && (!i.IsAttacking || !i.IsTargetedBy)) >= AbyssalDeadspaceBehavior.NumOfYellowBoxingAbyssalFrigsToPullDrones)
                        {
                            Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We have [" + AbyssalDeadspaceBehavior.NumOfYellowBoxingAbyssalFrigsToPullDrones + "]+ Frigate/Drone NPCs yellow boxing us");
                            return true;
                        }
                    }

                    if (Combat.PotentialCombatTargets.Any() && !AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && Statistics.StartedPocket.AddSeconds(20) > DateTime.UtcNow)
                    {
                        if (Combat.PotentialCombatTargets.Count(j => !j.WillYellowBoxButPosesLittleThreatToDrones && (!j.IsAttacking || !j.IsTargetedBy)) >= AbyssalDeadspaceBehavior.NumOfYellowBoxingAbyssalNPCsToPullDrones)
                        {
                            Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We have [" + AbyssalDeadspaceBehavior.NumOfYellowBoxingAbyssalNPCsToPullDrones + "]+ NPCs yellow boxing us: and we have only been in pocket less than 20 sec");
                            return true;
                        }
                    }
                }

                //
                // The AOE explosion of the Pleasure Gardens in Damsel in Distress kills drones
                //
                if (ESCache.Instance.Targets.Where(i => i.Name.Contains("Pleasure Gardens")).Any(i => .5 > i.StructurePct))
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: UseDrones is [" + UseDrones + "]");
                    return true;
                }

                int TargetedByInDroneRangeCount =
                    Combat.TargetedBy.Count(e => (!e.IsSentry || e.IsSentry && e.KillSentries || e.IsSentry && e.IsEwarTarget) && e.IsInDroneRange);
                if (TargetedByInDroneRangeCount == 0 && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe) && State.CurrentHydraState != HydraState.Combat && State.CurrentAbyssalDeadspaceBehaviorState != AbyssalDeadspaceBehaviorState.ExecuteMission && ESCache.Instance.EveAccount.SelectedController != "CombatDontMoveController")
                {
                    int TargtedByCount = 0;
                    if (Combat.TargetedBy != null && Combat.TargetedBy.Any())
                    {
                        TargtedByCount = Combat.TargetedBy.Count();
                        EntityCache __closestTargetedBy =
                            Combat.TargetedBy.OrderBy(i => i.Nearest5kDistance)
                                .FirstOrDefault(e => !e.IsSentry || e.IsSentry && e.KillSentries || e.IsSentry && e.IsEwarTarget);
                        if (__closestTargetedBy != null)
                            Log.WriteLine("The closest target that is targeting ME is at [" + __closestTargetedBy.Distance + "]k");
                    }

                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: There are [" +
                                  Combat.PotentialCombatTargets.Count(e => e.IsInDroneRange) +
                                  "] PotentialCombatTargets not targeting us within My MaxDroneRange: [" + Math.Round(MaxDroneRange / 1000, 0) +
                                  "k] Targeting Range Is [" +
                                  Math.Round(Combat.MaxTargetRange / 1000, 0) + "k] We have [" + TargtedByCount + "] total things targeting us and [" +
                                  Combat.PotentialCombatTargets.Count() +
                                  "] total PotentialCombatTargets");

                    if (DebugConfig.DebugDrones)
                        foreach (EntityCache PCTInDroneRange in Combat.PotentialCombatTargets.Where(i => i.IsInDroneRange && i.IsTargetedBy))
                            Log.WriteLine("Recalling Drones Details:  PCTInDroneRange [" + PCTInDroneRange.Name + "][" + PCTInDroneRange.MaskedId +
                                          "] at [" +
                                          Math.Round(PCTInDroneRange.Distance / 1000, 2) + "] not targeting us yet");

                    return true;
                }

                if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.GotoBase && !ESCache.Instance.InAbyssalDeadspace)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We changed states to Gotobase and we are not scrambled");
                    return true;
                }

                if (DronesShouldBePulled)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: DronesShouldBePulled [" + DronesShouldBePulled + "]");
                    return true;
                }

                if (ESCache.Instance.InWarp || ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We are warping");
                    return true;
                }

                if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name.ToLower().Contains("anomic team".ToLower()) && OurDronesHaveAHugeBonusToHitPoints && Combat.PotentialCombatTargets.Any(pt => (pt.Name.Contains("Enyo") || pt.Name.Contains("Vengeance") || pt.Name.Contains("Jaguar") || pt.Name.Contains("Hawk")) && !pt.IsAttacking && pt.IsTarget))
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: RecallDronesIfWeLoseAggroOnOurShip and we have a Potential Combat Target locked that is not aggoing us and will likely shoot drones soon!");
                    return true;
                }

                if (ESCache.Instance.Targets == null || ESCache.Instance.Targets != null && !ESCache.Instance.Targets.Any() && State.CurrentHydraState == HydraState.Combat && !DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We have nothing targeted");
                    return true;
                }

                if (ActiveDrones.All(i => i.Distance > 500 && i.Velocity < 10 && 10 > i.HealthPct))
                {
                    Log.WriteLine("Not Recalling [ " + ActiveDrones.Count() + " ] drones: Drones are outside scoop range, less than 10% health and not moving! (should we abandon this drone?)");
                    return false;
                }

                if ((_activeDronesStructureTotalOnLastPulse > GetActiveDroneStructureTotal() + 5) & PullDronesForDamage)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: structure! [Old:" +
                                  _activeDronesStructureTotalOnLastPulse.ToString("N2") +
                                  "][New: " + GetActiveDroneStructureTotal().ToString("N2") + "]");
                    return true;
                }

                if (_activeDronesArmorTotalOnLastPulse > GetActiveDroneArmorTotal() + 5 && PullDronesForDamage)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: armor! [Old:" + _activeDronesArmorTotalOnLastPulse.ToString("N2") +
                                  "][New: " +
                                  GetActiveDroneArmorTotal().ToString("N2") + "]");
                    return true;
                }

                if (_activeDronesShieldTotalOnLastPulse > GetActiveDroneShieldTotal() + 5 && PullDronesForDamage)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: shields! [Old: " +
                                  _activeDronesShieldTotalOnLastPulse.ToString("N2") + "][New: " +
                                  GetActiveDroneShieldTotal().ToString("N2") + "]");
                    return true;
                }

                if ((_activeDronesStructurePercentageOnLastPulse > GetActiveDroneStructurePercentage() + 1) & PullDronesForDamage)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: structure! [Old:" +
                                  _activeDronesStructurePercentageOnLastPulse.ToString("N2") +
                                  "][New: " + GetActiveDroneStructurePercentage().ToString("N2") + "]");
                    return true;
                }

                if (_activeDronesArmorPercentageOnLastPulse > GetActiveDroneArmorPercentage() + 1 && PullDronesForDamage)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: armor! [Old:" +
                                  _activeDronesArmorPercentageOnLastPulse.ToString("N2") + "][New: " +
                                  GetActiveDroneArmorPercentage().ToString("N2") + "]");
                    return true;
                }

                if (_activeDronesShieldPercentageOnLastPulse > GetActiveDroneShieldPercentage() + 1 && PullDronesForDamage)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: shields! [Old: " +
                                  _activeDronesShieldPercentageOnLastPulse.ToString("N2") +
                                  "][New: " + GetActiveDroneShieldPercentage().ToString("N2") + "]");
                    return true;
                }

                //if (GetActiveDroneStructurePercentage() < 10)
                //{
                //    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: structure is very low! [" + GetActiveDroneShieldPercentage().ToString("N2") + "]");
                //    return true;
                //}

                if ((ActiveDrones.Count() < _lastDroneCount || ActiveDrones.Count() == 1) && PullDronesForDamageWhenADroneDies)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones: We lost a drone! [Old:" + _lastDroneCount + "][New: " +
                                  ActiveDrones.Count() + "]");
                    return true;
                }

                if (Combat.PotentialCombatTargets.Any() && !Combat.PotentialCombatTargets.Any(i => i.IsTargeting || i.IsTarget) &&
                    !DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive && !ESCache.Instance.InAbyssalDeadspace)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones due to [" + ESCache.Instance.Targets.Count() +
                                  "] targets being locked. Locking [" +
                                  ESCache.Instance.Targeting.Count() + "] targets atm");
                    return true;
                }

                if (PullDronesForDamage && ESCache.Instance.ActiveShip.ArmorPercentage < lowArmorWarning && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe) && !ESCache.Instance.InAbyssalDeadspace)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones due to armor [" +
                                  Math.Round(ESCache.Instance.ActiveShip.ArmorPercentage, 0) +
                                  "%] below [" + lowArmorWarning + "%] minimum");
                    return true;
                }

                if (PullDronesForDamage && ESCache.Instance.ActiveShip.ShieldPercentage < lowShieldWarning && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe) && !ESCache.Instance.InAbyssalDeadspace)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones due to shield [" +
                                  Math.Round(ESCache.Instance.ActiveShip.ShieldPercentage, 0) +
                                  "%] below [" + lowShieldWarning + "%] minimum");
                    return true;
                }

                if (PullDronesForDamage && ESCache.Instance.ActiveShip.CapacitorPercentage < lowCapWarning && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe) && !ESCache.Instance.InAbyssalDeadspace)
                {
                    Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones due to capacitor [" +
                                  Math.Round(ESCache.Instance.ActiveShip.CapacitorPercentage, 0) +
                                  "%] below [" + lowCapWarning + "%] minimum");
                    return true;
                }

                if (State.CurrentQuestorState == QuestorState.CombatMissionsBehavior && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe))
                {
                    if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.GotoBase && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe) && !ESCache.Instance.InAbyssalDeadspace)
                    {
                        Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones due to gotobase state");
                        return true;
                    }

                    if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.GotoMission && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe) && !ESCache.Instance.InAbyssalDeadspace)
                    {
                        Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones due to gotomission state");
                        return true;
                    }

                    if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.Panic && !ESCache.Instance.EntitiesOnGrid.Any(i => i.IsTargetedBy && i.IsWarpScramblingMe) && !ESCache.Instance.InAbyssalDeadspace)
                    {
                        Log.WriteLine("Recalling [ " + ActiveDrones.Count() + " ] drones due to panic state");
                        return true;
                    }
                }

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        private static bool ShouldWeRecoverLostDrones()
        {
            if (State.CurrentQuestorState != QuestorState.CombatMissionsBehavior)
                return false;

            //if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.ExecuteMission)
            //    return false;

            //if (!QCache.Instance.InMission)
            //    return false;

            if (!UseDrones)
                return false;

            if (DronesShouldBePulled)
                return false;

            if (IsRecoverLostDronesAlreadyProcessedInThisPocket)
                return false;

            if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController")
            {
                if (!Combat.PotentialCombatTargets.Any())
                    return true;

                if (ESCache.Instance.AccelerationGates.Any())
                {
                    if (ESCache.Instance.AccelerationGates.Any(i => 2000 > i.Distance))
                        return true;
                }

                if (ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                    return true;
            }

            if (ESCache.Instance.Entities.Any() && ESCache.Instance.Entities.Any(i => i.TypeId == DroneTypeID && i.Velocity == 0))
            {
                Log.WriteLine("Drones with typeID [" + DroneTypeID + "] were found on grid not moving.");
                if (ESCache.Instance.Entities.Any(i => i._directEntity.OwnerId.ToString() == ESCache.Instance.EveAccount.myCharacterId))
                {
                    if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                    {
                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("Drones.ReconnectToDrones: !OkToInteractWithEveNow");
                        return false;
                    }

                    if (ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdReconnectToDrones))
                    {
                        Log.WriteLine("Drones with typeID [" + DroneTypeID + "] were found on grid not moving and appear to be owned by us! Reconnecting to Drones");
                        IsRecoverLostDronesAlreadyProcessedInThisPocket = true;
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        return true;
                    }

                    return false;
                }

                return false;
            }

            return false;
        }

        private static bool WaitingForTargetsDroneState()
        {
            if (ActiveDrones.Any())
            {
                ChangeDroneState(DroneState.Fighting, false);
                return true;
            }

            if (ESCache.Instance.Targets.Any(i => !i.IsWreck) || Combat.PotentialCombatTargets.Any() && DronesDontNeedTargetsBecauseWehaveThemSetOnAggressive)
            {
                //if (ShouldWeRecoverLostDrones()) return false;
                if (!ShouldWeLaunchDrones()) return false;

                _launchTries = 0;
                _lastLaunch = DateTime.UtcNow;
                ChangeDroneState(DroneState.Launch, false);
                return true;
            }

            return true;
        }

        private static bool WeHaveDronesInDroneBay()
        {
            if (DroneBay != null && DroneBay.Items != null && DroneBay.Items.Any())
                return true;

            return false;
        }

        #endregion Methods
    }
}