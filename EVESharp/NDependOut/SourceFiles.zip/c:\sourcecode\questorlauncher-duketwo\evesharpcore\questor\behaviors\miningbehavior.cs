﻿extern alias SC;

using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Questor.Actions;
using EVESharpCore.Questor.Activities;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Lookup;
using EVESharpCore.States;
using EVESharpCore.Questor.Traveller;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using EVESharpCore.Questor.States;
using EVESharpCore.Questor.Stats;
using EVESharpCore.Framework.Events;
using SC::SharedComponents.Events;
using SC::SharedComponents.Extensions;

namespace EVESharpCore.Questor.Behaviors
{
    public class MiningBehavior
    {
        #region Constructors

        public MiningBehavior()
        {
            ResetStatesToDefaults();
        }

        #endregion Constructors

        #region Fields

        #endregion Fields

        #region Properties


        public static string HomeBookmarkName { get; set; }

        #endregion Properties

        #region Methods

        public static bool ChangeMiningBehaviorState(MiningBehaviorState _StateToSet, bool wait = false, string LogMessage = null)
        {
            try
            {
                if (State.CurrentMiningBehaviorState != _StateToSet)
                {
                    if (_StateToSet == MiningBehaviorState.GotoHomeBookmark)
                    {
                        Traveler.Destination = null;
                        State.CurrentTravelerState = TravelerState.Idle;
                    }

                    Log.WriteLine("New MiningBehaviorState [" + _StateToSet + "]");
                    State.CurrentMiningBehaviorState = _StateToSet;
                    //if (!wait) ProcessState();
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }

            return true;
        }

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            Log.WriteLine("LoadSettings: MiningBehavior");

            HomeBookmarkName =
                (string)CharacterSettingsXml.Element("HomeBookmark") ?? (string)CharacterSettingsXml.Element("HomeBookmark") ??
                (string)CommonSettingsXml.Element("HomeBookmark") ?? (string)CommonSettingsXml.Element("HomeBookmark") ?? "HomeBookmark";
            Log.WriteLine("LoadSettings: AbyssalDeadspaceBehavior: HomeBookmarkName [" + HomeBookmarkName + "]");

        }

        public static void ProcessState()
        {
            try
            {
                if (!EveryPulse()) return;

                if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("State.CurrentAbyssalDeadspaceBehaviorState is [" + State.CurrentAbyssalDeadspaceBehaviorState + "]");

                switch (State.CurrentMiningBehaviorState)
                {
                    case MiningBehaviorState.Idle:
                        MissionSettings.MissionSafeDistanceFromStructure = 22000;
                        IdleCMBState();
                        break;

                    case MiningBehaviorState.Start:
                        StartCMBState();
                        break;

                    case MiningBehaviorState.Switch:
                        SwitchCMBState();
                        break;

                    case MiningBehaviorState.Arm:
                        ArmCMBState(1);
                        break;

                    case MiningBehaviorState.LocalWatch:
                        LocalWatchCMBState();
                        break;

                    case MiningBehaviorState.WaitingforBadGuytoGoAway:
                        WaitingFoBadGuyToGoAway();
                        break;

                    case MiningBehaviorState.WarpOutStation:
                        WarpOutBookmarkCMBState();
                        break;

                    case MiningBehaviorState.FindAsteroidToMine:
                        FindAsteroidToMineState();
                        break;

                    case MiningBehaviorState.GotoHomeBookmark:
                        GotoHomeBookmarkState();
                        break;

                    case MiningBehaviorState.UnloadLoot:
                        UnloadLootCMBState();
                        break;

                    case MiningBehaviorState.Traveler:
                        TravelerCMBState();
                        break;

                    case MiningBehaviorState.Default:
                        ChangeMiningBehaviorState(MiningBehaviorState.Idle);
                        break;
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        private static Dictionary<long, DateTime> AsteroidBeltsWithNoOre = new Dictionary<long, DateTime>();
        private static Dictionary<long, DateTime> AsteroidBeltsWithOtherMiners = new Dictionary<long, DateTime>();
        private static Dictionary<long, DateTime> AsteroidBeltsWithPvP = new Dictionary<long, DateTime>();
        private static Dictionary<long, DateTime> AsteroidBeltsWithNPCs = new Dictionary<long, DateTime>();
        private static Dictionary<long, DateTime> AsteroidBeltsWeAreMiningIn = new Dictionary<long, DateTime>();
        private static Dictionary<long, DateTime> AsteroidsWeWereMining = new Dictionary<long, DateTime>();

        //https://www.fuzzwork.co.uk/ore/


        private static EntityCache _nextAvailableAsteroidBeltInLocal;
        private static EntityCache NextAvailableAsteroidBeltInLocal
        {
            get
            {
                if (_nextAvailableAsteroidBeltInLocal == null)
                {
                    if (AvailableAsteroidBeltsInLocal.Any())
                    {
                        _nextAvailableAsteroidBeltInLocal = AvailableAsteroidBeltsInLocal.OrderBy(i => i.Distance).FirstOrDefault();
                        if (_nextAvailableAsteroidBeltInLocal != null)
                        {
                            return _nextAvailableAsteroidBeltInLocal;
                        }

                        return null;
                    }

                    return null;
                }

                return _nextAvailableAsteroidBeltInLocal;
            }
        }

        private static IEnumerable<EntityCache> _availableAsteroidBeltsInLocal = null;

        private static IEnumerable<EntityCache> AvailableAsteroidBeltsInLocal
        {
            get
            {
                if (ESCache.Instance.InWarp)
                    return new List<EntityCache>();

                if (_availableAsteroidBeltsInLocal == null)
                {
                    if (ESCache.Instance.Entities.Any())
                    {
                        if (ESCache.Instance.Entities.Any(i => i.GroupId == (int)Group.AsteroidBelt))
                        {
                            _availableAsteroidBeltsInLocal = AsteroidBeltsInLocal.Where(i => !AsteroidBeltsWithNoOre.ContainsKey(i.Id) &&
                                                                                !AsteroidBeltsWithPvP.ContainsKey(i.Id) &&
                                                                                !AsteroidBeltsWithOtherMiners.ContainsKey(i.Id) &&
                                                                                !AsteroidBeltsWithNPCs.ContainsKey(i.Id));

                            return _availableAsteroidBeltsInLocal;
                        }

                        return new List<EntityCache>();
                    }

                    return new List<EntityCache>();
                }

                return _availableAsteroidBeltsInLocal;
            }
        }


        private static IEnumerable<EntityCache> _asteroidBeltsInLocal = null;

        private static IEnumerable<EntityCache> AsteroidBeltsInLocal
        {
            get
            {
                if (ESCache.Instance.InWarp)
                    return new List<EntityCache>();

                if (_asteroidBeltsInLocal == null)
                {
                    if (ESCache.Instance.Entities.Any())
                    {
                        if (ESCache.Instance.Entities.Any(i => i.GroupId == (int)Group.AsteroidBelt))
                        {
                            _asteroidBeltsInLocal = ESCache.Instance.Entities.Where(i => i.GroupId == (int)Group.AsteroidBelt);
                            return _asteroidBeltsInLocal;
                        }

                        return new List<EntityCache>();
                    }

                    return new List<EntityCache>();
                }

                return _asteroidBeltsInLocal;
            }
        }

        private static IEnumerable<EntityCache> _minableAsteroids = null;

        private static IEnumerable<EntityCache> MinableAsteroids
        {
            get
            {
                if (ESCache.Instance.InWarp)
                    return new List<EntityCache>();

                if (_minableAsteroids == null)
                {
                    if (ESCache.Instance.Entities.Any())
                    {
                        if (ESCache.Instance.Entities.Any(i => i.CategoryId == (int)CategoryID.Asteroid && i.GroupId == (int)Group.Veldspar))
                        {
                            _minableAsteroids = ESCache.Instance.Entities.Where(i => i.CategoryId == (int)CategoryID.Asteroid && i.GroupId == (int)Group.Veldspar);
                            if (_minableAsteroids != null)
                            {
                                return _minableAsteroids;
                            }

                            return new List<EntityCache>();
                        }

                        return new List<EntityCache>();
                    }

                    return new List<EntityCache>();
                }

                return _minableAsteroids;
            }
        }

        private static void FindAsteroidToMineState()
        {
            if (IsThisAGoodPlaceToMine())
            {
                if (MinableAsteroids.Any())
                {
                    if (MinableAsteroids.OrderBy(i => i.Distance).FirstOrDefault(myAsteroid => 40000 > myAsteroid.Distance) != null)
                    {
                        NavigateOnGrid.NavigateToTarget(MinableAsteroids.OrderBy(i => i.Distance).FirstOrDefault(), 2000);
                        return;
                    }

                    MineRoid();
                }
            }

            GotoNextAsteroidBeltOrSite();
        }

        private static EntityCache ClosestMinableAsteroid
        {
            get
            {
                try
                {
                    if (MinableAsteroids.Any(x => x.IsOnGridWithMe && MiningModules.All(module => module.LastTargetId != x.Id)))
                    {
                        return MinableAsteroids.OrderBy(i => i.Distance).FirstOrDefault();
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        private static IEnumerable<ModuleCache> MiningModules
        {
            get
            {
                if (ESCache.Instance.Modules.Any(i => i.IsMiningModule && i.IsOnline))
                {
                    return ESCache.Instance.Modules.Where(i => i.IsMiningModule && i.IsOnline);
                }

                return new List<ModuleCache>();
            }
        }

        private static double MiningRange
        {
            get
            {
                if (MiningModules.Any())
                {
                    return MiningModules.FirstOrDefault().OptimalRange;
                }

                return 5000;
            }
        }

        private static bool MineRoid()
        {
            //if (AvailableAsteroidBeltsInLocal.Any(i => (int)Distances.OnGridWithMe > i.Distance))
            //{
                if (MinableAsteroids.Any())
                {
                    if (ClosestMinableAsteroid != null)
                    {
                        if (ClosestMinableAsteroid.Distance > MiningRange)
                        {
                            NavigateOnGrid.NavigateToTarget(ClosestMinableAsteroid, 0);
                        }

                        if (MiningModules.Any(i => !i.IsActive && !i.IsInLimboState && i.OptimalRange > ClosestMinableAsteroid.Distance))
                            MiningModules.FirstOrDefault(i => !i.IsActive && !i.IsInLimboState).Activate(ClosestMinableAsteroid);
                        return true;
                    }

                    return false;
                }

                //return false;
            //}

            return false;
        }

        private static bool IsThisAGoodPlaceToMine()
        {
                if (MinableAsteroids.Any())
                {
                    if (ESCache.Instance.EntitiesOnGrid.Any(i => 50000 > i.Distance && i.IsMiner && i.Id != ESCache.Instance.ActiveShip.ItemId))
                    {
                        AsteroidBeltsWithOtherMiners.AddOrUpdate(AvailableAsteroidBeltsInLocal.FirstOrDefault(i => (int)Distances.OnGridWithMe > i.Distance).Id, DateTime.UtcNow);
                        return false;
                    }

                    if (ESCache.Instance.EntitiesOnGrid.Any(i => 50000 > i.Distance && i.IsPlayer && !i.IsMiner && i.Id != ESCache.Instance.ActiveShip.ItemId))
                    {
                        AsteroidBeltsWithPvP.AddOrUpdate(AvailableAsteroidBeltsInLocal.FirstOrDefault(i => (int)Distances.OnGridWithMe > i.Distance).Id, DateTime.UtcNow);
                        return false;
                    }

                    if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsNPCBattlecruiser || i.IsNPCBattleship))
                    {
                        AsteroidBeltsWithNPCs.AddOrUpdate(AvailableAsteroidBeltsInLocal.FirstOrDefault(i => (int)Distances.OnGridWithMe > i.Distance).Id, DateTime.UtcNow);
                        return false;
                    }

                    return true;
                }

                //AsteroidBeltsWithNoOre.AddOrUpdate(AvailableAsteroidBeltsInLocal.FirstOrDefault(i => (int)Distances.OnGridWithMe > i.Distance).Id, DateTime.UtcNow);
                return false;
            //}

            return false;
        }

        private static bool GotoNextAsteroidBeltOrSite()
        {
            if (NextAvailableAsteroidBeltInLocal != null)
            {
                if (NextAvailableAsteroidBeltInLocal.Distance > (int)Distances.WarptoDistance)
                {
                    NavigateOnGrid.NavigateToTarget(NextAvailableAsteroidBeltInLocal, 0);
                    return false;
                }

                return true;
            }

            ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
            return false;
        }

        private static int MiningPrerequisiteCheckRetries = 0;
        private static DateTime LastMiningPrerequisiteCheck = DateTime.UtcNow;
        private static bool MiningPrerequisiteCheck()
        {
            if (DateTime.UtcNow < LastMiningPrerequisiteCheck.AddMinutes(10))
            {
                ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                MiningPrerequisiteCheckRetries++;
                return false;
            }

            if (MiningPrerequisiteCheckRetries > 3)
            {
                Log.WriteLine("MiningPrerequisiteCheck: if (AbyssalSitePrerequisiteCheckRetries > 10): go home");
                ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                MiningPrerequisiteCheckRetries++;
                return false;
            }

            if (ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.Items.Any())
            {
                if (ESCache.Instance.CurrentShipsCargo.Items.All(i => i.GroupId != (int) Group.AbyssalDeadspaceFilament))
                {
                    Log.WriteLine("MiningPrerequisiteCheck: We have no filaments in our cargo: go home");
                    ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                    MiningPrerequisiteCheckRetries++;
                    return false;
                }

                DirectItem abyssalFilament = ESCache.Instance.CurrentShipsCargo.Items.FirstOrDefault(i => i.GroupId == (int) Group.AbyssalDeadspaceFilament);
                if (abyssalFilament != null && !abyssalFilament.IsSafeToUseAbyssalKeyHere)
                {
                    Log.WriteLine("MiningPrerequisiteCheck: We have a filament but it is not safe to activate it here! go home and pause");
                    ESCache.Instance.PauseAfterNextDock = true;
                    ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                    MiningPrerequisiteCheckRetries++;
                    return false;
                }

                if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.All(i => !i.IsEnergyWeapon))
                {
                    if (ESCache.Instance.CurrentShipsCargo.UsedCapacity > ESCache.Instance.CurrentShipsCargo.Capacity * .8)
                    {
                        Log.WriteLine("MiningPrerequisiteCheck: Less than 80% of our cargo space left: go home");
                        ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                        MiningPrerequisiteCheckRetries++;
                        return false;
                    }

                    if (ESCache.Instance.CurrentShipsCargo.Items.Any(i => i.CategoryId == (int)CategoryID.Charge))
                    {
                        foreach (DirectItem ammoItem in ESCache.Instance.CurrentShipsCargo.Items.Where(i => i.CategoryId == (int)CategoryID.Charge))
                        {
                            Log.WriteLine("MiningPrerequisiteCheck: CargoHoldItem: [" + ammoItem.TypeName + "] TypeId [" + ammoItem.TypeId + "] Quantity [" + ammoItem.Quantity + "]");

                            if (ammoItem.Quantity < 2500 && ESCache.Instance.Weapons.All(i => i.GroupId == (int)Group.ProjectileWeapon ||
                                                                                              i.GroupId == (int)Group.HybridWeapon ||
                                                                                              i.IsMissileLauncher))
                            {
                                Log.WriteLine("MiningPrerequisiteCheck: Less than 2500 units, go back to base");
                                ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                                MiningPrerequisiteCheckRetries++;
                                return false;
                            }

                            if (ammoItem.Quantity < 500 && ESCache.Instance.Weapons.All(i => i.GroupId == (int)Group.PrecursorWeapon))
                            {
                                Log.WriteLine("MiningPrerequisiteCheck: Less than 500 units of Precursor weapon ammo, go back to base");
                                ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                                MiningPrerequisiteCheckRetries++;
                                return false;
                            }
                        }

                        Log.WriteLine("MiningPrerequisiteCheck: We have enough ammo.");
                        MiningPrerequisiteCheckRetries = 0;
                        return true;
                        /**
                        if (Drones.UseDrones)
                        {
                            //if (Drones.DroneBay != null && Drones.DroneBay.Capacity > 0)
                            //{
                            //    if (Drones.DroneBay.Capacity - Drones.DroneBay.UsedCapacity >= 25)
                            //    {
                            //        Log.WriteLine("AbyssalSitePrerequisiteCheck: if (Drones.DroneBay.Capacity - Drones.DroneBay.UsedCapacity >= 25)");
                            //        ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.GotoHomeBookmark);
                            //        return false;
                            //    }
                            //
                            Log.WriteLine("AbyssalSitePrerequisiteCheck: We assume we have enough drones!?!");
                            LastAbyssalSitePrerequisiteCheck = DateTime.UtcNow;
                            AbyssalSitePrerequisiteCheckRetries = 0;
                            return true;
                            //}

                            //AbyssalSitePrerequisiteCheckRetries++;
                            //return false;
                        }
                        Log.WriteLine("AbyssalSitePrerequisiteCheck: UseDrones is false");
                        AbyssalSitePrerequisiteCheckRetries = 0;
                        return true;
                        **/
                    }

                    Log.WriteLine("MiningPrerequisiteCheck: We have no ammo left in the cargo!");
                    ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                    MiningPrerequisiteCheckRetries++;
                    return false;
                }

                //Log.WriteLine("AbyssalSitePrerequisiteCheck: We are using Lasers we do not check for ammo when using lasers");
                MiningPrerequisiteCheckRetries = 0;
                return true;
            }

            Log.WriteLine("MiningPrerequisiteCheck: We have no items in our cargo!");
            ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
            return false;
        }

        private static void ArmCMBState(int FilamentsToLoad = 1)
        {
            //if (QCache.Instance.DirectEve.Session.Structureid.HasValue)
            //{
            //    Log.WriteLine("Pausing: Currently Arm does not work in Citadels, manually arm your ammo, drones, repair, etc and unpause");
            //    State.CurrentAbyssalDeadspaceBehaviorState = AbyssalDeadspaceBehaviorState.LocalWatch;
            //    ControllerManager.Instance.SetPause(true);
            //    return;
            //}

            if (!AttemptToBuyAmmo()) return;

            if (State.CurrentArmState == ArmState.Idle)
            {
                Log.WriteLine("Begin Arm");
                Arm.ChangeArmState(ArmState.Begin, true, null);
            }

            if (!ESCache.Instance.InStation) return;

            Arm.ProcessState();

            if (State.CurrentArmState == ArmState.NotEnoughAmmo ||
                State.CurrentArmState == ArmState.NotEnoughDrones)
            {
                if (Settings.Instance.BuyAmmo)
                {
                    Log.WriteLine("Armstate [" + State.CurrentArmState + "]: BuyAmmo [" + Settings.Instance.BuyAmmo + "]");
                    ESCache.Instance.EveAccount.LastAmmoBuy.AddDays(-1);
                    Arm.ChangeArmState(ArmState.Done, true, null);
                    return;
                }

                Log.WriteLine("Armstate [" + State.CurrentArmState + "]: BuyAmmo [" + Settings.Instance.BuyAmmo + "]");
                Arm.ChangeArmState(ArmState.NotEnoughAmmo, true, null);
                return;
            }

            if (State.CurrentArmState == ArmState.Done)
            {
                Arm.ChangeArmState(ArmState.Idle, true, null);

                if (Settings.Instance.BuyAmmo && BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.DisabledForThisSession)
                {
                    BuyAmmoController.CurrentBuyAmmoState = BuyAmmoState.Idle;
                    ControllerManager.Instance.RemoveController(typeof(BuyAmmoController));
                }

                State.CurrentDroneState = DroneState.WaitingForTargets;
                ChangeMiningBehaviorState(MiningBehaviorState.LocalWatch, true);
            }
        }

        private static bool AttemptToBuyAmmo()
        {
            if (ESCache.Instance.DirectEve.Session.IsAbyssalDeadspace || ESCache.Instance.InWormHoleSpace)
                return true;

            if (Settings.Instance.BuyAmmo)
                if (BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.Done && BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.DisabledForThisSession)
                    if (DateTime.UtcNow > ESCache.Instance.EveAccount.LastAmmoBuy.AddHours(8) && DateTime.UtcNow > ESCache.Instance.EveAccount.LastBuyLpItemAttempt.AddHours(1))
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastAmmoBuyAttempt), DateTime.UtcNow);
                        ControllerManager.Instance.AddController(new BuyAmmoController());
                        return false;
                    }

            return true;
        }

        //private static bool WeHaveBeenInPocketTooLong_WarningSent = false;

        public static void ClearPerPocketCache()
        {
            //WeHaveBeenInPocketTooLong_WarningSent = false;
            return;
        }

        private static void ProcessAlerts()
        {
            return;
        }

        private static bool EveryPulse()
        {
            if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugMiningBehavior) Log.WriteLine("MiningBehavior: CMBEveryPulse: if (!QCache.Instance.InSpace && !QCache.Instance.InStation)");
                return false;
            }

            if (Settings.Instance.FinishWhenNotSafe && State.CurrentAbyssalDeadspaceBehaviorState != AbyssalDeadspaceBehaviorState.GotoHomeBookmark)
                if (ESCache.Instance.InSpace &&
                    !ESCache.Instance.LocalSafe(Settings.Instance.LocalBadStandingPilotsToTolerate, Settings.Instance.LocalBadStandingLevelToConsiderBad))
                {
                    Log.WriteLine("Going back to base");
                    ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark, true);
                }

            if (ESCache.Instance.InWormHoleSpace)
            {
                if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("MiningBehavior: CMBEveryPulse: if (QCache.Instance.DirectEve.Session.IsAbyssalDeadspace)");
                return true;
            }

            Panic.ProcessState();

            if (State.CurrentPanicState == PanicState.Resume)
            {
                if (ESCache.Instance.InSpace || ESCache.Instance.InStation)
                {
                    State.CurrentPanicState = PanicState.Normal;
                    State.CurrentTravelerState = TravelerState.Idle;
                    ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                    return true;
                }

                if (DebugConfig.DebugMiningBehavior) Log.WriteLine("MiningBehavior: CMBEveryPulse: if (State.CurrentPanicState == PanicState.Resume)");
                return false;
            }

            if (DoIWantToBeMiningRightNow())
            {
                ChangeMiningBehaviorState(MiningBehaviorState.FindAsteroidToMine);
            }

            return true;
        }

        private static bool DoIWantToBeMiningRightNow()
        {
            if (Time.Instance.QuestorStarted_DateTime.AddMinutes(1) > DateTime.UtcNow)
                return false;

            if (!ESCache.Instance.InSpace)
                return false;

            if (ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                return false;

            if (ESCache.Instance.Entities.Any(i => i.CategoryId == (int)CategoryID.Asteroid) && ESCache.Instance.Modules.Any(module => module.IsMiningModule) && ESCache.Instance.Entities.Any(asteroid => asteroid.GroupId == (int)Group.Veldspar && 10000 > asteroid.Distance))
                return true;

            return false;
        }

        private static void ExecuteAbyssalDeadspaceSiteState()
        {
            if (!ESCache.Instance.InSpace)
            {
                if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("AbyssalDeadspaceBehavior: ExecuteAbyssalDeadspaceSiteState: if (!QCache.Instance.InSpace)");
                return;
            }

            if (ESCache.Instance.CurrentShipsCargo == null)
            {
                if (DebugConfig.DebugAbyssalDeadspaceBehavior) Log.WriteLine("AbyssalDeadspaceBehavior: ExecuteAbyssalDeadspaceSiteState: if (QCache.Instance.CurrentShipsCargo == null)");
                return;
            }

            if (!ESCache.Instance.InAbyssalDeadspace && DateTime.UtcNow > Time.Instance.LastActivateFilamentAttempt.AddSeconds(60))
            {
                //if (QCache.Instance.CurrentShipsCargo != null &&
                //    QCache.Instance.CurrentShipsCargo.Items != null &&
                //    QCache.Instance.CurrentShipsCargo.Items.Any(i => i.TypeId == AbyssalDeadspaceFilamentTypeId) &&
                //    RunAbyssalDeadspaceSitesUntilOurCargoContainsNoMoreCorrectFilaments)
                //{
                //    Log.WriteLine("AbyssalDeadspaceBehavior: ExecuteMission: InRegularSpace: RunAbyssalDeadspaceSitesUntilOurCargoContainsNoMoreCorrectFilaments");
                //    ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.GotoAbyssalBookmark);
                //    return;
                //}

                Log.WriteLine("MiningBehavior: ExecuteMission: InRegularSpace: Go Home");
                ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
                return;
            }

            if (DebugConfig.DebugMiningBehavior) Log.WriteLine("MiningBehavior: ExecuteMission: _actionControl.ProcessState();");

            ActionControl.ProcessState(null, null);

            if (NavigateOnGrid.ChooseNavigateOnGridTargets != null)
                NavigateOnGrid.NavigateIntoRange(NavigateOnGrid.ChooseNavigateOnGridTargets.FirstOrDefault(), "ClearPocket", true);
        }

        private static void GotoHomeBookmarkState()
        {
            if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugGotobase) Log.WriteLine("GotoHomeBookmark: AvoidBumpingThings()");
                NavigateOnGrid.AvoidBumpingThings(ESCache.Instance.BigObjects.FirstOrDefault(), "AbyssalDeadspaceBehaviorState.GotoBase", NavigateOnGrid.TooCloseToStructure, NavigateOnGrid.AvoidBumpingThingsBool());
            }

            if (DebugConfig.DebugGotobase) Log.WriteLine("GotoHomeBookmark: Traveler.TravelToBookmarkName(" + HomeBookmarkName + ");");

            Traveler.TravelToBookmarkName(HomeBookmarkName);

            if (State.CurrentTravelerState == TravelerState.AtDestination)
            {
                if (ESCache.Instance.InSpace)
                {
                    Log.WriteLine("HomeBookmark is defined as [" + HomeBookmarkName + "] and should be a bookmark of a station or citadel we can dock at: why are we still in space?!");
                    //Log.WriteLine("Pausing!");
                    //ControllerManager.Instance.SetPause(true);
                    return;
                }

                Traveler.Destination = null;
                ChangeMiningBehaviorState(MiningBehaviorState.Start, true);
            }
        }

        private static void IdleCMBState()
        {
            State.CurrentAgentInteractionState = AgentInteractionState.Idle;
            State.CurrentArmState = ArmState.Idle;
            State.CurrentDroneState = DroneState.Idle;
            State.CurrentSalvageState = SalvageState.Idle;
            State.CurrentStorylineState = StorylineState.Idle;
            //State.CurrentTravelerState = TravelerState.AtDestination;
            State.CurrentUnloadLootState = UnloadLootState.Idle;

            if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
            {
                if (DebugConfig.DebugTargetWrecks)
                    Log.WriteLine("Salvage.OpenWrecks = false;");
                Salvage.OpenWrecks = false;
            }
            else
            {
                Salvage.OpenWrecks = true;
            }

            ChangeMiningBehaviorState(MiningBehaviorState.GotoHomeBookmark);
        }

        private static DateTime LastDictionaryUpdate = DateTime.UtcNow;

        public static void InvalidateCache()
        {
            _minableAsteroids = null;
            _asteroidBeltsInLocal = null;
            _availableAsteroidBeltsInLocal = null;
            _nextAvailableAsteroidBeltInLocal = null;


            if (DateTime.UtcNow > LastDictionaryUpdate.AddMinutes(1))
            {
                try
                {
                    LastDictionaryUpdate = DateTime.UtcNow;
                    Dictionary<long, DateTime> tempAsteroidBeltsWithNoOre = AsteroidBeltsWithNoOre.Where(i => DateTime.UtcNow > i.Value.AddHours(5)).ToDictionary(x => x.Key, x => x.Value);
                    AsteroidBeltsWithNoOre = tempAsteroidBeltsWithNoOre;

                    Dictionary<long, DateTime> tempAsteroidBeltsWithPvP = AsteroidBeltsWithPvP.Where(i => DateTime.UtcNow > i.Value.AddHours(2)).ToDictionary(x => x.Key, x => x.Value);
                    AsteroidBeltsWithPvP = tempAsteroidBeltsWithPvP;

                    Dictionary<long, DateTime> tempAsteroidBeltsWithOtherMiners = AsteroidBeltsWithOtherMiners.Where(i => DateTime.UtcNow > i.Value.AddMinutes(45)).ToDictionary(x => x.Key, x => x.Value);
                    AsteroidBeltsWithOtherMiners = tempAsteroidBeltsWithOtherMiners;

                    Dictionary<long, DateTime> tempAsteroidBeltsWithNPCs = AsteroidBeltsWithNPCs.Where(i => DateTime.UtcNow > i.Value.AddMinutes(25)).ToDictionary(x => x.Key, x => x.Value);
                    AsteroidBeltsWithNPCs = tempAsteroidBeltsWithNPCs;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }
            }
        }

        private static void LocalWatchCMBState()
        {
            if (Settings.Instance.UseLocalWatch)
            {
                Time.Instance.LastLocalWatchAction = DateTime.UtcNow;

                if (DebugConfig.DebugArm) Log.WriteLine("Starting: Is LocalSafe check...");
                if (ESCache.Instance.LocalSafe(Settings.Instance.LocalBadStandingPilotsToTolerate, Settings.Instance.LocalBadStandingLevelToConsiderBad))
                {
                    Log.WriteLine("local is clear");
                    ChangeMiningBehaviorState(MiningBehaviorState.WarpOutStation);
                    return;
                }

                Log.WriteLine("Bad standings pilots in local: We will stay 5 minutes in the station and then we will check if it is clear again");
                ChangeMiningBehaviorState(MiningBehaviorState.WaitingforBadGuytoGoAway);
                return;
            }

            if (ESCache.Instance.DirectEve.Me.IsPvpLogoffTimerActive)
            {
                Log.WriteLine("AbyssalSitePrerequisiteCheck: We have pvp timer: waiting");
                return;
            }

            ChangeMiningBehaviorState(MiningBehaviorState.WarpOutStation);
        }

        private static bool ResetStatesToDefaults()
        {
            Log.WriteLine("AbyssalDeadspaceBehavior.ResetStatesToDefaults: start");
            State.CurrentAbyssalDeadspaceBehaviorState = AbyssalDeadspaceBehaviorState.Idle;
            State.CurrentArmState = ArmState.Idle;
            State.CurrentUnloadLootState = UnloadLootState.Idle;
            State.CurrentTravelerState = TravelerState.AtDestination;
            Log.WriteLine("CombatMissionsBehavior.ResetStatesToDefaults: done");
            return true;
        }

        private static void StartCMBState()
        {
            //
            // It takes 20 minutes (potentially) to do an abyssal site: if it is within 25min of Downtime (10:35 evetime) pause
            //
            if (DateTime.UtcNow.Hour == 10 && DateTime.UtcNow.Minute > 35)
            {
                Log.WriteLine("AbyssalDeadspaceController: Arm: Downtime is less than 25 minutes from now: Pausing");
                ControllerManager.Instance.SetPause(true);
                return;
            }

            //if (AbyssalFilamentsActivated >= ESCache.Instance.EveAccount.NumOfAbyssalSitesBeforeRestarting)
            //{
            //    //close eve here: if the schedule is on the launcher will restart
            //    ESCache.Instance.CloseQuestor("AbyssalDeadspaceController: We have done [" + ESCache.Instance.EveAccount.NumOfAbyssalSitesBeforeRestarting + "] Abyssal sites, restarting eve");
            //    return;
            //}

            ChangeMiningBehaviorState(MiningBehaviorState.Switch);
        }

        private static void SwitchCMBState()
        {
            //if (QCache.Instance.CurrentShipsCargo == null || QCache.Instance.CurrentShipsCargo.Items == null || QCache.Instance.ItemHangar == null ||
            //    QCache.Instance.ItemHangar.Items == null)
            //    return;

            //if (QCache.Instance.InStation && Settings.Instance.BuyPlex && BuyPlexController.ShouldBuyPlex)
            //{
            //    BuyPlexController.CheckBuyPlex();
            //    ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.Idle);
            //    return;
            //}

            if (State.CurrentArmState == ArmState.Idle)
            {
                Log.WriteLine("Begin");
                Arm.ChangeArmState(ArmState.ActivateCombatShip, true, null);
            }

            if (DebugConfig.DebugArm) Log.WriteLine("CombatMissionBehavior.Switch is Entering Arm.Processstate");
            Arm.ProcessState();

            if (State.CurrentArmState == ArmState.Done)
            {
                Log.WriteLine("Done");
                Arm.SwitchShipsOnly = false;
                Arm.ChangeArmState(ArmState.Idle, true, null);
                ChangeMiningBehaviorState(MiningBehaviorState.UnloadLoot);
            }
        }

        private static void TravelerCMBState()
        {
            try
            {
                if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
                {
                    if (DebugConfig.DebugTargetWrecks) Log.WriteLine("Salvage.OpenWrecks = false;");
                    Salvage.OpenWrecks = false;
                }

                List<long> destination = ESCache.Instance.DirectEve.Navigation.GetDestinationPath();
                if (destination == null || destination.Count == 0)
                {
                    Log.WriteLine("No destination?");
                    State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Error;
                    return;
                }

                if (destination.Count == 1 && destination.FirstOrDefault() == 0)
                    destination[0] = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;

                if (Traveler.Destination == null || Traveler.Destination.SolarSystemId != destination.LastOrDefault())
                {
                    if (ESCache.Instance.DirectEve.Bookmarks != null && ESCache.Instance.DirectEve.Bookmarks.Any())
                    {
                        IEnumerable<DirectBookmark> bookmarks = ESCache.Instance.DirectEve.Bookmarks.Where(b => b.LocationId == destination.LastOrDefault()).ToList();
                        if (bookmarks.FirstOrDefault() != null && bookmarks.Any())
                        {
                            Traveler.Destination = new BookmarkDestination(bookmarks.OrderBy(b => b.CreatedOn).FirstOrDefault());
                            return;
                        }

                        Log.WriteLine("Destination: [" + ESCache.Instance.DirectEve.Navigation.GetLocation(destination.Last()).Name + "]");
                        long lastSolarSystemInRoute = destination.LastOrDefault();

                        Log.WriteLine("Destination: [" + lastSolarSystemInRoute + "]");
                        Traveler.Destination = new SolarSystemDestination(destination.LastOrDefault());
                        return;
                    }

                    return;
                }

                Traveler.ProcessState();

                if (State.CurrentTravelerState == TravelerState.AtDestination)
                {
                    if (State.CurrentCombatMissionCtrlState == ActionControlState.Error)
                    {
                        Log.WriteLine("an error has occurred");
                        ChangeMiningBehaviorState(MiningBehaviorState.Error, true);
                        return;
                    }

                    if (ESCache.Instance.InSpace)
                    {
                        Log.WriteLine("Arrived at destination (in space, Questor stopped)");
                        ChangeMiningBehaviorState(MiningBehaviorState.Error, true);
                        return;
                    }

                    Log.WriteLine("Arrived at destination");
                    ChangeMiningBehaviorState(MiningBehaviorState.Idle, true);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void UnloadLootCMBState()
        {
            try
            {
                if (!ESCache.Instance.InStation)
                    return;

                //if (QCache.Instance.DirectEve.Session.Structureid.HasValue)
                //{
                //    Log.WriteLine("Currently Unloadloot does not work in Citadels, manually move your loot.");
                //    ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.Arm);
                //    return;
                //}

                if (State.CurrentUnloadLootState == UnloadLootState.Idle)
                {
                    Log.WriteLine("UnloadLoot: Begin");
                    State.CurrentUnloadLootState = UnloadLootState.Begin;
                }

                UnloadLoot.ProcessState();

                if (State.CurrentUnloadLootState == UnloadLootState.Done)
                {
                    State.CurrentUnloadLootState = UnloadLootState.Idle;

                    if (State.CurrentCombatState == CombatState.OutOfAmmo)
                        Log.WriteLine("State.CurrentCombatState == CombatState.OutOfAmmo");

                    ChangeMiningBehaviorState(MiningBehaviorState.Arm, true);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void WaitingFoBadGuyToGoAway()
        {
            if (DateTime.UtcNow.Subtract(Time.Instance.LastLocalWatchAction).TotalMinutes <
                Time.Instance.WaitforBadGuytoGoAway_minutes + ESCache.Instance.RandomNumber(1, 3))
                return;

            ChangeMiningBehaviorState(MiningBehaviorState.LocalWatch);
        }

        private static void WarpOutBookmarkCMBState()
        {
            if (!string.IsNullOrEmpty(Settings.Instance.UndockBookmarkPrefix))
            {
                IEnumerable<DirectBookmark> warpOutBookmarks = ESCache.Instance.BookmarksByLabel(Settings.Instance.UndockBookmarkPrefix ?? "");
                if (warpOutBookmarks != null && warpOutBookmarks.Any())
                {
                    DirectBookmark warpOutBookmark = warpOutBookmarks.FirstOrDefault(b => b.LocationId == ESCache.Instance.DirectEve.Session.SolarSystemId && b.Distance < 10000000 && b.Distance > (int)Distances.WarptoDistance);

                    long solarid = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;

                    if (warpOutBookmark == null)
                    {
                        Log.WriteLine("No Bookmark");
                        State.CurrentTravelerState = TravelerState.Idle;
                        ChangeMiningBehaviorState(MiningBehaviorState.FindAsteroidToMine);
                    }
                    else if (warpOutBookmark.LocationId == solarid)
                    {
                        if (Traveler.Destination == null)
                        {
                            Log.WriteLine("Warp at " + warpOutBookmark.Title);
                            Traveler.Destination = new BookmarkDestination(warpOutBookmark);
                        }

                        Traveler.ProcessState();
                        if (State.CurrentTravelerState == TravelerState.AtDestination)
                        {
                            Log.WriteLine("Safe!");
                            State.CurrentTravelerState = TravelerState.Idle;
                            ChangeMiningBehaviorState(MiningBehaviorState.FindAsteroidToMine);
                            Traveler.Destination = null;
                        }
                    }
                    else
                    {
                        Log.WriteLine("No Bookmark in System");
                        State.CurrentTravelerState = TravelerState.Idle;
                        ChangeMiningBehaviorState(MiningBehaviorState.FindAsteroidToMine);
                    }

                    return;
                }
            }

            Log.WriteLine("No Bookmark in System");
            ChangeMiningBehaviorState(MiningBehaviorState.FindAsteroidToMine);
        }

        #endregion Methods
    }
}