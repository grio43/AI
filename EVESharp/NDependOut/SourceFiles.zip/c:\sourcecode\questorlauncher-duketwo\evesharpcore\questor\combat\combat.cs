﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.States;
using SC::SharedComponents.EVE.ClientSettings;

namespace EVESharpCore.Questor.Combat
{
    public static partial class Combat
    {
        #region Fields

        private static bool? _doWeCurrentlyHaveProjectilesMounted;
        private static bool? _doWeCurrentlyHaveTurretsMounted;
        public static string DefaultCombatShipName;
        public static string AnomicShipName;

        public static IEnumerable<EntityCache> HighValueTargetsTargeted
        {
            get
            {
                try
                {
                    if (ESCache.Instance.EntitiesOnGrid != null && ESCache.Instance.EntitiesOnGrid.Any())
                    {
                        List<EntityCache> highValueTargetsTargeted = ESCache.Instance.EntitiesOnGrid.Where(t => !t.IsLowValueTarget && (t.IsTarget || t.IsTargeting) && !t.IsWreck && !t.IsContainer).ToList();
                        if (highValueTargetsTargeted != null && highValueTargetsTargeted.Any())
                        {
                            return highValueTargetsTargeted;
                        }

                        return new List<EntityCache>();
                    }

                    return new List<EntityCache>();
                }
                catch (Exception ex)
                {
                   Log.WriteLine("Exception [" + ex + "]");
                   return new List<EntityCache>();
                }
            }
        }

        public static EntityCache LastTargetPrimaryWeaponsWereShooting;
        public static IEnumerable<EntityCache> LowValueTargetsTargeted
        {
            get
            {
                try
                {
                    if (ESCache.Instance.EntitiesOnGrid != null && ESCache.Instance.EntitiesOnGrid.Any())
                    {
                        List<EntityCache> lowValueTargetsTargeted = ESCache.Instance.EntitiesOnGrid.Where(t => t.IsLowValueTargetThatIsTargeted && !t.IsWreck && !t.IsContainer).ToList();
                        if (lowValueTargetsTargeted != null && lowValueTargetsTargeted.Any())
                        {
                            return lowValueTargetsTargeted;
                        }

                        return new List<EntityCache>();
                    }

                    return new List<EntityCache>();
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return new List<EntityCache>();
                }
            }
        }
        public static int? maxHighValueTargets;
        public static int? maxLowValueTargets;
        public static long? PreferredPrimaryWeaponTargetID;
        public static string ScanningShipName;
        private static List<EntityCache> _aggressed;
        private static bool _isJammed;
        private static bool _killSentries;

        private static DateTime _lastCombatProcessState;

        //private static DateTime _lastReloadAll;
        private static double? _maxrange { get; set; }
        private static double? _maxWeaponRange;
        private static double? _maxTargetRange;
        private static List<EntityCache> _potentialCombatTargets;
        private static EntityCache _preferredPrimaryWeaponTarget;
        private static IEnumerable<EntityCache> _primaryWeaponPriorityEntities;
        private static List<PriorityTarget> _primaryWeaponPriorityTargets;
        private static List<PriorityTarget> _primaryWeaponPriorityTargetsPerFrameCaching;
        private static List<EntityCache> _targetedBy;
        private static int _weaponNumber;
        private static int icount;

        #endregion Fields

        #region Properties

        public static bool AddDampenersToPrimaryWeaponsPriorityTargetList { get; set; }

        public static bool AddECMsToPrimaryWeaponsPriorityTargetList { get; set; }

        public static bool AddNeutralizersToPrimaryWeaponsPriorityTargetList { get; set; }

        public static bool AddTargetPaintersToPrimaryWeaponsPriorityTargetList { get; set; }

        public static bool AddTrackingDisruptorsToPrimaryWeaponsPriorityTargetList { get; set; }

        public static bool AddWarpScramblersToPrimaryWeaponsPriorityTargetList { get; set; }

        public static bool AddWebifiersToPrimaryWeaponsPriorityTargetList { get; set; }

        public static IEnumerable<EntityCache> Aggressed
        {
            get { return _aggressed ?? (_aggressed = PotentialCombatTargets.Where(e => e.IsAttacking).ToList()); }
        }

        public static void ClearPerPocketCache()
        {
            _doWeCurrentlyHaveProjectilesMounted = null;
            LastTargetPrimaryWeaponsWereShooting = null;
            return;
        }

        public static string CombatShipName
        {
            get
            {
                try
                {
                    if (MissionSettings.MyMission != null)
                    {
                        if (MissionSettings.MyMission.Name.Contains("Anomic"))
                            return AnomicShipName;

                        if (!string.IsNullOrEmpty(MissionSettings.MissionSpecificShipName))
                            return MissionSettings.MissionSpecificShipName;
                    }

                    //
                    //if (!string.IsNullOrEmpty(MissionSettings.FactionSpecificShip))
                    //    return MissionSettings.FactionSpecificShip;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                return DefaultCombatShipName;
            }
        }

        public static int DoNotSwitchTargetsIfTargetHasMoreThanThisArmorDamagePercentage { get; set; }
        public static bool DontShootFrigatesWithSiegeorAutoCannons { get; set; }

        public static bool KillSentries
        {
            get
            {
                if (MissionSettings.MissionKillSentries != null)
                    return (bool)MissionSettings.MissionKillSentries;
                return _killSentries;
            }
            set => _killSentries = value;
        }

        public static double ListPriorityTargetsEveryXSeconds { get; set; }

        public static double LowValueTargetsHaveToBeWithinDistance
        {
            get
            {
                if (Drones.UseDrones && Drones.MaxDroneRange != 0)
                    return Drones.MaxDroneRange;

                return MaxRange;
            }
        }

        public static int MaximumTargetValueToConsiderTargetALowValueTarget { get; set; }

        public static double MaxRange
        {
            get
            {
                if (_maxrange == null)
                {
                    if (ESCache.Instance.Weapons.Any())
                    {
                        /**
                        if (ESCache.Instance.MyShipEntity.IsFrigate)
                        {
                            _maxrange = MaxTargetRange;
                            return _maxrange ?? 0;
                        }
                        **/

                        if (Drones.DronesKillHighValueTargets)
                        {
                            _maxrange = Math.Max(ESCache.Instance.WeaponRange, Drones.DroneControlRange);
                            return _maxrange ?? 0;
                        }

                        _maxrange = Math.Min(ESCache.Instance.WeaponRange, MaxTargetRange);
                        return _maxrange ?? 0;
                    }

                    if (ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Nestor)
                    {
                        _maxrange = 50000;
                        return _maxrange ?? 0;
                    }

                    if (ESCache.Instance.ActiveShip.GroupId == (int)Group.Logistics)
                    {
                        _maxrange = 80000;
                        return _maxrange ?? 0;
                    }

                    return _maxrange ?? 0;
                }

                return _maxrange ?? 0;
            }
        }

        public static double MaxWeaponRange
        {
            get
            {
                if (_maxWeaponRange == null)
                {
                    if (ESCache.Instance.Weapons.Any())
                    {
                        /**
                        if (ESCache.Instance.MyShipEntity.IsFrigate)
                        {
                            _maxWeaponRange = MaxTargetRange;
                            return _maxWeaponRange ?? 0;
                        }
                        **/

                        _maxWeaponRange = Math.Min(ESCache.Instance.WeaponRange, MaxTargetRange);
                        return _maxWeaponRange ?? 0;
                    }

                    return _maxWeaponRange ?? 0;
                }

                return _maxWeaponRange ?? 0;
            }
        }
        public static double MaxTargetRange
        {
            get
            {
                if (_maxTargetRange == null)
                {
                    _maxTargetRange = ESCache.Instance.ActiveShip.MaxTargetRange;
                    return _maxTargetRange ?? 0;
                }

                return _maxTargetRange ?? 0;
            }
        }
        public static int MinimumAmmoCharges { get; set; }
        public static int MinimumTargetValueToConsiderTargetAHighValueTarget { get; set; }
        public static int NosDistance { get; set; }
        public static List<EntityCache> NotYetTargetingMeAndNotYetTargeted { get; set; }

        //public static Dictionary<int, int> EntityHealthTracking = new Dictionary<int, int>();

        public static IEnumerable<EntityCache> PotentialCombatTargets
        {
            get
            {
                if (_potentialCombatTargets == null)
                {
                    if (ESCache.Instance.InSpace)
                    {
                        _potentialCombatTargets = ESCache.Instance.EntitiesOnGrid.Where(e => e.CategoryId == (int)CategoryID.Entity
                                                                                             && !e.IsIgnored
                                                                                             && (!e.IsSentry || e.IsSentry && e.KillSentries || e.IsSentry && e.IsEwarTarget)
                                                                                             && (e.IsNpcByGroupID || e.IsAttacking || e.IsDecloakedTransmissionRelay || ((e.IsAbyssalDeadspaceTriglavianBioAdaptiveCache || e.IsAbyssalDeadspaceTriglavianExtractionNode) && ESCache.Instance.InAbyssalDeadspace) || e.IsLargeCollidableWeAlwaysWantToBlowupLast || e.IsLargeCollidableWeAlwaysWantToBlowupFirst)
                                                                                             && !e.IsContainer
                                                                                             && !e.IsFactionWarfareNPC
                                                                                             && !e.IsEntityIShouldLeaveAlone
                                                                                             && !e.IsBadIdea
                                                                                             && (!e.IsPlayer || e.IsPlayer && e.IsAttacking || e.IsPlayer && State.CurrentHydraState == HydraState.Combat)
                                                                                             && !e.IsMiscJunk
                                                                                             && (!e.IsLargeCollidable || e.IsPrimaryWeaponPriorityTarget || (e.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && ESCache.Instance.InAbyssalDeadspace) || e.IsDecloakedTransmissionRelay || e.IsLargeCollidableWeAlwaysWantToBlowupLast || e.IsLargeCollidableWeAlwaysWantToBlowupFirst)
                            )
                            .ToList();

                        if (_potentialCombatTargets == null || !_potentialCombatTargets.Any())
                            _potentialCombatTargets = new List<EntityCache>();

                        return _potentialCombatTargets ?? new List<EntityCache>();
                    }

                    return new List<EntityCache>();
                }

                return _potentialCombatTargets;
            }
        }

        public static EntityCache PreferredPrimaryWeaponTarget
        {
            get
            {
                if (_preferredPrimaryWeaponTarget == null)
                {
                    if (PreferredPrimaryWeaponTargetID != null)
                    {
                        _preferredPrimaryWeaponTarget = ESCache.Instance.EntitiesOnGrid.FirstOrDefault(e => e.Id == PreferredPrimaryWeaponTargetID);

                        return _preferredPrimaryWeaponTarget ?? null;
                    }

                    return null;
                }

                return _preferredPrimaryWeaponTarget;
            }
            set
            {
                if (value == null)
                {
                    if (_preferredPrimaryWeaponTarget != null)
                    {
                        _preferredPrimaryWeaponTarget = null;
                        PreferredPrimaryWeaponTargetID = null;
                        if (DebugConfig.DebugPreferredPrimaryWeaponTarget)
                            Log.WriteLine("[ null ]");
                    }
                }
                else if (_preferredPrimaryWeaponTarget != null && _preferredPrimaryWeaponTarget.Id != value.Id || _preferredPrimaryWeaponTarget == null)
                {
                    _preferredPrimaryWeaponTarget = value;
                    PreferredPrimaryWeaponTargetID = value.Id;
                    if (DebugConfig.DebugPreferredPrimaryWeaponTarget)
                        Log.WriteLine(value.Name + " [" + value.MaskedId + "][" + Math.Round(value.Distance / 1000, 0) + "k] isTarget [" +
                                      value.IsTarget + "]");
                }
            }
        }

        public static IEnumerable<EntityCache> PrimaryWeaponPriorityEntities
        {
            get
            {
                try
                {
                    if (_primaryWeaponPriorityEntities == null)
                    {
                        if (_primaryWeaponPriorityTargets != null && _primaryWeaponPriorityTargets.Any())
                        {
                            _primaryWeaponPriorityEntities =
                                PrimaryWeaponPriorityTargets.OrderByDescending(pt => pt.PrimaryWeaponPriority)
                                    .ThenBy(pt => pt.Entity.Nearest5kDistance)
                                    .Select(pt => pt.Entity)
                                    .ToList();
                            return _primaryWeaponPriorityEntities;
                        }

                        if (DebugConfig.DebugAddPrimaryWeaponPriorityTarget)
                            Log.WriteLine("if (_primaryWeaponPriorityTargets.Any()) none available yet");
                        _primaryWeaponPriorityEntities = new List<EntityCache>();
                        return _primaryWeaponPriorityEntities;
                    }

                    return _primaryWeaponPriorityEntities;
                }
                catch (NullReferenceException)
                {
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public static List<PriorityTarget> PrimaryWeaponPriorityTargets
        {
            get
            {
                try
                {
                    if (_primaryWeaponPriorityTargetsPerFrameCaching == null)
                    {
                        if (_primaryWeaponPriorityTargets != null && _primaryWeaponPriorityTargets.Any())
                        {
                            foreach (PriorityTarget _primaryWeaponPriorityTarget in _primaryWeaponPriorityTargets)
                                if (ESCache.Instance.EntitiesOnGrid.All(e => e.Id != _primaryWeaponPriorityTarget.EntityID))
                                {
                                    Log.WriteLine("[" + _primaryWeaponPriorityTarget.Name + "] ID[" +
                                                  _primaryWeaponPriorityTarget.MaskedID + "] PriorityLevel [" +
                                                  _primaryWeaponPriorityTarget.PrimaryWeaponPriority + "] is dead / gone");
                                    _primaryWeaponPriorityTargets.Remove(_primaryWeaponPriorityTarget);
                                    break;
                                }

                            _primaryWeaponPriorityTargetsPerFrameCaching = _primaryWeaponPriorityTargets;
                            return _primaryWeaponPriorityTargets;
                        }

                        _primaryWeaponPriorityTargets = new List<PriorityTarget>();
                        _primaryWeaponPriorityTargetsPerFrameCaching = _primaryWeaponPriorityTargets;
                        return _primaryWeaponPriorityTargets;
                    }

                    return _primaryWeaponPriorityTargetsPerFrameCaching;
                }
                catch (NullReferenceException)
                {
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
            set => _primaryWeaponPriorityTargets = value;
        }

        public static int RemoteRepairDistance { get; set; }

        public static IEnumerable<EntityCache> TargetedBy
        {
            get { return _targetedBy ?? (_targetedBy = PotentialCombatTargets.Where(e => e.IsTargetedBy).ToList()); }
        }

        public static List<EntityCache> TargetingMe { get; set; }
        private static int MaxCharges { get; set; }

        private static int maxTotalTargets
        {
            get
            {
                try
                {
                    return maxHighValueTargets + maxLowValueTargets ?? 2;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return 2;
                }
            }
        }

        #endregion Properties

        #region Methods

        /**
        public static bool CheckForECMPriorityTargetsInOrder(EntityCache currentTarget, double distance)
        {
            try
            {
                return
                    true && SetPrimaryWeaponPriorityTarget(currentTarget, PrimaryWeaponPriority.WarpScrambler, distance) ||
                    true && SetPrimaryWeaponPriorityTarget(currentTarget, PrimaryWeaponPriority.Jamming, distance) ||
                    true && SetPrimaryWeaponPriorityTarget(currentTarget, PrimaryWeaponPriority.Webbing, distance) ||
                    AddTrackingDisruptorsToPrimaryWeaponsPriorityTargetList &&
                    SetPrimaryWeaponPriorityTarget(currentTarget, PrimaryWeaponPriority.TrackingDisrupting, distance) ||
                    AddNeutralizersToPrimaryWeaponsPriorityTargetList &&
                    SetPrimaryWeaponPriorityTarget(currentTarget, PrimaryWeaponPriority.Neutralizing, distance) ||
                    AddTargetPaintersToPrimaryWeaponsPriorityTargetList &&
                    SetPrimaryWeaponPriorityTarget(currentTarget, PrimaryWeaponPriority.TargetPainting, distance) ||
                    AddDampenersToPrimaryWeaponsPriorityTargetList && SetPrimaryWeaponPriorityTarget(currentTarget, PrimaryWeaponPriority.Dampening, distance);
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }
        **/

        public static EntityCache CurrentWeaponTarget()
        {
            EntityCache _currentWeaponTarget = null;

            try
            {
                if (!ESCache.Instance.Weapons.Any()) return null;

                ModuleCache weapon = ESCache.Instance.Weapons.FirstOrDefault(m => m.IsOnline
                                                                                  && !m.IsReloadingAmmo
                                                                                  && m.IsActive);
                if (weapon != null)
                {
                    _currentWeaponTarget = ESCache.Instance.EntityById(weapon.TargetId);

                    if (_currentWeaponTarget != null && _currentWeaponTarget.IsReadyToShoot)
                        return _currentWeaponTarget;

                    return null;
                }

                return null;
            }
            catch (Exception exception)
            {
                Log.WriteLine("exception [" + exception + "]");
            }

            return null;
        }

        public static bool DoWeCurrentlyHaveTurretsMounted()
        {
            try
            {
                if (_doWeCurrentlyHaveTurretsMounted == null)
                {
                    foreach (ModuleCache m in ESCache.Instance.Modules)
                        if (m.GroupId == (int)Group.ProjectileWeapon
                            || m.GroupId == (int)Group.EnergyWeapon
                            || m.GroupId == (int)Group.HybridWeapon
                            || m.GroupId == (int)Group.PrecursorWeapon
                        )
                        {
                            _doWeCurrentlyHaveTurretsMounted = true;
                            return _doWeCurrentlyHaveTurretsMounted ?? true;
                        }

                    _doWeCurrentlyHaveTurretsMounted = false;
                    return _doWeCurrentlyHaveTurretsMounted ?? false;
                }

                return _doWeCurrentlyHaveTurretsMounted ?? false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }

            return false;
        }

        public static bool DoWeCurrentlyProjectilesMounted()
        {
            try
            {
                if (_doWeCurrentlyHaveProjectilesMounted == null)
                {
                    foreach (ModuleCache m in ESCache.Instance.Modules)
                        if (m.GroupId == (int)Group.ProjectileWeapon
                        )
                        {
                            _doWeCurrentlyHaveProjectilesMounted = true;
                            return _doWeCurrentlyHaveProjectilesMounted ?? true;
                        }

                    _doWeCurrentlyHaveProjectilesMounted = false;
                    return _doWeCurrentlyHaveProjectilesMounted ?? false;
                }

                return _doWeCurrentlyHaveProjectilesMounted ?? false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }

            return false;
        }

        public static EntityCache FindCurrentTarget()
        {
            try
            {
                EntityCache currentTarget = null;

                if (currentTarget == null)
                {
                    if (CurrentWeaponTarget() != null
                        && CurrentWeaponTarget().IsReadyToShoot
                        && !CurrentWeaponTarget().IsIgnored)
                    {
                        LastTargetPrimaryWeaponsWereShooting = CurrentWeaponTarget();
                        currentTarget = LastTargetPrimaryWeaponsWereShooting;
                    }

                    if (DateTime.UtcNow < Time.Instance.LastPreferredPrimaryWeaponTargetDateTime.AddSeconds(6) && PreferredPrimaryWeaponTarget != null &&
                        ESCache.Instance.EntitiesOnGrid.Any(t => t.Id == PreferredPrimaryWeaponTargetID))
                        if (DebugConfig.DebugGetBestTarget)
                            Log.WriteLine("We have a PreferredPrimaryWeaponTarget [" + PreferredPrimaryWeaponTarget.Name + "][" +
                                          Math.Round(PreferredPrimaryWeaponTarget.Distance / 1000, 0) +
                                          "k] that was chosen less than 6 sec ago, and is still alive.");
                }

                return currentTarget;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return null;
            }
        }

        public static void LoadAmmoSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                if (ESCache.Instance.InSpace && MissionSettings.SelectedControllerUsesCombatMissionsBehavior && DateTime.UtcNow > Time.Instance.QuestorStarted_DateTime.AddSeconds(15))
                    return;

                //if (DirectModule.DefinedAmmoTypes != null)
                //    return;

                //if (DirectModule.DefinedAmmoTypes != null && DirectModule.DefinedAmmoTypes.Any())
                //    return;

                DirectModule.DefinedAmmoTypes = new List<AmmoType>();
                XElement ammoTypes = CharacterSettingsXml.Element("ammoTypes") ?? CommonSettingsXml.Element("ammoTypes");

                if (ammoTypes != null)
                    foreach (XElement ammo in ammoTypes.Elements("ammoType"))
                    {
                        AmmoType ammoToAdd = new AmmoType(ammo);
                        Log.WriteLine("Adding DefinedAmmoTypes [" + ammoToAdd.Description + "] TypeId [" + ammoToAdd.TypeId + "][" + ammoToAdd.DamageType + "] Range [" + ammoToAdd.Range + "] Quantity [" + ammoToAdd.Quantity + "]");
                        DirectModule.DefinedAmmoTypes.Add(ammoToAdd);
                    }

                //do not allow MinimumAmmoCharges to be set lower than 1. We always want to reload before the weapon is empty!
            }
            catch (Exception exception)
            {
                Log.WriteLine("Error Loading DefinedAmmoTypes Settings [" + exception + "]");
            }

            //
            // Verify settings loaded correctly and log errors as needed
            //
            if (DirectModule.DefinedAmmoTypes == null)
                Log.WriteLine("Combat.Combat.DefinedAmmoTypes == null");

            if (DirectModule.DefinedAmmoTypes != null && DirectModule.DefinedAmmoTypes.Any())
            {
                if (DirectModule.DefinedAmmoTypes.Select(a => a.DamageType).Distinct().Count() != 4)
                {
                    if (DirectModule.DefinedAmmoTypes.All(a => a.DamageType != DamageType.EM)) Log.WriteLine("Missing EM damage type!");
                    if (DirectModule.DefinedAmmoTypes.All(a => a.DamageType != DamageType.Thermal)) Log.WriteLine("Missing Thermal damage type!");
                    if (DirectModule.DefinedAmmoTypes.All(a => a.DamageType != DamageType.Kinetic)) Log.WriteLine("Missing Kinetic damage type!");
                    if (DirectModule.DefinedAmmoTypes.All(a => a.DamageType != DamageType.Explosive))
                        Log.WriteLine("Missing Explosive damage type!");

                    Log.WriteLine("You are required to specify all 4 damage types in your settings xml file!");
                }
            }
            else
            {
                DirectModule.DefinedAmmoTypes = new List<AmmoType>();
                Log.WriteLine("Missing AmmoTypes section: You are required to specify all 4 damage types in your settings xml file!");
            }
        }

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                Log.WriteLine("LoadSettings: Combat");
                DefaultCombatShipName =
                    (string)CharacterSettingsXml.Element("combatShipName") ??
                    (string)CommonSettingsXml.Element("combatShipName") ?? "My frigate of doom";
                Log.WriteLine("LoadSettings: Settings: combatShipName [" + DefaultCombatShipName + "]");
                AnomicShipName =
                    (string)CharacterSettingsXml.Element("anomicShipName") ??
                    (string)CommonSettingsXml.Element("anomicShipName") ?? "";
                Log.WriteLine("LoadSettings: Settings: anomicShipName [" + AnomicShipName + "]");
                DontShootFrigatesWithSiegeorAutoCannons =
                    (bool?)CharacterSettingsXml.Element("DontShootFrigatesWithSiegeorAutoCannons") ??
                    (bool?)CommonSettingsXml.Element("DontShootFrigatesWithSiegeorAutoCannons") ?? false;
                maxHighValueTargets =
                    (int?)CharacterSettingsXml.Element("maximumHighValueTargets") ??
                    (int?)CommonSettingsXml.Element("maximumHighValueTargets") ?? 2;
                Log.WriteLine("LoadSettings: Settings: maximumHighValueTargets [" + maxHighValueTargets + "]");
                maxLowValueTargets =
                    (int?)CharacterSettingsXml.Element("maximumLowValueTargets") ??
                    (int?)CommonSettingsXml.Element("maximumLowValueTargets") ?? 2;
                Log.WriteLine("LoadSettings: Settings: maximumLowValueTargets [" + maxLowValueTargets + "]");
                DoNotSwitchTargetsIfTargetHasMoreThanThisArmorDamagePercentage =
                    (int?)CharacterSettingsXml.Element("doNotSwitchTargetsIfTargetHasMoreThanThisArmorDamagePercentage") ??
                    (int?)CommonSettingsXml.Element("doNotSwitchTargetsIfTargetHasMoreThanThisArmorDamagePercentage") ?? 60;
                MinimumTargetValueToConsiderTargetAHighValueTarget =
                    (int?)CharacterSettingsXml.Element("minimumTargetValueToConsiderTargetAHighValueTarget") ??
                    (int?)CommonSettingsXml.Element("minimumTargetValueToConsiderTargetAHighValueTarget") ?? 3;
                MaximumTargetValueToConsiderTargetALowValueTarget =
                    (int?)CharacterSettingsXml.Element("maximumTargetValueToConsiderTargetALowValueTarget") ??
                    (int?)CommonSettingsXml.Element("maximumTargetValueToConsiderTargetALowValueTarget") ?? 2;
                AddDampenersToPrimaryWeaponsPriorityTargetList =
                    (bool?)CharacterSettingsXml.Element("addDampenersToPrimaryWeaponsPriorityTargetList") ??
                    (bool?)CommonSettingsXml.Element("addDampenersToPrimaryWeaponsPriorityTargetList") ?? true;
                AddECMsToPrimaryWeaponsPriorityTargetList =
                    (bool?)CharacterSettingsXml.Element("addECMsToPrimaryWeaponsPriorityTargetList") ??
                    (bool?)CommonSettingsXml.Element("addECMsToPrimaryWeaponsPriorityTargetList") ?? true;
                AddNeutralizersToPrimaryWeaponsPriorityTargetList =
                    (bool?)CharacterSettingsXml.Element("addNeutralizersToPrimaryWeaponsPriorityTargetList") ??
                    (bool?)CommonSettingsXml.Element("addNeutralizersToPrimaryWeaponsPriorityTargetList") ?? true;
                AddTargetPaintersToPrimaryWeaponsPriorityTargetList =
                    (bool?)CharacterSettingsXml.Element("addTargetPaintersToPrimaryWeaponsPriorityTargetList") ??
                    (bool?)CommonSettingsXml.Element("addTargetPaintersToPrimaryWeaponsPriorityTargetList") ?? true;
                AddTrackingDisruptorsToPrimaryWeaponsPriorityTargetList =
                    (bool?)CharacterSettingsXml.Element("addTrackingDisruptorsToPrimaryWeaponsPriorityTargetList") ??
                    (bool?)CommonSettingsXml.Element("addTrackingDisruptorsToPrimaryWeaponsPriorityTargetList") ?? true;
                AddWarpScramblersToPrimaryWeaponsPriorityTargetList =
                    (bool?)CharacterSettingsXml.Element("addWarpScramblersToPrimaryWeaponsPriorityTargetList") ??
                    (bool?)CommonSettingsXml.Element("addWarpScramblersToPrimaryWeaponsPriorityTargetList") ?? true;
                AddWebifiersToPrimaryWeaponsPriorityTargetList =
                    (bool?)CharacterSettingsXml.Element("addWebifiersToPrimaryWeaponsPriorityTargetList") ??
                    (bool?)CommonSettingsXml.Element("addWebifiersToPrimaryWeaponsPriorityTargetList") ?? true;
                ListPriorityTargetsEveryXSeconds =
                    (double?)CharacterSettingsXml.Element("listPriorityTargetsEveryXSeconds") ??
                    (double?)CommonSettingsXml.Element("listPriorityTargetsEveryXSeconds") ?? 300;
                GlobalAllowOverLoadOfWeapons = (bool?)CharacterSettingsXml.Element("overloadWeapons") ??
                                               (bool?)CommonSettingsXml.Element("overloadWeapons") ??
                                               (bool?)CharacterSettingsXml.Element("allowOverloadOfWeapons") ??
                                               (bool?)CommonSettingsXml.Element("allowOverloadOfWeapons") ?? false;
                GlobalAllowOverLoadOfEcm =
                    (bool?)CharacterSettingsXml.Element("allowOverLoadOfEcm") ??
                    (bool?)CommonSettingsXml.Element("allowOverLoadOfEcm") ?? false;
                GlobalAllowOverLoadOfSpeedMod =
                    (bool?)CharacterSettingsXml.Element("allowOverLoadOfSpeedMod") ??
                    (bool?)CommonSettingsXml.Element("allowOverLoadOfSpeedMod") ?? false;
                Log.WriteLine("LoadSettings: Settings: allowOverLoadOfSpeedMod [" + GlobalAllowOverLoadOfSpeedMod + "]");
                GlobalAllowOverLoadOfWebs =
                    (bool?)CharacterSettingsXml.Element("allowOverLoadOfWebs") ??
                    (bool?)CommonSettingsXml.Element("allowOverLoadOfWebs") ?? false;
                Log.WriteLine("LoadSettings: Settings: allowOverLoadOfWebs [" + GlobalAllowOverLoadOfWebs + "]");
                GlobalWeaponOverloadDamageAllowed =
                    (int?)CharacterSettingsXml.Element("weaponOverloadDamageAllowed") ??
                    (int?)CommonSettingsXml.Element("weaponOverloadDamageAllowed") ?? 50;
                Log.WriteLine("LoadSettings: Settings: weaponOverloadDamageAllowed [" + GlobalWeaponOverloadDamageAllowed + "]");
                GlobalEcmOverloadDamageAllowed =
                    (int?)CharacterSettingsXml.Element("ecmOverloadDamageAllowed") ??
                    (int?)CommonSettingsXml.Element("ecmOverloadDamageAllowed") ?? 50;
                GlobalSpeedModOverloadDamageAllowed =
                    (int?)CharacterSettingsXml.Element("speedModOverloadDamageAllowed") ??
                    (int?)CommonSettingsXml.Element("speedModOverloadDamageAllowed") ?? 50;
                Log.WriteLine("LoadSettings: Settings: speedModOverloadDamageAllowed [" + GlobalSpeedModOverloadDamageAllowed + "]");
                GlobalWebOverloadDamageAllowed =
                    (int?)CharacterSettingsXml.Element("webOverloadDamageAllowed") ??
                    (int?)CommonSettingsXml.Element("webOverloadDamageAllowed") ?? 50;
                Log.WriteLine("LoadSettings: Settings: webOverloadDamageAllowed [" + GlobalWebOverloadDamageAllowed + "]");
                NosDistance =
                    (int?)CharacterSettingsXml.Element("NosDistance") ??
                    (int?)CommonSettingsXml.Element("NosDistance") ?? 38000;
                Log.WriteLine("LoadSettings: Settings: NosDistance [" + NosDistance + "]");
                RemoteRepairDistance =
                    (int?)CharacterSettingsXml.Element("remoteRepairDistance") ??
                    (int?)CommonSettingsXml.Element("remoteRepairDistance") ?? 2000;
                MinimumAmmoCharges =
                    (int?)CharacterSettingsXml.Element("minimumAmmoCharges") ??
                    (int?)CommonSettingsXml.Element("minimumAmmoCharges") ?? 2;
                if (MinimumAmmoCharges < 2)
                    MinimumAmmoCharges = 2;
                KillSentries =
                    (bool?)CharacterSettingsXml.Element("killSentries") ??
                    (bool?)CommonSettingsXml.Element("killSentries") ?? false;
                Log.WriteLine("LoadSettings: Settings: killSentries [" + KillSentries + "]");
                ScanningShipName =
                    (string)CharacterSettingsXml.Element("scanningShipName") ??
                    (string)CommonSettingsXml.Element("scanningShipName") ?? "cloaky!";
                FocusFireWhenWeaponsAndDronesAreInRangeOfDifficultTargets =
                    (bool?)CharacterSettingsXml.Element("focusFireWhenWeaponsAndDronesAreInRangeOfDifficultTargets") ??
                    (bool?)CommonSettingsXml.Element("focusFireWhenWeaponsAndDronesAreInRangeOfDifficultTargets") ?? true;
                //
                // DefinedAmmoTypes settings
                //
                LoadAmmoSettings(CharacterSettingsXml, CommonSettingsXml);
            }
            catch (Exception exception)
            {
                Log.WriteLine("Error Loading Weapon and targeting Settings [" + exception + "]");
            }
        }

        public static bool RemovePrimaryWeaponPriorityTargets(List<EntityCache> targets)
        {
            try
            {
                targets = targets.ToList();

                if (targets.Any() && _primaryWeaponPriorityTargets != null && _primaryWeaponPriorityTargets.Any() &&
                    _primaryWeaponPriorityTargets.Any(pt => targets.Any(t => t.Id == pt.EntityID)))
                {
                    _primaryWeaponPriorityTargets.RemoveAll(pt => targets.Any(t => t.Id == pt.EntityID));
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }

            return false;
        }

        public static void RemovePrimaryWeaponPriorityTargetsByName(string stringEntitiesToRemove)
        {
            try
            {
                IEnumerable<EntityCache> entitiesToRemove = ESCache.Instance.EntitiesOnGrid.Where(i => i.Name.ToLower() == stringEntitiesToRemove.ToLower()).ToList();
                if (entitiesToRemove.Any())
                {
                    Log.WriteLine("removing [" + stringEntitiesToRemove + "] from the PWPT List");
                    RemovePrimaryWeaponPriorityTargets(entitiesToRemove.ToList());
                    return;
                }

                Log.WriteLine("[" + stringEntitiesToRemove + "] was not found on grid");
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static bool SetPrimaryWeaponPriorityTarget(EntityCache currentTarget, PrimaryWeaponPriority priorityType, double Distance)

        {
            try
            {
                EntityCache target = null;
                try
                {
                    if (PrimaryWeaponPriorityEntities.Any(pt => pt.PrimaryWeaponPriorityLevel == priorityType))
                        target =
                            PrimaryWeaponPriorityEntities.Where(
                                    pt =>
                                        pt.IsReadyToShoot && currentTarget != null && pt.Id == currentTarget.Id &&
                                        pt.Distance < Distance && !pt.IsTooCloseTooFastTooSmallToHit
                                        ||
                                        pt.IsReadyToShoot && pt.Distance < Distance && pt.PrimaryWeaponPriorityLevel == priorityType &&
                                        !pt.IsTooCloseTooFastTooSmallToHit)
                                .OrderByDescending(pt => pt.IsReadyToShoot)
                                .ThenByDescending(pt => pt.IsCurrentTarget)
                                .ThenByDescending(pt => !pt.IsNPCFrigate)
                                .ThenByDescending(pt => pt.IsInOptimalRange)
                                .ThenBy(pt => pt.ShieldPct + pt.ArmorPct + pt.StructurePct)
                                .ThenBy(pt => pt.Nearest5kDistance)
                                .FirstOrDefault();
                }
                catch (NullReferenceException)
                {
                }

                if (target != null)
                {
                    if (DebugConfig.DebugPreferredPrimaryWeaponTarget) Log.WriteLine("Combat.PreferredPrimaryWeaponTargetID = [ " + target.Name + "][" + target.MaskedId + "]");
                    PreferredPrimaryWeaponTarget = target;
                    Time.Instance.LastPreferredPrimaryWeaponTargetDateTime = DateTime.UtcNow;
                    return true;
                }

                return false;
            }
            catch (NullReferenceException)
            {
            }

            return false;
        }

        private static bool UnlockHighValueTarget(string module, string reason, bool OutOfRangeOnly = false)
        {
            EntityCache unlockThisHighValueTarget = null;
            long preferredId = PreferredPrimaryWeaponTarget != null ? PreferredPrimaryWeaponTarget.Id : -1;

            if (!OutOfRangeOnly)
            {
                if (LowValueTargetsTargeted.Count() > maxLowValueTargets &&
                    maxTotalTargets <= LowValueTargetsTargeted.Count() + HighValueTargetsTargeted.Count())
                    return UnlockLowValueTarget(reason, OutOfRangeOnly);

                try
                {
                    if (HighValueTargetsTargeted.Count(t => t.Id != preferredId) >= maxHighValueTargets)
                        unlockThisHighValueTarget = HighValueTargetsTargeted.Where(h => h.IsTarget && h.IsIgnored
                                                                                        ||
                                                                                        h.IsTarget && !h.isPreferredDroneTarget && !h.IsDronePriorityTarget &&
                                                                                        !h.isPreferredPrimaryWeaponTarget && !h.IsPrimaryWeaponPriorityTarget &&
                                                                                        !h.IsWarpScramblingMe && !h.IsInOptimalRange &&
                                                                                        PotentialCombatTargets.Count() >= 3
                                                                                        ||
                                                                                        h.IsTarget && !h.isPreferredPrimaryWeaponTarget &&
                                                                                        !h.IsDronePriorityTarget && h.IsHigherPriorityPresent &&
                                                                                        !h.IsPrimaryWeaponPriorityTarget &&
                                                                                        HighValueTargetsTargeted.Count() == maxHighValueTargets &&
                                                                                        !h.IsWarpScramblingMe
                                                                                        ||
                                                                                        h.IsTarget && !h.isPreferredPrimaryWeaponTarget &&
                                                                                        !h.IsDronePriorityTarget && !h.IsInOptimalRange &&
                                                                                        !h.IsPrimaryWeaponPriorityTarget &&
                                                                                        HighValueTargetsTargeted.Count() == maxHighValueTargets &&
                                                                                        !h.IsWarpScramblingMe &&
                                                                                        h.IsAnyOtherUnTargetedHighValueTargetInOptimal
                                                                                        ||
                                                                                        h.IsTarget && h.Distance > MaxRange)
                            .OrderByDescending(t => t.Distance > MaxRange)
                            .ThenByDescending(t => t.Nearest5kDistance)
                            .FirstOrDefault();
                }
                catch (NullReferenceException)
                {
                }
            }
            else
            {
                try
                {
                    unlockThisHighValueTarget = HighValueTargetsTargeted.Where(t => t.Distance > MaxRange)
                        .Where(h => h.IsTarget && h.IsIgnored && !h.IsWarpScramblingMe || h.IsTarget && !h.isPreferredDroneTarget &&
                                    !h.IsDronePriorityTarget && !h.isPreferredPrimaryWeaponTarget && !h.IsPrimaryWeaponPriorityTarget &&
                                    !h.IsWarpScramblingMe
                                    ||
                                    h.IsTarget && !h.isPreferredPrimaryWeaponTarget &&
                                    !h.IsDronePriorityTarget && !h.IsInOptimalRange &&
                                    !h.IsPrimaryWeaponPriorityTarget &&
                                    HighValueTargetsTargeted.Count() == maxHighValueTargets &&
                                    !h.IsWarpScramblingMe &&
                                    h.IsAnyOtherUnTargetedHighValueTargetInOptimal
                        )
                        .OrderByDescending(t => t.Nearest5kDistance)
                        .FirstOrDefault();
                }
                catch (NullReferenceException)
                {
                }
            }

            if (unlockThisHighValueTarget != null)
            {
                Log.WriteLine("Unlocking HighValue " + unlockThisHighValueTarget.Name + "[" + Math.Round(unlockThisHighValueTarget.Distance / 1000, 0) +
                              "k] myTargtingRange:[" + MaxTargetRange + "] myWeaponRange[:" + ESCache.Instance.WeaponRange + "] to make room for [" +
                              reason + "]");
                if (unlockThisHighValueTarget.UnlockTarget()) return false;
                return true;
            }

            return true;
        }

        public static bool FocusFireWhenWeaponsAndDronesAreInRangeOfDifficultTargets = true;

        private static bool UnlockLowValueTarget(string reason, bool OutOfWeaponsRange = false)
        {
            EntityCache unlockThisLowValueTarget = null;
            if (!OutOfWeaponsRange)
                try
                {
                    unlockThisLowValueTarget = LowValueTargetsTargeted.Where(h => h.IsTarget && h.IsIgnored
                                                                                  ||
                                                                                  h.IsTarget && !h.isPreferredDroneTarget && !h.IsDronePriorityTarget &&
                                                                                  !h.isPreferredPrimaryWeaponTarget && !h.IsPrimaryWeaponPriorityTarget &&
                                                                                  !h.IsWarpScramblingMe && !h.IsInOptimalRange &&
                                                                                  PotentialCombatTargets.Count() >= 3
                                                                                  ||
                                                                                  h.IsTarget && !h.isPreferredDroneTarget && !h.IsDronePriorityTarget &&
                                                                                  !h.isPreferredPrimaryWeaponTarget && !h.IsPrimaryWeaponPriorityTarget &&
                                                                                  !h.IsWarpScramblingMe && LowValueTargetsTargeted.Count() ==
                                                                                  maxLowValueTargets
                                                                                  ||
                                                                                  h.IsTarget && !h.isPreferredDroneTarget && !h.IsDronePriorityTarget &&
                                                                                  !h.isPreferredPrimaryWeaponTarget && !h.IsPrimaryWeaponPriorityTarget &&
                                                                                  h.IsHigherPriorityPresent && !h.IsWarpScramblingMe &&
                                                                                  LowValueTargetsTargeted.Count() == maxLowValueTargets
                                                                                  ||
                                                                                  h.IsTarget && h.Distance > MaxRange)
                        .OrderByDescending(t => t.Distance < (Drones.UseDrones ? Drones.MaxDroneRange : MaxRange))
                        .ThenByDescending(t => t.Nearest5kDistance)
                        .FirstOrDefault();
                }
                catch (NullReferenceException)
                {
                }
            else
                try
                {
                    unlockThisLowValueTarget = LowValueTargetsTargeted.Where(t => t.Distance > MaxTargetRange)
                        .Where(h => h.IsTarget)
                        .OrderByDescending(t => t.Nearest5kDistance)
                        .FirstOrDefault();
                }
                catch (NullReferenceException)
                {
                }

            if (unlockThisLowValueTarget != null)
            {
                Log.WriteLine("Unlocking LowValue " + unlockThisLowValueTarget.Name + "[" + Math.Round(unlockThisLowValueTarget.Distance / 1000, 0) +
                              "k] myTargtingRange:[" +
                              MaxTargetRange + "] myWeaponRange[:" + ESCache.Instance.WeaponRange + "] to make room for [" + reason + "]");
                if (unlockThisLowValueTarget.UnlockTarget()) return false;
                return true;
            }

            return true;
        }

        #endregion Methods
    }
}