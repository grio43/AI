﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Lookup;
using SC::SharedComponents.IPC;
using SC::SharedComponents.Py;
using SC::SharedComponents.Utility;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public enum BookmarkType
    {
        Station,
        Citadel,
        Solar_System,
        Coordinate
    }

    public class DirectBookmark : DirectInvType
    {
        #region Fields

        /// <summary>
        ///     Entity cache
        /// </summary>
        private DirectEntity _entity;

        #endregion Fields

        #region Constructors

        internal DirectBookmark(DirectEve directEve, PyObject pyBookmark)
            : base(directEve)
        {
            PyBookmark = pyBookmark;
            BookmarkId = (long?)pyBookmark.Attribute("bookmarkID");
            CreatedOn = (DateTime?)pyBookmark.Attribute("created");
            ItemId = (long?)pyBookmark.Attribute("itemID");
            LocationId = (long?)pyBookmark.Attribute("locationID");

            FolderId = (long?)pyBookmark.Attribute("folderID");
            Title = (string)pyBookmark.Attribute("memo");
            if (!string.IsNullOrEmpty(Title) && Title.Contains("\t"))
            {
                Memo = Title.Substring(Title.IndexOf("\t") + 1);
                Title = Title.Substring(0, Title.IndexOf("\t"));
            }
            Note = (string)pyBookmark.Attribute("note");
            OwnerId = (int?)pyBookmark.Attribute("ownerID");
            TypeId = (int)pyBookmark.Attribute("typeID");
            X = (double?)pyBookmark.Attribute("x");
            Y = (double?)pyBookmark.Attribute("y");
            Z = (double?)pyBookmark.Attribute("z");

            if (Enum.TryParse<BookmarkType>(GroupName.Replace(" ", "_"), out var result))
            {
                BookmarkType = result;
                if (BookmarkType != BookmarkType.Citadel && BookmarkType != BookmarkType.Station && X.HasValue && Y.HasValue && Z.HasValue)
                    BookmarkType = BookmarkType.Coordinate;
            }
        }

        #endregion Constructors

        #region Properties

        public long? BookmarkId { get; internal set; }
        public BookmarkType BookmarkType { get; }

        public Vector3 Coordinates
        {
            get
            {
                if (X == null || Y == null || Z == null) return new Vector3(0, 0, 0);
                return new Vector3((double)X, (double)Y, (double)Z);
            }
        }

        public DateTime? CreatedOn { get; internal set; }

        public double? Distance
        {
            get
            {
                try
                {
                    if (DirectEve.Session.IsInSpace)
                    {
                        double? deltaX = X - DirectEve.ActiveShip.Entity.X;
                        double? deltaY = Y - DirectEve.ActiveShip.Entity.Y;
                        double? deltaZ = Z - DirectEve.ActiveShip.Entity.Z;
                        if (deltaX != null && deltaY != null && deltaZ != null)
                            return Math.Sqrt((double)deltaX * (double)deltaX + (double)deltaY * (double)deltaY + (double)deltaZ * (double)deltaZ);

                        return null;
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        /// <summary>
        ///     The entity associated with this bookmark
        /// </summary>
        /// <remarks>
        ///     This property will be null if no entity can be found
        /// </remarks>
        public DirectEntity Entity => _entity ?? (_entity = DirectEve.GetEntityById(ItemId ?? -1));

        public long? FolderId { get; internal set; }
        public bool IsInCurrentSystem
        {
            get
            {
                //
                // this is necessary to avoid a crash, we dont use this feature (yet) in wspace anyway; if we need it we will nee to solve the other bug that was causing eve to freeze
                //
                if (DirectEve.Session.IsWspace)
                    return false;

                if (SolarSystem == null)
                    return false;

                return SolarSystem.Id == DirectEve.Session.SolarSystem.Id || ItemId == DirectEve.Session.LocationId;
            }
        }

        /// <summary>
        ///     If this is a bookmark of a station, this is the StationId
        /// </summary>
        public long? ItemId { get; internal set; }

        /// <summary>
        ///     Matches SolarSystemId
        /// </summary>
        public long? LocationId { get; internal set; }

        public string Memo { get; internal set; }

        public string Note { get; internal set; }

        public int? OwnerId { get; internal set; }

        public DirectSolarSystem SolarSystem
        {
            get
            {
                try
                {
                    if (SolarSystemId != null)
                    {
                        if (DirectEve.Session.IsWspace)
                            return null;

                        DirectSolarSystem tempSolarsystem = DirectEve.SolarSystems[(int)SolarSystemId];
                        if (tempSolarsystem != null)
                            return tempSolarsystem;
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public long? StationId
        {
            get
            {
                if (LocationId > 60000000 && LocationId < 64000000)
                    return LocationId;

                return null;
            }
        }

        public string Title { get; internal set; }

        public double? X { get; internal set; }

        public double? Y { get; internal set; }

        public double? Z { get; internal set; }

        internal PyObject PyBookmark { get; set; }

        private long? SolarSystemId
        {
            get
            {
                try
                {
                    //if (DirectEve.Session.IsWspace)
                    //    return null;

                    if (LocationId > 30000000 && LocationId < 33000000)
                        return LocationId;

                    //DirectEve.Log("Bookmark named [" + Title + "] returned locationID [" + LocationId + "]");
                    return null;
                }
                catch (Exception ex)
                {
                    DirectEve.Log("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        #endregion Properties

        #region Methods

        public DateTime NextApproachAction { get; set; }

        public DateTime NextWarpAction { get; set; }

        public bool Approach()
        {
            if (DateTime.UtcNow > NextApproachAction)
            {
                NextApproachAction = DateTime.UtcNow.AddSeconds(15);
                PyObject approachLocation = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions").Attribute("ApproachLocation");
                return DirectEve.ThreadedCall(approachLocation, PyBookmark);
            }

            return false;
        }

        public bool CopyBookmarksToCorpFolder()
        {
            if (!BookmarkId.HasValue || DirectEve.Session.CorporationId == null)
                return false;

            return DirectEve.ThreadedLocalSvcCall("bookmarkSvc", "MoveBookmarksToFolder", DirectEve.Session.CorporationId, DirectEve.Session.CorporationId,
                PyBookmark.Attribute("bookmarkID"));
        }

        public bool Delete()
        {
            if (!BookmarkId.HasValue)
                return false;

            return DirectEve.ThreadedLocalSvcCall("addressbook", "DeleteBookmarks", new List<PyObject> { PyBookmark.Attribute("bookmarkID") });
        }

        public double? DistanceFromEntity(DirectEntity otherEntityToMeasureFrom)
        {
            try
            {
                if (otherEntityToMeasureFrom == null)
                    return null;

                if (X == null || Y == null || Z == null)
                    return null;

                if (X == 0 || Y == 0 || Z == 0)
                    return null;

                if (otherEntityToMeasureFrom.X == 0 || otherEntityToMeasureFrom.Y == 0 || otherEntityToMeasureFrom.Z == 0)
                    return null;

                double deltaX = (double)X - otherEntityToMeasureFrom.X;
                double deltaY = (double)Y - otherEntityToMeasureFrom.Y;
                double deltaZ = (double)Z - otherEntityToMeasureFrom.Z;

                return Math.Sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
            }
            catch (Exception ex)
            {
                DirectEve.Log("Exception [" + ex + "]");
                return 0;
            }
        }

        public double DistanceTo(DirectStation station)
        {
            if (BookmarkType != BookmarkType.Coordinate)
                return double.MaxValue;

            return Math.Round(Math.Sqrt((station.X - X.Value) * (station.X - X.Value) + (station.Y - Y.Value) * (station.Y - Y.Value) + (station.Z - Z.Value) * (station.Z - Z.Value)), 2);
        }

        public double DistanceTo(DirectEntity entity)
        {
            if (BookmarkType != BookmarkType.Coordinate)
                return double.MaxValue;

            return Math.Round(Math.Sqrt((entity.X - X.Value) * (entity.X - X.Value) + (entity.Y - Y.Value) * (entity.Y - Y.Value) + (entity.Z - Z.Value) * (entity.Z - Z.Value)), 2);
        }

        public bool UpdateBookmark(string name, string comment)
        {
            if (!BookmarkId.HasValue)
                return false;

            return DirectEve.ThreadedLocalSvcCall("bookmarkSvc", "UpdateBookmark", PyBookmark.Attribute("bookmarkID"), PyBookmark.Attribute("ownerID"), name,
                comment, PyBookmark.Attribute("folderID"));
        }

        public bool WarpTo()
        {
            try
            {
                //if (DateTime.UtcNow < LastInWarp.AddSeconds(2))
                //    return false;

                if (DateTime.UtcNow > NextWarpAction)
                {
                    if (DirectEve.Session.IsInSpace && Distance != null)
                    {
                        if (DirectEve.Session.SolarSystem.Id != SolarSystem.Id)
                        {
                            DirectEve.Log("You can only warp to bookmarks that are in system with you! [" + Title + "] is in [" + SolarSystem.Name + "] and you are in [" + DirectEve.Session.SolarSystem.Name + "]");
                            return false;
                        }

                        if (Distance != null && Distance < (long)Distances.HalfOfALightYearInAu)
                        {
                            if (Distance != null && Distance > (int)Distances.WarptoDistance)
                            {
                                if (WarpTo(0))
                                {
                                    NextWarpAction = DateTime.UtcNow.AddSeconds(4);
                                    if (DirectEve.Session.SolarSystemId != null)
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, "SolarSystem", DirectEve.GetLocationName((long)DirectEve.Session.SolarSystemId));

                                    if (DirectEve.ActiveShip != null)
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(DirectEve.Session.Character.Name, "ShipType", DirectEve.ActiveShip.TypeName);

                                    return true;
                                }

                                return false;
                            }

                            DirectEve.Log("[" + Title + "] Distance [" + Math.Round((double)Distance / 1000, 0) +
                                          "k] is not greater then 150k away, WarpTo aborted!!");
                            return false;
                        }

                        DirectEve.Log("[" + Title + "] Distance [" + Math.Round((double)Distance / 1000, 0) +
                                      "k] was greater than 5000AU away, we assume this an error!, WarpTo aborted!");
                        return false;
                    }

                    DirectEve.Log("We have not yet been in space at least 2 seconds, waiting");
                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                DirectEve.Log("Exception [" + exception + "]");
                return false;
            }
        }

        public bool WarpTo(double distance)
        {
            if (DirectEve.Interval(4000, 5000))
            {
                PyObject warpToBookmark = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.movementFunctions").Attribute("WarpToBookmark");
                return DirectEve.ThreadedCall(warpToBookmark, PyBookmark, distance);
            }
            return false;
        }

        internal static bool BookmarkLocation(DirectEve directEve, long ownerId, long itemId, string name, string comment, int typeId, long? locationId,
            long? folderId)
        {
            PyObject bookmarkLocation = directEve.GetLocalSvc("bookmarkSvc").Attribute("BookmarkLocation");
            Dictionary<string, object> keywords = new Dictionary<string, object>();
            if (locationId.HasValue)
                keywords.Add("locationID", locationId.Value);
            if (folderId.HasValue)
                keywords.Add("folderID", folderId.Value);
            return directEve.ThreadedCallWithKeywords(bookmarkLocation, keywords, itemId, ownerId, name, comment, typeId);
        }

        internal static bool CreateBookmarkFolder(DirectEve directEve, long ownerId, string name)
        {
            return directEve.ThreadedLocalSvcCall("bookmarkSvc", "CreateFolder", ownerId, name);
        }

        internal static List<DirectBookmark> GetBookmarks(DirectEve directEve)
        {
            // List the bookmarks from cache
            Dictionary<long, PyObject> bookmarks = directEve.GetLocalSvc("bookmarkSvc").Attribute("bookmarkCache").ToDictionary<long>();
            return bookmarks.Values.Select(pyBookmark => new DirectBookmark(directEve, pyBookmark)).ToList();
        }

        internal static List<DirectBookmarkFolder> GetFolders(DirectEve directEve)
        {
            // List the bookmark folders from cache
            Dictionary<long, PyObject> folders = directEve.GetLocalSvc("bookmarkSvc").Attribute("folders").ToDictionary<long>();
            return folders.Values.Select(pyFolder => new DirectBookmarkFolder(directEve, pyFolder)).ToList();
        }

        internal static DateTime? GetLastBookmarksUpdate(DirectEve directEve)
        {
            // Get the bookmark-last-update-time
            return (DateTime?)directEve.GetLocalSvc("bookmarkSvc").Attribute("lastUpdateTime");
        }

        internal static bool RefreshBookmarks(DirectEve directEve)
        {
            // If the bookmarks need to be refreshed, then this will do it
            return directEve.ThreadedLocalSvcCall("bookmarkSvc", "GetBookmarks");
        }

        internal static bool RefreshPnPWindow(DirectEve directEve)
        {
            return directEve.ThreadedLocalSvcCall("bookmarkSvc", "RefreshWindow");
            ;
        }

        #endregion Methods
    }
}