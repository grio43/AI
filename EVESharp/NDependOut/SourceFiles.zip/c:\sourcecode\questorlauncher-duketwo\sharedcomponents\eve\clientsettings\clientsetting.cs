﻿using SharedComponents.EVE.ClientSettings.Global.Main;
using SharedComponents.EVE.ClientSettings.Pinata.Main;
using SharedComponents.EVE.ClientSettings.SharedComponents.EVE.ClientSettings;
using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SharedComponents.EVE.ClientSettings
{
    [Serializable]
    public class ClientSetting
    {
        #region Methods

        public ClientSetting Clone()
        {
            using (MemoryStream stream = new MemoryStream())
            {
                if (GetType().IsSerializable)
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(stream, this);
                    stream.Position = 0;
                    return (ClientSetting) formatter.Deserialize(stream);
                }
                return null;
            }
        }

        #endregion Methods

        //NOTE: Default values work only for non list types due a weird behaviour of the serialization

        #region Properties

        [TabRoot("Global")]
        public GlobalMainSetting GlobalMainSetting { get; set; } = new GlobalMainSetting();

        [TabRoot("Pinata")]
        public PinataMainSetting PinataMainSetting { get; set; } = new PinataMainSetting();

        public QuestorMainSetting QMS => QuestorMainSetting;

        [TabRoot("Questor")]
        public QuestorMainSetting QuestorMainSetting { get; set; } = new QuestorMainSetting();

        #endregion Properties
    }
}