﻿/*
 * User: duketwo
 * Date: 03.10.2018
 * Time: 19:52
 */

extern alias SC;

using EVESharpCore.Cache;
using EVESharpCore.Controllers.Base;
using EVESharpCore.Framework;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.IPC;
using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Questor.Activities;

namespace EVESharpCore.Controllers
{
    public enum DumpLootControllerState
    {
        TravelToHomeStation,
        CreateJitaUndockSpot,
        ActivateCloakyHauler,
        MoveLootToShip,
        TravelToJita,
        MoveLootToItemHangar,
        DumpLoot,
        Error,
        Done
    }

    /// <summary>
    ///     Description of DumpLootController.
    /// </summary>
    public class DumpLootController : BaseController
    {
        #region Fields

        private const int MAX_DUMP_LOOT_ITERATIONS = 10;
        private const int MIN_LOOT_TO_DUMP = 30000;
        private static bool _disabledForThisSession;
        private readonly Action _doneAction;
        private bool _createUndockBookmark;
        private DumpLootControllerState _state;
        private TravelerDestination _travelerDestination;

        #endregion Fields

        #region Constructors

        public DumpLootController()
        {
            IgnorePause = false;
            IgnoreModal = false;
        }

        public DumpLootController(Action doneAction)
        {
            IgnorePause = false;
            IgnoreModal = false;
            _doneAction = doneAction;
        }

        #endregion Constructors

        #region Methods

        public static bool ShouldDumpLoot
        {
            get
            {
                if (_disabledForThisSession)
                    return false;
                List<DirectItem> loot2Dump = UnloadLoot.LootItemsInLootHangar();
                double totalLoot2DumpVolume = loot2Dump.Sum(i => i.Quantity * i.Volume);
                return totalLoot2DumpVolume > MIN_LOOT_TO_DUMP && DumpLootIterations < MAX_DUMP_LOOT_ITERATIONS;
            }
        }

        private static int DumpLootIterations => WCFClient.Instance.GetPipeProxy.GetDumpLootIterations(ESCache.Instance.EveAccount.CharacterName);

        private bool AnyJitaUndockBookmark
        {
            get
            {
                DirectStation jita = ESCache.Instance.DirectEve.Stations[60003760];
                return ESCache.Instance.DirectEve.Bookmarks.Any(b => b.DistanceTo(jita) < 20000);
            }
        }

        private bool DockedInJita => ESCache.Instance.InStation && ESCache.Instance.DirectEve.Session.StationId == 60003760;

        public override void DoWork()
        {
            try
            {
                if (ESCache.Instance.InSpace &&
                    ESCache.Instance.ActiveShip.GroupId == (int)Group.Capsule)
                {
                    Log($"We are in a capsule. Error.");
                    _state = DumpLootControllerState.Error;
                }

                switch (_state)
                {
                    case DumpLootControllerState.TravelToHomeStation:

                        //if (ESCache.Instance.Agent.Name.ToLower() != ESCache.Instance.EveAccount.CS.QMS.AgentName.ToLower())
                        //{
                        //    Log($"The agent does not match the one defined within the settings. Reset the agent.");
                        //    ESCache.Instance.Agent = null;
                        //}

                        long homeStationId = MissionSettings.AgentToPullNextRegularMissionFrom.StationId;
                        if (ESCache.Instance.DirectEve.Session.StationId == homeStationId)
                        {
                            Log($"We are in the right station. Changing to next state ({nameof(DumpLootControllerState.ActivateCloakyHauler)}).");
                            _state = DumpLootControllerState.ActivateCloakyHauler;
                        }
                        else
                        {
                            if (DirectEve.Interval(2000, 2500))
                                Log($"TravelHome pulse.");
                            Traveler.TravelHome(MissionSettings.AgentToPullNextRegularMissionFrom);
                        }

                        break;

                    case DumpLootControllerState.CreateJitaUndockSpot:

                        if (AnyJitaUndockBookmark)
                        {
                            Log($"Jita undock bookmark exists, starting again.");
                            _state = DumpLootControllerState.TravelToHomeStation;
                        }
                        else
                        {
                            if (DockedInJita)
                            {
                                ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdExitStation);
                                LocalPulse = GetUTCNowDelayMilliseconds(3000, 4000);
                            }
                            else if (ESCache.Instance.InSpace
                                     && ESCache.Instance.Stations.Any(e => e.Id == 60003760 && e.Distance < 20000))
                            {
                                ESCache.Instance.DirectEve.BookmarkCurrentLocation(new Random().Next(10, 99).ToString(), "", null);
                                Log($"Adding Jita undock boomkark.");
                                LocalPulse = GetUTCNowDelayMilliseconds(3000, 4000);
                            }
                            else
                            {
                                _createUndockBookmark = true;
                                Log($"Travelling to Jita to create the undock bookmark.");
                                Log($"Changing state ({nameof(DumpLootControllerState.TravelToJita)}).");
                                _travelerDestination = new DockableLocationDestination(60003760);
                                _state = DumpLootControllerState.TravelToJita;
                            }
                        }

                        break;

                    case DumpLootControllerState.ActivateCloakyHauler:

                        if (!ESCache.Instance.InStation)
                            return;

                        if (ESCache.Instance.DirectEve.GetShipHangar() == null)
                        {
                            Log("Shiphangar is null.");
                            return;
                        }

                        if (ESCache.Instance.DirectEve.GetItemHangar() == null)
                        {
                            Log("ItemHangar is null.");
                            return;
                        }

                        if (!ShouldDumpLoot)
                        {
                            Log($"ShouldDumpLoot == false, changing state to done.");
                            _state = DumpLootControllerState.Done;
                            return;
                        }

                        List<DirectItem> ships = ESCache.Instance.DirectEve.GetShipHangar().Items.Where(i => i.IsSingleton
                                                                                                             && i.GroupId == (int)Group.BlockadeRunner
                                                                                                             && i.GivenName != null).ToList();

                        if (ESCache.Instance.ActiveShip == null)
                        {
                            Log("Active ship is null.");
                            return;
                        }

                        if (ESCache.Instance.ActiveShip.GroupId == (int)Group.BlockadeRunner)
                        {
                            _state = DumpLootControllerState.MoveLootToShip;
                            Log("Already in a transport ship.");
                            return;
                        }

                        if (ships.Any())
                        {
                            ships.FirstOrDefault().ActivateShip();
                            Log("Found a transport ship. Making it active.");
                            LocalPulse = DateTime.UtcNow.AddSeconds(Time.Instance.SwitchShipsDelay_seconds);
                            _state = DumpLootControllerState.MoveLootToShip;
                        }
                        else
                        {
                            Log("No transport ship found. Error.");
                            _state = DumpLootControllerState.Error;
                        }

                        break;

                    case DumpLootControllerState.MoveLootToShip:

                        if (ESCache.Instance.DirectEve.GetItemHangar() == null)
                        {
                            Log("ItemHangar is null.");
                            return;
                        }

                        if (ESCache.Instance.CurrentShipsCargo == null || ESCache.Instance.CurrentShipsCargo.Capacity == 0)
                            return;

                        if (!AnyJitaUndockBookmark)
                        {
                            Log($"No Jita undock bookmark found. Creating the bookmark.");
                            _state = DumpLootControllerState.CreateJitaUndockSpot;
                            return;
                        }

                        double freeCargo = ESCache.Instance.CurrentShipsCargo.Capacity - ESCache.Instance.CurrentShipsCargo.UsedCapacity;
                        Log("Current [" + ESCache.Instance.ActiveShip.GivenName + "] Cargo [" + ESCache.Instance.CurrentShipsCargo.Capacity +
                            "] Used Capacity [" +
                            ESCache.Instance.CurrentShipsCargo.UsedCapacity + "] Free Capacity [" + freeCargo + "]");

                        IOrderedEnumerable<DirectItem> loot2Dump = UnloadLoot.LootItemsInLootHangar().OrderByDescending(i => i.IskPerM3);
                        double cargoPerc = ESCache.Instance.CurrentShipsCargo.UsedCapacity / (ESCache.Instance.CurrentShipsCargo.Capacity / 100);

                        Log($"CargoPerc {cargoPerc}%");

                        if (!loot2Dump.Any() || cargoPerc >= 95)
                        {
                            if (ESCache.Instance.CurrentShipsCargo.Items.Any())
                            {
                                Log($"Changing state ({nameof(DumpLootControllerState.TravelToJita)}).");
                                _travelerDestination = new DockableLocationDestination(60003760);
                                _state = DumpLootControllerState.TravelToJita;
                            }
                            else
                            {
                                Log($"Changing state (Done).");
                                _state = DumpLootControllerState.Done;
                            }
                            return;
                        }

                        List<DirectItem> itemsToMove = new List<DirectItem>();

                        foreach (DirectItem item in loot2Dump)
                        {
                            double totalVolume = item.Quantity * item.Volume;
                            if (totalVolume > freeCargo)
                            {
                                if (itemsToMove.Any()) // items to move first
                                    break;
                                // try to move it partially or skip if the volume of one is more than left free cargo
                                if (item.Volume > freeCargo)
                                {
                                    Log($"Item {item.TypeName} Volume {item.Volume} exceeds remaining freecargo {freeCargo}.");
                                }
                                else
                                {
                                    int quantityToMove = Convert.ToInt32(Math.Floor(freeCargo / item.Volume));
                                    if (!ESCache.Instance.CurrentShipsCargo.Add(item, quantityToMove)) return;
                                    Log($"Adding {item.TypeName} partially. Total quantity {item.Quantity} Moving quantity {quantityToMove}");
                                    LocalPulse = GetUTCNowDelayMilliseconds(3000, 3500);
                                    return;
                                }
                            }
                            else
                            {
                                // add item to the list
                                itemsToMove.Add(item);
                                freeCargo -= totalVolume;
                                Log($"Added {item.TypeName} TotalVol {totalVolume} Freecargo {freeCargo}");
                            }
                            //Log($"TypeName {item.TypeName} Quantity {item.Quantity} ISKPerM3 {item.IskPerM3} Stacksize {item.Stacksize} Vol {item.Volume} TotalVol {item.Volume * item.Stacksize}");
                        }

                        if (itemsToMove.Any())
                        {
                            // move items
                            Log($"Moving items.");
                            if (!ESCache.Instance.CurrentShipsCargo.Add(itemsToMove)) return;
                            LocalPulse = GetUTCNowDelayMilliseconds(3000, 3500);
                        }

                        break;

                    case DumpLootControllerState.TravelToJita:

                        if (ESCache.Instance.DirectEve.Session.IsInSpace && ESCache.Instance.ActiveShip.Entity != null &&
                            ESCache.Instance.ActiveShip.Entity.IsWarping)
                            return;

                        if (Traveler.Destination != _travelerDestination)
                            Traveler.Destination = _travelerDestination;

                        Traveler.ProcessState();

                        if (State.CurrentTravelerState == TravelerState.AtDestination)
                        {
                            if (_createUndockBookmark)
                            {
                                Log($"Arrived at Jita 4/4. Changing to next state {nameof(DumpLootControllerState.CreateJitaUndockSpot)}.");
                                _state = DumpLootControllerState.CreateJitaUndockSpot;
                                _createUndockBookmark = false;
                            }
                            else
                            {
                                Log($"Arrived at Jita 4/4. Changing to next state {nameof(DumpLootControllerState.MoveLootToItemHangar)}.");
                                _state = DumpLootControllerState.MoveLootToItemHangar;
                            }
                            Traveler.Destination = null;
                            return;
                        }

                        if (State.CurrentTravelerState == TravelerState.Error)
                        {
                            if (Traveler.Destination != null)
                                Log("Stopped traveling, traveller threw an error.");

                            Traveler.Destination = null;
                            _state = DumpLootControllerState.Error;
                        }

                        break;

                    case DumpLootControllerState.MoveLootToItemHangar:

                        if (ESCache.Instance.CurrentShipsCargo == null || ESCache.Instance.CurrentShipsCargo.Capacity == 0)
                            return;

                        if (ESCache.Instance.DirectEve.GetItemHangar() == null)
                        {
                            Log("ItemHangar is null.");
                            return;
                        }

                        if (ESCache.Instance.CurrentShipsCargo.Items.Any())
                        {
                            Log($"Moving items.");
                            if (!ESCache.Instance.DirectEve.GetItemHangar().Add(ESCache.Instance.CurrentShipsCargo.Items)) return;
                            LocalPulse = GetUTCNowDelayMilliseconds(3000, 3500);
                        }
                        else
                        {
                            Log($"Changing state to {nameof(DumpLootControllerState.DumpLoot)}.");
                            _state = DumpLootControllerState.DumpLoot;
                        }

                        break;

                    case DumpLootControllerState.DumpLoot:
                        if (ESCache.Instance.DirectEve.GetItemHangar() == null)
                        {
                            Log("ItemHangar is null.");
                            return;
                        }

                        List<DirectItem> loot2dump = UnloadLoot.LootItemsInLootHangar().Where(i => !i.IsSingleton).ToList();

                        if (loot2dump.Any())
                        {
                            if (!ESCache.Instance.DirectEve.Windows.OfType<DirectMultiSellWindow>().Any())
                            {
                                Log($"Opening MultiSellWindow with {loot2dump.Count} items.");
                                ESCache.Instance.DirectEve.MultiSell(loot2dump);
                            }
                            else
                            {
                                DirectMultiSellWindow sellWnd = ESCache.Instance.DirectEve.Windows.OfType<DirectMultiSellWindow>().FirstOrDefault();
                                if (sellWnd.AddingItemsThreadRunning)
                                {
                                    Log($"Waiting for items to be added.");
                                    LocalPulse = GetUTCNowDelayMilliseconds(1500, 2000);
                                }
                                else
                                {
                                    if (sellWnd.GetSellItems().All(i => !i.HasBid))
                                    {
                                        Log($"Only items without a bid are left. Done. " +
                                            $"Changing to next state ({nameof(DumpLootControllerState.TravelToHomeStation)}).");
                                        sellWnd.Cancel();
                                        LocalPulse = GetUTCNowDelayMilliseconds(1500, 2000);
                                        _state = DumpLootControllerState.TravelToHomeStation;
                                        IncreaseDumpLootIterations();
                                    }
                                    else
                                    {
                                        if (sellWnd.GetDurationComboValue() != DurationComboValue.IMMEDIATE)
                                        {
                                            Log($"Setting duration combo value to {DurationComboValue.IMMEDIATE}.");
                                            sellWnd.SetDurationCombovalue(DurationComboValue.IMMEDIATE);
                                            LocalPulse = GetUTCNowDelayMilliseconds(3000, 4000);
                                            return;
                                        }

                                        Log($"Items added. Performing trade.");
                                        sellWnd.PerformTrade();
                                        LocalPulse = GetUTCNowDelayMilliseconds(3000, 4000);
                                    }
                                }
                            }
                        }
                        else
                        {
                            Log($"Sold all items. Changing to next state ({nameof(DumpLootControllerState.TravelToHomeStation)}).");
                            _state = DumpLootControllerState.TravelToHomeStation;
                            IncreaseDumpLootIterations();
                        }

                        break;

                    case DumpLootControllerState.Error:
                        _disabledForThisSession = true;
                        _state = DumpLootControllerState.Done;
                        break;

                    case DumpLootControllerState.Done:
                        ControllerManager.Instance.RemoveController(typeof(DumpLootController));
                        _doneAction?.Invoke();
                        break;
                }
            }
            catch (Exception ex)
            {
                Log("Exception [" + ex + "]");
            }
        }

        public override bool EvaluateDependencies(ControllerManager cm)
        {
            return true;
        }

        private static void IncreaseDumpLootIterations()
        {
            WCFClient.Instance.GetPipeProxy.IncreaseDumpLootIterations(ESCache.Instance.EveAccount.CharacterName);
        }

        #endregion Methods
    }
}