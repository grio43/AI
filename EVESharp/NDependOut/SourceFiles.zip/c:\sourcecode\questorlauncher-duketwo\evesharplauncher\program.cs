﻿/*
 * Created by SharpDevelop.
 * User: dserver
 * Date: 02.12.2013
 * Time: 09:09
 *
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */

using SharedComponents.EVE;
using SharedComponents.Utility;
using System;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace EVESharpLauncher
{
    /// <summary>
    ///     Class with program entry point.
    /// </summary>
    internal sealed class Program
    {
        #region Constructors

        /// <summary>
        ///     Program entry point.
        /// </summary>
        static Program()
        {
            Debug.WriteLine("Init");
        }

        #endregion Constructors

        #region Methods

        private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            HandleException(e.Exception);
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            HandleException((Exception)e.ExceptionObject);
        }

        private static void HandleException(Exception e)
        {
            Console.WriteLine(e);
            Debug.WriteLine(e);
        }

        [STAThread]
        private static void Main(string[] args)
        {
            Cache.IsServer = true;
            string path = Util.AssemblyPath.Replace(@"\", string.Empty).Replace(@"/", string.Empty);
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            Application.ThreadException += Application_ThreadException;
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            try
            {
                using (ProcessLock pLock = (ProcessLock)CrossProcessLockFactory.CreateCrossProcessLock(100, path))
                {
                    if (Cache.Instance.EveSettings.SharpLogLite)
                        SharpLogLiteHandler.Instance.StartListening();

                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    try
                    {
                        Application.Run(new MainForm());
                    }
                    catch (ThreadAbortException)
                    {
                        Cache.Instance.Log("ThreadAbortException");
                    }
                }
            }
            catch (Exception ex)
            {
                if (ex is CrossProcessLockFactoryMutexException)
                    MessageBox.Show("EVESharpLauncher.exe is already running from path: [" + Util.AssemblyPath + "EVESharpLauncher.exe]", "Another Instance Already Running!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    Cache.Instance.Log("Exception: " + ex);
            }
        }

        #endregion Methods
    }
}