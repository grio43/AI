﻿extern alias SC;

using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    public class DirectMultiSellWindowItem : DirectObject
    {
        #region Fields

        private readonly PyObject _pyObj;

        #endregion Fields

        #region Constructors

        internal DirectMultiSellWindowItem(DirectEve directEve, PyObject obj) : base(directEve)
        {
            _pyObj = obj;
        }

        #endregion Constructors

        #region Properties

        public float AveragePrice => _pyObj.Attribute("averagePrice").ToFloat();

        public float BestPrice => _pyObj.Attribute("bestPrice").ToFloat();

        public int BrokersFee => _pyObj.Attribute("brokersFee").ToInt();
        public float BrokersFeePerc => _pyObj.Attribute("brokersFeePerc").ToFloat();
        public bool HasBid => _pyObj.Attribute("bestBid").IsValid && _pyObj.Attribute("estimatedSellCount").ToInt() != 0;
        public long ItemId => _pyObj.Attribute("itemID").ToLong();
        public string ItemName => _pyObj.Attribute("itemName").ToUnicodeString();
        public long LocationId => _pyObj.Attribute("locationID").ToLong();
        public float PricePercentage => BestPrice / (AveragePrice / 100);
        public long RegionId => _pyObj.Attribute("regionID").ToLong();

        public int SolarSystemId => _pyObj.Attribute("solarSystemID").ToInt();
        public long StationId => _pyObj.Attribute("stationID").ToLong();

        #endregion Properties

        #region Methods

        public void RemoveItem()
        {
            DirectEve.ThreadedCall(_pyObj.Attribute("RemoveItem"));
        }

        public override string ToString()
        {
            return $"{nameof(AveragePrice)}: {AveragePrice}, {nameof(BestPrice)}: {BestPrice}," +
                   $" {nameof(BrokersFee)}: {BrokersFee}, {nameof(BrokersFeePerc)}: {BrokersFeePerc}," +
                   $" {nameof(ItemId)}: {ItemId}, {nameof(ItemName)}: {ItemName}, {nameof(LocationId)}: {LocationId}," +
                   $" {nameof(RegionId)}: {RegionId}, {nameof(StationId)}: {StationId}, {nameof(SolarSystemId)}: {SolarSystemId}";
        }

        #endregion Methods
    }
}