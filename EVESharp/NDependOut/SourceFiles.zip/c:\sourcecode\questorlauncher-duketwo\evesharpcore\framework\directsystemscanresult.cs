﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using SC::SharedComponents.Py;
using SC::SharedComponents.Utility;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public enum ScanGroup
    {
        Starbase = 0,
        Scrap = 1,
        Fighter = 2,
        Signature = 3,
        Ship = 4,
        Structure = 5,
        Drone = 6,
        Celestial = 7,
        Anomaly = 8,
        Charge = 9,
        NPC = 10,
        Orbital = 11,
        Deployable = 12,
        Sovereignty = 13
    }


    /**
    public Dictionary<int, string> EXPLORATION_SITE_TYPES
    {
        siteTypeOre = "OreSite",
        siteTypeGas = "GasSite",
        siteTypeRelic = "RelicSite",
        siteTypeData = "DataSite",
        siteTypeWormhole = "Wormhole",
        siteTypeCombat = "Combat"
    }
    **/

    public class DirectSystemScanResult : DirectObject
    {
        #region Fields

        internal PyObject PyResult;

        #endregion Fields

        //'itemID': 1026895148307L,
        //'typeID': None,
        //'isIdentified': False,
        //'scanGroupID': 4,
        //'factionID': None,
        //'difficulty': None,
        //'data': (-76322780977.72708, -25978895447.96276, 430583048001.9394),
        //'certainty': 0.08137081820865469,
        //'prevCertainty': 0.08137081886993291,
        //'pos': (-76322780977.72708, -25978895447.96276, 430583048001.9394),
        //'groupID': None,
        //'strengthAttributeID': None,
        //'isPerfect': False,
        //'dungeonNameID': None,
        //'GetDistance': <bound method Result._GetDistance of <Result : HPK-944 - 4, None, None>>,
        //'id': 'HPK-943'}>

        #region Constructors

        internal DirectSystemScanResult(DirectEve directEve, PyObject pyResult)
            : base(directEve)
        {
            PyResult = pyResult;
            Id = (string) pyResult.Attribute("id");
            ScanGroupID = (int) pyResult.Attribute("scanGroupID");
            //StrengthAttributeID = (string)pyResult.Attribute("strengthAttributeID");
            //if (!string.IsNullOrEmpty(StrengthAttributeID))
            //{
            //    Logging.Log.WriteLine("strengthAttributeID is [" + StrengthAttributeID.ToString() + "]");
            //}

            TypeID = (int) pyResult.Attribute("typeID");
            GroupID = (int) pyResult.Attribute("groupID");
            ScanGroup = (ScanGroup) ScanGroupID;
            IsPerfectResult = (bool) pyResult.Attribute("isPerfect");
            //GroupName = (string) pyResult.Attribute("groupName").ToUnicodeString();
            //TypeName = (string) pyResult.Attribute("typeName").ToUnicodeString();
            SignalStrength = (double) pyResult.Attribute("certainty");
            PreviousSignalStrength = (double) pyResult.Attribute("prevCertainty");
            Deviation = (double) pyResult.Attribute("deviation");
            PyObject pos = pyResult.Attribute("pos");
            PyObject data = pyResult.Attribute("data");
            Pos = new Vector3((double) pos.Item(0), (double) pos.Item(1), (double) pos.Item(2));
            Data = new Vector3((double) data.Item(0), (double) data.Item(1), (double) data.Item(2));
            IsPointResult = (string) PyResult.Attribute("data").Attribute("__class__").Attribute("__name__") == "tuple";
            IsSphereResult = (string) PyResult.Attribute("data").Attribute("__class__").Attribute("__name__") == "float";
            MultiPointResult = (string) PyResult.Attribute("data").Attribute("__class__").Attribute("__name__") == "list";
            if (IsPerfectResult)
            {
                X = (double?)pyResult.Attribute("data").Attribute("x");
                Y = (double?)pyResult.Attribute("data").Attribute("y");
                Z = (double?)pyResult.Attribute("data").Attribute("z");
            }
            //IsCircleResult = !IsPointResult && !IsSpereResult;
            //if (IsPointResult)
            //{
            //    X = (double?) pyResult.Attribute("data").Attribute("x");
            //    Y = (double?) pyResult.Attribute("data").Attribute("y");
            //    Z = (double?) pyResult.Attribute("data").Attribute("z");
            //}
            //else if (IsCircleResult)
            //{
            //    X = (double?) pyResult.Attribute("data").Attribute("point").Attribute("x");
            //    Y = (double?) pyResult.Attribute("data").Attribute("point").Attribute("y");
            //    Z = (double?) pyResult.Attribute("data").Attribute("point").Attribute("z");
            //}

            // If SphereResult: X,Y,Z is probe location

            //if (X.HasValue && Y.HasValue && Z.HasValue)
            //{
            //    var myship = directEve.ActiveShip.Entity;
            //    Distance = Math.Sqrt((X.Value - myship.X) * (X.Value - myship.X) + (Y.Value - myship.Y) * (Y.Value - myship.Y) +
            //                         (Z.Value - myship.Z) * (Z.Value - myship.Z));
            //}
            GroupName = GetGroupName();
            TypeName = GetTypeName();
        }

        #endregion Constructors

        #region Properties

        public string GetTypeName()
        {
            if (ScanGroup == ScanGroup.Signature || ScanGroup == ScanGroup.Anomaly)
            {
                if (PyResult.Attribute("dungeonNameID").IsValid)
                {
                    return DirectEve.GetLocalizationMessageById(PyResult.Attribute("dungeonNameID").ToInt());
                }
            }
            //if (PyResult.Attribute("typeID").IsValid)
            //{
            //    var typeId = PyResult.Attribute("typeID").ToInt();
            //    DirectEve.Log(typeId.ToString());
            //    //return DirectEve.GetInvType(typeId).TypeName;
            //}
            return string.Empty;
        }

        public bool IsAnomaly
        {
            get
            {
                if (ScanGroup == ScanGroup.Anomaly)
                    return true;

                return false;
            }
        }

        public bool IsSignature
        {
            get
            {
                if (ScanGroup == ScanGroup.Signature)
                    return true;

                return false;
            }
        }

        public bool IsCombatSite
        {
            get
            {
                if (ScanGroup == ScanGroup.Signature)
                    if (GetGroupName().Contains("Combat"))
                        return true;

                return false;
            }
        }

        public string GetGroupName()
        {
            if (ScanGroup == ScanGroup.Signature || ScanGroup == ScanGroup.Anomaly)
            {
                if (PyResult.Attribute("strengthAttributeID").IsValid)
                {
                    var i = PyResult.Attribute("strengthAttributeID").ToInt();
                    var d = DirectEve.Const["EXPLORATION_SITE_TYPES"].ToDictionary<int>();
                    if (d.ContainsKey(i))
                    {
                        return DirectEve.GetLocalizationMessageByLabel(d[i].ToUnicodeString());
                    }
                }
            }
            //if (PyResult.Attribute("groupID").IsValid)
            //{
            //    var groupId = PyResult.Attribute("groupID").ToInt();
            //    // TODO: finish (evetypes.GetGroupNameByGroup)
            //}
            return string.Empty;
        }
        public Vector3 Data { get; internal set; }

        public string TypeName { get; internal set; }
        public double? Distance
        {
            get
            {
                if (IsPerfectResult)
                    DirectEve.ActiveShip.Entity.DistanceTo((double)X, (double)Y, (double)Z);

                return null;
            }
        }
        public double? X { get; internal set; }
        public double? Y { get; internal set; }
        public double? Z { get; internal set; }
        public double Deviation { get; internal set; }

        public int GroupID { get; internal set; }
        public string Id { get; internal set; }

        public bool IsPerfectResult { get; internal set; }
        public bool IsPointResult { get; internal set; }
        public bool IsSphereResult { get; internal set; }
        public bool MultiPointResult { get; internal set; }
        public Vector3 Pos { get; internal set; }
        public double PreviousSignalStrength { get; internal set; }
        public ScanGroup ScanGroup { get; internal set; }
        public bool IsIgnoredScanGroup
        {
            get
            {
                if (ScanGroup == ScanGroup.Celestial)
                    return true;

                if (ScanGroup == ScanGroup.Charge)
                    return true;

                if (ScanGroup == ScanGroup.Deployable)
                    return true;

                if (ScanGroup == ScanGroup.Drone)
                    return true;

                if (ScanGroup == ScanGroup.Fighter)
                    return true;

                if (ScanGroup == ScanGroup.NPC)
                    return true;

                if (ScanGroup == ScanGroup.Orbital)
                    return true;

                if (ScanGroup == ScanGroup.Scrap)
                    return true;

                if (ScanGroup == ScanGroup.Ship)
                    return true;

                if (ScanGroup == ScanGroup.Sovereignty)
                    return true;

                if (ScanGroup == ScanGroup.Starbase)
                    return true;

                if (ScanGroup == ScanGroup.Structure)
                    return true;

                return false;
            }
        }

        public bool IsGasSite
        {
            get
            {
                if (GroupName.ToLower().Contains("Gas".ToLower()))
                    return true;

                return false;
            }
        }

        public bool IsRelicSite
        {
            get
            {
                if (GroupName.ToLower().Contains("Relic".ToLower()))
                    return true;

                return false;
            }
        }

        public bool IsDataSite
        {
            get
            {
                if (GroupName.ToLower().Contains("Data".ToLower()))
                    return true;

                return false;
            }
        }

        public bool IsWormhole
        {
            get
            {
                if (GroupName.ToLower().Contains("Wormhole".ToLower()))
                    return true;

                return false;
            }
        }

        public int ScanGroupID { get; internal set; }

        public string GroupName { get; internal set; }
        public double SignalStrength { get; internal set; }

        public string StrengthAttributeID { get; internal set; }
        public int TypeID { get; internal set; }

        #endregion Properties

        //public bool IsCircleResult { get; internal set; }

        #region Methods

        public bool BookmarkScanResult(string title, string comment = "", bool corp = false)
        {
            if (corp)
                return DirectEve.ThreadedLocalSvcCall("bookmarkSvc", "BookmarkScanResult", DirectEve.Session.SolarSystemId.Value, title, comment, Id,
                    DirectEve.Session.CorporationId);
            return DirectEve.ThreadedLocalSvcCall("bookmarkSvc", "BookmarkScanResult", DirectEve.Session.SolarSystemId.Value, title, comment, Id,
                DirectEve.Session.CharacterId);
        }

        public bool WarpTo()
        {
            if (SignalStrength == 1)
                return DirectEve.ThreadedLocalSvcCall("menu", "WarpToScanResult", Id);
            return false;
        }

        public bool WarpFleetTo()
        {
            if (SignalStrength == 1)
                return DirectEve.ThreadedLocalSvcCall("menu", "WarpFleetToScanResult", Id);
            return false;
        }

        public bool IgnoreResult()
        {
            return true;
            //return DirectEve.ThreadedLocalSvcCall("menu", "IngoreResult", Id);
            //return DirectEve.ThreadedLocalSvcCall("menu", "IgnoreResult", Id);
            //PyObject scanSvc = DirectEve.GetLocalSvc("scanSvc");
            //if (scanSvc.IsValid)
            //{
            //    //return DirectEve.ThreadedLocalSvcCall("scanSvc", "IgnoreResult", .....);
            //}
        }

        #endregion Methods
    }
}