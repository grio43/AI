﻿
extern alias SC;

using SC::SharedComponents.Py;
using System.Collections.Generic;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectCharacterCreation : DirectObject
    {
        //
        // This is not yet ready for use!
        //

        #region Fields

        #endregion Fields

        #region Constructors

        internal DirectCharacterCreation(DirectEve directEve) : base(directEve)
        {
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        ///     The character selection screen is open
        /// </summary>
        public bool AtSelectRaceSelection => (bool) CharacterCreationLayer.Attribute("isopen");

        /// <summary>
        ///     The character creation screen is open
        /// </summary>
        public bool AtCharacterCreation => (bool)CharacterCreationLayer.Attribute("isopen") || (bool) LoginLayer.Attribute("isopening");

        /// <summary>
        ///     Is the character selection screen ready
        /// </summary>
        public bool IsCharacterCreationReady => (bool)CharacterCreationLayer.Attribute("ready");


        /// <summary>
        ///     Either the character selection screen or login screen is loading
        /// </summary>
        public bool IsLoading => (bool)LoginLayer.Attribute("isopening") || (bool)CharSelectLayer.Attribute("isopening");

        /// <summary>
        ///     The server status string
        /// </summary>
        public string ServerStatus => (string)LoginLayer.Attribute("serverStatusTextControl").Attribute("text");

        private PyObject CharSelectLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("charsel");
        private PyObject LoginLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("login");
        private PyObject CharacterCreationLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("charactercreation");


        //
        // Other viewstates
        //

        private PyObject PlanetLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("planet");
        private PyObject ActiveLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("activemap");
        private PyObject StarMapLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("starmap");
        private PyObject SystemMapLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("systemmap");
        private PyObject InflightLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("inflight");
        private PyObject ShipTreeLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("shiptree");
        private PyObject DockPanelLayer => PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("layer").Attribute("dockpanel");



        #endregion Properties
    }
}