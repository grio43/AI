﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 11.12.2013
 * Time: 12:51
 *
 * ---------------------------------------
 */

using EasyHook;
using SharedComponents.EVE;
using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;

namespace DomainHandler
{
    public class Main : IEntryPoint
    {
        #region Fields

        private readonly EVESharpInterface Interface;

        #endregion Fields

        #region Constructors

        public Main(RemoteHooking.IContext InContext, string ChannelName, string[] args)
        {
            Interface = RemoteHooking.IpcConnectClient<EVESharpInterface>(ChannelName);
            Interface.Ping();
        }

        #endregion Constructors

        #region Methods

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        public void Run(RemoteHooking.IContext InContext, string ChannelName, string[] args)
        {
            AppDomain currentDomain = AppDomain.CurrentDomain;
            AppDomain hookManagerDomain = AppDomain.CreateDomain("hookManagerDomain");
            string assemblyFolder = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            hookManagerDomain.ExecuteAssembly(assemblyFolder + "\\HookManager.exe", args);
            while (true)
                try
                {
                    Thread.Sleep(100);
                    Interface.Ping();
                }
                catch (Exception)
                {
                }
        }

        [DllImport("kernel32.dll")]
        private static extern void FreeLibraryAndExitThread(IntPtr hModule, uint dwExitCode);

        #endregion Methods
    }
}