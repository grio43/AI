﻿using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Text.RegularExpressions;

namespace SharedComponents.Socks5.Socks5Relay
{
    internal class Socks5Relay
    {
        #region Constructors

        public Socks5Relay(int timeout)
        {
            socketTimeout = timeout;
        }

        #endregion Constructors

        #region Fields

        private const int ver = 5;
        private readonly int socketTimeout;
        private string firstHost;

        private bool firstJump = true;
        private int firstPort;
        private byte[] readBuf;
        private byte[] writeBuf;

        #endregion Fields

        #region Methods

        public bool Add(string con)
        {
            GroupCollection match = new Regex("^(?:(.*?):(.*?)@)?(.*?)(?::(\\d+))?$").Match(con).Groups;

            string user = match[1].Success ? match[1].Value : null;
            string pass = match[2].Success ? match[2].Value : null;
            string host = match[3].Value;
            int port = match[4].Success ? int.Parse(match[4].Value) : 1080;

            List<byte> write = new List<byte>();
            List<byte> read = new List<byte>();

            if (writeBuf != null) write.AddRange(writeBuf);
            if (readBuf != null) read.AddRange(readBuf);

            if (firstJump)
            {
                firstHost = host;
                firstPort = port;
                firstJump = false;
            }
            else
            {
                write.AddRange(new byte[] { ver, 1, 0, 3, (byte)host.Length });
                write.AddRange(Encoding.ASCII.GetBytes(host));
                write.AddRange(new[] { (byte)(port >> 8), (byte)(port & 255) });
            }

            write.AddRange(new byte[] { ver, 1 });
            read.Add(ver);

            if (user != null && pass != null)
            {
                write.AddRange(new byte[] { 2, 1, (byte)user.Length });
                write.AddRange(Encoding.ASCII.GetBytes(user));
                write.AddRange(new[] { (byte)pass.Length });
                write.AddRange(Encoding.ASCII.GetBytes(pass));

                read.AddRange(new byte[] { 2, ver });
            }
            else
            {
                write.Add(0);
            }

            read.AddRange(new byte[] { 0, ver, 0, 0, 1, 0, 0, 0, 0, 0, 0 });

            writeBuf = write.ToArray();
            readBuf = read.ToArray();

            return true;
        }

        public Socket Connect()
        {
            if (firstHost == null)
                return null;

            Socket socket = new TcpClient(firstHost, firstPort).Client;
            socket.ReceiveTimeout = socketTimeout;
            socket.SendTimeout = socketTimeout;

            return socket;
        }

        public bool Pull(Socket sock)
        {
            if (!sock.Connected)
                return false;

            try
            {
                byte[] buf = new byte[readBuf.Length];
                int read = 0;
                while (read != readBuf.Length)
                {
                    int len = sock.Receive(buf, readBuf.Length, SocketFlags.None);
                    if (0 == len) break;
                    read += len;
                }
            }
            catch
            {
                return false;
            }

            return true;
        }

        public bool Push(Socket sock)
        {
            return PushRaw(sock, writeBuf);
        }

        public bool PushRaw(Socket sock, byte[] msg)
        {
            if (!sock.Connected)
                return false;

            try
            {
                sock.Send(msg);
            }
            catch
            {
                return false;
            }

            return true;
        }

        #endregion Methods
    }
}