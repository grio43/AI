﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 02.06.2014
 * Time: 19:29
 *
 * ---------------------------------------
 */

using EasyHook;
using SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;

namespace HookManager.Win32Hooks
{
    /// <summary>
    ///     Description of StealthTest.
    /// </summary>
    public static class StealthTest
    {
        #region Methods

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern IntPtr GetModuleHandleA(IntPtr lpModuleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr GetModuleHandleW(IntPtr lpModuleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern IntPtr LoadLibraryA(IntPtr lpModuleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr LoadLibraryW(IntPtr lpModuleName);

        public static void StealthTestEnumProc()
        {
            uint arraySize = 200;
            uint arrayBytesSize = arraySize * sizeof(uint);
            uint[] processIds = new uint[arraySize];
            //uint[] processIdsToReturn = new uint[arraySize];
            uint bytesCopied;

            HookManagerImpl.Log("[StealthTest] Enumprocs: EnumProcesses");
            bool success = EnumProcesses(processIds, arrayBytesSize, out bytesCopied);

            if (!success) return;
            if (0 == bytesCopied) return;

            int numIdsCopied = Convert.ToInt32(bytesCopied / 4);
            HookManagerImpl.Log("[StealthTest] Enumprocs: numIdsCopied [" + numIdsCopied + "]");

            int currentEvePID = Process.GetCurrentProcess().Id;
            HookManagerImpl.Log("[StealthTest] Enumprocs: currentEvePID [" + currentEvePID + "]");

            int processID = 0;

            for (int i = 0; i < numIdsCopied; i++)
            {
                processID = Convert.ToInt32(processIds[i]);
                try
                {
                    Process p = Process.GetProcessById(processID);
                    if (p != null)
                        HookManagerImpl.Log("ProcID i: (" + i + ") " + processID + " ExeName: " + p.ProcessName);
                    else
                        HookManagerImpl.Log("P: " + processIds[i] + " is null.");
                }
                catch (Exception ex)
                {
                    HookManagerImpl.Log("Exception [" + ex + "]");
                }
            }

            HookManagerImpl.Log("[StealthTest] Enumprocs: Done");
        }

        public static void StealthTestK32numProc()
        {
            uint arraySize = 200;
            uint arrayBytesSize = arraySize * sizeof(uint);
            uint[] processIds = new uint[arraySize];
            //uint[] processIdsToReturn = new uint[arraySize];
            uint bytesCopied;

            HookManagerImpl.Log("[StealthTest] Enumprocs: K32EnumProcesses: Started");
            bool success = K32EnumProcesses(processIds, arrayBytesSize, out bytesCopied);

            if (!success) return;
            if (0 == bytesCopied) return;

            int numIdsCopied = Convert.ToInt32(bytesCopied / 4);
            HookManagerImpl.Log("[StealthTest] Enumprocs: numIdsCopied [" + numIdsCopied + "]");

            int currentEvePID = Process.GetCurrentProcess().Id;
            HookManagerImpl.Log("[StealthTest] Enumprocs: currentEvePID [" + currentEvePID + "]");

            int processID = 0;

            for (int i = 0; i < numIdsCopied; i++)
            {
                processID = Convert.ToInt32(processIds[i]);
                try
                {
                    Process p = Process.GetProcessById(processID);
                    if (p != null)
                        HookManagerImpl.Log("ProcID i: (" + i + ") " + processID + " ExeName: " + p.ProcessName);
                    else
                        HookManagerImpl.Log("P: " + processIds[i] + " is null.");
                }
                catch (Exception ex)
                {
                    HookManagerImpl.Log("Exception [" + ex + "]");
                }
            }

            HookManagerImpl.Log("[StealthTest] Enumprocs: K32EnumProcesses: Done");
        }

        public static void StealthTestLoadLibrary()
        {
            try
            {
                HookManagerImpl.Log("[StealthTest] StealthTestLoadLibrary Started");

                string[] dllNames =
                        {"SharedComponents.dll", "EasyHook.dll", "DomainHandler.dll", "NotExisting.dll", "HookManager.exe", "EVESharpCore.exe"};

                foreach (string dllName in dllNames)
                {
                    IntPtr ptr = LoadLibrary(dllName);
                    if (ptr != IntPtr.Zero)
                        HookManagerImpl.Log("[StealthTest-LoadLibrary] Handle found for " + dllName);
                    else
                        HookManagerImpl.Log("[StealthTest-LoadLibrary] Handle NOT found for " + dllName);

                    ptr = IntPtr.Zero;
                }

                HookManagerImpl.Log("[StealthTest] StealthTestLoadLibrary Done");
            }
            catch (Exception ex)
            {
                HookManagerImpl.Log("Exception [" + ex + "]");
            }
        }

        public static void StealthTestGetModuleHandle()
        {
            try
            {
                HookManagerImpl.Log("StealthTestGetModuleHandle Started");

                string[] dllNames =
                        {"SharedComponents.dll", "EasyHook.dll", "DomainHandler.dll", "NotExisting.dll", "HookManager.exe", "EVESharpCore.exe", "DirectEve.dll"};

                foreach (string dllName in dllNames)
                {
                    IntPtr ptr = GetModuleHandle(dllName);
                    if (ptr != IntPtr.Zero)
                        HookManagerImpl.Log("[StealthTest-GetModuleHandle] Handle found for: " + dllName);
                    else
                        HookManagerImpl.Log("[StealthTest-GetModuleHandle] Handle not found for: " + dllName);

                    ptr = IntPtr.Zero;
                }

                HookManagerImpl.Log("[StealthTest] StealthTestGetModuleHandle Done");
            }
            catch (Exception ex)
            {
                HookManagerImpl.Log("Exception [" + ex + "]");
            }
        }

        public static void StealthTestGetImportAddress()
        {
            try
            {
                HookManagerImpl.Log("[StealthTest] Starting StealthTestGetImportAddress.");
                // hook imports test
                List<Tuple<string, string>> ListOfItemsToTest = new List<Tuple<string, string>>
                {
                    new Tuple<string, string>("Kernel32.dll", "CreateFileA"),
                    new Tuple<string, string>("Kernel32.dll", "CreateFileW"),
                    new Tuple<string, string>("advapi32.dll", "CryptCreateHash"),
                    new Tuple<string, string>("advapi32.dll", "CryptHashData"),
                    new Tuple<string, string>("kernel32.dll", "K32EnumProcesses"),
                    new Tuple<string, string>("Iphlpapi.dll", "GetAdaptersInfo"),
                    new Tuple<string, string>("Kernel32.dll", "GetModuleHandleA"),
                    new Tuple<string, string>("Kernel32.dll", "GetModuleHandleW"),
                    new Tuple<string, string>("kernel32.dll", "GlobalMemoryStatusEx"),
                    new Tuple<string, string>("wininet.dll", "InternetConnectA"),
                    new Tuple<string, string>("wininet.dll", "InternetConnectW"),
                    new Tuple<string, string>("Kernel32.dll", "IsDebuggerPresent"),
                    new Tuple<string, string>("Kernel32.dll", "LoadLibraryA"),
                    new Tuple<string, string>("Kernel32.dll", "LoadLibraryW"),
                    new Tuple<string, string>("DbgHelp.dll", "MiniDumpWriteDump"),
                    new Tuple<string, string>("advapi32.dll", "RegQueryValueExA"),
                    new Tuple<string, string>("shell32.dll", "SHGetFolderPathA"),
                    new Tuple<string, string>("shell32.dll", "SHGetFolderPathW"),
                    new Tuple<string, string>("WS2_32.dll", "connect")
                };

                foreach (Tuple<string, string> individualTestTupleOfItems in ListOfItemsToTest)
                {
                    IntPtr a = IntPtr.Zero;
                    IntPtr b = IntPtr.Zero;
                    IntPtr c = IntPtr.Zero;
                    IntPtr d = IntPtr.Zero;

                    try
                    {
                        a = Util.GetImportAddress("_ctypes.pyd", individualTestTupleOfItems.Item1, individualTestTupleOfItems.Item2);
                    }
                    catch (Exception ex)
                    {
                        HookManagerImpl.Log("[StealthTest]" + individualTestTupleOfItems.ToString() + "[ _ctypes.pyd ]Exception [" + ex + "]");
                    }

                    try
                    {
                        b = Util.GetImportAddress("blue.dll", individualTestTupleOfItems.Item1, individualTestTupleOfItems.Item2);
                    }
                    catch (Exception ex)
                    {
                        HookManagerImpl.Log("[StealthTest]" + individualTestTupleOfItems.ToString() + "[ blue.dll ] Exception [" + ex + "]");
                    }

                    try
                    {
                        c = Util.GetImportAddress("exefile.exe", individualTestTupleOfItems.Item1, individualTestTupleOfItems.Item2);
                    }
                    catch (Exception ex)
                    {
                        HookManagerImpl.Log("[StealthTest]" + individualTestTupleOfItems.ToString() + "[ exefile.exe ] Exception [" + ex + "]");
                    }

                    try
                    {
                        d = LocalHook.GetProcAddress(individualTestTupleOfItems.Item1, individualTestTupleOfItems.Item2);
                    }
                    catch (Exception ex)
                    {
                        HookManagerImpl.Log("[StealthTest] GetProcAddress: Exception [" + ex + "]");
                    }

                    HookManagerImpl.Log("[StealthTest] " + string.Format("{0}: {1} - {2} - {3} - {4}", individualTestTupleOfItems, a, b, c, d));
                }
            }
            catch (Exception ex)
            {
                HookManagerImpl.Log("Exception [" + ex + "]");
            }
        }

        public static void Test()
        {
            new Thread(() =>
            {
                try
                {
                    HookManagerImpl.Log("[StealthTest] Starting stealth tests.");

                    //StealthTestEnumProc();
                    //StealthTestK32numProc();
                    StealthTestLoadLibrary();
                    StealthTestGetModuleHandle();
                    StealthTestGetImportAddress();
                }
                catch (Exception ex)
                {
                    HookManagerImpl.Log("Exception [" + ex + "]");
                }
            }).Start();
        }

        [DllImport("psapi.dll")]
        private static extern bool EnumProcesses(
            [MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.U4)] [In] [Out] uint[] processIds,
            uint arraySizeBytes,
            [MarshalAs(UnmanagedType.U4)] out uint bytesCopied);

        [DllImport("kernel32.dll")]
        private static extern bool K32EnumProcesses(
            [MarshalAs(UnmanagedType.LPArray, ArraySubType = UnmanagedType.U4)] [In] [Out] uint[] processIds,
            uint arraySizeBytes,
            [MarshalAs(UnmanagedType.U4)] out uint bytesCopied);

        [DllImport("kernel32", SetLastError = true, CharSet = CharSet.Unicode)]
        private static extern IntPtr LoadLibrary(string lpFileName);

        #endregion Methods
    }
}