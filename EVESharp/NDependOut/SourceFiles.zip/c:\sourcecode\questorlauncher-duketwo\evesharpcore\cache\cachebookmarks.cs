﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Stats;
using EVESharpCore.States;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Cache
{
    public partial class ESCache
    {
        #region Fields

        public List<DirectBookmark> _allBookmarks;
        public DateTime NextBookmarkDeletionAttempt = DateTime.UtcNow;
        internal static DirectBookmark _undockBookmarkInLocal;
        private int _bookmarkDeletionAttempt;
        private IEnumerable<DirectBookmark> ListOfUndockBookmarks;

        #endregion Fields

        #region Properties

        public IEnumerable<DirectBookmark> AfterMissionSalvageBookmarks
        {
            get
            {
                try
                {
                    string _bookmarkprefix = Settings.Instance.BookmarkPrefix;

                    if (Instance.BookmarksByLabel(_bookmarkprefix + " ") != null)
                        return Instance.BookmarksByLabel(_bookmarkprefix + " ").ToList();

                    return new List<DirectBookmark>();
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return new List<DirectBookmark>();
                }
            }
        }

        public DirectBookmark GetSalvagingBookmark
        {
            get
            {
                try
                {
                    if (Instance.DirectEve.Bookmarks != null && Instance.DirectEve.Bookmarks.Any())
                    {
                        List<DirectBookmark> _SalvagingBookmarks;
                        DirectBookmark _SalvagingBookmark;
                        if (Salvage.FirstSalvageBookmarksInSystem)
                        {
                            Log.WriteLine("Salvaging at first bookmark from system");
                            _SalvagingBookmarks = Instance.BookmarksByLabel(Settings.Instance.BookmarkPrefix + " ");
                            if (_SalvagingBookmarks != null && _SalvagingBookmarks.Any())
                            {
                                _SalvagingBookmark =
                                    _SalvagingBookmarks.OrderBy(b => b.CreatedOn).FirstOrDefault(c => c.LocationId == Instance.DirectEve.Session.SolarSystemId);
                                return _SalvagingBookmark;
                            }

                            return null;
                        }

                        Log.WriteLine("Salvaging at first oldest bookmarks");
                        _SalvagingBookmarks = Instance.BookmarksByLabel(Settings.Instance.BookmarkPrefix + " ");
                        if (_SalvagingBookmarks != null && _SalvagingBookmarks.Any())
                        {
                            _SalvagingBookmark = _SalvagingBookmarks.OrderBy(b => b.CreatedOn).FirstOrDefault();
                            return _SalvagingBookmark;
                        }

                        return null;
                    }

                    return null;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return null;
                }
            }
        }

        public IEnumerable<DirectBookmark> SafeSpotBookmarks
        {
            get
            {
                try
                {
                    if (_safeSpotBookmarks == null)
                        if (Instance.BookmarksByLabel(Settings.Instance.SafeSpotBookmarkPrefix).Any())
                            _safeSpotBookmarks = Instance.BookmarksByLabel(Settings.Instance.SafeSpotBookmarkPrefix).ToList();

                    if (_safeSpotBookmarks != null && _safeSpotBookmarks.Any())
                        return _safeSpotBookmarks;

                    return new List<DirectBookmark>();
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                }

                return new List<DirectBookmark>();
            }
        }

        public DirectBookmark UndockBookmark
        {
            get
            {
                try
                {
                    if (_undockBookmarkInLocal == null)
                    {
                        if (ListOfUndockBookmarks == null)
                            if (Settings.Instance.UndockBookmarkPrefix != "")
                                ListOfUndockBookmarks = Instance.BookmarksByLabel(Settings.Instance.UndockBookmarkPrefix);
                        if (ListOfUndockBookmarks != null && ListOfUndockBookmarks.Any())
                        {
                            ListOfUndockBookmarks = ListOfUndockBookmarks.Where(i => i.IsInCurrentSystem).ToList();
                            _undockBookmarkInLocal =
                                ListOfUndockBookmarks.OrderBy(i => Instance.DistanceFromMe(i.X ?? 0, i.Y ?? 0, i.Z ?? 0))
                                    .FirstOrDefault(b => Instance.DistanceFromMe(b.X ?? 0, b.Y ?? 0, b.Z ?? 0) < (int)Distances.NextPocketDistance);
                            if (_undockBookmarkInLocal != null)
                                return _undockBookmarkInLocal;

                            return null;
                        }

                        return null;
                    }

                    return _undockBookmarkInLocal;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("[" + exception + "]");
                    return null;
                }
            }
            internal set => _undockBookmarkInLocal = value;
        }

        #endregion Properties

        #region Methods

        public DirectBookmark BookmarkById(long bookmarkId)
        {
            return Instance.DirectEve.Bookmarks.FirstOrDefault(b => b.BookmarkId == bookmarkId);
        }

        public List<DirectBookmark> BookmarksByLabel(string label)
        {
            try
            {
                //
                // does this work in w-space? .solarsystem might be null in that case
                //
                if (Instance.DirectEve.Bookmarks != null && Instance.DirectEve.Bookmarks.Any())
                {
                    //Log.WriteLine("BookmarksByLabel: We have [" + Instance.DirectEve.Bookmarks.Count() + "] bookmarks total");
                    //foreach (var bookmark in Instance.DirectEve.Bookmarks.Where(b => b.CreatedOn > DateTime.UtcNow.AddYears(-2)))
                    //{
                    //    Log.WriteLine("Bookmark named [" + bookmark.Title + "] locationid [" + bookmark.LocationId + "] solarsystem [" + bookmark.SolarSystem.Name + "]");
                    //}

                    List<DirectBookmark> tempBookmarks = Instance.DirectEve.Bookmarks.Where(b => !string.IsNullOrEmpty(label) &&  b.LocationId != null && !string.IsNullOrEmpty(b.Title) && b.Title.ToLower().StartsWith(label.ToLower())).ToList() ?? new List<DirectBookmark>();
                    if (tempBookmarks.Any())
                    {
                        //Log.WriteLine("BookmarksByLabel: We have [" + tempBookmarks.Count() + "] bookmarks with [" + label + "] in the title");
                        tempBookmarks = tempBookmarks.OrderBy(f => f.LocationId).ToList() ?? new List<DirectBookmark>();
                        tempBookmarks = tempBookmarks.OrderBy(f => f.LocationId).ThenBy(i => Instance.DistanceFromMe(i.X ?? 0, i.Y ?? 0, i.Z ?? 0)).ToList() ?? new List<DirectBookmark>();
                        return tempBookmarks;
                    }

                    //Log.WriteLine("BookmarksByLabel: No Bookmarks found containing [" + label + "].");
                    return new List<DirectBookmark>();
                }

                //Log.WriteLine("BookmarksByLabel: No Bookmarks found containing [" + label + "]");
                return new List<DirectBookmark>();
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return new List<DirectBookmark>();
            }
        }

        public List<DirectBookmark> BookmarksThatContain(string label)
        {
            try
            {
                if (Instance.DirectEve.Bookmarks != null && Instance.DirectEve.Bookmarks.Any())
                    return
                        Instance.DirectEve.Bookmarks.Where(b => !string.IsNullOrEmpty(b.Title) && b.Title.ToLower().Contains(label.ToLower()))
                            .OrderBy(f => f.LocationId)
                            .ToList();

                return null;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return null;
            }
        }

        public bool CreateBookmark(string label)
        {
            try
            {
                if (Instance.AfterMissionSalvageBookmarks.Count() < 100)
                    if (Salvage.CreateSalvageBookmarksIn.ToLower() == "corp".ToLower())
                    {
                        DirectBookmarkFolder folder = Instance.DirectEve.BookmarkFolders.FirstOrDefault(i => i.Name == Settings.Instance.BookmarkFolder);
                        if (folder != null)
                        {
                            if (!Instance.EveAccount.OkToInteractWithEveNow)
                            {
                                if (DebugConfig.DebugInteractWithEve) Log.WriteLine("CreateBookmark: !OkToInteractWithEveNow");
                                return false;
                            }

                            if (Instance.DirectEve.CorpBookmarkCurrentLocation(label, "", folder.Id))
                            {
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                return true;
                            }

                            return false;
                        }
                        if (!Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("CreateBookmark: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (Instance.DirectEve.CorpBookmarkCurrentLocation(label, "", null))
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            return true;
                        }

                        return false;
                    }
                    else
                    {
                        DirectBookmarkFolder folder = Instance.DirectEve.BookmarkFolders.FirstOrDefault(i => i.Name == Settings.Instance.BookmarkFolder);
                        if (folder != null)
                        {
                            if (!Instance.EveAccount.OkToInteractWithEveNow)
                            {
                                if (DebugConfig.DebugInteractWithEve) Log.WriteLine("CreateBookmark: !OkToInteractWithEveNow");
                                return false;
                            }

                            if (Instance.DirectEve.BookmarkCurrentLocation(label, "", folder.Id))
                            {
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                return true;
                            }

                            return false;
                        }
                        if (!Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("CreateBookmark: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (Instance.DirectEve.BookmarkCurrentLocation(label, "", null))
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            return true;
                        }

                        return false;
                    }
                Log.WriteLine(
                    "We already have over 100 AfterMissionSalvage bookmarks: their must be a issue processing or deleting bookmarks. No additional bookmarks will be created until the number of salvage bookmarks drops below 100.");

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }
        }

        public bool DeleteBookmarksOnGrid(string module)
        {
            try
            {
                if (DateTime.UtcNow < NextBookmarkDeletionAttempt)
                    return false;

                NextBookmarkDeletionAttempt = DateTime.UtcNow.AddSeconds(5 + Settings.Instance.RandomNumber(1, 5));

                DeleteUselessSalvageBookmarks(module);

                List<DirectBookmark> bookmarksInLocal =
                    new List<DirectBookmark>(
                        AfterMissionSalvageBookmarks.Where(b => b.LocationId == Instance.DirectEve.Session.SolarSystemId).OrderBy(b => b.CreatedOn));
                DirectBookmark onGridBookmark = bookmarksInLocal.FirstOrDefault(b => Instance.DistanceFromMe(b.X ?? 0, b.Y ?? 0, b.Z ?? 0) < (int)Distances.OnGridWithMe);
                if (onGridBookmark != null)
                {
                    _bookmarkDeletionAttempt++;
                    if (_bookmarkDeletionAttempt <= bookmarksInLocal.Count + 60)
                    {
                        Log.WriteLine("removing salvage bookmark:" + onGridBookmark.Title);
                        onGridBookmark.Delete();
                        Log.WriteLine("after: removing salvage bookmark:" + onGridBookmark.Title);
                        NextBookmarkDeletionAttempt = DateTime.UtcNow.AddSeconds(Instance.RandomNumber(2, 6));
                        return false;
                    }

                    if (_bookmarkDeletionAttempt > bookmarksInLocal.Count + 60)
                    {
                        Log.WriteLine("error removing bookmark!" + onGridBookmark.Title);
                        State.CurrentQuestorState = QuestorState.Error;
                        return false;
                    }

                    return false;
                }

                _bookmarkDeletionAttempt = 0;
                Statistics.FinishedSalvaging = DateTime.UtcNow;
                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }
        }

        public bool DeleteUselessSalvageBookmarks(string module)
        {
            if (DateTime.UtcNow < NextBookmarkDeletionAttempt)
            {
                if (DebugConfig.DebugSalvage)
                    Log.WriteLine("NextBookmarkDeletionAttempt is still [" + NextBookmarkDeletionAttempt.Subtract(DateTime.UtcNow).TotalSeconds +
                                  "] sec in the future... waiting");
                return false;
            }

            try
            {
                DateTime bmExpirationDate = DateTime.UtcNow.AddMinutes(-Salvage.AgeofSalvageBookmarksToExpire);
                List<DirectBookmark> uselessSalvageBookmarks =
                    new List<DirectBookmark>(
                        AfterMissionSalvageBookmarks.Where(e => e.CreatedOn != null && e.CreatedOn.Value.CompareTo(bmExpirationDate) < 0).ToList());

                DirectBookmark uselessSalvageBookmark = uselessSalvageBookmarks.FirstOrDefault();
                if (uselessSalvageBookmark != null)
                {
                    _bookmarkDeletionAttempt++;
                    if (_bookmarkDeletionAttempt <=
                        uselessSalvageBookmarks.Count(e => e.CreatedOn != null && e.CreatedOn.Value.CompareTo(bmExpirationDate) < 0) + 60)
                    {
                        Log.WriteLine("removing a salvage bookmark that aged more than [" + Salvage.AgeofSalvageBookmarksToExpire + "]" +
                                      uselessSalvageBookmark.Title);
                        NextBookmarkDeletionAttempt = DateTime.UtcNow.AddSeconds(5 + Settings.Instance.RandomNumber(1, 5));
                        uselessSalvageBookmark.Delete();
                        return false;
                    }

                    if (_bookmarkDeletionAttempt >
                        uselessSalvageBookmarks.Count(e => e.CreatedOn != null && e.CreatedOn.Value.CompareTo(bmExpirationDate) < 0) + 60)
                    {
                        Log.WriteLine("error removing bookmark!" + uselessSalvageBookmark.Title);
                        State.CurrentQuestorState = QuestorState.Error;
                        return false;
                    }

                    return false;
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception:" + ex.Message);
            }

            return true;
        }

        #endregion Methods
    }
}