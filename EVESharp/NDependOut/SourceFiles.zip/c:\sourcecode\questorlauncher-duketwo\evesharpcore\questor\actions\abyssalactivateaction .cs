using EVESharpCore.Cache;
using EVESharpCore.Logging;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Lookup;
using EVESharpCore.States;
using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Questor.Behaviors;
using Action = EVESharpCore.Questor.Actions.Base.Action;
using EVESharpCore.Framework;

namespace EVESharpCore.Questor.Actions
{
    public partial class ActionControl
    {
        #region Methods

        private static void AbyssalActivateAction(Action action)
        {
            try
            {
                if (NextActionBool) Nextaction(null, null, true);

                if (ESCache.Instance.InWarp || ESCache.Instance.MyShipEntity.HasInitiatedWarp) return;
                if (Time.Instance.LastInWarp.AddSeconds(3) > DateTime.UtcNow) return;

                if (!ESCache.Instance.AccelerationGates.Any())
                {
                    if (!_waiting)
                    {
                        Log.WriteLine("Activate: Can't find any gates to activate! Waiting [" + Time.Instance.NoGateFoundRetryDelay_seconds + "] seconds before giving up");
                        _waitingSince = DateTime.UtcNow;
                        _waiting = true;
                        return;
                    }

                    return;
                }

                EntityCache closest = ESCache.Instance.AccelerationGates.OrderBy(t => t.Distance).FirstOrDefault(); // at least one gate must exists at this point
                if (closest != null)
                {
                    NavigateOnGrid.NavigateToTarget(closest, 0);

                    if (DateTime.UtcNow > Time.Instance.LastApproachAction.AddSeconds(15) && 50 > ESCache.Instance.MyShipEntity.Velocity && closest.Distance > (int)Distances.GateActivationRange)
                    {
                        Log.WriteLine("ActivateAction: [" + closest.Name + "][" + Math.Round(closest.Distance / 1000,0) + "k away ] going [" + Math.Round(ESCache.Instance.MyShipEntity.Velocity, 0) + " m/s]: approaching gate");
                        closest.Approach();
                    }

                    try
                    {
                        if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBsSpawnRunAway)
                        {
                            double FarthestDroneDistance = 0;
                            if (Drones.ActiveDrones.Any())
                            {
                                FarthestDroneDistance = Math.Round(Drones.ActiveDrones.OrderByDescending(i => i.Distance).FirstOrDefault().Distance / 1000, 0);
                            }

                            double AccelerationGateDistance = 0;
                            if (ESCache.Instance.AccelerationGates.Any())
                            {
                                AccelerationGateDistance = Math.Round(ESCache.Instance.AccelerationGates.FirstOrDefault().Distance / 1000, 0);
                            }

                            if (AccelerationGateDistance < 15000 && Drones.ActiveDrones.Any(i => i.Distance > 10000))
                            {
                                ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.CmdDronesReturnAndOrbit);
                                Log.WriteLine("14BSSpawn: DronesShouldBePulled [" + Drones.DronesShouldBePulled + "] AccelerationGate [" + AccelerationGateDistance + "k] Farthest Drone [" + FarthestDroneDistance + "] ");
                            }
                            else if (Drones.DronesShouldBePulled && AccelerationGateDistance > 16000 && Combat.Combat.PotentialCombatTargets.Any(i => i.IsWebbingMe))
                            {
                                Log.WriteLine("14BSSpawn: DronesShouldBePulled [" + Drones.DronesShouldBePulled + "] AccelerationGate [" + AccelerationGateDistance + "k]");
                                Drones.DronesShouldBePulled = false;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.WriteLine("Exception [" + ex + "]");
                    }

                    if (5000 > closest.Distance)
                    {
                        closest.Orbit(500);
                    }

                    if (2000 > closest.Distance)
                    {
                        Log.WriteLine("ActivateAction: [" + closest.Name + "]: We are within [ 2000m ] of [" + closest.Name + "]");

                        try
                        {
                            if (!AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && ESCache.Instance.DirectEve.Me.AbyssalContentExpirationRemainingSeconds > 10)
                            {
                                Combat.Combat.ReloadAllWeaponsWithSameAmmoUsingCmdReloadAmmo();
                            }
                        }
                        catch (Exception){}

                        // We cant activate if we have drones out
                        if (Drones.ActiveDrones.Any())
                        {
                            // Tell the drones module to retract drones
                            Drones.DronesShouldBePulled = true;
                            Log.WriteLine("ActivateAction: Waiting for drones to return to the drone bay: Farthest Drone [" + Math.Round(Drones.ActiveDrones.OrderByDescending(i => i.Distance).FirstOrDefault().Distance / 1000, 0) + "k away][" + Math.Round(Drones.ActiveDrones.OrderByDescending(i => i.Velocity).FirstOrDefault().Distance, 0) + " m/s]");
                            if (WaitForDronesToReturn) return;
                        }

                        if (!HealthCheck())
                        {
                            NavigateOnGrid.LogMyCurrentHealth("Activate HealthCheck Failed");
                            return;
                        }

                        if (closest.Activate())
                        {
                            Log.WriteLine("Activate: [" + closest.Name + "]: change state to 'NextPocket'");
                            ChangeCombatMissionCtrlState(ActionControlState.NextPocket, null, null);
                            return;
                        }

                        Log.WriteLine("Activate: [" + closest.Name + "] failed: retrying");
                    }
                }

                return;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        private static bool WaitForDronesToReturn
        {
            get
            {
                //abyssal timer uncomfortably low
                if (10 > ESCache.Instance.DirectEve.Me.AbyssalContentExpirationRemainingSeconds)
                    return false;

                if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs && (ESCache.Instance.ActiveShip.IsShieldTanked && 50 > ESCache.Instance.MyShipEntity.ArmorPct) || (ESCache.Instance.ActiveShip.IsShieldTanked && 50 > ESCache.Instance.MyShipEntity.ShieldPct))
                    return false;

                return true;
            }
        }

        private static bool HealthCheckNeeded
        {
            get
            {
                //abyssal timer uncomfortably low
                if (10 > ESCache.Instance.DirectEve.Me.AbyssalContentExpirationRemainingSeconds)
                    return false;

                //exiting abyssal deadspace
                if (ESCache.Instance.AccelerationGates.Any() && ESCache.Instance.AccelerationGates.FirstOrDefault().Name.Contains("Origin Conduit"))
                    return false;

                if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs)
                    return false;

                return true;
            }
        }

        public static bool HealthCheck()
        {
            if (ESCache.Instance.ActiveShip != null && HealthCheckNeeded)
            {
                if (AbyssalDeadspaceBehavior.HealthCheckMinimumShieldPercentage > (ESCache.Instance.ActiveShip.ShieldPercentage * 100))
                    return false;

                if (ESCache.Instance.Modules.Any(i => i.IsArmorRepairModule) && AbyssalDeadspaceBehavior.HealthCheckMinimumArmorPercentage > (ESCache.Instance.ActiveShip.ArmorPercentage * 100))
                    return false;

                if (AbyssalDeadspaceBehavior.HealthCheckMinimumCapacitorPercentage > (ESCache.Instance.ActiveShip.CapacitorPercentage * 100))
                    return false;
            }

            return true;
        }
        #endregion Methods
    }
}