﻿extern alias SC;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using System;
using System.Collections.Generic;
using System.Linq;
using SC::SharedComponents.Utility;

namespace EVESharpCore.Questor.BackgroundTasks
{
    public class Scanner
    {
        #region Fields


        #endregion Fields

        #region Properties


        #endregion Properties

        #region Methods

        public static DirectMapViewWindow myDirectMapViewWindow
        {
            get
            {
                DirectWindow tempWindow = ESCache.Instance.DirectEve.Windows.FirstOrDefault(w => w.GetType() == typeof(DirectMapViewWindow));

                if (tempWindow == null)
                {
                    Log.WriteLine("Opening MapViewWindow.");
                    if (ESCache.Instance.DirectEve.IsDirectionalScannerWindowOpen && ESCache.Instance.DirectEve.IsProbeScannerWindowOpen)
                    {
                        Log.WriteLine($"The DirectionalScanner and the ProbeScanner needs to be docked in within the MapViewWindow.");
                        return null;
                    }

                    if (ESCache.Instance.DirectEve.IsDirectionalScannerWindowOpen)
                    {
                        ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.ToggleProbeScanner);
                        return null;
                    }

                    if (ESCache.Instance.DirectEve.IsProbeScannerWindowOpen)
                    {
                        ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenDirectionalScanner);
                        return null;
                    }

                    ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenDirectionalScanner);
                    return null;
                }

                DirectMapViewWindow mapViewWindow = (DirectMapViewWindow)tempWindow;

                if (!mapViewWindow.IsProbeScanOpen())
                {
                    ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.ToggleProbeScanner);
                    return null;
                }

                if (!mapViewWindow.IsDirectionalScanOpen())
                {
                    ESCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenDirectionalScanner);
                    return null;
                }

                if (!mapViewWindow.IsDirectionalScannerDocked() || !mapViewWindow.IsProbeScannerDocked())
                {
                    Log.WriteLine($"The DirectionalScanner and the ProbeScanner needs to be docked in within the MapViewWindow.");
                    return null;
                }

                return mapViewWindow;
            }
        }

        public static DateTime PerformNextDscan = DateTime.MinValue;
        public static DateTime PerformNextProbeScan = DateTime.MinValue;
        public static bool executedScan = false;

        private static void SetDirectionalScanSettings(DirectMapViewWindow mapViewWindow)
        {
            mapViewWindow.IncreaseProbeRange();
            return;
        }

        private static List<DirectDirectionalScanResult> ListOfShipsSeenWhileNooneWasInLocal;


        public static void ClearPerPocketCache()
        {
            return;
        }

        private static int ProbeScanAttempts = 0;

        public static bool ProbeScanResultsReady
        {
            get
            {
                if (ProbeScanAttempts > 1)
                    return true;

                return false;
            }
        }

        public static void ClearPerSystemCache()
        {
            ListOfShipsSeenWhileNooneWasInLocal = new List<DirectDirectionalScanResult>();
            AnomalyScanResults = new List<DirectSystemScanResult>();
            SignatureScanResults = new List<DirectSystemScanResult>();
            ProbeScanAttempts = 0;
            return;
        }

        private static void CacheDirectionalScanResults(List<DirectDirectionalScanResult> myDirectionalScannerResults)
        {
            if (!ESCache.Instance.DirectEve.Session.CharactersInLocal.Any())
            {
                if (!myDirectionalScannerResults.Except(ListOfShipsSeenWhileNooneWasInLocal).Any())
                    return;

                ListOfShipsSeenWhileNooneWasInLocal = myDirectionalScannerResults;
            }

            return;
        }

        public static List<DirectSystemScanResult> AnomalyScanResults = new List<DirectSystemScanResult>();
        public static List<DirectSystemScanResult> SignatureScanResults = new List<DirectSystemScanResult>();
        public static List<DirectSystemScanResult> CachedSystemScanResults = new List<DirectSystemScanResult>();

        private static bool WeHaveNewAnomalies
        {
            get
            {
                bool boolNewAnoms = AnomalyScanResults.SequenceEqual(CachedSystemScanResults.Where(i => i.IsAnomaly));
                return boolNewAnoms;
            }
        }

        private static bool WeHaveNewSignatures
        {
            get
            {
                bool boolNewSignatures = SignatureScanResults.SequenceEqual(CachedSystemScanResults.Where(i => !i.IsAnomaly));
                return boolNewSignatures;
            }
        }

        public static void PerformProbeScan()
        {
            try
            {
                if (PerformNextProbeScan > DateTime.UtcNow)
                    return;

                if (ESCache.Instance.DirectEve.Bookmarks != null && !ESCache.Instance.DirectEve.Bookmarks.Any())
                    return;

                //if (!ESCache.Instance.DirectEve.Session.IsWspace)
                //    return;

                if (ESCache.Instance.InStation)
                {
                    Log.WriteLine("That doesn't work in stations.");
                    return;
                }

                if (ESCache.Instance.InWarp || ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                {
                    Log.WriteLine("Waiting, in warp.");
                    return;
                }

                if (myDirectMapViewWindow == null)
                    return;

                //LaunchProbesIfNeeded();

                if (myDirectMapViewWindow.IsProbeScanning())
                {
                    Log.WriteLine("Probe scan active, waiting.");
                    PerformNextDscan = DateTime.UtcNow.AddSeconds(1);
                    return;
                }

                ProbeScanAttempts++;
                CachedSystemScanResults = myDirectMapViewWindow.SystemScanResults;

                if (WeHaveNewAnomalies)
                {
                    int intAnomNumber = 0;
                    AnomalyScanResults = new List<DirectSystemScanResult>();
                    foreach (DirectSystemScanResult myAnom in CachedSystemScanResults.Where(r => r.ScanGroup == ScanGroup.Anomaly))
                    {
                        intAnomNumber++;
                        if (DebugConfig.DebugDirectionalScanner) Log.WriteLine("ProbeScan: [" + intAnomNumber + "][" + myAnom.Id + "] GroupName [" + myAnom.GroupName + "] SignalStrength [" + Math.Round(myAnom.SignalStrength, 2) + "]");
                        AnomalyScanResults.Add(myAnom);
                        continue;
                    }
                }

                if (WeHaveNewSignatures)
                {
                    int intSignatureNumber = 0;
                    SignatureScanResults = new List<DirectSystemScanResult>();
                    foreach (DirectSystemScanResult mySignature in CachedSystemScanResults.Where(r => r.ScanGroup == ScanGroup.Signature))
                    {
                        intSignatureNumber++;
                        if (DebugConfig.DebugDirectionalScanner) Log.WriteLine("ProbeScan: [" + intSignatureNumber + "][" + mySignature.Id + "] GroupName [" + mySignature.GroupName + "]");
                        SignatureScanResults.Add(mySignature);
                        continue;
                    }
                }

                PerformNextProbeScan = DateTime.UtcNow.AddMilliseconds(ESCache.Instance.RandomNumber(2000, 4000));
            }
            catch (Exception){}
        }

        public static void CloseMapViewWindow()
        {
            try
            {
                DirectWindow MapViewWindow = ESCache.Instance.DirectEve.Windows.FirstOrDefault(w => w.GetType() == typeof(DirectMapViewWindow));

                if (MapViewWindow != null)
                {
                    Log.WriteLine("Closing DirectionalScannerWindow");
                    MapViewWindow.Close();
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
                return;
            }
        }

        public static void PerformDirectionalScan()
        {
            try
            {
                if (PerformNextDscan > DateTime.UtcNow)
                    return;

                if (DebugConfig.DebugDisableCleanup) Log.WriteLine("PerformDirectionalScan()");
                DirectMapViewWindow mapViewWindow = myDirectMapViewWindow;
                if (mapViewWindow == null)
                    return;

                if (executedScan)
                {
                    List<DirectDirectionalScanResult> ListDirectionalScanResults = mapViewWindow.DirectionalScanResults.ToList();
                    int ShipsFoundOnScan = 0;
                    if (ListDirectionalScanResults.Any(i => i.CategoryId == (int)CategoryID.Ship && ESCache.Instance.Entities.All(x => x.Name != i.Name)))
                        ShipsFoundOnScan = ListDirectionalScanResults.Count(i => i.CategoryId == (int)CategoryID.Ship && ESCache.Instance.Entities.All(x => x.Name != i.Name));

                    Log.WriteLine($"D-Scan executed. [" + ListDirectionalScanResults.Count + "] items [" + ShipsFoundOnScan + "] ships found");
                    CacheDirectionalScanResults(ListDirectionalScanResults);

                    int intResult = 0;
                    foreach (DirectDirectionalScanResult directionalScanResult in ListDirectionalScanResults)
                    {
                        intResult++;
                        if (directionalScanResult.CategoryId != (int)CategoryID.Ship && directionalScanResult.CategoryId != (int)CategoryID.Entity)
                            continue;

                        /**
                        if (directionalScanResult.GroupId != (int)Group.Frigate &&
                            directionalScanResult.GroupId != (int)Group.AssaultShip &&
                            directionalScanResult.GroupId != (int)Group.Interceptor &&
                            directionalScanResult.GroupId != (int)Group.Interdictor &&
                            directionalScanResult.GroupId != (int)Group.CovertOpsFrigate &&
                            directionalScanResult.GroupId != (int)Group.ExpeditionFrigate &&
                            directionalScanResult.GroupId != (int)Group.Destroyer &&
                            directionalScanResult.GroupId != (int)Group.CommandDestroyer &&
                            directionalScanResult.GroupId != (int)Group.TacticalDestroyer &&
                            directionalScanResult.GroupId != (int)Group.ElectronicAttackShip &&
                            directionalScanResult.GroupId != (int)Group.Cruiser &&
                            directionalScanResult.GroupId != (int)Group.HeavyAssaultShip &&
                            directionalScanResult.GroupId != (int)Group.HeavyInterdictor &&
                            directionalScanResult.GroupId != (int)Group.CombatReconShip &&
                            directionalScanResult.GroupId != (int)Group.ForceReconShip &&
                            directionalScanResult.GroupId != (int)Group.Logistics &&
                            directionalScanResult.GroupId != (int)Group.StrategicCruiser &&
                            directionalScanResult.GroupId != (int)Group.CommandShip &&
                            directionalScanResult.GroupId != (int)Group.Battlecruiser &&
                            directionalScanResult.GroupId != (int)Group.Battleship &&
                            directionalScanResult.GroupId != (int)Group.BlackOps &&
                            directionalScanResult.GroupId != (int)Group.Marauder &&
                            directionalScanResult.GroupId != (int)Group.Carrier &&
                            directionalScanResult.GroupId != (int)Group.Titan &&
                            directionalScanResult.GroupId != (int)Group.Dreadnaught)
                            continue;
                        **/
                        if (directionalScanResult.GroupId == (int)Group.TransportShip ||
                            directionalScanResult.GroupId != (int)Group.Freighter ||
                            directionalScanResult.GroupId != (int)Group.JumpFreighter ||
                            directionalScanResult.GroupId != (int)Group.Industrial ||
                            directionalScanResult.GroupId != (int)Group.Capsule)
                            continue;

                        if (ListOfShipsSeenWhileNooneWasInLocal.Any(i => i.Name == directionalScanResult.Name && i.TypeId == directionalScanResult.TypeId))
                            continue;

                        Log.WriteLine("[" + intResult + "][" + directionalScanResult.TypeName + "][" + directionalScanResult.TypeId + "] Name [" + directionalScanResult.Name + "]");
                    }

                    executedScan = false;
                    return;
                }

                if (!mapViewWindow.IsDirectionalScanning())
                {
                    SetDirectionalScanSettings(mapViewWindow);
                    Log.WriteLine("Executed directional scan.");
                    mapViewWindow.DirectionalScan();
                    executedScan = true;
                    PerformNextDscan = DateTime.UtcNow.AddMilliseconds(ESCache.Instance.RandomNumber(4000, 6000));
                    return;
                }

                return;
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
                return;
            }
        }

        public static bool DoADirectionalScan()
        {
            try
            {
                if (ESCache.Instance.EveAccount.SelectedController == "AbyssalDeadspaceController")
                    return false;

                if (ESCache.Instance.InAbyssalDeadspace)
                    return false;

                if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController")
                    return false;

                if (ESCache.Instance.InWormHoleSpace)
                    return true;

                if (ESCache.Instance.DirectEve.Session.SolarSystem.IsLowSecuritySpace)
                    return true;

                if (ESCache.Instance.DirectEve.Me.IsAtWar)
                    return true;

                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        public static bool DoAProbeScan()
        {
            if (ESCache.Instance.EveAccount.SelectedController == "AbyssalDeadspaceController")
                return false;

            if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController")
                return false;

            if (ESCache.Instance.InAbyssalDeadspace)
                return false;

            if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.TransportShip)
                return false;

            if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.Freighter)
                return false;

            if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.BlockadeRunner)
                return false;

            if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.Industrial)
                return false;

            return true;
        }

        public static Dictionary<long, bool> PlanetsWeHaveScannedFrom = new Dictionary<long, bool>();

        public static void InitializePlanets()
        {
            if (ESCache.Instance.Planets.Any())
            {
                foreach (EntityCache planet in ESCache.Instance.Planets)
                {
                    if (PlanetsWeHaveScannedFrom.ContainsKey(planet.Id))
                        PlanetsWeHaveScannedFrom.Clear();
                }
            }
        }

        public static List<DirectSystemScanResult> PreviousTempScanResults = new List<DirectSystemScanResult>();

        public static void UpdatePreviousTempScanResults(DirectSystemScanResult result)
        {
            if (PreviousTempScanResults.Contains(result))
            {
                PreviousTempScanResults.Remove(result);
                PreviousTempScanResults.Add(result);
            }
        }

        public static Vector3 NextPlanetToScanFrom
        {
            get
            {
                foreach (EntityCache planet in ESCache.Instance.Planets)
                {
                    if (!PlanetsWeHaveScannedFrom.ContainsKey(planet.Id))
                    {
                        Log.WriteLine("Add [" + planet.Name + "] to the list of planets we have scanned from.");
                        PlanetsWeHaveScannedFrom.Add(planet.Id, true);
                        if (ESCache.Instance.Planets.Any(i => (double)Distances.OneAu > i.Distance))
                        {
                            foreach (EntityCache closePlanet in ESCache.Instance.Planets.Where(i => (double)Distances.OneAu > i.Distance))
                            {
                                if (!PlanetsWeHaveScannedFrom.ContainsKey(closePlanet.Id))
                                {
                                    Log.WriteLine("Add [" + closePlanet.Name + "] to the list of planets we have scanned from because it is close to [" + planet.Name + "]");
                                    PlanetsWeHaveScannedFrom.Add(closePlanet.Id, true);
                                }
                            }
                        }

                        Log.WriteLine("NextPlanetToScanFrom is [" + planet.Name + "][" + planet.Id + "]");
                        Vector3 planetCoord = new Vector3(planet.XCoordinate, planet.YCoordinate, planet.ZCoordinate);
                        return planetCoord;
                    }
                }

                Log.WriteLine("NextPlanetToScanFrom is you ship!? no planets left to scan from: Clearing list");
                PlanetsWeHaveScannedFrom = new Dictionary<long, bool>();
                return new Vector3(ESCache.Instance.Planets.FirstOrDefault().XCoordinate, ESCache.Instance.MyShipEntity.YCoordinate, ESCache.Instance.MyShipEntity.ZCoordinate);
            }
        }

        public static DateTime LastScanAction = DateTime.UtcNow;

        private static bool ShouldWeCloseMapViewWindow()
        {
            if (ESCache.Instance.InWormHoleSpace)
                return false;

            if (ESCache.Instance.DirectEve.Me.IsInvasionActive)
                return false;

            if (!DoADirectionalScan() && !DoAProbeScan())
                if (DateTime.UtcNow > LastScanAction.AddMinutes(2))
                    return true;

            return false;
        }

        public static void ProcessState()
        {
            if (!ESCache.Instance.DirectEve.Session.IsReady)
                return;

            if (ESCache.Instance.InSpace)
            {
                if (DoADirectionalScan())
                    PerformDirectionalScan();

                if (DoAProbeScan())
                    PerformProbeScan();

                if(ShouldWeCloseMapViewWindow())
                    CloseMapViewWindow();
            }
        }



        #endregion Methods
    }
}