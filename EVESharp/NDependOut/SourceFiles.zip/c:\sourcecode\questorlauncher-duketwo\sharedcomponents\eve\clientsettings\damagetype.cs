﻿using System;

namespace SharedComponents.EVE.ClientSettings
{
    [Serializable]
    public enum DamageType
    {
        EM,
        Kinetic,
        Thermal,
        Explosive
    }
}