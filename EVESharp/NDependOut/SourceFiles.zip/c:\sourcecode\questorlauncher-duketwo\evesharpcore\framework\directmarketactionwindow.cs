﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using SC::SharedComponents.Py;
using System;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectMarketActionWindow : DirectWindow
    {
        #region Constructors

        internal DirectMarketActionWindow(DirectEve directEve, PyObject pyWindow) : base(directEve, pyWindow)
        {
            IsReady = (bool) pyWindow.Attribute("ready");
            IsBuyAction = Name == "marketbuyaction";
            IsSellAction = Name == "marketsellaction";

            Item = new DirectItem(directEve);
            Item.PyItem = pyWindow.Attribute("sr").Attribute("sellItem");

            PyObject order = pyWindow.Attribute("sr").Attribute("currentOrder");
            Price = (double?) order.Attribute("price");
            RemainingVolume = (double?) order.Attribute("volRemaining");
            Range = (int?) order.Attribute("range");
            OrderId = (long?) order.Attribute("orderID");
            EnteredVolume = (int?) order.Attribute("volEntered");
            MinimumVolume = (int?) order.Attribute("minVolume");
            IsBid = (bool?) order.Attribute("bid");
            Issued = (DateTime?) order.Attribute("issued");
            Duration = (int?) order.Attribute("duration");
            StationId = (long?) order.Attribute("stationID");
            RegionId = (long?) order.Attribute("regionID");
            SolarSystemId = (long?) order.Attribute("solarSystemID");
            Jumps = (int?) order.Attribute("jumps");
        }

        #endregion Constructors

        #region Properties

        public int? Duration { get; }
        public int? EnteredVolume { get; }
        public bool? IsBid { get; }
        public bool IsBuyAction { get; }
        public bool IsReady { get; }
        public bool IsSellAction { get; }

        public DateTime? Issued { get; }
        public DirectItem Item { get; }

        public int? Jumps { get; }
        public int? MinimumVolume { get; }
        public long? OrderId { get; }
        public double? Price { get; }
        public int? Range { get; }
        public long? RegionId { get; }
        public double? RemainingVolume { get; }
        public long? SolarSystemId { get; }
        public long? StationId { get; }

        #endregion Properties

        #region Methods

        /// <summary>
        ///     Accept the action
        /// </summary>
        /// <returns></returns>
        public bool Accept()
        {
            string call = IsBuyAction ? "Buy" : "Sell";
            return DirectEve.ThreadedCall(PyWindow.Attribute(call));
        }

        /// <summary>
        ///     Cancel the action
        /// </summary>
        /// <returns></returns>
        public bool Cancel()
        {
            return DirectEve.ThreadedCall(PyWindow.Attribute("Cancel"));
        }

        #endregion Methods
    }
}