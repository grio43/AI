﻿extern alias SC;

using EVESharpCore.Framework;
using EVESharpCore.Framework.Events;
using EVESharpCore.Logging;
using EVESharpCore.Questor.Actions;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Lookup;
using EVESharpCore.States;
using EVESharpCore.Questor.Stats;
using SC::SharedComponents.EVE;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.Events;
using SC::SharedComponents.Extensions;
using SC::SharedComponents.IPC;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace EVESharpCore.Cache
{
    public class EntityCache
    {
        #region Constructors

        public EntityCache(DirectEntity entity)
        {
            _directEntity = entity;
            ThisEntityCacheCreated = DateTime.UtcNow;
        }

        #endregion Constructors

        #region Fields

        public readonly DirectEntity _directEntity;
        //public double? _effectiveHitpointsViaEM;
        //public double? _effectiveHitpointsViaExplosive;
        //public double? _effectiveHitpointsViaKinetic;
        //public double? _effectiveHitpointsViaThermal;
        private const int DictionaryCountThreshhold = 250;
        private readonly DateTime ThisEntityCacheCreated = DateTime.UtcNow;
        private string _givenName;
        //private bool? _isAbyssalDeadspaceAoeTowerWeapon;
        //private bool? _isAbyssalDeadspaceBioluminesenceCloud;
        //private bool? _isAbyssalDeadspaceCausticCloud;
        private bool? _isAbyssalDeadspaceDeviantAutomataSuppressorTower;
        //private bool? _isAbyssalDeadspaceFilamentCloud;
        private bool? _isAbyssalDeadspaceMultibodyTrackingPylonTower;
        private bool? _isAbyssalDeadspaceTriglavianBioAdaptiveCache { get;  set; }
        private bool? _isAbyssalDeadspaceTriglavianExtractionNode { get; set; }
        private bool? _isAbyssalPrecursorCache;
        private bool? _IsBadIdea;
        private bool? _isCorrectSizeForMyWeapons;
        private bool? _isEntityIShouldKeepShooting;
        private bool? _isEntityIShouldKeepShootingWithDrones;
        private bool? _isHigherPriorityPresent;
        private bool? _isHighValueTarget;
        private bool? _isIgnored;
        private bool? _isInOptimalRange;
        //private bool? _isInRangeOfAnAbyssalCloud;
        //private bool? _isInRangeOfAnAbyssalTower;
        private bool? _isLowValueTarget;
        private bool? _isOnGridWithMe;
        private bool? _isPreferredDroneTarget;
        private bool? _isPreferredPrimaryWeaponTarget;
        private bool? _isPrimaryWeaponKillPriority;
        private bool? _IsReadyForDronesToShoot;
        private bool? _IsReadyToShoot;
        private bool? _IsReadyToTarget;
        private bool? _IsTooCloseTooFastTooSmallToHit;
        private bool? _isTrackable;
        private double? _nearest5kDistance;
        private bool? _npcHasNeutralizers;
        private double? _npcRemoteArmorRepairChance;
        private double? _npcRemoteShieldRepairChance;
        private PrimaryWeaponPriority? _primaryWeaponPriorityLevel;

        private int? _targetValue;

        private double? _warpScrambleChance;

        #endregion Fields

        #region Properties

        public double AngularVelocity
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (Combat.DoWeCurrentlyHaveTurretsMounted())
                        return _directEntity.AngularVelocity;

                    return 0;
                }

                return 0;
            }
        }

        public double ArmorHitPoints => _directEntity.TotalArmor ?? 0;
        public double ArmorPct => _directEntity.ArmorPct;
        public double ArmorResistanceEM => _directEntity.ArmorResistanceEm ?? 0;
        public double ArmorResistanceExplosive => _directEntity.ArmorResistanceExplosive ?? 0;
        public double ArmorResistanceKinetic => _directEntity.ArmorResistanceKinetic ?? 0;
        public double ArmorResistanceThermal => _directEntity.ArmorResistanceThermal ?? 0;
        public List<DamageType> BestDamageTypes => _directEntity.BestDamageTypes;
        public BracketType BracketType => _directEntity.BracketType;

        public bool ScoopToCargoHold => _directEntity.ScoopToCargoHold;

        public DirectItem DirectItemFromAmmoType(AmmoType myAmmoType)
        {
            DirectItem tempDirectItem = new DirectItem(ESCache.Instance.DirectEve);
            tempDirectItem.TypeId = (int)myAmmoType.TypeId;
            return tempDirectItem;
        }

        public AmmoType BestAvailableAmmoTypes(List<AmmoType> listAvailableAmmo)
        {
            if (BestDamageTypes != null)
            {
                foreach (DamageType bestDamageType in BestDamageTypes)
                {
                    foreach (AmmoType individualAvailableAmmo in listAvailableAmmo.Where(i => i.DamageType == bestDamageType).OrderByDescending(x => MissileDamageCalc(DirectItemFromAmmoType(x))))
                    {
                        return individualAvailableAmmo;
                    }

                    continue;
                }


                return null;
            }

            return null;
        }

        public DirectContainerWindow CargoWindow
        {
            get
            {
                try
                {
                    if (ESCache.Instance.Windows == null || !ESCache.Instance.Windows.Any())
                        return null;

                    return ESCache.Instance.Windows.OfType<DirectContainerWindow>().FirstOrDefault(w => w.ItemId == Id);
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public int CategoryId => _directEntity.CategoryId;
        public double Distance => _directEntity.Distance;

        /**
        public bool IsBeingShotAtByOurDrones
        {
            get
            {
                if (Drones.ActiveDrones.Any())
                {
                    EntityCache drone = Drones.ActiveDrones.FirstOrDefault();
                    drone.IsLastTargetDronesWereShooting
                }

                return false;
            }
        }
        **/
        public bool? _isKillTarget;

        public bool IsKillTarget
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (_isKillTarget == null)
                    {
                        if (Combat._pickPrimaryWeaponTarget == null)
                            return false;

                        if (Combat._pickPrimaryWeaponTarget.Id == Id)
                        {
                            _isKillTarget = true;
                            return (bool)_isKillTarget;
                        }

                        _isKillTarget = false;
                        return (bool)_isKillTarget;
                    }

                    return (bool)_isKillTarget;
                }

                return false;
            }
        }

        public bool? _isDroneKillTarget;

        public bool IsDroneKillTarget
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (_isDroneKillTarget == null)
                    {
                        if (Drones._cachedDroneTarget == null)
                            return false;

                        if (Drones._cachedDroneTarget.Id == Id)
                        {
                            _isDroneKillTarget = true;
                            return (bool)_isDroneKillTarget;
                        }

                        _isDroneKillTarget = false;
                        return (bool)_isDroneKillTarget;
                    }

                    return (bool)_isDroneKillTarget;
                }

                return false;
            }
        }

        public bool WeShouldFocusFire
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (!Combat.FocusFireWhenWeaponsAndDronesAreInRangeOfDifficultTargets)
                        return false;

                    if (!IsInDroneRange)
                        return false;

                    if (!IsInRangeOfWeapons)
                        return false;

                    //if (BracketType == BracketType.NPC_Battleship)
                    //    return true;

                    if (BracketType == BracketType.NPC_Battlecruiser)
                        return true;

                    //if (BracketType == BracketType.Battleship)
                    //    return true;

                    if (BracketType == BracketType.Battlecruiser)
                        return true;

                    if (Name.ToLower().Contains("Vila Vedmak".ToLower()))
                        return false;

                    if (Name.ToLower().Contains("Vedmak".ToLower()))
                        return true;

                    if (TypeId == 48087) //Starving Vedmak
                        return true;

                    if (TypeId == 48090) //Starving Vedmak
                        return true;

                    if (TypeId == 48091) //Harrowing Vedmak
                        return true;

                    if (TypeId == 48092) //Striking Vedmak
                        return true;

                    //if (IsNPCCruiser && TriglavianDamage > 0)
                    //    return true;
                    //
                    //if (IsNPCCruiser && TriglavianDPS > 0)
                    //    return true;

                    return false;
                }

                return false;
            }
        }

        public DronePriority DronePriorityLevel
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Drones.DronePriorityTargets.Any(pt => pt.EntityID == _directEntity.Id))
                        {
                            DronePriority currentTargetPriority = Drones.DronePriorityTargets.Where(t => t.Entity.IsTarget
                                                                                                         && t.EntityID == Id)
                                .Select(pt => pt.DronePriority)
                                .FirstOrDefault();

                            return currentTargetPriority;
                        }

                        return DronePriority.NotUsed;
                    }

                    return DronePriority.NotUsed;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return DronePriority.NotUsed;
                }
            }
        }

        public long FollowId => _directEntity.FollowId;
        public double GetBounty => _directEntity != null ? _directEntity.GetBounty() : 0;

        public string GivenName
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                            Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                          Math.Round(_directEntity.Distance / 1000, 0) + "k][" +
                                          MaskedId + "] was created more than 5 seconds ago (ugh!)");
                        if (string.IsNullOrEmpty(_givenName))
                            _givenName = _directEntity.GivenName;

                        return _givenName ?? "";
                    }

                    return "";
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return "";
                }
            }
        }
        public int GroupId => _directEntity.GroupId;
        public bool HasExploded => _directEntity.HasExploded;
        public bool HasInitiatedWarp => _directEntity.IsWarping;
        public bool HasReleased => _directEntity.HasReleased;
        public bool HaveLootRights
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Salvage.IgnoreLootRights)
                            return true;

                        if (GroupId == (int)Group.SpawnContainer)
                            return true;

                        bool result = false;
                        if (ESCache.Instance.ActiveShip.Entity != null)
                        {
                            result |= _directEntity.CorpId == ESCache.Instance.ActiveShip.Entity.CorpId;
                            result |= _directEntity.OwnerId == ESCache.Instance.ActiveShip.Entity.CharId;
                            return result;
                        }

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public double EffectiveHitpointsViaEM
        {
            get
            {
                return ShieldEffectiveHitpointsViaEM * ArmorEffectiveHitpointsViaEM;
            }
        }

        public double EffectiveHitpointsViaExplosive
        {
            get
            {
                return ShieldEffectiveHitpointsViaExplosive * ArmorEffectiveHitpointsViaExplosive;
            }
        }

        public double EffectiveHitpointsViaKinetic
        {
            get
            {
                return ShieldEffectiveHitpointsViaKinetic * ArmorEffectiveHitpointsViaKinetic;
            }
        }

        public double EffectiveHitpointsViaThermal
        {
            get
            {
                return ShieldEffectiveHitpointsViaThermal * ArmorEffectiveHitpointsViaThermal;
            }
        }

        public double ShieldEffectiveHitpointsViaEM
        {
            get
            {
                return ShieldResistanceEm * ShieldHitPoints;
            }
        }

        public double ShieldEffectiveHitpointsViaExplosive
        {
            get
            {
                return ShieldResistanceEm * ShieldHitPoints;
            }
        }

        public double ShieldEffectiveHitpointsViaKinetic
        {
            get
            {
                return ShieldResistanceKinetic * ShieldHitPoints;
            }
        }

        public double ShieldEffectiveHitpointsViaThermal
        {
            get
            {
                return ShieldEffectiveHitpointsViaThermal * ShieldHitPoints;
            }
        }

        public double ArmorEffectiveHitpointsViaEM
        {
            get
            {
                return ArmorResistanceEM * ArmorHitPoints;
            }
        }

        public double ArmorEffectiveHitpointsViaExplosive
        {
            get
            {
                return ArmorResistanceExplosive * ArmorHitPoints;
            }
        }

        public double ArmorEffectiveHitpointsViaKinetic
        {
            get
            {
                return ArmorResistanceKinetic * ArmorHitPoints;
            }
        }

        public double ArmorEffectiveHitpointsViaThermal
        {
            get
            {
                return ArmorResistanceThermal * ArmorHitPoints;
            }
        }

        public int HealthPct
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                        return (int)((ShieldPct + ArmorPct + StructurePct) * 100);

                    return 0;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return 0;
                }
            }
        }

        public int TotalHitpoints
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                        return (int)(ShieldHitPoints + ArmorHitPoints + StructureHitPoints);

                    return 0;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return 0;
                }
            }
        }

        public long Id => _directEntity.Id;

        public bool Exists
        {
            get
            {
                if (ESCache.Instance.Entities != null && ESCache.Instance.Entities.Any(i => i.Id == Id && IsValid && !HasExploded && !HasReleased))
                {
                    return true;
                }

                return false;
            }
        }

        public bool IsAbyssalDeadspaceBioluminesenceCloud
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= GroupId == (int)TypeID.SmallBioluminescenceCloud;
                        result |= GroupId == (int)TypeID.MediumBioluminescenceCloud;
                        result |= GroupId == (int)TypeID.LargeBioluminescenceCloud;

                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceCausticCloud
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= GroupId == (int)TypeID.SmallCausticCloud;
                        result |= GroupId == (int)TypeID.MediumCausticCloud;
                        result |= GroupId == (int)TypeID.LargeCausticCloud;

                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceDeviantAutomataSuppressor
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isAbyssalDeadspaceDeviantAutomataSuppressorTower == null)
                        {
                            bool result = false;
                            result |= GroupId == (int)TypeID.ShortRangeDeviantAutomataSuppressor;
                            result |= GroupId == (int)TypeID.MediumRangeDeviantAutomataSuppressor;

                            _isAbyssalDeadspaceDeviantAutomataSuppressorTower = result;
                            if (DebugConfig.DebugEntityCache)
                                Log.WriteLine("Adding [" + Name + "] to EntityIsAbyssalDeadspaceAoeTowerWeapon as [" + _isAbyssalDeadspaceDeviantAutomataSuppressorTower + "]");
                            return (bool)_isAbyssalDeadspaceDeviantAutomataSuppressorTower;
                        }

                        return (bool)_isAbyssalDeadspaceDeviantAutomataSuppressorTower;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceFilamentCloud
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= GroupId == (int)TypeID.SmallFilamentCloud;
                        result |= GroupId == (int)TypeID.MediumFilamentCloud;
                        result |= GroupId == (int)TypeID.LargeFilamentCloud;

                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceMultibodyTrackingPylon
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isAbyssalDeadspaceMultibodyTrackingPylonTower == null)
                        {
                            bool result = false;
                            result |= GroupId == (int)TypeID.ShortRangeMultibodyTrackingPylon;
                            result |= GroupId == (int)TypeID.MediumRangeMultibodyTrackingPylon;

                            _isAbyssalDeadspaceMultibodyTrackingPylonTower = result;
                            if (DebugConfig.DebugEntityCache)
                                Log.WriteLine("Adding [" + Name + "] to EntityIsAbyssalDeadspaceAoeTowerWeapon as [" + _isAbyssalDeadspaceMultibodyTrackingPylonTower + "]");
                            return (bool)_isAbyssalDeadspaceMultibodyTrackingPylonTower;
                        }

                        return (bool)_isAbyssalDeadspaceMultibodyTrackingPylonTower;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceTriglavianExtractionNode
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isAbyssalDeadspaceTriglavianExtractionNode == null)
                        {
                            _isAbyssalDeadspaceTriglavianExtractionNode = false;

                            if (TypeId == (int)TypeID.AbyssalDeadspaceTriglavianExtractionNode && ESCache.Instance.InAbyssalDeadspace)
                                _isAbyssalDeadspaceTriglavianExtractionNode = true;

                            if (Name == "Triglavian Extraction Node" && ESCache.Instance.InAbyssalDeadspace)
                                _isAbyssalDeadspaceTriglavianExtractionNode = true;

                            return _isAbyssalDeadspaceTriglavianExtractionNode ?? false;
                        }

                        return (bool)_isAbyssalDeadspaceTriglavianExtractionNode;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceTriglavianExtractionNodeReadyToTarget
        {
            get
            {
                try
                {
                    if (!IsAbyssalDeadspaceTriglavianExtractionNode)
                        return false;

                    if (Distance > Salvage.TractorBeamRange + 8000)
                        return false;

                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceTriglavianBioAdaptiveCache
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isAbyssalDeadspaceTriglavianBioAdaptiveCache == null)
                        {
                            _isAbyssalDeadspaceTriglavianBioAdaptiveCache = false;

                            if (TypeId == (int) TypeID.AbyssalDeadspaceTriglavianBioAdaptiveCache && ESCache.Instance.InAbyssalDeadspace)
                                _isAbyssalDeadspaceTriglavianBioAdaptiveCache = true;

                            if (TypeId == (int)TypeID.AbyssalDeadspaceTriglavianBioCombinativeCache && ESCache.Instance.InAbyssalDeadspace)
                                _isAbyssalDeadspaceTriglavianBioAdaptiveCache = true;

                            if (Name == "Triglavian BioAdaptive Cache" && ESCache.Instance.InAbyssalDeadspace)
                                _isAbyssalDeadspaceTriglavianBioAdaptiveCache = true;

                            if (Name == "Triglavian Biocombinative Cache" && ESCache.Instance.InAbyssalDeadspace)
                                _isAbyssalDeadspaceTriglavianBioAdaptiveCache = true;

                            return _isAbyssalDeadspaceTriglavianBioAdaptiveCache ?? false;
                        }

                        return (bool)_isAbyssalDeadspaceTriglavianBioAdaptiveCache;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAbyssalDeadspaceTriglavianBioAdaptiveCacheReadyToTarget
        {
            get
            {
                try
                {
                    if (!IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                        return false;

                    if (Distance > Salvage.TractorBeamRange + 8000)
                        return false;

                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public bool IsAbyssalPrecursorCache
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isAbyssalPrecursorCache == null)
                        {
                            bool result = false;
                            result |= GroupId == (int)Group.AbyssalPrecursorCache && ESCache.Instance.InAbyssalDeadspace;
                            _isAbyssalPrecursorCache = result;
                            if (DebugConfig.DebugEntityCache)
                                Log.WriteLine("Adding [" + Name + "] to EntityIsAbyssalDeadspaceAoeTowerWeapon as [" + _isAbyssalPrecursorCache + "]");
                            return (bool)_isAbyssalPrecursorCache;
                        }

                        return (bool)_isAbyssalPrecursorCache;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsMobileTractor
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (GroupId == (int)Group.MobileTractor)
                    {
                        return true;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool IsInTractorRange
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Salvage.TractorBeams != null && !Salvage.TractorBeams.Any())
                            return true; //If used for targeting in AbyssalDeadspace we want to target it if we dont have any tractors

                        if (Salvage.TractorBeamRange != null && Salvage.TractorBeamRange > Distance)
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception)
                {
                    return true;
                }
            }
        }

        public bool IsAccelerationGate => _directEntity.IsAccelerationGate;

        public DronePriority IsActiveDroneEwarType
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (IsWarpScramblingMe)
                            return DronePriority.WarpScrambler;

                        if (IsWebbingMe)
                            return DronePriority.Webbing;

                        if (IsNeutralizingMe)
                            return DronePriority.PriorityKillTarget;

                        if (IsJammingMe)
                            return DronePriority.PriorityKillTarget;

                        if (IsSensorDampeningMe)
                            return DronePriority.PriorityKillTarget;

                        if (IsTargetPaintingMe)
                            return DronePriority.PriorityKillTarget;

                        if (IsTrackingDisruptingMe)
                            return DronePriority.PriorityKillTarget;

                        return DronePriority.NotUsed;
                    }

                    return DronePriority.NotUsed;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return DronePriority.NotUsed;
                }
            }
        }

        public bool IsActiveTarget => _directEntity.IsActiveTarget;

        public bool IsAnyOtherUnTargetedHighValueTargetInOptimal
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (Combat.PotentialCombatTargets != null && Combat.PotentialCombatTargets.Any())
                    {
                        if (Combat.PotentialCombatTargets.Any(i => !i.IsTarget && !i.IsTargeting && IsHighValueTarget && i.IsInOptimalRange && i.IsTrackable))
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool IsAnyOtherUnTargetedLowValueTargetInOptimal
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (Combat.PotentialCombatTargets != null && Combat.PotentialCombatTargets.Any())
                    {
                        if (Combat.PotentialCombatTargets.Any(i => !i.IsTarget && !i.IsTargeting && IsLowValueTarget && i.IsInOptimalRange && i.IsTrackable))
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool IsApproachedByActiveShip => _directEntity.IsApproachedOrKeptAtRangeByActiveShip;

        public bool IsApproaching => _directEntity.IsApproachingOrKeptAtRange;

        public bool IsAsteroid
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= CategoryId == (int)CategoryID.Asteroid;
                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAsteroidBelt
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= GroupId == (int)Group.AsteroidBelt;
                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsAttacking => _directEntity.IsAttacking;

        public bool IsBadIdea
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_IsBadIdea == null)
                        {
                            if (IsInMyEveSharpFleet)
                                return true;

                            if (ESCache.Instance.MyFleetMembersAsEntities.Any(i => i.Id == Id))
                                return true;

                            if (State.CurrentHydraState == HydraState.Combat)
                                return false;

                            bool result = false;
                            if (ESCache.Instance.InAbyssalDeadspace)
                                if (IsNPCDrone)
                                    return true;

                            result |= GroupId == (int)Group.ConcordDrone;
                            result |= GroupId == (int)Group.PoliceDrone;
                            result |= GroupId == (int)Group.CustomsOfficial;
                            result |= GroupId == (int)Group.Billboard;
                            result |= GroupId == (int)Group.Stargate;
                            result |= GroupId == (int)Group.Station;
                            result |= GroupId == (int)Group.Citadel;
                            result |= GroupId == (int)Group.SentryGun;
                            result |= GroupId == (int)Group.MissionContainer;
                            result |= GroupId == (int)Group.CustomsOffice;
                            result |= GroupId == (int)Group.GasCloud;
                            result |= GroupId == (int)Group.ConcordBillboard;

                            if (ESCache.Instance.InWormHoleSpace)
                                return false;

                            result |= GroupId == (int)Group.Capsule;
                            result |= IsPlayer;
                            _IsBadIdea = result;
                            if (DebugConfig.DebugEntityCache)
                                Log.WriteLine("Adding [" + Name + "] to EntityIsBadIdea as [" + _IsBadIdea + "]");
                            return (bool)_IsBadIdea;
                        }

                        return (bool)_IsBadIdea;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsBattlecruiser => _directEntity.IsBattlecruiser;

        public bool IsBattleship => _directEntity.IsBattleship;

        public bool IsCelestial
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= CategoryId == (int)CategoryID.Celestial;
                        result |= CategoryId == (int)CategoryID.Station;
                        result |= GroupId == (int)Group.Moon;
                        result |= GroupId == (int)Group.AsteroidBelt;
                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsWithinOptimalOfDrones
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (!ESCache.Instance.InSpace)
                            return false;

                        if (Drones.ActiveDrones == null || !Drones.ActiveDrones.Any())
                            return false;

                        if (6000 > DistanceFromEntity(Drones.ActiveDrones.FirstOrDefault()))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public bool IsCloseToDrones
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (!ESCache.Instance.InSpace)
                            return false;

                        if (Drones.ActiveDrones == null || !Drones.ActiveDrones.Any())
                            return false;

                        if (10000 > DistanceFromEntity(Drones.ActiveDrones.FirstOrDefault()))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public bool IsContainer => _directEntity.IsContainer;

        public bool IsCorrectSizeForMyWeapons
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isCorrectSizeForMyWeapons == null)
                        {
                            if (Drones.DronesKillHighValueTargets)
                            {
                                if (IsFrigate)
                                    return false;

                                return true;
                            }

                            if (ESCache.Instance.MyShipEntity.IsFrigate)
                                if (IsFrigate || IsNPCFrigate)
                                {
                                    _isCorrectSizeForMyWeapons = true;
                                    return (bool)_isCorrectSizeForMyWeapons;
                                }

                            if (ESCache.Instance.MyShipEntity.IsCruiser)
                                if (IsCruiser || IsNPCCruiser)
                                {
                                    _isCorrectSizeForMyWeapons = true;
                                    return (bool)_isCorrectSizeForMyWeapons;
                                }

                            if (ESCache.Instance.MyShipEntity.IsBattlecruiser || ESCache.Instance.MyShipEntity.IsBattleship)
                                if (IsBattleship || IsBattlecruiser || IsNPCBattlecruiser || IsNPCBattleship)
                                {
                                    _isCorrectSizeForMyWeapons = true;
                                    return (bool)_isCorrectSizeForMyWeapons;
                                }

                            return false;
                        }

                        return (bool)_isCorrectSizeForMyWeapons;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                }

                return false;
            }
        }

        public bool IsCruiser => _directEntity.IsCruiser;

        public bool IsCurrentTarget => Combat.CurrentWeaponTarget() == this;

        public bool IsCustomsOffice
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= GroupId == (int)Group.CustomsOffice;
                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsDronePriorityTarget
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Drones.DronePriorityTargets.All(i => i.EntityID != Id))
                            return false;

                        return true;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsEntityIShouldKeepShooting
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isEntityIShouldKeepShooting == null)
                        {
                            if (IsReadyToShoot
                                && IsInOptimalRange && !IsLargeCollidable
                                && (!IsFrigate && !IsNPCFrigate || !IsTooCloseTooFastTooSmallToHit)
                                && ArmorPct * 100 < Combat.DoNotSwitchTargetsIfTargetHasMoreThanThisArmorDamagePercentage)
                            {
                                if (DebugConfig.DebugGetBestTarget)
                                    Log.WriteLine("[" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" + MaskedId + " GroupID [" + GroupId +
                                                  "]] has less than 60% armor, keep killing this target");
                                _isEntityIShouldKeepShooting = true;
                                return (bool)_isEntityIShouldKeepShooting;
                            }

                            _isEntityIShouldKeepShooting = false;
                            return (bool)_isEntityIShouldKeepShooting;
                        }

                        return (bool)_isEntityIShouldKeepShooting;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception: [" + ex + "]");
                }

                return false;
            }
        }

        public bool IsEntityIShouldKeepShootingWithDrones
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isEntityIShouldKeepShootingWithDrones == null)
                        {
                            if (IsReadyForDronesToShoot
                                && IsInDroneRange
                                && !IsLargeCollidable
                                && (IsFrigate || IsNPCFrigate || Drones.DronesKillHighValueTargets)
                                && ShieldPct * 100 < 80)
                            {
                                if (DebugConfig.DebugGetBestTarget)
                                    Log.WriteLine("[" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" + MaskedId + " GroupID [" + GroupId +
                                                  "]] has less than 60% armor, keep killing this target");
                                _isEntityIShouldKeepShootingWithDrones = true;
                                return (bool)_isEntityIShouldKeepShootingWithDrones;
                            }

                            _isEntityIShouldKeepShootingWithDrones = false;
                            return (bool)_isEntityIShouldKeepShootingWithDrones;
                        }

                        return (bool)_isEntityIShouldKeepShootingWithDrones;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception: [" + ex + "]");
                }

                return false;
            }
        }

        public bool IsEntityIShouldLeaveAlone => _directEntity.IsEntityIShouldLeaveAlone;

        public bool IsEwarImmune => _directEntity.IsEwarImmune;

        public bool IsEwarTarget => _directEntity.IsEwarTarget;

        public bool KillSentries
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsSentry && IsPrimaryWeaponPriorityTarget)
                        return true;

                    if (IsSentry && IsDronePriorityTarget)
                        return true;

                    if (Combat.KillSentries)
                        return true;

                    return false;
                }

                return false;
            }
        }

        public bool IsFactionWarfareNPC => _directEntity.IsFactionWarfareNPC;

        public bool IsFrigate => _directEntity.IsFrigate;

        public bool IsHigherPriorityPresent
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isHigherPriorityPresent == null)
                            if (Combat.PrimaryWeaponPriorityTargets.Any() || Drones.DronePriorityTargets.Any())
                            {
                                if (Combat.PrimaryWeaponPriorityTargets.Any())
                                {
                                    if (Combat.PrimaryWeaponPriorityTargets.Any(pt => pt.EntityID == Id))
                                    {
                                        PrimaryWeaponPriority _currentPrimaryWeaponPriority =
                                            Combat.PrimaryWeaponPriorityEntities.Where(t => t.Id == _directEntity.Id)
                                                .Select(pt => pt.PrimaryWeaponPriorityLevel)
                                                .FirstOrDefault();

                                        if (
                                            !Combat.PrimaryWeaponPriorityEntities.All(
                                                pt => pt.PrimaryWeaponPriorityLevel < _currentPrimaryWeaponPriority && pt.Distance < Combat.MaxRange))
                                        {
                                            _isHigherPriorityPresent = true;
                                            return (bool)_isHigherPriorityPresent;
                                        }

                                        _isHigherPriorityPresent = false;
                                        return (bool)_isHigherPriorityPresent;
                                    }

                                    if (Combat.PrimaryWeaponPriorityEntities.Any(e => e.Distance < Combat.MaxRange))
                                    {
                                        _isHigherPriorityPresent = true;
                                        return (bool)_isHigherPriorityPresent;
                                    }

                                    _isHigherPriorityPresent = false;
                                    return (bool)_isHigherPriorityPresent;
                                }

                                if (Drones.DronePriorityTargets.Any())
                                {
                                    if (Drones.DronePriorityTargets.Any(pt => pt.EntityID == _directEntity.Id))
                                    {
                                        DronePriority _currentEntityDronePriority =
                                            Drones.DronePriorityEntities.Where(t => t.Id == _directEntity.Id)
                                                .Select(pt => pt.DronePriorityLevel)
                                                .FirstOrDefault();

                                        if (
                                            !Drones.DronePriorityEntities.All(
                                                pt => pt.DronePriorityLevel < _currentEntityDronePriority && pt.Distance < Drones.MaxDroneRange))
                                            return true;

                                        return false;
                                    }

                                    if (Drones.DronePriorityEntities.Any(e => e.Distance < Drones.MaxDroneRange))
                                    {
                                        _isHigherPriorityPresent = true;
                                        return (bool)_isHigherPriorityPresent;
                                    }

                                    _isHigherPriorityPresent = false;
                                    return (bool)_isHigherPriorityPresent;
                                }

                                _isHigherPriorityPresent = false;
                                return (bool)_isHigherPriorityPresent;
                            }

                        return _isHigherPriorityPresent ?? false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsHighValueTargetThatIsTargeted
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (!IsLowValueTarget && (IsTarget || IsTargeting))
                        return true;

                    return false;
                }

                return false;
            }
        }

        public bool IsHighValueTarget
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isHighValueTarget == null)
                        {
                            if (ESCache.Instance.EntityIsHighValueTarget.Any() && ESCache.Instance.EntityIsHighValueTarget.Count() > DictionaryCountThreshhold)
                                if (DebugConfig.DebugEntityCache)
                                    Log.WriteLine("We have [" + ESCache.Instance.EntityIsHighValueTarget.Count() +
                                                  "] Entities in Cache.Instance.EntityIsHighValueTarget");

                            if (ESCache.Instance.EntityIsHighValueTarget.Any())
                            {
                                bool value;
                                if (ESCache.Instance.EntityIsHighValueTarget.TryGetValue(Id, out value))
                                {
                                    _isHighValueTarget = value;
                                    return (bool)_isHighValueTarget;
                                }
                            }

                            if (TargetValue != null)
                            {
                                if (!IsIgnored && !IsContainer && !IsBadIdea && !IsCustomsOffice && !IsFactionWarfareNPC && !IsPlayer)
                                    if (TargetValue >= Combat.MinimumTargetValueToConsiderTargetAHighValueTarget)
                                    {
                                        if (IsSentry && !KillSentries && !IsEwarTarget)
                                        {
                                            _isHighValueTarget = false;
                                            if (DebugConfig.DebugEntityCache)
                                                Log.WriteLine("Adding [" + Name + "] to EntityIsHighValueTarget as [" + _isHighValueTarget + "]");
                                            return (bool)_isHighValueTarget;
                                        }

                                        _isHighValueTarget = true;
                                        if (DebugConfig.DebugEntityCache)
                                            Log.WriteLine("Adding [" + Name + "] to EntityIsHighValueTarget as [" + _isHighValueTarget + "]");
                                        ESCache.Instance.EntityIsHighValueTarget.Add(Id, (bool)_isHighValueTarget);
                                        return (bool)_isHighValueTarget;
                                    }

                                _isHighValueTarget = false;
                                return (bool)_isHighValueTarget;
                            }


                            _isHighValueTarget = false;
                            if (IsNPCBattleship || IsNPCBattlecruiser)
                                _isHighValueTarget = true;

                            if (IsNPCCruiser && ESCache.Instance.EntitiesOnGrid.All(i => !i.IsNPCBattleship && !i.IsNPCBattlecruiser))
                                _isHighValueTarget = true;

                            if (DebugConfig.DebugEntityCache)
                                Log.WriteLine("Adding [" + Name + "] to EntityIsHighValueTarget as [" + _isHighValueTarget + "]");
                            ESCache.Instance.EntityIsHighValueTarget.Add(Id, (bool)_isHighValueTarget);
                            return (bool)_isHighValueTarget;
                        }

                        return (bool)_isHighValueTarget;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsIgnored
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (IsWarpScramblingMe) return false;

                        if (_isIgnored == null)
                        {
                            if (ActionControl.IgnoreTargets != null && ActionControl.IgnoreTargets.Any())
                            {
                                _isIgnored = ActionControl.IgnoreTargets.Contains(Name.Trim());
                                if ((bool)_isIgnored)
                                {
                                    if (Combat.PreferredPrimaryWeaponTarget != null && Combat.PreferredPrimaryWeaponTarget.Id != Id)
                                        Combat.PreferredPrimaryWeaponTarget = null;

                                    if (ESCache.Instance.EntityIsLowValueTarget.ContainsKey(Id))
                                        ESCache.Instance.EntityIsLowValueTarget.Remove(Id);

                                    if (ESCache.Instance.EntityIsHighValueTarget.ContainsKey(Id))
                                        ESCache.Instance.EntityIsHighValueTarget.Remove(Id);

                                    if (DebugConfig.DebugEntityCache)
                                        Log.WriteLine("[" + Name + "][" + Math.Round(Distance / 1000, 0) + "k][" + MaskedId + "] isIgnored [" +
                                                      _isIgnored +
                                                      "]");
                                    return (bool)_isIgnored;
                                }

                                if (IsSentry && !KillSentries)
                                    return true;

                                _isIgnored = false;
                                if (DebugConfig.DebugEntityCache)
                                    Log.WriteLine("[" + Name + "][" + Math.Round(Distance / 1000, 0) + "k][" + MaskedId + "] isIgnored [" + _isIgnored +
                                                  "]");
                                return (bool)_isIgnored;
                            }

                            _isIgnored = false;
                            if (DebugConfig.DebugEntityCache)
                                Log.WriteLine("[" + Name + "][" + Math.Round(Distance / 1000, 0) + "k][" + MaskedId + "] isIgnored [" + _isIgnored + "]");
                            return (bool)_isIgnored;
                        }

                        if (DebugConfig.DebugEntityCache)
                            Log.WriteLine("[" + Name + "][" + Math.Round(Distance / 1000, 0) + "k][" + MaskedId + "] isIgnored [" + _isIgnored + "]");
                        return (bool)_isIgnored;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsInDroneRange
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Drones.MaxDroneRange > 0)
                        {
                            if (Distance < Drones.MaxDroneRange)
                                return true;

                            return false;
                        }

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsInRangeOfWeapons
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Combat.MaxWeaponRange > 0)
                        {
                            if (Combat.MaxWeaponRange > Distance)
                                return true;

                            return false;
                        }

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsInMyEveSharpFleet
        {
            get
            {
                if (ESCache.Instance.EveAccount.LeaderCharacterName == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName1 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName2 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName3 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName4 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName5 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName6 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName7 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName8 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName9 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName10 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName11 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName12 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName13 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName14 == Name)
                    return true;

                if (ESCache.Instance.EveAccount.SlaveCharacterName15 == Name)
                    return true;

                return false;
            }
        }

        public bool IsInMyRepairGroup
        {
            get
            {
                if (IsInMyEveSharpFleet)
                {
                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (ESCache.Instance.MyCorpMatesAsEntities.Any(i => i.Id == Id) || IsInMyEveSharpFleet)");
                    if (string.IsNullOrEmpty(ESCache.Instance.EveAccount.RepairGroup))
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (string.IsNullOrEmpty(ESCache.Instance.EveAccount.RepairGroup))");
                        return false;
                    }

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.LeaderCharacterName))
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter1RepairGroup))");
                        if (ESCache.Instance.EveAccount.LeaderCharacterName == Name)
                        {
                            if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (ESCache.Instance.EveAccount.SlaveCharacterName1 == Name)");
                            if (ESCache.Instance.EveAccount.LeaderRepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                            {
                                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (ESCache.Instance.EveAccount.SlaveCharacter1RepairGroup == ESCache.Instance.EveAccount.RepairGroup)");
                                return true;
                            }
                        }
                    }


                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter1RepairGroup))
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter1RepairGroup))");
                        if (ESCache.Instance.EveAccount.SlaveCharacterName1 == Name)
                        {
                            if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (ESCache.Instance.EveAccount.SlaveCharacterName1 == Name)");
                            if (ESCache.Instance.EveAccount.SlaveCharacter1RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                            {
                                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (ESCache.Instance.EveAccount.SlaveCharacter1RepairGroup == ESCache.Instance.EveAccount.RepairGroup)");
                                return true;
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter2RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName2 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter2RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter3RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName3 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter3RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter4RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName4 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter4RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter5RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName5 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter5RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter6RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName6 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter6RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter7RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName7 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter7RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter8RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName8 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter8RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter9RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName9 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter9RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter10RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName10 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter10RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter11RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName11 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter11RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter12RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName12 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter12RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter13RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName13 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter13RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter14RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName14 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter14RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    if (!string.IsNullOrEmpty(ESCache.Instance.EveAccount.SlaveCharacter15RepairGroup) &&
                        ESCache.Instance.EveAccount.SlaveCharacterName15 == Name &&
                        ESCache.Instance.EveAccount.SlaveCharacter15RepairGroup == ESCache.Instance.EveAccount.RepairGroup)
                        return true;

                    return false;
                }

                return false;
            }
        }

        public bool IsInOptimalRange
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isInOptimalRange == null)
                        {
                            if (Drones.DronesKillHighValueTargets)
                                if (IsInDroneRange)
                                    return true;

                            if (ESCache.Instance.Weapons.Any())
                            {
                                if (Combat.DoWeCurrentlyProjectilesMounted())
                                    try
                                    {
                                        if (IsTrackable)
                                        {
                                            if (Distance < ESCache.Instance.Weapons.FirstOrDefault().OptimalRange + ESCache.Instance.Weapons.FirstOrDefault().FallOff * .75 && Distance < Combat.MaxRange)
                                            {
                                                _isInOptimalRange = true;
                                                return (bool)_isInOptimalRange;
                                            }

                                            return false;
                                        }

                                        return false;
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLine("Exception [" + ex + "]");
                                        return false;
                                    }

                                if (Combat.DoWeCurrentlyHaveTurretsMounted())
                                    try
                                    {
                                        if (IsTrackable)
                                        {
                                            if (Distance < ESCache.Instance.Weapons.FirstOrDefault().OptimalRange && Distance < Combat.MaxRange)
                                            {
                                                _isInOptimalRange = true;
                                                return (bool)_isInOptimalRange;
                                            }

                                            return false;
                                        }

                                        return false;
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.WriteLine("Exception [" + ex + "]");
                                        return false;
                                    }

                                try
                                {
                                    //
                                    // this has to be missiles, if its in range its in optimalrange
                                    //
                                    if (Distance < Combat.MaxRange)
                                    {
                                        _isInOptimalRange = true;
                                        return (bool)_isInOptimalRange;
                                    }

                                    _isInOptimalRange = false;
                                    return (bool)_isInOptimalRange;
                                }
                                catch (Exception ex)
                                {
                                    Log.WriteLine("Exception [" + ex + "]");
                                    return false;
                                }
                            }

                            _isInOptimalRange = false;
                            return (bool)_isInOptimalRange;
                        }

                        return (bool)_isInOptimalRange;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsInOptimalRangeOrNothingElseAvail
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (IsInOptimalRange)
                            return true;

                        //
                        // this is used by the targeting routine to determine what to target!
                        //
                        if (!IsTarget && !IsContainer)
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        /**
        public bool IsInRangeOfAnAbyssalCausticCloud
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isInRangeOfAnAbyssalCloud == null)
                        {
                            if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsAbyssalDeadspaceCausticCloud && i.DistanceFromEntity(this) < i.OptimalRange))
                            {
                                _isInRangeOfAnAbyssalCloud = true;
                                return (bool) _isInRangeOfAnAbyssalCloud;
                            }

                            _isInRangeOfAnAbyssalCloud = false;
                            return (bool) _isInRangeOfAnAbyssalCloud;
                        }

                        return (bool) _isInRangeOfAnAbyssalCloud;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }
        **/
        /**
        public bool IsInRangeOfAnAbyssalTower
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isInRangeOfAnAbyssalTower == null)
                        {
                            if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsAbyssalDeadspaceAoeTowerWeapon && i.DistanceFromEntity(this) < i.OptimalRange))
                            {
                                _isInRangeOfAnAbyssalTower = true;
                                return (bool) _isInRangeOfAnAbyssalTower;
                            }

                            _isInRangeOfAnAbyssalTower = false;
                            return (bool) _isInRangeOfAnAbyssalTower;
                        }

                        return (bool) _isInRangeOfAnAbyssalTower;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }
        **/
        /**
        public PrimaryWeaponPriority IsActivePrimaryWeaponEwarType
        {
            get
            {
                try
                {
                    if (IsWarpScramblingMe)
                        return PrimaryWeaponPriority.WarpScrambler;

                    if (IsWebbingMe)
                        return PrimaryWeaponPriority.Webbing;

                    if (IsNeutralizingMe)
                        return PrimaryWeaponPriority.Neutralizing;

                    if (IsJammingMe)
                        return PrimaryWeaponPriority.Jamming;

                    if (IsSensorDampeningMe)
                        return PrimaryWeaponPriority.Dampening;

                    if (IsTargetPaintingMe)
                        return PrimaryWeaponPriority.TargetPainting;

                    if (IsTrackingDisruptingMe)
                        return PrimaryWeaponPriority.TrackingDisrupting;

                    return PrimaryWeaponPriority.NotUsed;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return PrimaryWeaponPriority.NotUsed;
                }
            }
        }
        **/

        public bool IsInWebRange
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (ESCache.Instance.Modules.Any(i => i.GroupId == (int)Group.StasisWeb))
                        {
                            ModuleCache web = ESCache.Instance.Modules.FirstOrDefault(i => i.GroupId == (int)Group.StasisWeb);
                            if (Distance > web.MaxRange)
                                return false;

                            return true;
                        }

                        //
                        // if we dont have any webs rturn true!
                        //
                        return true;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsJammingMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_directEntity.ElectronicWarfare.Contains("electronic"))
                        {
                            if (!ESCache.Instance.ListOfJammingEntities.Contains(Id)) ESCache.Instance.ListOfJammingEntities.Add(Id);
                            return true;
                        }

                        if (ESCache.Instance.ListOfJammingEntities.Contains(Id))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsLargeCollidable => _directEntity.IsLargeCollidable;

        public bool IsLargeCollidableWeAlwaysWantToBlowupLast
        {
            get
            {
                if (_directEntity.IsLargeCollidable)
                {
                    if (ESCache.Instance.InMission && MissionSettings.MyMission != null)
                    {
                        if (MissionSettings.MyMission.Name.Contains("In the Midst of Deadspace (3 of 5)") && Name.ToLower() == "EM Forcefield".ToLower())
                            return true;

                        if (MissionSettings.MyMission.Name.Contains("In the Midst of Deadspace (3 of 5)") && Name.ToLower() == "Imperial Armory".ToLower() && ESCache.Instance.EntitiesOnGrid.All(i => i.Name.ToLower() != "EM Forecefield".ToLower()))
                            return true;

                        if (MissionSettings.MyMission.Name.Contains("In the Midst of Deadspace (4 of 5)") && Name.ToLower() == "Imperial Stargate".ToLower())
                            return true;

                        if (MissionSettings.MyMission.Name.Contains("In the Midst of Deadspace (5 of 5)") && Name.ToLower() == "Caldari Manufacturing Plant".ToLower())
                            return true;

                    }

                    return false;
                }

                return false;
            }
        }

        public bool IsLargeCollidableWeAlwaysWantToBlowupFirst
        {
            get
            {
                if (GroupId == (int)Group.DeadSpaceOverseersStructure || GroupId == (int)Group.DeadSpaceOverseersBelongings)
                {
                    if (ESCache.Instance.InMission && MissionSettings.MyMission != null)
                    {
                        if (MissionSettings.MyMission.Name.ToLower().Contains("Shipyard Theft".ToLower()) && Name == "Silo")
                            return true;
                    }
                }

                if (_directEntity.IsLargeCollidable)
                {
                    if (ESCache.Instance.InMission && MissionSettings.MyMission != null)
                    {
                        //if (MissionSettings.MyMission.Name.ToLower().Contains("RandomMissionNameHere".ToLower()) && Name == "ItemToBlowUp")
                        //    return true;
                    }
                }

                return false;
            }
        }



        public bool IsDecloakedTransmissionRelay => _directEntity.IsDecloakedTransmissionRelay;
        public bool IsLargeWreck => _directEntity.IsLargeWreck;

        public bool IsEntityDronesAreShooting
        {
            get
            {
                if (Drones.ActiveDrones.Any(i => i.FollowId == Id))
                    return true;

                return false;
            }

        }

        public bool IsLastTargetDronesWereShooting
        {
            get
            {
                if (Drones.ActiveDrones.Any(i => i.IsEntityDronesAreShooting))
                    if (Drones.ActiveDrones.Where(i => i.IsEntityDronesAreShooting).FirstOrDefault().Name == Name)
                    {
                        if (IsEntityDronesAreShooting)
                            return true;

                        return false;
                    }

                if (Drones.LastTargetIDDronesEngaged != null && Id == Drones.LastTargetIDDronesEngaged)
                    return true;

                return false;
            }

        }
        public bool IsLastTargetPrimaryWeaponsWereShooting => Combat.LastTargetPrimaryWeaponsWereShooting != null && Id == Combat.LastTargetPrimaryWeaponsWereShooting.Id;

        public bool IsLootTarget => ESCache.Instance.ListofContainersToLoot.Contains(Id);

        public bool IsLowValueTargetThatIsTargeted
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsLowValueTarget && (IsTarget || IsTargeting))
                        return true;

                    return false;
                }

                return false;
            }
        }

        public bool IsLowValueTarget
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isLowValueTarget == null)
                        {
                            if (ESCache.Instance.EntityIsLowValueTarget.Any() && ESCache.Instance.EntityIsLowValueTarget.Count() > DictionaryCountThreshhold)
                                if (DebugConfig.DebugEntityCache)
                                    Log.WriteLine("We have [" + ESCache.Instance.EntityIsLowValueTarget.Count() +
                                                  "] Entities in Cache.Instance.EntityIsLowValueTarget");

                            if (ESCache.Instance.EntityIsLowValueTarget.Any())
                            {
                                bool value;
                                if (ESCache.Instance.EntityIsLowValueTarget.TryGetValue(Id, out value))
                                {
                                    _isLowValueTarget = value;
                                    return (bool)_isLowValueTarget;
                                }
                            }

                            if (!IsIgnored && !IsContainer && !IsBadIdea && !IsCustomsOffice && !IsFactionWarfareNPC && !IsPlayer)
                            {
                                if (TargetValue != null && TargetValue <= Combat.MaximumTargetValueToConsiderTargetALowValueTarget)
                                {
                                    if (IsSentry && !KillSentries && !IsEwarTarget)
                                    {
                                        _isLowValueTarget = false;
                                        if (DebugConfig.DebugEntityCache)
                                            Log.WriteLine("Adding [" + Name + "] to EntityIsLowValueTarget as [" + _isLowValueTarget + "]");
                                        return (bool)_isLowValueTarget;
                                    }

                                    if (TargetValue < 0 && Velocity == 0)
                                    {
                                        _isLowValueTarget = false;
                                        if (DebugConfig.DebugEntityCache)
                                            Log.WriteLine("Adding [" + Name + "] to EntityIsLowValueTarget as [" + _isLowValueTarget + "]");
                                        return (bool)_isLowValueTarget;
                                    }

                                    _isLowValueTarget = true;
                                    if (DebugConfig.DebugEntityCache)
                                        Log.WriteLine("Adding [" + Name + "] to EntityIsLowValueTarget as [" + _isLowValueTarget + "]");
                                    ESCache.Instance.EntityIsLowValueTarget.Add(Id, (bool)_isLowValueTarget);
                                    return (bool)_isLowValueTarget;
                                }

                                _isLowValueTarget = false;
                                if (DebugConfig.DebugEntityCache)
                                    Log.WriteLine("Adding [" + Name + "] to EntityIsLowValueTarget as [" + _isLowValueTarget + "]");
                                return (bool)_isLowValueTarget;
                            }

                            _isLowValueTarget = false;
                            return (bool)_isLowValueTarget;
                        }

                        return (bool)_isLowValueTarget;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsMediumWreck => _directEntity.IsMediumWreck;

        public bool IsMiscJunk => _directEntity.IsMiscJunk;

        public bool IsNeutralizingMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_directEntity.ElectronicWarfare.Contains("ewEnergyNeut"))
                        {
                            if (!ESCache.Instance.ListNeutralizingEntities.Contains(Id)) ESCache.Instance.ListNeutralizingEntities.Add(Id);
                            return true;
                        }

                        if (ESCache.Instance.ListNeutralizingEntities.Contains(Id))
                            return true;

                        if (ESCache.Instance.InAbyssalDeadspace && (Name.Contains("Starving") || Name.Contains("Nullcharge") || Name.Contains("Dissipator") || Name.Contains("Firewatcher") || Name.Contains("Sentinel")))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsNotYetTargetingMeAndNotYetTargeted
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= (IsNpc || IsNpcByGroupID) && !IsTargeting && !IsTarget && !IsContainer && CategoryId == (int)CategoryID.Entity &&
                                  Distance < Combat.MaxTargetRange && !IsIgnored && !IsBadIdea && !IsTargetedBy && !IsEntityIShouldLeaveAlone &&
                                  !IsFactionWarfareNPC && !IsLargeCollidable && !IsStation;

                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        private bool? _isEntityEngagedByMyOtherToons = null;

        public bool IsEntityEngagedByMyOtherToons
        {
            get
            {
                if (_isEntityEngagedByMyOtherToons == null)
                {
                    if (ESCache.Instance.EveAccount.EntityIdsEngagedByOthers.Any())
                    {
                        foreach (long entityIdEngagedByOthers in ESCache.Instance.EveAccount.EntityIdsEngagedByOthers)
                        {
                            if (entityIdEngagedByOthers == Id)
                            {
                                _isEntityEngagedByMyOtherToons = true;
                                return (bool)_isEntityEngagedByMyOtherToons;
                            }
                        }

                        _isEntityEngagedByMyOtherToons = false;
                        return (bool)_isEntityEngagedByMyOtherToons;
                    }

                    _isEntityEngagedByMyOtherToons = false;
                    return (bool)_isEntityEngagedByMyOtherToons;
                }

                return (bool)_isEntityEngagedByMyOtherToons;
            }
        }

        public bool IsNpc => _directEntity.IsNpc;

        public bool IsNPCBattlecruiser => _directEntity.IsNPCBattlecruiser;

        public bool IsNpcCapitalEscalation => _directEntity.IsNpcCapitalEscalation;

        public bool IsNPCWormHoleSpaceDrifter => Name.Contains("Arithmos Tyrannos");
        public bool IsNPCBattleship => _directEntity.IsNPCBattleship;

        public bool IsNpcByGroupID => _directEntity.IsNpcByGroupID;
        public bool IsNPCCapitalShip => _directEntity.IsNPCCapitalShip;

        public bool IsNPCCruiser => _directEntity.IsNPCCruiser;

        public bool IsNPCDrone => _directEntity.IsNPCDrone;

        public bool IsNPCFrigate => _directEntity.IsNPCFrigate;

        public bool IsOnGridWithMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isOnGridWithMe == null)
                        {
                            if (Distance < (double)Distances.OnGridWithMe)
                            {
                                _isOnGridWithMe = true;
                                return (bool)_isOnGridWithMe;
                            }

                            _isOnGridWithMe = false;
                            return (bool)_isOnGridWithMe;
                        }

                        return (bool)_isOnGridWithMe;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsOrbitedByActiveShip => _directEntity.IsOrbitedByActiveShip;

        public bool IsOrbiting => _directEntity.IsOrbiting;

        public bool IsOreOrIce
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= GroupId == (int)Group.Plagioclase;
                        result |= GroupId == (int)Group.Spodumain;
                        result |= GroupId == (int)Group.Kernite;
                        result |= GroupId == (int)Group.Hedbergite;
                        result |= GroupId == (int)Group.Arkonor;
                        result |= GroupId == (int)Group.Bistot;
                        result |= GroupId == (int)Group.Pyroxeres;
                        result |= GroupId == (int)Group.Crokite;
                        result |= GroupId == (int)Group.Jaspet;
                        result |= GroupId == (int)Group.Omber;
                        result |= GroupId == (int)Group.Scordite;
                        result |= GroupId == (int)Group.Gneiss;
                        result |= GroupId == (int)Group.Veldspar;
                        result |= GroupId == (int)Group.Hemorphite;
                        result |= GroupId == (int)Group.DarkOchre;
                        result |= GroupId == (int)Group.Ice;
                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsMiner
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (!IsPlayer)
                        return false;

                    if (TypeId == (int)TypeID.Venture)
                        return true;

                    if (GroupId == (int)Group.MiningBarge)
                        return true;

                    if (GroupId == (int)Group.Exhumer)
                        return true;

                    if (GroupId == (int)Group.BlockadeRunner)
                        return true;

                    if (GroupId == (int)Group.TransportShip)
                        return true;

                    if (GroupId == (int)Group.Industrial)
                        return true;

                    return _directEntity.IsPlayer;
                }

                return false;
            }
        }

        public bool IsPlayer
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (ESCache.Instance.InAbyssalDeadspace) //Can we detect the proving grounds by the gates available?
                        return false;

                    if (GroupId == (int)Group.AbyssalSpaceshipEntities)
                        return false;

                    if (GroupId == (int)Group.AbyssalDeadspaceDroneEntities)
                        return false;

                    if (GroupId == (int)Group.InvadingPrecursorEntities)
                        return false;

                    return _directEntity.IsPlayer;
                }

                return false;
            }
        }

        public bool IsPotentialCombatTarget
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (Combat.PotentialCombatTargets != null && Combat.PotentialCombatTargets.Any())
                        return Combat.PotentialCombatTargets.Any(i => i.Id == Id);

                    return false;
                }

                return false;
            }
        }

        public bool IsPotentialNinjaLooter
        {
            get
            {
                if (CategoryId == (int)CategoryID.Ship)
                {
                    if (GroupId == (int)Group.Titan)
                        return false;

                    //if (GroupId == (int)Group.Carrier)
                    //    return false;

                    if (GroupId == (int)Group.Carrier)
                        return false;

                    if (GroupId == (int)Group.Dreadnaught)
                        return false;

                    if (TypeId == (int)TypeID.Noctis)
                        return false;

                    if (IsBattleship)
                        return false;

                    if (IsBattlecruiser)
                        return false;

                    if (IsT2Cruiser && GroupId != (int)Group.ForceReconShip)
                        return false;

                    if (GroupId == (int)Group.Shuttle)
                        return false;

                    if (GroupId == (int)Group.Capsule)
                        return false;

                    return true;
                }

                return false;
            }
        }

        public bool isPreferredDroneTarget
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Drones.DronesKillHighValueTargets)
                            return isPreferredPrimaryWeaponTarget;

                        if (_isPreferredDroneTarget == null)
                        {
                            if (Drones.PreferredDroneTarget != null && Drones.PreferredDroneTarget.Id == _directEntity.Id)
                            {
                                _isPreferredDroneTarget = true;
                                return (bool)_isPreferredDroneTarget;
                            }

                            _isPreferredDroneTarget = false;
                            return (bool)_isPreferredDroneTarget;
                        }

                        return (bool)_isPreferredDroneTarget;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool isPreferredPrimaryWeaponTarget
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isPreferredPrimaryWeaponTarget == null)
                        {
                            if (Combat.PreferredPrimaryWeaponTarget != null && Combat.PreferredPrimaryWeaponTarget.Id == Id)
                            {
                                _isPreferredPrimaryWeaponTarget = true;
                                return (bool)_isPreferredPrimaryWeaponTarget;
                            }

                            _isPreferredPrimaryWeaponTarget = false;
                            return (bool)_isPreferredPrimaryWeaponTarget;
                        }

                        return (bool)_isPreferredPrimaryWeaponTarget;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsPrimaryWeaponKillPriority
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isPrimaryWeaponKillPriority == null)
                        {
                            if (Combat.PrimaryWeaponPriorityTargets.Any(e => e.Entity.Id == Id))
                            {
                                _isPrimaryWeaponKillPriority = true;
                                return (bool)_isPrimaryWeaponKillPriority;
                            }

                            _isPrimaryWeaponKillPriority = false;
                            return (bool)_isPrimaryWeaponKillPriority;
                        }

                        return (bool)_isPrimaryWeaponKillPriority;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsPrimaryWeaponPriorityTarget
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Combat.PrimaryWeaponPriorityTargets.Any(i => i.EntityID == Id))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsReadyForDronesToShoot
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_IsReadyForDronesToShoot == null)
                        {
                            if (!HasExploded && IsTarget && Distance < Drones.MaxDroneRange && !IsBadIdea && !IsWreck && Id != ESCache.Instance.MyShipEntity.Id)
                            {
                                _IsReadyForDronesToShoot = true;
                                return (bool)_IsReadyForDronesToShoot;
                            }

                            _IsReadyForDronesToShoot = false;
                            return (bool)_IsReadyForDronesToShoot;
                        }

                        return _IsReadyForDronesToShoot ?? false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsReadyToShoot
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_IsReadyToShoot == null)
                        {
                            if (IsDecloakedTransmissionRelay && .98 > ShieldPct)
                            {
                                UnlockTarget();
                                _IsReadyToShoot = false;
                                return (bool)_IsReadyToShoot;
                            }

                            if (!HasExploded && IsTarget && IsInRangeOfWeapons && !IsWreck && !IsNPCDrone && !IsIgnored && !IsBadIdea && Id != ESCache.Instance.MyShipEntity.Id)
                            {
                                _IsReadyToShoot = true;
                                return (bool)_IsReadyToShoot;
                            }

                            _IsReadyToShoot = false;
                            return (bool)_IsReadyToShoot;
                        }

                        return _IsReadyToShoot ?? false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsReadyToTarget
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_IsReadyToTarget == null)
                        {
                            if (!HasExploded && !IsTarget && !IsTargeting && (Distance < Combat.MaxRange || Distance < 20000) && Id != ESCache.Instance.MyShipEntity.Id)
                            {
                                if (IsDecloakedTransmissionRelay && .98 > ShieldPct)
                                {
                                    _IsReadyToTarget = false;
                                    return (bool)_IsReadyToTarget;
                                }

                                _IsReadyToTarget = true;
                                return (bool)_IsReadyToTarget;
                            }

                            _IsReadyToTarget = false;
                            return (bool)_IsReadyToTarget;
                        }

                        return (bool)_IsReadyToTarget;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsSensorDampeningMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_directEntity.ElectronicWarfare.Contains("ewRemoteSensorDamp"))
                        {
                            if (!ESCache.Instance.ListOfDampenuingEntities.Contains(Id)) ESCache.Instance.ListOfDampenuingEntities.Add(Id);
                            return true;
                        }

                        if (ESCache.Instance.ListOfDampenuingEntities.Contains(Id))
                            return true;

                        if (ESCache.Instance.InAbyssalDeadspace && (Name.Contains("Obfuscator") || Name.Contains("Blinding") || Name.Contains("Gazedimmer")))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsSentry => _directEntity.IsSentry;

        public bool IsSmallWreck => _directEntity.IsSmallWreck;

        public bool IsSomethingICouldKillFasterIfIWereCloser
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (!IsInWebRange) return true;
                    if (!IsInOptimalRange) return true;
                    if (!IsInDroneRange && Drones.DronesKillHighValueTargets) return true;
                    if (Distance > Combat.MaxRange && !Drones.DronesKillHighValueTargets) return true;
                    return false;
                }

                return false;
            }
        }

        public bool IsStation
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= GroupId == (int)Group.Station;
                        result |= GroupId == (int)Group.Citadel;
                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsT2Cruiser => _directEntity.IsT2Cruiser;

        public bool IsTarget => _directEntity.IsTarget;

        public bool IsTargetedBy => _directEntity.IsTargetedBy;

        public bool IsTargeting => _directEntity.IsTargeting;

        public bool IsTargetingMeAndNotYetTargeted
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= (IsNpc || IsNpcByGroupID || IsAttacking)
                                  && CategoryId == (int)CategoryID.Entity
                                  && Distance < Combat.MaxTargetRange
                                  && !IsLargeCollidable && !IsTargeting && !IsTarget && IsTargetedBy && !IsContainer && !IsIgnored &&
                                  (!IsBadIdea || IsAttacking) && !IsEntityIShouldLeaveAlone && !IsFactionWarfareNPC && !IsStation;

                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsTargetPaintingMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_directEntity.ElectronicWarfare.Contains("ewTargetPaint"))
                        {
                            if (!ESCache.Instance.ListOfTargetPaintingEntities.Contains(Id)) ESCache.Instance.ListOfTargetPaintingEntities.Add(Id);
                            return true;
                        }

                        if (ESCache.Instance.ListOfTargetPaintingEntities.Contains(Id))
                            return true;

                        if (ESCache.Instance.InAbyssalDeadspace && (Name.Contains("Spotlighter") || Name.Contains("Harrowing") || Name.Contains("Illuminator")))

                            return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsTargetWeCanShootButHaveNotYetTargeted
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= CategoryId == (int)CategoryID.Entity
                                  && !IsTarget
                                  && !IsTargeting
                                  && Distance < Combat.MaxRange
                                  && !IsIgnored
                                  && !IsStation;

                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsTooCloseTooFastTooSmallToHit
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_IsTooCloseTooFastTooSmallToHit == null)
                            if (IsNPCFrigate || IsFrigate)
                            {
                                if (Combat.DoWeCurrentlyHaveTurretsMounted() && Drones.UseDrones && Drones.ActiveDrones.Any())
                                {
                                    if (!IsTrackable)
                                    {
                                        if (Combat.PotentialCombatTargets.Any() && Combat.PotentialCombatTargets.Any(i => !i.IsNPCFrigate))
                                        {
                                            _IsTooCloseTooFastTooSmallToHit = true;
                                            return (bool)_IsTooCloseTooFastTooSmallToHit;
                                        }

                                        //
                                        // it may not be tracable, but its potentially the only thing left to shoot...
                                        //

                                        _IsTooCloseTooFastTooSmallToHit = true;
                                        return (bool)_IsTooCloseTooFastTooSmallToHit;
                                    }

                                    _IsTooCloseTooFastTooSmallToHit = false;
                                    return (bool)_IsTooCloseTooFastTooSmallToHit;
                                }

                                _IsTooCloseTooFastTooSmallToHit = false;
                                return (bool)_IsTooCloseTooFastTooSmallToHit;
                            }

                        return _IsTooCloseTooFastTooSmallToHit ?? false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public double Health
        {
            get { return ShieldHitPoints + ArmorHitPoints + StructureHitPoints; }
        }

        public bool AllowChangingAmmoBasedOnResists
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsNPCBattleship && Health > 1000)
                        return true;

                    if (IsLargeCollidable && Health > 1000)
                        return true;

                    return false;
                }

                return false;
            }
        }
        //todo: improve this to work for missiles (either hard coded NPC sizes to missile sizes, or better explosion velocity calcs)
        public bool IsTrackable
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_isTrackable == null)
                        {
                            if (ESCache.Instance.Weapons.Any())
                            {
                                if (Combat.DoWeCurrentlyHaveTurretsMounted())
                                    try
                                    {
                                        //Divide turret tracking by 1000, you'll hit frigates doing that many rad/s 50% of the time.
                                        //Multiply by 3.2, you'll hit cruisers doing that many rad/s 50% of the time.
                                        //Multiply that by 3.2(or divide original turret tracking by 100) and you'll hit battleships doing that many rad/s 50% of the time.
                                        //That's the rule of thumb you want to start with, it obviously changes a little if the sig sizes aren't exactly 40 / 125 / 400.
                                        ModuleCache myTurret = ESCache.Instance.Weapons.FirstOrDefault(i => i.IsTurret);
                                        if (myTurret != null)
                                        {
                                            if ((IsFrigate || IsNPCFrigate) && AngularVelocity < myTurret.TrackingSpeed / 1000)
                                            {
                                                _isTrackable = true;
                                                return (bool)_isTrackable;
                                            }

                                            if ((IsCruiser || IsNPCCruiser) && AngularVelocity < myTurret.TrackingSpeed / 1000 * 3.2)
                                            {
                                                _isTrackable = true;
                                                return (bool)_isTrackable;
                                            }

                                            if ((IsBattleship || IsBattlecruiser || IsNPCBattleship || IsNPCBattlecruiser) && AngularVelocity < myTurret.TrackingSpeed / 100)
                                            {
                                                _isTrackable = true;
                                                return (bool)_isTrackable;
                                            }

                                            _isTrackable = false;
                                            return (bool)_isTrackable;
                                        }

                                        _isTrackable = false;
                                        return (bool)_isTrackable;
                                    }
                                    catch (Exception exception)
                                    {
                                        Log.WriteLine("Exception [" + exception + "]");
                                        return false;
                                    }

                                return true;
                            }

                            _isTrackable = false;
                            return (bool)_isTrackable;
                        }

                        return (bool)_isTrackable;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsTrackingDisruptingMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_directEntity.ElectronicWarfare.Contains("ewTrackingDisrupt"))
                        {
                            if (!ESCache.Instance.ListOfTrackingDisruptingEntities.Contains(Id)) ESCache.Instance.ListOfTrackingDisruptingEntities.Add(Id);
                            return true;
                        }

                        if (ESCache.Instance.ListOfTrackingDisruptingEntities.Contains(Id))
                            return true;

                        if (ESCache.Instance.InAbyssalDeadspace && (Name.Contains("Ghosting") || Name.Contains("Fogcaster") || Name.Contains("Confuser")))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsValid => _directEntity.IsValid;

        public bool IsWarpScramblingMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (ESCache.Instance.InAbyssalDeadspace)
                            return false;

                        //ESCache.Instance.AttemptingToWarp = false;
                        return _directEntity.IsWarpScramblingMe;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsWebbingMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_directEntity.Attacks.Contains("effects.ModifyTargetSpeed"))
                        {
                            if (!ESCache.Instance.ListofWebbingEntities.Contains(Id)) ESCache.Instance.ListofWebbingEntities.Add(Id);
                            return true;
                        }

                        if (ESCache.Instance.ListofWebbingEntities.Contains(Id))
                            return true;

                        if (ESCache.Instance.InAbyssalDeadspace && (Name.Contains("Spearfisher") || Name.Contains("Tangling") || Name.Contains("Snarecaster") || Name.Contains("Upholder") || Name.Contains("Warden") || Name.Contains("Entanglement") || Name.Contains("Entangler")))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsMissileDisruptingMe
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        //if (_directEntity.Attacks.Contains("effects.ModifyTargetSpeed"))
                        //{
                        //    if (!ESCache.Instance.ListofWebbingEntities.Contains(Id)) ESCache.Instance.ListofWebbingEntities.Add(Id);
                        //    return true;
                        //}

                        //if (ESCache.Instance.ListofWebbingEntities.Contains(Id))
                        //    return true;

                        if (ESCache.Instance.InAbyssalDeadspace && Name.Contains("Fogcaster"))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsHighDps
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        //if (_directEntity.Attacks.Contains("effects.ModifyTargetSpeed"))
                        //{
                        //    if (!ESCache.Instance.ListofWebbingEntities.Contains(Id)) ESCache.Instance.ListofWebbingEntities.Add(Id);
                        //    return true;
                        //}

                        //if (ESCache.Instance.ListofWebbingEntities.Contains(Id))
                        //    return true;

                        if (ESCache.Instance.InAbyssalDeadspace)
                        {
                            if (IsNPCFrigate)
                            {
                                if (Name.Contains("Lance") || Name.Contains("Striking") || Name.Contains("Warding"))
                                    return true;
                            }

                            if (IsNPCCruiser)
                            {
                                if (Name.Contains("Vedmak") || Name.Contains("Lancer"))
                                    return true;
                            }

                            if (IsNPCBattleship)
                            {
                                if (Name.Contains("Leshak"))
                                    return true;
                            }
                        }

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsWreck
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (GroupId == (int)Group.Wreck)
                            return true;

                        if (Name.Contains("Cache Wreck") && !IsPlayer)
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsWreckEmpty
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (IsWreck)
                            return _directEntity.IsEmpty;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public bool KillThisJammingNpc
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsJammingMe)
                    {
                        if (Combat.AddECMsToPrimaryWeaponsPriorityTargetList)
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool KillThisNeutralizingNpc
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsNeutralizingMe)
                    {
                        if (Combat.AddNeutralizersToPrimaryWeaponsPriorityTargetList || ESCache.Instance.Modules != null && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        /**
        public bool IsPriorityWarpScrambler
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (Combat.PrimaryWeaponPriorityTargets.Any(pt => pt.EntityID == Id && pt.PrimaryWeaponPriority == PrimaryWeaponPriority.WarpScrambler))
                            return true;

                        if (Drones.DronePriorityTargets.Any(pt => pt.EntityID == Id && pt.DronePriority == DronePriority.WarpScrambler))
                            return true;

                        return false;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }
        **/

        public bool KillThisSensorDampeningNpc
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsSensorDampeningMe)
                    {
                        if (Combat.AddDampenersToPrimaryWeaponsPriorityTargetList)
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool KillThisTargetPaintingNpc
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsTargetPaintingMe)
                    {
                        if (Combat.AddTargetPaintersToPrimaryWeaponsPriorityTargetList)
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool KillThisTrackingDisruptingNpc
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsTrackingDisruptingMe)
                    {
                        if (Combat.AddTrackingDisruptorsToPrimaryWeaponsPriorityTargetList)
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool KillThisWarpScramblingNpc
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsWarpScramblingMe)
                    {
                        if (Combat.AddWarpScramblersToPrimaryWeaponsPriorityTargetList)
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public bool KillThisWebbingNpc
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsWebbingMe)
                    {
                        if (Combat.AddWebifiersToPrimaryWeaponsPriorityTargetList)
                            return true;

                        return false;
                    }

                    return false;
                }

                return false;
            }
        }

        public DirectSolarSystem LeadsToSolarSystem
        {
            get
            {
                if (GroupId == (int)Group.Stargate)
                {
                    IEnumerable<DirectSolarSystem> NeighboringSystems = ESCache.Instance.DirectEve.Session.SolarSystem.GetNeighbours(1);
                    if (NeighboringSystems.Any(i => i.Name == Name))
                    {
                        DirectSolarSystem tempSolarSystem = NeighboringSystems.FirstOrDefault(i => i.Name == Name);
                        return tempSolarSystem;
                    }
                }

                return null;
            }
        }

        public bool WeCanKillThisNPCAndStillHaveEnoughDpsOnFieldToKillLooters
        {
            get
            {
                if (IsNPCFrigate && 8 >= Combat.PotentialCombatTargets.Count(i => i.IsNPCFrigate))
                    return false;

                if (IsNPCCruiser && 6 >= Combat.PotentialCombatTargets.Count(i => i.IsNPCCruiser))
                    return false;

                if (IsNPCBattlecruiser && 4 >= Combat.PotentialCombatTargets.Count(i => i.IsNPCBattlecruiser))
                    return false;

                if (IsNPCBattleship && 2 >= Combat.PotentialCombatTargets.Count(i => i.IsNPCBattleship))
                    return false;

                return true;
            }
        }

        public string MaskedId
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        int numofCharacters = _directEntity.Id.ToString(CultureInfo.InvariantCulture).Length;
                        if (numofCharacters >= 5)
                        {
                            string maskedID = _directEntity.Id.ToString(CultureInfo.InvariantCulture).Substring(numofCharacters - 4);
                            maskedID = "[MaskedID]" + maskedID;
                            return maskedID;
                        }

                        return "!0!";
                    }

                    return "!0!";
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return "!0!";
                }
            }
        }

        /// <summary>
        /// Calculate the damage done by a missile
        /// https://wiki.eveuniversity.org/Missile_mechanics#Missile_damage_formula
        /// </summary>
        /// <param name="missileToUseInDamageCalc">DirectItem of Missile to use for Damage Calculations</param>
        /// <returns>The final damage dealt by the missile impact</returns>
        public double MissileDamageCalc(DirectItem missileToUseInDamageCalc)
        {
            if (missileToUseInDamageCalc.CategoryId == (int) CategoryID.Charge && missileToUseInDamageCalc.IsMissile)
            {
                // To prevent doing damage greater than the missile's base damage, return the smallest out of:
                // 1 (full damage)
                // Sig Radius / Explosion Radius (signature radius is larger than the explosion radius)
                // The full calculation
                double missileBaseEmDamage = missileToUseInDamageCalc.Attributes.TryGet<int>("emDamage");
                double missileBaseExplosiveDamage = missileToUseInDamageCalc.Attributes.TryGet<int>("explosiveDamage");
                double missileBaseKineticDamage = missileToUseInDamageCalc.Attributes.TryGet<int>("kineticDamage");
                double missileBaseThermalDamage = missileToUseInDamageCalc.Attributes.TryGet<int>("thermalDamage");

                double missileDamageReductionFactor = missileToUseInDamageCalc.Attributes.TryGet<int>("aoeDamageReductionFactor");
                double missileExplosionRadius = missileToUseInDamageCalc.Attributes.TryGet<int>("aoeCloudSize");
                double missileExplosionVelocity = missileToUseInDamageCalc.Attributes.TryGet<int>("aoeVelocity");

                double missileCalculatedRawEmDamage = missileBaseEmDamage * Math.Min(1, Math.Min(((double)_directEntity.EntitySignatureRadius * missileExplosionRadius), Math.Pow(((double)_directEntity.EntitySignatureRadius / missileExplosionRadius) * (missileExplosionVelocity / (double)Velocity), missileDamageReductionFactor)));
                double missileCalculatedRawExplosiveDamage = missileBaseExplosiveDamage * Math.Min(1, Math.Min(((double)_directEntity.EntitySignatureRadius * missileExplosionRadius), Math.Pow(((double)_directEntity.EntitySignatureRadius / missileExplosionRadius) * (missileExplosionVelocity / (double)Velocity), missileDamageReductionFactor)));
                double missileCalculatedRawKineticDamage = missileBaseKineticDamage * Math.Min(1, Math.Min(((double)_directEntity.EntitySignatureRadius * missileExplosionRadius), Math.Pow(((double)_directEntity.EntitySignatureRadius / missileExplosionRadius) * (missileExplosionVelocity / (double)Velocity), missileDamageReductionFactor)));
                double missileCalculatedRawThermalDamage = missileBaseThermalDamage * Math.Min(1, Math.Min(((double)_directEntity.EntitySignatureRadius * missileExplosionRadius), Math.Pow(((double)_directEntity.EntitySignatureRadius / missileExplosionRadius) * (missileExplosionVelocity / (double)Velocity), missileDamageReductionFactor)));

                double missileCalculatedEmDamage = missileCalculatedRawEmDamage * CurrentEmResistance;
                double missileCalculatedExplosiveDamage = missileCalculatedRawExplosiveDamage * CurrentExplosiveResistance;
                double missileCalculatedKineticDamage = missileCalculatedRawKineticDamage * CurrentKineticResistance;
                double missileCalculatedThermalDamage = missileCalculatedRawThermalDamage * CurrentThermalResistance;
                double missileCalculatedTotalDamage = missileCalculatedEmDamage + missileCalculatedExplosiveDamage + missileCalculatedKineticDamage + missileCalculatedThermalDamage;
                return missileCalculatedTotalDamage;
            }

            return 0;
        }

        public double TurretChanceToHit(DirectModule myTurret)
        {
            if (myTurret.OptimalRange != null && myTurret.FallOff != null && myTurret.IsTurret)
            {
                // How likely it is to hit the target with how fast the target is moving in relation to the ship doing the shooting
                double trackingTerm = 0.5 * (((double)_directEntity.AngularVelocity * 40000) / ((double)myTurret.TrackingSpeed * (double)_directEntity.EntitySignatureRadius));

                // How likely it is to hit the target at the distance it is
                // 100% within optimal range
                // about 50% at optimal + under half of falloff
                // about 6.5% @ optimal + over half of falloff
                // about 0.2% @ optimal + falloff
                double rangeTerm = 0.5 * (Math.Max(0, Distance - (double)myTurret.OptimalRange) / (double)myTurret.FallOff);

                return trackingTerm * rangeTerm;
            }

            return 1;
        }

        public double CurrentEmResistance
        {
            get
            {
                if (ShieldHitPoints > 0)
                    return ShieldResistanceEm;

                if (ArmorHitPoints > 0)
                    return ArmorResistanceEM;

                if (StructureHitPoints > 0)
                    return 0;

                return 0;
            }
        }

        public double CurrentExplosiveResistance
        {
            get
            {
                if (ShieldHitPoints > 0)
                    return ShieldResistanceExplosive;

                if (ArmorHitPoints > 0)
                    return ArmorResistanceExplosive;

                if (StructureHitPoints > 0)
                    return 0;

                return 0;
            }
        }

        public double CurrentKineticResistance
        {
            get
            {
                if (ShieldHitPoints > 0)
                    return ShieldResistanceKinetic;

                if (ArmorHitPoints > 0)
                    return ArmorResistanceKinetic;

                if (StructureHitPoints > 0)
                    return 0;

                return 0;
            }
        }

        public double CurrentThermalResistance
        {
            get
            {
                if (ShieldHitPoints > 0)
                    return ShieldResistanceThermal;

                if (ArmorHitPoints > 0)
                    return ArmorResistanceThermal;

                if (StructureHitPoints > 0)
                    return 0;

                return 0;
            }
        }

        public int Mode => _directEntity.Mode;

        // 0 = entityIdle
        // 1 = Approaching or entityCombat
        // 2 = entityMining
        // 3 = Warping (is this correct? entityApproaching)
        // 4 = Orbiting (is this correct? entityDeparting)
        // 5 = entityDeparting2
        // 6 = entityPursuit
        // 7 = entityFleeing
        // 8 =
        // 9 = entityOperating
        // 10 = entityEngage
        // 18 = entitySalvaging
        public string Name => _directEntity.Name;

        public bool IsBurnerMainNPC
        {
            get
            {
                switch (Name)
                {
                    case "Burner Jaguar":
                    case "Burner Hawk":
                    case "Burner Enyo":
                    case "Burner Vengeance":
                    case "Burner Cruor":
                    case "Burner Daredevil":
                    case "Burner Dramiel":
                    case "Burner Succubus":
                    case "Burner Worm":
                        return true;
                }

                return false;
            }
        }

        public double Nearest5kDistance
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (ESCache.Instance.InAbyssalDeadspace)
                            return 0;

                        if (_nearest5kDistance == null)
                            if (Distance > 0 && Distance < 900000000)
                                _nearest5kDistance = Math.Ceiling(Math.Round(Distance / 1000) / 5.0) * 5;

                        return _nearest5kDistance ?? Distance;
                    }

                    return 0;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return 0;
                }
            }
        }

        public bool NpcHasNeutralizers
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (_npcHasNeutralizers == null)
                        _npcHasNeutralizers = _directEntity.NpcHasNeutralizers;

                    if (IsNeutralizingMe)
                        _npcHasNeutralizers = IsNeutralizingMe;

                    return (bool)_npcHasNeutralizers;
                }

                return false;
            }
        }

        public bool NpcHasALotOfRemoteRepair
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    //remote shield rep
                    if (Name.Contains("Fieldweaver") || Name.Contains("Plateweaver") || Name.Contains("Preserver"))
                        return true;

                    if (Name.Contains("Renewing") || Name.Contains("Plateforger"))
                        return true;

                    return false;
                }

                return false;
            }
        }

        public bool NpcHasRemoteRepair
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (NpcRemoteArmorRepairChance > 0 || _npcRemoteShieldRepairChance > 0)
                        return true;
                    //remote shield rep
                    if (Name.Contains("Fieldweaver") || Name.Contains("Plateweaver") || Name.Contains("Preserver"))
                        return true;
                    //remote armor rep
                    if (Name.Contains("Renewing") || Name.Contains("Plateforger"))
                        return true;
                    //remote armor rep
                    if (Name.Contains("Anchoring"))
                        return true;

                    return false;
                }

                return false;
            }
        }

        public bool WillYellowBoxButPosesLittleThreatToDrones
        {
            get
            {
                if (_directEntity != null && IsValid)
                {
                    if (Name.ToLower().Contains("Blastgrip Tessera".ToLower()))
                        return false; //this NPC is a threat to drones

                    if (Name.ToLower().Contains("Sparkgrip Tessera".ToLower()))
                        return false; //this NPC is a threat to drones

                    if (Name.ToLower().Contains("Strikegrip Tessera".ToLower()))
                        return false; //this NPC is a threat to drones

                    if (NpcHasRemoteRepair)
                        return true;

                    if (Name.ToLower().Contains("Striking Damavik".ToLower()))
                        return true;

                    return false;
                }

                return false;
            }
        }

        public double NpcRemoteArmorRepairChance
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_npcRemoteArmorRepairChance != null)
                            return (double)_npcRemoteArmorRepairChance;

                        if (_directEntity.NpcRemoteArmorRepairChance > 0)
                        {
                            _npcRemoteArmorRepairChance = _directEntity.NpcRemoteArmorRepairChance;
                            return (double)_npcRemoteArmorRepairChance;
                        }

                        return 0;
                    }

                    return 0;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return 0;
                }
            }
        }

        public double NpcRemoteShieldRepairChance
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_npcRemoteShieldRepairChance != null)
                            return (double)_npcRemoteShieldRepairChance;

                        if (_directEntity.NpcRemoteArmorRepairChance > 0)
                        {
                            _npcRemoteShieldRepairChance = _directEntity.NpcRemoteArmorRepairChance;
                            return (double)_npcRemoteShieldRepairChance;
                        }

                        return 0;
                    }

                    return 0;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return 0;
                }
            }
        }

        public double OptimalRange => _directEntity.OptimalRange;

        public PrimaryWeaponPriority PrimaryWeaponPriorityLevel
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (_primaryWeaponPriorityLevel == null)
                        {
                            if (Combat.PrimaryWeaponPriorityTargets.Any(pt => pt.EntityID == Id))
                            {
                                _primaryWeaponPriorityLevel = Combat.PrimaryWeaponPriorityTargets.Where(t => t.Entity.IsTarget && t.EntityID == Id)
                                    .Select(pt => pt.PrimaryWeaponPriority)
                                    .FirstOrDefault();
                                return (PrimaryWeaponPriority)_primaryWeaponPriorityLevel;
                            }

                            return PrimaryWeaponPriority.NotUsed;
                        }

                        return (PrimaryWeaponPriority)_primaryWeaponPriorityLevel;
                    }

                    return PrimaryWeaponPriority.NotUsed;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return PrimaryWeaponPriority.NotUsed;
                }
            }
        }

        public bool SalvagersAvailable
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        bool result = false;
                        result |= ESCache.Instance.Modules.Any(m => m.GroupId == (int)Group.Salvager && m.IsOnline);
                        return result;
                    }

                    return false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return false;
                }
            }
        }

        public double ShieldHitPoints => _directEntity.TotalShield ?? 0;
        public double ShieldPct => _directEntity.ShieldPct;
        public double ShieldResistanceEm => _directEntity.ShieldResistanceEM ?? 0;
        public double ShieldResistanceExplosive => _directEntity.ShieldResistanceExplosive ?? 0;
        public double ShieldResistanceKinetic => _directEntity.ShieldResistanceKinetic ?? 0;
        public double ShieldResistanceThermal => _directEntity.ShieldResistanceThermal ?? 0;
        public double StructureHitPoints => _directEntity.TotalStructure ?? 0;
        public double StructurePct => _directEntity.StructurePct;

        public int? TargetValue
        {
            get
            {
                try
                {
                    int result = -1;

                    if (_directEntity != null && IsValid)
                    {
                        if (_targetValue == null)
                        {
                            ShipTargetValue value = null;

                            try
                            {
                                if (ESCache.Instance.ShipTargetValues != null && ESCache.Instance.ShipTargetValues.Any(v => v.GroupId == GroupId))
                                    value = ESCache.Instance.ShipTargetValues.FirstOrDefault(v => v.GroupId == GroupId);

                                if (Name.Contains("Burner Enyo") ||
                                    Name.Contains("Burner Hawk") ||
                                    Name.Contains("Burner Jaguar") ||
                                    Name.Contains("Burner Vengeance"))
                                {
                                    _targetValue = 4;
                                    return _targetValue;
                                }
                            }
                            catch (Exception ex)
                            {
                                Log.WriteLine(ex.ToString());
                            }

                            if (value == null)
                            {
                                if (IsNPCBattleship)
                                    _targetValue = 4;
                                else if (IsNPCBattlecruiser)
                                    _targetValue = 3;
                                else if (IsNPCCruiser)
                                    _targetValue = 2;
                                else if (IsNPCFrigate)
                                    _targetValue = 0;

                                return _targetValue ?? -1;
                            }

                            _targetValue = value.TargetValue;
                            return _targetValue;
                        }

                        return _targetValue;
                    }

                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return -1;
                }
            }
        }

        public double TransversalVelocity => _directEntity.TransversalVelocity;
        public double? TriglavianDamage => _directEntity.TriglavianDamage;
        public double? TriglavianDPS => _directEntity.TriglavianDPS;
        public int TypeId => _directEntity.TypeId;
        public string TypeName => _directEntity.TypeName;
        public double Velocity => _directEntity.Velocity;

        public double WarpScrambleChance
        {
            get
            {
                try
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (ESCache.Instance.InAbyssalDeadspace)
                            return 0;

                        if (IsWarpScramblingMe)
                            return 1;

                        if (_warpScrambleChance != null)
                            return (double)_warpScrambleChance;

                        if (_directEntity.Attacks.Contains("effects.WarpScramble") || _directEntity.WarpScrambleChance > 0)
                        {
                            _warpScrambleChance = _directEntity.WarpScrambleChance;
                            return (double)_warpScrambleChance;
                        }

                        return 0;
                    }

                    return 0;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return 0;
                }
            }
        }

        public double XCoordinate => _directEntity.X;

        public double YCoordinate => _directEntity.Y;

        public double ZCoordinate => _directEntity.Z;

        #endregion Properties

        /**
        private bool? _isAtCorrectRangeForMyCurrentAmmo;

        public bool IsAtCorrectRangeForMyCurrentAmmo
        {
            get
            {
                try
                {
                    if (_isAtCorrectRangeForMyCurrentAmmo != null)
                    {
                        return (bool)_isAtCorrectRangeForMyCurrentAmmo;
                    }
                    //
                    // Do I even have more than one ammo in cargo?
                    //
                    if (MissionSettings.AmmoTypesToLoad.Count > 1)
                    {
                        foreach (KeyValuePair<AmmoType, DateTime> ammoType in MissionSettings.AmmoTypesToLoad)
                        {
                            if (QCache.Instance.Weapons.FirstOrDefault() != null)
                            {
                                if (QCache.Instance.Weapons.FirstOrDefault().Charge != null)
                                {
                                    if (ammoType.Key.TypeId == QCache.Instance.Weapons.FirstOrDefault().Charge.TypeId)
                                    {
                                        //
                                        // In Range for this DefinedAmmoTypes?
                                        //
                                        if (ammoType.Key.Range > Distance)
                                        {
                                            if (MissionSettings.AmmoTypesToLoad.Any(am => am.Key.Range > Distance))
                                            {
                                                _isAtCorrectRangeForMyCurrentAmmo = false;
                                                return (bool)_isAtCorrectRangeForMyCurrentAmmo;
                                            }

                                            _isAtCorrectRangeForMyCurrentAmmo = true;
                                            return (bool)_isAtCorrectRangeForMyCurrentAmmo;
                                        }

                                        _isAtCorrectRangeForMyCurrentAmmo = false;
                                        return (bool)_isAtCorrectRangeForMyCurrentAmmo;
                                    }
                                }
                            }
                        }

                        //if we cant figure out if its in range or not, assume it is
                        _isAtCorrectRangeForMyCurrentAmmo = true;
                        return (bool)_isAtCorrectRangeForMyCurrentAmmo;
                    }

                    _isAtCorrectRangeForMyCurrentAmmo = true;
                    return (bool)_isAtCorrectRangeForMyCurrentAmmo;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return true;
                }
            }
        }
        **/

        #region Methods

        public bool IsVulnerableAgainstCurrentDamageType => BestDamageTypes.FirstOrDefault() == MissionSettings.CurrentDamageType;

        public bool CloseCargoWindows()
        {
            //if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation) return false;

            foreach (DirectWindow tempWindow in ESCache.Instance.DirectEve.Windows)
            {
                if(tempWindow.Name.Contains("Wreck"))
                {
                    Log.WriteLine("CloseCargoWindows: Attempting to close window [" + tempWindow.Name + "]");
                    bool forceWindowClose = true;
                    tempWindow.Close(forceWindowClose);
                }
            }

            return true;
        }

        public bool Activate()
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                if (DateTime.UtcNow > Time.Instance.NextActivateAction)
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                            Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                          Math.Round(_directEntity.Distance / 1000, 0) + "k][" +
                                          MaskedId + "] was created more than 5 seconds ago (ugh!)");

                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            Log.WriteLine("EntityCache: Activate: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (!SafeToInitiateMovementCommand("Activate"))
                            return false;

                        if (!SafeToInitiateWarpJumpActivateCommand("Activate"))
                            return false;

                        if (ESCache.Instance.InAbyssalDeadspace)
                        {
                            CloseCargoWindows();
                            if (Name.Contains("Transfer Conduit"))
                            {
                                if (_directEntity.ActivateAbyssalAccelerationGate())
                                {
                                    Log.WriteLine("Entering Pocket number [" + ActionControl.PocketNumber + "]");
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                    ESCache.Instance.ClearPerPocketCache("Activate");
                                    Time.Instance.LastInitiatedWarp = DateTime.UtcNow;
                                    //Time.Instance.LastInWarp = DateTime.UtcNow;
                                    Time.Instance.NextActivateAction = DateTime.UtcNow.AddSeconds(10);
                                    DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "Gate Activated"));
                                    return true;
                                }

                                Log.WriteLine("Failed to activate gate at [" + Math.Round(Distance, 0) + "k]");
                                return false;
                            }

                            if (Name.Contains("Origin Conduit") && _directEntity.ActivateAbyssalEndGate())
                            {
                                Log.WriteLine("Exiting Abyssal Deadspace");
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                ESCache.Instance.ClearPerPocketCache("Activate");
                                Time.Instance.LastInitiatedWarp = DateTime.UtcNow;
                                //Time.Instance.LastInWarp = DateTime.UtcNow;
                                Time.Instance.NextActivateAction = DateTime.UtcNow.AddSeconds(5);
                                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "EndGate Activated"));
                                return true;
                            }

                            Log.WriteLine("Failed to activate gate at [" + Math.Round(Distance, 0) + "k].");
                            return false;
                        }
                        if (_directEntity.Activate())
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            ESCache.Instance.ClearPerPocketCache("Activate");
                            Time.Instance.LastInitiatedWarp = DateTime.UtcNow;
                            Time.Instance.NextActivateAction = DateTime.UtcNow.AddSeconds(15);
                            DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "Gate Activated"));
                            if (ESCache.Instance.EveAccount.IsLeader)
                            {
                                if (ESCache.Instance.EveAccount.LeaderLastEntityIdActivate != Id)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdActivate), Id);

                                if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastActivate.AddSeconds(10))
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastActivate), DateTime.UtcNow);
                            }

                            return true;
                        }

                        Log.WriteLine("Failed to activate gate at [" + Math.Round(Distance, 0) + "]k");
                        return false;
                    }

                    Log.WriteLine("[" + Name + "] DirecEntity is null or is not valid");
                    return false;
                }

                Log.WriteLine("You have another [" + Time.Instance.NextActivateAction.Subtract(DateTime.UtcNow).TotalSeconds +
                              "] sec before we should attempt to activate [" + Name + "], waiting.");
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool ActuallyWarpTo(double range = 0)
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                if (DateTime.UtcNow > Time.Instance.NextWarpAction)
                {
                    if (ESCache.Instance.InSpace)
                    {
                        if (_directEntity != null && IsValid)
                        {
                            if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                                Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                              Math.Round(_directEntity.Distance / 1000, 0) +
                                              "k][" + MaskedId + "] was created more than 5 seconds ago (ugh!)");

                            if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsWarpScramblingMe))
                            {
                                AlignTo();
                                return false;
                            }

                            if (Distance < (long)Distances.HalfOfALightYearInAu)
                            {
                                if (Distance > (int)Distances.WarptoDistance)
                                {
                                    if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile)
                                        return false;

                                    if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                                    {
                                        if (DebugConfig.DebugInteractWithEve) Log.WriteLine("EntityCache: WarpTo: !OkToInteractWithEveNow");
                                        return false;
                                    }

                                    AlignTo();

                                    if (!HasInitiatedWarp && _directEntity.WarpTo(range))
                                    {
                                        Log.WriteLine("Warping to [" + Name + "][" + Math.Round(Distance / 1000 / 149598000, 2) + " AU away]");
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                        Drones.DronesShouldBePulled = true;
                                        ESCache.Instance.ClearPerPocketCache("WarpTo");
                                        Time.Instance.WehaveMoved = DateTime.UtcNow;
                                        Time.Instance.LastInitiatedWarp = DateTime.UtcNow;
                                        Time.Instance.NextWarpAction = DateTime.UtcNow.AddSeconds(Time.Instance.WarptoDelay_seconds);
                                        Defense.ActivateCovopsCloak(false, false);

                                        if (ESCache.Instance.DirectEve.Session.SolarSystemId != null)
                                        {
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.SolarSystem), ESCache.Instance.DirectEve.GetLocationName((long)ESCache.Instance.DirectEve.Session.SolarSystemId));
                                            if (ESCache.Instance.EveAccount.IsLeader)
                                            {
                                                if (ESCache.Instance.EveAccount.LeaderIsInSystemId != (long)ESCache.Instance.DirectEve.Session.SolarSystemId ||
                                                    ESCache.Instance.EveAccount.LeaderIsInSystemName != ESCache.Instance.DirectEve.GetLocationName((long)ESCache.Instance.DirectEve.Session.SolarSystemId))
                                                {
                                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderIsInSystemName), ESCache.Instance.DirectEve.GetLocationName((long)ESCache.Instance.DirectEve.Session.SolarSystemId));
                                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderIsInSystemId), (long)ESCache.Instance.DirectEve.Session.SolarSystemId);
                                                }

                                                if (ESCache.Instance.EveAccount.LeaderLastEntityIdWarp != Id)
                                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdWarp), Id);

                                                if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastWarp.AddSeconds(5))
                                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastWarp), DateTime.UtcNow);
                                            }
                                        }

                                        if (ESCache.Instance.MyShipEntity != null)
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.ShipType), ESCache.Instance.MyShipEntity.TypeName);

                                        return true;
                                    }

                                    return false;
                                }

                                Log.WriteLine("[" + Name + "] Distance [" + Math.Round(Distance / 1000, 0) +
                                              "k] is not greater then 150k away, WarpTo aborted!");
                                return false;
                            }

                            Log.WriteLine("[" + Name + "] Distance [" + Math.Round(Distance / 1000, 0) +
                                          "k] was greater than 5000AU away, we assume this an error!, WarpTo aborted!");
                            return false;
                        }

                        Log.WriteLine("[" + Name + "] DirecEntity is null or is not valid");
                        return false;
                    }

                    Log.WriteLine("We have not yet been in space at least 2 seconds, waiting");
                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool AlignTo()
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                if (DateTime.UtcNow < Time.Instance.LastAlign.AddSeconds(15))
                    return true;

                if (DateTime.UtcNow > Time.Instance.NextAlign)
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                            Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                          Math.Round(_directEntity.Distance / 1000, 0) + "k][" +
                                          MaskedId + "] was created more than 5 seconds ago (ugh!)");

                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("EntityCache: AlignTo: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (SafeToInitiateMovementCommand("AlignTo") && _directEntity.AlignTo())
                        {
                            Log.WriteLine("Aligning to [" + Name + "]");
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            if (ESCache.Instance.EveAccount.IsLeader)
                            {
                                if (ESCache.Instance.EveAccount.LeaderLastEntityIdAlign != Id)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdAlign), Id);

                                if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastAlign.AddSeconds(5))
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastAlign), DateTime.UtcNow);
                            }

                            Time.Instance.WehaveMoved = DateTime.UtcNow;
                            Time.Instance.NextAlign = DateTime.UtcNow.AddSeconds(Time.Instance.AlignDelay_seconds);
                            Time.Instance.LastAlign = DateTime.UtcNow;

                            Defense.ActivateCovopsCloak(false, false);
                            return true;
                        }

                        return false;
                    }

                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool Approach()
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                if (DateTime.UtcNow > Time.Instance.NextApproachAction)
                {
                    if (_directEntity != null && IsValid && DateTime.UtcNow > Time.Instance.NextApproachAction)
                    {
                        if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                            Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                          Math.Round(_directEntity.Distance / 1000, 0) + "k][" +
                                          MaskedId + "] was created more than 5 seconds ago (ugh!)");

                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("EntityCache: Approach: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (true)//SafeToInitiateMovementCommand("Approach"))
                        {
                            if (IsStation)
                            {
                                if (_directEntity.MoveTo())
                                {
                                    Log.WriteLine("MoveTo [" + Name + "][" + Math.Round(Distance / 1000, 0) + "k][" + MaskedId + "]");
                                    Defense.AlwaysActivateSpeedModForThisGridOnly = true;
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                    Time.Instance.LastApproachAction = DateTime.UtcNow;
                                    Time.Instance.NextApproachAction = DateTime.UtcNow.AddSeconds(Time.Instance.ApproachDelay_seconds + ESCache.Instance.RandomNumber(1, 3));
                                    Time.Instance.NextTravelerAction = DateTime.UtcNow.AddSeconds(Time.Instance.ApproachDelay_seconds);
                                    if (ESCache.Instance.EveAccount.IsLeader)
                                    {
                                        if (ESCache.Instance.EveAccount.LeaderLastEntityIdApproach != Id)
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdApproach), Id);

                                        if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastApproach.AddSeconds(5))
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastApproach), DateTime.UtcNow);
                                    }
                                }
                            }
                            else
                            {
                                //if (!IsApproachedByActiveShip && _directEntity.Approach())
                                if (_directEntity.Approach())
                                {
                                    Log.WriteLine("Approach [" + Name + "][" + Math.Round(Distance / 1000, 0) + "k][" + MaskedId + "]");
                                    Time.Instance.LastApproachAction = DateTime.UtcNow;
                                    Time.Instance.NextApproachAction = DateTime.UtcNow.AddSeconds(Time.Instance.ApproachDelay_seconds + ESCache.Instance.RandomNumber(1, 5));
                                    Time.Instance.NextTravelerAction = DateTime.UtcNow.AddSeconds(Time.Instance.ApproachDelay_seconds);
                                    if (ESCache.Instance.EveAccount.IsLeader)
                                    {
                                        if (ESCache.Instance.EveAccount.LeaderLastEntityIdApproach != Id)
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdApproach), Id);

                                        if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastApproach.AddSeconds(5))
                                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastApproach), DateTime.UtcNow);
                                    }

                                    return true;
                                }

                                return false;
                            }

                            return false;
                        }

                        //return false;
                    }

                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public double? DistanceFromEntity(EntityCache OtherEntityToMeasureFrom)
        {
            try
            {
                if (OtherEntityToMeasureFrom == null)
                    return null;

                double deltaX = XCoordinate - OtherEntityToMeasureFrom.XCoordinate;
                double deltaY = YCoordinate - OtherEntityToMeasureFrom.YCoordinate;
                double deltaZ = ZCoordinate - OtherEntityToMeasureFrom.ZCoordinate;

                return Math.Sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return 0;
            }
        }

        public bool Dock()
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                if (ESCache.Instance.EveAccount.DoNotSessionChange)
                {
                    Log.WriteLine("DoNotSessionChange: true - waiting for other EVE Accounts to completely login before session changing (avoid crashing...)");
                    return false;
                }

                if (DateTime.UtcNow > Time.Instance.NextDockAction)
                {
                    if (ESCache.Instance.InSpace)
                    {
                        if (_directEntity != null && IsValid)
                        {
                            if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                            {
                                if (DebugConfig.DebugInteractWithEve) Log.WriteLine("EntityCache: Dock: !OkToInteractWithEveNow");
                                return false;
                            }

                            if (!SafeToInitiateMovementCommand("Dock"))
                                return false;

                            if (!SafeToInitiateWarpJumpActivateCommand("Dock"))
                                return false;

                            if (_directEntity.Dock())
                            {
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                if (ESCache.Instance.EveAccount.IsLeader)
                                {
                                    if (ESCache.Instance.EveAccount.LeaderLastEntityIdDock != Id)
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdDock), Id);

                                    if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastDock.AddSeconds(10))
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastDock), DateTime.UtcNow);
                                }

                                if (ESCache.Instance.MyShipEntity != null)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.ShipType), ESCache.Instance.MyShipEntity.TypeName);
                                ESCache.Instance.ClearPerSystemCache("Dock()");
                                Drones.ResetInSpaceSettingsWhenEnteringStation();
                                Time.Instance.WehaveMoved = DateTime.UtcNow.AddDays(-7);
                                Time.Instance.NextDockAction = DateTime.UtcNow.AddSeconds(Time.Instance.DockingDelay_seconds);
                                Time.Instance.NextApproachAction = DateTime.UtcNow.AddSeconds(Time.Instance.DockingDelay_seconds);
                                Time.Instance.LastDockAction = DateTime.UtcNow;
                                Time.Instance.NextActivateModules = DateTime.UtcNow.AddSeconds(Time.Instance.TravelerJumpedGateNextCommandDelay_seconds);
                            }
                        }
                        return false;
                    }

                    return false;
                }
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool Jump()
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddMilliseconds(500))
                    return false;

                if (ESCache.Instance.EveAccount.DoNotSessionChange)
                {
                    Log.WriteLine("DoNotSessionChange: true - waiting for other EVE Accounts to completely login before session changing (avoid crashing...)");
                    return false;
                }

                if (DateTime.UtcNow > Time.Instance.NextJumpAction)
                {
                    if (ESCache.Instance.InSpace)
                    {
                        if (_directEntity != null && IsValid)
                        {
                            if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                                Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                              Math.Round(_directEntity.Distance / 1000, 0) +
                                              "k][" + MaskedId + "] was created more than 5 seconds ago (ugh!)");

                            if (Distance < 2500)
                            {
                                if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                                {
                                    if (DebugConfig.DebugInteractWithEve) Log.WriteLine("Jump: !OkToInteractWithEveNow");
                                    return false;
                                }

                                if (!SafeToInitiateMovementCommand("WarpTo"))
                                    return false;

                                if (!SafeToInitiateWarpJumpActivateCommand("WarpTo"))
                                    return false;

                                if (_directEntity.Jump())
                                {
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                    if (ESCache.Instance.EveAccount.LeaderLastEntityIdJump != Id)
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdJump), Id);

                                    if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastJump.AddSeconds(7))
                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastJump), DateTime.UtcNow);

                                    ESCache.Instance.ClearPerSystemCache("Jump()");
                                    Time.Instance.WehaveMoved = DateTime.UtcNow.AddDays(-7);
                                    Time.Instance.NextJumpAction = DateTime.UtcNow.AddSeconds(ESCache.Instance.RandomNumber(10, 15));
                                    Time.Instance.LastJumpAction = DateTime.UtcNow;
                                    Time.Instance.NextTravelerAction = DateTime.UtcNow.AddSeconds(Time.Instance.TravelerJumpedGateNextCommandDelay_seconds);
                                    Time.Instance.NextActivateModules = DateTime.UtcNow.AddSeconds(Time.Instance.TravelerJumpedGateNextCommandDelay_seconds);
                                    return true;
                                }
                            }

                            if (DebugConfig.DebugTraveler)
                                Log.WriteLine("we tried to jump through [" + Name + "] but it is [" + Math.Round(Distance / 1000, 2) + "k away][" + MaskedId +
                                              "]");
                            return false;
                        }

                        if (DebugConfig.DebugTraveler) Log.WriteLine("[" + Name + "] DirecEntity is null or is not valid");
                        return false;
                    }

                    if (DebugConfig.DebugTraveler) Log.WriteLine("We have not yet been in space for 2 seconds, waiting");
                    return false;
                }

                if (DebugConfig.DebugTraveler) Log.WriteLine("We just jumped. We should wait at least another [" + Math.Round(Time.Instance.NextJumpAction.Subtract(DateTime.UtcNow).TotalSeconds, 0) + "] sec before trying to jump again.");
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool KeepAtRange(int range, bool allowNegativeRanges = false, bool force = false)
        {
            try
            {
                if (DateTime.UtcNow > Time.Instance.NextApproachAction || force)
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                            Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                          Math.Round(_directEntity.Distance / 1000, 0) + "k][" +
                                          MaskedId + "] was created more than 5 seconds ago (ugh!)");

                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow && !force)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("EntityCache: KeepAtRange: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (!allowNegativeRanges && range < 0)
                            range = 0;

                        if (IsApproachedByActiveShip && !force)
                            return true;

                        //if (!IsApproachedByActiveShip && _directEntity.KeepAtRange(range))
                        if (_directEntity.KeepAtRange(range, force))
                        {
                            Log.WriteLine("KeepAtRange [" + range + "][" + Name + "] Current Distance [" + Math.Round(Distance / 1000, 0) + "k][" + MaskedId + "]");
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            Time.Instance.LastApproachAction = DateTime.UtcNow;
                            Time.Instance.NextApproachAction = DateTime.UtcNow.AddSeconds(Time.Instance.ApproachDelay_seconds + ESCache.Instance.RandomNumber(0, 2));
                            if (ESCache.Instance.EveAccount.IsLeader)
                            {
                                if (ESCache.Instance.EveAccount.LeaderLastEntityIdKeepAtRange != Id)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdKeepAtRange), Id);

                                if (ESCache.Instance.EveAccount.LeaderLastKeepAtRangeDistance != range)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastKeepAtRangeDistance), range);

                                if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastKeepAtRange.AddSeconds(5))
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastKeepAtRange), DateTime.UtcNow);
                            }

                            return true;
                        }

                        //Log.WriteLine("if (_directEntity.KeepAtRange(range))");
                        return false;
                    }

                    //Log.WriteLine("!if (_directEntity != null && IsValid)");
                    return false;
                }

                //Log.WriteLine("!if (DateTime.UtcNow > Time.Instance.NextApproachAction || force)");
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool LockTarget(string module)
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                if (DateTime.UtcNow < Time.Instance.NextTargetAction)
                    return false;

                if (ESCache.Instance.InsidePosForceField)
                    return false;

                if (_directEntity != null && IsValid)
                {
                    if (!IsTarget)
                    {
                        if (!HasExploded)
                        {
                            if (Distance < Combat.MaxTargetRange)
                            {
                                if (ESCache.Instance.Targets.Count() < ESCache.Instance.MaxLockedTargets)
                                {
                                    if (!IsTargeting)
                                    {
                                        if (ESCache.Instance.EntitiesOnGrid.Any(i => i.Id == Id))
                                        {
                                            if (ESCache.Instance.MyShipEntity.Id == Id && Distance == 0)
                                            {
                                                Log.WriteLine("[" + module + "] You cannot target yourself! aborting targeting attempt");
                                                return false;
                                            }

                                            if (IsBadIdea && !IsAttacking && State.CurrentHydraState != HydraState.Combat && ESCache.Instance.EveAccount.SelectedController != "CombatDontMoveController")
                                            {
                                                Log.WriteLine(
                                                    "[" + module + "] Attempted to target a player or concord entity! [" + Name + "] - aborting");
                                                return false;
                                            }

                                            if (Distance >= 250001 || Distance > Combat.MaxTargetRange)
                                            {
                                                Log.WriteLine("[" + module + "] tried to lock [" + Name + "] which is [" +
                                                              Math.Round(Distance / 1000, 2) +
                                                              "k] away. Do not try to lock things that you cant possibly target");
                                                return false;
                                            }

                                            foreach (
                                                EntityCache target in
                                                ESCache.Instance.EntitiesOnGrid.Where(e => e.IsTarget && ESCache.Instance.TargetingIDs.ContainsKey(e.Id)))
                                                ESCache.Instance.TargetingIDs.Remove(target.Id);

                                            if (ESCache.Instance.TargetingIDs.ContainsKey(Id))
                                            {
                                                DateTime lastTargeted = ESCache.Instance.TargetingIDs[Id];

                                                double seconds = DateTime.UtcNow.Subtract(lastTargeted).TotalSeconds;
                                                if (seconds < 20)
                                                {
                                                    Log.WriteLine("[" + module + "] tried to lock [" + Name + "][" + Math.Round(Distance / 1000, 2) +
                                                                  "k][" + MaskedId +
                                                                  "][" + ESCache.Instance.Targets.Count() + "] targets already, can reTarget in [" +
                                                                  Math.Round(20 - seconds, 0) + "]");
                                                    return false;
                                                }
                                            }

                                            if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                                            {
                                                if (DebugConfig.DebugInteractWithEve) Log.WriteLine("LockTarget: !OkToInteractWithEveNow");
                                                return false;
                                            }

                                            if (_directEntity.LockTarget())
                                            {
                                                Combat.PotentialCombatTargetsCount_AtLastLockedTarget = Combat.CurrentPotentialCombatTargetsCount;
                                                Time.Instance.NextTargetAction = DateTime.UtcNow.AddMilliseconds(Time.Instance.TargetDelay_milliseconds);
                                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                                                ESCache.Instance.TargetingIDs[Id] = DateTime.UtcNow;
                                                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "Target Locked"));
                                                if (!Statistics.BountyValues.ContainsKey(Id))
                                                    try
                                                    {
                                                        double bounty = _directEntity.GetBounty();
                                                        if (bounty > 0)
                                                        {
                                                            Log.WriteLine("Added bounty [" + bounty + "] for [" + Name + "] at [" + Math.Round(Distance / 1000, 0) + "k] Id [" + MaskedId + "] - locking target");
                                                            Statistics.BountyValues.AddOrUpdate(Id, bounty);
                                                        }
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        Log.WriteLine("Exception [" + ex + "]");
                                                    }
                                                return true;
                                            }

                                            Log.WriteLine("[" + module + "] tried to lock [" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" +
                                                          MaskedId + "][" +
                                                          ESCache.Instance.Targets.Count() + "] LockedTargets already, LockTarget failed (unknown reason)");
                                            return false;
                                        }

                                        Log.WriteLine("[" + module + "] tried to lock [" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" +
                                                      MaskedId +
                                                      "][" +
                                                      ESCache.Instance.Targets.Count() +
                                                      "] LockedTargets already, LockTarget failed: target was not in Entities List");
                                        return false;
                                    }

                                    Log.WriteLine("[" + module + "] tried to lock [" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" + MaskedId +
                                                  "][" +
                                                  ESCache.Instance.Targets.Count() +
                                                  "] targets already, LockTarget aborted: target is already being targeted");
                                    return false;
                                }

                                Log.WriteLine("[" + module + "] tried to lock [" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" + MaskedId +
                                              "][" +
                                              ESCache.Instance.Targets.Count() + "] targets already, we only have [" + ESCache.Instance.MaxLockedTargets +
                                              "] slots!");
                                return false;
                            }

                            Log.WriteLine("[" + module + "] tried to lock [" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" + MaskedId + "][" +
                                          ESCache.Instance.Targets.Count() + "] targets already, my targeting range is only [" +
                                          Math.Round(Combat.MaxTargetRange / 1000, 2) + "k]!");
                            return false;
                        }

                        Log.WriteLine("[" + module + "] tried to lock [" + Name + "][" + ESCache.Instance.Targets.Count() +
                                      "] targets already, target is already dead!");
                        return false;
                    }

                    Log.WriteLine("[" + module + "] LockTarget request has been ignored for [" + Name + "][" + Math.Round(Distance / 1000, 2) + "k][" +
                                  MaskedId + "][" +
                                  ESCache.Instance.Targets.Count() + "] targets already, target is already locked!");
                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool MakeActiveTarget()
        {
            return _directEntity.MakeActiveTarget();
        }

        public bool OpenCargo()
        {
            try
            {
                if (DateTime.UtcNow > Time.Instance.NextOpenCargoAction)
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("EntityCache: OpenCargo: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (_directEntity.OpenCargo())
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            Time.Instance.NextOpenCargoAction = DateTime.UtcNow.AddSeconds(2 + ESCache.Instance.RandomNumber(1, 3));
                            return true;
                        }

                        return false;
                    }

                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool Orbit(int orbitRange, bool forceOrbit = false, string LogMessage = "")
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                if (DateTime.UtcNow > Time.Instance.NextOrbit)
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                            Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                          Math.Round(_directEntity.Distance / 1000, 0) + "k][" +
                                          MaskedId + "] was created more than 5 seconds ago (ugh!)");

                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("EntityCache: Orbit: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (orbitRange <= 0) orbitRange = 500;
                        if (SafeToInitiateMovementCommand("Orbit") && _directEntity.Orbit(orbitRange))
                        {
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            if (ESCache.Instance.EveAccount.IsLeader)
                            {
                                if (ESCache.Instance.EveAccount.LeaderLastEntityIdOrbit != Id)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastEntityIdOrbit), Id);

                                if (ESCache.Instance.EveAccount.LeaderLastOrbitDistance != orbitRange)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastOrbitDistance), orbitRange);

                                if (DateTime.UtcNow > ESCache.Instance.EveAccount.LeaderLastOrbit.AddSeconds(3))
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderLastOrbit), DateTime.UtcNow);
                            }
                            if (!string.IsNullOrEmpty(LogMessage))
                                Log.WriteLine(LogMessage);
                            else
                                Log.WriteLine("Initiating Orbit [" + Name + "][" + Math.Round(Distance / 1000, 0) + "k] at [" + Math.Round((double)orbitRange / 1000, 0) + "k][" + MaskedId + "]");

                            Time.Instance.NextOrbit = DateTime.UtcNow.AddSeconds(5 + ESCache.Instance.RandomNumber(1, 5));
                            return true;
                        }

                        return false;
                    }

                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool? OrbitAt10KLessThanTarget(int distanceToCheck, int finalOrbitRange)
        {
            bool forceReOrbit = true;
            distanceToCheck = Math.Max(distanceToCheck, finalOrbitRange);

            if (Distance > distanceToCheck)
            {
                if (Orbit(distanceToCheck - 10000, forceReOrbit))
                {
                    if (finalOrbitRange == distanceToCheck) return true;
                    return false;
                }

                return false;
            }

            return null;
        }

        public bool SafeToInitiateMovementCommand(string module)
        {
            try
            {
                if (ESCache.Instance.AccelerationGates != null && ESCache.Instance.AccelerationGates.Any())
                {
                    if ((int)Distances.JumpRange > ESCache.Instance.AccelerationGates.FirstOrDefault().Distance)
                        return true;
                }

                if (DateTime.UtcNow < Time.Instance.LastInitiatedWarp.AddSeconds(6))
                {
                    if (DebugConfig.DebugTraveler) Log.WriteLine("SafeToInitiateMovementCommand: if (DateTime.UtcNow < Time.Instance.LastInitiatedWarp.AddSeconds(6)) waiting");
                    return false;
                }

                if (DateTime.UtcNow < Time.Instance.LastAlign.AddSeconds(1))
                {
                    if (DebugConfig.DebugTraveler) Log.WriteLine("SafeToInitiateMovementCommand: if (DateTime.UtcNow < Time.Instance.LastAlign.AddSeconds(4)) waiting");
                    return false;
                }

                if (DateTime.UtcNow < Time.Instance.LastApproachAction.AddSeconds(2))
                {
                    if (DebugConfig.DebugTraveler) Log.WriteLine("SafeToInitiateMovementCommand: if (DateTime.UtcNow < Time.Instance.LastApproachAction.AddSeconds(4)) waiting");
                    return false;
                }

                //if (DateTime.UtcNow < Time.Instance.LastOrbitAction.AddSeconds(15))
                //    return false;

                if (DateTime.UtcNow < Time.Instance.NextActivateAction)
                {
                    if (DebugConfig.DebugTraveler) Log.WriteLine("SafeToInitiateMovementCommand: if (DateTime.UtcNow < Time.Instance.NextActivateAction) waiting");
                    return false;
                }

                if (DateTime.UtcNow < Time.Instance.NextOrbit.AddSeconds(-5))
                {
                    if (DebugConfig.DebugTraveler) Log.WriteLine("SafeToInitiateMovementCommand: if (DateTime.UtcNow < Time.Instance.NextOrbit) waiting");
                    return false;
                }

                if (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile)
                {
                    if (DebugConfig.DebugTraveler) Log.WriteLine("SafeToInitiateMovementCommand: f (ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.IsImmobile)");
                    return false;
                }

                //if (DateTime.UtcNow < Time.Instance.LastDockAction.AddSeconds(15))
                //    return false;

                //if (DateTime.UtcNow < Time.Instance.LastJumpAction.AddSeconds(15))
                //    return false;

                return true;
            }
            catch (Exception)
            {
                return true;
            }
        }

        public bool SafeToInitiateWarpJumpActivateCommand(string module)
        {
            try
            {
                if (ESCache.Instance.EntitiesOnGrid.All(i => !i.IsWarpScramblingMe && i.WarpScrambleChance == 0))
                {
                    //
                    // If we are using drones and if drones are in space that are not incapacitated
                    //
                    if (Drones.UseDrones && Drones.ActiveDrones != null && Drones.ActiveDrones.Any() && Drones.ActiveDrones.All(i => i.StructurePct > .2))
                    {
                        Log.WriteLine("[" + module + "] We Attempted to warp with drones in space: Recall Drones");
                        Drones.RecallDrones();
                        return false;
                    }

                    //
                    // we are not warp scrambled and we have no drones out
                    //
                    return true;
                }

                //
                // we are warp scrambled!
                //
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return true;
            }
        }

        public bool SpiralInProgressively(int finalOrbitRange)
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.LastInWarp.AddSeconds(2))
                    return false;

                int DistanceToCheck = 100000;
                bool? spiralResult = OrbitAt10KLessThanTarget(DistanceToCheck, finalOrbitRange);
                //
                // null means we arent within that range (yet)
                //
                if (spiralResult == null) return false;
                //
                // true means we have reached the desired final orbit range
                //
                if ((bool)spiralResult) return true;
                //
                // false means we arent yet at the final distance, but we may have orbited at an intermediary distance ok...
                //
                DistanceToCheck = 90000;
                ///repeat for closer distances

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool UnlockTarget()
        {
            try
            {
                if (_directEntity != null && IsValid)
                {
                    if (IsTarget)
                    {
                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("UnlockTarget: !OkToInteractWithEveNow");
                            return false;
                        }

                        if (_directEntity.UnlockTarget())
                        {
                            Time.Instance.NextTargetAction = DateTime.UtcNow.AddMilliseconds(Time.Instance.TargetDelay_milliseconds);
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                            ESCache.Instance.TargetingIDs.Remove(Id);
                            DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "Unlocked Target"));
                            if (Statistics.BountyValues.ContainsKey(Id))
                                try
                                {
                                    double bounty = _directEntity.GetBounty();
                                    if (bounty > 0)
                                    {
                                        Log.WriteLine("Removed bounty [" + bounty + "] for [" + Name + "] at [" + Math.Round(Distance / 1000, 0) + "k] Id [" + MaskedId + "] - unlocking target");
                                        Statistics.BountyValues.Remove(Id);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.WriteLine("Exception [" + ex + "]");
                                }
                        }

                        return true;
                    }

                    return false;
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public bool WarpTo(double range = 0)
        {
            try
            {
                if (ESCache.Instance.InSpace)
                {
                    if (_directEntity != null && IsValid)
                    {
                        if (DateTime.UtcNow.AddSeconds(-5) > ThisEntityCacheCreated)
                        {
                            Log.WriteLine("The EntityCache instance that represents [" + _directEntity.Name + "][" +
                                          Math.Round(_directEntity.Distance / 1000, 0) +
                                          "k][" + MaskedId + "] was created more than 5 seconds ago (ugh!)");
                            ControllerManager.Instance.SetPause(true);
                        }

                        if (ESCache.Instance.EntitiesOnGrid.Any(i => i.IsWarpScramblingMe))
                            return false;

                        //ESCache.Instance.AttemptingToWarp = true;

                        if (Distance < (long)Distances.HalfOfALightYearInAu)
                        {
                            if (Distance > (int)Distances.WarptoDistance)
                            {
                                if (!SafeToInitiateMovementCommand("WarpTo"))
                                    return false;

                                if (!SafeToInitiateWarpJumpActivateCommand("WarpTo"))
                                    return false;

                                if (DebugConfig.DebugWarpCloakyTrick)
                                {
                                    if (!AlignTo())
                                    {
                                        if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: if (!AlignTo())");
                                        return false;
                                    }

                                    if (Defense.EntityThatMayDecloakMe != null && Defense.EntityThatMayDecloakMe.Distance >= (int)Distances.SafeToCloakDistance && (int)Defense.EntityThatMayDecloakMe.Distance != 0)
                                    {
                                        if (ESCache.Instance.Modules.Any(i => i.GroupId == (int)Group.CloakingDevice))
                                        {
                                            //
                                            // MWD
                                            //
                                            bool forceSpeedModToActivate = true;
                                            bool deactivsteSpeedModIfActive = true;
                                            if (!Defense.ActivateSpeedMod(forceSpeedModToActivate, deactivsteSpeedModIfActive))
                                                if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: if (!Defense.ActivateSpeedMod(forceSpeedModToActivate, deactivsteSpeedModIfActive))");

                                            //
                                            // Cloak / DeCloak
                                            //
                                            //bool deactivateCloakWhenSpeedModIsOff = true;
                                            //if (!Defense.ActivateCovopsCloak(deactivateCloakWhenSpeedModIsOff, true))
                                            //{
                                            //    if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: if (!Defense.ActivateCovopsCloak(deactivateCloakWhenSpeedModIsOff, warpCloakyTrick))");
                                            //    return false;
                                            //}

                                            if (ActuallyWarpTo())
                                            {
                                                if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: if (WarpTo())");
                                                return true;
                                            }

                                            if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: WarpTo() returned false");
                                            return true;
                                        }

                                        if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: we have no cloaking device: just warp");

                                        if (ActuallyWarpTo())
                                        {
                                            if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: if (WarpTo()).");
                                            return true;
                                        }
                                    }

                                    if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: we are too close to [" + Defense.EntityThatMayDecloakMe.Name + "][" + Math.Round(Defense.EntityThatMayDecloakMe.Distance, 0) + "m] to even try to cloak. just warp.");
                                }

                                if (ActuallyWarpTo())
                                {
                                    if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: if (WarpTo()).");
                                    return true;
                                }

                                if (DebugConfig.DebugTraveler) Log.WriteLine("WarpTo: WarpTo() returned false.");
                                return false;
                            }

                            Log.WriteLine("[" + Name + "] Distance [" + Math.Round(Distance / 1000, 0) +
                                          "k] is not greater then 150k away, AlignCloakMWDDeCloakWarp aborted!");
                            return false;
                        }

                        Log.WriteLine("[" + Name + "] Distance [" + Math.Round(Distance / 1000, 0) +
                                      "k] was greater than 5000AU away, we assume this an error!, AlignCloakMWDDeCloakWarp aborted!");
                        return false;
                    }

                    Log.WriteLine("[" + Name + "] DirecEntity is null or is not valid");
                    return false;
                }

                Log.WriteLine("We have not yet been in space at least 2 seconds, waiting");
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        #endregion Methods
    }

    public static class CombatMath
    {
        /// <summary>
        /// Calculate the damage done by a missile
        /// https://wiki.eveuniversity.org/Missile_mechanics#Missile_damage_formula
        /// </summary>
        /// <param name="missileBaseDamage">The base damage of the missile, of a particular damage type</param>
        /// <param name="missileDamageReductionFactor">The Damage Reduction Factor of the missile</param>
        /// <param name="missileExplosionRadius">THe Explosion Radius of the missile</param>
        /// <param name="missileExplosionVelocity">The Explosion Velocity of the missile</param>
        /// <param name="targetSigRadius">The Signature Radius of the target</param>
        /// <param name="targetVelocity">The Velocity of the target</param>
        /// <returns>The final damage dealt by the missile impact</returns>
        public static double MissileDamageCalc(
            double missileBaseDamage,
            double missileDamageReductionFactor,
            double missileExplosionRadius,
            double missileExplosionVelocity,
            double targetSigRadius,
            double targetVelocity
        )
        {
            // To prevent doing damage greater than the missile's base damage, return the smallest out of:
            // 1 (full damage)
            // Sig Radius / Explosion Radius (signature radius is larger than the explosion radius)
            // The full calculation
            return missileBaseDamage * Math.Min(
                       1,
                       Math.Min(
                           (targetSigRadius * missileExplosionRadius),
                           Math.Pow((targetSigRadius / missileExplosionRadius) * (missileExplosionVelocity / targetVelocity), missileDamageReductionFactor)
                       )
                   );
        }

        /// <summary>
        /// Calculate the range of a missile.
        /// https://wiki.eveuniversity.org/Eve_Math#Missiles
        /// Note that EVE servers operate on 1-second intervals. A missile with a flight time of 12.3 seconds has
        /// a 70% chance of flying for 12 seconds and a 30% probability of flying for 13 seconds.
        /// </summary>
        /// <param name="missileFlightTime"></param>
        /// <param name="missileVelocity"></param>
        /// <returns></returns>
        public static double MissileFlightTimeCalc(double missileFlightTime, double missileVelocity)
        {
            return missileFlightTime * missileVelocity;
        }

        /// <summary>
        /// <para>Calculate the chance for a turret to hit something</para>
        /// <para>https://wiki.eveuniversity.org/Turret_Damage#Tracking</para>
        /// </summary>
        /// <param name="targetAngularVelocity">The angular velocity of the target, relative to the shooter</param>
        /// <param name="targetSigRadius">The target's signature radius</param>
        /// <param name="targetDistance">The target's distance from teh shooter</param>
        /// <param name="turretTrackingSpeed">The turret's tracking speed</param>
        /// <param name="turretOptimalRange">The turret's optimal range</param>
        /// <param name="turretFalloff">The turret's falloff range</param>
        /// <returns>The chance to hit (e.g. 0.5 = 50%)</returns>
        public static double TurretChanceToHit(
            double targetAngularVelocity,
            double targetSigRadius,
            double targetDistance,
            double turretTrackingSpeed,
            double turretOptimalRange,
            double turretFalloff)
        {
            // How likely it is to hit the target with how fast the target is moving in relation to the ship doing the shooting
            double trackingTerm = 0.5 * ((targetAngularVelocity * 40000) / (turretTrackingSpeed * targetSigRadius));

            // How likely it is to hit the target at the distance it is
            // 100% within optimal range
            // about 50% at optimal + under half of falloff
            // about 6.5% @ optimal + over half of falloff
            // about 0.2% @ optimal + falloff
            double rangeTerm = 0.5 * ((Math.Max(0, targetDistance - turretOptimalRange)) / turretFalloff);

            return trackingTerm * rangeTerm;
        }

        /// <summary>
        /// Get a rough estimate of Effective Hit Points; the ship's hit points (shield, armor, or hull) with your resistance applied.
        /// </summary>
        /// <example>1000 shields, 50% EM res., 60% Therm res. 60% Exp res., 70% Kin res., 60% averaged shield resistance.
        /// EffectiveHitPointsSimple(1000, 0.5, 0.6, 0.6, 0.7) = 1500 EHP</example>
        /// <param name="baseHP">The total hit points of shields, armor, or hull</param>
        /// <param name="resistEM">The EM resistance modifier</param>
        /// <param name="resistExp">The Explosive resistance modifier</param>
        /// <param name="resistTherm">The Thermal resistance modifier</param>
        /// <param name="resistKin">The Kinetic resistance modifier</param>
        /// <returns></returns>
        public static double EffectiveHitPoints(
            double baseHP,
            double resistEM,
            double resistExp,
            double resistTherm,
            double resistKin
        )
        {
            double averageResistance = (resistEM + resistExp + resistTherm + resistKin) / 4; //Get your average resistance
            return baseHP * (1 + averageResistance);
        }

        /// <summary>
        /// Get an estimate of Effective Hit Points; the ship's hit points (shield, armor, or hull) with your resistance applied.
        /// </summary>
        /// <param name="baseHP">The total hit points of shields, armor, or hull</param>
        /// <param name="resistEM">The EM resistance modifier</param>
        /// <param name="resistExp">The Explosive resistance modifier</param>
        /// <param name="resistTherm">The Thermal resistance modifier</param>
        /// <param name="resistKin">The Kinetic resistance modifier</param>
        /// <param name="attackEM">The percentage of incoming EM damage</param>
        /// <param name="attackExp">The percentage of incoming Explosive damage</param>
        /// <param name="attackTherm">The percentage of incoming Thermal damage</param>
        /// <param name="attackKin">The percentage of incoming Kinetic damage</param>
        /// <returns></returns>
        public static double EffectiveHitPoints(
            double baseHP,
            double resistEM,
            double resistExp,
            double resistTherm,
            double resistKin,
            double attackEM,
            double attackExp,
            double attackTherm,
            double attackKin
        )
        {
            return baseHP *
                   (1 + resistEM - attackEM) *
                   (1 + resistExp - attackExp) *
                   (1 + resistTherm - attackTherm) *
                   (1 + resistKin - attackKin);
        }

        // https://forums.eveonline.com/t/targeting-time-locking-time-calculation/91133
        // =40000/(ScanRes*ASINH(SigRadius)^2)
        /// <summary>
        /// Calculate how long in seconds it will take for a ship to lock a target, in seconds.
        /// Due to how EVE's servers operate in 'ticks', time is rounded to the next second (e.g. 3.36s becomes 4s).
        /// </summary>
        /// <param name="shipScanResolution">The targetting resolution of the ship doing the targetting, in millimetres</param>
        /// <param name="targetSignatureRadius">The signature resolution of thie ship being targetted, in metres</param>
        /// <returns></returns>
        public static int LockTime(
            int shipScanResolution,
            int targetSignatureRadius
        )
        {
            // The C# Math library doesn't have a function for ArcSinH, so we'll calculate it ourselves
            // If you're doing this equation in Excel or anothe language which has asinh, just use that
            // https://www.codeproject.com/Articles/86805/An-introduction-to-numerical-programming-in-C
            // asinh(x) = log(x + sqrt(x2 + 1))
            double sigRadiusAsinh = Math.Log(targetSignatureRadius + Math.Sqrt(Math.Pow(targetSignatureRadius, 2) + 1));

            return (int)Math.Ceiling(40000 / (shipScanResolution * Math.Pow(sigRadiusAsinh, 2)));
        }

        #region EWarAndLogistics

        // Most of the EWar math comes from
        // https://wiki.eveuniversity.org/Electronic_warfare

        // Most of the logistics information comes from
        // https://wiki.eveuniversity.org/Guide_to_Logistics
        // https://forums-archive.eveonline.com/message/6306658/

        /// <summary>
        /// <para>Get the probability of an ECM jammer sucessfully jamming a target, based on the target's distance & sensor power vs the jammer's range and strength.</para>
        /// <para>When an ECM jammer cycles, it "rolls the die" against this probability of success.</para>
        /// </summary>
        /// <param name="jammerStrength">The ECM jammer's strength against the target's sensor type, after bonuses and range effects are applied.</param>
        /// <param name="targetSensorStrength">The target's sensor strength, after bonuses are applied.</param>
        /// <param name="jammerAccuracyFalloff">The jammer's effective accuracy falloff distance.</param>
        /// <param name="jammerOptimalRange">The jammer's optimal range.</param>
        /// <param name="targetDistance">The target's distance from the jamming ship.</param>
        /// <returns>The probabilty of the ECM jammer successfully jamming the target, as a number between 0 and 1.</returns>
        public static double EcmChanceToJam(
            double jammerStrength,
            double jammerOptimalRange,
            double jammerAccuracyFalloff,
            double targetSensorStrength,
            double targetDistance
        )
        {
            // Jammer strength vs the target's sensor strength
            double strengthTerm = jammerStrength / targetSensorStrength;

            //How strong or weak the jammer is because of range
            double rangeTerm = EWarAndLogisticsEffectiveness(jammerOptimalRange, jammerAccuracyFalloff, targetDistance);

            return 1 * strengthTerm * rangeTerm;
        }

        /// <summary>
        /// <para>Calculate the effectiveness modifier, depending on the module's range and the targets distance.</para>
        /// <para>This applies to electronic warfare modules (e.g. target painters, tracking disruptors, sensor dampeners) as well as logistics modules (e.g. remote repair, sensor booter).</para>
        /// <para>Note that it uses a similar calculation to turret range and accuracy, however angular velocity and signature radius has no effect.</para>
        /// <para>For ECM jmmers, use <seealso cref="EcmChanceToJam"./></para>
        /// </summary>
        /// <param name="moduleOptimalRange">The module's effective optimal range.</param>
        /// <param name="moduleAccuracyFalloff">The module's effective accuracy falloff distance.</param>
        /// <param name="targetDistance">The targets distance from the ship.</param>
        /// <returns>The effectiveness of the module, as a number between 0 and 1.</returns>
        public static double EWarAndLogisticsEffectiveness(
            double moduleOptimalRange,
            double moduleAccuracyFalloff,
            double targetDistance
        )
        {
            //How strong or weak the module's effect is because of range
            // 100% within optimal range
            // about 50% at optimal + under half of falloff
            // about 6.5% @ optimal + over half of falloff
            // about 0.2% @ optimal + falloff
            return 0.5 * ((Math.Max(0, targetDistance - moduleOptimalRange)) / moduleAccuracyFalloff);
        }


        #endregion
    }
}