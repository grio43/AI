using EVESharpCore.Framework;
using EVESharpCore.Logging;
using System;
using Action = EVESharpCore.Questor.Actions.Base.Action;

namespace EVESharpCore.Questor.Actions
{
    public partial class ActionControl
    {
        #region Methods

        private static void ReloadAllAction(Action action, DirectAgentMission myMission, DirectAgent myAgent)
        {
            try
            {
                if (DateTime.UtcNow < _nextCombatMissionCtrlAction)
                    return;

                Log.WriteLine("Reload All Action"); // reload ammo
                //if (!Combat.Combat.ReloadAll()) return; // reload ammo
                Combat.Combat.ReloadAllWeaponsWithSameAmmoUsingCmdReloadAmmo();
                Log.WriteLine("Done reloading"); // reload ammo
                Nextaction(myMission, myAgent, true);
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        #endregion Methods
    }
}