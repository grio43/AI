﻿/*
* ---------------------------------------
* User: duketwo
* Date: 12.12.2013
* Time: 12:51
*
* ---------------------------------------
*/

using SharedComponents.Py.D3DDetour;
using System;

namespace HookManager.Win32Hooks
{
    public class D3DDetourController : IHook, IDisposable
    {
        #region Constructors

        public D3DDetourController()
        {
            Name = typeof(D3DDetourController).Name;
            Error = false;
            StandaloneFrameworkRef = new StandaloneFramework(HookManagerImpl.Instance.EveAccount.DX11 ? D3DVersion.Direct3D11 : D3DVersion.Direct3D9);
            StandaloneFrameworkRef.RegisterFrameHook(OnFrameDelegate);
        }

        #endregion Constructors

        #region Properties

        public bool Error { get; set; }
        public string Name { get; set; }
        public StandaloneFramework StandaloneFrameworkRef { get; set; }
        private DateTime LastPulse { get; set; }

        #endregion Properties

        #region Methods

        public void Dispose()
        {
            StandaloneFrameworkRef.Dispose();
        }

        private void OnFrameDelegate(object sender, EventArgs eventArgs)
        {
            //using (var pySharp = new PySharp(true))
            //{
            //    dynamic ps = pySharp;
            //}
        }

        #endregion Methods
    }
}