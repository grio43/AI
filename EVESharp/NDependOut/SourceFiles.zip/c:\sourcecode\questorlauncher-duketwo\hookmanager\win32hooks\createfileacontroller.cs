﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 12.12.2013
 * Time: 12:51
 *
 * ---------------------------------------
 */

using EasyHook;
using System;
using System.IO;
using System.Runtime.InteropServices;

namespace HookManager.Win32Hooks
{
    /// <summary>
    ///     Description of IsDebuggerPresent.
    /// </summary>
    public class CreateFileAController : IHook, IDisposable
    {
        #region Fields

        private readonly LocalHook _hook;

        #endregion Fields

        #region Constructors

        public CreateFileAController()
        {
            Error = false;
            Name = typeof(CreateFileAController).Name;

            try
            {
                _hook = LocalHook.Create(
                    LocalHook.GetProcAddress("kernel32.dll", "CreateFileA"),
                    new CreateFileADelegate(CreateFileADetour),
                    this);

                _hook.ThreadACL.SetExclusiveACL(new int[] { });
                Error = false;
            }
            catch (Exception)
            {
                Error = true;
            }
        }

        #endregion Constructors

        #region Delegates

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi, SetLastError = true)]
        private delegate IntPtr CreateFileADelegate(
            string InFileName,
            uint InDesiredAccess,
            uint InShareMode,
            IntPtr InSecurityAttributes,
            uint InCreationDisposition,
            uint InFlagsAndAttributes,
            IntPtr InTemplateFile);

        #endregion Delegates

        #region Properties

        public bool Error { get; set; }
        public string Name { get; set; }

        #endregion Properties

        #region Methods

        public static bool IsRead(uint InDesiredAccess)
        {
            return InDesiredAccess == 2147483648 || InDesiredAccess == 131072 || InDesiredAccess == 256;
        }

        // GENERIC_WRITE = 1073741824
        // GENERIC READ+WRITE = 0xC0000000 -> 3221225472
        // fILE_ATTRIBUTE_TEMPORARY      =  256
        // sTANDARD_RIGHTS_READ      =  131072
        public static bool IsWrite(uint InDesiredAccess)
        {
            return InDesiredAccess == 1073741824 || InDesiredAccess == 3221225472;
        }

        public void Dispose()
        {
            _hook.Dispose();
        }

        [DllImport("kernel32.dll",
            CharSet = CharSet.Ansi,
            SetLastError = true,
            CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr CreateFile(
            string InFileName,
            uint InDesiredAccess,
            uint InShareMode,
            IntPtr InSecurityAttributes,
            uint InCreationDisposition,
            uint InFlagsAndAttributes,
            IntPtr InTemplateFile);

        private static IntPtr CreateFileADetour(
            string InFileName,
            uint InDesiredAccess,
            uint InShareMode,
            IntPtr InSecurityAttributes,
            uint InCreationDisposition,
            uint InFlagsAndAttributes,
            IntPtr InTemplateFile)
        {
            if (HookManagerImpl.Instance.EveWndShown)
                try
                {
                    string inFileName = InFileName;
                    uint inDesiredAccess = InDesiredAccess;
                    string fileName = Path.GetFileName(inFileName);
                    string pathName = Path.GetDirectoryName(inFileName);

                    if (HookManagerImpl.IsBacklistedDirectory(pathName))
                        HookManagerImpl.Log("[BLACKLISTED_FILE] " + pathName + "\\" + fileName + " [DESIRED_ACCESS] " + inDesiredAccess);

                    bool isRead = IsRead(inDesiredAccess);
                    bool isWrite = IsWrite(inDesiredAccess);

                    if (isRead && HookManagerImpl.IsWhiteListedReadDirectory(pathName))
                    {
                        //	HookManager.Log("[Whitelisted] CreateFileWDetour-lpFileName(READ): " + pathName + "\\" + fileName + " Desired Access: " + InDesiredAccess.ToString());
                    }
                    else
                    {
                        if (isWrite && HookManagerImpl.IsWhiteListedWriteDirectory(pathName))
                        {
                            //	HookManager.Log("[Whitelisted] CreateFileWDetour-lpFileName(WRITE): " + pathName + "\\" + fileName + " Desired Access: " + InDesiredAccess.ToString());
                        }
                        else
                        {
                            if (inDesiredAccess != 0)
                            {
                                string t = isRead ? "READ" : "WRITE";
                                HookManagerImpl.Log("[NOT_WHITELISTED_FILE] " + pathName + "\\" + fileName + " [DESIRED_ACCESS] " + t);
                                //return new IntPtr(-1);
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    HookManagerImpl.Log("Exception:  " + e);
                }

            IntPtr ret = CreateFile(InFileName, InDesiredAccess, InShareMode, InSecurityAttributes, InCreationDisposition, InFlagsAndAttributes, InTemplateFile);
            return ret;
        }

        #endregion Methods
    }
}