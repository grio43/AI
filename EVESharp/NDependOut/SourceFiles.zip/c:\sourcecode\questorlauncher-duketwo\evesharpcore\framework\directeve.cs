﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using EVESharpCore.Cache;
using EVESharpCore.Framework.Events;
using EVESharpCore.Lookup;
using SC::SharedComponents.EVE;
using SC::SharedComponents.Events;
using SC::SharedComponents.Extensions;
using SC::SharedComponents.IPC;
using SC::SharedComponents.Py;
using SC::SharedComponents.Py.Frameworks;
using SC::SharedComponents.WinApiUtil;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectEveEventArgs : EventArgs
    {
        public DirectEveEventArgs(long lastFrameTook)
        {
            LastFrameTook = lastFrameTook;
        }

        public long LastFrameTook { get; }
    }

    public class DirectEve : IDisposable
    {
        private static Dictionary<string, ulong> _hasFrameChangedCallerDictionary = new Dictionary<string, ulong>();

        private static readonly Stopwatch eveFrameSt = new Stopwatch();

        private static long _ballParkCount;

        private static readonly List<string> _servicesAdditionalRequirementsCallOnlyOnce = new List<string>();

        private static readonly Dictionary<int, string> _localizationMessageByIdStorage = new Dictionary<int, string>();

        private static readonly Dictionary<string, DateTime> _intervalDict = new Dictionary<string, DateTime>();

        private static readonly Random _random = new Random();

        /// <summary>
        ///     Item container cache
        /// </summary>
        private readonly Dictionary<long, DirectContainer> _containers;

        private readonly bool _enableStatisticsModifying;

        /// <summary>
        ///     Info on when a certain target was last targeted
        /// </summary>
        private readonly Dictionary<long, DateTime> _lastKnownTargets;

        ////Statistic variables

        private readonly Dictionary<long, DateTime> _lastSeenEffectActivating;

        /// <summary>
        ///     Cache the LocalSvc objects
        /// </summary>
        private readonly Dictionary<string, PyObject> _localSvcCache;

        private readonly Dictionary<DirectCmd, DateTime> _nextDirectCmdExec;

        private readonly List<string> _servicesToLoad = new List<string> { "agents" };

        /// <summary>
        ///     Info on when a target was in targetsBeingRemoved set
        /// </summary>
        private readonly Dictionary<long, DateTime> _targetsBeingRemoved;

        //private DirectEveSecurity _security;
        //private bool _securityCheckFailed;

        /// <summary>
        ///     ActiveShip cache
        /// </summary>
        private DirectActiveShip _activeShip;

        /// <summary>
        ///     Cache the Agent Missions
        /// </summary>
        private List<DirectAgentMission> _agentMissions;

        /// <summary>
        ///     Cache the Bookmark Folders
        /// </summary>
        private List<DirectBookmarkFolder> _bookmarkFolders;

        /// <summary>
        ///     Cache the Bookmarks
        /// </summary>
        private List<DirectBookmark> _bookmarks;

        /// <summary>
        ///     Const cache
        /// </summary>
        private DirectConst _const;

        /// <summary>
        ///     Cache the GetConstellations call
        /// </summary>
        private Dictionary<long, DirectConstellation> _constellations;

        private DirectContract _directContract;

        private DirectPlexVault _directPlexVault;

        /// <summary>
        ///     Cache the Entities
        /// </summary>
        private Dictionary<long, DirectEntity> _entitiesById;

        private double _frameTimeAbove100ms;
        private double _frameTimeAbove200ms;
        private double _frameTimeAbove300ms;
        private double _frameTimeAbove400ms;
        private double _frameTimeAbove500ms;

        /// <summary>
        ///     The framework object that wraps OnFrame and Log
        /// </summary>
        private IFramework _framework;

        private Dictionary<string, int> _invtypeNames;

        /// <summary>
        ///     Item Hangar container cache
        /// </summary>
        private DirectContainer _itemHangar;

        /// <summary>
        ///     Global Assets cache
        /// </summary>
        private List<DirectItem> _listGlobalAssets;

        private LockedItemState _lockedItemState;

        /// <summary>
        ///     Login cache
        /// </summary>
        private DirectLogin _login;

        /// <summary>
        ///     Market Window cache
        /// </summary>
        private DirectMarketWindow _marketWindow;

        /// <summary>
        ///     Me cache
        /// </summary>
        private DirectMe _me;

        private List<DirectWindow> _modalWindows;

        /// <summary>
        ///     Cache the Windows
        /// </summary>
        private List<DirectModule> _modules;

        /// <summary>
        ///     Navigation cache
        /// </summary>
        private DirectNavigation _navigation;

        private DirectNewEdenStore _newEdenStore;

        private double _prevFrameTimeAbove100ms;
        private double _prevFrameTimeAbove200ms;
        private double _prevFrameTimeAbove300ms;
        private double _prevFrameTimeAbove400ms;
        private double _prevFrameTimeAbove500ms;
        private double _prevtimesliceWarnings;

        /// <summary>
        ///     Cache the GetRegions call
        /// </summary>
        private Dictionary<long, DirectRegion> _regions;

        /// <summary>
        ///     Session cache
        /// </summary>
        private DirectSession _session;

        /// <summary>
        ///     Ship Hangar container cache
        /// </summary>
        private DirectContainer _shipHangar;

        /// <summary>
        ///     Ship's cargo container cache
        /// </summary>
        private DirectContainer _shipsCargo;

        /// <summary>
        ///     Ship's drone bay cache
        /// </summary>
        private DirectContainer _shipsDroneBay;

        /// <summary>
        ///     Ship's fleet hangar cache
        /// </summary>
        private DirectContainer _shipsFleetHangar;

        /// <summary>
        ///     Ship's modules container cache
        /// </summary>
        private DirectContainer _shipsModules;

        /// <summary>
        ///     Ship's ore hold container cache
        /// </summary>
        private DirectContainer _shipsOreHold;

        private DirectSkills _skills;

        private DirectWallet _wallet;

        /// <summary>
        ///     Cache the GetRegions call
        /// </summary>
        private Dictionary<int, DirectSolarSystem> _solarSystems;

        /// <summary>
        ///     Standings cache
        /// </summary>
        private DirectStandings _standings;

        /// <summary>
        ///     Cache the GetStations call
        /// </summary>
        private Dictionary<int, DirectStation> _stations;

        private double _timesliceWarnings;
        private DateTime _waitForLockedItemsUntil;

        /// <summary>
        ///     Cache the GetWindows call
        /// </summary>
        private List<DirectWindow> _windows;

        private IEnumerable<DirectAgent> listDirectAgentsTypeDistribution;

        //public HashSet<long> DronesWeHaveLaunched = new HashSet<long>();

        /// <summary>
        ///     Create a DirectEve object
        /// </summary>
        public DirectEve(IFramework framework = null, bool enableStatisticModifying = true)
        {
            _enableStatisticsModifying = enableStatisticModifying;

            // create an instance of IFramework
            if (framework != null)
                _framework = framework;

            try
            {
                _localSvcCache = new Dictionary<string, PyObject>();
                _containers = new Dictionary<long, DirectContainer>();
                _lastKnownTargets = new Dictionary<long, DateTime>();
                _targetsBeingRemoved = new Dictionary<long, DateTime>();
                _nextDirectCmdExec = new Dictionary<DirectCmd, DateTime>();
                _lastSeenEffectActivating = new Dictionary<long, DateTime>();

#if DEBUG
                //Log("Registering OnFrame event");
#endif
                _framework.RegisterFrameHook(FrameworkOnFrame);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///     Return a DirectConst object
        /// </summary>
        internal DirectConst Const => _const ?? (_const = new DirectConst(this));

        /// <summary>
        ///     Return a DirectNavigation object
        /// </summary>
        public DirectLogin Login => _login ?? (_login = new DirectLogin(this));

        public long GetLastFrameExecutionDuration { get; private set; }

        /// <summary>
        ///     Return a DirectNavigation object
        /// </summary>
        public DirectNavigation Navigation => _navigation ?? (_navigation = new DirectNavigation(this));

        public DirectContract DirectContract => _directContract ?? (_directContract = new DirectContract(this));

        /// <summary>
        ///     Return a DirectMe object
        /// </summary>
        public DirectMe Me => _me ?? (_me = new DirectMe(this));

        public DirectPlexVault PlexVault => _directPlexVault ?? (_directPlexVault = new DirectPlexVault(this));

        /// <summary>
        ///     Return a DirectStandings object
        /// </summary>
        public DirectStandings Standings => _standings ?? (_standings = new DirectStandings(this));

        /// <summary>
        ///     Return a DirectActiveShip object
        /// </summary>
        public DirectActiveShip ActiveShip => _activeShip ?? (_activeShip = new DirectActiveShip(this));

        /// <summary>
        ///     Return a DirectSession object
        /// </summary>
        public DirectSession Session => _session ?? (_session = new DirectSession(this));

        /// <summary>
        ///     Return a DirectSkills object
        /// </summary>
        public DirectSkills Skills => _skills ?? (_skills = new DirectSkills(this));

        /// <summary>
        ///     Return a DirectWallet object
        /// </summary>
        public DirectWallet Wallet => _wallet ?? (_wallet = new DirectWallet(this));

        /// <summary>
        ///     Internal reference to the PySharp object that is used for the frame
        /// </summary>
        /// <remarks>
        ///     This reference is only valid while in an OnFrame event
        /// </remarks>
        public PySharp PySharp { get; private set; }

        /// <summary>
        ///     Return a list of entities
        /// </summary>
        /// <value></value>
        /// <remarks>
        ///     Only works in space
        /// </remarks>
        public List<DirectEntity> Entities => EntitiesById.Values.ToList();

        /// <summary>
        ///     Return a dictionary of entities by id
        /// </summary>
        /// <value></value>
        /// <remarks>
        ///     Only works in space
        /// </remarks>
        public Dictionary<long, DirectEntity> EntitiesById
        {
            get
            {
                if (_entitiesById == null)
                    _entitiesById = DirectEntity.GetEntities(this);
                return _entitiesById;
            }
        }

        /// <summary>
        ///     The last bookmark update
        /// </summary>
        public DateTime LastBookmarksUpdate => DirectBookmark.GetLastBookmarksUpdate(this) ?? new DateTime(0, 0, 0);

        /// <summary>
        ///     Return a list of bookmarks
        /// </summary>
        /// <value></value>
        public List<DirectBookmark> Bookmarks => _bookmarks ?? (_bookmarks = DirectBookmark.GetBookmarks(this));

        /// <summary>
        ///     Return a list of bookmark folders
        /// </summary>
        /// <value></value>
        public List<DirectBookmarkFolder> BookmarkFolders => _bookmarkFolders ?? (_bookmarkFolders = DirectBookmark.GetFolders(this));

        /// <summary>
        ///     Return a list of agent missions
        /// </summary>
        /// <value></value>
        public List<DirectAgentMission> AgentMissions => _agentMissions ?? (_agentMissions = DirectAgentMission.GetAgentMissions(this));

        /// <summary>
        ///     Return a list of all open windows
        /// </summary>
        /// <value></value>
        public List<DirectWindow> Windows
        {
            get
            {
                try
                {
                    if (_windows != null)
                    {
                        return _windows;
                    }

                    _windows = DirectWindow.GetWindows(this) ?? new List<DirectWindow>();
                    return _windows;
                }
                catch (InvalidOperationException)
                {
                    return new List<DirectWindow>();
                }
                catch (Exception ex)
                {
                    Log("Exception [" + ex + "]");
                    return new List<DirectWindow>();
                }
            }
        }

        public List<DirectChatWindow> ChatWindows
        {
            get
            {
                try
                {
                    List<DirectWindow> windows = new List<DirectWindow>();
                    List<DirectChatWindow> chatChannels = new List<DirectChatWindow>();
                    windows.AddRange(Windows.Where(w => w.Name.StartsWith("chatchannel_")));

                    foreach (DirectWindow w in windows)
                    {
                        DirectChatWindow c = (DirectChatWindow)w;
                        chatChannels.Add(c);
                    }

                    return chatChannels;
                }
                catch (Exception ex)
                {
                    Log("Exception [" + ex + "]");
                    return new List<DirectChatWindow>();
                }
            }
        }

        public string GetLocalizationMessageByLabel(string label)
        {
            if (_localizationMessageByLabelStorage.TryGetValue(label, out var val))
            {
                return val;
            }
            var r = PySharp.Import("localization").Call("GetByLabel", label).ToUnicodeString();
            _localizationMessageByLabelStorage[label] = r;
            return r;
        }

        private static Dictionary<string, string> _localizationMessageByLabelStorage = new Dictionary<string, string>();

        /// <summary>
        ///     Return a list of all open modal/dialog windows
        /// </summary>
        /// <value></value>
        public List<DirectWindow> ModalWindows => _modalWindows ?? (_modalWindows = DirectWindow.GetModalWindows(this));

        /// <summary>
        ///     Return a list of all modules
        /// </summary>
        /// <value></value>
        /// <remarks>
        ///     Only works inspace and does not return hidden modules
        /// </remarks>
        public List<DirectModule> Modules => _modules ?? (_modules = DirectModule.GetModules(this));

        /// <summary>
        ///     Return active drone id's
        /// </summary>
        /// <value></value>
        public List<DirectEntity> ActiveDrones
        {
            get
            {
                Dictionary<long, PyObject>.KeyCollection droneIds = GetLocalSvc("michelle").Call("GetDrones").Attribute("items").ToDictionary<long>().Keys;
                return Entities.Where(e => droneIds.Any(d => d == e.Id)).ToList();
            }
        }

        public DirectNewEdenStore NewEdenStore => _newEdenStore ?? (_newEdenStore = new DirectNewEdenStore(this));

        /// <remarks>
        ///     This is cached throughout the existance of this DirectEve Instance
        /// </remarks>
        public Dictionary<int, DirectStation> Stations => _stations ?? (_stations = DirectStation.GetStations(this));

        /// <summary>
        ///     Return a dictionary of solar systems
        /// </summary>
        /// <remarks>
        ///     This is cached throughout the existance of this DirectEve Instance
        /// </remarks>
        public Dictionary<int, DirectSolarSystem> SolarSystems => _solarSystems ?? (_solarSystems = DirectSolarSystem.GetSolarSystems(this));

        /// <summary>
        ///     Return a dictionary of solar systems
        /// </summary>
        /// <remarks>
        ///     This is cached throughout the existance of this DirectEve Instance
        /// </remarks>
        public Dictionary<long, DirectConstellation> Constellations => _constellations ?? (_constellations = DirectConstellation.GetConstellations(this));

        /// <summary>
        ///     Return a dictionary of solar systems
        /// </summary>
        /// <remarks>
        ///     This is cached throughout the existance of this DirectEve Instance
        /// </remarks>
        public Dictionary<long, DirectRegion> Regions => _regions ?? (_regions = DirectRegion.GetRegions(this));

        public static Dictionary<Tuple<long, string>, CourierMissionCtrlState> DictCurrentCourierMissionCtrlState { get; set; } = new Dictionary<Tuple<long, string>, CourierMissionCtrlState>();

        public static Dictionary<Tuple<long, string>, CourierMissionCtrlState> DictPreviousCourierMissionCtrlState { get; set; } = new Dictionary<Tuple<long, string>, CourierMissionCtrlState>();

        public static Dictionary<Tuple<long, string>, Faction> DictCurrentMissionFaction { get; set; } = new Dictionary<Tuple<long, string>, Faction>();
        public static Dictionary<long, DirectItem> DictCurrentCourierMissionItemToMove { get; set; } = new Dictionary<long, DirectItem>();
        public static Dictionary<long, string> DictCurrentCourierMissionToContainer { get; set; } = new Dictionary<long, string>();
        public static Dictionary<long, string> DictCurrentCourierMissionFromContainer { get; set; } = new Dictionary<long, string>();

        /// <summary>
        ///     Is EVE rendering 3D, you can enable/disable rendering by setting this value to true or false
        /// </summary>
        /// <remarks>
        ///     This used SceneName to determine what 'scene' you are in to enable/disable 3d for that scene: inspace or instation
        /// </remarks>
        public bool Rendering3D
        {
            get
            {
                bool rendering1 = (bool)GetLocalSvc("sceneManager").Attribute("registeredScenes").DictionaryItem(SceneName).Attribute("display");
                return rendering1;
            }
            set => GetLocalSvc("sceneManager").Attribute("registeredScenes").DictionaryItem(SceneName).SetAttribute("display", value);
        }

        private string SceneName
        {
            get
            {
                //
                // options are:
                // default: means we have in space
                // characterCreation: character creation
                // starmap
                // systemmap
                // planet
                // ShipTreeView
                // doesnt include station or citadel!?!

                string sceneName = "default";
                //if (Login.AtCharacterSelection)
                //...
                if (Session.IsInSpace)
                {
                    sceneName = "default";
                }
                else if (Session.IsInDockableLocation)
                {
                    sceneName = "hangar";
                }

                return sceneName;
            }
        }

        /// <summary>
        ///     Is EVE loading textures, you can enable/disable texture loading by setting this value to true or false
        /// </summary>
        /// <remarks>
        ///     Use at own risk!
        /// </remarks>
        public bool ResourceLoad
        {
            get
            {
                //bool disableGeometryLoad = (bool)PySharp.Import("trinity").Attribute("device").Attribute("disableGeometryLoad");
                bool disableEffectLoad = (bool)PySharp.Import("trinity").Attribute("device").Attribute("disableEffectLoad");
                bool disableTextureLoad = (bool)PySharp.Import("trinity").Attribute("device").Attribute("disableTextureLoad");
                //return disableGeometryLoad || disableEffectLoad || disableTextureLoad;
                return disableEffectLoad || disableTextureLoad;
            }
            set
            {
                //PySharp.Import("trinity").Attribute("device").SetAttribute("disableGeometryLoad", value);
                PySharp.Import("trinity").Attribute("device").SetAttribute("disableEffectLoad", value);
                PySharp.Import("trinity").Attribute("device").SetAttribute("disableTextureLoad", value);
            }
        }

        public static ulong FrameCount { get; private set; }

        private long EveHWnd => ESCache.Instance.EveAccount.EveHWnd;

        public bool FormNewFleet()
        {
            if (!Session.IsInSpace && !Session.IsInDockableLocation)
            {
                Log("if (!IsInSpace && !IsInDockableLocation)");
                return false;
            }

            if (Session.InFleet)
            {
                Log("FormNewFleet: Session.FleetId is [" + Session.FleetId + "]");
                return true;
            }

            PyObject fleetsvc = GetLocalSvc("fleet");
            if (fleetsvc == null || !fleetsvc.IsValid)
            {
                Log("FormNewFleet: if (fleetsvc == null || !fleetsvc.IsValid)");
                return false;
            }

            if (ThreadedCall(fleetsvc.Attribute("StartNewFleet"), Session.CharacterId))
                return true;

            return false;
        }

        public bool CreateFleetAdvert()
        {
            if (!Session.IsInSpace && !Session.IsInDockableLocation)
            {
                Log("if (!IsInSpace && !IsInDockableLocation)");
                return false;
            }

            if (!Session.InFleet)
            {
                Log("FormNewFleet: Session.FleetId is [" + Session.FleetId + "]");
                return false;
            }

            PyObject fleetsvc = GetLocalSvc("fleet");
            if (fleetsvc == null || !fleetsvc.IsValid)
            {
                Log("FormNewFleet: if (fleetsvc == null || !fleetsvc.IsValid)");
                return false;
            }

            //if (ThreadedCall(fleetsvc.Attribute("RegisterFleet"), Session.CharacterId))
            //    return true;

            return false;
        }

        public bool OpenRegisterFleetWindow()
        {
            if (!Session.IsInSpace && !Session.IsInDockableLocation)
            {
                Log("if (!IsInSpace && !IsInDockableLocation)");
                return false;
            }

            if (!Session.InFleet)
            {
                Log("FormNewFleet: Session.FleetId is [" + Session.FleetId + "]");
                return false;
            }

            PyObject fleetsvc = GetLocalSvc("fleet");
            if (fleetsvc == null || !fleetsvc.IsValid)
            {
                Log("FormNewFleet: if (fleetsvc == null || !fleetsvc.IsValid)");
                return false;
            }

            if (ThreadedCall(fleetsvc.Attribute("OpenRegisterFleetWindow"), Session.CharacterId))
                return true;

            return false;
        }

        public bool RemoveFleetAdvert()
        {
            if (!Session.IsInSpace && !Session.IsInDockableLocation)
            {
                Log("if (!IsInSpace && !IsInDockableLocation)");
                return false;
            }

            if (!Session.InFleet)
            {
                Log("FormNewFleet: Session.FleetId is [" + Session.FleetId + "]");
                return false;
            }

            PyObject fleetsvc = GetLocalSvc("fleet");
            if (fleetsvc == null || !fleetsvc.IsValid)
            {
                Log("FormNewFleet: if (fleetsvc == null || !fleetsvc.IsValid)");
                return false;
            }

            if (ThreadedCall(fleetsvc.Attribute("UnRegisterFleet"), Session.CharacterId))
                return true;

            return false;
        }

        public bool ApplyToJoinFleetID()
        {
            if (!Session.IsInSpace && !Session.IsInDockableLocation)
            {
                Log("if (!IsInSpace && !IsInDockableLocation)");
                return false;
            }

            if (Session.InFleet)
            {
                Log("ApplyToJoinFleetID: We are in a fleet already! Session.FleetId is [" + Session.FleetId + "]");
                return true;
            }

            if (string.IsNullOrEmpty(ESCache.Instance.EveAccount.LeaderCharacterName))
            {
                Log("ApplyToJoinFleetID: LeaderCharacterName is empty: Do we have IsLeader checked on the toon that is supposed to be the leader?");
                return true;
            }

            if (ESCache.Instance.EveAccount.LeaderFleetID == 0)
            {
                Log("ApplyToJoinFleetID: Waiting for Leader to create the fleet");
                return true;
            }

            PyObject fleetsvc = GetLocalSvc("fleet");
            if (fleetsvc == null || !fleetsvc.IsValid)
            {
                Log("FormNewFleet: if (fleetsvc == null || !fleetsvc.IsValid)");
                return false;
            }

            if (ThreadedCall(fleetsvc.Attribute("AskJoinFleetFromLink"), ESCache.Instance.EveAccount.LeaderFleetID))
                return true;

            return false;
        }

        List<DirectFleetMember> _fleetMembers = new List<DirectFleetMember>();

        public List<DirectFleetMember> GetFleetMembers
        {
            get
            {
                try
                {
                    if (_fleetMembers == null)
                    {
                        _fleetMembers = new List<DirectFleetMember>();
                        Dictionary<long, PyObject> pyMembers = GetLocalSvc("fleet").Attribute("members").ToDictionary<long>();
                        foreach (KeyValuePair<long, PyObject> pyMember in pyMembers)
                            _fleetMembers.Add(new DirectFleetMember(this, pyMember.Value));
                        return _fleetMembers;
                    }

                    return _fleetMembers;
                }
                catch (Exception)
                {
                    return new List<DirectFleetMember>();
                }
            }
        }

        public List<long> GetStationGuests
        {
            get
            {
                List<long> charIds = new List<long>();
                Dictionary<PyObject, PyObject> pyCharIds = GetLocalSvc("station").Attribute("guests").ToDictionary();
                foreach (KeyValuePair<PyObject, PyObject> pyChar in pyCharIds)
                    charIds.Add((long)pyChar.Key);
                return charIds;
            }
        }

        private bool ServicesLoaded { get; set; }
        public Dictionary<string, int> InvTypeNames => _invtypeNames ?? (_invtypeNames = DirectInvType.GetInvTypeNames(this));

        private bool _shuttingDown { get; set; }
        private bool _shutDown { get; set; }

        public bool IsProbeScannerWindowOpen => Windows.Any(w => w.Name.Equals("probeScannerWindow"));

        public bool IsDirectionalScannerWindowOpen => Windows.Any(w => w.Name.Equals("directionalScannerWindow"));

        public DateTime LastBookmarkAction { get; set; }

        public DirectFittingManagerWindow FittingManagerWindow
        {
            get
            {
                if ((bool)!Session.IsInDockableLocation || Session.IsInSpace)
                    return null;

                DirectFittingManagerWindow fittingManagerWindow = Windows.OfType<DirectFittingManagerWindow>().FirstOrDefault();

                if (fittingManagerWindow == null)
                {
                    OpenFitingManager();
                    return null;
                }
                if (!fittingManagerWindow.IsReady)
                    return null;

                return fittingManagerWindow;
            }
        }

        public void SetAudioEnabled()
        {
            bool tempAudioEnabled = GetLocalSvc("station").Attribute("public").Attribute("audio").Call("get", "audioEnabled", 1).ToBool();
            if (!tempAudioEnabled)
            {
                //ExecuteCommand(DirectCmd.CmdToggleAudio);
                GetLocalSvc("station").Attribute("public").Attribute("audio").Call("set", "audioEnabled", true);
            }
        }

        public void SetAudioDisabled()
        {
            bool tempAudioEnabled = GetLocalSvc("station").Attribute("public").Attribute("audio").Call("get", "audioEnabled", 1).ToBool();
            if (!tempAudioEnabled)
            {
                //ExecuteCommand(DirectCmd.CmdToggleAudio);
                GetLocalSvc("station").Attribute("public").Attribute("audio").Call("set", "audioEnabled", false);
            }
        }

        public void SetAutoRejectDuelInvitationsEnabled()
        {
            //GetService('characterSettings').Save(const.autoRejectDuelSettingsKey, str(int(checkbox.checked)))
            bool tempAutoRejectDuelInvitations = GetLocalSvc("characterSettings").Call("Get", "autoRejectDuelInvitations").ToBool();
            if (!tempAutoRejectDuelInvitations)
            {
                //ExecuteCommand(DirectCmd.CmdToggleAudio);
                GetLocalSvc("characterSettings").Call("Save", "autoRejectDuelInvitations", "1");
            }
        }

        public void SetAutoRejectDuelInvitationsDisabled()
        {
            //GetService('characterSettings').Save(const.autoRejectDuelSettingsKey, str(int(checkbox.checked)))
            bool tempAutoRejectDuelInvitations = GetLocalSvc("characterSettings").Call("Get", "autoRejectDuelInvitations").ToBool();
            if (tempAutoRejectDuelInvitations)
            {
                //ExecuteCommand(DirectCmd.CmdToggleAudio);
                GetLocalSvc("characterSettings").Call("Save", "autoRejectDuelInvitations", "0");
            }
        }

        public IEnumerable<DirectModule> Weapons => Modules.Where(m => m.IsOnline && m.IsWeapon);

        public IEnumerable<DirectAgent> ListDirectAgentsTypeDistribution
        {
            get
            {
                try
                {
                    if (listDirectAgentsTypeDistribution == null || !listDirectAgentsTypeDistribution.Any())
                        listDirectAgentsTypeDistribution = GetAllAgents().Select(a => a.Value).Select(a => GetAgentById(a)).Where(i => i.AgentTypeName.Contains("BasicAgent") && i.DivisionName.Contains("Distribution")).ToList();

                    return listDirectAgentsTypeDistribution;
                }
                catch (Exception ex)
                {
                    Log("Exception [" + ex + "]");
                    return new List<DirectAgent>();
                }
            }
        }

        #region IDisposable Members

        /// <summary>
        ///     Dispose of DirectEve
        /// </summary>
        public void Dispose()
        {
            _shuttingDown = true;
            Console.WriteLine($"DirectEve initiating shutdown.");
            while (!_shutDown) SpinWait.SpinUntil(() => false, 1);
            Console.WriteLine($"Onframe handler finished the last frame. Disposing framework.");
            if (_framework != null)
                _framework.Dispose();
            _framework = null;
        }

        #endregion IDisposable Members

        public string GetLocalizationMessageById(int id)
        {
            if (_localizationMessageByIdStorage.TryGetValue(id, out var val))
                return val;
            string r = PySharp.Import("localization").Call("GetByMessageID", id).ToUnicodeString();
            _localizationMessageByIdStorage[id] = r;
            return r;
        }

        public bool AnyModalWindows()
        {
            PySharp pySharp = PySharp;
            PyObject carbonui = pySharp.Import("carbonui");
            List<PyObject> pyWindows = carbonui.Attribute("uicore").Attribute("uicore").Attribute("registry").Attribute("windows").ToList();
            foreach (PyObject pyWindow in pyWindows)
            {
                if ((bool)pyWindow.Attribute("destroyed"))
                    continue;
                PyObject name = pyWindow.Attribute("name");
                string nameStr = name.IsValid ? name.ToUnicodeString() : string.Empty;
                if (nameStr.Equals("modal") || (bool)pyWindow.Attribute("isModal") || nameStr == "telecom") return true;
            }

            return false;
        }

        /// <summary>
        ///     Set destination without fetching DirectLocation ~ CPU Intensive
        /// </summary>
        /// <param name="locationId"></param>
        /// <returns></returns>
        public bool SetDestination(long locationId)
        {
            return DirectNavigation.SetDestination(locationId, this);
        }

        public int GetDistanceBetweenSolarsystems(int solarsystem1, int solarsystem2)
        {
            return DirectSolarSystem.GetDistanceBetweenSolarsystems(solarsystem1, solarsystem2, this);
        }

        public DirectInvType GetInvType(int typeId)
        {
            return DirectInvType.GetInvType(this, typeId);
        }

        public bool DoesInvTypeExistInTypeStorage(int typeId)
        {
            return DirectInvType.GetInvType(this, typeId) != null;
        }

        /// <summary>
        ///     Refresh the bookmark cache (if needed)
        /// </summary>
        /// <returns></returns>
        public bool RefreshBookmarks()
        {
            return DirectBookmark.RefreshBookmarks(this);
        }

        /// <summary>
        ///     Refresh the PnPWindow
        /// </summary>
        /// <returns></returns>
        public bool RefreshPnPWindow()
        {
            return DirectBookmark.RefreshPnPWindow(this);
        }

        public bool IsTargetStillValid(long id)
        {
            //dynamic ps = PySharp;
            PyObject targetSvc = GetLocalSvc("target");
            PyObject target = targetSvc.Attribute("targetsByID").DictionaryItem(id);
            if (target.IsValid)
                return true;
            //var targets = ps.__builtin__.sm.services["target"].targetsByID.ToDictionary<long>();
            //if (targets.ContainsKey(id))
            //return true;

            return false;
        }

        public bool IsTargetBeingRemoved(long id)
        {
            PyObject target = GetLocalSvc("target");
            PyObject targetsBeingRemoved = target.Attribute("deadShipsBeingRemoved"); // set object
            if (targetsBeingRemoved.IsValid && targetsBeingRemoved.PySet_Contains(id) || _targetsBeingRemoved.ContainsKey(id))
                return true;

            return false;
        }

        public Dictionary<long, DateTime> GetTargetsBeingRemoved()
        {
            return _targetsBeingRemoved;
        }

        //		private static Dictionary<int, DirectInvType> _invTypes = null;

        /// <summary>
        ///     OnFrame event, use this to do your eve-stuff
        /// </summary>
        public event EventHandler<DirectEveEventArgs> OnFrame;

        public static bool HasFrameChanged([CallerMemberName] string caller = null)
        {
            if (!_hasFrameChangedCallerDictionary.ContainsKey(caller))
            {
                _hasFrameChangedCallerDictionary[caller] = FrameCount;
                return true;
            }
            if (_hasFrameChangedCallerDictionary[caller] == FrameCount)
                return false;
            _hasFrameChangedCallerDictionary[caller] = FrameCount;
            return true;
        }

        /// <summary>
        ///     Check to run certain code at a given interval and once at most each frame.
        ///     Limitation: Due the fact the line number is used as part of the reference, this
        ///     method can only be used once per line.
        /// </summary>
        /// <param name="delayMs">The requested interval.</param>
        /// <param name="delayMsMax">If set the interval will be randomized between (delayMs, delayMsMax). Max val is exclusive!</param>
        /// <param name="uniqueName">
        ///     Instead of the combination of CallerMemberName and CallerLineNumber a unique string can be used. That
        ///     way the Interval can be used at multiple locations.
        /// </param>
        /// <param name="ln">Internal use only</param>
        /// <param name="caller">Internal use only</param>
        /// <returns></returns>
        public static bool Interval(int delayMs, int delayMsMax = 0, string uniqueName = null, [CallerLineNumber] int ln = 0, [CallerMemberName] string caller = null)
        {
            caller = uniqueName ?? caller + ln;
            if (!HasFrameChanged(caller))
                return false;

            DateTime now = DateTime.UtcNow;
            int delay = delayMsMax == 0 ? delayMs : _random.Next(delayMs, delayMsMax);

            if (_intervalDict.TryGetValue(caller, out var dt) && dt > now)
                return false;

            _intervalDict[caller] = now.AddMilliseconds(delay);
            return true;
        }

        public bool IsEffectActivating(DirectModule m)
        {
            if (_lastSeenEffectActivating.TryGetValue(m.ItemId, out _))
            {
                if (m.IsActive || m.IsReloadingAmmo || m.IsBeingRepaired || m.IsDeactivating)
                {
                    _lastSeenEffectActivating.Remove(m.ItemId);
                    return false;
                }
                return true;
            }
            return false;
        }

        public void AddEffectTimer(DirectModule m)
        {
            _lastSeenEffectActivating[m.ItemId] = DateTime.UtcNow;
        }

        /// <summary>
        ///     Internal "OnFrame" handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrameworkOnFrame(object sender, EventArgs e)
        {
            if (!_shuttingDown)
                try
                {
                    Stopwatch directFrameSt = new Stopwatch();
                    directFrameSt.Start();

                    using (PySharp pySharp = new PySharp(true))
                    {
                        // Make the link to the instance
                        PySharp = pySharp;

                        // Get current target list
                        dynamic ps = pySharp;
                        // targetsByID and targeting are now dictionaries
                        List<long> targets = ps.__builtin__.sm.services["target"].targetsByID.keys().ToList<long>();
                        targets.AddRange(ps.__builtin__.sm.services["target"].targeting.keys().ToList<long>());
                        List<long> targetsBeingRemoved = ps.__builtin__.sm.services["target"].deadShipsBeingRemoved.ToList<long>();
                        DateTime now = DateTime.UtcNow;

                        foreach (long t in targetsBeingRemoved)
                            if (!_targetsBeingRemoved.ContainsKey(t))
                                _targetsBeingRemoved.Add(t, now);

                        foreach (PyObject eff in GetLocalSvc("godma").Attribute("stateManager").Attribute("activatingEffects").ToList())
                        {
                            long moduleId = eff.Item(0).ToLong();
                            if (moduleId > 0)
                                _lastSeenEffectActivating[moduleId] = now;
                        }

                        foreach (KeyValuePair<long, DateTime> eff in _lastSeenEffectActivating.ToList())
                            if (eff.Value.AddSeconds(3) < now)
                                _lastSeenEffectActivating.Remove(eff.Key);

                        // Update currently locked targets
                        targets.ForEach(t => _lastKnownTargets[t] = now);
                        // Remove all targets that have not been locked for 3 seconds
                        foreach (long t in _lastKnownTargets.Keys.ToArray())
                            if (now.AddSeconds(-3) >= _lastKnownTargets[t])
                                _lastKnownTargets.Remove(t);

                        _hasFrameChangedCallerDictionary = new Dictionary<string, ulong>();

                        foreach (KeyValuePair<long, DateTime> kv in _targetsBeingRemoved.ToArray())
                            if (now.AddSeconds(-10) >= kv.Value)
                                _targetsBeingRemoved.Remove(kv.Key);

                        ////Populate the statistic variables
                        if (_enableStatisticsModifying)
                            CheckStatistics();

                        directFrameSt.Stop();
                        GetLastFrameExecutionDuration = directFrameSt.ElapsedMilliseconds;

                        if (!ServicesLoaded && Session.IsReady)
                            LoadServices();
                        else
                            OnFrame?.Invoke(this, new DirectEveEventArgs(GetLastFrameExecutionDuration));

                        // Clear any cache that we had during this frame
                        _localSvcCache.Clear();
                        _entitiesById = null;
                        _windows = null;
                        _modules = null;
                        _const = null;
                        _bookmarks = null;
                        _agentMissions = null;

                        _containers.Clear();
                        _fleetMembers = null;
                        _itemHangar = null;
                        _marketWindow = null;
                        _shipHangar = null;
                        _shipsCargo = null;
                        _shipsOreHold = null;
                        _shipsModules = null;
                        _shipsDroneBay = null;
                        _shipsFleetHangar = null;
                        _listGlobalAssets = null;
                        _modalWindows = null;
                        _me = null;
                        _activeShip = null;
                        _standings = null;
                        _navigation = null;
                        _session = null;
                        _login = null;
                        _skills = null;
                        // Remove the link
                        PySharp = null;
                    }

                    if (eveFrameSt.IsRunning)
                    {
                        int fpsLimit = ESCache.Instance.EveSetting.BackgroundFPS;
                        if (fpsLimit < ESCache.Instance.EveSetting.BackgroundFPSMin)
                            fpsLimit = ESCache.Instance.EveSetting.BackgroundFPSMin;
                        int limitForeground = 800 / fpsLimit;
                        int limitBackground = 600 / fpsLimit;
                        long fgw = Pinvokes.GetForegroundWindow().ToInt64();
                        int limit = fgw == EveHWnd ? limitForeground : limitBackground;
                        while (eveFrameSt.ElapsedMilliseconds < limit)
                            SpinWait.SpinUntil(() => false, 1);

                        eveFrameSt.Stop();
                    }

                    eveFrameSt.Restart();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("DirectEve Exception:" + ex);
                }
            else
                _shutDown = true;
            FrameCount++;
        }

        private void LoadServices()
        {
            foreach (string svc in _servicesToLoad)
            {
                if (!IsServiceRunning(svc)) // start the service if it's not running already
                {
                    GetLocalSvc(svc);
                    return;
                }

                if (IsServiceRunning(svc)) // additional startup requirements for different services
                    switch (svc)
                    {
                        case "agents":

                            if (!IsAgentsByIdDictionaryPopulated())
                            {
                                if (!_servicesAdditionalRequirementsCallOnlyOnce.Any(k => k.Equals(nameof(PopulateAgentsByIdDictionary))))
                                {
                                    _servicesAdditionalRequirementsCallOnlyOnce.Add(nameof(PopulateAgentsByIdDictionary));
                                    PopulateAgentsByIdDictionary();
                                }

                                return;
                            }

                            break;

                        default:
                            break;
                    }
            }

            ServicesLoaded = true;
        }

        /// <summary>
        ///     Open the corporation hangar
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Only works in a station!
        /// </remarks>
        private bool OpenCorporationHangar()
        {
            return ExecuteCommand(DirectCmd.OpenCorpHangar);
        }

        public bool OpenInventory()
        {
            return ExecuteCommand(DirectCmd.OpenInventory);
        }

        public long GetBallParkCount()
        {
            if (!HasFrameChanged())
                return _ballParkCount;
            _ballParkCount = DirectEntity.GetBallparkCount(this);
            return _ballParkCount;
        }

        public bool AnyEntities()
        {
            return GetBallParkCount() != 0;
        }

        public int GetCorpHangarId(string divisionName)
        {
            PyObject divisions = GetLocalSvc("corp").Call("GetDivisionNames");
            for (int i = 0; i < 7; i++)
                if (string.Compare(divisionName, (string)divisions.DictionaryItem(i), true) == 0)
                    return i;
            return -1;
        }

        public bool OpenCorpHangarArray(long itemID)
        {
            return ThreadedLocalSvcCall("menu", "OpenCorpHangarArray", itemID, PySharp.PyNone);
        }

        public bool OpenShipMaintenanceBay(long itemID)
        {
            PyObject OpenShipMaintenanceBayShip = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.openFunctions")
                .Attribute("OpenShipMaintenanceBayShip");
            return ThreadedCall(OpenShipMaintenanceBayShip, itemID, PySharp.PyNone);
        }

        public bool OpenStructure(long itemID)
        {
            return ThreadedLocalSvcCall("menu", "OpenStructure", itemID, PySharp.PyNone);
        }

        public bool OpenStructureCharges(long itemID, bool hasCapacity)
        {
            return ThreadedLocalSvcCall("menu", "OpenStructureCharges", itemID, PySharp.PyNone, hasCapacity);
        }

        public bool OpenStructureCargo(long itemID)
        {
            return ThreadedLocalSvcCall("menu", "OpenStructureCargo", itemID, PySharp.PyNone);
        }

        public bool OpenStrontiumBay(long itemID)
        {
            return ThreadedLocalSvcCall("menu", "OpenStrontiumBay", itemID, PySharp.PyNone);
        }

        /// <summary>
        ///     Execute a command
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public bool ExecuteCommand(DirectCmd cmd)
        {
            Tuple<int, int> throttle;
            switch (cmd)
            {
                case DirectCmd.CmdZoomOut:
                    throttle = new Tuple<int, int>(1000, 2000);
                    break;

                case DirectCmd.CmdDronesReturnToBay:
                    throttle = new Tuple<int, int>(7000, 10000);
                    break;

                case DirectCmd.CmdStopShip:
                    throttle = new Tuple<int, int>(7000, 10000);
                    break;

                case DirectCmd.OpenJournal:
                case DirectCmd.CmdExitStation:
                    Log("Calling DirectCmd [" + cmd + "]");
                    throttle = new Tuple<int, int>(1500, 2000);
                    break;

                case DirectCmd.OpenShipHangar:
                case DirectCmd.OpenHangarFloor:
                case DirectCmd.OpenCorpHangar:
                case DirectCmd.OpenCargoHoldOfActiveShip:
                case DirectCmd.OpenDroneBayOfActiveShip:
                case DirectCmd.OpenFleetHangarOfActiveShip:
                case DirectCmd.OpenLoginCampaignWindow:
                case DirectCmd.OpenMarket:
                case DirectCmd.OpenOreHoldOfActiveShip:
                case DirectCmd.OpenRepairShop:
                    Log("Calling DirectCmd [" + cmd + "]");
                    throttle = new Tuple<int, int>(4000, 5000);
                    break;

                case DirectCmd.CmdDronesReturnAndOrbit:
                    Log("Calling DirectCmd [" + cmd + "]");
                    throttle = new Tuple<int, int>(2500, 3500);
                    break;

                case DirectCmd.CmdDronesEngage:
                    Log("Calling DirectCmd [" + cmd + "]");
                    throttle = new Tuple<int, int>(1500, 1500);
                    break;

                case DirectCmd.CmdReconnectToDrones:
                    Log("Calling DirectCmd [" + cmd + "]");
                    throttle = new Tuple<int, int>(5000, 7000);
                    break;

                case DirectCmd.CmdReloadAmmo:
                    throttle = new Tuple<int, int>(25000, 27000);
                    break;

                default:
                    Log("Calling DirectCmd [" + cmd + "]");
                    throttle = new Tuple<int, int>(1000, 1500);
                    break;
            }

            if (_nextDirectCmdExec.TryGetValue(cmd, out var dt) && dt > DateTime.UtcNow)
            {
                Log($"Calling DirectCmd [{cmd}] too frequently!");
                return false;
            }

            _nextDirectCmdExec[cmd] = DateTime.UtcNow.AddMilliseconds(new Random().Next(throttle.Item1, throttle.Item2));

            switch (cmd)
            {
                case DirectCmd.CmdExitStation:
                    DirectEventManager.NewEvent(new DirectEvent(DirectEvents.UNDOCK, "Undocking from station."));
                    DirectSession.SetSessionNextSessionReady();
                    break;

                default:
                    break;
            }

            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
            return ThreadedLocalSvcCall("cmd", cmd.ToString());
        }

        /// <summary>
        ///     Return a list of locked items
        /// </summary>
        /// <returns></returns>
        public List<long> GetLockedItems()
        {
            Dictionary<long, PyObject> locks = GetLocalSvc("invCache").Attribute("lockedItems").ToDictionary<long>();
            return locks.Keys.ToList();
        }

        /// <summary>
        ///     Remove all item locks
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     Do not abuse this, the client probably placed them for a reason!
        /// </remarks>
        public bool UnlockItems()
        {
            return GetLocalSvc("invCache").Attribute("lockedItems").Clear();
        }

        /// <summary>
        ///     Item hangar container
        /// </summary>
        /// <returns></returns>
        public DirectContainer GetItemHangar()
        {
            if ((bool)!Session.IsInDockableLocation || Session.IsInSpace)
                return null;

            if (_itemHangar == null)
            {
                DirectContainer itemHangar = DirectContainer.GetItemHangar(this);

                if (!itemHangar.IsValid)
                {
                    if (DebugConfig.DebugArm) Log("if (!itemHangar.IsValid)");
                    return null;
                }

                if (itemHangar.Window == null)
                {
                    if (DebugConfig.DebugArm) Log("if (itemHangar.Window == null)");
                    ExecuteCommand(DirectCmd.OpenHangarFloor);
                    return null;
                }

                if (!itemHangar.IsReady)
                {
                    if (DebugConfig.DebugArm) Log("if (!itemHangar.IsReady)");
                    return null;
                }

                _itemHangar = itemHangar;
            }

            return _itemHangar;
        }

        /// <summary>
        ///     Ship hangar container
        /// </summary>
        /// <returns></returns>
        public DirectContainer GetShipHangar()
        {
            if ((bool)!Session.IsInDockableLocation || Session.IsInSpace)
                return null;

            if (_shipHangar == null)
            {
                if (DebugConfig.DebugArm) Log("if (_shipHangar == null)");
                DirectContainer shipHangar = DirectContainer.GetShipHangar(this);
                if (!shipHangar.IsValid)
                {
                    if (DebugConfig.DebugArm) Log("if (!shipHangar.IsValid)");
                    return null;
                }

                if (shipHangar.Window == null)
                {
                    if (DebugConfig.DebugArm) Log("if (shipHangar.Window == null)");
                    ExecuteCommand(DirectCmd.OpenShipHangar);
                    return null;
                }
                if (!shipHangar.IsReady)
                {
                    if (DebugConfig.DebugArm) Log("if (!shipHangar.IsReady)");
                    return null;
                }

                if (DebugConfig.DebugArm) Log("_shipHangar = shipHangar;");
                _shipHangar = shipHangar;
            }

            if (DebugConfig.DebugArm) Log("return _shipHangar;");
            return _shipHangar;
        }

        /// <summary>
        ///     Ship's cargo container
        /// </summary>
        /// <returns></returns>
        public DirectContainer GetShipsCargo()
        {
            if (_shipsCargo == null)
            {
                DirectContainer shipsCargo = DirectContainer.GetShipsCargo(this);
                if (shipsCargo == null) return null;

                if (!shipsCargo.IsValid)
                    return null;
                if (shipsCargo.Window == null)
                {
                    ExecuteCommand(DirectCmd.OpenCargoHoldOfActiveShip);
                    return null;
                }
                if (!shipsCargo.IsReady)
                    return null;

                _shipsCargo = shipsCargo;
            }

            return _shipsCargo;
        }

        /// <summary>
        ///     Ship's ore hold container
        /// </summary>
        /// <returns></returns>
        public DirectContainer GetShipsOreHold()
        {
            if (_shipsOreHold == null)
            {
                DirectContainer shipsOreHold = DirectContainer.GetShipsOreHold(this);
                if (shipsOreHold == null) return null;

                if (!shipsOreHold.IsValid)
                    return null;

                if (shipsOreHold.Window == null)
                {
                    ExecuteCommand(DirectCmd.OpenOreHoldOfActiveShip);
                    return null;
                }

                if (!shipsOreHold.IsReady)
                    return null;

                _shipsOreHold = shipsOreHold;
            }

            return _shipsOreHold;
        }

        /// <summary>
        ///     Assets list
        /// </summary>
        /// <returns></returns>
        public List<DirectItem> GetAssets()
        {
            if (_listGlobalAssets == null)
            {
                _listGlobalAssets = new List<DirectItem>();
                Dictionary<long, PyObject> pyItemDict = GetLocalSvc("invCache").Attribute("containerGlobal").Attribute("cachedItems").ToDictionary<long>();
                foreach (KeyValuePair<long, PyObject> pyItem in pyItemDict)
                {
                    DirectItem item = new DirectItem(this);
                    item.PyItem = pyItem.Value;
                    _listGlobalAssets.Add(item);
                }
            }

            return _listGlobalAssets;
        }

        /// <summary>
        ///     Refresh global assets list (note: 5min delay in assets)
        /// </summary>
        /// <returns></returns>
        public bool RefreshAssets()
        {
            return ThreadedCall(GetLocalSvc("invCache").Call("GetInventory", Const.ContainerGlobal).Attribute("List"));
        }

        public DirectMarketWindow GetMarketWindow()
        {
            if (_marketWindow == null)
            {
                DirectMarketWindow marketWindow = Windows.OfType<DirectMarketWindow>().FirstOrDefault();

                if (marketWindow == null)
                {
                    ExecuteCommand(DirectCmd.OpenMarket);
                    return null;
                }

                if (!marketWindow.IsReady)
                {
                    if (DebugConfig.DebugArm || DebugConfig.DebugMarketOrders) Log("if (!marketWindow.IsReady)");
                    return null;
                }

                _marketWindow = marketWindow;
            }

            return _marketWindow;
        }

        /// <summary>
        ///     Ship's modules container
        /// </summary>
        /// <returns></returns>
        public DirectContainer GetShipsModules()
        {
            return _shipsModules ?? (_shipsModules = DirectContainer.GetShipsModules(this));
        }

        /// <summary>
        ///     Ship's drone bay
        /// </summary>
        /// <returns></returns>
        public DirectContainer GetShipsDroneBay()
        {
            if (_shipsDroneBay == null)
            {
                if (ActiveShip.IsShipWithNoDroneBay)
                {
                    if (DebugConfig.DebugArm) Log("if (ActiveShip.IsShipWithNoDroneBay)");
                    return null;
                }

                DirectContainer shipsDroneBay = DirectContainer.GetShipsDroneBay(this);

                if (shipsDroneBay == null) return null;

                if (!shipsDroneBay.IsValid)
                {
                    if (DebugConfig.DebugArm) Log("if (!shipsDroneBay.IsValid)");
                    return null;
                }

                if (shipsDroneBay.Window == null)
                {
                    ExecuteCommand(DirectCmd.OpenDroneBayOfActiveShip);
                    return null;
                }

                if (!shipsDroneBay.IsReady)
                {
                    if (DebugConfig.DebugArm) Log("if (!shipsDroneBay.IsReady)");
                    return null;
                }

                _shipsDroneBay = shipsDroneBay;
            }

            return _shipsDroneBay;
        }

        /// <summary>
        ///     Ship's drone bay
        /// </summary>
        /// <returns></returns>
        public DirectContainer GetShipsFleetHangar()
        {
            if (_shipsFleetHangar == null)
            {
                if (!ActiveShip.IsShipWithFleetHangar)
                    return null;

                DirectContainer shipsFleetHangar = DirectContainer.GetShipsFleetHangar(this);

                if (shipsFleetHangar == null) return null;

                if (!shipsFleetHangar.IsValid)
                    return null;

                if (shipsFleetHangar.Window == null)
                {
                    ExecuteCommand(DirectCmd.OpenFleetHangarOfActiveShip);
                    return null;
                }

                if (!shipsFleetHangar.IsReady)
                    return null;

                _shipsFleetHangar = shipsFleetHangar;
            }

            return _shipsFleetHangar;
        }

        /// <summary>
        ///     Item container
        /// </summary>
        /// <param name="itemId"></param>
        /// <returns></returns>
        public DirectContainer GetContainer(long itemId)
        {
            if (!_containers.ContainsKey(itemId))
                _containers[itemId] = DirectContainer.GetContainer(this, itemId);

            if (_containers[itemId] == null) return null;

            return _containers[itemId];
        }

        /// <summary>
        ///     Get the corporation hangar container based on division name
        /// </summary>
        /// <param name="divisionName"></param>
        /// <returns></returns>
        public DirectContainer GetCorporationHangar(string divisionName)
        {
            return DirectContainer.GetCorporationHangar(this, divisionName);
        }

        public bool DoesCorpHangarExistHere
        {
            get
            {
                if (Session.IsInSpace) return false;
                if (!Session.IsInDockableLocation) return false;
                if (Me.CorpName == "Viziam") return false; //Amarr
                if (Me.CorpName == "Ministry of War") return false; //Amarr
                if (Me.CorpName == "Imperial Shipment ") return false; //Amarr
                if (Me.CorpName == "Perkone") return false; //Caldari
                if (Me.CorpName == "Caldari Provisions") return false; //Caldari
                if (Me.CorpName == "Deep Core Mining Inc.") return false; //Caldari
                if (Me.CorpName == "The Scope") return false; //Gallente
                if (Me.CorpName == "Aliastra") return false; //Gallente
                if (Me.CorpName == "Garoun Investment Bank") return false; //Gallente
                if (Me.CorpName == "Brutor Tribe") return false; //Minmatar
                if (Me.CorpName == "Sebiestor Tribe") return false; //Minmatar
                if (Me.CorpName == "Native Freshfood") return false; //Minmatar

                long itemId = 0;
                try
                {
                    itemId = (long)GetLocalSvc("officeManager").Call("GetCorpOfficeAtLocation").Attribute("officeID");
                    if (itemId != 0) return true;
                    return false;
                }
                catch (Exception ex)
                {
                    Logging.Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        /// <summary>
        ///     Get the corporation hangar container based on division id (1-7)
        /// </summary>
        /// <param name="divisionId"></param>
        /// <returns></returns>
        public DirectContainer GetCorporationHangar(int divisionId = 1)
        {
            return DirectContainer.GetCorporationHangar(this, divisionId);
        }

        public DirectContainer GetCorporationHangarArray(long itemId, string divisionName)
        {
            return DirectContainer.GetCorporationHangarArray(this, itemId, divisionName);
        }

        public DirectContainer GetCorporationHangarArray(long itemId, int divisionId)
        {
            return DirectContainer.GetCorporationHangarArray(this, itemId, divisionId);
        }

        /// <summary>
        ///     Return the entity by it's id
        /// </summary>
        /// <param name="entityId"></param>
        /// <returns></returns>
        public DirectEntity GetEntityById(long entityId)
        {
            if (EntitiesById.TryGetValue(entityId, out var entity))
                return entity;

            return null;
        }

        /// <summary>
        ///     Bookmark the current location
        /// </summary>
        /// <param name="name"></param>
        /// <param name="comment"></param>
        /// <param name="folderId"></param>
        /// <returns></returns>
        public bool BookmarkCurrentLocation(string name, string comment, long? folderId)
        {
            if (Session.CharacterId == null)
                return false;

            return BookmarkCurrentLocation(Session.CharacterId.Value, name, comment, folderId);
        }

        /// <summary>
        ///     Bookmark the current location
        /// </summary>
        /// <param name="name"></param>
        /// <param name="comment"></param>
        /// <param name="folderId"></param>
        /// <returns></returns>
        public bool CorpBookmarkCurrentLocation(string name, string comment, long? folderId)
        {
            if (Session.CorporationId == null)
                return false;

            return BookmarkCurrentLocation(Session.CorporationId.Value, name, comment, folderId);
        }

        /// <summary>
        ///     Bookmark the current location
        /// </summary>
        /// <param name="ownerId"></param>
        /// <param name="name"></param>
        /// <param name="comment"></param>
        /// <param name="folderId"></param>
        /// <returns></returns>
        internal bool BookmarkCurrentLocation(long ownerId, string name, string comment, long? folderId)
        {
            if (Session.StationId.HasValue)
            {
                PyObject station = GetLocalSvc("station").Attribute("station");
                if (!station.IsValid)
                    return false;

                if (LastBookmarkAction.AddSeconds(3) > DateTime.UtcNow)
                    return false;

                bool tempBool = DirectBookmark.BookmarkLocation(this, ownerId, (long)station.Attribute("stationID"), name, comment,
                    (int)station.Attribute("stationTypeID"), (long?)station.Attribute("solarSystemID"), folderId);

                if (tempBool)
                {
                    LastBookmarkAction = DateTime.UtcNow;
                    return tempBool;
                }

                return false;
            }

            if (ActiveShip.Entity.IsValid && Session.SolarSystemId.HasValue)
                return DirectBookmark.BookmarkLocation(this, ownerId, ActiveShip.Entity.Id, name, comment, ActiveShip.Entity.TypeId, Session.SolarSystemId,
                    folderId);

            return false;
        }

        /// <summary>
        ///     Bookmark an entity
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="name"></param>
        /// <param name="comment"></param>
        /// <param name="folderId"></param>
        /// <param name="corp"></param>
        /// <returns></returns>
        public bool BookmarkEntity(DirectEntity entity, string name, string comment, long? folderId, bool corp = false)
        {
            if (!entity.IsValid)
                return false;

            if (!corp && Session.CharacterId == null)
                return false;

            if (corp && Session.CorporationId == null)
                return false;

            if (!corp)
                return DirectBookmark.BookmarkLocation(this, Session.CharacterId.Value, entity.Id, name, comment, entity.TypeId, Session.SolarSystemId,
                    folderId);
            return DirectBookmark.BookmarkLocation(this, Session.CorporationId.Value, entity.Id, name, comment, entity.TypeId, Session.SolarSystemId,
                folderId);
        }

        /// <summary>
        ///     Bookmark an entity
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="name"></param>
        /// <param name="comment"></param>
        /// <param name="folderId"></param>
        /// <returns></returns>
        public bool CorpBookmarkEntity(DirectEntity entity, string name, string comment, long? folderId)
        {
            if (!entity.IsValid)
                return false;

            if (Session.CorporationId == null)
                return false;

            return DirectBookmark.BookmarkLocation(this, Session.CorporationId.Value, entity.Id, name, comment, entity.TypeId, Session.SolarSystemId, folderId);
        }

        /// <summary>
        ///     Create a bookmark folder
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public bool CreateBookmarkFolder(string name)
        {
            if (Session.CharacterId == null)
                return false;

            return DirectBookmark.CreateBookmarkFolder(this, Session.CharacterId.Value, name);
        }

        /// <summary>
        ///     Create a bookmark folder
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public bool CreateCorpBookmarkFolder(string name)
        {
            if (Session.CorporationId == null)
                return false;

            return DirectBookmark.CreateBookmarkFolder(this, Session.CorporationId.Value, name);
        }

        /// <summary>
        ///     Drop bookmarks into people &amp; places
        /// </summary>
        /// <param name="bookmarks"></param>
        /// <returns></returns>
        public bool DropInPeopleAndPlaces(IEnumerable<DirectItem> bookmarks)
        {
            return DirectItem.DropInPlaces(this, bookmarks);
        }

        /// <summary>
        ///     Refine items from the hangar floor
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public bool ReprocessStationItems(IEnumerable<DirectItem> items)
        {
            if (items == null)
                return false;

            if (items.Any(i => !i.PyItem.IsValid))
                return false;

            if ((bool)!Session.IsInDockableLocation)
                return false;

            if (items.Any(i => i.LocationId != Session.StationId))
                return false;

            PyObject Refine = PySharp.Import("eve.client.script.ui.services.menuSvcExtras.invItemFunctions").Attribute("Refine");
            return ThreadedCall(Refine, items.Select(i => i.PyItem));
        }

        /// <summary>
        ///     Return an owner
        /// </summary>
        /// <param name="ownerId"></param>
        /// <returns></returns>
        public DirectOwner GetOwner(long ownerId)
        {
            return DirectOwner.GetOwner(this, ownerId);
        }

        /// <summary>
        ///     Return a location
        /// </summary>
        /// <param name="locationId"></param>
        /// <returns></returns>
        public DirectLocation GetLocation(int locationId)
        {
            return DirectLocation.GetLocation(this, locationId);
        }

        /// <summary>
        ///     Return the name of a location
        /// </summary>
        /// <param name="locationId"></param>
        /// <returns></returns>
        public string GetLocationName(long locationId)
        {
            return DirectLocation.GetLocationName(this, locationId);
        }

        /// <summary>
        ///     Return the agent by id
        /// </summary>
        /// <param name="agentId"></param>
        /// <returns></returns>
        public DirectAgent GetAgentById(long agentId)
        {
            return DirectAgent.GetAgentById(this, agentId);
        }

        /// <summary>
        ///     Return the agent by name
        /// </summary>
        /// <param name="agentName"></param>
        /// <returns></returns>
        public DirectAgent GetAgentByName(string agentName)
        {
            return DirectAgent.GetAgentByName(this, agentName);
        }

        public Dictionary<string, long> GetAllAgents()
        {
            return DirectAgent.GetAllAgents(this);
        }

        public bool IsAgentsByIdDictionaryPopulated()
        {
            return DirectAgent.IsAgentsByIdDictionaryPopulated(this);
        }

        public void PopulateAgentsByIdDictionary()
        {
            DirectAgent.PopulateAgentsByIdDictionary(this);
        }

        /// <summary>
        ///     Return what "eve.LocalSvc" would return, unless the service wasn't started yet
        /// </summary>
        /// <param name="svc"></param>
        /// <returns></returns>
        /// <remarks>Use at your own risk!</remarks>
        public PyObject GetLocalSvc(string svc, bool addCache = true, bool startService = true)
        {
            PyObject service;
            // Do we have a cached version (this is to stop overloading the LocalSvc call)
            if (_localSvcCache.TryGetValue(svc, out service))
                return service;

            // First try to get it from services
            service = PySharp.Import("__builtin__").Attribute("sm").Attribute("services").DictionaryItem(svc);

            // Add it to the cache (it doesn't matter if its not valid)
            if (addCache)
                _localSvcCache.Add(svc, service);

            // If its valid, return the service
            if (service.IsValid)
                return service;

            if (!startService)
                return PySharp.PyZero;

            // Start the service in a ThreadedCall
            PyObject localSvc = PySharp.Import("__builtin__").Attribute("sm").Attribute("GetService");
            ThreadedCall(localSvc, svc);

            // Return an invalid PyObject (so that LocalSvc can start the service)
            return PySharp.PyZero;
        }

        public bool IsServiceRunning(string svc)
        {
            if (!_localSvcCache.TryGetValue(svc, out var obj))
                obj = PySharp.Import("__builtin__").Attribute("sm").Attribute("services").DictionaryItem(svc);

            if (obj == null || !obj.IsValid)
                return false;

            _localSvcCache.AddOrUpdate(svc, obj);

            return obj.Attribute("state").ToInt() == 4;
        }

        public Dictionary<string, PyObject> GetAllRunningServices()
        {
            Dictionary<string, PyObject> ret = new Dictionary<string, PyObject>();

            Dictionary<string, PyObject> services = PySharp.Import("__builtin__").Attribute("sm").Attribute("services").ToDictionary<string>();

            if (services != null && services.Any())
                ret = services;

            return ret;
        }

        public void StartService(string svc)
        {
            GetLocalSvc(svc);
        }

        /// <summary>
        ///     Perform a uthread.new(pyCall, parms) call
        /// </summary>
        /// <param name="pyCall"></param>
        /// <param name="parms"></param>
        /// <returns></returns>
        /// <remarks>Use at your own risk!</remarks>
        public bool ThreadedCall(PyObject pyCall, params object[] parms)
        {
            return ThreadedCallWithKeywords(pyCall, null, parms);
        }

        /// <summary>
        ///     Perform a uthread.new(pyCall, parms) call
        /// </summary>
        /// <param name="pyCall"></param>
        /// <param name="keywords"></param>
        /// <param name="parms"></param>
        /// <returns></returns>
        /// <remarks>Use at your own risk!</remarks>
        public bool ThreadedCallWithKeywords(PyObject pyCall, Dictionary<string, object> keywords, params object[] parms)
        {
            // Check specifically for this, as the call has to be valid (e.g. not null or none)
            if (!pyCall.IsValid)
                return false;

            RegisterAppEventTime();
            return !PySharp.Import("uthread").CallWithKeywords("new", keywords, new object[] { pyCall }.Concat(parms).ToArray()).IsNull;
        }

        /// <summary>
        ///     Perform a uthread.new(svc.call, parms) call
        /// </summary>
        /// <param name="svc"></param>
        /// <param name="call"></param>
        /// <param name="parms"></param>
        /// <returns></returns>
        /// <remarks>Use at your own risk!</remarks>
        public bool ThreadedLocalSvcCall(string svc, string call, params object[] parms)
        {
            PyObject pyCall = GetLocalSvc(svc).Attribute(call);
            return ThreadedCall(pyCall, parms);
        }

        /// <summary>
        ///     Return's true if the entity has not been a target in the last 3 seconds
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        internal bool CanTarget(long id)
        {
            return !_lastKnownTargets.ContainsKey(id);
        }

        /// <summary>
        ///     Remove's the target from the last known targets
        /// </summary>
        /// <param name="id"></param>
        internal void ClearTargetTimer(long id)
        {
            _lastKnownTargets.Remove(id);
        }

        /// <summary>
        ///     Set the target's last target time
        /// </summary>
        /// <param name="id"></param>
        internal void SetTargetTimer(long id)
        {
            _lastKnownTargets[id] = DateTime.UtcNow;
        }

        /// <summary>
        ///     Register app event time
        /// </summary>
        private void RegisterAppEventTime()
        {
            PySharp.Import("carbonui").Attribute("uicore").Attribute("uicore").Attribute("uilib").Call("RegisterAppEventTime");
        }

        /// <summary>
        ///     Open the fitting management window
        /// </summary>
        public void OpenFitingManager()
        {
            if (!Interval(4500, 6500))
                return;
            Log($"Opening the fitting management window.");
            PyObject form = PySharp.Import("form");
            ThreadedCall(form.Attribute("FittingMgmt").Attribute("Open"));
        }

        /// <summary>
        ///     Open the repairshop window
        /// </summary>
        public void OpenRepairShop()
        {
            if ((bool)!Session.IsInDockableLocation)
                Log("OpenRepairShop: IsInDockableLocation is null or false: waiting");
            PyObject form = PySharp.Import("form");
            ThreadedCall(form.Attribute("RepairShopWindow").Attribute("Open"));
        }

        internal long? getServiceMask()
        {
            if ((bool)!Session.IsInDockableLocation)
                return null;

            return (long)PySharp.Import("__builtin__").Attribute("eve").Attribute("stationItem").Attribute("serviceMask");
        }

        /**
        public bool? hasRepairFacility()
        {
            if (!Session.IsReady)
                return null;

            if (!Session.IsInDockableLocation)
            {
                Log("hasRepairFacility: if (!Session.IsInDockableLocation)");
                return false;
            }

            if (Session.Structureid.HasValue)
                return true;

            if (getServiceMask() == null)
            {
                Log("hasRepairFacility: if (serviceMask == null)");
                return null;
            }

            if (getServiceMask() == 0)
            {
                Log("hasRepairFacility: if (serviceMask == 0)");
                return false;
            }

            return (getServiceMask() & (long)Const["stationServiceRepairFacilities"]) != 0;
        }
        **/

        /// <summary>
        ///     Broadcast scatter events.  Use with caution.
        /// </summary>
        /// <param name="evt">The event name.</param>
        /// <returns></returns>
        public bool ScatterEvent(string evt)
        {
            PyObject scatterEvent = PySharp.Import("__builtin__").Attribute("sm").Attribute("ScatterEvent");
            return ThreadedCall(scatterEvent, evt);
        }

        /// <summary>
        ///     Log a message.
        /// </summary>
        /// <param name="msg">A string to output to the loggers.</param>
        public void Log(string msg, [CallerMemberName] string caller = null)
        {
            Logging.Log.WriteLine(msg, null, caller);
        }

        public bool MultiSell(List<DirectItem> items)
        {
            if (items.Any(i => !i.PyItem.IsValid))
                return false;

            items.RemoveAll(i => i.IsSingleton);

            List<List<PyObject>> list = new List<List<PyObject>>();

            foreach (DirectItem item in items)
                list.Add(new List<PyObject> { item.PyItem });

            return ThreadedLocalSvcCall("menu", "MultiSell", new List<List<List<PyObject>>> { list });
        }

        internal PyObject GetRange(DirectOrderRange range)
        {
            switch (range)
            {
                case DirectOrderRange.SolarSystem:
                    return Const.RangeSolarSystem;

                case DirectOrderRange.Constellation:
                    return Const.RangeConstellation;

                case DirectOrderRange.Region:
                    return Const.RangeRegion;

                default:
                    return Const.RangeStation;
            }
        }

        public bool Buy(int StationId, int TypeId, double Price, int quantity, DirectOrderRange range, int minVolume, int duration) //, bool useCorp)
        {
            PyObject pyRange = GetRange(range);
            //def BuyStuff(self, stationID, typeID, price, quantity, orderRange = None, minVolume = 1, duration = 0, useCorp = False):
            return ThreadedLocalSvcCall("marketQuote", "BuyStuff", StationId, TypeId, Price, quantity, pyRange, minVolume, duration); //, useCorp);
        }

        public bool InviteToFleet(long charId)
        {
            return ThreadedLocalSvcCall("menu", "InviteToFleet", charId);
        }

        public bool KickMember(long charId)
        {
            return ThreadedLocalSvcCall("menu", "KickMember", charId);
        }

        public bool LeaveFleet()
        {
            return ThreadedLocalSvcCall("menu", "LeaveFleet");
        }

        public bool MakeFleetBoss(long charId)
        {
            return ThreadedLocalSvcCall("menu", "MakeLeader", charId);
        }

        /// <summary>
        ///     Initiates trade window
        /// </summary>
        /// <param name="charId"></param>
        /// <returns>Fails if char is not in station, if charId is not in station and if the service is not active yet</returns>
        public bool InitiateTrade(long charId)
        {
            if ((bool)!Session.IsInDockableLocation)
                return false;

            if (!GetStationGuests.Any(i => i == charId))
                return false;

            PyObject tradeService = GetLocalSvc("pvptrade");
            if (!tradeService.IsValid)
                return false;

            return ThreadedCall(tradeService.Attribute("StartTradeSession"), charId);
        }

        public bool AddToAddressbook(int charid)
        {
            return ThreadedLocalSvcCall("addressbook", "AddToPersonalMulti", new List<int> { charid });
        }

        private enum LockedItemState
        {
            NoLockedItems,
            WaitingToClear
        }

        public bool NoLockedItemsOrWaitAndClearLocks(string calledFrom)
        {
            if (GetLockedItems().Count == 0)
            {
                //Log("No items locked.");
                _lockedItemState = LockedItemState.NoLockedItems;
                return true;
            }

            switch (_lockedItemState)
            {
                case LockedItemState.NoLockedItems:
                    _waitForLockedItemsUntil = DateTime.UtcNow.AddSeconds(new Random().Next(2, 4));
                    _lockedItemState = LockedItemState.WaitingToClear;
                    return false;

                case LockedItemState.WaitingToClear:
                    if (_waitForLockedItemsUntil < DateTime.UtcNow)
                    {
                        UnlockItems();
                        Log("Clearing item locks.");
                        _lockedItemState = LockedItemState.NoLockedItems;
                    }

                    Log("[" + calledFrom + "][" + GetLockedItems().Count + "] Items currently moving (locked): Waiting");
                    return false;
            }

            return false;
        }

        private void GetProcessMemory()
        {
            //From processhealthsvc.py
            //
            //var line = subprocess.Popen('tasklist /FO csv /FI "PID eq %s" /NH' % self._pid, stdout=subprocess.PIPE)
            //var memory = line.stdout.read().split('"')[9]
            //return int (memory.split(' ')[0].replace(',', '').replace('.', '')) * 1024
        }

        /// <summary>
        ///     Reset DE caused freezes ~ Will be expanded later
        /// </summary>
        private void CheckStatistics()
        {
            Dictionary<string, PyObject> StatsDict = GetLocalSvc("clientStatsSvc").Attribute("statsEntries").ToDictionary<string>();

            //We detect change frameTimeAbove100msStat and other in python functions by client side
            // eve\client\script\sys\clientStatsSvc.py
            _frameTimeAbove100ms = (double)StatsDict["frameTimeAbove100ms"].Attribute("value");
            _frameTimeAbove200ms = (double)StatsDict["frameTimeAbove200ms"].Attribute("value");
            _frameTimeAbove300ms = (double)StatsDict["frameTimeAbove300ms"].Attribute("value");
            _frameTimeAbove400ms = (double)StatsDict["frameTimeAbove400ms"].Attribute("value");
            _frameTimeAbove500ms = (double)StatsDict["frameTimeAbove500ms"].Attribute("value");
            _timesliceWarnings = (double)StatsDict["timesliceWarnings"].Attribute("value");

            if (GetLastFrameExecutionDuration > 80)
            {
                StatsDict["frameTimeAbove100ms"].Call("Set", _prevFrameTimeAbove100ms);
                StatsDict["frameTimeAbove200ms"].Call("Set", _prevFrameTimeAbove200ms);
                StatsDict["frameTimeAbove300ms"].Call("Set", _prevFrameTimeAbove300ms);
                StatsDict["frameTimeAbove400ms"].Call("Set", _prevFrameTimeAbove400ms);
                StatsDict["frameTimeAbove500ms"].Call("Set", _prevFrameTimeAbove500ms);
                StatsDict["timesliceWarnings"].Call("Set", _prevtimesliceWarnings);
            }

            _prevFrameTimeAbove100ms = _frameTimeAbove100ms;
            _prevFrameTimeAbove200ms = _frameTimeAbove200ms;
            _prevFrameTimeAbove300ms = _frameTimeAbove300ms;
            _prevFrameTimeAbove400ms = _frameTimeAbove400ms;
            _prevFrameTimeAbove500ms = _frameTimeAbove500ms;
            _prevtimesliceWarnings = _timesliceWarnings;
        }
    }

    public enum CourierMissionCtrlState
    {
        Start,
        ActivateTransportShip,
        ItemsFoundAndBeingMoved,
        TryToGrabPickupItemsFromHomeStation,
        GotoPickupLocation,
        PickupItem,
        GotoDropOffLocation,
        DropOffItem,
        Idle,
        CompleteMission,
        Done,
        Error,
        Statistics,
        NotEnoughCargoRoom,
        Unused
    }
}