﻿using EasyHook;
using SharedComponents.EVE;
using SharedComponents.IPC;
using System;
using System.Runtime.InteropServices;

namespace HookManager.Win32Hooks
{
    /// <summary>
    ///     Description of IWbemClassObjectGetController.
    ///     https://docs.microsoft.com/en-us/windows/desktop/api/wbemcli/nf-wbemcli-iwbemclassobject-get
    ///     https://msdn.microsoft.com/en-us/windows/aa391442(v=vs.71)
    /// </summary>
    /// HRESULT Get(
    //  [in]            LPCWSTR wszName,
    //  [in]            LONG    lFlags,
    //  [out]           VARIANT *pVal,
    //  [out, optional] CIMTYPE *pvtType,
    //  [out, optional] LONG    *plFlavor
    //);
    public class IWbemClassObjectGetController : IHook, IDisposable
    {
        #region Fields

        private readonly LocalHook _hook;

        #endregion Fields

        #region Constructors

        public IWbemClassObjectGetController()
        {
            Error = false;
            Name = typeof(IWbemClassObjectGetController).Name;
            try
            {
                _hook = LocalHook.Create(
                    LocalHook.GetProcAddress("fastprox.dll", "?Get@CWbemObject@@UAGJPBGJPAUtagVARIANT@@PAJ2@Z"),
                    new GetDelegate(GetDetour),
                    this);

                _hook.ThreadACL.SetExclusiveACL(new int[] { });
                Error = false;
            }
            catch (Exception e)
            {
                HookManagerImpl.Log("Exception: " + e);
                Error = true;
            }
        }

        #endregion Constructors

        #region Delegates

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)]
        internal delegate int GetDelegate([In] int callRef, [In] [MarshalAs(UnmanagedType.LPWStr)] string wszName, [In] int lFlags, [In] [Out] ref object pVal, [In] [Out] ref int pType, [In] [Out] ref int plFlavor);

        [DllImport("fastprox.dll",
            EntryPoint = "?Get@CWbemObject@@UAGJPBGJPAUtagVARIANT@@PAJ2@Z",
            ExactSpelling = true,
            CallingConvention = CallingConvention.StdCall,
            CharSet = CharSet.Unicode)]
        public static extern int Get([In] int callRef, [In] [MarshalAs(UnmanagedType.LPWStr)] string wszName, [In] int lFlags, [In] [Out] ref object pVal, [In] [Out] ref int pType, [In] [Out] ref int plFlavor);

        #endregion Delegates

        #region Properties

        public bool Error { get; set; }
        public string Name { get; set; }

        #endregion Properties

        #region Methods

        public void Dispose()
        {
            _hook.Dispose();
        }

        private static int GetDetour([In] int callRef, [In] [MarshalAs(UnmanagedType.LPWStr)] string wszName, [In] int lFlags, [In] [Out] ref object pVal, [In] [Out] ref int pType, [In] [Out] ref int plFlavor)
        {
            // quit on any WMI call
            WCFClient.Instance.GetPipeProxy.RemoteLog("A WMI call was made. Qutting/disabling this instance.");
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(HookManagerImpl.Instance.CharName,
                nameof(EveAccount.UseScheduler), false);
            Environment.Exit(0);
            Environment.FailFast("exit"); // shouldn't reach the code below, failfast terminates instantly.

            int orig = Get(callRef, wszName, lFlags, ref pVal, ref pType, ref plFlavor);
            //if (wszName.Equals("MACAddress"))
            //{
            //    pVal = "E9-67-CB-D9-17-B4"; // VARIANT marshalling works by ref in both directions :)
            //}
            HookManagerImpl.Log($"WMI value called. Property [{wszName}] ValueType [{pVal.GetType()}] Value[{pVal}]");
            return orig;
        }

        #endregion Methods
    }
}