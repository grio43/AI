﻿using System;
using System.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Lookup;

namespace EVESharpCore.Framework
{
    public partial class DirectEntity
    {
        #region Properties

        public bool IsAccelerationGate
        {
            get
            {
                if (GroupId == (int)Group.AccelerationGate)
                {
                    if (Name.Contains("Proving"))
                        return false;

                    return true;
                }

                return false;
            }
        }

        public bool IsBadIdea
        {
            get
            {
                if (GroupId == (int)Group.InvadingPrecursorEntities)
                    return false;

                bool result = false;
                result |= BracketType == BracketType.Asteroid_Billboard;
                result |= BracketType == BracketType.Sentry_Gun;
                result |= BracketType == BracketType.Stargate;
                result |= BracketType == BracketType.Station;
                result |= BracketType == BracketType.Wormhole;
                result |= BracketType == BracketType.Warp_Gate;
                result |= BracketType == BracketType.Planetary_Customs_Office;
                result |= BracketType == BracketType.Planetary_Customs_Office_NPC;
                result |= BracketType == BracketType.Capsule;
                result |= GroupId == (int)Group.ConcordDrone;
                result |= GroupId == (int)Group.PoliceDrone;
                result |= GroupId == (int)Group.CustomsOfficial;
                result |= GroupId == (int)Group.Billboard;
                result |= GroupId == (int)Group.Stargate;
                result |= GroupId == (int)Group.Station;
                result |= GroupId == (int)Group.Citadel;
                result |= GroupId == (int)Group.SentryGun;
                result |= GroupId == (int)Group.Capsule;
                result |= GroupId == (int)Group.MissionContainer;
                result |= GroupId == (int)Group.CustomsOffice;
                result |= GroupId == (int)Group.GasCloud;
                result |= GroupId == (int)Group.ConcordBillboard;
                result |= IsFrigate;
                result |= IsCruiser;
                result |= IsBattlecruiser;
                result |= IsBattleship;
                result |= IsPlayer;
                return result;
            }
        }

        public bool IsBattlecruiser
        {
            get
            {
                bool result = false;
                result |= BracketType == BracketType.Battlecruiser;
                result |= GroupId == (int)Group.Battlecruiser;
                result |= GroupId == (int)Group.CommandShip;
                result |= GroupId == (int)Group.StrategicCruiser;
                return result;
            }
        }

        public bool IsBattleship
        {
            get
            {
                bool result = false;
                result |= BracketType == BracketType.Battleship;
                result |= GroupId == (int)Group.Battleship;
                result |= GroupId == (int)Group.EliteBattleship;
                result |= GroupId == (int)Group.BlackOps;
                result |= GroupId == (int)Group.Marauder;
                return result;
            }
        }

        public bool IsCelestial => CategoryId == (int)CategoryID.Celestial
                                   || CategoryId == (int)CategoryID.Station
                                   || GroupId == (int)Group.Moon
                                   || GroupId == (int)Group.AsteroidBelt;

        public bool IsContainer => GroupId == (int)Group.Wreck
                                   || GroupId == (int)Group.CargoContainer
                                   || GroupId == (int)Group.SpawnContainer
                                   || GroupId == (int)Group.MissionContainer
                                   || GroupId == (int)Group.DeadSpaceOverseersBelongings;

        public bool IsCruiser
        {
            get
            {
                bool result = false;
                result |= BracketType == BracketType.Cruiser;
                result |= BracketType == BracketType.Fighter_Squadron;
                result |= GroupId == (int)Group.Cruiser;
                result |= GroupId == (int)Group.HeavyAssaultShip;
                result |= GroupId == (int)Group.AdvancedCruisers;
                result |= GroupId == (int)Group.Logistics;
                result |= GroupId == (int)Group.ForceReconShip;
                result |= GroupId == (int)Group.CombatReconShip;
                result |= GroupId == (int)Group.HeavyInterdictor;
                return result;
            }
        }

        public bool IsT2Cruiser
        {
            get
            {
                bool result = false;
                result |= GroupId == (int)Group.HeavyAssaultShip;
                result |= GroupId == (int)Group.AdvancedCruisers;
                result |= GroupId == (int)Group.Logistics;
                result |= GroupId == (int)Group.ForceReconShip;
                result |= GroupId == (int)Group.CombatReconShip;
                result |= GroupId == (int)Group.HeavyInterdictor;
                return result;
            }
        }

        public bool IsEntityIShouldLeaveAlone
        {
            get
            {
                bool result = false;
                result |= GroupId == (int)Group.Merchant;
                result |= GroupId == (int)Group.Mission_Merchant;
                result |= GroupId == (int)Group.FactionWarfareNPC;
                result |= GroupId == (int)Group.Plagioclase;
                result |= GroupId == (int)Group.Spodumain;
                result |= GroupId == (int)Group.Kernite;
                result |= GroupId == (int)Group.Hedbergite;
                result |= GroupId == (int)Group.Arkonor;
                result |= GroupId == (int)Group.Bistot;
                result |= GroupId == (int)Group.Pyroxeres;
                result |= GroupId == (int)Group.Crokite;
                result |= GroupId == (int)Group.Jaspet;
                result |= GroupId == (int)Group.Omber;
                result |= GroupId == (int)Group.Scordite;
                result |= GroupId == (int)Group.Gneiss;
                result |= GroupId == (int)Group.Veldspar;
                result |= GroupId == (int)Group.Hemorphite;
                result |= GroupId == (int)Group.DarkOchre;
                result |= GroupId == (int)Group.Ice;
                result |= TypeId == (int)TypeID.TransportVessel;
                return result;
            }
        }

        public bool IsEwarImmune
        {
            get
            {
                if (IsNpc && Name.Contains("Zor"))
                    return true;

                if (ESCache.Instance.InWormHoleSpace && IsNpcCapitalEscalation)
                    return true;

                if ((double)Ball.Attribute("disallowOffensiveModifiers") == 1)
                    return true;

                return false;
            }
        }

        public bool IsEwarTarget
        {
            get
            {
                bool result = false;
                result |= IsWarpScramblingMe;
                result |= IsWebbingMe;
                result |= IsNeutralizingMe;
                result |= IsJammingMe;
                result |= IsSensorDampeningMe;
                result |= IsTargetPaintingMe;
                result |= IsTrackingDisruptingMe;
                return result;
            }
        }

        public bool IsFactionWarfareNPC => GroupId == (int)Group.FactionWarfareNPC;

        public bool IsFrigate
        {
            get
            {
                if (TypeId == (int)TypeID.Nergal) return true;

                bool result = false;
                result |= BracketType == BracketType.Frigate;
                result |= GroupId == (int)Group.Frigate;
                result |= GroupId == (int)Group.AssaultShip;
                result |= GroupId == (int)Group.StealthBomber;
                result |= GroupId == (int)Group.ElectronicAttackShip;
                result |= GroupId == (int)Group.PrototypeExplorationShip;
                result |= GroupId == (int)Group.Destroyer;
                result |= GroupId == (int)Group.Interdictor;
                result |= GroupId == (int)Group.Interceptor;
                return result;
            }
        }

        public bool IsLargeCollidable
        {
            get
            {
                //
                // hack to get this mission to complete and still not disable avoidbumpingthings
                //
                try
                {
                    if (DirectEve.AgentMissions.Any(i => i.Agent.IsAgentMissionAccepted && i.Name == "Cargo Delivery"))
                        if (DirectEve.AgentMissions.FirstOrDefault(i => i.Agent.IsAgentMissionAccepted && i.Name == "Cargo Delivery").Bookmarks.Any(bookmark => bookmark.Distance.Value < (double)Distances.OnGridWithMe))
                            if (TypeId == 17784)
                                return false;
                }
                catch (Exception)
                {
                }

                bool result = false;
                result |= BracketType == BracketType.Large_Collidable_Structure;
                result |= GroupId == (int)Group.LargeColidableObject;
                result |= GroupId == (int)Group.LargeColidableShip;
                result |= GroupId == (int)Group.LargeColidableStructure;
                result |= GroupId == (int)Group.DeadSpaceOverseersStructure;
                result |= GroupId == (int)Group.DeadSpaceOverseersBelongings;
                //result |= GroupId == (int)Group.AbyssalPrecursorCache;
                result |= GroupId == (int) Group.AbyssalDeadspaceWeather && Name.ToLower().Contains("Asteroid".ToLower());
                result |= GroupId == (int)Group.AbyssalDeadspaceCloud && Name.ToLower().Contains("Asteroid".ToLower());
                return result;
            }
        }

        public bool IsDecloakedTransmissionRelay
        {
            get
            {
                if (TypeId == (int)TypeID.DecloakedTransmissionRelay)
                    return true;

                return false;
            }
        }
        public bool IsLargeWreck => !new[]
        {
            26563, 26569, 26575, 26581, 26587, 26593, 26933, 26939, 27041, 27044,
            27047, 27050, 27053, 27056, 27060, 30459
        }.All(x => x != TypeId);

        public bool IsMediumWreck => !new[]
        {
            26562, 26568, 26574, 26580, 26586, 26592, 26595, 26934, 26940, 27042,
            27045, 27048, 27051, 27054, 27057, 27061, 34440
        }.All(x => x != TypeId);

        public bool IsMiscJunk
        {
            get
            {
                bool result = false;
                result |= GroupId == (int)Group.PlayerDrone;
                result |= GroupId == (int)Group.Wreck;
                result |= IsAccelerationGate;
                result |= GroupId == (int)Group.GasCloud;
                return result;
            }
        }

        public bool IsNPCBattlecruiser
        {
            get
            {
                bool result = false;

                if (DirectEve.Session.IsAbyssalDeadspace)
                    result |= BracketType == BracketType.NPC_Battlecruiser;

                if (GroupId == (int)Group.InvadingPrecursorEntities)
                {
                    if (Name.Contains("Drekavac"))
                        return true;

                    if (BracketType == BracketType.NPC_Battlecruiser)
                        return true;
                }

                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Guristas_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Serpentis_BattleCruiser;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Caldari_State_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Khanid_Battlecruiser;
                result |= GroupId == (int)Group.Mission_CONCORD_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Mordu_Battlecruiser;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Mission_Thukker_Battlecruiser;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_BattleCruiser;
                return result;
            }
        }

        public bool IsNpcCapitalEscalation
        {
            get
            {
                if (Name.Contains("Upgraded Avenger"))
                    return true;

                return false;
            }
        }

        public bool IsNPCCapitalShip
        {
            get
            {
                if (BracketType == BracketType.NPC_Super_Carrier)
                    return true;

                if (BracketType == BracketType.NPC_Carrier)
                    return true;

                if (BracketType == BracketType.NPC_Dreadnought)
                    return true;

                return false;
            }
        }

        public bool IsNPCBattleship
        {
            get
            {
                bool result = false;

                if (DirectEve.Session.IsWspace)
                {
                    if (Name.Contains("Sleepless Guardian"))
                        return true;

                    if (Name.Contains("Sleepless Keeper"))
                        return true;

                    if (Name.Contains("Sleepless Sentinel"))
                        return true;

                    if (Name.Contains("Sleepless Warden"))
                        return true;
                }

                if (GroupId == (int)Group.InvadingPrecursorEntities)
                {
                    if (Name.Contains("Leshak"))
                        return true;

                    if (BracketType == BracketType.NPC_Battleship)
                        return true;
                }

                if (DirectEve.Session.IsAbyssalDeadspace)
                {
                    result |= BracketType == BracketType.NPC_Battleship;
                    result |= BracketType == BracketType.NPC_Carrier;
                    result |= BracketType == BracketType.NPC_Freighter;
                    result |= BracketType == BracketType.NPC_Super_Carrier;
                    result |= TypeId == (int)TypeID.Karybdis_Tyrannos;
                }

                result |= GroupId == (int)Group.Storyline_Battleship;
                result |= GroupId == (int)Group.Storyline_Mission_Battleship;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Battleship;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Battleship;
                result |= GroupId == (int)Group.Asteroid_Guristas_Battleship;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Battleship;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Battleship;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_Battleship;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_Battleship;
                result |= GroupId == (int)Group.Deadspace_Guristas_Battleship;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_Battleship;
                result |= GroupId == (int)Group.Deadspace_Serpentis_Battleship;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Battleship;
                result |= GroupId == (int)Group.Mission_Caldari_State_Battleship;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Battleship;
                result |= GroupId == (int)Group.Mission_Khanid_Battleship;
                result |= GroupId == (int)Group.Mission_CONCORD_Battleship;
                result |= GroupId == (int)Group.Mission_Mordu_Battleship;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Battleship;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Battleship;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_Battleship;
                result |= GroupId == (int)Group.Mission_Generic_Battleships;
                result |= GroupId == (int)Group.Deadspace_Overseer_Battleship;
                result |= GroupId == (int)Group.Mission_Thukker_Battleship;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_Battleship;
                result |= GroupId == (int)Group.Mission_Faction_Battleship;
                if (DirectEve.Session.IsAbyssalDeadspace || DirectEve.Session.IsWspace)
                {
                    result |= GroupId == (int)Group.Drifters_Battleship;
                    result |= GroupId == (int)Group.DrifterResponseBattleship;
                    result |= GroupId == (int)Group.DrifterResponseBattleship;
                }

                return result;
            }
        }

        public bool IsNpcByGroupID
        {
            get
            {
                bool result = false;
                result |= IsLargeCollidable;
                result |= IsSentry;

                if (DirectEve.Session.IsAbyssalDeadspace)
                    if (IsNPCBattleship || IsNPCBattlecruiser || IsNPCCruiser || IsNPCFrigate)
                        return true;

                if (GroupId == (int)Group.InvadingPrecursorEntities)
                {
                    return true;
                }

                result |= GroupId == (int)Group.DeadSpaceOverseersStructure;
                result |= GroupId == (int)Group.Storyline_Battleship;
                result |= GroupId == (int)Group.Storyline_Mission_Battleship;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Battleship;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Battleship;
                result |= GroupId == (int)Group.Asteroid_Guristas_Battleship;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Battleship;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Battleship;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_Battleship;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_Battleship;
                result |= GroupId == (int)Group.Deadspace_Guristas_Battleship;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_Battleship;
                result |= GroupId == (int)Group.Deadspace_Serpentis_Battleship;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Battleship;
                result |= GroupId == (int)Group.Mission_Caldari_State_Battleship;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Battleship;
                result |= GroupId == (int)Group.Mission_Khanid_Battleship;
                result |= GroupId == (int)Group.Mission_CONCORD_Battleship;
                result |= GroupId == (int)Group.Mission_Mordu_Battleship;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Battleship;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Battleship;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_Battleship;
                result |= GroupId == (int)Group.Mission_Generic_Battleships;
                result |= GroupId == (int)Group.Deadspace_Overseer_Battleship;
                result |= GroupId == (int)Group.Mission_Thukker_Battleship;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_Battleship;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Battleship;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_Battleship;
                result |= GroupId == (int)Group.Mission_Faction_Battleship;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Guristas_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Serpentis_BattleCruiser;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Caldari_State_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Khanid_Battlecruiser;
                result |= GroupId == (int)Group.Mission_CONCORD_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Mordu_Battlecruiser;
                result |= GroupId == (int)Group.Mission_Faction_Industrials;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Mission_Thukker_Battlecruiser;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_BattleCruiser;
                result |= GroupId == (int)Group.Storyline_Cruiser;
                result |= GroupId == (int)Group.Storyline_Mission_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Guristas_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Serpentis_Cruiser;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Cruiser;
                result |= GroupId == (int)Group.Mission_Caldari_State_Cruiser;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Cruiser;
                result |= GroupId == (int)Group.Mission_Khanid_Cruiser;
                result |= GroupId == (int)Group.Mission_CONCORD_Cruiser;
                result |= GroupId == (int)Group.Mission_Mordu_Cruiser;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Commander_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_Cruiser;
                result |= GroupId == (int)Group.Mission_Generic_Cruisers;
                result |= GroupId == (int)Group.Deadspace_Overseer_Cruiser;
                result |= GroupId == (int)Group.Mission_Thukker_Cruiser;
                result |= GroupId == (int)Group.Mission_Generic_Battle_Cruisers;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_Cruiser;
                result |= GroupId == (int)Group.Mission_Faction_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Guristas_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Guristas_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Serpentis_Destroyer;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Destroyer;
                result |= GroupId == (int)Group.Mission_Caldari_State_Destroyer;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Destroyer;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Destroyer;
                result |= GroupId == (int)Group.Mission_Khanid_Destroyer;
                result |= GroupId == (int)Group.Mission_CONCORD_Destroyer;
                result |= GroupId == (int)Group.Mission_Mordu_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Commander_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_Destroyer;
                result |= GroupId == (int)Group.Mission_Thukker_Destroyer;
                result |= GroupId == (int)Group.Mission_Generic_Destroyers;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_Destroyer;
                result |= GroupId == (int)Group.TutorialDrone;
                result |= GroupId == (int)Group.asteroid_angel_cartel_frigate;
                result |= GroupId == (int)Group.asteroid_blood_raiders_frigate;
                result |= GroupId == (int)Group.asteroid_guristas_frigate;
                result |= GroupId == (int)Group.asteroid_sanshas_nation_frigate;
                result |= GroupId == (int)Group.asteroid_serpentis_frigate;
                result |= GroupId == (int)Group.deadspace_angel_cartel_frigate;
                result |= GroupId == (int)Group.deadspace_blood_raiders_frigate;
                result |= GroupId == (int)Group.deadspace_guristas_frigate;
                result |= GroupId == (int)Group.Deadspace_Overseer_Frigate;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_Swarm;
                result |= GroupId == (int)Group.deadspace_sanshas_nation_frigate;
                result |= GroupId == (int)Group.deadspace_serpentis_frigate;
                result |= GroupId == (int)Group.mission_amarr_empire_frigate;
                result |= GroupId == (int)Group.mission_caldari_state_frigate;
                result |= GroupId == (int)Group.mission_gallente_federation_frigate;
                result |= GroupId == (int)Group.mission_minmatar_republic_frigate;
                result |= GroupId == (int)Group.mission_khanid_frigate;
                result |= GroupId == (int)Group.mission_concord_frigate;
                result |= GroupId == (int)Group.mission_mordu_frigate;
                result |= GroupId == (int)Group.asteroid_rouge_drone_frigate;
                result |= GroupId == (int)Group.deadspace_rogue_drone_frigate;
                result |= GroupId == (int)Group.asteroid_angel_cartel_commander_frigate;
                result |= GroupId == (int)Group.asteroid_blood_raiders_commander_frigate;
                result |= GroupId == (int)Group.asteroid_guristas_commander_frigate;
                result |= GroupId == (int)Group.asteroid_sanshas_nation_commander_frigate;
                result |= GroupId == (int)Group.asteroid_serpentis_commander_frigate;
                result |= GroupId == (int)Group.mission_generic_frigates;
                result |= GroupId == (int)Group.mission_thukker_frigate;
                result |= GroupId == (int)Group.asteroid_rouge_drone_commander_frigate;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Officer;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Officer;
                result |= GroupId == (int)Group.Asteroid_Guristas_Officer;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Officer;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Officer;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Officer;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Awakened_Defender;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Awakened_Patroller;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Awakened_Sentinel;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Emergent_Defender;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Emergent_Patroller;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Emergent_Sentinel;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Sleepless_Defender;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Sleepless_Patroller;
                result |= GroupId == (int)Group.Deadspace_Sleeper_Sleepless_Sentinel;
                result |= GroupId == (int)Group.AbyssalSpaceshipEntities;
                result |= GroupId == (int)Group.AbyssalDeadspaceDroneEntities;
                result |= GroupId == (int)Group.InvadingPrecursorEntities;

                if (DirectEve.Session.IsAbyssalDeadspace || DirectEve.Session.IsWspace)
                {
                    result |= GroupId == (int)Group.AbyssalFlagCruiser;
                    result |= GroupId == (int)Group.Drifters_Battleship;
                    result |= GroupId == (int)Group.DrifterResponseBattleship;
                    result |= GroupId == (int)Group.DrifterResponseBattleship;
                }

                return result;
            }
        }

        public bool IsNPCCruiser
        {
            get
            {
                bool result = false;

                if (DirectEve.Session.IsWspace)
                {
                    if (Name.Contains("Awakened Guardian"))
                        return true;

                    if (Name.Contains("Awakened Keeper"))
                        return true;

                    if (Name.Contains("Awakened Sentinel"))
                        return true;

                    if (Name.Contains("Awakened Warden"))
                        return true;
                }

                if (GroupId == (int)Group.InvadingPrecursorEntities)
                {
                    if (Name.Contains("Vedmak"))
                        return true;

                    if (Name.Contains("Rodiva"))
                        return true;

                    if (BracketType == BracketType.NPC_Cruiser)
                        return true;
                }

                if (DirectEve.Session.IsAbyssalDeadspace)
                {
                    result |= BracketType == BracketType.NPC_Cruiser;
                    result |= BracketType == BracketType.NPC_Industrial;
                    result |= BracketType == BracketType.NPC_Mining_Barge;
                    result |= GroupId == (int)Group.AbyssalFlagCruiser;
                    result |= Name.Contains("Ephialtes");
                    result |= Name.Contains("Vedmak");
                }

                result |= GroupId == (int)Group.Storyline_Cruiser;
                result |= GroupId == (int)Group.Storyline_Mission_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Guristas_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Serpentis_Cruiser;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Cruiser;
                result |= GroupId == (int)Group.Mission_Caldari_State_Cruiser;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Cruiser;
                result |= GroupId == (int)Group.Mission_Khanid_Cruiser;
                result |= GroupId == (int)Group.Mission_CONCORD_Cruiser;
                result |= GroupId == (int)Group.Mission_Mordu_Cruiser;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_Cruiser;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Commander_Cruiser;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_Cruiser;
                result |= GroupId == (int)Group.Mission_Generic_Cruisers;
                result |= GroupId == (int)Group.Deadspace_Overseer_Cruiser;
                result |= GroupId == (int)Group.Mission_Thukker_Cruiser;
                result |= GroupId == (int)Group.Mission_Generic_Battle_Cruisers;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_Cruiser;
                result |= GroupId == (int)Group.Mission_Faction_Cruiser;
                result |= GroupId == (int)Group.Mission_Faction_Industrials;
                if (DirectEve.Session.IsAbyssalDeadspace || DirectEve.Session.IsWspace)
                    result |= GroupId == (int)Group.AbyssalFlagCruiser;
                return result;
            }
        }

        public bool IsNPCDrone
        {
            get
            {
                bool result = false;
                if (IsPlayer)
                    return false;

                if (DirectEve.Session.IsAbyssalDeadspace)
                {
                    result |= BracketType == BracketType.NPC_Drone;
                    result |= BracketType == BracketType.NPC_Drone_EW;
                    result |= BracketType == BracketType.NPC_Fighter;
                    result |= BracketType == BracketType.NPC_Fighter_Bomber;
                }

                return result;
            }
        }

        public bool IsNPCFrigate
        {
            get
            {
                bool result = false;

                if (DirectEve.Session.IsAbyssalDeadspace)
                {
                    if (Name.Contains("Damavik"))
                    {
                        return true;
                    }

                    return false;
                }

                if (GroupId == (int)Group.InvadingPrecursorEntities)
                {
                    if (Name.Contains("Damavik"))
                        return true;

                    if (Name.Contains("Kikimora"))
                        return true;

                    if (BracketType == BracketType.NPC_Frigate)
                        return true;

                    if (BracketType == BracketType.NPC_Destroyer)
                        return true;
                }

                if (DirectEve.Session.IsWspace)
                {
                    if (Name.Contains("Emergent Escort"))
                        return true;

                    if (Name.Contains("Emergent Keeper"))
                        return true;

                    if (Name.Contains("Emergent Sentinel"))
                        return true;

                    if (Name.Contains("Emergent  Warden"))
                        return true;
                }

                if (DirectEve.Session.IsAbyssalDeadspace)
                {
                    //see: https://suitonia.wordpress.com/2018/05/28/the-demons-which-lurk-in-the-abyss/
                    result |= BracketType == BracketType.NPC_Frigate;
                    result |= BracketType == BracketType.NPC_Destroyer;
                    result |= BracketType == BracketType.NPC_Shuttle;
                    result |= BracketType == BracketType.NPC_Rookie_Ship;
                    result |= Name.Contains("Fieldweaver");
                    result |= Name.Contains("Plateweaver");
                    result |= Name.Contains("Snarecaster");
                    result |= Name.Contains("Fogcaster");
                    result |= Name.Contains("Gazedimmer");
                    result |= Name.Contains("Spotlighter");
                    result |= Name.Contains("Damavik");
                    return result;
                }

                result |= GroupId == (int)Group.Frigate;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Guristas_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Angel_Cartel_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Blood_Raiders_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Guristas_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Sanshas_Nation_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Serpentis_Destroyer;
                result |= GroupId == (int)Group.Mission_Amarr_Empire_Destroyer;
                result |= GroupId == (int)Group.Mission_Caldari_State_Destroyer;
                result |= GroupId == (int)Group.Mission_Gallente_Federation_Destroyer;
                result |= GroupId == (int)Group.Mission_Minmatar_Republic_Destroyer;
                result |= GroupId == (int)Group.Mission_Khanid_Destroyer;
                result |= GroupId == (int)Group.Mission_CONCORD_Destroyer;
                result |= GroupId == (int)Group.Mission_Mordu_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Angel_Cartel_Commander_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Blood_Raiders_Commander_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Guristas_Commander_Destroyer;
                result |= GroupId == (int)Group.Deadspace_Rogue_Drone_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Sanshas_Nation_Commander_Destroyer;
                result |= GroupId == (int)Group.Asteroid_Serpentis_Commander_Destroyer;
                result |= GroupId == (int)Group.Mission_Thukker_Destroyer;
                result |= GroupId == (int)Group.Mission_Generic_Destroyers;
                result |= GroupId == (int)Group.Asteroid_Rogue_Drone_Commander_Destroyer;
                result |= GroupId == (int)Group.asteroid_angel_cartel_frigate;
                result |= GroupId == (int)Group.asteroid_blood_raiders_frigate;
                result |= GroupId == (int)Group.asteroid_guristas_frigate;
                result |= GroupId == (int)Group.asteroid_sanshas_nation_frigate;
                result |= GroupId == (int)Group.asteroid_serpentis_frigate;
                result |= GroupId == (int)Group.deadspace_angel_cartel_frigate;
                result |= GroupId == (int)Group.deadspace_blood_raiders_frigate;
                result |= GroupId == (int)Group.deadspace_guristas_frigate;
                result |= GroupId == (int)Group.deadspace_sanshas_nation_frigate;
                result |= GroupId == (int)Group.deadspace_serpentis_frigate;
                result |= GroupId == (int)Group.mission_amarr_empire_frigate;
                result |= GroupId == (int)Group.mission_caldari_state_frigate;
                result |= GroupId == (int)Group.mission_gallente_federation_frigate;
                result |= GroupId == (int)Group.mission_minmatar_republic_frigate;
                result |= GroupId == (int)Group.mission_khanid_frigate;
                result |= GroupId == (int)Group.mission_concord_frigate;
                result |= GroupId == (int)Group.mission_mordu_frigate;
                result |= GroupId == (int)Group.asteroid_rouge_drone_frigate;
                result |= GroupId == (int)Group.deadspace_rogue_drone_frigate;
                result |= GroupId == (int)Group.asteroid_angel_cartel_commander_frigate;
                result |= GroupId == (int)Group.asteroid_blood_raiders_commander_frigate;
                result |= GroupId == (int)Group.asteroid_guristas_commander_frigate;
                result |= GroupId == (int)Group.asteroid_sanshas_nation_commander_frigate;
                result |= GroupId == (int)Group.asteroid_serpentis_commander_frigate;
                result |= GroupId == (int)Group.mission_generic_frigates;
                result |= GroupId == (int)Group.mission_thukker_frigate;
                result |= GroupId == (int)Group.asteroid_rouge_drone_commander_frigate;
                result |= GroupId == (int)Group.TutorialDrone;
                return result;
            }
        }

        public bool IsSentry
        {
            get
            {
                if (DirectEve.Session.IsWspace && Name.Contains("Orthrus"))
                    return true;

                bool result = false;
                result |= BracketType == BracketType.Sentry_Gun;
                result |= GroupId == (int)Group.ProtectiveSentryGun;
                result |= GroupId == (int)Group.MobileSentryGun;
                result |= GroupId == (int)Group.DestructibleSentryGun;
                result |= GroupId == (int)Group.MobileMissileSentry;
                result |= GroupId == (int)Group.MobileProjectileSentry;
                result |= GroupId == (int)Group.MobileLaserSentry;
                result |= GroupId == (int)Group.MobileHybridSentry;
                result |= GroupId == (int)Group.DeadspaceOverseersSentry;
                result |= GroupId == (int)Group.StasisWebificationBattery;
                result |= GroupId == (int)Group.EnergyNeutralizingBattery;
                return result;
            }
        }

        public bool IsSmallWreck => !new[]
        {
            26561, 26567, 26573, 26579, 26585, 26591, 26594, 26935,
            26941, 27043, 27046, 27049, 27052, 27055, 27058, 27062
        }.All(x => x != TypeId);

        #endregion Properties
    }
}