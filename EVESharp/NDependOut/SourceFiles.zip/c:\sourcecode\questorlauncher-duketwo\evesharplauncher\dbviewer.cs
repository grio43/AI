﻿//using ServiceStack.OrmLite;
using SharedComponents.EVE;

//using SharedComponents.SQLite;
using SharedComponents.Utility;
using System;
using System.Data;
using System.Windows.Forms;

namespace EVESharpLauncher
{
    /**
    public partial class DBViewer : Form
    {
        #region Constructors

        public DBViewer()
        {
            InitializeComponent();
        }

        #endregion Constructors

        #region Methods

        private void DBViewer_Shown(object sender, EventArgs e)
        {
            FormUtil.SetDoubleBuffered(dataGridView1);

            DataTable dt;
            using (ReadConn rc = ReadConn.Open())
            {
                dt = Util.ConvertToDataTable(rc.DB.Select<StatisticsEntry>());
            }
            dataGridView1.DataSource = dt;
        }

        #endregion Methods
    }
    **/
}