﻿using EasyHook;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

//using SC::Utility;

namespace SharedComponents.Py.D3DDetour
{
    public class D3D9 : D3DHook
    {
        private Delegate2 delegate2_0;
        public IntPtr EndScenePointer = IntPtr.Zero;
        private LocalHook localHook_0;
        public IntPtr ResetExPointer = IntPtr.Zero;
        public IntPtr ResetPointer = IntPtr.Zero;

        [DllImport("d3d9.dll")]
        private static extern IntPtr Direct3DCreate9(uint uint_0);

        public override void Initialize()
        {
            Form form = new Form();
            IntPtr intPtr = Direct3DCreate9(32u);
            if (intPtr == IntPtr.Zero)
                throw new Exception("Failed to create D3D.");
            Struct0 @struct = new Struct0
            {
                bool_0 = true,
                uint_6 = 1u,
                uint_2 = 0u
            };
            Delegate4 @delegate = (Delegate4)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(Marshal.ReadIntPtr(intPtr), 64), typeof(Delegate4));
            IntPtr intPtr2;
            if (@delegate(intPtr, 0u, 1u, form.Handle, 32u, ref @struct, out intPtr2) < 0)
                throw new Exception("Failed to create device.");
            EndScenePointer = Marshal.ReadIntPtr(Marshal.ReadIntPtr(intPtr2), 168);
            Delegate3 delegate2 = (Delegate3)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(Marshal.ReadIntPtr(intPtr2), 8), typeof(Delegate3));
            Delegate3 delegate3 = (Delegate3)Marshal.GetDelegateForFunctionPointer(Marshal.ReadIntPtr(Marshal.ReadIntPtr(intPtr), 8), typeof(Delegate3));
            delegate2(intPtr2);
            delegate3(intPtr);
            form.Dispose();
            delegate2_0 = (Delegate2)Marshal.GetDelegateForFunctionPointer(EndScenePointer, typeof(Delegate2));
            localHook_0 = LocalHook.Create(EndScenePointer, new Delegate2(method_0), this);

            localHook_0.ThreadACL.SetExclusiveACL(new int[] { });
        }

        private int method_0(IntPtr intptr_0)
        {
            RaiseEvent();
            return delegate2_0(intptr_0);
        }

        public override void Remove()
        {
            localHook_0.Dispose();
        }

        private delegate int Delegate2(IntPtr intptr_0);

        private delegate void Delegate3(IntPtr intptr_0);

        private delegate int Delegate4(IntPtr instance, uint adapter, uint deviceType, IntPtr focusWindow, uint behaviorFlags,
            [In] ref Struct0 presentationParameters, out IntPtr returnedDeviceInterface);

        private struct Struct0
        {
#pragma warning disable
            public readonly uint uint_0;
            public readonly uint uint_1;
            public uint uint_2;
            public readonly uint uint_3;
            public readonly uint uint_4;
            public readonly uint uint_5;
            public uint uint_6;
            public readonly IntPtr intptr_0;
            [MarshalAs(UnmanagedType.Bool)] public bool bool_0;
            [MarshalAs(UnmanagedType.Bool)] public readonly bool bool_1;
            public readonly uint uint_7;
            public readonly uint uint_8;
            public readonly uint uint_9;
            public readonly uint uint_10;
#pragma warning restore
        }
    }
}