﻿using System;
using System.Windows.Forms;

namespace SharedComponents.EVE
{
    public partial class AccountChallengeForm : Form
    {
        #region Constructors

        public AccountChallengeForm()
        {
            InitializeComponent();
        }

        #endregion Constructors

        #region Properties

        public string Challenge => textBox1.Text;

        #endregion Properties

        #region Methods

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        #endregion Methods
    }
}