﻿extern alias SC;

using SC::SharedComponents.Py;
using System.Collections.Generic;

namespace EVESharpCore.Framework
{
    public class DirectNewEdenStore : DirectObject
    {
        #region Constructors

        public DirectNewEdenStore(DirectEve directEve) : base(directEve)
        {
        }

        #endregion Constructors

        #region Fields

        private const string ActivityTracker = "activitytracker";

        // VGS Store category constants
        private const string CATEGORY_GAME_TIME = "gametime";

        private const string CATEGORY_PLEX = "plex";

        private const string CharacterCreation = "charactercreation";

        private const string CharacterSelector = "charsel";

        private const string DockPanel = "dockpanelview";

        private const string Hangar = "hangar";

        private const string Intro = "intro";

        // Constants for all the valid view states for the EVE client
        private const string Login = "login";

        private const string Planet = "planet";
        private const string ShipTree = "shiptree";
        private const string Space = "inflight";
        private const string StarMap = "starmap";
        private const string Station = "station";
        private const string Structure = "structure";
        private const string SystemMap = "systemmap";
        private const string VirtualGoodsStore = "virtual_goods_store";

        #endregion Fields

        #region Properties

        public bool IsStoreOpen
        {
            get
            {
                PyObject viewStateSvc = DirectEve.GetLocalSvc("viewState");
                if (viewStateSvc.IsValid)
                {
                    PyObject isViewActive = viewStateSvc.Attribute("IsViewActive");
                    if (isViewActive.IsValid)
                        return viewStateSvc.Call("IsViewActive", VirtualGoodsStore).ToBool();
                }
                return false;
            }
        }

        public DirectNewEdenStoreOffer Offer
        {
            get
            {
                PyObject vgsService = DirectEve.GetLocalSvc("vgsService");
                if (vgsService.IsValid)
                {
                    PyObject offer = vgsService.Attribute("uiController").Attribute("detailContainer").Attribute("offer");
                    PyObject detailContainer = vgsService.Attribute("uiController").Attribute("detailContainer");
                    if (offer.IsValid)
                        return new DirectNewEdenStoreOffer(DirectEve, offer, detailContainer);
                }
                return null;
            }
        }

        #endregion Properties

        #region Methods

        public void CloseStore()
        {
            if (!IsStoreOpen)
                return;

            DirectEve.ExecuteCommand(DirectCmd.ToggleAurumStore);
        }

        public bool IsOfferOpen()
        {
            PyObject vgsService = DirectEve.GetLocalSvc("vgsService");
            if (vgsService.IsValid)
            {
                PyObject offerContainer = vgsService.Attribute("uiController").Attribute("detailContainer").Attribute("offerContainer");
                if (offerContainer.IsValid)
                    return !offerContainer.Attribute("destroyed").ToBool();
            }
            return false;
        }

        public void OpenStore()
        {
            if (IsStoreOpen)
                return;

            PyObject vgsService = DirectEve.GetLocalSvc("vgsService");
            if (vgsService.IsValid)
            {
                PyObject openStore = vgsService.Attribute("OpenStore");
                if (openStore.IsValid)
                    DirectEve.ThreadedCallWithKeywords(openStore, new Dictionary<string, object> {{"categoryTag", CATEGORY_GAME_TIME}});
            }
        }

        public void ShowOffer(int id)
        {
            if (!IsStoreOpen)
                return;

            PyObject vgsService = DirectEve.GetLocalSvc("vgsService");
            if (vgsService.IsValid)
            {
                PyObject showOffer = vgsService.Attribute("ShowOffer");
                if (showOffer.IsValid)
                    DirectEve.ThreadedCallWithKeywords(showOffer, new Dictionary<string, object> {{"offerId", id}});
            }
        }

        #endregion Methods
    }
}