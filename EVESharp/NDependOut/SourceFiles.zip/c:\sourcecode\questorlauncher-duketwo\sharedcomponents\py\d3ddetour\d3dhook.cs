﻿using System;

namespace SharedComponents.Py.D3DDetour
{
    public enum D3DVersion
    {
        Direct3D9,
        Direct3D11
    }

    public abstract class D3DHook
    {
        #region Delegates

        public delegate void OnFrameDelegate();

        #endregion Delegates

        #region Fields

        protected static readonly object _frameLock = new object();

        #endregion Fields

        #region Events

        public static event EventHandler<EventArgs> OnFrame;

        public static event OnFrameDelegate OnFrameOnce;

        #endregion Events

        #region Methods

        public abstract void Initialize();

        public abstract void Remove();

        protected void RaiseEvent()
        {
            lock (_frameLock)
            {
                if (OnFrame != null)
                    OnFrame(null, new EventArgs());

                if (OnFrameOnce != null)
                {
                    OnFrameOnce();
                    OnFrameOnce = null;
                }
            }
        }

        #endregion Methods
    }
}