﻿using SharedComponents.EVE;
using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace SharedComponents.Socks5.Socks5Relay
{
    public class DsocksHandler
    {
        #region IDisposable

        public static void Dispose()
        {
            try
            {
                if (listener != null)
                {
                    Debug.WriteLine("Stopping listener..");
                    listener.Stop();
                    listener = null;
                }
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
        }

        #endregion IDisposable

        #region Fields

        private static Socks5Relay chain;
        private static volatile TcpListener listener;
        private static volatile Thread ta;

        #endregion Fields

        #region Methods

        public static void StartChain(string[] args)
        {
            string listenAddr = "127.0.0.1";
            int listenPort = 41337;
            int socketTimeout = 5000;

            Debug.WriteLine("Creating new chain..");

            chain = new Socks5Relay(socketTimeout);
            if (!ParseArgs(args, ref chain))
                return;

            if (listener == null)
            {
                Debug.WriteLine("Starting TCP listener..");
                listener = new TcpListener(IPAddress.Parse(listenAddr), listenPort);
                listener.Start(500);

                Cache.IsShuttingDownEvent += delegate
                {
                    Debug.WriteLine("Stopping listener..");
                    if (listener != null)
                        listener.Stop();
                };
            }

            if (ta != null)
                return;

            ta = new Thread(() =>
            {
                while (true && !Cache.IsShuttingDown)
                    try
                    {
                        DSocks clientSocks = null;
                        Socket client = null;
                        try
                        {
                            Debug.WriteLine("Accepting connection");
                            client = listener.AcceptSocket();
                            clientSocks = new DSocks(client);
                        }
                        catch (Exception)
                        {
                            ta = null;
                            break;
                        }

                        Thread tb = new Thread(() =>
                        {
                            try
                            {
                                if (clientSocks.ServerInit() && clientSocks.ParseRequest() && clientSocks.ServerReply(0))
                                {
                                    Debug.WriteLine("Target {0} {1}", clientSocks.domain, clientSocks.port);

                                    //Debug.WriteLine("Connecting...");
                                    Socket server = chain.Connect();

                                    if (!server.Connected)
                                    {
                                        //Debug.WriteLine("Couldn't connect to server");
                                        client.Close();
                                    }
                                    else
                                    {
                                        //Debug.WriteLine("OK");
                                        Task.Factory.StartNew(() =>
                                        {
                                            chain.Push(server);
                                            chain.PushRaw(server, clientSocks.lastRequest);
                                            Pipe(client, server);
                                        });
                                        Task.Factory.StartNew(() =>
                                        {
                                            chain.Pull(server);
                                            Pipe(server, client);
                                        });
                                    }
                                }
                                else
                                {
                                    client.Close();
                                }
                            }
                            catch (Exception ex)
                            {
                                Debug.WriteLine(ex);
                                if (client != null)
                                    client.Close();
                            }
                        });
                        tb.Start();
                    }
                    catch (Exception)
                    {
                        ta = null;
                        break;
                    }
            });
            ta.Start();
        }

        private static bool ParseArgs(string[] args, ref Socks5Relay chain)
        {
            if (args.Length < 1)
                return false;

            for (int i = 0; i < args.Length; i++)
                chain.Add(args[i]);

            return true;
        }

        private static void Pipe(Socket s1, Socket s2)
        {
            byte[] buf = new byte[0x10000];

            while (true)
                try
                {
                    int len = s1.Receive(buf);
                    if (len == 0)
                        break;
                    s2.Send(buf, len, SocketFlags.None);
                }
                catch
                {
                    break;
                }

            s1.Close();
            s2.Close();
        }

        #endregion Methods
    }
}