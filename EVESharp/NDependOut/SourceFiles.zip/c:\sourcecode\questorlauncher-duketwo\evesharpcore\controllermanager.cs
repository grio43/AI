﻿/*
* Created by SharpDevelop.
* User: duketwo
* Date: 28.05.2016
* Time: 17:38
*
* To change this template use Tools | Options | Coding | Edit Standard Headers.
*/

extern alias SC;

using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Controllers.Base;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using SC::SharedComponents.IPC;
using SC::SharedComponents.Utility;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using EVESharpCore.Lookup;
using SC::SharedComponents.EVE;
using Timer = System.Threading.Timer;

namespace EVESharpCore
{
    /// <summary>
    ///     Description of ControllerManager.
    /// </summary>
    public sealed class ControllerManager : IDisposable
    {
        #region Constructors

        private ControllerManager(int pulseDelayMilliseconds = 100)
        {
            PulseDelayMilliseconds = pulseDelayMilliseconds;
            Pulse = DateTime.MinValue;
            Rnd = new Random();
            ControllerList = new ConcurrentBindingList<BaseController>();
            ControllerDict = new ConcurrentDictionary<Type, IController>();
        }

        #endregion Constructors

        #region Fields

        public static readonly List<Type> DEFAULT_CONTROLLERS = new List<Type> // controller which are enabled by default
        {
            typeof(LoginController),
            typeof(TargetCombatantsController),
            typeof(CombatController),
            typeof(DroneController),
            typeof(SkillQueueController),
            typeof(CleanupController),
            typeof(ActionQueueController),
            typeof(NotificationController),
            typeof(WalletCheckController),
            typeof(NotificationController),
            typeof(ReduceGraphicLoadController),
            typeof(DebugWindowsController),
            typeof(DebugInventoryContainersController),
            typeof(DebugController),
            typeof(SalvageController),
            typeof(DefenseController),
            typeof(IgnoreBookmarkedSignaturesController),
            typeof(DirectionalScannerController),
            typeof(UITravellerController)
        };

        private readonly bool DebugOnFrame = false;

        #endregion Fields

        #region Properties

        public static ControllerManager Instance { get; } = new ControllerManager();

        public ConcurrentDictionary<Type, IController> ControllerDict { get; }
        public ConcurrentBindingList<BaseController> ControllerList { get; }
        public BaseController CurrentController => Enumerator != null ? Enumerator.Current : null;

        public DateTime NextPulse
        {
            set => Pulse = value;
            get
            {
                DateTime ret = Pulse;
                if (DateTime.UtcNow >= Pulse)
                {
                    Pulse = DateTime.UtcNow.AddMilliseconds(PulseDelayMilliseconds);
                    ret = Pulse;
                }
                return ret;
            }
        }

        private IEnumerator<BaseController> Enumerator { get; set; }

        private DateTime Pulse { get; set; }

        private int PulseDelayMilliseconds { get; }

        private Random Rnd { get; }

        #endregion Properties

        #region Methods

        private static readonly Stopwatch _getNextControllerStopwatch = new Stopwatch();

        public void AddController(IController controller) // main add method
        {
            try
            {
                if (controller == null)
                    return;

                if (ControllerList.All(c => c.GetType() != controller.GetType()))
                {
                    //Log.WriteLine("AddController [" + controller.GetType() + "]");
                    ControllerList.Add(controller);
                    ControllerDict.AddOrUpdate(controller.GetType(), controller, (key, oldValue) => controller);
                }

                foreach (Type depControllerType in controller.DependsOn) // add dependent controllers
                    if (ControllerList.All(c => c.GetType() != depControllerType))
                        AddController(depControllerType);

                Program.EveSharpCoreFormInstance.AddControllerTab(controller);
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        public void AddController(Type t)
        {
            object inst = Activator.CreateInstance(t);
            AddController((IController)inst);
        }

        public void AddController(string n)
        {
            try
            {
                if (string.IsNullOrEmpty(n) || n.Equals("None"))
                    return;

                Type t = Type.GetType($"{nameof(EVESharpCore)}.{nameof(Controllers)}." + n);
                if (t != null)
                {
                    object inst = Activator.CreateInstance(t);
                    AddController((IController)inst);
                }
                else
                {
                    Log.WriteLine("AddController failed: [" + n + "] is not a valid controller name");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        public T GetController<T>()
        {
            if (ControllerDict.TryGetValue(typeof(T), out var c))
                return (T)c;
            return default(T);
        }

        public bool CloseEveSharp(string Reason)
        {
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.RestartOfEveClientNeeded), true);
            if (ESCache.Instance.EveAccount.RestartOfEveClientNeeded)
            {
                Log.WriteLine("Closing EVESharp [" + Reason + "]");
                Util.TaskKill(Process.GetCurrentProcess().Id, false);
                return false;
            }

            return false;
        }

        private void IsEveClientHealthy(object obj, EventArgs eventArgs)
        {
            //
            // reasons to not be healthy: last onframe was a loooong time ago
            //
            if (DateTime.UtcNow > LastOnFrameEvent.AddSeconds(20))
            {
                CloseEveSharp("LastOnFrameEvent was more than 20 seconds ago!");
                return;
            }

            return;
        }

        public void Initialize()
        {
            try
            {
                //
                // todo: check for DX9 in the commandline of exefile.exe (how?) and warn the user if its not DX9
                //

                // set callback
                Log.WriteLine("SetCallBackService LauncherCallBack: CharacterName [" + ESCache.Instance.EveAccount.CharacterName + "]");
                WCFClient.Instance.SetCallBackService(new LauncherCallback(), ESCache.Instance.EveAccount.CharacterName);
                if (!ESCache.LoadDirectEVEInstance(ESCache.D3DVersion)) return;

                Log.WriteLine("Registering Onframe Event.");
                ESCache.Instance.DirectEve.OnFrame += EVEOnFrame;
                System.Windows.Forms.Timer watchDogTimer1 = new System.Windows.Forms.Timer
                {
                    Enabled = true,
                    Interval = 5000
                };

                watchDogTimer1.Tick += IsEveClientHealthy;

                Log.WriteLine("Start: Adding Global Default Controllers");
                foreach (Type c in DEFAULT_CONTROLLERS)
                {
                    Log.WriteLine("Adding Controller: [" + c.Name + "]");
                    AddController(c);
                }
                Log.WriteLine("Done: Adding Global Default Controllers");

                string selectedController = ESCache.Instance.EveAccount.SelectedController;
                Log.WriteLine("Adding selected controller [" + selectedController + "] from EVESharpLauncher");
                Instance.AddController(selectedController);


            }
            catch (Exception e)
            {
                Log.WriteLine(e.ToString());
            }
        }

        public void CheckForConnectionLost()
        {

            return;
        }

        public void RemoveAllControllers()
        {
            try
            {
                ControllerList.Clear();
                ControllerDict.Clear();
                Log.WriteLine("Removed all controllers.");
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        public void RemoveController(string n)
        {
            try
            {
                Type t = Type.GetType($"{nameof(EVESharpCore)}.{nameof(Controllers)}." + n);
                RemoveController(t);
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        public void RemoveController(Type t)
        {
            try
            {
                if (ControllerList.Any(c => c.GetType().Equals(t)))
                    RemoveController(ControllerList.FirstOrDefault(c => c.GetType().Equals(t)));
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        public void RemoveController(IController controller) // main remove method
        {
            try
            {
                if (controller == null)
                    return;

                if (DEFAULT_CONTROLLERS.Any(t => t == controller.GetType()))
                {
                    Log.WriteLine("Default type controllers can't be removed.");
                    return;
                }

                if (ControllerList.Any(c => c.GetType().Equals(controller.GetType())))
                {
                    // remove dependant controllers
                    BaseController controllerToBeRemoved = ControllerList.FirstOrDefault(c => c.GetType().Equals(controller.GetType()));
                    foreach (Type depControllerType in controllerToBeRemoved.DependsOn)
                    {
                        // check if any other controller depends on that we are trying to remove before removing it completely
                        IEnumerable<Type> allDepsExceptSelf = ControllerList.ToList().Where(c => c != controllerToBeRemoved).SelectMany(k => k.DependsOn);
                        if (!allDepsExceptSelf.Contains(depControllerType))
                            RemoveController(depControllerType);
                    }

                    ControllerList.Remove(controller);
                    ControllerDict.TryRemove(controller.GetType(), out _);
                    Log.WriteLine("RemoveController [" + controller.GetType() + "]");
                }

                Program.EveSharpCoreFormInstance.RemoveControllerTab(controller);

                Instance.SetPause(false);
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        public void SetPause(bool val = true)
        {
            foreach (BaseController controller in ControllerList.ToList())
            {
                if (controller.IgnorePause)
                    continue;

                controller.IsPaused = val;
            }

            Log.WriteLine("SetPause [" + val + "]");
        }

        public bool TryGetController<T>(out T controller)
        {
            controller = default(T);
            if (ControllerDict.TryGetValue(typeof(T), out var c))
            {
                controller = (T)c;
                return true;
            }
            return false;
        }

        private DateTime LastOnFrameEvent = DateTime.UtcNow;

        private void EVEOnFrame(object sender, DirectEveEventArgs e)
        {
            try
            {
                if (DebugOnFrame) Log.WriteLine("EVEOnFrame Firing Again");
                LastOnFrameEvent = DateTime.UtcNow;

                TryGetController<LoginController>(out var loginController);
                if (TryGetController<ActionQueueController>(out var aQC))
                    if (loginController != null && loginController.IsWorkDone && !aQC.IsPaused)
                        if (!aQC.IsFastActionQueueEmpty)
                        {
                            SessionCheck();
                            aQC.DoWorkEveryFrame();
                        }

                if (DateTime.UtcNow < Pulse)
                    return;

                BaseController controller = GetNextController();
                if (controller == null)
                    return;

                if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} Frame count: {DirectEve.FrameCount}");

                if (controller.LocalPulse > DateTime.UtcNow)
                    return;

                if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} IsReady: {ESCache.Instance.DirectEve.Session.IsReady}");

                //don't run any paused controller
                if (controller.IsPaused)
                {
                    if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} is paused");
                    return;
                }

                if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} is not paused");

                //check if the controller should only run after we successfully logged in
                if (!controller.RunBeforeLoggedIn)
                {
                    if (loginController == null)
                        if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} loginController == null");

                    if (!loginController.IsWorkDone)
                    {
                        if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} LoginController.isWorkDone is false");
                        return;
                    }

                    if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} LoginController.isWorkDone is true");
                }

                SessionCheck();

                // check if the session is valid
                if (!controller.IgnoreValidSession)
                    if (!controller.CheckSessionValid())
                        return;

                if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} Session is ready");
                // if the work is done, do nothing
                if (controller.IsWorkDone)
                    return;

                // if there is a modal and not ignoring modal windows
                //if (QCache.Instance.DirectEve.ModalWindows.Any() && !controller.IgnoreModal)
                //    return;

                // evaluate dependencies
                if (!controller.EvaluateDependencies(this))
                    return;

                // start stopwatch
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();

                // execute controller
                controller.DoWork();
                if (DebugOnFrame) Log.WriteLine($"Pulse. Current controller: {controller.GetType()} DoWork: Done");
                stopwatch.Stop();
                controller.SetDuration((ulong)stopwatch.ElapsedMilliseconds + (ulong)e.LastFrameTook);
            }
            catch (Exception ex)
            {
                Log.WriteLine("EVEOnFrame Exception: " + ex);
            }
        }

        private BaseController GetNextController()
        {
            try
            {
                if (Enumerator == null)
                {
                    if (_getNextControllerStopwatch.IsRunning)
                        _getNextControllerStopwatch.Stop();

                    _getNextControllerStopwatch.Restart();
                    Enumerator = ControllerList.GetEnumerator();
                }

                while (Enumerator.MoveNext())
                {
                    if (Enumerator.Current.IsWorkDone)
                        continue;

                    return Enumerator.Current;
                }
            }
            catch (Exception)
            {
                //Log.WriteLine($"ControllerList was changed during processing.");
                // thrown if list was changed during iteration
            }

            long duration = _getNextControllerStopwatch.ElapsedMilliseconds; // The duration all controllers took.
            long nextPulseDuration = PulseDelayMilliseconds - duration; // Reduce that duration from the next pulse delay to ensure we run the controllers at the given intervall.
            nextPulseDuration = Math.Max(1, nextPulseDuration);
            // If the duration exceeds PulseDelayMilliseconds (500ms), for example in the case we have set a very low fps: 10 fps / 100ms.
            // Then that already happens with an amount of 5 controllers, which should have no negative impact except overall delayed controllers.
            // For 10 controllers at 10 fps, each controller gets called every single second.
            // That means for time crtical code the fast action queue should be used.
            Pulse = NextPulse; //DateTime.UtcNow.AddMilliseconds(nextPulseDuration);
            Enumerator = null; // reset at the end of the iterator or if an exception was thrown
            return null;
        }

        private void SessionCheck()
        {
            ESCache.Instance.DirectEve.Session.SetSessionReady();
            ESCache.Instance.InvalidateCache();
        }

        #endregion Methods

        #region IDisposable implementation

        private bool m_Disposed;

        ~ControllerManager()
        {
            Dispose();
        }

        public void Dispose()
        {
            try
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        private void Dispose(bool disposing)
        {
            try
            {
                if (!m_Disposed)
                {
                    if (disposing)
                        if (ESCache.Instance.DirectEve != null)
                        {
                            ESCache.Instance.DirectEve.OnFrame -= EVEOnFrame;
                            ESCache.Instance.DirectEve.Dispose();
                        }
                    m_Disposed = true;
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine(ex.ToString());
            }
        }

        #endregion IDisposable implementation
    }
}