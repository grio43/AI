﻿using System;
using System.Diagnostics;
using System.Security.Authentication;
using ImapX;
using ImapX.Collections;
using SharedComponents.EVE;

namespace SharedComponents.IMAP
{
    public static class Imap
    {
        #region Methods

        public static MessageCollection GetInboxEmails(string imapHost, int imapPort, SslProtocols sslProto, bool verifySSLCerts,
            string emailUser, string emailPassword, string socks5Host = "", int socks5Port = 0, string socks5User = "", string socks5Password = "")
        {
            ImapClient client = new ImapClient();
            bool boolIMAPSessionConnected = false;
            if (!string.IsNullOrEmpty(socks5Host))
                boolIMAPSessionConnected = client.Connect(imapHost, imapPort, sslProto, verifySSLCerts, socks5Host, socks5Port, socks5User, socks5Password);
            else
                boolIMAPSessionConnected = client.Connect(imapHost, imapPort, sslProto, verifySSLCerts);


            if (boolIMAPSessionConnected)
                if (client.Login(emailUser, emailPassword))
                {
                    Cache.Instance.Log("Auth successful.");
                    client.Folders.Inbox.Messages.Download();
                    client.Disconnect();
                    client.Dispose();

                    return client.Folders.Inbox.Messages;
                }
                else
                {
                    Cache.Instance.Log("Auth failed: emailUser [" + emailUser + "] emailPassword [" + emailPassword + "]");
                    throw new AuthenticationException("Wrong Socks5/Email authentication information.");
                }

            Cache.Instance.Log("Connection failed: imapHost [" + imapHost + "] imapPort [" + imapPort + "] socks5Host [" + socks5Host + "] socks5Port [" + socks5Port + "] socks5User [" + socks5User + "] socks5Password [" + socks5Password + "]");
            throw new AuthenticationException("Wrong Socks5/Email authentication information.");
        }

        public static MessageCollection GetInboxEmails(EveAccount eA)
        {
            if (eA != null && eA.HWSettings != null && eA.HWSettings.Proxy != null)
            {
                Proxy p = eA.HWSettings.Proxy;
                return GetInboxEmails(eA.IMAPHost, 993, SslProtocols.Default, true, eA.Email, eA.EmailPassword, p.Ip, Convert.ToInt32(p.Socks5Port),
                    p.Username, p.Password);
            }

            Debug.WriteLine("HWSettings or Proxy == null.");
            return null;
        }

        #endregion Methods
    }
}