﻿using EVESharpCore.Cache;
using EVESharpCore.Controllers.Base;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Lookup;
using System;
using System.Linq;

namespace EVESharpCore.Controllers
{
    /// <summary>
    ///     Drone Controller
    ///     Use Drones as needed, respecting pause...
    ///     Note: will not move your ship, ever.
    /// </summary>
    public class DroneController : BaseController
    {
        #region Constructors

        public DroneController()
        {
            IgnorePause = false;
            IgnoreModal = false;
        }

        #endregion Constructors

        #region Methods

        public static void ProcessState()
        {
            if (DebugConfig.DebugDisableDrones)
                return;

            // drones
            Drones.ProcessState();
        }

        public override void DoWork()
        {
            try
            {
                if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                {
                    if (Time.Instance.LastInWarp.AddSeconds(1) > DateTime.UtcNow)
                        return;

                    if (ESCache.Instance.Stargates.Any() && Time.Instance.LastInWarp.AddSeconds(10) > DateTime.UtcNow)
                        if (ESCache.Instance.ClosestStargate != null && ESCache.Instance.ClosestStargate.IsOnGridWithMe && ESCache.Instance.ClosestStargate.Distance < 10000)
                        {
                            if (DebugConfig.DebugCleanup) Log("CheckModalWindows: We are within 10k of a stargate, do nothing while we wait to jump.");
                            return;
                        }
                }

                if (!Settings.Instance.DefaultSettingsLoaded)
                    Settings.Instance.LoadSettings();

                if (DebugConfig.DebugDroneController) Log("DroneController.DoWork()");

                ProcessState();
            }
            catch (Exception ex)
            {
                Log("Exception [" + ex + "]");
            }
        }

        public override bool EvaluateDependencies(ControllerManager cm)
        {
            return true;
        }

        #endregion Methods
    }
}