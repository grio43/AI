﻿extern alias SC;

using EVESharpCore.Logging;
using EVESharpCore.Questor.States;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Activities;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.Stats;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Questor.Behaviors
{
    public class TransportHangarToMarketBehavior
    {
        #region Constructors

        public TransportHangarToMarketBehavior()
        {
            //IgnorePause = false;
            //IgnoreModal = false;
        }

        #endregion Constructors

        #region Fields

        //private static readonly int maxStateIterations = 500;
        private static Dictionary<int, int> _moveToCargoList = new Dictionary<int, int>();

        private static DateTime nextAction = DateTime.MinValue;

        //private static int orderIterations;

        private static Dictionary<BuyAmmoState, int> stateIterations = new Dictionary<BuyAmmoState, int>();

        private static TravelerDestination travelerDestination;


        #endregion Fields

        #region Properties

        public static TransportHangarToMarketBehaviorState CurrentTransportHangarToMarketBehaviorState { get; set; } // idle == default

        #endregion Properties

        #region Methods

        public static bool ChangeTransportHangarToMarketBehaviorState(TransportHangarToMarketBehaviorState StateToSet, bool wait = false)
        {
            try
            {
                if (CurrentTransportHangarToMarketBehaviorState != StateToSet)
                {
                    Log.WriteLine("New TransportHangarToMarketBehaviorState [" + StateToSet + "]");
                    CurrentTransportHangarToMarketBehaviorState = StateToSet;
                    if (!wait) ProcessState();
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }

            return true;
        }

        private static List<DirectItem> _stuffToMove = new List<DirectItem>();

        public static void ProcessState()
        {
            if (nextAction > DateTime.UtcNow)
                return;

            switch (CurrentTransportHangarToMarketBehaviorState)
            {
                case TransportHangarToMarketBehaviorState.Idle:
                    stateIterations = new Dictionary<BuyAmmoState, int>();
                    _stuffToMove = new List<DirectItem>();
                    ChangeTransportHangarToMarketBehaviorState(TransportHangarToMarketBehaviorState.ActivateBlockadeRunner, false);
                    break;

                case TransportHangarToMarketBehaviorState.Prerequisites:
                    // Do we require a BlockadeRunner?
                    // How we we guarantee we have one? by groupID?

                    // What system is considered Market? Jita? Other?

                    // Do we have a clear path to Market? with no low sec?
                    //

                    // Is it safe to travel to Market?
                    // Any Wars?
                    // Any PVP Timers?
                    // Any kill rights?

                    // Do we have enough value in the loot hangar to justify a trip to market?
                    //
                    break;

                case TransportHangarToMarketBehaviorState.ActivateBlockadeRunner:

                    if (!ESCache.Instance.InStation)
                        return;

                    if (ESCache.Instance.AmmoHangar == null)
                        return;

                    if (ESCache.Instance.ShipHangar == null)
                        return;

                    if (ESCache.Instance.ActiveShip.GivenName != null &&
                        ESCache.Instance.ActiveShip.GivenName.ToLower() == Settings.Instance.TransportShipName.ToLower())
                    {
                        ChangeTransportHangarToMarketBehaviorState(TransportHangarToMarketBehaviorState.LoadItems, false);
                        return;
                    }

                    if (ESCache.Instance.ActiveShip.GivenName != null &&
                        ESCache.Instance.ActiveShip.GivenName.ToLower() != Settings.Instance.TransportShipName.ToLower())
                    {
                        List<DirectItem> ships = ESCache.Instance.ShipHangar.Items;
                        foreach (
                            DirectItem ship in ships.Where(ship => ship.GivenName != null && ship.GivenName.ToLower() == Settings.Instance.TransportShipName.ToLower())
                        )
                        {
                            Log.WriteLine("Making [" + ship.GivenName + "] active");
                            ship.ActivateShip();
                            nextAction = DateTime.UtcNow.AddSeconds(Time.Instance.SwitchShipsDelay_seconds);
                        }

                        //ChangeBuyAmmoControllerState(BuyAmmoState.CreateBuyList, false);
                    }
                    break;

                case TransportHangarToMarketBehaviorState.CalculateItemsToMove:
                    if (!ESCache.Instance.InStation)
                        return;

                    if (ESCache.Instance.LootHangar == null) return;

                    if (!ESCache.Instance.LootHangar.Items.Any())
                        ChangeTransportHangarToMarketBehaviorState(TransportHangarToMarketBehaviorState.Done);

                    foreach (DirectItem lootHangarItem in ESCache.Instance.LootHangar.Items)
                    {
                        if (ESCache.Instance.CurrentShipsCargo.FreeCapacity > _stuffToMove.Sum(i => i.TotalVolume))
                        {
                            _stuffToMove.Add(lootHangarItem);
                            continue;
                        }

                        break;
                    }

                    ChangeTransportHangarToMarketBehaviorState(TransportHangarToMarketBehaviorState.LoadItems);

                    break;

                case TransportHangarToMarketBehaviorState.LoadItems:
                    if (!ESCache.Instance.InStation)
                        return;

                    if (!ESCache.Instance.CurrentShipsCargo.IsReady)
                        return;

                    if (ESCache.Instance.LootHangar == null)
                        return;

                    //LoadItemsToHaul.MoveToCargoList

                    if (ESCache.Instance.CurrentShipsCargo.FreeCapacity >= _stuffToMove.Sum(i => i.TotalVolume))
                    {
                        if (ESCache.Instance.CurrentShipsCargo.Add(_stuffToMove))
                        {
                            ChangeTransportHangarToMarketBehaviorState(TransportHangarToMarketBehaviorState.WaitForItemsToMove);
                            return;
                        }
                    }

                    break;

                case TransportHangarToMarketBehaviorState.WaitForItemsToMove:
                    if (!ESCache.Instance.CurrentShipsCargo.IsReady)
                        return;

                    ChangeTransportHangarToMarketBehaviorState(TransportHangarToMarketBehaviorState.TravelToMarket);
                    break;

                case TransportHangarToMarketBehaviorState.TravelToMarket:

                    if (ESCache.Instance.InSpace && ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                        return;

                    if (Traveler.Destination != travelerDestination)
                        Traveler.Destination = travelerDestination;

                    Traveler.ProcessState();

                    if (State.CurrentTravelerState == TravelerState.AtDestination)
                    {
                        Log.WriteLine("Arrived at destination");
                        //ChangeBuyAmmoControllerState(BuyAmmoState.BuyAmmo, true);
                        //orderIterations = 0;
                        Traveler.Destination = null;
                        return;
                    }

                    if (State.CurrentTravelerState == TravelerState.Error)
                    {
                        if (Traveler.Destination != null)
                            Log.WriteLine("Stopped traveling, traveller threw an error...");

                        Traveler.Destination = null;
                        //ChangeBuyAmmoControllerState(BuyAmmoState.Error, true);
                    }

                    break;


                //case TransportHangarToMarketBehaviorState.MoveItemsToCargo:
                //    if (!LoadItemsToHaul.MoveHangarItems(ESCache.Instance.ItemHangar, ESCache.Instance.CurrentShipsCargo, _moveToCargoList)) return;
                //    ChangeBuyAmmoControllerState(BuyAmmoState.Done, false);
                //    break;


                case TransportHangarToMarketBehaviorState.Error:
                    //CurrentBuyAmmoState = BuyAmmoState.DisabledForThisSession;
                    if (ESCache.Instance.EveAccount.SelectedController == "QuestorController")
                        CombatMissionsBehavior.ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.DelayedGotoBase, true, null);
                    Arm.ChangeArmState(ArmState.Idle, true, null);
                    Log.WriteLine("ERROR. BuyAmmo should stay disabled while this session is still active.");
                    ControllerManager.Instance.RemoveController(typeof(BuyAmmoController));
                    break;
            }
        }

        #endregion Methods
    }
}