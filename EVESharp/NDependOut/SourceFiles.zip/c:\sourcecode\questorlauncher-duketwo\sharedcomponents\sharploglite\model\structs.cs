﻿using System;
using System.Net.Sockets;
using System.Runtime.InteropServices;

/*
 * User: duketwo - https://github.com/duketwo/
 * Date: 10.11.2016
 */

namespace SharedComponents.SharpLogLite.Model
{
    [StructLayout(LayoutKind.Explicit, Pack = 1)]
    public struct ConnectionMessage
    {
        [FieldOffset(0)] public uint Version;
        [FieldOffset(8)] public uint Pid;

        public override string ToString()
        {
            return string.Format("{0} {1}", Version, Pid);
        }
    }

    [StructLayout(LayoutKind.Explicit, Pack = 0)]
    public struct RawLogMessage
    {
        [FieldOffset(0)] [MarshalAs(UnmanagedType.U4)] public MessageType Type;
        [FieldOffset(8)] public TextMessage TextMessage;
        [FieldOffset(8)] public ConnectionMessage ConnectionMessage;
    }

    public struct SharpLogMessage
    {
        #region Fields

        public string Channel;
        public DateTime DateTime;
        public string Message;
        public string Module;
        public int Pid;
        public LogSeverity Severity;

        #endregion Fields

        #region Constructors

        public SharpLogMessage(DateTime dateTime, LogSeverity severity, string module, string channel, string message, int pid)
        {
            DateTime = dateTime;
            Severity = severity;
            Module = module;
            Channel = channel;
            Message = message;
            Pid = pid;
        }

        #endregion Constructors

        #region Methods

        public SharpLogMessage Copy()
        {
            return new SharpLogMessage(DateTime, Severity, Module, Channel, Message, Pid);
        }

        public override string ToString()
        {
            return string.Format("{0} {1} {2} {3} {4} {5}", DateTime, Severity, Module, Channel, Message, Pid);
        }

        #endregion Methods
    }

    [StructLayout(LayoutKind.Explicit, Pack = 1)]
    public struct TextMessage
    {
        [FieldOffset(0)] [MarshalAs(UnmanagedType.U8)] public ulong Timestamp;
        [FieldOffset(8)] [MarshalAs(UnmanagedType.U4)] public LogSeverity Severity;
        [FieldOffset(12)] [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string Module;
        [FieldOffset(44)] [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string Channel;
        [FieldOffset(76)] [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Message;

        public override string ToString()
        {
            return string.Format("{0} {1} {2} {3} {4}", Timestamp, Severity, Module, Channel, Message);
        }
    }

    public class StateObject
    {
        #region Fields

        public const int BufferSize = 344;
        public byte[] buffer = new byte[BufferSize];
        public SharpLogMessage sharpLogMessage;
        public Socket workSocket = null;

        #endregion Fields
    }
}