﻿using System;

namespace SharedComponents.EVE.ClientSettings.Pinata
{
    [Serializable]
    public enum Region
    {
        Curse,
        Delve,
        Venal,
        Stain,
        Fountain,
        The_Forge
    }
}