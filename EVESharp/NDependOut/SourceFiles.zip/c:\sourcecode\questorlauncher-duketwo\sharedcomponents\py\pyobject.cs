﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using SharedComponents.Events;
using SharedComponents.Utility;

namespace SharedComponents.Py
{
    public partial class PyObject
    {
        #region Constructors

        /// <summary>
        ///     Create a PyObject
        /// </summary>
        /// <param name="pySharp">The main PySharp object</param>
        /// <param name="pyReference">The Python Reference</param>
        /// <param name="newReference">Is this a new reference? (e.g. did the reference counter get increased?)</param>
        /// ///
        /// <param name="attributeName">Attribute name of the new PyObject</param>
        public PyObject(PySharp pySharp, IntPtr pyReference, bool newReference, string attributeName = "")
        {
            _pyReference = pyReference;
            _newReference = newReference;
            _pySharp = pySharp;
            _attributeName = attributeName;

            if (pySharp != null && _newReference)
                pySharp.AddReference(this);

            HandlePythonError();

            if (!IsValid)
                return;

            // Only build up cache if it actually a valid object
            _attributeCache = new Dictionary<string, PyObject>();
            _dictionaryCache = new Dictionary<PyObject, PyObject>();
            _itemCache = new Dictionary<int, PyObject>();
        }

        #endregion Constructors

        #region Fields

        public static readonly DateTime PY_EPOCHE_DATE = new DateTime(1601, 1, 1);

        /// <summary>
        ///     Attribute cache
        /// </summary>
        private readonly Dictionary<string, PyObject> _attributeCache;

        /// <summary>
        ///     Attribute name
        /// </summary>
        private readonly string _attributeName;

        /// <summary>
        ///     Dictionary cache (used by DictionaryItem)
        /// </summary>
        private readonly Dictionary<PyObject, PyObject> _dictionaryCache;

        /// <summary>
        ///     Item cache (used by Item)
        /// </summary>
        private readonly Dictionary<int, PyObject> _itemCache;

        /// <summary>
        ///     Store if its a new reference
        /// </summary>
        private readonly bool _newReference;

        /// <summary>
        ///     Reference to the overall PySharp object
        /// </summary>
        private readonly PySharp _pySharp;

        /// <summary>
        ///     Reference to the actual python object
        /// </summary>
        private IntPtr _pyReference;

        /// <summary>
        ///     PyType cache
        /// </summary>
        private PyType? _pyType;

        #endregion Fields

        #region Properties

        public string AttributeName => _attributeName;

        /// <summary>
        ///     Is this PyObject a PyNone?
        /// </summary>
        public bool IsNone => _pyReference == Py.PyNoneStruct;

        /// <summary>
        ///     Is this PyObject Null?
        /// </summary>
        public bool IsNull => _pyReference == IntPtr.Zero;

        /// <summary>
        ///     Is this PyObject valid?
        /// </summary>
        /// <remarks>
        ///     Both null and none values are considered invalid
        /// </remarks>
        public bool IsValid => !IsNull && !IsNone;

        /// <summary>
        ///     Return the Python Reference Count
        /// </summary>
        public int ReferenceCount => Py.GetRefCnt(this);

        public string Repr => (string)new PyObject(_pySharp, Py.PyObject_Repr(this), true);

        /// <summary>
        ///     The time difference between Datetime.UtcNow and blue.os.GetSimTime()
        ///     TODO: Add caching for a certain interval (3-5 seconds) to improve performance
        /// </summary>
        private double TimeDiff
        {
            get
            {
                DateTime now = DateTime.UtcNow;
                DateTime simtime = _pySharp != null ? PY_EPOCHE_DATE.AddTicks(_pySharp.SimTime) : now;
                double diff = (now - simtime).TotalMilliseconds;
                return diff;
            }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        ///     Cast a PyObject to an bool
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator bool(PyObject pyObject)
        {
            return pyObject.ToBool();
        }

        /// <summary>
        ///     Cast a PyObject to a nullable bool
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator bool? (PyObject pyObject)
        {
            return pyObject.IsValid ? pyObject.ToBool() : (bool?)null;
        }

        /// <summary>
        ///     Cast a PyObject to an integer
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator DateTime(PyObject pyObject)
        {
            return pyObject.ToDateTime();
        }

        /// <summary>
        ///     Cast a PyObject to a nullable long
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator DateTime? (PyObject pyObject)
        {
            return pyObject.IsValid ? pyObject.ToDateTime() : (DateTime?)null;
        }

        /// <summary>
        ///     Cast a PyObject to a dictionary
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator Dictionary<int, PyObject>(PyObject pyObject)
        {
            return pyObject.ToDictionary<int>();
        }

        /// <summary>
        ///     Cast a PyObject to a dictionary
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator Dictionary<long, PyObject>(PyObject pyObject)
        {
            return pyObject.ToDictionary<long>();
        }

        /// <summary>
        ///     Cast a PyObject to a dictionary
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator Dictionary<PyObject, PyObject>(PyObject pyObject)
        {
            return pyObject.ToDictionary();
        }

        /// <summary>
        ///     Cast a PyObject to a dictionary
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator Dictionary<string, PyObject>(PyObject pyObject)
        {
            return pyObject.ToDictionary<string>();
        }

        /// <summary>
        ///     Cast a PyObject to an integer
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator double(PyObject pyObject)
        {
            return pyObject.ToDouble();
        }

        /// <summary>
        ///     Cast a PyObject to a nullable long
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator double? (PyObject pyObject)
        {
            return pyObject.IsValid ? pyObject.ToDouble() : (double?)null;
        }

        /// <summary>
        ///     Cast a PyObject to an integer
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator float(PyObject pyObject)
        {
            return pyObject.ToFloat();
        }

        /// <summary>
        ///     Cast a PyObject to a nullable long
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator float? (PyObject pyObject)
        {
            return pyObject.IsValid ? pyObject.ToFloat() : (float?)null;
        }

        /// <summary>
        ///     Cast a PyObject to an integer
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator int(PyObject pyObject)
        {
            return pyObject.ToInt();
        }

        /// <summary>
        ///     Cast a PyObject to a nullable integer
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator int? (PyObject pyObject)
        {
            return pyObject.IsValid ? pyObject.ToInt() : (int?)null;
        }

        /// <summary>
        ///     Cast a PyObject to a List
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator List<int>(PyObject pyObject)
        {
            return pyObject.ToList<int>();
        }

        /// <summary>
        ///     Cast a PyObject to a List
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator List<long>(PyObject pyObject)
        {
            return pyObject.ToList<long>();
        }

        /// <summary>
        ///     Cast a PyObject to a List
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator List<PyObject>(PyObject pyObject)
        {
            return pyObject.ToList();
        }

        /// <summary>
        ///     Cast a PyObject to a List
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator List<string>(PyObject pyObject)
        {
            return pyObject.ToList<string>();
        }

        /// <summary>
        ///     Cast a PyObject to an integer
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator long(PyObject pyObject)
        {
            return pyObject.ToLong();
        }

        /// <summary>
        ///     Cast a PyObject to a nullable long
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator long? (PyObject pyObject)
        {
            return pyObject.IsValid ? pyObject.ToLong() : (long?)null;
        }

        /// <summary>
        ///     Cast a PyObject to a string
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static explicit operator string(PyObject pyObject)
        {
            return pyObject.ToUnicodeString();
        }

        /// <summary>
        ///     Cast a PyObject to a IntPtr
        /// </summary>
        /// <param name="pyObject"></param>
        /// <returns></returns>
        public static implicit operator IntPtr(PyObject pyObject)
        {
            return pyObject._pyReference;
        }

        /// <summary>
        ///     Attach the PyObject to a new PySharp object
        /// </summary>
        /// <param name="pySharp">New PySharp object</param>
        /// <returns>A new copy of itself</returns>
        public PyObject Attach(PySharp pySharp)
        {
            if (_newReference)
                Py.Py_IncRef(_pyReference);

            return new PyObject(pySharp, _pyReference, _newReference);
        }

        /// <summary>
        ///     Returns an attribute from the current Python object
        /// </summary>
        /// <param name="attribute"></param>
        /// <returns></returns>
        public PyObject Attribute(string attribute)
        {
            if (!IsValid || string.IsNullOrEmpty(attribute) || attribute.ToLower().Equals("dead"))
                return PySharp.PyZero;

            if (!HasAttrString(attribute))
                return PySharp.PyZero;

            PyObject result;
            if (!_attributeCache.TryGetValue(attribute, out result))
            {
                result = new PyObject(_pySharp, Py.PyObject_GetAttrString(this, attribute), true, attribute);
                _attributeCache[attribute] = result;
            }
            return result;
        }

        /// <summary>
        ///     Returns a dictionary of all attributes within the current Python object
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, PyObject> Attributes()
        {
            if (!IsValid)
                return new Dictionary<string, PyObject>();

            return new PyObject(_pySharp, Py.PyObject_Dir(this), true).ToList<string>().ToDictionary(attr => attr, Attribute);
        }

        /// <summary>
        ///     Call a python function
        /// </summary>
        /// <param name="function"></param>
        /// <param name="parms"></param>
        /// <returns></returns>
        public PyObject Call(string function, params object[] parms)
        {
            PyObject func = Attribute(function);

            if (!func.IsValid || !IsCallable(func._pyReference))
                return PySharp.PyZero;

            return func.CallThis(parms);
        }

        /// <summary>
        ///     Call a python function
        /// </summary>
        /// <param name="function"></param>
        /// <param name="keywords"></param>
        /// <param name="parms"></param>
        /// <returns></returns>
        public PyObject CallWithKeywords(string function, Dictionary<string, object> keywords, params object[] parms)
        {
            PyObject func = Attribute(function);
            if (!func.IsValid || !IsCallable(func._pyReference))
                return PySharp.PyZero;
            return func.CallThisWithKeywords(keywords, parms);
        }

        /// <summary>
        ///     Clear this PyObject (the PyObject must be a List, Tuple or Dictionary)
        /// </summary>
        /// <returns></returns>
        /// <remarks>
        ///     For a list attribute, the list is cleared
        ///     For a Dictionary attribute, the dictionary is cleared
        /// </remarks>
        public bool Clear()
        {
            return Clear(GetPyType());
        }

        /// <summary>
        ///     Clear this PyObject (the PyObject must be a List or Dictionary)
        /// </summary>
        /// <param name="pyType">Force this Python Type</param>
        /// <returns></returns>
        /// <remarks>
        ///     For a list attribute, the list is cleared
        ///     For a Dictionary attribute, the dictionary is cleared
        /// </remarks>
        public bool Clear(PyType pyType)
        {
            try
            {
                switch (pyType)
                {
                    case PyType.ListType:
                    case PyType.DerivedListType:
                        return Py.PyList_SetSlice(this, 0, Size() - 1, PySharp.PyZero) == 0;

                    case PyType.DictType:
                    case PyType.DictProxyType:
                    case PyType.DerivedDictType:
                    case PyType.DerivedDictProxyType:
                        return ToDictionary().All(item => Py.PyDict_DelItem(this, item.Key) == 0);
                }

                return false;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns a dictionary item from the current Python object
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public PyObject DictionaryItem(int key)
        {
            if (_pySharp == null)
                return PySharp.PyZero;

            return DictionaryItem(_pySharp.From(key));
        }

        /// <summary>
        ///     Returns a dictionary item from the current Python object
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public PyObject DictionaryItem(long key)
        {
            if (_pySharp == null)
                return PySharp.PyZero;

            return DictionaryItem(_pySharp.From(key));
        }

        /// <summary>
        ///     Returns a dictionary item from the current Python object
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public PyObject DictionaryItem(string key)
        {
            if (_pySharp == null)
                return PySharp.PyZero;

            return DictionaryItem(_pySharp.From(key));
        }

        /// <summary>
        ///     Returns a dictionary item from the current Python object
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public PyObject DictionaryItem(PyObject key)
        {
            if (!IsValid || key.IsNull)
                return PySharp.PyZero;

            try
            {
                PyObject result;
                if (!_dictionaryCache.TryGetValue(key, out result))
                {
                    PyType thisType = GetPyType();
                    if (thisType == PyType.DerivedDictType || thisType == PyType.DictType)
                        result = new PyObject(_pySharp, Py.PyDict_GetItem(this, key), false);
                    else
                        result = new PyObject(_pySharp, Call("__getitem__", key), false);
                    _dictionaryCache[key] = result;
                }
                return result;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Return python type
        /// </summary>
        /// <returns></returns>
        public PyType GetPyType()
        {
            if (IsNull)
                _pyType = PyType.Invalid;

            if (IsNone)
                _pyType = PyType.NoneType;

            if (!_pyType.HasValue)
                _pyType = Py.GetPyType(this);

            return _pyType.Value;
        }

        public bool GetValue(out object obj, out Type t)
        {
            obj = null;
            t = null;
            switch (GetPyType())
            {
                case PyType.NoneType:
                    obj = "None";
                    t = t = typeof(string);
                    return true;

                case PyType.StringType:
                case PyType.UnicodeType:
                case PyType.DerivedStringType:
                    obj = (object)ToUnicodeString();
                    t = typeof(string);
                    return true;

                case PyType.BoolType:
                case PyType.DerivedBoolType:
                    obj = (object)ToBool();
                    t = typeof(bool);
                    return true;

                case PyType.IntType:
                case PyType.DerivedIntType:
                    obj = (object)ToInt();
                    t = typeof(int);
                    return true;

                case PyType.LongType:
                case PyType.DerivedLongType:
                    obj = (object)ToLong();
                    t = typeof(long);
                    return true;

                case PyType.FloatType:
                case PyType.DerivedFloatType:
                    obj = (object)ToFloat();
                    t = typeof(float);
                    return true;

                default:
                    break;
            }
            return false;
        }

        /// <summary>
        ///     Does this python object has this attribute string?
        /// </summary>
        /// <remarks>
        ///     -----
        /// </remarks>
        public bool HasAttrString(string s)
        {
            return Py.PyObject_HasAttrString(this, s) == 1 ? true : false;
        }

        /// <summary>
        ///     Is this python object callable, eg. a function?
        /// </summary>
        /// <remarks>
        ///     -----
        /// </remarks>
        public bool IsCallable(IntPtr ptr)
        {
            return Py.PyCallable_Check(ptr) == 1 ? true : false;
        }

        /// <summary>
        ///     Returns a list item from the current Python object
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public PyObject Item(int index)
        {
            return Item(index, GetPyType());
        }

        /// <summary>
        ///     Returns a list item from the current Python object
        /// </summary>
        /// <param name="index"></param>
        /// <param name="type">Force the PyType to List or Tuple</param>
        /// <returns></returns>
        public PyObject Item(int index, PyType type)
        {
            if (!IsValid)
                return PySharp.PyZero;

            try
            {
                Func<IntPtr, int, IntPtr> getItem = type == PyType.TupleType || type == PyType.DerivedTupleType ? (Func<IntPtr, int, IntPtr>)Py.PyTuple_GetItem : Py.PyList_GetItem;

                PyObject result;
                if (!_itemCache.TryGetValue(index, out result))
                {
                    result = new PyObject(_pySharp, getItem(this, index), false);
                    _itemCache[index] = result;
                }
                return result;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Logs debug information about this PyObject
        /// </summary>
        public string LogObject()
        {
            string s = string.Empty;
            s += string.Format("\nDumping attributes of {0}...\n", Repr);
            foreach (KeyValuePair<string, PyObject> pair in Attributes())
            {
                string k = string.Format("  {0} : {1}\n", pair.Key, pair.Value.Repr);
                s += k;
            }
            return s;
        }

        public bool PySet_Contains<T>(T value)
        {
            try
            {
                if (GetPyType() == PyType.SetType) //TODO: add other set types
                {
                    PyObject pyValue = PySharp.PyZero;

                    object oValue = value;
                    if (value is PyObject)
                        pyValue = (PyObject)oValue;
                    // Only allow type conversions if we have a PySharp object reference
                    if (_pySharp != null)
                    {
                        if (oValue is bool)
                            pyValue = _pySharp.From((bool)oValue);
                        if (oValue is int)
                            pyValue = _pySharp.From((int)oValue);
                        if (oValue is long)
                            pyValue = _pySharp.From((long)oValue);
                        if (oValue is float)
                            pyValue = _pySharp.From((float)oValue);
                        if (oValue is double)
                            pyValue = _pySharp.From((double)oValue);
                        if (oValue is string)
                            pyValue = _pySharp.From((string)oValue);
                        if (oValue is IEnumerable<PyObject>)
                            pyValue = _pySharp.From((IEnumerable<PyObject>)oValue);
                        if (oValue is IEnumerable<int>)
                            pyValue = _pySharp.From((IEnumerable<int>)oValue);
                        if (oValue is IEnumerable<long>)
                            pyValue = _pySharp.From((IEnumerable<long>)oValue);
                        if (oValue is IEnumerable<float>)
                            pyValue = _pySharp.From((IEnumerable<float>)oValue);
                        if (oValue is IEnumerable<double>)
                            pyValue = _pySharp.From((IEnumerable<double>)oValue);
                        if (oValue is IEnumerable<string>)
                            pyValue = _pySharp.From((IEnumerable<string>)oValue);
                    }
                    else
                    {
                        return false;
                    }

                    if (Py.PySet_Contains(this, pyValue) == 1)
                        return true;

                    return false;
                }
            }
            finally
            {
                HandlePythonError();
            }

            return false;
        }

        /// <summary>
        ///     Release the PyObject's internal reference
        /// </summary>
        public void Release()
        {
            if (!IsNull && _newReference)
                Py.Py_DecRef(_pyReference);

            _pyReference = IntPtr.Zero;
        }

        /// <summary>
        ///     Set an attribute value
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="attribute"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public bool SetAttribute<T>(string attribute, T value)
        {
            PyObject pyValue = PySharp.PyZero;

            object oValue = value;
            if (value is PyObject)
                pyValue = (PyObject)oValue;

            // Only allow type conversions if we have a PySharp object reference
            if (_pySharp != null)
            {
                if (oValue is bool)
                    pyValue = _pySharp.From((bool)oValue);
                if (oValue is int)
                    pyValue = _pySharp.From((int)oValue);
                if (oValue is long l)
                    pyValue = _pySharp.From(l);
                if (oValue is float)
                    pyValue = _pySharp.From((float)oValue);
                if (oValue is double)
                    pyValue = _pySharp.From((double)oValue);
                if (oValue is string)
                    pyValue = _pySharp.From((string)oValue);
                if (oValue is IEnumerable<PyObject>)
                    pyValue = _pySharp.From((IEnumerable<PyObject>)oValue);
                if (oValue is IEnumerable<int>)
                    pyValue = _pySharp.From((IEnumerable<int>)oValue);
                if (oValue is IEnumerable<long>)
                    pyValue = _pySharp.From((IEnumerable<long>)oValue);
                if (oValue is IEnumerable<float>)
                    pyValue = _pySharp.From((IEnumerable<float>)oValue);
                if (oValue is IEnumerable<double>)
                    pyValue = _pySharp.From((IEnumerable<double>)oValue);
                if (oValue is IEnumerable<string>)
                    pyValue = _pySharp.From((IEnumerable<string>)oValue);
            }

            try
            {
                if (IsValid && !pyValue.IsNull)
                    return Py.PyObject_SetAttrString(this, attribute, pyValue) != -1;

                return false;
            }
            finally
            {
                HandlePythonError();
            }
        }

        public bool SetTriple(string attribute, object a, object b, object c)
        {
            if (!IsValid)
                return false;

            PyObject pyValue = PySharp.PyZero;
            List<object> list = new List<object> { a, b, c };
            List<PyObject> returnList = new List<PyObject>();

            foreach (object value in list)
            {
                object oValue = value;
                if (value is PyObject)
                    pyValue = (PyObject)oValue;

                // Only allow type conversions if we have a PySharp object reference
                if (_pySharp != null)
                {
                    if (oValue is bool)
                        pyValue = _pySharp.From((bool)oValue);
                    if (oValue is int)
                        pyValue = _pySharp.From((int)oValue);
                    if (oValue is long l)
                        pyValue = _pySharp.From(l);
                    if (oValue is float)
                        pyValue = _pySharp.From((float)oValue);
                    if (oValue is double)
                        pyValue = _pySharp.From((double)oValue);
                    if (oValue is string)
                        pyValue = _pySharp.From((string)oValue);
                    if (oValue is IEnumerable<PyObject>)
                        pyValue = _pySharp.From((IEnumerable<PyObject>)oValue);
                    if (oValue is IEnumerable<int>)
                        pyValue = _pySharp.From((IEnumerable<int>)oValue);
                    if (oValue is IEnumerable<long>)
                        pyValue = _pySharp.From((IEnumerable<long>)oValue);
                    if (oValue is IEnumerable<float>)
                        pyValue = _pySharp.From((IEnumerable<float>)oValue);
                    if (oValue is IEnumerable<double>)
                        pyValue = _pySharp.From((IEnumerable<double>)oValue);
                    if (oValue is IEnumerable<string>)
                        pyValue = _pySharp.From((IEnumerable<string>)oValue);
                }

                returnList.Add(pyValue);
            }

            if (returnList.Any(o => !o.IsValid))
                return false;

            try
            {
                PyObject tuple = new PyObject(_pySharp, Py.PyTuple_Pack(3, returnList[0], returnList[1], returnList[2]), false);

                if (!tuple.IsValid)
                    return false;

                return Py.PyObject_SetAttrString(this, attribute, tuple) != -1;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns the size of the list or tuple
        /// </summary>
        /// <returns></returns>
        public int Size()
        {
            return Size(GetPyType());
        }

        /// <summary>
        ///     Returns the size of the given type (tuple, otherwise list)
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public int Size(PyType type)
        {
            if (!IsValid)
                return -1;

            try
            {
                if (type == PyType.SetType)
                    return (int)Py.PySet_Size(_pyReference);
                Func<IntPtr, int> getSize = type == PyType.TupleType || type == PyType.DerivedTupleType ? (Func<IntPtr, int>)Py.PyTuple_Size : Py.PyList_Size;
                return getSize(this);
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns the PyObject as a bool
        /// </summary>
        /// <returns></returns>
        public bool ToBool()
        {
            return ToInt() == 1;
        }

        /// <summary>
        ///     Returns the PyObject as a DateTime
        /// </summary>
        /// <returns></returns>
        public DateTime ToDateTime()
        {
            DateTime value = PY_EPOCHE_DATE.AddTicks(ToLong());
            if (IsValid)
            {
                double diff = TimeDiff;
                value = value.AddMilliseconds(diff);
            }
            return value;
        }

        /// <summary>
        ///     Returns the PyObject as a dictionary
        /// </summary>
        /// <returns></returns>
        public Dictionary<PyObject, PyObject> ToDictionary()
        {
            return ToDictionary<PyObject>();
        }

        /// <summary>
        ///     Cast a PyObject to a dictionary
        /// </summary>
        /// <returns></returns>
        public Dictionary<TKey, PyObject> ToDictionary<TKey>()
        {
            Dictionary<TKey, PyObject> result = new Dictionary<TKey, PyObject>();
            if (!IsValid)
                return result;
            try
            {
                List<PyObject> keys = Call("keys").ToList();
                foreach (PyObject key in keys)
                {
                    object oKey = null;

                    if (typeof(TKey) == typeof(int))
                        oKey = key.ToInt();
                    if (typeof(TKey) == typeof(long))
                        oKey = key.ToLong();
                    if (typeof(TKey) == typeof(float))
                        oKey = key.ToFloat();
                    if (typeof(TKey) == typeof(double))
                        oKey = key.ToDouble();
                    if (typeof(TKey) == typeof(string))
                        oKey = key.ToUnicodeString();
                    if (typeof(TKey) == typeof(PyObject))
                        oKey = key;

                    if (oKey == null)
                        continue;

                    result[(TKey)oKey] = DictionaryItem(key);
                }

                return result;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns the PyObject as a double
        /// </summary>
        /// <returns></returns>
        public double ToDouble()
        {
            try
            {
                return IsValid ? Py.PyFloat_AsDouble(this) : 0;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns the PyObject as a float
        /// </summary>
        /// <returns></returns>
        public float ToFloat()
        {
            try
            {
                return IsValid ? (float)Py.PyFloat_AsDouble(this) : 0;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns the PyObject as an integer
        /// </summary>
        /// <returns></returns>
        public int ToInt()
        {
            try
            {
                return IsValid ? Py.PyLong_AsLong(this) : 0;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns the PyObject as a list
        /// </summary>
        /// <returns></returns>
        public List<PyObject> ToList()
        {
            return ToList<PyObject>();
        }

        /// <summary>
        ///     Returns the PyObject as a list
        /// </summary>
        /// <returns></returns>
        public List<T> ToList<T>()
        {
            List<T> result = new List<T>();
            if (!IsValid)
                return result;

            try
            {
                if (GetPyType() == PyType.SetType) //TODO: add other types
                    return SetToList<T>();

                int size = Size();
                for (int i = 0; i < size; i++)
                {
                    PyObject item = Item(i);

                    object oItem = null;
                    if (typeof(T) == typeof(int))
                        oItem = item.ToInt();
                    if (typeof(T) == typeof(long))
                        oItem = item.ToLong();
                    if (typeof(T) == typeof(float))
                        oItem = item.ToFloat();
                    if (typeof(T) == typeof(double))
                        oItem = item.ToDouble();
                    if (typeof(T) == typeof(string))
                        oItem = item.ToUnicodeString();
                    if (typeof(T) == typeof(PyObject))
                        oItem = item;

                    if (oItem == null)
                        continue;

                    result.Add((T)oItem);
                }

                return result;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Returns the PyObject as a long
        /// </summary>
        /// <returns></returns>
        public long ToLong()
        {
            try
            {
                return IsValid ? Py.PyLong_AsLongLong(this) : 0;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Return the PyObject as a string
        /// </summary>
        /// <param name="p">Internal use only to prevent endless loops due circlular tuples/lists</param>
        /// <returns></returns>
        public string ToUnicodeString(bool p = true)
        {
            try
            {
                if (!IsValid)
                    return null;
                PyType type = GetPyType();

                // Manually convert from buffers to string
                if (type == PyType.UnicodeType)
                {
                    int size = Py.PyUnicodeUCS2_GetSize(this);
                    if (size <= 0)
                        return null;

                    IntPtr ptr = Py.PyUnicodeUCS2_AsUnicode(this);
                    if (ptr == IntPtr.Zero)
                        return null;

                    return Marshal.PtrToStringUni(ptr, size);
                }
                else if (type == PyType.StringType)
                {
                    int size = Py.PyString_Size(this);
                    if (size <= 0)
                        return null;

                    IntPtr ptr = Py.PyString_AsString(this);
                    if (ptr == IntPtr.Zero)
                        return null;

                    return Marshal.PtrToStringAnsi(ptr, size);
                }
                else if (type == PyType.BoolType)
                {
                    return ToBool().ToString();
                }
                else if (type == PyType.IntType)
                {
                    return ToInt().ToString();
                }
                else if (type == PyType.FloatType)
                {
                    return ToFloat().ToString();
                }
                else if (type == PyType.LongType)
                {
                    return ToFloat().ToString();
                }
                else if (p && (type == PyType.TupleType || type == PyType.ListType))
                {
                    List<PyObject> list = ToList();
                    string ret = "(";
                    foreach (PyObject obj in list)
                        ret += obj.ToUnicodeString(false) + ", ";
                    ret += ")";
                    return ret;
                }

                Console.WriteLine($"AttributeName {AttributeName} PyType {type} couldn't be converted to a string.");
                return string.Empty;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Call this PyObject as a python function
        /// </summary>
        /// <param name="parms"></param>
        /// <returns></returns>
        private PyObject CallThis(params object[] parms)
        {
            return CallThisWithKeywords(null, parms);
        }

        /// <summary>
        ///     Call this PyObject as a python function
        /// </summary>
        /// <param name="keywords"></param>
        /// <param name="parms"></param>
        /// <returns></returns>
        private PyObject CallThisWithKeywords(Dictionary<string, object> keywords, params object[] parms)
        {
            if (!IsValid)
                return PySharp.PyZero;

            if (_pySharp == null)
                throw new NotImplementedException();

            PyObject pyKeywords = PySharp.PyZero;
            if (keywords != null && keywords.Keys.Any())
            {
                pyKeywords = new PyObject(_pySharp, Py.PyDict_New(), true);
                foreach (KeyValuePair<string, object> item in keywords)
                {
                    PyObject pyValue = _pySharp.From(item.Value);

                    if (pyValue == null || pyValue.IsNull)
                        throw new NotImplementedException();

                    Py.PyDict_SetItem(pyKeywords, _pySharp.From(item.Key), pyValue);
                }
            }

            List<PyObject> pyParms = new List<PyObject>();
            foreach (object parm in parms)
            {
                PyObject pyParm = _pySharp.From(parm);

                if (pyParm == null || pyParm.IsNull)
                    throw new NotImplementedException();

                // Fail if any parameter is invalid (PyNone is a valid parameter)
                if (pyParm.IsNull)
                    return PySharp.PyZero;

                pyParms.Add(pyParm);
            }

            string format = "(" + string.Join("", pyParms.Select(dummy => "O").ToArray()) + ")";
            PyObject pyArgs = null;
            if (pyParms.Count == 0)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format), true);
            if (pyParms.Count == 1)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format, pyParms[0]), true);
            if (pyParms.Count == 2)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format, pyParms[0], pyParms[1]), true);
            if (pyParms.Count == 3)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format, pyParms[0], pyParms[1], pyParms[2]), true);
            if (pyParms.Count == 4)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format, pyParms[0], pyParms[1], pyParms[2], pyParms[3]), true);
            if (pyParms.Count == 5)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format, pyParms[0], pyParms[1], pyParms[2], pyParms[3], pyParms[4]), true);
            if (pyParms.Count == 6)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format, pyParms[0], pyParms[1], pyParms[2], pyParms[3], pyParms[4], pyParms[5]), true);
            if (pyParms.Count == 7)
                pyArgs = new PyObject(_pySharp, Py.Py_BuildValue(format, pyParms[0], pyParms[1], pyParms[2], pyParms[3], pyParms[4], pyParms[5], pyParms[6]),
                    true);
            if (pyParms.Count == 8)
                pyArgs = new PyObject(_pySharp,
                    Py.Py_BuildValue(format, pyParms[0], pyParms[1], pyParms[2], pyParms[3], pyParms[4], pyParms[5], pyParms[6], pyParms[7]), true);

            if (pyArgs == null)
                throw new NotImplementedException();

            return new PyObject(_pySharp, Py.PyEval_CallObjectWithKeywords(this, pyArgs, pyKeywords), true);
        }

        private PyObject GetIterator()
        {
            try
            {
                if (_pySharp == null || !IsValid)
                    return PySharp.PyZero;

                if (GetPyType() != PyType.SetType) //TODO: add other types
                    return PySharp.PyZero;

                PyObject result;
                result = new PyObject(_pySharp, Py.PyObject_GetIter(_pyReference), true);
                return result;
            }
            finally
            {
                HandlePythonError();
            }
        }

        /// <summary>
        ///     Handle a python error (e.g. clear error)
        /// </summary>
        /// <remarks>
        ///     This checks if an error actually occured and clears the error
        /// </remarks>
        private void HandlePythonError()
        {
            // TODO: Save the python error to a log file?
            if (Py.PyErr_Occurred() != IntPtr.Zero)
                Py.PyErr_Clear();
        }

        private PyObject InteratorNext(PyObject py)
        {
            if (_pySharp == null || !IsValid || !py.IsValid)
                return PySharp.PyZero;
            try
            {
                PyObject result;
                result = new PyObject(_pySharp, Py.PyIter_Next(py._pyReference), true);
                return result;
            }
            finally
            {
                HandlePythonError();
            }
        }

        private List<T> SetToList<T>()
        {
            List<T> result = new List<T>();
            if (!IsValid || GetPyType() != PyType.SetType) //TODO: add other set types
                return result;
            try
            {
                PyObject iter = GetIterator();
                for (PyObject obj; (obj = InteratorNext(iter)).IsValid && iter.IsValid;) // can't declare a variable within a while loop in c#
                {
                    PyObject item = obj;
                    object oItem = null;
                    if (typeof(T) == typeof(int))
                        oItem = item.ToInt();
                    if (typeof(T) == typeof(long))
                        oItem = item.ToLong();
                    if (typeof(T) == typeof(float))
                        oItem = item.ToFloat();
                    if (typeof(T) == typeof(double))
                        oItem = item.ToDouble();
                    if (typeof(T) == typeof(string))
                        oItem = item.ToUnicodeString();
                    if (typeof(T) == typeof(PyObject))
                        oItem = item;

                    if (oItem == null)
                        continue;

                    result.Add((T)oItem);
                }
            }
            finally
            {
                HandlePythonError();
            }

            return result;
        }

        #endregion Methods
    }
}