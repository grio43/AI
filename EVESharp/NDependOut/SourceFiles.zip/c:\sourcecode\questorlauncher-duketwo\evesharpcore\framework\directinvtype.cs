﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;
using System;
using System.Collections.Generic;
using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public enum BracketType
    {
        Unknown,
        Agents_in_Space,
        Assembly_Array,
        Asteroid_Belt,
        Asteroid_Billboard,
        Asteroid_Large,
        Asteroid_Medium,
        Asteroid_Small,
        Battlecruiser,
        Battleship,
        Biomass,
        Bomb,
        Capsule,
        Capture_Point,
        Cargo_container,
        Cargo_Container_NPC,
        Carrier,
        Celestial_Agent_Site_Beacon,
        Celestial_Beacon_II,
        Command_Node_Beacon,
        Compression_Array,
        Control_Tower,
        Corporate_Hangar_Array,
        Cruiser,
        Cynosural_Field,
        Cynosural_Generator_Array,
        Cynosural_System_Jammer,
        Destroyer,
        Destructible_Station_Service,
        Dreadnought,
        Drone,
        Drone_EW,
        Drone_Logistics,
        Drone_Mining,
        Drone_Salvaging,
        Drone_Sentry,
        Encounter_Surveillance_System,
        Entity,
        Extra_Large_Engineering_Complex,
        Extra_Large_Structure,
        Fighter_Squadron,
        Force_Auxiliary,
        Force_Field,
        Freighter,
        Frigate,
        FW_Infrastructure_Hub,
        Harvestable_Cloud,
        Ice_Field,
        Ice_Large,
        Ice_Small,
        Industrial_Command_Ship,
        Industrial_Ship,
        Infrastructure_Hub,
        Jump_Portal_Array,
        Laboratory,
        Large_Collidable_Structure,
        Large_Engineering_Complex,
        Large_Refinery,
        Large_Structure,
        Medium_Engineering_Complex,
        Medium_Refinery,
        Medium_Structure,
        Mining_Barge,
        Mining_Frigate,
        Mobile_Cynosural_Inhibitor,
        Mobile_Depot,
        Mobile_Jump_Disruptor,
        Mobile_Micro_Jump_Unit,
        Mobile_Power_Core,
        Mobile_Scan_Inhibitor,
        Mobile_Shield_Generator,
        Mobile_Siphon_Unit,
        Mobile_Storage,
        Mobile_Tractor_Unit,
        Mobile_Warp_Disruptor,
        Moon,
        Moon_Asteroid,
        Moon_Asteroid_Jackpot,
        Moon_Mining,
        Navy_Concord_Customs,
        NO_BRACKET,
        NPC_Battlecruiser,
        NPC_Battleship,
        NPC_Carrier,
        NPC_Cruiser,
        NPC_Destroyer,
        NPC_Dreadnought,
        NPC_Drone,
        NPC_Drone_EW,
        NPC_Extra_Large_Engineering_Complex,
        NPC_Fighter,
        NPC_Fighter_Bomber,
        NPC_Force_Auxiliary,
        NPC_Freighter,
        NPC_Frigate,
        NPC_Industrial,
        NPC_Industrial_Command_Ship,
        NPC_Mining_Barge,
        NPC_Mining_Frigate,
        NPC_Rookie_Ship,
        NPC_Shuttle,
        NPC_Super_Carrier,
        NPC_Titan,
        Personal_Hangar_Array,
        Planet,
        Planetary_Customs_Office,
        Planetary_Customs_Office_NPC,
        Platform,
        Reactor,
        Reprocessing_Array,
        Rookie_ship,
        Satellite_Beacon,
        Scanner_Array,
        Scanner_Probe,
        Sentry_Gun,
        Ship_Maintenance_Array,
        Shuttle,
        Silo,
        Sovereignty_Blockade_Unit,
        Starbase_Electronic_Warfare_Battery,
        Starbase_Energy_Neutralizing_Battery,
        Starbase_Hybrid_Battery,
        Starbase_Laser_Battery,
        Starbase_Missile_Battery,
        Starbase_Projectile_Battery,
        Starbase_Sensor_Dampening_Battery,
        Starbase_Shield_Hardening_Array,
        Starbase_Stasis_Webification_Battery,
        Starbase_Warp_Scrambling_Battery,
        Stargate,
        Station,
        Structure,
        Sun,
        Super_Carrier,
        Territorial_Claim_Unit,
        Titan,
        Warp_Gate,
        Wormhole,
        Wreck,
        Wreck_NPC,
        XL_Ship_maintenance_Array
    }

    public class DirectInvType : DirectObject
    {
        #region Fields

        /// <summary>
        ///     TypeId; Bracketname dict
        /// </summary>
        private static readonly Dictionary<int, string> _bracketNameDictionary = new Dictionary<int, string>();

        private static readonly Dictionary<int, string> _bracketTexturePathDictionary = new Dictionary<int, string>();
        private static readonly Dictionary<int, BracketType> _bracketTypeDictionary = new Dictionary<int, BracketType>();
        private static readonly Dictionary<int, DirectInvType> invTypeCache = new Dictionary<int, DirectInvType>();
        private Dictionary<string, object> _attrdictionary;
        private double? _averagePrice;
        private double? _basePrice;
        private double? _capacity;

        private int? _categoryId;

        //private string _categoryName;
        private double? _chanceOfDuplicating;

        private int? _dataId;
        private string _description;

        private List<PyObject> _dmgAttributes;

        //private double? _emTurretEffectiveDps;

        //private double? _emMissileEffectiveDps;
        private int? _graphicId;
        private int? _groupId;
        private string _groupName;
        private int? _iconId;

        //private double? _kineticTurretEffectiveDps;

        private int? _marketGroupId;

        //private double? _kineticMissileEffectiveDps;
        private double? _mass;


        //private double? _emTurretEffectiveDamage;


        //private double? _explosiveEffectiveDps;


        //private double? _explosiveMissileEffectiveDps;
        private int? _portionSize;

        private bool? _published;

        //private PyObject _pyInvCategory;
        private PyObject _pyInvGroup;

        private PyObject _pyInvType;
        private int? _raceId;
        private double? _radius;
        private int? _soundId;


        //private double? _thermalTurretEffectiveDps;

        //private double? _thermalMissileEffectiveDps;
        private string _typeName;
        private double? _volume;

        #endregion Fields

        #region Constructors

        public DirectInvType(DirectEve directEve, int typeId)
            : base(directEve)
        {
            TypeId = typeId;
        }

        internal DirectInvType(DirectEve directEve)
            : base(directEve)
        {
        }

        #endregion Constructors

        #region Properties

        private string _categoryName;

        private PyObject _pyInvCategory;

        public double BasePrice
        {
            get
            {
                if (!_basePrice.HasValue)
                    _basePrice = (double) PyInvType.Attribute("basePrice");

                return _basePrice.Value;
            }
        }

        public BracketType BracketType
        {
            get
            {
                if (_bracketTypeDictionary.TryGetValue(TypeId, out var bracketType)) return bracketType;

                BracketType r = default(BracketType);
                if (Enum.TryParse<BracketType>(GetBracketName().Replace(" ", "_"), out var type)) r = type;

                _bracketTypeDictionary[TypeId] = r;
                return r;
            }
        }

        public double Capacity
        {
            get
            {
                if (!_capacity.HasValue)
                    _capacity = (double) PyInvType.Attribute("capacity");

                return _capacity.Value;
            }
        }

        public int CategoryId
        {
            get
            {
                if (!_categoryId.HasValue)
                    _categoryId = (int) PyInvGroup.Attribute("categoryID");

                return _categoryId.Value;
            }
        }

        public string CategoryName
        {
            get
            {
                if (string.IsNullOrEmpty(_categoryName))
                    _categoryName = (string) PySharp.Import("evetypes")
                        .Attribute("localizationUtils")
                        .Call("GetLocalizedCategoryName", (int) PyInvCategory.Attribute("categoryNameID"), "en-us");
                return _categoryName;
            }
        }

        public double ChanceOfDuplicating
        {
            get
            {
                if (!_chanceOfDuplicating.HasValue)
                    _chanceOfDuplicating = (double) PyInvType.Attribute("chanceOfDuplicating");

                return _chanceOfDuplicating.Value;
            }
        }

        public int DataId
        {
            get
            {
                if (!_dataId.HasValue)
                    _dataId = (int) PyInvType.Attribute("dataID");

                return _dataId.Value;
            }
        }

        public string Description
        {
            get
            {
                if (string.IsNullOrEmpty(_description))
                    _description = (string) PyInvType.Attribute("description");

                return _description;
            }
        }

        //     quote = sm.GetService('marketQuote')
        // averagePrice = quote.GetAveragePrice(typeID)
        public double GetAveragePrice
        {
            get
            {
                if (_averagePrice == null) _averagePrice = (double) DirectEve.GetLocalSvc("marketQuote").Call("GetAveragePrice", TypeId);

                return _averagePrice == null ? 0 : (double) _averagePrice;
            }
        }

        public int GraphicId
        {
            get
            {
                if (!_graphicId.HasValue)
                    _graphicId = (int) PyInvType.Attribute("graphicID");

                return _graphicId.Value;
            }
        }

        public int GroupId
        {
            get
            {
                if (!_groupId.HasValue)
                    _groupId = (int) PyInvType.Attribute("groupID");

                return _groupId.Value;
            }
        }

        public bool IsContainerUsedToSortItemsInStations
        {
            get
            {
                if (GroupId == (int)Group.CargoContainer)
                    return true;

                if (GroupId == (int)Group.SecureContainer)
                    return true;

                if (GroupId == (int)Group.AuditLogSecureContainer)
                    return true;

                if (GroupId == (int)Group.FreightContainer)
                    return true;

                return false;
            }
        }

        private double? _armorResistanceEm;

        private double? _armorResistanceExplosive;

        private double? _armorResistanceKinetic;

        private double? _armorResistanceThermal;


        public double? ArmorResistanceEm
        {
            get
            {
                if (!_armorResistanceEm.HasValue)
                    _armorResistanceEm = Math.Round(1.0d - TryGet<float>("armorEmDamageResonance"), 2);
                return _armorResistanceEm ?? 0;
            }
        }

        private double? _optimalRange;

        public double OptimalRange
        {
            get
            {
                if (!_optimalRange.HasValue)
                    _optimalRange = (double)PyInvType.Attribute("maxRange");

                return _optimalRange.Value;
            }
        }

        private double? _falloff;

        public double? Falloff
        {
            get
            {
                if (_falloff == null)
                    _falloff = (float)PyInvType.Attribute("falloff");
                return _falloff.Value;
            }
        }

        public double? ArmorResistanceExplosive
        {
            get
            {
                if (!_armorResistanceExplosive.HasValue)
                    _armorResistanceExplosive = Math.Round(1.0d - TryGet<float>("armorExplosiveDamageResonance"), 2);
                return _armorResistanceExplosive ?? 0;
            }
        }

        public double? ArmorResistanceKinetic
        {
            get
            {
                if (!_armorResistanceKinetic.HasValue)
                    _armorResistanceKinetic = Math.Round(1.0d - TryGet<float>("armorKineticDamageResonance"), 2);
                return _armorResistanceKinetic ?? 0;
            }
        }

        public double? ArmorResistanceThermal
        {
            get
            {
                if (!_armorResistanceThermal.HasValue)
                    _armorResistanceThermal = Math.Round(1.0d - TryGet<float>("armorThermalDamageResonance"), 2);
                return _armorResistanceThermal ?? 0;
            }
        }

        private double? _shieldResistanceEM;
        private double? _shieldResistanceExplosive;
        private double? _shieldResistanceKinetic;
        private double? _shieldResistanceThermal;

        public double? ShieldResistanceEM
        {
            get
            {
                if (!_shieldResistanceEM.HasValue)
                    _shieldResistanceEM = Math.Round(1.0d - TryGet<float>("shieldEmDamageResonance"), 2);
                return _shieldResistanceEM ?? 0;
            }
        }

        public double? ShieldResistanceExplosive
        {
            get
            {
                if (!_shieldResistanceExplosive.HasValue)
                    _shieldResistanceExplosive = Math.Round(1.0d - TryGet<float>("shieldExplosiveDamageResonance"), 2);
                return _shieldResistanceExplosive ?? 0;
            }
        }

        public double? ShieldResistanceKinetic
        {
            get
            {
                if (!_shieldResistanceKinetic.HasValue)
                    _shieldResistanceKinetic = Math.Round(1.0d - TryGet<float>("shieldKineticDamageResonance"), 2);
                return _shieldResistanceKinetic ?? 0;
            }
        }

        public double? ShieldResistanceThermal
        {
            get
            {
                if (!_shieldResistanceThermal.HasValue)
                    _shieldResistanceThermal = Math.Round(1.0d - TryGet<float>("shieldThermalDamageResonance"), 2);
                return _shieldResistanceThermal ?? 0;
            }
        }

        private bool? _isMissile;

        public bool IsMissile
        {
            get
            {
                if (CategoryId != (int)CategoryID.Charge) return false;

                if (_isMissile == null)
                {
                    if (GroupId != 0)
                    {
                        switch (GroupId)
                        {
                            case (int) Group.Rockets:
                            case (int) Group.LightMissiles:
                            case (int) Group.HeavyMissiles:
                            case (int) Group.HeavyAssaultMissiles:
                            case (int) Group.CruiseMissiles:
                            case (int) Group.Torpedoes:
                            {
                                _isMissile = true;
                                return (bool)_isMissile;
                            }
                        }

                        _isMissile = false;
                        return (bool)_isMissile;
                    }

                    _isMissile = false;
                    return (bool)_isMissile;
                }

                return (bool)_isMissile;
            }
        }

        public string GroupName
        {
            get
            {
                if (string.IsNullOrEmpty(_groupName))
                    _groupName = (string) PySharp.Import("evetypes")
                        .Attribute("localizationUtils")
                        .Call("GetLocalizedGroupName", (int) PyInvGroup.Attribute("groupNameID"), "en-us");
                return _groupName;
            }
        }

        public int IconId
        {
            get
            {
                if (!_iconId.HasValue)
                    _iconId = (int) PyInvType.Attribute("iconID");

                return _iconId.Value;
            }
        }

        public int MarketGroupId
        {
            get
            {
                if (!_marketGroupId.HasValue)
                    _marketGroupId = (int) PyInvType.Attribute("marketGroupID");

                return _marketGroupId.Value;
            }
        }

        public double Mass
        {
            get
            {
                if (!_mass.HasValue)
                    _mass = (double) PyInvType.Attribute("mass");

                return _mass.Value;
            }
        }

        public int PortionSize
        {
            get
            {
                if (!_portionSize.HasValue)
                    _portionSize = (int) PyInvType.Attribute("portionSize");

                return _portionSize.Value;
            }
        }

        public bool Published
        {
            get
            {
                if (!_published.HasValue)
                    _published = (bool) PyInvType.Attribute("published");

                return _published.Value;
            }
        }

        public int RaceId
        {
            get
            {
                if (!_raceId.HasValue)
                    _raceId = (int) PyInvType.Attribute("raceID");

                return _raceId.Value;
            }
        }

        public double Radius
        {
            get
            {
                if (!_radius.HasValue)
                    _radius = (float)PyInvType.Attribute("radius");

                return _radius.Value;
            }
        }


        /**
        public double? SignatureRadius
        {
            get
            {
                if (!_signatureRadius.HasValue)
                    _signatureRadius = (float)PyInvType.Attribute("signatureRadius") ?? 0;
                return _signatureRadius.Value;
            }
        }
        **/

        public int SoundId
        {
            get
            {
                if (!_soundId.HasValue)
                    _soundId = (int) PyInvType.Attribute("soundID");

                return _soundId.Value;
            }
        }

        private double? _totalArmor;
        private double? _totalShield;
        private double? _totalStructure;



        public double? TotalHealth => TotalShield + TotalArmor + TotalStructure;

        public double? TotalArmor
        {
            get
            {
                if (!_totalArmor.HasValue)
                    _totalArmor = TryGet<float>("armorHP");
                return _totalArmor;
            }
        }

        public double? TotalShield
        {
            get
            {
                if (!_totalShield.HasValue)
                    _totalShield = TryGet<float>("shieldCapacity");
                return _totalShield;
            }
        }

        public double? TotalStructure
        {
            get
            {
                if (!_totalStructure.HasValue)
                    _totalStructure = TryGet<float>("hp");
                return _totalStructure;
            }
        }

        public int TypeId { get; internal set; }

        public string TypeName
        {
            get
            {
                if (string.IsNullOrEmpty(_typeName))
                    _typeName = (string) PySharp.Import("evetypes")
                        .Attribute("localizationUtils")
                        .Call("GetLocalizedTypeName", (int) PyInvType.Attribute("typeNameID"), "en-us");

                return _typeName;
            }
        }

        public double Volume
        {
            get
            {
                if (!_volume.HasValue)
                    _volume = (double) PyInvType.Attribute("volume");

                return _volume.Value;
            }
        }

        internal PyObject PyInvCategory => _pyInvCategory ?? (_pyInvCategory = PySharp.Import("evetypes")
                                               .Attribute("CategoryStorage")
                                               .Attribute("_storage")
                                               .DictionaryItem(CategoryId));

        internal PyObject PyInvGroup => _pyInvGroup ?? (_pyInvGroup = PySharp.Import("evetypes")
                                            .Attribute("GroupStorage")
                                            .Attribute("_storage")
                                            .DictionaryItem(GroupId));

        internal PyObject PyInvType => _pyInvType ?? (_pyInvType = PySharp.Import("evetypes")
                                           .Attribute("storages")
                                           .Attribute("TypeStorage")
                                           .Attribute("_storage")
                                           .DictionaryItem(TypeId));

        #endregion Properties

        #region Methods

        public Dictionary<string, object> GetAttributesInvType()
        {
            if (_attrdictionary == null)
            {
                _attrdictionary = new Dictionary<string, object>();
                List<PyObject> dmgA = dmgAttributes();
                if (dmgA == null)
                    return _attrdictionary;
                foreach (PyObject pyitem in dmgAttributes())
                    try
                    {
                        int itemkeyattr = (int) pyitem.Attribute("attributeID");
                        string itemattr = (string) DirectEve.PySharp.Import("__builtin__")
                            .Attribute("cfg")
                            .Attribute("_dgmattribs")
                            .DictionaryItem(itemkeyattr)
                            .Attribute("attributeName");

                        object type = null;
                        PyObject pyitemvalue = pyitem.Attribute("value");
                        switch (pyitemvalue.GetPyType())
                        {
                            case PyType.IntType:
                                type = pyitemvalue.ToInt();
                                break;

                            case PyType.LongType:
                                type = pyitemvalue.ToLong();
                                break;

                            case PyType.StringType:
                            case PyType.UnicodeType:
                                type = pyitemvalue.ToUnicodeString();
                                break;

                            case PyType.BoolType:
                                type = pyitemvalue.ToBool();
                                break;

                            case PyType.FloatType:
                                type = pyitemvalue.ToFloat();
                                break;

                            default:
                                DirectEve.Log("DirectItemAttributes Item Unknow type [" + itemattr + "]");
                                break;
                        }
                        _attrdictionary[itemattr] = type;
                    }
                    catch (Exception ex)
                    {
                        DirectEve.Log("DirectInvTypes.GetAttributes exception:" + ex);
                    }
            }
            return _attrdictionary;
        }

        /// <summary>
        ///     Retrieves the bracket data
        /// </summary>
        /// <returns></returns>
        public PyObject GetBracketData()
        {
            PyObject bracketSvc = DirectEve.GetLocalSvc("bracket");

            int getBracketId()
            {
                if (bracketSvc.IsValid)
                {
                    PyObject bracketDataByTypeID = bracketSvc.Attribute("bracketDataByTypeID");
                    if (bracketDataByTypeID.IsValid)
                    {
                        PyObject bd = bracketDataByTypeID.Call("Get", TypeId);
                        if (bd.IsValid)
                            return bd.ToInt();
                    }

                    PyObject bracketDataByGroupID = bracketSvc.Attribute("bracketDataByGroupID");
                    if (bracketDataByGroupID.IsValid)
                    {
                        PyObject bd = bracketDataByGroupID.Call("Get", GroupId);
                        if (bd.IsValid)
                            return bd.ToInt();
                    }

                    PyObject bracketDataByCategoryID = bracketSvc.Attribute("bracketDataByCategoryID");
                    if (bracketDataByCategoryID.IsValid)
                    {
                        PyObject bd = bracketDataByCategoryID.Call("Get", CategoryId);
                        if (bd.IsValid)
                            return bd.ToInt();
                    }
                }

                return 0;
            }

            int bracketId = getBracketId();
            if (bracketId != 0)
            {
                PyObject bracketData = bracketSvc.Call("GetBrackeDatatByID", bracketId);
                return bracketData;
            }

            return PySharp.PyZero;
        }

        /// <summary>
        ///     Retrieves the bracket name, 'NPC Battleship' for example
        /// </summary>
        /// <returns></returns>
        public string GetBracketName()
        {
            if (_bracketNameDictionary.TryGetValue(TypeId, out var name))
                return name;

            name = string.Empty;
            PyObject bd = GetBracketData();
            if (bd.IsValid) name = (string) bd.Attribute("name");
            if (GroupId == 446)
                _bracketNameDictionary[TypeId] = BracketType.Navy_Concord_Customs.ToString();
            else
                _bracketNameDictionary[TypeId] = name;
            return _bracketNameDictionary[TypeId];
        }

        public string GetBracketTexturePath()
        {
            if (_bracketTexturePathDictionary.TryGetValue(TypeId, out var texturePath))
                return texturePath;

            texturePath = string.Empty;
            PyObject bd = GetBracketData();
            if (bd.IsValid) texturePath = (string) bd.Attribute("texturePath");
            if (string.IsNullOrEmpty(texturePath))
                texturePath = string.Empty;
            _bracketTexturePathDictionary[TypeId] = texturePath;
            return texturePath;
        }

        public T TryGet<T>(string keyname)
        {
            object obj = null;
            if (GetAttributesInvType().ContainsKey(keyname))
            {
                object item = GetAttributesInvType()[keyname];
                if (item != null)
                {
                    if (typeof(T) == typeof(bool))
                    {
                        obj = (int) item;
                        return (T) obj;
                    }
                    if (typeof(T) == typeof(string))
                    {
                        obj = (string) item;
                        return (T) obj;
                    }
                    if (typeof(T) == typeof(int))
                    {
                        obj = (int) item;
                        return (T) obj;
                    }
                    if (typeof(T) == typeof(long))
                    {
                        obj = (long) item;
                        return (T) obj;
                    }
                    if (typeof(T) == typeof(float))
                    {
                        obj = (float) item;
                        return (T) obj;
                    }
                    if (typeof(T) == typeof(double))
                    {
                        obj = Convert.ToDouble(item);
                        return (T) obj;
                    }
                    if (typeof(T) == typeof(DateTime))
                    {
                        obj = Convert.ToDateTime(item);
                        return (T) obj;
                    }
                }
            }
            return default(T);
        }

        internal static DirectInvType GetInvType(DirectEve directEve, int typeId)
        {
            if (invTypeCache.TryGetValue(typeId, out var cachedInvType))
                return cachedInvType;
            PyObject pyDictItem = directEve.PySharp.Import("evetypes")
                .Attribute("storages")
                .Attribute("TypeStorage")
                .Attribute("_storage")
                .DictionaryItem(typeId);
            DirectInvType ret = pyDictItem != null && pyDictItem.IsValid ? new DirectInvType(directEve, typeId) : null;
            invTypeCache[typeId] = ret;
            return ret;
        }

        internal static Dictionary<string, int> GetInvTypeNames(DirectEve directEve)
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            Dictionary<int, PyObject> pyDict = directEve.PySharp.Import("evetypes").Attribute("storages").Attribute("TypeStorage").Attribute("_storage").ToDictionary<int>();
            foreach (KeyValuePair<int, PyObject> pair in pyDict) result[new DirectInvType(directEve, pair.Key).TypeName] = pair.Key;
            return result;
        }

        private List<PyObject> dmgAttributes()
        {
            if (_dmgAttributes == null)
            {
                PyObject _dmgAttribute = DirectEve.PySharp.Import("__builtin__").Attribute("cfg").Attribute("_dgmtypeattribs").DictionaryItem(TypeId);
                if (!_dmgAttribute.IsValid)
                    return null;
                _dmgAttributes = _dmgAttribute.ToList();
            }

            return _dmgAttributes;
        }

        #endregion Methods
    }
}