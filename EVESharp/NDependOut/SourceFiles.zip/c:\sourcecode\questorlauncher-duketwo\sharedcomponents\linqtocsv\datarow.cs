﻿using System.Collections.Generic;

namespace SharedComponents.LINQtoCSV
{
    public class DataRow : List<DataRowItem>, IDataRow
    {
    }
}