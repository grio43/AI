﻿extern alias SC;

using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    public class DirectNewEdenStoreOffer : DirectObject
    {
        #region Constructors

        public DirectNewEdenStoreOffer(DirectEve directEve, PyObject offer, PyObject detailContainer) : base(directEve)
        {
            this.offer = offer;
            this.detailContainer = detailContainer;
        }

        #endregion Constructors

        // 500
        // 2293

        #region Methods

        public void BuyOffer()
        {
            PyObject buyButton = detailContainer.Attribute("activeBottomPanel").Attribute("buyButton");
            if (buyButton.IsValid)
                DirectEve.ThreadedCall(buyButton.Attribute("OnClick"));
        }

        #endregion Methods

        #region Fields

        private readonly PyObject detailContainer;
        private readonly PyObject offer;

        #endregion Fields

        #region Properties

        public int OfferId => offer.Attribute("id").ToInt();
        public string OfferName => offer.Attribute("name").ToUnicodeString(); // "30 Day Omega Clone time"
        public float Price => offer.Attribute("offerPricings").ToList()[0].Attribute("price").ToFloat();

        #endregion Properties
    }
}