﻿using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Drawing;
using System.Threading;

namespace SharedComponents.Utility.AsyncLogQueue
{
    public class AsyncLogQueue
    {
        #region Delegates

        public delegate void Message(string msg, Color? col);

        #endregion Delegates

        #region Constructors

        public AsyncLogQueue()
        {
            _Logger.WorkerSupportsCancellation = false;
            _Logger.DoWork += _Logger_DoWork;
        }

        #endregion Constructors

        #region Properties

        public string File { get; set; }

        #endregion Properties

        #region Events

        public event Message OnMessage;

        #endregion Events

        #region Fields

        private readonly ConcurrentQueue<LogEntry> _LogEntryQueue = new ConcurrentQueue<LogEntry>();

        private readonly BackgroundWorker _Logger = new BackgroundWorker();

        private readonly object lockObj = new object();

        private readonly SemaphoreSlim sema = new SemaphoreSlim(1, 1);

        #endregion Fields

        #region Methods

        public void Enqueue(LogEntry le)
        {
            try
            {
                _LogEntryQueue.Enqueue(le);
                lock (lockObj) // lock because it rarely can happen that two threads call runWorkerAsync
                {
                    if (!_LogEntryQueue.IsEmpty && !_Logger.IsBusy)
                        _Logger.RunWorkerAsync();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
            }
        }

        private void _Logger_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                while (!_LogEntryQueue.IsEmpty && _LogEntryQueue.TryDequeue(out var le))
                {
                    string msg = string.Format("[{0:dd-MMM-yy HH:mm:ss:fff}] {1}", DateTime.UtcNow, "[" + le.DescriptionOfWhere + "] " + le.Message);
                    OnMessage?.Invoke(msg, le.Color);
                    if (!string.IsNullOrEmpty(File))
                        Util.WriteTextAsync(File, msg + Environment.NewLine, sema);
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.ToString());
            }
        }

        #endregion Methods
    }
}