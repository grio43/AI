﻿extern alias SC;

using SC::SharedComponents.Py;
using SC::SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Framework
{
    public class DirectMapViewWindow : DirectWindow
    {
        #region Constructors

        internal DirectMapViewWindow(DirectEve directEve, PyObject pyWindow) : base(directEve, pyWindow)
        {
        }

        #endregion Constructors

        #region Fields

        private List<DirectDirectionalScanResult> _scanResults;
        private List<DirectSystemScanResult> _systemScanResults;

        #endregion Fields

        #region Properties

        public bool UpdateRangeInput
        {
            get
            {
                //def UpdateRangeInput(self, scanRangeKM):
                //Distances.AU


                return false;
            }
        }

        public List<DirectDirectionalScanResult> DirectionalScanResults
        {
            get
            {
                long? charId = DirectEve.Session.CharacterId;
                if (_scanResults == null && charId != null)
                {
                    _scanResults = new List<DirectDirectionalScanResult>();
                    foreach (PyObject result in PyWindow.Attribute("mapView").Attribute("directionalScannerPalette").Attribute("scanresult").Attribute("lines")
                        .ToList())
                    {
                        // scan result is a list of tuples
                        List<PyObject> resultAsList = result.ToList();
                        _scanResults.Add(new DirectDirectionalScanResult(DirectEve, resultAsList[0].ToLong(),
                            resultAsList[1].ToInt(), resultAsList[2].ToInt()));
                    }
                }

                return _scanResults;
            }
        }

        public List<DirectSystemScanResult> SystemScanResults
        {
            get
            {
                if (_systemScanResults == null)
                {
                    _systemScanResults = new List<DirectSystemScanResult>();
                    List<PyObject> pyResults = DirectEve.GetLocalSvc("scanSvc").Call("GetResults").Item(0).ToList();
                    foreach (PyObject pyResult in pyResults) _systemScanResults.Add(new DirectSystemScanResult(DirectEve, pyResult));
                }

                return _systemScanResults;
            }
        }

        #endregion Properties

        #region Methods

        public void DecreaseProbeRange()
        {
            foreach (DirectScannerProbe p in GetProbes()) p.DecreaseProbeRange();
        }

        public bool IsAnyProbeAtMinRange
        {
            get
            {
                foreach (var p in GetProbes())
                {
                    if (p.IsAtMinRange)
                        return true;
                }
                return false;
            }
        }

        public bool IsAnyProbeAtMaxRange
        {
            get
            {
                foreach (var p in GetProbes())
                {
                    if (p.IsAtMaxRange)
                        return true;
                }
                return false;
            }
        }

        public void DirectionalScan()
        {
            if (!IsDirectionalScanOpen())
                return;

            if (IsDirectionalScanning())
                return;

            DirectEve.ThreadedCall(PyWindow.Attribute("mapView").Attribute("directionalScannerPalette").Attribute("DirectionalScan"));
        }

        public List<Vector3> GetPinPointCoordinates()
        {
            List<Vector3> offsets = new List<Vector3> {new Vector3(0, 0, 0), new Vector3(0, 0.2, 0), new Vector3(0, -0.2, 0)};

            double GetXValue(double i)
            {
                //return 0.4d * Math.Cos(i * 2 * Math.PI / 5);
                //return 0.3d * Math.Cos(i * 2 * Math.PI / 5);
                return 0.2d * Math.Cos(i * 2 * Math.PI / 5);
            }

            double GetZValue(double i)
            {
                //return 0.4d * Math.Sin(i * 2 * Math.PI / 5);
                //return 0.3d * Math.Sin(i * 2 * Math.PI / 5);
                return 0.2d * Math.Sin(i * 2 * Math.PI / 5);
            }

            for (int i = 0; i < 5; i++) offsets.Add(new Vector3(GetXValue(i), 0, GetZValue(i)));
            return offsets;
        }

        public List<DirectScannerProbe> GetProbes()
        {
            List<DirectScannerProbe> Probes = new List<DirectScannerProbe>();
            Dictionary<long, PyObject> pyProbes = DirectEve.GetLocalSvc("scanSvc").Attribute("probeTracker").Attribute("probeData").ToDictionary<long>();
            foreach (KeyValuePair<long, PyObject> pyProbe in pyProbes)
                //DirectEve.Log($"{pyProbe.Value.LogObject()}");
                Probes.Add(new DirectScannerProbe(DirectEve, pyProbe.Value));

            return Probes;
        }

        public void IncreaseProbeRange()
        {
            foreach (DirectScannerProbe p in GetProbes()) p.IncreaseProbeRange();
        }

        public bool IsDirectionalScannerDocked()
        {
            return PyWindow.Attribute("mapView").Attribute("directionalScannerPalette").IsValid;
        }

        public bool IsDirectionalScanning()
        {
            return DirectEve.GetLocalSvc("directionalScanSvc").Attribute("isScanning").ToBool();
        }

        public bool IsDirectionalScanOpen()
        {
            return PyWindow.Attribute("mapView").Attribute("directionalScannerPalette").IsValid
                   || DirectEve.IsDirectionalScannerWindowOpen;
        }

        public bool IsProbeScannerDocked()
        {
            return PyWindow.Attribute("mapView").Attribute("probeScannerPalette").IsValid;
        }

        public bool IsProbeScanning()
        {
            return DirectEve.GetLocalSvc("scanSvc").Call("IsScanning").ToBool();
        }

        public bool ClearIgnoredResult()
        {
            return DirectEve.GetLocalSvc("scanSvc").Call("ClearIgnoredResults").ToBool();
        }

        public bool IsProbeScanOpen()
        {
            return PyWindow.Attribute("mapView").Attribute("probeScannerPalette").IsValid
                   || DirectEve.IsProbeScannerWindowOpen;
        }



        public void MoveProbesTo(Vector3 dest)
        {
            List<Vector3> pinpointOffsets = GetPinPointCoordinates();
            int i = 0;
            foreach (DirectScannerProbe p in GetProbes())
            {
                p.SetLocation(dest + pinpointOffsets[i] * (149598000000 * p.RangeAu));
                i++;
            }
        }

        public void ProbeScan()
        {
            {
                if (!IsProbeScanOpen())
                    return;

                if (IsProbeScanning())
                    return;

                PyObject primaryButton = PyWindow.Attribute("mapView").Attribute("probeScannerPalette").Attribute("primaryButton");

                bool? disabled = (bool?) primaryButton.Attribute("disabled");
                string primaryButtonText = primaryButton.Attribute("text").ToUnicodeString();

                if (primaryButtonText != "<center>Analyze</center>")
                    return;

                if (!disabled.HasValue || disabled.Value)
                    return;

                DirectEve.ThreadedCall(PyWindow.Attribute("mapView").Attribute("probeScannerPalette").Attribute("Analyze"));
            }
        }

        public bool RecoverProbes()
        {
            List<DirectScannerProbe> probes = GetProbes();
            if (probes.Any())
                return DirectEve.ThreadedCall(DirectEve.GetLocalSvc("scanSvc").Attribute("RecoverProbes"), probes.Select(p => p.ProbeId));

            return false;
        }

        public void RefreshUI()
        {
            foreach (DirectScannerProbe p in GetProbes()) p.RefreshUI();
        }

        public void SetMaxProbeRange()
        {
            foreach (DirectScannerProbe p in GetProbes()) p.SetMaxProbeRange();
        }

        #endregion Methods
    }
}