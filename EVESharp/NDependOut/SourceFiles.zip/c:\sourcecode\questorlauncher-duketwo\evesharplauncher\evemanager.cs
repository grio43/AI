﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 31.01.2014
 * Time: 12:00
 *
 * ---------------------------------------
 */

using SharedComponents.EVE;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Xml;
using System.Xml.Linq;

using SharedComponents.Utility;

namespace EVESharpLauncher
{
    public class EveManager : IDisposable
    {
        #region Fields

        public static Thread eveManagerThread;
        public static Thread eveSettingsManagerThread;
        public static bool isEveManagerThreadAborting;
        public static bool isEveSettingsManagerThreadAborting;
        private static readonly Random rnd = new Random();
        private static Thread eveKillThread;

        #endregion Fields

        #region Properties

        public static EveManager Instance { get; } = new EveManager();

        private bool IsAnyEveProcessAlive
        {
            get { return Cache.Instance.EveAccountSerializeableSortableBindingList.List.Any(e => e.Running); }
        }

        #endregion Properties

        #region Methods

        private DateTime NextEveManagerThreadTimeStamp = DateTime.UtcNow.AddSeconds(-1);
        private DateTime EveManagerStart = DateTime.UtcNow;

        public void Dispose()
        {
            DisposeEveManager();
            DisposeEveSettingsManager();
        }

        public void DisposeEveManager()
        {
            if (!isEveManagerThreadAborting)
                isEveManagerThreadAborting = true;
        }

        public void DisposeEveSettingsManager()
        {
            if (!isEveSettingsManagerThreadAborting)
                isEveSettingsManagerThreadAborting = true;
        }

        public void KillEveInstances()
        {
            foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(a => a.Running))
                eA.KillEveProcess(true);
        }

        public void KillEveInstancesDelayed()
        {
            if (eveKillThread == null || !eveKillThread.IsAlive)
            {
                Cache.Instance.Log("Stopping all eve instances delayed.");
                eveKillThread = new Thread(KillEveInstancesDelayedThread);
                eveKillThread.Start();
            }
        }

        public void StartEveManager()
        {
            if (eveManagerThread == null || !eveManagerThread.IsAlive)
            {
                Cache.Instance.Log("Starting EveManager: Scheduler Initializing");
                //nextEveStart = DateTime.MinValue;
                eveManagerThread = new Thread(EveManagerThread);
                isEveManagerThreadAborting = false;
                eveManagerThread.Start();
                if (eveManagerThread.IsAlive)
                    Cache.Instance.Log("Starting EveManager: Scheduler On.");

                return;
            }

            if (eveManagerThread != null && eveManagerThread.IsAlive)
            {
                Cache.Instance.Log("EveManager: Scheduler On");
                isEveManagerThreadAborting = false;
            }
        }

        public void StartSettingsManager()
        {
            foreach (EveAccount thisEveAccount in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
            {
                ClearSlaveCharacters(thisEveAccount);
            }

            if (eveSettingsManagerThread == null || !eveSettingsManagerThread.IsAlive)
            {
                Cache.Instance.Log("Starting EveSettingsIPCForHydra");
                eveSettingsManagerThread = new Thread(EveSettingsManagerThread);
                isEveSettingsManagerThreadAborting = false;
                eveSettingsManagerThread.Start();
                return;
            }

            if (eveSettingsManagerThread != null && eveSettingsManagerThread.IsAlive)
            {
                Cache.Instance.Log("EveSettingsIPCForHydra: Running");
                isEveSettingsManagerThreadAborting = false;
            }
        }

        private void AddNewSlaveCharacterToList(EveAccount thisEveAccount, string slaveNameToAdd, string slaveIdToAdd)
        {
            try
            {
                //Cache.Instance.Log("AddNewSlaveCharacterToList [" + thisEveAccount.CharacterName + "] slaveNameToAdd [" + slaveNameToAdd + "] slaveIdAtoAdd [" + slaveIdToAdd + "]");
                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName1))
                {
                    //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName1))");
                    thisEveAccount.SlaveCharacterName1 = slaveNameToAdd;
                    thisEveAccount.SlaveCharacter1RepairGroup = slaveIdToAdd;
                    return;
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))
                {
                    if (thisEveAccount.SlaveCharacterName1 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName2 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter2RepairGroup = slaveIdToAdd;
                    }

                    return;
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName3))
                {
                    if (thisEveAccount.SlaveCharacterName2 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName3 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter3RepairGroup = slaveIdToAdd;
                    }

                    return;
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName4))
                {
                    if (thisEveAccount.SlaveCharacterName3 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName4 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter4RepairGroup = slaveIdToAdd;
                    }

                    return;
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName5))
                {
                    if (thisEveAccount.SlaveCharacterName4 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName5 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter5RepairGroup = slaveIdToAdd;
                    }

                    return;
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName6))
                {
                    if (thisEveAccount.SlaveCharacterName5 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName6 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter6RepairGroup = slaveIdToAdd;
                    }

                    return;
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName7))
                {
                    if (thisEveAccount.SlaveCharacterName6 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName7 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter7RepairGroup = slaveIdToAdd;
                    }

                    return;
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName8))
                {
                    if (thisEveAccount.SlaveCharacterName7 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName8 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter8RepairGroup = slaveIdToAdd;
                    }
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName9))
                {
                    if (thisEveAccount.SlaveCharacterName8 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName9 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter9RepairGroup = slaveIdToAdd;
                    }
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName10))
                {
                    if (thisEveAccount.SlaveCharacterName9 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName10 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter10RepairGroup = slaveIdToAdd;
                    }
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName11))
                {
                    if (thisEveAccount.SlaveCharacterName10 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName11 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter11RepairGroup = slaveIdToAdd;
                    }
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName12))
                {
                    if (thisEveAccount.SlaveCharacterName11 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName12 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter12RepairGroup = slaveIdToAdd;
                    }
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName13))
                {
                    if (thisEveAccount.SlaveCharacterName12 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName13 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter13RepairGroup = slaveIdToAdd;
                    }
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName14))
                {
                    if (thisEveAccount.SlaveCharacterName13 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName14 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter14RepairGroup = slaveIdToAdd;
                    }
                }

                if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName15))
                {
                    if (thisEveAccount.SlaveCharacterName14 != slaveNameToAdd)
                    {
                        //Cache.Instance.Log("AddNewSlaveCharacterToList: if (string.IsNullOrEmpty(thisEveAccount.SlaveCharacterName2))");
                        thisEveAccount.SlaveCharacterName15 = slaveNameToAdd;
                        thisEveAccount.SlaveCharacter15RepairGroup = slaveIdToAdd;
                    }
                }
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception: " + ex);
            }
        }

        private void ClearSlaveCharacters(EveAccount thisEveAccount)
        {
            try
            {
                //Cache.Instance.Log("thisEveAccount [" + thisEveAccount.CharacterName + "] ClearSlaveCharacters");
                thisEveAccount.LeaderCharacterName = string.Empty;
                thisEveAccount.SlaveCharacterName1 = string.Empty;
                thisEveAccount.SlaveCharacterName2 = string.Empty;
                thisEveAccount.SlaveCharacterName3 = string.Empty;
                thisEveAccount.SlaveCharacterName4 = string.Empty;
                thisEveAccount.SlaveCharacterName5 = string.Empty;
                thisEveAccount.SlaveCharacterName6 = string.Empty;
                thisEveAccount.SlaveCharacterName7 = string.Empty;
                thisEveAccount.SlaveCharacterName8 = string.Empty;
                thisEveAccount.SlaveCharacterName9 = string.Empty;
                thisEveAccount.SlaveCharacterName10 = string.Empty;
                thisEveAccount.SlaveCharacterName11 = string.Empty;
                thisEveAccount.SlaveCharacterName12 = string.Empty;
                thisEveAccount.SlaveCharacterName13 = string.Empty;
                thisEveAccount.SlaveCharacterName14 = string.Empty;
                thisEveAccount.SlaveCharacterName15 = string.Empty;
                thisEveAccount.SlaveCharacter1RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter2RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter3RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter4RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter5RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter6RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter7RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter8RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter9RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter10RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter11RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter12RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter13RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter14RepairGroup = string.Empty;
                thisEveAccount.SlaveCharacter15RepairGroup = string.Empty;
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception: " + ex);
            }
        }

        private void CopyLeaderInfoToSlaves(EveAccount thisSlaveAccount, EveAccount thisLeaderAccount)
        {
            try
            {
                //Cache.Instance.Log("CopyLeaderInfoToSlaves: thisSlaveAccount [" + thisSlaveAccount.CharacterName + "] from thisLeaderAccount [" + thisLeaderAccount.CharacterName + "] )");
                if (DateTime.UtcNow > thisLeaderAccount.AggressingTargetDate.AddMinutes(2))
                    thisSlaveAccount.AggressingTargetId = 0;
                thisSlaveAccount.boolNewSignatureDetected = false;
                thisSlaveAccount.LeaderIsAggressingTargetId = thisLeaderAccount.AggressingTargetId;
                thisSlaveAccount.LeaderCharacterName = thisLeaderAccount.CharacterName;
                thisSlaveAccount.LeaderRepairGroup = thisLeaderAccount.RepairGroup;
                thisSlaveAccount.LeaderCharacterId = thisLeaderAccount.myCharacterId;
                thisSlaveAccount.LeaderEntityId = thisLeaderAccount.LeaderEntityId;
                thisSlaveAccount.LeaderHomeStationId = thisLeaderAccount.LeaderHomeStationId;
                thisSlaveAccount.LeaderHomeSystemId = thisLeaderAccount.LeaderHomeStationId;
                thisSlaveAccount.LeaderInSpace = thisLeaderAccount.LeaderInSpace;
                thisSlaveAccount.LeaderInStation = thisLeaderAccount.LeaderInStation;
                thisSlaveAccount.LeaderInStationId = thisLeaderAccount.LeaderInStationId;
                thisSlaveAccount.LeaderInWarp = thisLeaderAccount.LeaderInWarp;
                thisSlaveAccount.LeaderIsTargetingId1 = thisLeaderAccount.LeaderIsTargetingId1;
                thisSlaveAccount.LeaderIsTargetingId2 = thisLeaderAccount.LeaderIsTargetingId2;
                thisSlaveAccount.LeaderIsTargetingId3 = thisLeaderAccount.LeaderIsTargetingId3;
                thisSlaveAccount.LeaderIsTargetingId4 = thisLeaderAccount.LeaderIsTargetingId4;
                thisSlaveAccount.LeaderIsTargetingId5 = thisLeaderAccount.LeaderIsTargetingId5;
                thisSlaveAccount.LeaderIsTargetingId6 = thisLeaderAccount.LeaderIsTargetingId6;
                thisSlaveAccount.LeaderIsTargetingId7 = thisLeaderAccount.LeaderIsTargetingId7;
                thisSlaveAccount.LeaderIsTargetingId8 = thisLeaderAccount.LeaderIsTargetingId8;
                thisSlaveAccount.LeaderIsTargetingId9 = thisLeaderAccount.LeaderIsTargetingId9;
                thisSlaveAccount.LeaderIsTargetingId10 = thisLeaderAccount.LeaderIsTargetingId10;
                thisSlaveAccount.LeaderLastActivate = thisLeaderAccount.LeaderLastActivate;
                thisSlaveAccount.LeaderLastAlign = thisLeaderAccount.LeaderLastAlign;
                thisSlaveAccount.LeaderLastApproach = thisLeaderAccount.LeaderLastApproach;
                thisSlaveAccount.LeaderLastDock = thisLeaderAccount.LeaderLastDock;
                thisSlaveAccount.LeaderLastEntityIdActivate = thisLeaderAccount.LeaderLastEntityIdActivate;
                thisSlaveAccount.LeaderLastEntityIdAlign = thisLeaderAccount.LeaderLastEntityIdAlign;
                thisSlaveAccount.LeaderLastEntityIdApproach = thisLeaderAccount.LeaderLastEntityIdApproach;
                thisSlaveAccount.LeaderLastEntityIdDock = thisLeaderAccount.LeaderLastEntityIdDock;
                thisSlaveAccount.LeaderLastOrbit = thisLeaderAccount.LeaderLastOrbit;
                thisSlaveAccount.LeaderLastEntityIdJump = thisLeaderAccount.LeaderLastEntityIdJump;
                thisSlaveAccount.LeaderLastEntityIdOrbit = thisLeaderAccount.LeaderLastEntityIdOrbit;
                thisSlaveAccount.LeaderLastEntityIdWarp = thisLeaderAccount.LeaderLastEntityIdWarp;
                thisSlaveAccount.LeaderLastJump = thisLeaderAccount.LeaderLastJump;
                thisSlaveAccount.LeaderIsInSystemId = thisLeaderAccount.LeaderIsInSystemId;
                thisSlaveAccount.LeaderTravelerDestinationSystemId = thisLeaderAccount.LeaderTravelerDestinationSystemId;

                thisSlaveAccount.SlaveCharacter1RepairGroup = thisLeaderAccount.SlaveCharacter1RepairGroup;
                thisSlaveAccount.SlaveCharacter2RepairGroup = thisLeaderAccount.SlaveCharacter2RepairGroup;
                thisSlaveAccount.SlaveCharacter3RepairGroup = thisLeaderAccount.SlaveCharacter3RepairGroup;
                thisSlaveAccount.SlaveCharacter4RepairGroup = thisLeaderAccount.SlaveCharacter4RepairGroup;
                thisSlaveAccount.SlaveCharacter5RepairGroup = thisLeaderAccount.SlaveCharacter5RepairGroup;
                thisSlaveAccount.SlaveCharacter6RepairGroup = thisLeaderAccount.SlaveCharacter6RepairGroup;
                thisSlaveAccount.SlaveCharacter7RepairGroup = thisLeaderAccount.SlaveCharacter7RepairGroup;
                thisSlaveAccount.SlaveCharacter8RepairGroup = thisLeaderAccount.SlaveCharacter8RepairGroup;
                thisSlaveAccount.SlaveCharacter9RepairGroup = thisLeaderAccount.SlaveCharacter9RepairGroup;
                thisSlaveAccount.SlaveCharacter10RepairGroup = thisLeaderAccount.SlaveCharacter10RepairGroup;
                thisSlaveAccount.SlaveCharacter11RepairGroup = thisLeaderAccount.SlaveCharacter11RepairGroup;
                thisSlaveAccount.SlaveCharacter12RepairGroup = thisLeaderAccount.SlaveCharacter12RepairGroup;
                thisSlaveAccount.SlaveCharacter13RepairGroup = thisLeaderAccount.SlaveCharacter13RepairGroup;
                thisSlaveAccount.SlaveCharacter14RepairGroup = thisLeaderAccount.SlaveCharacter14RepairGroup;
                thisSlaveAccount.SlaveCharacter15RepairGroup = thisLeaderAccount.SlaveCharacter15RepairGroup;

                thisSlaveAccount.SlaveCharacterName1 = thisLeaderAccount.SlaveCharacterName1;
                thisSlaveAccount.SlaveCharacterName2 = thisLeaderAccount.SlaveCharacterName2;
                thisSlaveAccount.SlaveCharacterName3 = thisLeaderAccount.SlaveCharacterName3;
                thisSlaveAccount.SlaveCharacterName4 = thisLeaderAccount.SlaveCharacterName4;
                thisSlaveAccount.SlaveCharacterName5 = thisLeaderAccount.SlaveCharacterName5;
                thisSlaveAccount.SlaveCharacterName6 = thisLeaderAccount.SlaveCharacterName6;
                thisSlaveAccount.SlaveCharacterName7 = thisLeaderAccount.SlaveCharacterName7;
                thisSlaveAccount.SlaveCharacterName8 = thisLeaderAccount.SlaveCharacterName8;
                thisSlaveAccount.SlaveCharacterName9 = thisLeaderAccount.SlaveCharacterName9;
                thisSlaveAccount.SlaveCharacterName10 = thisLeaderAccount.SlaveCharacterName10;
                thisSlaveAccount.SlaveCharacterName11 = thisLeaderAccount.SlaveCharacterName11;
                thisSlaveAccount.SlaveCharacterName12 = thisLeaderAccount.SlaveCharacterName12;
                thisSlaveAccount.SlaveCharacterName13 = thisLeaderAccount.SlaveCharacterName13;
                thisSlaveAccount.SlaveCharacterName14 = thisLeaderAccount.SlaveCharacterName14;
                thisSlaveAccount.SlaveCharacterName15 = thisLeaderAccount.SlaveCharacterName15;
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception: " + ex);
            }
        }

        private bool WeHaveToonsCurrentlyDisconnected
        {
            get
            {
                if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.Any(a => !a.Running && (a.InAbyssalDeadspace || a.InMission || a.RestartOfEveClientNeeded || a.TestingEmergencyReLogin)))
                    return true;

                return false;
            }
        }

        private DateTime LogToonsLeftToLoginLogging = DateTime.UtcNow;

        private void LogToonsLeftToLogin()
        {
            if (DateTime.UtcNow > LogToonsLeftToLoginLogging)
            {
                int intNum = 0;
                foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(a => !a.Running && a.ShouldBeRunning && a.ShouldBeStarted))
                {
                    intNum++;
                    Cache.Instance.Log("[" + intNum + "] Account [" + eA.AccountName + "] Character [" + eA.MaskedCharacterName + "] still waiting to be logged in: InAbyssalDeadspace [" + eA.InAbyssalDeadspace + "] InMission [" + eA.InMission + "] isActive [" + eA.UseScheduler + "]");
                }

                LogToonsLeftToLoginLogging = DateTime.UtcNow.AddSeconds(15);
            }

            return;
        }

        private void EveManagerThread()
        {
            while (true && !isEveManagerThreadAborting)
                try
                {
                    //Cache.Instance.Log("EVEManagerThread: Iteration");
                    if (EveManagerStart.AddSeconds(3) > DateTime.UtcNow) // && !WeHaveToonsCurrentlyDisconnected)
                    {
                        Cache.Instance.Log("EVEManagerThread: waiting a few seconds before processing the schedule");
                        continue;
                    }

                    if (DateTime.UtcNow < NextEveManagerThreadTimeStamp)
                        continue;

                    #region after downtime - before we start any characters

                    if (DateTime.UtcNow.Hour == 11 && DateTime.UtcNow.Minute <= 5)
                    {
                        Cache.Instance.Log("EVEManagerThread: if (DateTime.UtcNow.Hour == 11 && DateTime.UtcNow.Minute < 10)");
                        KillEveInstances();
                        continue;
                    }

                    #endregion after downtime - before we start any characters

                    #region 24hrs

                    if (Cache.Instance.EveSettings.Last24HourTS.AddHours(24) < DateTime.UtcNow)
                    {
                        Cache.Instance.Log(string.Format("EVEManagerThread: Once Per Day: LastHourTS was: [" + Cache.Instance.EveSettings.LastHourTS.ToShortTimeString() + "] now: [" + DateTime.UtcNow.ToShortTimeString() + "]"));
                        Cache.Instance.EveSettings.Last24HourTS = DateTime.UtcNow;
                    }

                    #endregion 24hrs

                    if (Cache.Instance.EveSettings.LastEmptyStandbyList.AddMinutes(30) < DateTime.UtcNow)
                    {
                        Cache.Instance.Log(string.Format("EVEManagerThread: Once every 30 min: LastEmptyStandbyList was: [" + Cache.Instance.EveSettings.LastEmptyStandbyList.ToShortTimeString() + "] now: [" + DateTime.UtcNow.ToShortTimeString() + "]"));
                        Cache.Instance.EveSettings.LastEmptyStandbyList = DateTime.UtcNow;
                        try
                        {
                            string ExeFileToLaunch = "c:\\eveoffline\\questorlauncher\\EmptyStandbyList.exe";
                            if (File.Exists(ExeFileToLaunch))
                            {
                                ProcessStartInfo processStartInfo = new ProcessStartInfo(ExeFileToLaunch, "standbylist")
                                {
                                    WindowStyle = ProcessWindowStyle.Hidden,
                                    CreateNoWindow = true,
                                    UseShellExecute = false,
                                    WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory,
                                    RedirectStandardOutput = true,
                                    RedirectStandardError = true
                                };
                                Process.Start(processStartInfo);
                                Cache.Instance.Log("Clearing Memory Standby List so we have more memory to use...");
                            }
                            else Cache.Instance.Log("Clearing Memory Standby List: Failed: Missing [" + ExeFileToLaunch + "]");
                        }
                        catch(Exception ex)
                        {
                            Cache.Instance.Log("Exception: [" + ex + "]");
                        }
                    }

                    #region 1hrs

                    int accountNum = 0;

                    if (Cache.Instance.EveSettings.LastHourTS.AddHours(1) < DateTime.UtcNow)
                    {
                        //Cache.Instance.Log(string.Format("EVEManagerThread: Once Per Hour: LastHourTS was: [" + Cache.Instance.EveSettings.LastHourTS.ToShortTimeString() + "] now: [" + DateTime.UtcNow.ToShortTimeString() + "]"));
                        Cache.Instance.EveSettings.LastHourTS = DateTime.UtcNow;
                        //Cache.Instance.XMLBackupRotate();

                        accountNum = 0;
                        foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(eA => eA != null && !eA.SelectedController.Equals("None")).ToList())
                        {
                            accountNum++;
                            eA.OtherToonsAreStillLoggingIn = Cache.Instance.EveAccountSerializeableSortableBindingList.List.Any(a => a.Running && !a.DoneLaunchingEveInstance);
                            //Cache.Instance.Log(string.Format("EVEManagerThread: Once Per Hour: Account [" + accountNum + "][" + eA.AccountName + "] Character [" + eA.CharacterName + "]"));
                            if (eA.EndTime < DateTime.UtcNow && eA.StartTime.AddHours(10) < DateTime.UtcNow)
                            {
                                Cache.Instance.Log(string.Format("Generating new timespan for Account [" + accountNum + "][" + eA.AccountName + "] Character [" + eA.CharacterName + "]"));
                                eA.StartsPast24H = 0;
                                eA.GenerateNewTimeSpans();
                            }

                            if (eA.ManuallyStarted && DateTime.UtcNow > eA.LastStartTime.AddHours(4))
                            {
                                Cache.Instance.Log(string.Format("Account [" + accountNum + "][" + eA.AccountName + "] Character [" + eA.CharacterName + "] was manually logged in more than 6 hours ago. Resetting manual flags to false."));
                                eA.ManuallyStarted = false;
                                eA.ManuallyPausedViaUI = false;
                            }
                        }
                    }

                    #endregion 1hrs

                    accountNum = 0;
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.OrderByDescending(i => i.InAbyssalDeadspace).ThenByDescending(i => i.InMission))
                    {
                        if (eA.Running)
                        {
                            try
                            {
                                Process p = Process.GetProcessById(eA.Pid);
                            }
                            catch (ArgumentException)
                            {
                                //This can happen if eve is closed during this portion of thread execution and is unavoidable: ignore this exception and continue
                                continue;
                            }
                            catch(Exception ex)
                            {
                                Cache.Instance.Log("Exception [" + ex + "]");
                                continue;
                            }

                            /**
                            if (p.WorkingSet64 / (1024 * 1024) > eA.MAX_MEMORY && (Cache.Instance.EveSettings.KillUnresponsiveEvEs ?? true && !eA.ManuallyPausedViaUI && !eA.InAbyssalDeadspace && eA.IsDocked))
                            {
                                //
                                // When docked: check for memory usage and close eve if we get above the memory usage threshold
                                //
                                eA.RestartOfEveClientNeeded = true;
                                string msg = "Stopping Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "] memory working set reached the defined limit of [" + eA.MAX_MEMORY + "]. Current working set size [" + p.WorkingSet64 / 1024 / 1024 + "]";
                                Cache.Instance.Log(msg);
                                eA.KillEveProcess();
                            }
                            **/

                            if (eA.ClientSettingsSerializationErrors > eA.MAX_SERIALIZATION_ERRORS && !eA.IgnoreSeralizationErrors && eA.IsDocked)
                            {
                                Cache.Instance.Log("Client settings serialization error! Disabling this instance.");
                                eA.UseScheduler = false;
                                eA.KillEveProcess();
                                break;
                            }

                            if (!eA.IsProcessAlive() && eA.ShouldWeKillEveIfProcessNotAlive)
                            {
                                //
                                // check for eve client responsiveness and if we think the client is unresponsive, close eve.
                                //
                                eA.RestartOfEveClientNeeded = true;
                                Cache.Instance.Log("Stopping Eve: Account [" + eA.AccountName + "] Character[" + eA.CharacterName + "] as it was not responding");
                                eA.KillEveProcess();
                                break;
                            }

                            if (!eA.ShouldBeRunning && !string.IsNullOrEmpty(eA.CharacterName) && (Cache.Instance.EveSettings.KillUnresponsiveEvEs ?? true) && !eA.ManuallyPausedViaUI && !eA.ManuallyStarted && !eA.InAbyssalDeadspace && eA.IsDocked)
                            {
                                //
                                // When docked: check the schedule and close eve if we are done running for the day.
                                //
                                Cache.Instance.Log("Stopping Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "] to comply with the schedule");
                                eA.KillEveProcess();
                                break;
                            }
                        }

                        if (!eA.InAbyssalDeadspace)
                        {
                            if (DateTime.UtcNow.Hour == 10 && DateTime.UtcNow.Minute > 40)
                            {
                                Cache.Instance.Log("EVEManagerThread: if (DateTime.UtcNow.Hour == 10 && DateTime.UtcNow.Minute > 40)");
                                NextEveManagerThreadTimeStamp = DateTime.UtcNow.AddMinutes(5);
                                continue;
                            }
                        }

                        if (DateTime.UtcNow.Hour == 11 && DateTime.UtcNow.Minute <= 15)
                        {
                            Cache.Instance.Log("EVEManagerThread: if (DateTime.UtcNow.Hour == 11 && DateTime.UtcNow.Minute < 10)");
                            NextEveManagerThreadTimeStamp = DateTime.UtcNow.AddMinutes(5);
                            continue;
                        }

                        if (!eA.Running && eA.ShouldBeRunning && eA.ShouldBeStarted)
                        {
                            //
                            // If we recently started an eve wait until that is done launching before launching the next
                            //

                            if (!WeHaveToonsCurrentlyDisconnected && Cache.Instance.EveAccountSerializeableSortableBindingList.List.Any(a => a.Running && !a.DoneLaunchingEveInstance) && !eA.AllowSimultaneousLogins)
                            {
                                EveAccount ToonStillLoggingIn = Cache.Instance.EveAccountSerializeableSortableBindingList.List.FirstOrDefault(a => a.Running && !a.DoneLaunchingEveInstance);
                                Cache.Instance.Log("Waiting for [" + ToonStillLoggingIn.CharacterName + "] to finish launching before attemping to login [" + eA.CharacterName + "]");
                                NextEveManagerThreadTimeStamp = DateTime.UtcNow.AddSeconds(20);
                                break;
                            }

                            //if (eA.IsDocked && eA.ShipType != "Capsule" && eA.AllLoggedInAccountsAreNotInLocalWhereIWillLogin)
                            //{
                            //    ...
                            //}

                            //
                            // Start any account that is InMission (disconnected?) or InAbyssalDeadspace (disconnected?) or Should be running according to the schedule but isnt yet
                            //
                            Cache.Instance.Log("Starting Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "] Reason: " + eA.ReasonThisEveAccountShouldBeRunning);

                            if (eA.HWSettings.Proxy.IsValid)
                            {
                                bool checkSocks5Proxy = eA.HWSettings.Proxy.CheckSocks5InternetConnectivity();
                                if (checkSocks5Proxy)
                                {
                                    Cache.Instance.Log("Starting Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckSocks5ProxyInternetConnectivity [ true ]");
                                    bool checkHttpProxy = eA.HWSettings.Proxy.CheckHttpProxyInternetConnectivity();
                                    if (checkHttpProxy)
                                    {
                                        Cache.Instance.Log("Starting Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckHttpProxyInternetConnectivity [ true ]");
                                        eA.ManuallyStarted = false;
                                        eA.StartEveInject();
                                    }
                                    else Cache.Instance.Log("Starting Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckHttpProxyInternetConnectivity [ false ]");
                                }
                                else Cache.Instance.Log("Starting Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckHttpProxyInternetConnectivity [ false ]");
                            }
                            else Cache.Instance.Log("Starting Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "] Failed: Proxy is not Valid!");

                            //if (WeHaveToonsCurrentlyDisconnected)
                            //{
                            //    LogToonsLeftToLogin();
                            //    Cache.Instance.Log("if (WeHaveToonsCurrentlyDisconnected) continue;");
                            //    continue;
                            //}

                            LogToonsLeftToLogin();
                            NextEveManagerThreadTimeStamp = DateTime.UtcNow.AddMilliseconds(Util.GetRandom(800, 1700));
                            break;
                        }

                        //Cache.Instance.Log("Not Starting Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "] Running [" + eA.Running + "] ShouldBeRunning [" + eA.ShouldBeRunning + "] ShouldBeStarted [" + eA.ShouldBeStarted + "]");
                    }
                }
                catch (ThreadAbortException)
                {
                    isEveManagerThreadAborting = true;
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception [" + ex + "]");
                }
                finally
                {
                    for (int i = 0; i < 50; i++)
                    {
                        if (isEveManagerThreadAborting)
                            break;

                        Thread.Sleep(200);
                    }
                }

            Cache.Instance.Log("Stopped EveManager: Scheduler Off");
        }

        //public DateTime nextEveStart = DateTime.MinValue;

        private void UpdateLeaderAndSlaveCharacterNameInfo()
        {
            foreach (EveAccount thisLeaderAccount in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(i => i.IsLeader))
            {
                thisLeaderAccount.boolNewSignatureDetected = false;
                //Cache.Instance.Log("EveSettingsManagerThread: Found Leader [" + thisLeaderAccount.CharacterName + "]");
                int intSlave = 0;
                try
                {
                    //
                    // use the Leader account (if any) to copy targets from to the rest of the accounts to (potentially) use
                    //
                    intSlave = 0;
                    foreach (EveAccount thisSlaveAccount in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(e => thisLeaderAccount.FleetName == e.FleetName && !e.IsLeader).OrderBy(i => i.Num)) //&& e.DoneLaunchingEveInstance))
                    {
                        intSlave++;
                        //Cache.Instance.Log("EveSettingsManagerThread: Found Slave# [" + intSlave + "][" + thisSlaveAccount.CharacterName + "]");
                        AddNewSlaveCharacterToList(thisLeaderAccount, thisSlaveAccount.CharacterName, thisSlaveAccount.RepairGroup);
                    }
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception: " + ex);
                    return;
                }

                try
                {

                    intSlave = 0;
                    foreach (EveAccount thisSlaveAccount in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(e => thisLeaderAccount.FleetName == e.FleetName && !e.IsLeader).OrderBy(i => i.Num)) //&& e.DoneLaunchingEveInstance))
                    {
                        intSlave++;
                        //Cache.Instance.Log("EveSettingsManagerThread: Found Slave# [" + intSlave + "][" + thisSlaveAccount.CharacterName + "]");
                        CopyLeaderInfoToSlaves(thisSlaveAccount, thisLeaderAccount);
                    }
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception: " + ex);
                    return;
                }
            }

            return;
        }

        private void EveSettingsManagerThread()
        {
            while (true && !isEveSettingsManagerThreadAborting)
                try
                {
                    //Cache.Instance.Log("EVEManagerThread");
                    int accountNum = 0;
                    foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                    {
                        accountNum++;
                        //Cache.Instance.Log("EVEManagerThread EveAccount [" + accountNum + "][" + eA.AccountName + "][" + eA.CharacterName + "]");
                        if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(a => a.Running).All(b => b.DoneLaunchingEveInstance))
                        {
                            if (eA.DoNotSessionChange)
                            {
                                Cache.Instance.Log("EVEManagerThread: [" + accountNum + "][" + eA.AccountName + "] Character [" + eA.CharacterName + "] setting DoNotSessionChange = false");
                                eA.DoNotSessionChange = false;
                            }
                        }
                        else
                        {
                            if (eA.Running && !eA.DoNotSessionChange)
                                eA.DoNotSessionChange = true;
                        }

                        if (eA.EveProcessExists())
                        {
                            //Cache.Instance.Log("EVEManagerThread: [" + accountNum + "][" + eA.AccountName + "] Character [" + eA.CharacterName + "] Running");
                            //Cache.Instance.Log("EVEManagerThread: [" + accountNum + "][" + eA.AccountName + "] Character [" + eA.CharacterName + "] Running");
                            eA.Running = true;
                            eA.LastPcName = Environment.MachineName;
                            eA.LastPcNameDateTime = DateTime.UtcNow;
                        }
                        else
                        {
                            eA.Running = false;
                            eA.DoNotSessionChange = false;
                            eA.DoneLaunchingEveInstance = false;
                        }
                    }

                    if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.Any(i => i.Running && i.boolNewSignatureDetected))
                        Cache.Instance.Log("New Signature Found!");

                    //
                    // find account marked as Leader = true:
                    // you CAN have more than one set of toons (FleetName)
                    // and thus more than one valid leader
                    //
                    UpdateLeaderAndSlaveCharacterNameInfo();
                }
                catch (ThreadAbortException)
                {
                    isEveSettingsManagerThreadAborting = true;
                }
                catch (InvalidOperationException){}
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception: " + ex);
                    continue;
                }
                finally
                {
                    for (int i = 0; i < 10; i++)
                        Thread.Sleep(300);
                }

            Cache.Instance.Log("Stopped EveSettingsManager");
        }

        private void KillEveInstancesDelayedThread()
        {
            while (IsAnyEveProcessAlive && (Cache.Instance.EveSettings.KillUnresponsiveEvEs ?? true))
            {
                foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                    if (eA.Running && !eA.ManuallyPausedViaUI && !eA.ManuallyStarted)
                        eA.KillEveProcess();
                Thread.Sleep(1000);
            }
            Cache.Instance.Log("Finished stopping all eve instances.");
        }

        #endregion Methods
    }

    public class EveManager2 : IDisposable
    {
        #region Fields

        //private static XElement IndividualAccountDataIpcXml = null;
        private static DateTime _lastModifiedDateOfAccountDataIpcFile = DateTime.MinValue;

        private static XElement AccountDataIpcXml;

        #endregion Fields

        #region Properties

        public static string AccountDataIpcFileName //just the filename, no path, without file extension
        {
            get
            {
                try
                {
                    return "AccountDataIpc";
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception [" + ex + "]");
                    return "common.xml";
                }
            }
        }

        public static string AccountDataIpcFilePath
        {
            get
            {
                try
                {
                    string FullPathToEveSharpLauncherExe = Assembly.GetExecutingAssembly().Location;
                    string DirectoryWhereEveSharpLauncherWasLaunched = Path.GetDirectoryName(FullPathToEveSharpLauncherExe);
                    string _accountDataIpcFilePath = Path.Combine(DirectoryWhereEveSharpLauncherWasLaunched, "EveSharpSettings", AccountDataIpcFileName + ".xml");
                    return _accountDataIpcFilePath;
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception [" + ex + "]");
                    return string.Empty;
                }
            }
        }

        private static DateTime NextLoadSettings { get; set; } = DateTime.UtcNow;

        #endregion Properties

        #region Methods

        public void Dispose()
        {
            //DisposeEveManager();
            //DisposeEveSettingsManager();
        }

        public void LoadSettings(bool forcereload = false)
        {
            try
            {
                if (DateTime.UtcNow < NextLoadSettings)
                    return;

                NextLoadSettings = DateTime.UtcNow.AddSeconds(10);

                try
                {
                    bool reloadSettings = true;
                    if (File.Exists(AccountDataIpcFilePath))
                    {
                        reloadSettings = _lastModifiedDateOfAccountDataIpcFile != File.GetLastWriteTime(AccountDataIpcFilePath);
                        if (!reloadSettings && forcereload) reloadSettings = true;

                        if (!reloadSettings)
                            return;
                    }
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception [" + ex + "]");
                }

                if (File.Exists(AccountDataIpcFilePath))
                {
                    using (XmlTextReader reader = new XmlTextReader(AccountDataIpcFilePath))
                    {
                        reader.EntityHandling = EntityHandling.ExpandEntities;
                        AccountDataIpcXml = XDocument.Load(reader).Root;
                    }

                    if (AccountDataIpcXml == null)
                        Cache.Instance.Log("unable to find [" + AccountDataIpcFilePath + "] FATAL ERROR");
                    else
                        try
                        {
                            if (File.Exists(AccountDataIpcFilePath)) _lastModifiedDateOfAccountDataIpcFile = File.GetLastWriteTime(AccountDataIpcFilePath);
                            ReadSettingsFromXML();
                        }
                        catch (Exception ex)
                        {
                            Cache.Instance.Log("Exception [" + ex + "]");
                        }
                }
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Problem creating directories for logs [" + ex + "]");
            }
        }

        public void ReadSettingsFromXML()
        {
            try
            {
                Cache.Instance.Log("Start reading settings from xml");

                if (!string.IsNullOrEmpty(AccountDataIpcFilePath) && File.Exists(AccountDataIpcFilePath))
                {
                    Cache.Instance.Log("Loading AccountData IPC XML [" + AccountDataIpcFilePath + "]");
                    AccountDataIpcXml = XDocument.Load(AccountDataIpcFilePath).Root;
                    if (AccountDataIpcXml == null)
                        Cache.Instance.Log("found [" + AccountDataIpcXml + "] but was unable to load it: FATAL ERROR!");
                }
                else
                {
                    //
                    // if the common XML does not exist, load the characters XML into the CommonSettingsXml just so we can simplify the XML element loading stuff.
                    //
                    Cache.Instance.Log("AccountData IPC XML [" + AccountDataIpcFilePath + "] not found.");
                }

                if (AccountDataIpcXml == null)
                    return;
                // this should never happen as we load the characters xml here if the common xml is missing. adding this does quiet some warnings though

                Cache.Instance.Log("Loading Settings from [" + AccountDataIpcFilePath + "]");

                //
                // these are listed by feature and should likely be re-ordered to reflect that
                //

                //
                // Enable / Disable the different types of logging that are available
                //
                //Statistics.WreckLootStatistics = (bool?)CharacterSettingsXml.Element("WreckLootStatistics") ?? true;
                //Statistics.MissionDungeonIdLog = (bool?)CharacterSettingsXml.Element("MissionDungeonIdLog") ?? true;
                try
                {
                    foreach (EveAccount thisAccount in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(i => i.Running || !i.Running))
                        if (thisAccount.AccountName == AccountDataIpcXml.Element("AccountName").Value)
                        {
                            //IndividualAccountDataIpcXml = AccountDataIpcXml.
                            //IndividualAccountDataIpcXml = XDocument.Load(AccountDataIpcFilePath);
                        }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }
            }
            catch (Exception exception)
            {
                Cache.Instance.Log("ReadSettingsFromXML: Exception [" + exception + "]");
            }
        }

        #endregion Methods
    }
}