﻿using SharedComponents.Extensions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace SharedComponents.EVE
{
    [Serializable]
    public class GPUDetail
    {
        #region Constructors

        public GPUDetail(string cardName, string deviceId, string vendorId, string revisionId, string driverVerison,
            string directXVersion, string manufacturer, string deviceIdentifier, string driverDate)
        {
            CardName = cardName;
            DeviceId = deviceId;
            VendorId = vendorId;
            RevisionId = revisionId;
            DriverVersion = driverVerison;
            DirectXVersion = directXVersion;
            Manufacturer = manufacturer;
            DeviceIdentifier = deviceIdentifier;
            DriverDate = driverDate;
        }

        public GPUDetail()
        {
        }

        #endregion Constructors

        #region Properties

        public string CardName { get; set; }

        public string DeviceId { get; set; }

        public string DeviceIdentifier { get; set; }

        public string DirectXVersion { get; set; }

        public string DriverDate { get; set; }

        public DateTime? DriverDateTime
        {
            get
            {
                if (DriverDate.Contains("/"))
                {
                    string usCulture = "en-US";
                    if (DateTime.TryParse(DriverDate, new CultureInfo(usCulture, false), DateTimeStyles.AdjustToUniversal, out var dtx))
                        return dtx;
                    return null;
                }

                if (DateTime.TryParse(DriverDate, out var dt))
                    return dt;
                return null;
            }
        }

        public string DriverVersion { get; set; }

        public string Manufacturer { get; set; }

        public string RevisionId { get; set; }

        public string VendorId { get; set; }

        #endregion Properties

        #region Methods

        public static GPUDetail ParseDXDiagFile(string cont)
        {
            try
            {
                if (cont.Contains("Display Devices"))
                {
                    GPUDetail gpuDetail = new GPUDetail();

                    string strD = @"Display Devices
---------------";
                    string strA = "-------------";

                    string dispCont = cont.Substring(strD, strA);

                    Match match = Regex.Match(dispCont, @"(?<=Card name: ).*");
                    if (match.Success)
                        gpuDetail.CardName = match.Value.Trim();

                    match = Regex.Match(dispCont, @"(?<=Driver Version: ).*");
                    if (match.Success)
                    {
                        gpuDetail.DriverVersion = match.Value.Trim();
                        gpuDetail.DriverVersion = gpuDetail.DriverVersion.Replace(" (English)", "");
                    }

                    match = Regex.Match(dispCont, @"(?<=Vendor ID: ).*");
                    if (match.Success)
                        gpuDetail.VendorId = Convert.ToInt32(match.Value.Trim(), 16).ToString();

                    match = Regex.Match(dispCont, @"(?<=Device ID: ).*");
                    if (match.Success)
                        gpuDetail.DeviceId = Convert.ToInt32(match.Value.Trim(), 16).ToString();

                    match = Regex.Match(dispCont, @"(?<=Revision ID: ).*");
                    if (match.Success)
                        gpuDetail.RevisionId = Convert.ToInt32(match.Value.Trim(), 16).ToString();

                    match = Regex.Match(dispCont, @"(?<=Device Identifier: ).*");
                    if (match.Success)
                        gpuDetail.DeviceIdentifier = match.Value.Trim().Replace("{", string.Empty).Replace("}", string.Empty).ToLower();

                    match = Regex.Match(cont, @"(?<=DirectX Version: ).*");
                    if (match.Success)
                    {
                        gpuDetail.DirectXVersion = match.Value.Trim().Replace("{", string.Empty).Replace("}", string.Empty).ToLower();
                        if (gpuDetail.DirectXVersion.Contains("("))
                            gpuDetail.DirectXVersion = gpuDetail.DirectXVersion.Substring(0, gpuDetail.DirectXVersion.IndexOf("(")).Trim();
                        gpuDetail.DirectXVersion = gpuDetail.DirectXVersion.ToLower().Replace("directx", "").Replace(" ", "");
                    }

                    IEnumerable<Match> matches = Regex.Matches(dispCont, @"(?<=Manufacturer: ).*").Cast<Match>();
                    if (matches.Any())
                        gpuDetail.Manufacturer = matches.Last().Value.Trim();

                    match = Regex.Match(dispCont, @"(?<=Driver Date/Size: ).*");
                    if (match.Success)
                    {
                        gpuDetail.DriverDate = match.Value.Trim().Split(',')[0];
                        if (gpuDetail.DriverDateTime == null)
                            return null;
                    }

                    return gpuDetail;
                }
                return null;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ParseDXDiagFile Exception: " + ex);
                return null;
            }
        }

        public static void ReadFromDirectory(string path)
        {
            List<GPUDetail> list = new List<GPUDetail>();
            foreach (string file in Directory.EnumerateFiles(path
                , "*.*", SearchOption.AllDirectories))
            {
                GPUDetail ret = ParseDXDiagFile(File.ReadAllText(file));
                if (ret != null)
                    list.Add(ret);
            }

            list = list.Distinct().ToList();
            list.RemoveAll(k => k == null || k.CardName.Contains("?") || k.CardName.ToLower().Contains("standard")
                                || k.AnyMemberEmpty()
                                || k.DriverDateTime.Value.Year < 2017
                                || !(k.DirectXVersion.Contains("11") || k.DirectXVersion.Contains("12") || k.DirectXVersion.Contains("10")));
            list = list.OrderBy(k => k.CardName).ToList();

            foreach (GPUDetail k in list)
                k.Print();
        }

        public bool AnyMemberEmpty()
        {
            return string.IsNullOrEmpty(CardName) ||
                   string.IsNullOrEmpty(DeviceId) ||
                   string.IsNullOrEmpty(VendorId) ||
                   string.IsNullOrEmpty(RevisionId) ||
                   string.IsNullOrEmpty(DriverVersion) ||
                   string.IsNullOrEmpty(DirectXVersion) ||
                   string.IsNullOrEmpty(Manufacturer) ||
                   string.IsNullOrEmpty(DeviceIdentifier) ||
                   string.IsNullOrEmpty(DriverDate);
        }

        public void Print()
        {
            Debug.WriteLine($"new GPUDetail(\"{CardName}\", \"{DeviceId}\", \"{VendorId}\", \"{RevisionId}\", \"{DriverVersion}\", \"{DirectXVersion}\", \"{Manufacturer}\", \"{DeviceIdentifier}\", \"{DriverDate}\"),");
        }

        #endregion Methods
    }
}