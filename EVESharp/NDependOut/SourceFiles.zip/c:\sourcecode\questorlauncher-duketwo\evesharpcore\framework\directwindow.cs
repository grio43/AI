﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using EVESharpCore.Logging;
using SC::SharedComponents.Py;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectWindow : DirectObject
    {
        #region Enums

        public enum ModalResultType
        {
            NONE,
            OK,
            CANCEL,
            YES,
            NO,
            CLOSE,
            HELP
        }

        #endregion Enums

        #region Constructors

        internal DirectWindow(DirectEve directEve, PyObject pyWindow) : base(directEve)
        {
            PyWindow = pyWindow;
            Id = (int?) pyWindow.Attribute("windowID");
            Type = (string) pyWindow.Attribute("__guid__");
            Name = (string) pyWindow.Attribute("name");
            IsKillable = (bool) pyWindow.Attribute("_killable");
            IsDialog = (bool) pyWindow.Attribute("isDialog");
            IsModal = (bool) pyWindow.Attribute("isModal");
            Caption = (string) pyWindow.Call("GetCaption");
            ViewMode = (string) pyWindow.Attribute("viewMode");
        }

        #endregion Constructors

        #region Nested type: WindowType

        private class WindowType
        {
            #region Constructors

            public WindowType(string attribute, string value, Func<DirectEve, PyObject, DirectWindow> creator)
            {
                Attribute = attribute;
                Value = value;
                Creator = creator;
            }

            #endregion Constructors

            #region Properties

            public string Attribute { get; }
            public Func<DirectEve, PyObject, DirectWindow> Creator { get; }
            public string Value { get; }

            #endregion Properties
        }

        #endregion Nested type: WindowType

        // FROM CONST: probably better to read the values from the game
        //ID_NONE = 0
        //ID_OK = 1
        //ID_CANCEL = 2
        //ID_YES = 6
        //ID_NO = 7
        //ID_CLOSE = 8
        //ID_HELP = 9

        #region Fields

        internal PyObject PyWindow;

        private static readonly WindowType[] _windowTypes =
        {
            new WindowType("name", "marketsellaction", (directEve, pyWindow) => new DirectMarketActionWindow(directEve, pyWindow)),
            new WindowType("name", "marketbuyaction", (directEve, pyWindow) => new DirectMarketActionWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.AgentDialogueWindow", (directEve, pyWindow) => new DirectAgentWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.VirtualInvWindow", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.PVPOfferView", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.PVPTrade", (directEve, pyWindow) => new DirectTradeWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.SpyHangar", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCont.PlayerTrade", (directEve, pyWindow) => new DirectTradeWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCont.StationItems", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCont.StationShips", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.Inventory", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.InventoryPrimary", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.InventorySecondary", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.StationItems", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.StationShips", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.StationCorpHangars", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("Caption", "Corporation hangars", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.CorpHangarArray", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.CorpMemberHangar", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.CorpMarketHangar", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.ShipCargoView", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.ActiveShipCargo", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipCargo", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.DockedCargoView", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.InflightCargoView", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.LootCargoView", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.DroneBay", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipDroneBay", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipFuelBay", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipOreHold", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipGasHold", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipMineralHold", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipSalvageHold", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipShipHold", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipAmmoHold", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.StationCorpDeliveries", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.StationItems", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.StationShips", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.POSStrontiumBay", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.POSFuelBay", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.POSJumpBridge", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ItemFloatingCargo", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipMaintenanceBay", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ShipFleetHangar", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "invCtrl.ItemWreck", (directEve, pyWindow) => new DirectContainerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.RegionalMarket", (directEve, pyWindow) => new DirectMarketWindow(directEve, pyWindow)),
            new WindowType("__guid__", "uicontrols.Window", (directEve, pyWindow) => new DirectChatWindow(directEve, pyWindow)),
            new WindowType("name", "telecom", (directEve, pyWindow) => new DirectTelecomWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.FittingMgmt", (directEve, pyWindow) => new DirectFittingManagerWindow(directEve, pyWindow)),
            //new WindowType("__guid__", "uicontrols.Window", (directEve, pyWindow) => new DirectScannerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.ReprocessingDialog", (directEve, pyWindow) => new DirectReprocessingWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.LPStore", (directEve, pyWindow) => new DirectLoyaltyPointStoreWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.RepairShopWindow", (directEve, pyWindow) => new DirectRepairShopWindow(directEve, pyWindow)),
            //new WindowType("__guid__", "directionalScanner", (directEve, pyWindow) => new DirectDirectionalScannerWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.Journal", (directEve, pyWindow) => new DirectJournalWindow(directEve, pyWindow)),
            new WindowType("name", "LoginRewardWindow", (directEve, pyWindow) => new DirectLoginRewardWindow(directEve, pyWindow)),
            //new WindowType("__guid__", "form.RedeemWindow", (directEve, pyWindow) => new DirectRedeemWindow(directEve, pyWindow)),
            //new WindowType("__guid__", "form.CraftingWindow", (directEve, pyWindow) => new DirectCraftingWindow(directEve, pyWindow)),
            //new WindowType("windowID", "CraftingWindow", (directEve, pyWindow) => new DirectCraftingWindow(directEve, pyWindow)),
            new WindowType("windowID", "solar_system_map_panel", (directEve, pyWindow) => new DirectMapViewWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.KeyActivationWindow", (directEve, pyWindow) => new DirectKeyActivationWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.AbyssActivationWindow", (directEve, pyWindow) => new DirectFleetAbyssActivationWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.SellItems", (directEve, pyWindow) => new DirectMultiSellWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.Industry", (directEve, pyWindow) => new DirectIndustryWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.FleetWindow", (directEve, pyWindow) => new DirectFleetWindow(directEve, pyWindow)),
            new WindowType("__guid__", "form.FleetWindow", (directEve, pyWindow) => new DirectFleetWindow(directEve, pyWindow)),

            //new WindowType("__guid__", "form.CharacterSheet", (directEve, pyWindow) => new DirectCharacterSheetWindow(directEve, pyWindow)),
            //new WindowType("windowID", "industryWnd", (directEve, pyWindow) => new DirectIndustryWindow(directEve, pyWindow)),
        };

        private string html;

        #endregion Fields

        #region Properties

        public string Caption { get; internal set; }

        public string Html
        {
            get
            {
                if (!string.IsNullOrEmpty(html))
                    return html;

                List<PyObject> paragraphs = PyWindow.Attribute("edit").Attribute("sr").Attribute("paragraphs").ToList();
                html = paragraphs.Aggregate("", (current, paragraph) => current + (string) paragraph.Attribute("text"));
                if (string.IsNullOrEmpty(html))
                    html = (string) PyWindow.Attribute("edit").Attribute("sr").Attribute("currentTXT");
                if (string.IsNullOrEmpty(html))
                {
                    paragraphs = PyWindow.Attribute("sr").Attribute("messageArea").Attribute("sr").Attribute("paragraphs").ToList();
                    html = paragraphs.Aggregate("", (current, paragraph) => current + (string) paragraph.Attribute("text"));
                }

                return html;
            }
        }

        public int? Id { get; internal set; }
        public bool IsDialog { get; internal set; }
        public bool IsKillable { get; internal set; }
        public bool IsModal { get; internal set; }
        public string Name { get; internal set; }

        public bool Ready
        {
            get
            {
                PyObject edit = PyWindow.Attribute("edit");
                if (edit.IsValid && edit.Attribute("_loading").ToBool())
                    return false;

                if (PyWindow.Attribute("startingup").ToBool())
                    return false;

                return true;
            }
        }

        public string Type { get; internal set; }
        public string ViewMode { get; internal set; }

        #endregion Properties

        #region Methods

        /// <summary>
        ///     Answers a modal window
        /// </summary>
        /// <param name="button">a string indicating which button to press. Possible values are: Yes, No, Ok, Cancel, Suppress</param>
        /// <returns>true if successfull</returns>
        public bool AnswerModal(string button)
        {
            //string[] buttonPath = { "__maincontainer", "bottom", "btnsmainparent", "btns", "Yes_Btn" };

            if (!IsModal && Name != "modal")
                return false;

            ModalResultType mr = ModalResultType.YES;

            switch (button)
            {
                case "Yes":
                    break;

                case "No":
                    //buttonPath[4] = "No_Btn";
                    mr = ModalResultType.NO;
                    break;

                case "OK":
                case "Ok":
                    if (Name == "Set Quantity")
                    {
                        if (PyWindow != null)
                        {
                            PyWindow.Call("Confirm", 12345);
                            return true;
                        }
                        return false;
                    }
                    mr = ModalResultType.OK;
                    //buttonPath[4] = "OK_Btn";
                    break;

                case "Cancel":
                    mr = ModalResultType.CANCEL;
                    //buttonPath[4] = "Cancel_Btn";
                    break;
                //case "Suppress":
                //string[] suppress = { "__maincontainer", "main", "suppressContainer", "suppress" };
                //buttonPath = suppress;
                //break;
                default:
                    return false;
            }

            //var btn = FindChildWithPath(PyWindow, buttonPath);
            //if (btn != null)
            //    return DirectEve.ThreadedCall(btn.Attribute("OnClick"));
            return SetModalResult(mr);

            //return false;
        }

        public virtual bool Minimize()
        {
            return DirectEve.ThreadedCall(PyWindow.Attribute("Minimize"));
        }

        public virtual bool Maximize()
        {
            return DirectEve.ThreadedCall(PyWindow.Attribute("Maximize"));
        }

        /// <summary>
        ///     Closes the window
        ///     Container windows are a special case and can't be closed as we are opening them automatically while
        ///     retrieving the corresponding container. Use forceCloseContainerWnd with caution!
        /// </summary>
        /// <param name="forceCloseContainerWnd"></param>
        /// <returns></returns>
        public virtual bool Close(bool forceCloseContainerWnd = false)
        {
            if (!IsKillable) //&& Type != "form.Telecom")
                return false;

            if (!forceCloseContainerWnd && GetType() == typeof(DirectContainerWindow))
            {
                DirectEve.Log($"Container windows can't be closed.");
                return false;
            }
            return DirectEve.ThreadedCall(PyWindow.Attribute("CloseByUser"));
        }

        public int GetModalResult(ModalResultType mr)
        {
            int modalResult = 0;
            switch (mr)
            {
                case ModalResultType.NONE:
                    modalResult = 0;
                    break;

                case ModalResultType.OK:
                    modalResult = 1;
                    break;

                case ModalResultType.CANCEL:
                    modalResult = 2;
                    break;

                case ModalResultType.YES:
                    modalResult = 6;
                    break;

                case ModalResultType.NO:
                    modalResult = 7;
                    break;

                case ModalResultType.CLOSE:
                    modalResult = 8;
                    break;

                case ModalResultType.HELP:
                    modalResult = 9;
                    break;
            }

            return modalResult;
        }

        public bool SetModalResult(ModalResultType mr)
        {
            int modalResult = GetModalResult(mr);
            if (IsModal && Name != "modal")
                return DirectEve.ThreadedCall(PyWindow.Attribute("SetModalResult"), modalResult);
            return false;
        }

        /// <summary>
        ///     Find a child object (usually button)
        /// </summary>
        /// <param name="container"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        internal static PyObject FindChild(PyObject container, string name)
        {
            List<PyObject> childs = container.Attribute("children").Attribute("_childrenObjects").ToList();
            return childs.Find(c => string.Compare((string) c.Attribute("_name"), name) == 0) ?? PySharp.PyZero;
        }

        /// <summary>
        ///     Find a child object (using the supplied path)
        /// </summary>
        /// <param name="container"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        internal static PyObject FindChildWithPath(PyObject container, IEnumerable<string> path)
        {
            return path.Aggregate(container, FindChild);
        }

        internal static List<DirectWindow> GetModalWindows(DirectEve directEve)
        {
            List<DirectWindow> windows = new List<DirectWindow>();

            PySharp pySharp = directEve.PySharp;
            PyObject carbonui = pySharp.Import("carbonui");
            List<PyObject> pyWindows = carbonui.Attribute("uicore").Attribute("uicore").Attribute("registry").Attribute("windows").ToList();
            foreach (PyObject pyWindow in pyWindows)
            {
                if ((bool) pyWindow.Attribute("destroyed"))
                    continue;

                PyObject name = pyWindow.Attribute("name");
                string nameStr = name.IsValid ? name.ToUnicodeString() : string.Empty;

                if (nameStr.Equals("modal") || (bool) pyWindow.Attribute("isModal"))
                {
                    DirectWindow window = new DirectWindow(directEve, pyWindow);
                    windows.Add(window);
                }

                if (nameStr == "telecom")
                {
                    DirectTelecomWindow window = new DirectTelecomWindow(directEve, pyWindow);
                    windows.Add(window);
                }
            }
            return windows;
        }

        internal static List<DirectWindow> GetWindows(DirectEve directEve)
        {
            try
            {
                List<DirectWindow> windows = new List<DirectWindow>();

                PySharp pySharp = directEve.PySharp;
                PyObject carbonui = pySharp.Import("carbonui");
                List<PyObject> pyWindows = carbonui.Attribute("uicore").Attribute("uicore").Attribute("registry").Attribute("windows").ToList();
                if (pyWindows != null && pyWindows.Any())
                    foreach (PyObject pyWindow in pyWindows)
                    {
                        // Ignore destroyed windows
                        if ((bool)pyWindow.Attribute("destroyed"))
                            continue;

                        DirectWindow window = null;
                        try
                        {
                            foreach (WindowType windowType in _windowTypes) // TODO: make me faster
                                try
                                {
                                    if ((string)pyWindow.Attribute(windowType.Attribute) != windowType.Value)
                                        continue;

                                    window = windowType.Creator(directEve, pyWindow);
                                }
                                catch (Exception ex)
                                {
                                    Log.WriteLine("Exception [" + ex + "]");
                                }
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                        }

                        if (window == null)
                            window = new DirectWindow(directEve, pyWindow);

                        windows.Add(window);
                    }

                return windows ?? new List<DirectWindow>();
            }
            catch (Exception)
            {
                return new List<DirectWindow>();
            }
        }

        #endregion Methods
    }
}