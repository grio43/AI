﻿using System;

namespace SharedComponents.EVE.ClientSettings
{
    namespace SharedComponents.EVE.ClientSettings
    {
        [AttributeUsage(AttributeTargets.All)]
        public class TabRootAttribute : Attribute
        {
            #region Fields

            // Private fields.

            #endregion Fields

            #region Constructors

            public TabRootAttribute(string name)
            {
                Name = name;
            }

            #endregion Constructors

            #region Properties

            public virtual string Name { get; }

            #endregion Properties
        }
    }
}