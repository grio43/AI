﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 23.03.2014
 * Time: 14:20
 *
 * ---------------------------------------
 */

using SharedComponents.WinApiUtil;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SharedComponents.Utility
{
    /// <summary>
    ///     Description of Util.
    /// </summary>
    public class Util
    {
        #region Delegates

        public delegate bool Win32Callback(IntPtr hwnd, IntPtr lParam);

        #endregion Delegates

        #region Properties

        public static string AssemblyPath
        {
            get
            {
                if (_assemblyPath == null)
                    _assemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                return _assemblyPath;
            }
        }

        #endregion Properties

        #region Structs

        /// <summary>
        ///     A utility class to determine a process parent.
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct ParentProcessUtilities
        {
            // These members must match PROCESS_BASIC_INFORMATION
            internal IntPtr Reserved1;

            internal IntPtr PebBaseAddress;
            internal IntPtr Reserved2_0;
            internal IntPtr Reserved2_1;
            internal IntPtr UniqueProcessId;
            internal IntPtr InheritedFromUniqueProcessId;

            [DllImport("ntdll.dll")]
            private static extern int NtQueryInformationProcess(IntPtr processHandle, int processInformationClass,
                ref ParentProcessUtilities processInformation, int processInformationLength, out int returnLength);

            /// <summary>
            ///     Gets the parent process of the current process.
            /// </summary>
            /// <returns>An instance of the Process class.</returns>
            public static Process GetParentProcess()
            {
                return GetParentProcess(Process.GetCurrentProcess().Handle);
            }

            /// <summary>
            ///     Gets the parent process of specified process.
            /// </summary>
            /// <param name="id">The process id.</param>
            /// <returns>An instance of the Process class.</returns>
            public static Process GetParentProcess(int id)
            {
                Process process = Process.GetProcessById(id);
                return GetParentProcess(process.Handle);
            }

            /// <summary>
            ///     Gets the parent process of a specified process.
            /// </summary>
            /// <param name="handle">The process handle.</param>
            /// <returns>An instance of the Process class.</returns>
            public static Process GetParentProcess(IntPtr handle)
            {
                ParentProcessUtilities pbi = new ParentProcessUtilities();
                int returnLength;
                int status = NtQueryInformationProcess(handle, 0, ref pbi, Marshal.SizeOf(pbi), out returnLength);
                if (status != 0)
                    throw new Win32Exception(status);

                try
                {
                    return Process.GetProcessById(pbi.InheritedFromUniqueProcessId.ToInt32());
                }
                catch (ArgumentException)
                {
                    // not found
                    return null;
                }
            }
        }

        #endregion Structs

        #region Fields

        public const int SW_HIDE = 0;

        public const int SW_RESTORE = 9;

        public const int SW_SHOW = 1;

        public const int SW_SHOWNOACTIVATE = 4;

        public static Random _random = new Random();

        private const int
            WM_PRINT = 0x317,
            PRF_CLIENT = 4,
            PRF_CHILDREN = 0x10,
            PRF_NON_CLIENT = 2,
            COMBINED_PRINTFLAGS = PRF_CLIENT | PRF_CHILDREN | PRF_NON_CLIENT;

        private static string _assemblyPath;

        #endregion Fields

        #region Methods

        public static T ByteArrayToStructure<T>(byte[] bytes) where T : struct
        {
            GCHandle handle = GCHandle.Alloc(bytes, GCHandleType.Pinned);
            T obj = (T)Marshal.PtrToStructure(handle.AddrOfPinnedObject(), typeof(T));
            handle.Free();
            return obj;
        }

        public static string ByteToHex(byte[] bytes)
        {
            char[] c = new char[bytes.Length * 2];
            int b;
            for (int i = 0; i < bytes.Length; i++)
            {
                b = bytes[i] >> 4;
                c[i * 2] = (char)(55 + b + (((b - 10) >> 31) & -7));
                b = bytes[i] & 0xF;
                c[i * 2 + 1] = (char)(55 + b + (((b - 10) >> 31) & -7));
            }
            return new string(c);
        }

        public static Image CaptureWindow(IntPtr handle, int offsetX = 0, int offsetY = 0)
        {
            // get te hDC of the target window
            IntPtr hdcSrc = Pinvokes.GetWindowDC(handle);
            // get the size
            Pinvokes.GetWindowRect(handle, out var windowRect);
            int width = windowRect.Width + offsetY;
            int height = windowRect.Height + offsetY;
            // create a device context we can copy to
            IntPtr hdcDest = Pinvokes.CreateCompatibleDC(hdcSrc);
            // create a bitmap we can copy it to,
            // using GetDeviceCaps to get the width/height
            IntPtr hBitmap = Pinvokes.CreateCompatibleBitmap(hdcSrc, width, height);
            // select the bitmap object
            IntPtr hOld = Pinvokes.SelectObject(hdcDest, hBitmap);
            // bitblt over
            Pinvokes.BitBlt(hdcDest, 0, 0, width, height, hdcSrc, 0, 0, Pinvokes.SRCCOPY);
            // restore selection
            Pinvokes.SelectObject(hdcDest, hOld);
            // clean up
            Pinvokes.DeleteDC(hdcDest);
            Pinvokes.ReleaseDC(handle, hdcSrc);
            // get a .NET image object for it
            Image img = Image.FromHbitmap(hBitmap);
            // free up the Bitmap object
            Pinvokes.DeleteObject(hBitmap);
            return img;
        }

        public static void CheckCreateDirectorys(string windowsUserLogin)
        {
            string userDir = "C:\\Users\\" + windowsUserLogin + "\\";
            string[] path = { userDir + "Documents", userDir + "AppData\\Local\\Temp", userDir + "AppData\\Local\\Roaming", userDir + "AppData\\Local\\Temp" };

            foreach (string d in path)
                if (!Directory.Exists(d))
                    Directory.CreateDirectory(d);
        }

        public static DataTable ConvertToDataTable<T>(IList<T> data)
        {
            PropertyDescriptorCollection properties =
                TypeDescriptor.GetProperties(typeof(T));

            DataTable table = new DataTable();

            foreach (PropertyDescriptor prop in properties)
                table.Columns.Add(prop.Name, Nullable.GetUnderlyingType(prop.PropertyType) ?? prop.PropertyType);

            foreach (T item in data)
            {
                DataRow row = table.NewRow();
                foreach (PropertyDescriptor prop in properties)
                    row[prop.Name] = prop.GetValue(item) ?? DBNull.Value;
                table.Rows.Add(row);
            }
            return table;
        }

        [DllImport("kernel32.dll", EntryPoint = "RtlMoveMemory")]
        public static extern void CopyMemory(IntPtr Destination, IntPtr Source, uint Length);

        public static byte[] Decompress(byte[] input)
        {
            MemoryStream sourceStream = new MemoryStream(input, 2, input.Length - 2); // two bytes removed due zlid header
            DeflateStream stream = new DeflateStream(sourceStream, CompressionMode.Decompress);
            return ReadAllBytes(stream);
        }

        public static void DirectoryCopy(string sourceDirName, string destDirName, bool copySubDirs)
        {
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);
            DirectoryInfo[] dirs = dir.GetDirectories();

            if (!dir.Exists)
                throw new DirectoryNotFoundException(
                    "Source directory does not exist or could not be found: "
                    + sourceDirName);
            if (!Directory.Exists(destDirName))
                Directory.CreateDirectory(destDirName);
            FileInfo[] files = dir.GetFiles();
            foreach (FileInfo file in files)
            {
                string temppath = Path.Combine(destDirName, file.Name);
                file.CopyTo(temppath, false);
            }

            if (copySubDirs)
                foreach (DirectoryInfo subdir in dirs)
                {
                    string temppath = Path.Combine(destDirName, subdir.Name);
                    DirectoryCopy(subdir.FullName, temppath, copySubDirs);
                }
        }

        public static void DirectoryDelete(string path, bool recursive = false)
        {
            if (!Directory.Exists(path))
                return;

            if (!recursive)
                Array.ForEach(Directory.GetFiles(path), File.Delete);
            else
                Directory.Delete(path, true);
        }

        public static void Dump(object myObj)
        {
            foreach (PropertyInfo prop in myObj.GetType().GetProperties())
                Console.WriteLine(prop.Name + ": " + prop.GetValue(myObj, null));

            foreach (FieldInfo field in myObj.GetType().GetFields())
                Console.WriteLine(field.Name + ": " + field.GetValue(myObj));
        }

        [DllImport("user32.Dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool EnumChildWindows(IntPtr parentHandle, Win32Callback callback, IntPtr lParam);

        [DllImport("User32.dll")]
        public static extern IntPtr
            FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string strClassName, string strWindowName);

        public static List<IntPtr> GetChildWindows(IntPtr parent)
        {
            List<IntPtr> result = new List<IntPtr>();
            GCHandle listHandle = GCHandle.Alloc(result);
            try
            {
                Win32Callback childProc = EnumWindow;
                EnumChildWindows(parent, childProc, GCHandle.ToIntPtr(listHandle));
            }
            finally
            {
                if (listHandle.IsAllocated)
                    listHandle.Free();
            }
            return result;
        }

        public static IntPtr GetImportAddress(string module, string importedModule, string function)
        {
            IntPtr handle = GetModuleHandle(module);
            if (handle == IntPtr.Zero)
                return IntPtr.Zero;

            IntPtr address = GetThunk(handle, importedModule, function);
            if (address == IntPtr.Zero)
                return IntPtr.Zero;

            if (address == GetProcAddresFunc(importedModule, function))
                return IntPtr.Zero;

            return address;
        }

        public static Dictionary<IntPtr, string> GetInvisibleWindows(int pid)
        {
            Dictionary<IntPtr, string> dic = new Dictionary<IntPtr, string>();
            IntPtr hWnd = IntPtr.Zero;
            uint threadID;
            uint currentProcId;
            do
            {
                currentProcId = 0;
                hWnd = FindWindowEx(IntPtr.Zero, hWnd, null, null);
                threadID = GetWindowThreadProcessId(hWnd, out currentProcId);
                if (pid == currentProcId)
                    if (!IsWindowVisible(hWnd))
                    {
                        StringBuilder title = new StringBuilder(512);
                        GetWindowText(hWnd, title, 512);
                        if (title.ToString().Contains("GDI+ Window"))
                            continue;
                        if (title.ToString().Contains("NET-BroadcastEventWindow"))
                            continue;
                        if (dic.ContainsKey(hWnd))
                            continue;
                        dic.Add(hWnd, title.ToString().Trim());
                        //ShowWindow(hWnd, SW_RESTORE);
                    }
            } while (!hWnd.Equals(IntPtr.Zero));

            return dic;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr GetModuleHandleW(IntPtr lpModuleName);

        public static int GetRandom(int minValue, int maxValue)
        {
            return _random.Next(minValue, maxValue);
        }

        public static List<IntPtr> GetRootWindowsOfProcess(int pid)
        {
            List<IntPtr> rootWindows = GetChildWindows(IntPtr.Zero);
            List<IntPtr> dsProcRootWindows = new List<IntPtr>();
            foreach (IntPtr hWnd in rootWindows)
            {
                GetWindowThreadProcessId(hWnd, out var lpdwProcessId);
                if (lpdwProcessId == pid)
                    dsProcRootWindows.Add(hWnd);
            }
            return dsProcRootWindows;
        }

        public static IntPtr GetThunk(IntPtr moduleHandle, string intermodName, string funcName)
        {
            IMAGE_DOS_HEADER idh = (IMAGE_DOS_HEADER)Marshal.PtrToStructure(moduleHandle, typeof(IMAGE_DOS_HEADER));
            if (!idh.isValid)
                return IntPtr.Zero;

            IMAGE_NT_HEADERS32 inh32 = (IMAGE_NT_HEADERS32)Marshal.PtrToStructure(IntPtr.Add(moduleHandle, idh.e_lfanew), typeof(IMAGE_NT_HEADERS32));
            if (!inh32.isValid || inh32.OptionalHeader.ImportTable.VirtualAddress == 0)
                return IntPtr.Zero;

            IntPtr iidPtr = IntPtr.Add(moduleHandle, (int)inh32.OptionalHeader.ImportTable.VirtualAddress);
            if (iidPtr == IntPtr.Zero)
                return IntPtr.Zero;

            IMAGE_IMPORT_DESCRIPTOR iid = (IMAGE_IMPORT_DESCRIPTOR)Marshal.PtrToStructure(iidPtr, typeof(IMAGE_IMPORT_DESCRIPTOR));
            while (iid.Name != 0)
            {
                string iidName = Marshal.PtrToStringAnsi(IntPtr.Add(moduleHandle, (int)iid.Name));
                if (string.Compare(iidName, intermodName, StringComparison.OrdinalIgnoreCase) != 0)
                {
                    iidPtr = IntPtr.Add(iidPtr, Marshal.SizeOf(typeof(IMAGE_IMPORT_DESCRIPTOR)));
                    iid = (IMAGE_IMPORT_DESCRIPTOR)Marshal.PtrToStructure(iidPtr, typeof(IMAGE_IMPORT_DESCRIPTOR));

                    continue;
                }

                // this probably won't work for 64-bit processes as the thunk data structure is different
                IntPtr itdPtr = IntPtr.Add(moduleHandle, (int)iid.FirstThunk);
                IntPtr oitdPtr = IntPtr.Add(moduleHandle, (int)iid.OriginalFirstThunk);
                while (itdPtr != IntPtr.Zero && oitdPtr != IntPtr.Zero)
                {
                    IMAGE_THUNK_DATA itd = (IMAGE_THUNK_DATA)Marshal.PtrToStructure(itdPtr, typeof(IMAGE_THUNK_DATA));
                    IMAGE_THUNK_DATA oitd = (IMAGE_THUNK_DATA)Marshal.PtrToStructure(oitdPtr, typeof(IMAGE_THUNK_DATA));

                    IntPtr iibnPtr = IntPtr.Add(moduleHandle, (int)oitd.AddressOfData);
                    string iibnName = Marshal.PtrToStringAnsi(IntPtr.Add(iibnPtr, Marshal.OffsetOf(typeof(IMAGE_IMPORT_BY_NAME), "Name").ToInt32()));
                    if (itd.Function == 0)
                        return IntPtr.Zero;

                    if (string.Compare(iibnName, funcName, StringComparison.OrdinalIgnoreCase) == 0)
                        return new IntPtr(itd.Function);

                    itdPtr = IntPtr.Add(itdPtr, Marshal.SizeOf(typeof(IMAGE_THUNK_DATA)));
                    oitdPtr = IntPtr.Add(oitdPtr, Marshal.SizeOf(typeof(IMAGE_THUNK_DATA)));
                }

                return IntPtr.Zero;
            }

            return IntPtr.Zero;
        }

        public static Dictionary<IntPtr, string> GetVisibleWindows(int pid)
        {
            Dictionary<IntPtr, string> dic = new Dictionary<IntPtr, string>();
            foreach (IntPtr hWnd in GetRootWindowsOfProcess(pid))
                if (IsWindowVisible(hWnd))
                {
                    StringBuilder title = new StringBuilder(512);
                    GetWindowText(hWnd, title, 512);
                    if (dic.ContainsKey(hWnd))
                        continue;
                    dic.Add(hWnd, title.ToString().Trim());
                }
            return dic;
        }

        [DllImport("user32.dll")]
        public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        public static string HexDump(byte[] bytes)
        {
            if (bytes == null) return "<null>";
            int len = bytes.Length;
            StringBuilder result = new StringBuilder((len + 15) / 16 * 78);
            char[] chars = new char[78];
            // fill all with blanks
            for (int i = 0; i < 75; i++)
                chars[i] = ' ';
            chars[76] = '\r';
            chars[77] = '\n';

            for (int i1 = 0; i1 < len; i1 += 16)
            {
                chars[0] = HexChar(i1 >> 28);
                chars[1] = HexChar(i1 >> 24);
                chars[2] = HexChar(i1 >> 20);
                chars[3] = HexChar(i1 >> 16);
                chars[4] = HexChar(i1 >> 12);
                chars[5] = HexChar(i1 >> 8);
                chars[6] = HexChar(i1 >> 4);
                chars[7] = HexChar(i1 >> 0);

                int offset1 = 11;
                int offset2 = 60;

                for (int i2 = 0; i2 < 16; i2++)
                {
                    if (i1 + i2 >= len)
                    {
                        chars[offset1] = ' ';
                        chars[offset1 + 1] = ' ';
                        chars[offset2] = ' ';
                    }
                    else
                    {
                        byte b = bytes[i1 + i2];
                        chars[offset1] = HexChar(b >> 4);
                        chars[offset1 + 1] = HexChar(b);
                        chars[offset2] = b < 32 ? '·' : (char)b;
                    }
                    offset1 += i2 == 7 ? 4 : 3;
                    offset2++;
                }
                result.Append(chars);
            }
            return result.ToString();
        }

        public static void LoadLibrary(string libraryName)
        {
            if (GetModuleHandle(libraryName) == IntPtr.Zero)
            {
                IntPtr lib = Marshal.StringToHGlobalAnsi(libraryName);
                try
                {
                    LoadLibraryA(lib);
                }
                finally
                {
                    Marshal.FreeHGlobal(lib);
                }
            }
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi)]
        public static extern IntPtr LoadLibraryA(IntPtr lpModuleName);

        public static void MeasureTime(Action a, bool disableLog = false)
        {
            using (new DisposableStopwatch(t =>
            {
                if (!disableLog)
                {
                    Console.WriteLine($"{1000000 * t.Ticks / Stopwatch.Frequency}  µs elapsed.");
                    Console.WriteLine($"{1000000 * t.Ticks / Stopwatch.Frequency / 1000} ms elapsed.");
                }
            }))
            {
                a.Invoke();
            }
        }

        public static int NthIndexOf(string target, string value, int n)
        {
            Match m = Regex.Match(target, "((" + Regex.Escape(value) + ").*?){" + n + "}");

            if (m.Success)
                return m.Groups[2].Captures[n - 1].Index;
            return -1;
        }

        public static DateTime? ParseDateTime(string s)
        {
            if (s.Contains("/"))
            {
                string usCulture = "en-US";
                if (DateTime.TryParse(s, new CultureInfo(usCulture, false), DateTimeStyles.AdjustToUniversal, out var dtx))
                    return dtx;
                return null;
            }

            if (DateTime.TryParse(s, out var dt))
                return dt;
            return null;
        }

        [DllImport("user32.dll")]
        public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, int nFlags);

        public static Bitmap PrintWindow(IntPtr hwnd)
        {
            GetWindowRect(hwnd, out var rc);
            Bitmap bmp = new Bitmap(rc.Width, rc.Height, PixelFormat.Format32bppArgb);
            Graphics gfxBmp = Graphics.FromImage(bmp);
            IntPtr hdcBitmap = gfxBmp.GetHdc();

            //SendMessage(hwnd, WM_PRINT, hdcBitmap, COMBINED_PRINTFLAGS);
            //const int flags = (0x10 | 0x4 | 0x20 | 0x2 | 0x8); // CHILDREN, CLIENT, OWNED, NONCLIENT, ERASEBKGND
            //Pinvokes.SendMessage(hwnd, 0x317, hdcBitmap, (IntPtr)flags);

            PrintWindow(hwnd, hdcBitmap, 0);
            //Pinvokes.SendMessage(hwnd, 0x000F, hdcBitmap, (IntPtr)0);

            gfxBmp.ReleaseHdc(hdcBitmap);
            gfxBmp.Dispose();

            return bmp;
        }

        public static byte[] ReadAllBytes(Stream source)
        {
            byte[] readBuffer = new byte[4096];

            int totalBytesRead = 0;
            int bytesRead;

            while ((bytesRead = source.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
            {
                totalBytesRead += bytesRead;

                if (totalBytesRead == readBuffer.Length)
                {
                    int nextByte = source.ReadByte();
                    if (nextByte != -1)
                    {
                        byte[] temp = new byte[readBuffer.Length * 2];
                        Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                        Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                        readBuffer = temp;
                        totalBytesRead++;
                    }
                }
            }

            byte[] buffer = readBuffer;
            if (readBuffer.Length != totalBytesRead)
            {
                buffer = new byte[totalBytesRead];
                Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
            }
            return buffer;
        }

        public static string RemoveFirstLines(string text, int linesCount)
        {
            IEnumerable<string> lines = Regex.Split(text, "\r\n|\r|\n").Skip(linesCount);
            return string.Join(Environment.NewLine, lines.ToArray());
        }

        public static Image ResizeImage(Image originalImage, int width, int height, ImageFormat format)
        {
            Image finalImage = new Bitmap(width, height);
            Graphics graphic = Graphics.FromImage(finalImage);
            graphic.CompositingQuality = CompositingQuality.HighSpeed;
            graphic.SmoothingMode = SmoothingMode.HighSpeed;
            graphic.InterpolationMode = InterpolationMode.Bilinear;
            Rectangle rectangle = new Rectangle(0, 0, width, height);
            graphic.DrawImage(originalImage, rectangle);
            return finalImage;
        }

        public static void RunInDirectory(string filename, bool waitforExit = true, string workingDirectory = null)
        {
            RunInDirectory(filename, string.Empty, waitforExit, workingDirectory);
        }

        public static void RunInDirectory(string filename, string parameters = "", bool waitforExit = true, string workingDirectory = null)
        {
            Process process = new Process();
            process.StartInfo.UseShellExecute = !waitforExit;
            process.StartInfo.FileName = AssemblyPath + Path.DirectorySeparatorChar + filename;
            process.StartInfo.Arguments = parameters;
            process.StartInfo.WorkingDirectory = workingDirectory != null ? workingDirectory : AssemblyPath;
            process.StartInfo.CreateNoWindow = false;
            process.Start();

            if (waitforExit)
                process.WaitForExit();
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern void SetLastError(int errorCode);

        public static string Sha256(string s)
        {
            SHA256Managed crypt = new SHA256Managed();
            StringBuilder hash = new StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(s), 0, Encoding.UTF8.GetByteCount(s));
            foreach (byte theByte in crypto)
                hash.Append(theByte.ToString("x2"));
            return hash.ToString();
        }

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        public static void TaskKill(int pid, bool createNoWindow = true)
        {
            try
            {
                ProcessStartInfo processStartInfo = new ProcessStartInfo("taskkill", "/f /t /pid " + pid)
                {
                    WindowStyle = ProcessWindowStyle.Hidden,
                    CreateNoWindow = createNoWindow,
                    UseShellExecute = false,
                    WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                Process.Start(processStartInfo);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
        }

        public static void ClearStandbyList(int pid, bool createNoWindow = true)
        {
            try
            {
                string ExeFileToLaunch = "c:\\eveoffline\\questorlauncher\\EmptyStandbyList.exe";
                ProcessStartInfo processStartInfo = new ProcessStartInfo(ExeFileToLaunch, "standbylist")
                {
                    WindowStyle = ProcessWindowStyle.Hidden,
                    CreateNoWindow = createNoWindow,
                    UseShellExecute = false,
                    WorkingDirectory = AppDomain.CurrentDomain.BaseDirectory,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                };
                Process.Start(processStartInfo);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }
        }

        public static void Touch(string fileName)
        {
            FileStream myFileStream = File.Open(fileName, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
            myFileStream.Close();
            myFileStream.Dispose();
            File.SetLastWriteTimeUtc(fileName, DateTime.UtcNow);
        }

        public static DateTime Unix2DateTime(ulong unix)
        {
            DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddMilliseconds(unix).ToUniversalTime();
            return dtDateTime;
        }

        public static async Task WriteTextAsync(string filePath, string text, SemaphoreSlim sema)
        {
            byte[] encodedText = Encoding.UTF8.GetBytes(text);
            await sema.WaitAsync();
            try
            {
                using (FileStream sourceStream = new FileStream(filePath,
                    FileMode.Append, FileAccess.Write, FileShare.None,
                    4096, true))
                {
                    await sourceStream.WriteAsync(encodedText, 0, encodedText.Length);
                }
                ;
            }
            finally
            {
                sema.Release();
            }
        }

        public static object XmlDeserialize(string s, Type t)
        {
            XmlSerializer xmlSer = new XmlSerializer(t);
            TextReader reader = new StringReader(s);
            object obj = xmlSer.Deserialize(reader);
            return obj;
        }

        public static string XmlSerialize(object o)
        {
            XmlSerializer xmlSer = new XmlSerializer(o.GetType());
            StringWriter textWriter = new StringWriter();
            xmlSer.Serialize(textWriter, o);
            return textWriter.ToString();
        }

        private static bool EnumWindow(IntPtr handle, IntPtr pointer)
        {
            GCHandle gch = GCHandle.FromIntPtr(pointer);
            List<IntPtr> list = gch.Target as List<IntPtr>;
            if (list == null)
                throw new InvalidCastException("GCHandle Target could not be cast as List<IntPtr>");
            list.Add(handle);
            //  You can modify this to check to see if you want to cancel the operation, then return a null here
            return true;
        }

        private static IntPtr GetProcAddresFunc(string module, string function)
        {
            return GetProcAddress(GetModuleHandle(module), function);
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int GetWindowText(IntPtr hWnd, StringBuilder title, int size);

        private static char HexChar(int value)
        {
            value &= 0xF;
            if (value >= 0 && value <= 9)
                return (char)('0' + value);
            return (char)('A' + (value - 10));
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool IsWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("USER32.DLL")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, int lParam);

        #endregion Methods

        #region Native structures

        public enum DllCharacteristicsType : ushort
        {
            RES_0 = 0x0001,
            RES_1 = 0x0002,
            RES_2 = 0x0004,
            RES_3 = 0x0008,
            IMAGE_DLL_CHARACTERISTICS_DYNAMIC_BASE = 0x0040,
            IMAGE_DLL_CHARACTERISTICS_FORCE_INTEGRITY = 0x0080,
            IMAGE_DLL_CHARACTERISTICS_NX_COMPAT = 0x0100,
            IMAGE_DLLCHARACTERISTICS_NO_ISOLATION = 0x0200,
            IMAGE_DLLCHARACTERISTICS_NO_SEH = 0x0400,
            IMAGE_DLLCHARACTERISTICS_NO_BIND = 0x0800,
            RES_4 = 0x1000,
            IMAGE_DLLCHARACTERISTICS_WDM_DRIVER = 0x2000,
            IMAGE_DLLCHARACTERISTICS_TERMINAL_SERVER_AWARE = 0x8000
        }

        public enum MachineType : ushort
        {
            Native = 0,
            I386 = 0x014c,
            Itanium = 0x0200,
            x64 = 0x8664
        }

        public enum MagicType : ushort
        {
            IMAGE_NT_OPTIONAL_HDR32_MAGIC = 0x10b,
            IMAGE_NT_OPTIONAL_HDR64_MAGIC = 0x20b
        }

        public enum SubSystemType : ushort
        {
            IMAGE_SUBSYSTEM_UNKNOWN = 0,
            IMAGE_SUBSYSTEM_NATIVE = 1,
            IMAGE_SUBSYSTEM_WINDOWS_GUI = 2,
            IMAGE_SUBSYSTEM_WINDOWS_CUI = 3,
            IMAGE_SUBSYSTEM_POSIX_CUI = 7,
            IMAGE_SUBSYSTEM_WINDOWS_CE_GUI = 9,
            IMAGE_SUBSYSTEM_EFI_APPLICATION = 10,
            IMAGE_SUBSYSTEM_EFI_BOOT_SERVICE_DRIVER = 11,
            IMAGE_SUBSYSTEM_EFI_RUNTIME_DRIVER = 12,
            IMAGE_SUBSYSTEM_EFI_ROM = 13,
            IMAGE_SUBSYSTEM_XBOX = 14
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct IMAGE_DATA_DIRECTORY
        {
            public uint VirtualAddress;
            public uint Size;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct IMAGE_DOS_HEADER
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)] public char[] e_magic; // Magic number
            public ushort e_cblp; // Bytes on last page of file
            public ushort e_cp; // Pages in file
            public ushort e_crlc; // Relocations
            public ushort e_cparhdr; // Size of header in paragraphs
            public ushort e_minalloc; // Minimum extra paragraphs needed
            public ushort e_maxalloc; // Maximum extra paragraphs needed
            public ushort e_ss; // Initial (relative) SS value
            public ushort e_sp; // Initial SP value
            public ushort e_csum; // Checksum
            public ushort e_ip; // Initial IP value
            public ushort e_cs; // Initial (relative) CS value
            public ushort e_lfarlc; // File address of relocation table
            public ushort e_ovno; // Overlay number
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)] public ushort[] e_res1; // Reserved words
            public ushort e_oemid; // OEM identifier (for e_oeminfo)
            public ushort e_oeminfo; // OEM information; e_oemid specific
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)] public ushort[] e_res2; // Reserved words
            public int e_lfanew; // File address of new exe header

            private string _e_magic => new string(e_magic);

            public bool isValid => _e_magic == "MZ";
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct IMAGE_FILE_HEADER
        {
            public ushort Machine;
            public ushort NumberOfSections;
            public uint TimeDateStamp;
            public uint PointerToSymbolTable;
            public uint NumberOfSymbols;
            public ushort SizeOfOptionalHeader;
            public ushort Characteristics;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct IMAGE_IMPORT_BY_NAME
        {
            public short Hint;
            public byte Name;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct IMAGE_IMPORT_DESCRIPTOR
        {
            #region union

            /// <summary>
            ///     C# doesn't really support unions, but they can be emulated by a field offset 0
            /// </summary>
            [FieldOffset(0)] public uint Characteristics; // 0 for terminating null import descriptor

            [FieldOffset(0)] public uint OriginalFirstThunk; // RVA to original unbound IAT (PIMAGE_THUNK_DATA)

            #endregion union

            [FieldOffset(4)] public uint TimeDateStamp;
            [FieldOffset(8)] public uint ForwarderChain;
            [FieldOffset(12)] public uint Name;
            [FieldOffset(16)] public uint FirstThunk;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct IMAGE_NT_HEADERS32
        {
            [FieldOffset(0)] [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)] public char[] Signature;

            [FieldOffset(4)] public IMAGE_FILE_HEADER FileHeader;

            [FieldOffset(24)] public IMAGE_OPTIONAL_HEADER32 OptionalHeader;

            private string _Signature => new string(Signature);

            public bool isValid => _Signature == "PE\0\0" && OptionalHeader.Magic == MagicType.IMAGE_NT_OPTIONAL_HDR32_MAGIC;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct IMAGE_OPTIONAL_HEADER32
        {
            [FieldOffset(0)] public MagicType Magic;

            [FieldOffset(2)] public byte MajorLinkerVersion;

            [FieldOffset(3)] public byte MinorLinkerVersion;

            [FieldOffset(4)] public uint SizeOfCode;

            [FieldOffset(8)] public uint SizeOfInitializedData;

            [FieldOffset(12)] public uint SizeOfUninitializedData;

            [FieldOffset(16)] public uint AddressOfEntryPoint;

            [FieldOffset(20)] public uint BaseOfCode;

            // PE32 contains this additional field
            [FieldOffset(24)] public uint BaseOfData;

            [FieldOffset(28)] public uint ImageBase;

            [FieldOffset(32)] public uint SectionAlignment;

            [FieldOffset(36)] public uint FileAlignment;

            [FieldOffset(40)] public ushort MajorOperatingSystemVersion;

            [FieldOffset(42)] public ushort MinorOperatingSystemVersion;

            [FieldOffset(44)] public ushort MajorImageVersion;

            [FieldOffset(46)] public ushort MinorImageVersion;

            [FieldOffset(48)] public ushort MajorSubsystemVersion;

            [FieldOffset(50)] public ushort MinorSubsystemVersion;

            [FieldOffset(52)] public uint Win32VersionValue;

            [FieldOffset(56)] public uint SizeOfImage;

            [FieldOffset(60)] public uint SizeOfHeaders;

            [FieldOffset(64)] public uint CheckSum;

            [FieldOffset(68)] public SubSystemType Subsystem;

            [FieldOffset(70)] public DllCharacteristicsType DllCharacteristics;

            [FieldOffset(72)] public uint SizeOfStackReserve;

            [FieldOffset(76)] public uint SizeOfStackCommit;

            [FieldOffset(80)] public uint SizeOfHeapReserve;

            [FieldOffset(84)] public uint SizeOfHeapCommit;

            [FieldOffset(88)] public uint LoaderFlags;

            [FieldOffset(92)] public uint NumberOfRvaAndSizes;

            [FieldOffset(96)] public IMAGE_DATA_DIRECTORY ExportTable;

            [FieldOffset(104)] public IMAGE_DATA_DIRECTORY ImportTable;

            [FieldOffset(112)] public IMAGE_DATA_DIRECTORY ResourceTable;

            [FieldOffset(120)] public IMAGE_DATA_DIRECTORY ExceptionTable;

            [FieldOffset(128)] public IMAGE_DATA_DIRECTORY CertificateTable;

            [FieldOffset(136)] public IMAGE_DATA_DIRECTORY BaseRelocationTable;

            [FieldOffset(144)] public IMAGE_DATA_DIRECTORY Debug;

            [FieldOffset(152)] public IMAGE_DATA_DIRECTORY Architecture;

            [FieldOffset(160)] public IMAGE_DATA_DIRECTORY GlobalPtr;

            [FieldOffset(168)] public IMAGE_DATA_DIRECTORY TLSTable;

            [FieldOffset(176)] public IMAGE_DATA_DIRECTORY LoadConfigTable;

            [FieldOffset(184)] public IMAGE_DATA_DIRECTORY BoundImport;

            [FieldOffset(192)] public IMAGE_DATA_DIRECTORY IAT;

            [FieldOffset(200)] public IMAGE_DATA_DIRECTORY DelayImportDescriptor;

            [FieldOffset(208)] public IMAGE_DATA_DIRECTORY CLRRuntimeHeader;

            [FieldOffset(216)] public IMAGE_DATA_DIRECTORY Reserved;
        }

        [StructLayout(LayoutKind.Explicit)]
        public struct IMAGE_THUNK_DATA
        {
            [FieldOffset(0)] public uint ForwarderString; // PBYTE
            [FieldOffset(0)] public uint Function; // PDWORD
            [FieldOffset(0)] public uint Ordinal;
            [FieldOffset(0)] public uint AddressOfData; // PIMAGE_IMPORT_BY_NAME
        }

        #endregion Native structures

        public static int IdleTime() //In seconds
        {
            try
            {
                LASTINPUTINFO lastinputinfo = new LASTINPUTINFO();
                lastinputinfo.cbSize = (uint)Marshal.SizeOf(lastinputinfo);
                IdleTimeFinder.GetLastInputInfo(ref lastinputinfo);
                return (int)(((Environment.TickCount & int.MaxValue) - (lastinputinfo.dwTime & int.MaxValue)) & int.MaxValue) / 1000;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }

    public struct LASTINPUTINFO
    {
        public uint cbSize;

        public uint dwTime;
    }

    /// <summary>
    /// Helps to find the idle time, (in milliseconds) spent since the last user input
    /// </summary>
    public class IdleTimeFinder
    {
        [DllImport("User32.dll")]
        public static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

        [DllImport("Kernel32.dll")]
        public static extern uint GetLastError();

        public static uint GetIdleTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            GetLastInputInfo(ref lastInPut);

            return ((uint)Environment.TickCount - lastInPut.dwTime);
        }
        /// <summary>
        /// Get the Last input time in milliseconds
        /// </summary>
        /// <returns></returns>
        public static long GetLastInputTime()
        {
            LASTINPUTINFO lastInPut = new LASTINPUTINFO();
            lastInPut.cbSize = (uint)System.Runtime.InteropServices.Marshal.SizeOf(lastInPut);
            if (!GetLastInputInfo(ref lastInPut))
            {
                throw new Exception(GetLastError().ToString());
            }
            return lastInPut.dwTime;
        }
    }
}