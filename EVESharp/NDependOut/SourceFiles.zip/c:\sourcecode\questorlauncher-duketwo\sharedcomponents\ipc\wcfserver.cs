﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 08.04.2014
 * Time: 11:35
 *
 * ---------------------------------------
 */

using SharedComponents.EVE;
using SharedComponents.EVE.ClientSettings;
using SharedComponents.EVE.ClientSettings.Global.Main;
using SharedComponents.EVE.ClientSettings.Pinata;
using SharedComponents.EVE.ClientSettings.Pinata.Main;
using SharedComponents.Events;
using SharedComponents.SharpLogLite.Model;
using SharedComponents.Utility;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.Threading;

namespace SharedComponents.IPC
{
    public interface IDuplexServiceCallback
    {
        #region Methods

        [OperationContract(IsOneWay = true)]
        void GotoHomebaseAndIdle();

        [OperationContract(IsOneWay = true)]
        void GotoJita();

        [OperationContract(IsOneWay = true)]
        void OnCallback();

        [OperationContract(IsOneWay = true)]
        void PauseAfterNextDock();

        #endregion Methods
    }

    [ServiceKnownType(typeof(MissionType))]
    [ServiceKnownType(typeof(AmmoType))]
    [ServiceKnownType(typeof(ClientSetting))]
    [ServiceKnownType(typeof(DamageType))]
    [ServiceKnownType(typeof(QuestorDebugSetting))]
    [ServiceKnownType(typeof(ShipFitting))]
    [ServiceKnownType(typeof(FactionFitting))]
    [ServiceKnownType(typeof(MissionFitting))]
    [ServiceKnownType(typeof(QuestorSetting))]
    [ServiceKnownType(typeof(QuestorMainSetting))]
    [ServiceKnownType(typeof(QuestorFaction))]
    [ServiceKnownType(typeof(QuestorMission))]
    [ServiceKnownType(typeof(EveAccount))]
    [ServiceKnownType(typeof(HWSettings))]
    [ServiceKnownType(typeof(EveSetting))]
    [ServiceKnownType(typeof(DirectEvent))]
    [ServiceKnownType(typeof(Proxy))]
    [ServiceKnownType(typeof(ConcurrentBindingList<Proxy>))]
    [ServiceKnownType(typeof(LogSeverity))]
    [ServiceKnownType(typeof(PinataMainSetting))]
    [ServiceKnownType(typeof(Region))]
    [ServiceKnownType(typeof(List<int>))]
    [ServiceKnownType(typeof(List<string>))]
    [ServiceContract(CallbackContract = typeof(IDuplexServiceCallback))]
    [ServiceKnownType(typeof(GlobalMainSetting))]
    [ServiceKnownType(typeof(TimeSpan))]
    [ServiceKnownType(typeof(FactionType))]
    public interface IOperationContract
    {
        #region Methods

        [OperationContract(IsOneWay = true)]
        void AttachCallbackHandlerToEveAccount(string charName);

        [OperationContract]
        void CompileQuestor(string charName);

        [OperationContract]
        int GetDumpLootIterations(string charName);

        [OperationContract]
        EveAccount GetEveAccount(string charName);

        [OperationContract]
        EveSetting GetEVESettings();

        [OperationContract]
        Proxy GetProxy(int proxyId);

        [OperationContract]
        void IncreaseDumpLootIterations(string charName);

        [OperationContract]
        bool IsMainFormMinimized();

        [OperationContract]
        long MainFormHWnd();

        [OperationContract(IsOneWay = true)]
        void OnDirectEvent(string charName, DirectEvent directEvent);

        [OperationContract]
        void Ping();

        [OperationContract(IsOneWay = true)]
        void RemoteLog(string s);

        [OperationContract(IsOneWay = true)]
        void SetEveAccountAttributeValue(string charName, string attributeName, object val);

        [OperationContract]
        void SetEveAccountAttributeValueBlocking(string charName, string attributeName, object val);

        #endregion Methods
    }

    [KnownType(typeof(MissionType))]
    [KnownType(typeof(AmmoType))]
    [KnownType(typeof(ClientSetting))]
    [KnownType(typeof(DamageType))]
    [KnownType(typeof(QuestorDebugSetting))]
    [KnownType(typeof(ShipFitting))]
    [KnownType(typeof(FactionFitting))]
    [KnownType(typeof(MissionFitting))]
    [KnownType(typeof(QuestorSetting))]
    [KnownType(typeof(QuestorMainSetting))]
    [KnownType(typeof(QuestorFaction))]
    [KnownType(typeof(QuestorMission))]
    [KnownType(typeof(EveAccount))]
    [KnownType(typeof(HWSettings))]
    [KnownType(typeof(EveSetting))]
    [KnownType(typeof(DirectEvent))]
    [KnownType(typeof(Proxy))]
    [KnownType(typeof(ConcurrentBindingList<Proxy>))]
    [KnownType(typeof(LogSeverity))]
    [KnownType(typeof(Region))]
    [KnownType(typeof(PinataMainSetting))]
    [KnownType(typeof(List<int>))]
    [KnownType(typeof(List<string>))]
    [KnownType(typeof(GlobalMainSetting))]
    [KnownType(typeof(FactionType))]
    [KnownType(typeof(TimeSpan))]
    public class OperationContract : IOperationContract
    {
        #region Fields

        private readonly ConcurrentDictionary<string, EveAccount> _eveAccountCache;

        #endregion Fields

        #region Constructors

        public OperationContract()
        {
            _eveAccountCache = new ConcurrentDictionary<string, EveAccount>();
            Debug.WriteLine("New InjectorWcfMethods instance.");
        }

        #endregion Constructors

        #region Properties

        private IDuplexServiceCallback Callback => OperationContext.Current.GetCallbackChannel<IDuplexServiceCallback>();

        #endregion Properties

        #region Methods

        public void AttachCallbackHandlerToEveAccount(string charName)
        {
            try
            {
                EveAccount eA = GetEveAccount(charName);
                if (eA != null)
                    eA.SetClientCallback(Callback);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void CompileQuestor(string charName)
        {
            Util.RunInDirectory("Updater.exe", "CompileEVESharpCore");
        }

        public int GetDumpLootIterations(string charName)
        {
            EveAccount eA = GetEveAccount(charName);
            if (eA.DumpLootTimestamp.AddHours(24) < DateTime.UtcNow)
            {
                eA.DumpLootTimestamp = DateTime.UtcNow;
                eA.DumpLootIterations = 0;
            }
            return eA.DumpLootIterations;
        }

        public EveAccount GetEveAccount(string charName)
        {
            try
            {
                if (string.IsNullOrEmpty(charName))
                    return new EveAccount();

                if (_eveAccountCache.TryGetValue(charName, out var eA) && eA != null)
                    return eA;
                EveAccount ret = Cache.Instance.EveAccountSerializeableSortableBindingList.List.ToList()
                    .FirstOrDefault(s => !string.IsNullOrEmpty(s.CharacterName) && s.CharacterName.Equals(charName));
                if (ret == null) //if we sisnt find a characterName that matched look for an accountname: useful when first adding a toon and the character doesnt yet exist!
                    ret = Cache.Instance.EveAccountSerializeableSortableBindingList.List.ToList()
                    .FirstOrDefault(s => !string.IsNullOrEmpty(s.AccountName) && s.AccountName.Equals(charName));
                if (ret != null)
                    _eveAccountCache[charName] = ret; // AddOrUpdate func isn't atomic!
                //Debug.WriteLine($"EVEAccount of {charName} wasn't found in the cache. Adding to the cache.");
                return ret;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                Cache.Instance.Log(e.ToString());
                return null;
            }
        }

        public EveSetting GetEVESettings()
        {
            try
            {
                return Cache.Instance.EveSettings;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public Proxy GetProxy(int proxyId)
        {
            try
            {
                return Cache.Instance.EveSettings.Proxies.FirstOrDefault(p => p.Id == proxyId);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return null;
            }
        }

        public void IncreaseDumpLootIterations(string charName)
        {
            EveAccount eA = GetEveAccount(charName);
            eA.DumpLootIterations++;
        }

        public bool IsMainFormMinimized()
        {
            try
            {
                return Cache.Instance.IsMainFormMinimized;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public long MainFormHWnd()
        {
            try
            {
                return Cache.Instance.MainFormHWnd;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return (long) IntPtr.Zero;
            }
        }

        public void OnDirectEvent(string charName, DirectEvent directEvent)
        {
            try
            {
                DirectEventHandler.OnNewDirectEvent(charName, directEvent);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void Ping()
        {
        }

        public void RemoteLog(string s)
        {
            Cache.Instance.Log(s);
        }

        public void SetEveAccountAttributeValue(string charName, string attributeName, object val)
        {
            try
            {
                if (string.IsNullOrEmpty(charName))
                    return;

                EveAccount eA = GetEveAccount(charName);
                if (eA != null)
                {
                    Type t = eA.GetType();
                    PropertyInfo info = t.GetProperty(attributeName);
                    if (info == null)
                        return;
                    if (!info.CanWrite)
                        return;
                    info.SetValue(eA, val, null);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Attrib: " + attributeName + " Value: " + val + e);
                Cache.Instance.Log("Attrib: " + attributeName + " Value: " + val + e.ToString());
            }
        }

        public void SetEveAccountAttributeValueBlocking(string charName, string attributeName, object val)
        {
            SetEveAccountAttributeValue(charName, attributeName, val);
        }

        #endregion Methods
    }

    public class WCFServer
    {
        #region Fields

        public Thread thread;
        private ServiceHost host;

        #endregion Fields

        #region Properties

        public static WCFServer Instance { get; } = new WCFServer();

        public string GetPipeName => Cache.Instance.EveSettings.WCFPipeName;

        #endregion Properties

        #region Methods

        public void StartWCFServer()
        {
            if (Cache.Instance.EveSettings.WCFPipeName == string.Empty ||
                Cache.Instance.EveSettings.WCFPipeName == null)
                Cache.Instance.EveSettings.WCFPipeName = Guid.NewGuid().ToString();

            thread = new Thread(() =>
            {
                while (true)
                {
                    try
                    {
                        host = new ServiceHost(typeof(OperationContract), new Uri("net.pipe://localhost/" + Cache.Instance.EveSettings.WCFPipeName));

                        ((ServiceBehaviorAttribute) host.Description.Behaviors[typeof(ServiceBehaviorAttribute)]).InstanceContextMode =
                            InstanceContextMode.Single;
                        ((ServiceBehaviorAttribute) host.Description.Behaviors[typeof(ServiceBehaviorAttribute)]).ConcurrencyMode = ConcurrencyMode.Multiple;
                        ((ServiceBehaviorAttribute) host.Description.Behaviors[typeof(ServiceBehaviorAttribute)]).MaxItemsInObjectGraph = int.MaxValue;
                        host.AddServiceEndpoint(typeof(IOperationContract), new NetNamedPipeBinding(), "");
                        ServiceThrottlingBehavior stb = new ServiceThrottlingBehavior
                        {
                            MaxConcurrentSessions = 10000,
                            MaxConcurrentCalls = 10000,
                            MaxConcurrentInstances = 10000
                        };
                        host.Description.Behaviors.Add(stb);

                        host.Open();
                    }
                    catch (Exception)
                    {
                        Debug.WriteLine("Generating new guid..");
                        Cache.Instance.EveSettings.WCFPipeName = Guid.NewGuid().ToString();
                        continue;
                    }

                    break;
                }
            });
            thread.Start();
        }

        public void StopWCFServer()
        {
            if (host != null)
                host.Close();
        }

        #endregion Methods
    }
}