extern alias SC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Xml.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Framework.Events;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.Events;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;
using EVESharpCore.Controllers.ActionQueue.Actions.Base;
using SC::SharedComponents.Extensions;

namespace EVESharpCore.Questor.BackgroundTasks
{
    public static class IgnoreBookmarkedSignatures
    {
        #region Constructors

        static IgnoreBookmarkedSignatures()
        {

        }

        #endregion Constructors

        #region Fields
        private static ActionQueueAction _autoProbeAction;
        //private static string _currentSig;

        #endregion Fields

        #region Properties

        #endregion Properties

        #region Methods

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            try
            {
                /**
                MinimumPropulsionModuleDistance =
                    (int?) CharacterSettingsXml.Element("minimumPropulsionModuleDistance") ??
                    (int?) CommonSettingsXml.Element("minimumPropulsionModuleDistance") ?? 5000;
                Log.WriteLine("LoadSettings: Defense: minimumPropulsionModuleDistance [" + MinimumPropulsionModuleDistance + "]");
                MinimumPropulsionModuleCapacitor =
                    (int?) CharacterSettingsXml.Element("minimumPropulsionModuleCapacitor") ??
                    (int?) CommonSettingsXml.Element("minimumPropulsionModuleCapacitor") ?? 55;
                Log.WriteLine("LoadSettings: Defense: minimumPropulsionModuleCapacitor [" + MinimumPropulsionModuleCapacitor + "]");
                ActivateRepairModulesAtThisPercGlobalSetting =
                    (int?) CharacterSettingsXml.Element("activateRepairModules") ??
                    (int?) CommonSettingsXml.Element("activateRepairModules") ?? 65;
                Log.WriteLine("LoadSettings: Defense: activateRepairModules [" + ActivateRepairModulesAtThisPercGlobalSetting + "]");
                OverloadRepairModulesAtThisPercGlobalSetting =
                    (int?) CharacterSettingsXml.Element("overloadRepairModulesAtThisPerc") ??
                    (int?) CommonSettingsXml.Element("overloadRepairModulesAtThisPerc") ?? 30;
                Log.WriteLine("LoadSettings: Defense: overloadRepairModulesAtThisPerc [" + OverloadRepairModulesAtThisPercGlobalSetting + "]");
                ActivateSecondRepairModulesAtThisPercGlobalSetting =
                    (int?) CharacterSettingsXml.Element("activateSecondRepairModules") ??
                    (int?) CommonSettingsXml.Element("activateSecondRepairModules") ?? 50;
                Log.WriteLine("LoadSettings: Defense: activateSecondRepairModules [" + ActivateSecondRepairModulesAtThisPercGlobalSetting + "]");
                DeactivateRepairModulesAtThisPercGlobalSetting =
                    (int?) CharacterSettingsXml.Element("deactivateRepairModules") ??
                    (int?) CommonSettingsXml.Element("deactivateRepairModules") ?? 95;
                Log.WriteLine("LoadSettings: Defense: deactivateRepairModules [" + DeactivateRepairModulesAtThisPercGlobalSetting + "]");
                GlobalInjectCapPerc =
                    (int?) CharacterSettingsXml.Element("injectCapPerc") ??
                    (int?) CharacterSettingsXml.Element("injectcapperc") ??
                    (int?) CommonSettingsXml.Element("injectCapPerc") ??
                    (int?) CommonSettingsXml.Element("injectcapperc") ?? 60;
                Log.WriteLine("LoadSettings: Defense: injectCapPerc [" + GlobalInjectCapPerc + "]");
                GlobalAllowOverLoadOfReps =
                    (bool?) CharacterSettingsXml.Element("allowOverLoadOfReps") ??
                    (bool?) CommonSettingsXml.Element("allowOverLoadOfReps") ?? false;
                Log.WriteLine("LoadSettings: Defense: allowOverLoadOfReps [" + GlobalAllowOverLoadOfReps + "]");
                GlobalRepsOverloadDamageAllowed =
                    (int?) CharacterSettingsXml.Element("repsOverloadDamageAllowed") ??
                    (int?) CommonSettingsXml.Element("repsOverloadDamageAllowed") ?? 50;
                Log.WriteLine("LoadSettings: Defense: repsOverloadDamageAllowed [" + GlobalRepsOverloadDamageAllowed + "]");
                GlobalAllowOverLoadOfHardeners =
                    (bool?) CharacterSettingsXml.Element("allowOverloadOfHardeners") ??
                    (bool?) CommonSettingsXml.Element("allowOverloadOfHardeners") ?? false;
                Log.WriteLine("LoadSettings: Defense: allowOverloadOfHardeners [" + GlobalAllowOverLoadOfHardeners + "]");

                BoosterTypesToLoadIntoCargo = new HashSet<long>();
                XElement boostersToLoadIntoCargoXml = CharacterSettingsXml.Element("boosterTypesToLoadIntoCargo") ?? CommonSettingsXml.Element("boosterTypesToLoadIntoCargo");

                if (boostersToLoadIntoCargoXml != null)
                    foreach (XElement boosterToLoadIntoCargo in boostersToLoadIntoCargoXml.Elements("boosterType"))
                    {
                        long booster = int.Parse(boosterToLoadIntoCargo.Value);
                        DirectInvType boosterInvType = ESCache.Instance.DirectEve.GetInvType(int.Parse(boosterToLoadIntoCargo.Value));
                        Log.WriteLine("Adding booster [" + boosterInvType.TypeName + "] to the list of boosters that will be loaded into cargo for use in space (if needed)");
                        BoosterTypesToLoadIntoCargo.Add(booster);
                    }
                **/
            }
            catch (Exception exception)
            {
                Log.WriteLine("Error Loading Defense Settings [" + exception + "]");
            }
        }

        public static void ProcessState()
        {
            if (!ESCache.Instance.DirectEve.Session.IsReady)
                return;

            if (DebugConfig.DebugIgnoreBookmarkedSignatures)
                Log.WriteLine("DebugIgnoreBookmarkedSignatures: IgnoreBookmarkedSignatures ProcessState");

            if (ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugIgnoreBookmarkedSignatures)
                    Log.WriteLine("DebugIgnoreBookmarkedSignatures: We are in a station.");

                //_nextOverloadAttempt = DateTime.UtcNow;
                return;
            }

            if (!ESCache.Instance.InSpace)
            {
                if (DebugConfig.DebugDefense) Log.WriteLine("we are not in space (yet?)");
                return;
            }

            if (ESCache.Instance.ActiveShip.GroupId == (int) Group.Capsule)
                return;

            if (ESCache.Instance.DirectEve.Bookmarks != null && !ESCache.Instance.DirectEve.Bookmarks.Any())
                return;

            IgnoreBookmarkedSignaturesState();
        }

        private static void LaunchProbesIfNeeded()
        {
            if (!Scanner.myDirectMapViewWindow.GetProbes().Any())
            {
                Log.WriteLine("No probes found in space, launching probes.");
                ModuleCache probeLauncher = ESCache.Instance.Modules.FirstOrDefault(m => m.GroupId == (int)Group.ProbeLauncher);
                if (probeLauncher == null)
                {
                    Log.WriteLine("No probe launcher found.");
                    return;
                }

                if (probeLauncher.InLimboState || probeLauncher.IsActive)
                {
                    Log.WriteLine("Probe launcher is active or reloading.");
                    _autoProbeAction.QueueAction();
                    waitUntil = DateTime.UtcNow.AddSeconds(2);
                    return;
                }

                if (ESCache.Instance.CurrentShipsCargo.Items.DistinctBy(i => i.TypeId).Any(i => !i.IsSingleton
                                                                                                && ESCache.Instance.CurrentShipsCargo.Items.Count(n => n.TypeId == i.TypeId) >= 2))
                {
                    Log.WriteLine("Stacking current ship hangar.");
                    ESCache.Instance.CurrentShipsCargo.StackAll();
                    _autoProbeAction.QueueAction();
                    waitUntil = DateTime.UtcNow.AddSeconds(2);
                    return;
                }

                if (!Defense.DeactivateCloak()) return;

                if (probeLauncher.Charge == null || probeLauncher.ChargeQty < 8)
                {
                    IOrderedEnumerable<DirectItem> probes = ESCache.Instance.CurrentShipsCargo.Items.Where(i => i.GroupId == (int)Group.Probes).OrderBy(i => i.Stacksize);
                    IOrderedEnumerable<DirectItem> coreProbes = probes.Where(i => i.TypeName.Contains("Core")).OrderBy(i => i.Stacksize);
                    IOrderedEnumerable<DirectItem> combatProbes = probes.Where(i => i.TypeName.Contains("Combat")).OrderBy(i => i.Stacksize);
                    DirectItem charge = coreProbes.FirstOrDefault();
                    if (charge == null)
                    {
                        Log.WriteLine("No core probes found in cargohold.");
                        return;
                    }

                    if (charge.Stacksize < 8)
                    {
                        Log.WriteLine("Probe stacksize was smaller than 8.");
                        return;
                    }

                    probeLauncher.ChangeAmmo(charge, 0, 0);
                    _autoProbeAction.QueueAction();
                    waitUntil = DateTime.UtcNow.AddSeconds(11);
                    return;
                }

                Log.WriteLine("Launching probes.");
                probeLauncher.Click();

                _autoProbeAction.QueueAction();
                waitUntil = DateTime.UtcNow.AddSeconds(2);
                return;
            }

            if (Scanner.myDirectMapViewWindow.GetProbes().Count != 8)
            {
                //TODO: check probe range, can't be retrieved if below CONST.MIN_PROBE_RECOVER_DISTANCE
                Log.WriteLine("Probe amount is != 8, recovering probes.");
                _autoProbeAction.QueueAction();
                bool OurProbesAreTooCloseToRecover = false;
                if (ESCache.Instance.EntitiesOnGrid.Any(i => i.GroupId == (int)Group.Probes))
                    foreach (DirectScannerProbe deployedProbe in Scanner.myDirectMapViewWindow.GetProbes())
                    {
                        if (ESCache.Instance.EntitiesOnGrid.All(i => i.Id != deployedProbe.ProbeId))
                            continue;

                        if (ESCache.Instance.EntitiesOnGrid.Any(i => i.Distance < (double)Distances.MIN_PROBE_RECOVER_DISTANCE))
                            OurProbesAreTooCloseToRecover = true;
                    }

                if (!OurProbesAreTooCloseToRecover)
                    Scanner.myDirectMapViewWindow.RecoverProbes();

                waitUntil = DateTime.UtcNow.AddSeconds(2);
                return;
            }

            return;
        }

        private static DateTime waitUntil = DateTime.MinValue;

        private static void IgnoreBookmarkedSignaturesState()
        {
            return;
            _autoProbeAction = new ActionQueueAction(() =>
            {
                try
                {
                    if (_autoProbeAction == null)
                    {
                        Log.WriteLine("AutoProbeAction finished.");
                        return;
                    }

                    if (waitUntil > DateTime.UtcNow)
                    {
                        _autoProbeAction.QueueAction();
                        return;
                    }

                    if (ESCache.Instance.DirectEve.Bookmarks != null && !ESCache.Instance.DirectEve.Bookmarks.Any())
                        return;

                    //if (!ESCache.Instance.DirectEve.Session.IsWspace)
                    //    return;


                    if (ESCache.Instance.InStation)
                    {
                        Log.WriteLine("That doesn't work in stations.");
                        return;
                    }

                    if (ESCache.Instance.InWarp || ESCache.Instance.MyShipEntity.HasInitiatedWarp)
                    {
                        Log.WriteLine("Waiting, in warp.");
                        _autoProbeAction.QueueAction();
                        return;
                    }

                    if (Scanner.myDirectMapViewWindow == null)
                    {
                        _autoProbeAction.QueueAction();
                        return;
                    }

                    //LaunchProbesIfNeeded();

                    if (Scanner.myDirectMapViewWindow.IsProbeScanning())
                    {
                        Log.WriteLine("Probe scan active, waiting.");
                        _autoProbeAction.QueueAction();
                        waitUntil = DateTime.UtcNow.AddSeconds(1);
                        return;
                    }

                    int intSignatureNumber = 0;
                    foreach (DirectSystemScanResult mySignatureOrAnom in Scanner.myDirectMapViewWindow.SystemScanResults.Where(r => r.ScanGroup == ScanGroup.Signature || r.ScanGroup == ScanGroup.Anomaly))
                    {
                        intSignatureNumber++;
                        Log.WriteLine("IgnoreBookmarkedSignatures: [" + intSignatureNumber + "][" + mySignatureOrAnom.Id + "] GroupName [" + mySignatureOrAnom.GroupName + "]");
                        DirectBookmark myMatchingBookmark = ESCache.Instance.DirectEve.Bookmarks.FirstOrDefault(i => i.Title.Length > 4 && i.Title.ToLower().Contains(mySignatureOrAnom.Id.ToLower()) && i.CreatedOn.Value.AddDays(3) > DateTime.UtcNow && i.LocationId == ESCache.Instance.DirectEve.Session.LocationId);
                        if (myMatchingBookmark != null)
                        {
                            Log.WriteLine("IgnoreBookmarkedSignatures: [" + mySignatureOrAnom.Id + "] GroupName [" + mySignatureOrAnom.GroupName + "] is bookmarked as [" + myMatchingBookmark.Title + "]: Ignoring");
                            mySignatureOrAnom.IgnoreResult();
                            waitUntil = DateTime.UtcNow.AddSeconds(10);
                            return;
                        }

                        continue;
                    }

                    waitUntil = DateTime.UtcNow.AddSeconds(10);
                }
                catch (Exception ex)
                {
                    Log.WriteLine(ex.ToString());
                }
            });

            _autoProbeAction.Initialize().QueueAction();
            //_currentSig = null;
        }



        #endregion Methods
    }
}