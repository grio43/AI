﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

extern alias SC;

using EVESharpCore.Framework.Events;
using SC::SharedComponents.Events;
using SC::SharedComponents.Py;
using SC::SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Framework
{
    public enum IncursionEffect
    {
        effectIcon_cyno,
        effectIcon_tax,
        effectIcon_tank,
        effectIcon_damage,
        effectIcon_armor,
        effectIcon_shield,
        effectIcon_velocity
    }

    public enum NegativeBoosterEffect
    {
        boosterAOEVelocityPenalty,
        boosterCapacitorCapacityPenalty,
        boosterShieldCapacityPenalty,
        boosterArmorHPPenalty,
        boosterMaxVelocityPenalty,
        boosterMissileVelocityPenalty,
        boosterShieldBoostAmountPenalty,
        boosterArmorRepairAmountPenalty,
        boosterTurretFalloffPenalty
    }

    public class DirectMe : DirectObject
    {
        #region Constructors

        internal DirectMe(DirectEve directEve) : base(directEve)
        {
            _attributes = new DirectItemAttributes(directEve, directEve.Session.CharacterId ?? -1);
        }

        #endregion Constructors

        #region Fields

        /// <summary>
        ///     Attribute cache
        /// </summary>
        private readonly DirectItemAttributes _attributes;

        private bool? _IsOmegaClone;

        #endregion Fields

        #region Properties

        private static DateTime _lastInWwarp;

        private bool? _isWarping;

        public float AbyssalContentExpirationRemainingSeconds => IsAbyssalContentExpirationTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("abyssalContentExpirationTimer").Attribute("ratio").ToFloat() * 60
            : 0;

        public List<DirectBooster> Boosters =>
            DirectEve.GetLocalSvc("crimewatchSvc").Call("GetMyBoosters").ToList().Select(k => new DirectBooster(DirectEve, k)).ToList();

        public DirectSolarSystem CurrentSolarSystem => DirectEve.SolarSystems.TryGetValue(DirectEve.Session.SolarSystemId.Value, out var ss) ? ss : null;

        public string CorpName => DirectEve.GetOwner(DirectEve.Session.CorporationId ?? -1).Name;

        public float CriminalTimerRemainingSeconds => IsCriminalTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("criminalTimer").Attribute("ratio").ToFloat() * 900
            : 0;

        public List<IncursionEffect> IncursionEffects => IsIncursionActive
            ? DirectEve.GetLocalSvc("incursion").Attribute("incursionData").Attribute("effects").ToList<PyObject>().Select(k =>
                (IncursionEffect) Enum.Parse(typeof(IncursionEffect), k.ToDictionary<string>()["name"].ToUnicodeString())).ToList()
            : new List<IncursionEffect>();

        //
        //ToDo: Use this info to decline missions? other?
        //
        public float IncursionInfluence => IsIncursionActive
            ? DirectEve.GetLocalSvc("incursion").Attribute("incursionData").Attribute("influenceData").Attribute("influence").ToFloat()
            : 0;

        public float InvasionInfluence => IsInvasionActive
            ? DirectEve.GetLocalSvc("incursion").Attribute("invasionData").Attribute("influenceData").Attribute("influence").ToFloat()
            : 0;

        public bool IsAbyssalContentExpirationTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject suspectTimer = combatTimerContainer.Attribute("abyssalContentExpirationTimer");
                        return !suspectTimer.IsNone;
                    }
                }
                return false;
            }
        }

        /// <summary>
        ///     Are we in an active war?
        /// </summary>
        /// <returns></returns>
        public bool IsAtWar
        {
            get
            {
                //var id = DirectEve.Session.AllianceId;
                //if (id == null)
                //    id = DirectEve.Session.CorporationId;

                //var atWar = (int)DirectEve.GetLocalSvc("war").Attribute("wars").Call("AreInAnyHostileWarStates", id);
                //if (atWar == 1)
                //    return true;
                //else
                //    return false;
                try
                {
                    long? allyId = DirectEve.Session.AllianceId;
                    long? corpId = DirectEve.Session.CorporationId;
                    PyObject warSvc = DirectEve.GetLocalSvc("war");
                    Dictionary<long, PyObject>.ValueCollection wars = warSvc.Attribute("wars").Attribute("warsByWarID").ToDictionary<long>().Values;
                    //DirectEve.Log($"AllyId {allyId} CorpId {corpId}");
                    foreach (PyObject war in wars)
                    {
                        DateTime timeStarted = war.Attribute("timeStarted").ToDateTime();
                        DateTime timeDeclared = war.Attribute("timeDeclared").ToDateTime();
                        int againstID = war.Attribute("againstID").ToInt();
                        int declaredByID = war.Attribute("declaredByID").ToInt();

                        //DirectEve.Log($"timeStarted {timeStarted} timeDeclared {timeDeclared} againstID {againstID} declaredByID {declaredByID}");

                        if (allyId == againstID || corpId == againstID || allyId == declaredByID || corpId == declaredByID)
                            if (timeStarted.AddMinutes(-240) < DateTime.UtcNow)
                            {
                                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.NOTICE, $"War detected! War begins at {timeStarted}"));
                                return true;
                            }
                    }

                    return false;
                }
                catch (Exception e)
                {
                    DirectEve.Log(e.ToString());
                    return true;
                }
            }
        }

        public bool IsCriminalTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject criminalTimer = combatTimerContainer.Attribute("criminalTimer");
                        return !criminalTimer.IsNone;
                    }
                }
                return false;
            }
        }

        public bool IsIncursionActive => !DirectEve.GetLocalSvc("incursion").Attribute("incursionData").IsNone;

        public bool IsInvasionActive => !DirectEve.GetLocalSvc("invasion").Attribute("invasionData").IsNone;

        public bool IsInvulnUndock
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject invulnTimer = combatTimerContainer.Attribute("invulnTimer");
                        return !invulnTimer.IsNone;
                    }
                }

                return false;
            }
        }

        public float IsInvulnUndockRemainingSeconds => IsInvulnUndock
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("invulnTimer").Attribute("ratio").ToFloat() * 30
            : 0;

        public bool IsJumpActivationTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject jumpActivationTimer = combatTimerContainer.Attribute("jumpActivationTimer");
                        return !jumpActivationTimer.IsNone;
                    }
                }
                return false;
            }
        }

        public bool IsJumpCloakActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject jumpCloakTimer = combatTimerContainer.Attribute("jumpCloakTimer");
                        return !jumpCloakTimer.IsNone;
                    }
                }
                //!DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("jumpCloakTimer").IsNone;
                return false;
            }
        }

        public bool IsJumpFatigueTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject jumpFatigueTimer = combatTimerContainer.Attribute("jumpFatigueTimer");
                        return !jumpFatigueTimer.IsNone;
                    }
                }
                return false;
            }
        }

        public bool IsNpcLogoffTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject npcTimer = combatTimerContainer.Attribute("npcTimer");
                        return !npcTimer.IsNone;
                    }
                }
                return false;
            }
        }

        public bool? IsOmegaClone
        {
            get
            {
                if (_IsOmegaClone == null)
                {
                    int b = (int) DirectEve.GetLocalSvc("cloneGradeSvc").Call("IsOmega");
                    _IsOmegaClone = b == 1;
                }
                return _IsOmegaClone;
            }
        }

        //  def GetOmegaTime(self):
        //return sm.RemoteSvc('subscriptionMgr').GetSubscriptionTime() - 20.11.2017
        //CLONE_STATE_ALPHA = 0
        //CLONE_STATE_OMEGA = 1
        public bool IsPvpLogoffTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject pvpTimer = combatTimerContainer.Attribute("pvpTimer");
                        return !pvpTimer.IsNone;
                    }
                }
                return false;
            }
        }

        public bool IsSuspectTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject suspectTimer = combatTimerContainer.Attribute("engagementTimer");
                        return !suspectTimer.IsNone;
                    }
                }
                return false;
            }
        }

        public bool IsTrialAccount => DirectEve.Session.UserType == 23;

        public bool IsWarping
        {
            get
            {
                if (_isWarping == null)
                {
                    _isWarping = DirectEve.Session.IsInSpace && !DirectEve.Session.IsInDockableLocation && DirectEve.ActiveShip.Entity != null && DirectEve.ActiveShip.Entity.IsWarping;
                    if (_isWarping.Value)
                        _lastInWwarp = DateTime.UtcNow;
                }
                return _isWarping.Value || _lastInWwarp.AddMilliseconds(1250) > DateTime.UtcNow;
            }
        }

        public bool IsWeaponsTimerActive
        {
            get
            {
                PyObject panelSvc = DirectEve.GetLocalSvc("infoPanel");
                if (panelSvc.IsValid)
                {
                    PyObject combatTimerContainer = panelSvc.Attribute("combatTimerContainer");
                    if (combatTimerContainer.IsValid)
                    {
                        PyObject weaponsTimer = combatTimerContainer.Attribute("weaponsTimer");
                        return !weaponsTimer.IsNone;
                    }
                }
                return false;
            }
        }

        //other timer attributes
        //boosterTimer
        //jumpFatigueTimer

        public float JumpActivationRemainingSeconds => IsJumpActivationTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("jumpActivationTimer").Attribute("ratio").ToFloat() * 60
            : 0;

        public float JumpCloakRemainingSeconds => IsJumpCloakActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("jumpCloakTimer").Attribute("ratio").ToFloat() * 60
            : 0;

        public float JumpFatigueRemainingSeconds => IsJumpFatigueTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("jumpFatigueTimer").Attribute("ratio").ToFloat() * 60
            : 0;

        public int MaxActiveDrones => _attributes.TryGet<int>("maxActiveDrones");
        public int MaxLockedTargets => _attributes.TryGet<int>("maxLockedTargets");
        public string Name => DirectEve.GetOwner(DirectEve.Session.CharacterId ?? -1).Name;

        public float NpcTimerRemainingSeconds => IsNpcLogoffTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("npcTimer").Attribute("ratio").ToFloat() * 300
            : 0;

        public float PvpTimerRemainingSeconds => IsPvpLogoffTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("pvpTimer").Attribute("ratio").ToFloat() * 900
            : 0;

        public string shortName => DirectEve.GetOwner(DirectEve.Session.AllianceId ?? -1).shortName;

        /// <summary>
        ///     Retrieves days left on account after login
        /// </summary>
        //  daysLeft = sm.GetService('charactersheet').GetSubscriptionDays(force)
        // __builtin__.uicore.layer.charsel.countDownCont.subTimeEnd // duketwo 05.29.2016
        public DateTime SubTimeEnd
        {
            get
            {
                //if (DirectEve.Login.AtCharacterSelection)
                //{
                    //DateTime subTimeEnd = PySharp.Import("carbonui")
                        //.Attribute("uicore")
                        //.Attribute("uicore")
                        //.Attribute("layer")
                        //.Attribute("charsel")
                        //.Attribute("countDownCont")
                        //.Attribute("subTimeEnd")
                        //.ToDateTime();

                    var daysLeft = (int?)DirectEve.GetLocalSvc("charactersheet").Call("GetSubscriptionDays");

                    if (daysLeft != null && daysLeft > 0)
                        return DateTime.UtcNow.AddDays((int)daysLeft);

                    //if (subTimeEnd > DateTime.UtcNow)
                    //    return subTimeEnd;
                    //else
                    //    return DateTime.MinValue;
                //}



                    //return DateTime.MinValue;
                    //}

                return DateTime.MinValue;
            }
        }

        public float SuspectTimerRemainingSeconds => IsSuspectTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("engagementTimer").Attribute("ratio").ToFloat() * 900
            : 0;

        public string tickerName => DirectEve.GetOwner(DirectEve.Session.CorporationId ?? -1).tickerName;
        public double Wealth => DirectEve.Wallet.Wealth;

        //public double CorpWealth => (double) DirectEve.GetLocalSvc("wallet").Attribute("corpwealth");

        public float WeaponsTimerRemainingSeconds => IsWeaponsTimerActive
            ? DirectEve.GetLocalSvc("infoPanel").Attribute("combatTimerContainer").Attribute("weaponsTimer").Attribute("ratio").ToFloat() * 900
            : 0;

        #endregion Properties

        #region Methods

        public double DistanceFromMe(Vector3 pos)
        {
            double curX = DirectEve.ActiveShip.Entity.X;
            double curY = DirectEve.ActiveShip.Entity.Y;
            double curZ = DirectEve.ActiveShip.Entity.Z;
            return Math.Round(Math.Sqrt((curX - pos.X) * (curX - pos.X) + (curY - pos.Y) * (curY - pos.Y) + (curZ - pos.Z) * (curZ - pos.Z)), 2);
        }

        public double DistanceFromMe(double x, double y, double z)
        {
            return DistanceFromMe(new Vector3(x, y, z));
        }

        public List<NegativeBoosterEffect> GetAllNegativeBoosterEffects()
        {
            return Boosters.SelectMany(k => GetNegativeBoosterEffects(k)).ToList();
        }

        public List<DirectDgmEffect> GetBoosterEffects(DirectBooster booster, bool negativeOnly = false)
        {
            if (!booster.PyObject.IsValid)
                return new List<DirectDgmEffect>();
            PyObject obj = DirectEve.GetLocalSvc("crimewatchSvc").Call("GetBoosterEffects", booster.PyObject);
            return obj.ToDictionary<string>().Where(k => negativeOnly ? k.Key.Equals("negative") : true).SelectMany(b => b.Value.ToList())
                .Select(b => new DirectDgmEffect(DirectEve, b)).ToList();
        }

        public List<NegativeBoosterEffect> GetNegativeBoosterEffects(DirectBooster booster)
        {
            if (!booster.PyObject.IsValid)
                return new List<NegativeBoosterEffect>();
            List<DirectDgmEffect> negEffects = GetBoosterEffects(booster, true);
            return negEffects.Select(k => (NegativeBoosterEffect) Enum.Parse(typeof(NegativeBoosterEffect), k.EffectName)).ToList();
        }

        #endregion Methods
    }
}