﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Framework.Events;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Actions;
using EVESharpCore.Questor.Activities;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.Stats;
using EVESharpCore.Questor.Storylines;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.Events;
using SC::SharedComponents.EVE;
using SC::SharedComponents.Extensions;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Questor.Behaviors
{
    public class CombatMissionsBehavior
    {
        #region Constructors

        public CombatMissionsBehavior()
        {
            //_lastPulse = DateTime.MinValue;
            ResetStatesToDefaults();
        }

        #endregion Constructors

        #region Fields

        private static bool _previousInMission;

        #endregion Fields

        #region Methods

        public static bool ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState _CMBStateToSet, bool wait, DirectAgent myAgent)
        {
            try
            {
                if (State.CurrentCombatMissionBehaviorState != _CMBStateToSet)
                {
                    if (_CMBStateToSet == CombatMissionsBehaviorState.Arm)
                        AgentInteraction.LastButtonPushedPerAgentId = new Dictionary<long, ButtonType>();

                    if (_CMBStateToSet == CombatMissionsBehaviorState.GotoBase)
                        State.CurrentTravelerState = TravelerState.Idle;

                    if (_CMBStateToSet == CombatMissionsBehaviorState.Start)
                        State.CurrentAgentInteractionState = AgentInteractionState.Idle;

                    if (_CMBStateToSet == CombatMissionsBehaviorState.CourierMission)
                        if (MissionSettings.StorylineMission != null && MissionSettings.StorylineMission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.Idle)
                            CourierMissionCtrl.ChangeCourierMissionCtrlState(MissionSettings.StorylineMission, CourierMissionCtrlState.Start);

                    Log.WriteLine("New CombatMissionsBehaviorState [" + _CMBStateToSet + "]");
                    State.CurrentCombatMissionBehaviorState = _CMBStateToSet;
                    if (!wait) ProcessState(myAgent);
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }

            return true;
        }

        public static bool CMBBringSpoilsOfWar()
        {
            if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                return true;

            if (MissionSettings.StorylineMission == null || MissionSettings.StorylineMission.Agent.StationId != ESCache.Instance.DirectEve.Session.LocationId)
                return true;

            if (!ESCache.Instance.InSpace && ESCache.Instance.InStation)
            {
                if (!Arm.BringSpoilsOfWar()) return false;
                return true;
            }

            return false;
        }

        public static bool PrepareToMoveToNewStation(DirectAgent myAgent)
        {
            if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                return true;

            if (!ESCache.Instance.InSpace && ESCache.Instance.InStation)
            {
                if (!Cleanup.RepairItems()) return false;

                if (ESCache.Instance.ItemHangar != null && !ESCache.Instance.ItemHangar.Items.Any()) return true;

                if (State.CurrentArmState == ArmState.Idle)
                {
                    Log.WriteLine("Begin: Arm.PrepareToMoveToNewStation");
                    Arm.ChangeArmState(ArmState.PrepareToMoveToNewStation, true, myAgent);
                }

                Arm.ProcessState(myAgent);

                if (State.CurrentArmState == ArmState.Done)
                {
                    Arm.ChangeArmState(ArmState.Idle, true, myAgent);
                    return true;
                }

                return false;
            }

            return true;
        }

        public static void ProcessState(DirectAgent myAgent)
        {
            try
            {
                if (!CMBEveryPulse(myAgent)) return;

                if (string.IsNullOrEmpty(MissionSettings.strCurrentAgentName))
                {
                    if (DebugConfig.DebugAgentInteractionReplyToAgent)
                        Log.WriteLine("if (string.IsNullOrEmpty(Cache.Instance.strCurrentAgentName)) return;");
                    return;
                }

                if (DebugConfig.DebugCombatMissionsBehavior) Log.WriteLine("State.CurrentCombatMissionBehaviorState is [" + State.CurrentCombatMissionBehaviorState + "]");

                switch (State.CurrentCombatMissionBehaviorState)
                {
                    case CombatMissionsBehaviorState.Idle:
                        IdleCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.DelayedGotoBase:
                        DelayedGotoBaseCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.Start:
                        StartCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.Switch:
                        SwitchCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.Arm:
                        if (MissionSettings.MyMission != null)
                        {
                            ArmCMBState(MissionSettings.MyMission.Agent);
                            break;
                        }
                        else
                        {
                            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, false, myAgent);
                        }

                        break;

                    case CombatMissionsBehaviorState.LocalWatch:
                        LocalWatchCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.WaitingforBadGuytoGoAway:
                        WaitingFoBadGuyToGoAway(myAgent);
                        break;

                    case CombatMissionsBehaviorState.WarpOutStation:
                        WarpOutBookmarkCMBState(myAgent);
                        //ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoMission, true);
                        break;

                    case CombatMissionsBehaviorState.GotoMission:
                        GotoMissionCmbState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.ExecuteMission:
                        ExecuteMissionCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.GotoBase:
                        GotoBaseCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.CompleteMission:
                        CompleteMissionCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.Statistics:
                        StatisticsCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.UnloadLoot:
                        UnloadLootCMBState(myAgent);
                        break;

                    //case CombatMissionsBehaviorState.CheckBookmarkAge:
                    //    if (!ESCache.Instance.DeleteUselessSalvageBookmarks("RemoveOldBookmarks")) return;
                    //    Statistics.StartedSalvaging = DateTime.UtcNow;
                    //    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.BeginAfterMissionSalvaging, false);
                    //    break;

                    //case CombatMissionsBehaviorState.BeginAfterMissionSalvaging:
                    //    BeginAftermissionSalvagingCMBState();
                    //    break;

                    //case CombatMissionsBehaviorState.GotoSalvageBookmark:
                    //    SalvageGotoBookmarkCMBState();
                    //    break;

                    //case CombatMissionsBehaviorState.Salvage:
                    //    SalvageCMBState();
                    //    break;

                    //case CombatMissionsBehaviorState.SalvageUseGate:
                    //    SalvageUseGateCMBState();
                    //    break;

                    //case CombatMissionsBehaviorState.SalvageNextPocket:
                    //    SalvageNextPocketCMBState();
                    //    break;

                    case CombatMissionsBehaviorState.PrepareStorylineSwitchAgents:
                        //DirectAgent agent = null;
                        //if (_storyline.StorylineMission != null)
                        //    if (_storyline.StorylineMission.AgentId != 0)
                        //        agent = ESCache.Instance.DirectEve.GetAgentById(_storyline.StorylineMission.AgentId);

                        //MissionSettings.strCurrentAgentName = agent.Name;
                        //ESCache.Instance.CurrentStorylineAgentId = agent.AgentId;
                        //MissionSettings.Agent = null;
                        /**
                        try
                        {
                            if (!Arm.ActivateShip(Combat.Combat.CombatShipName))
                                return;

                            Arm.ChangeArmState(ArmState.Idle);
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                        }
                        **/

                        Log.WriteLine("agent is [ " + MissionSettings.StorylineMission.Agent.Name + " ][" + MissionSettings.StorylineMission.Agent.SolarSystem.Name + "]");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.PrepareStorylineChangeFitting, false, MissionSettings.StorylineMission.Agent);
                        break;

                    case CombatMissionsBehaviorState.PrepareStorylineChangeFitting:
                        if (!Settings.Instance.UseFittingManager)
                            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Storyline, false, MissionSettings.StorylineMission.Agent);

                        if (State.CurrentArmState == ArmState.Idle)
                            Arm.ChangeArmState(ArmState.Begin, true, MissionSettings.StorylineMission.Agent);

                        Arm.ProcessState(MissionSettings.StorylineMission.Agent);

                        if (State.CurrentArmState == ArmState.Done)
                            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Storyline, false, MissionSettings.StorylineMission.Agent);

                        break;

                    case CombatMissionsBehaviorState.PrepareStorylineGotoBase:
                        PrepareStorylineGotoBaseCMBState(MissionSettings.StorylineMission.Agent);
                        break;

                    case CombatMissionsBehaviorState.Storyline:
                        MissionSettings.StorylineInstance.ProcessState();
                        if (State.CurrentStorylineState == StorylineState.Done)
                        {
                            Log.WriteLine("We have completed the storyline, resetting agent and returning to base");
                            MissionSettings.ClearMissionSpecificSettings();

                            if (myAgent == null)
                            {
                                Log.WriteLine("Storyline: done: if (MissionSettings.AgentToPullNextRegularMissionFrom == null)");
                                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Error, true, null);
                            }

                            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                        }
                        break;

                    case CombatMissionsBehaviorState.StorylineReturnToBase:
                        StorylineReturnToBaseCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.CourierMissionArm:
                        CourierMissionArmCmbState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.CourierMission:
                        if (MissionSettings.MyMission != null)
                        {
                            CourierMissionCtrl.ProcessState(MissionSettings.MyMission);
                            return;
                        }

                        Log.WriteLine("CombatMissionsBehavior.ProcessState: CourierMission: RegularMission must be complete. GoToBase");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                        break;

                    case CombatMissionsBehaviorState.Traveler:
                        TravelerCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.GotoNearestStation:
                        GotoNearestStationCMBState(myAgent);
                        break;

                    case CombatMissionsBehaviorState.Default:
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, false, myAgent);
                        break;
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static void StatisticsCMBState(DirectAgent myAgent)
        {
            if (Drones.UseDrones && !ESCache.Instance.ActiveShip.IsShipWithNoDroneBay)
            {
                DirectInvType drone = ESCache.Instance.DirectEve.GetInvType(Drones.DroneTypeID);
                if (drone != null)
                {
                    if (Drones.DroneBay == null)
                    {
                        Log.WriteLine("StatisticsCMBState: if (Drones.DroneBay == null)");
                        return;
                    }

                    Statistics.LostDrones = (int)Math.Floor((Drones.DroneBay.Capacity - Drones.DroneBay.UsedCapacity) / drone.Volume);
                    if (!Statistics.WriteDroneStatsLog()) return;
                }
                else
                {
                    Log.WriteLine("Could not find the drone TypeID specified in the character settings xml; this should not happen!");
                }
            }

            if (!Statistics.AmmoConsumptionStatistics()) return;
            Statistics.FinishedMission = DateTime.UtcNow;

            try
            {
                if (!Statistics.MissionLoggingCompleted)
                    if (!Statistics.WriteMissionStatistics()) return;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }

            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.UnloadLoot, false, myAgent);
        }

        private static void ArmCMBState(DirectAgent myAgent)
        {
            if (!AttemptToBuyAmmo()) return;
            if (!AttemptToBuyLpItems()) return;
            //if (!AttemptToCourierContractItems()) return;

            if (State.CurrentArmState == ArmState.Idle)
            {
                Log.WriteLine("Begin Arm");
                Arm.ChangeArmState(ArmState.Begin, true, myAgent);
            }

            if (!ESCache.Instance.InStation) return;

            Arm.ProcessState(myAgent);

            if (State.CurrentArmState == ArmState.NotEnoughAmmo)
            {
                Log.WriteLine("Armstate.NotEnoughAmmo");
                Arm.ChangeArmState(ArmState.Idle, true, myAgent);
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Error, true, myAgent);
                return;
            }

            if (State.CurrentArmState == ArmState.NotEnoughDrones)
            {
                Log.WriteLine("Armstate.NotEnoughDrones");
                Arm.ChangeArmState(ArmState.Idle, true, myAgent);
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Error, true, myAgent);
                return;
            }

            if (State.CurrentArmState == ArmState.Done)
            {
                Arm.ChangeArmState(ArmState.Idle, true, myAgent);

                if (Settings.Instance.BuyAmmo && BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.DisabledForThisSession)
                {
                    BuyAmmoController.CurrentBuyAmmoState = BuyAmmoState.Idle;
                    ControllerManager.Instance.RemoveController(typeof(BuyAmmoController));
                }

                State.CurrentDroneState = DroneState.WaitingForTargets;
                if (MissionSettings.CourierMission(myAgent))
                {
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.CourierMission, false, myAgent);
                    return;
                }

                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.LocalWatch, false, myAgent);
            }
        }

        private static bool AttemptToBuyAmmo()
        {
            if (Settings.Instance.BuyAmmo)
            {
                if (MissionSettings.StorylineMission != null && MissionSettings.StorylineMission.Agent.StationId == ESCache.Instance.DirectEve.Session.StationId)
                {
                    Log.WriteLine("We are at a Storyline Agents Station. We only attempt to check for and buy ammo when we are at our regular agents station.");
                    return true;
                }

                if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.Storyline || State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.StorylineReturnToBase)
                {
                    Log.WriteLine("We are on a Storyline. We only attempt to check for and buy ammo when we are at our regular agents station.");
                    return true;
                }

                if (BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.Done && BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.DisabledForThisSession)
                    if (DateTime.UtcNow > ESCache.Instance.EveAccount.LastAmmoBuy.AddHours(8) && DateTime.UtcNow > ESCache.Instance.EveAccount.LastBuyLpItemAttempt.AddHours(1))
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastAmmoBuyAttempt), DateTime.UtcNow);
                        ControllerManager.Instance.AddController(new BuyAmmoController());
                        return false;
                    }

                if (ESCache.Instance.EveAccount.SelectedController == "CareerAgentController")
                    if (DateTime.UtcNow > ESCache.Instance.EveAccount.LastAmmoBuy.AddHours(1) && DateTime.UtcNow > ESCache.Instance.EveAccount.LastAmmoBuyAttempt.AddHours(.5))
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastAmmoBuyAttempt), DateTime.UtcNow);
                        ControllerManager.Instance.AddController(new BuyAmmoController());
                        return false;
                    }
            }

            return true;
        }

        private static bool AttemptToBuyLpItems()
        {
            if (Settings.Instance.BuyLpItems)
                if (DateTime.UtcNow > ESCache.Instance.EveAccount.LastBuyLpItems.AddDays(8) && DateTime.UtcNow > ESCache.Instance.EveAccount.LastBuyLpItemAttempt.AddDays(1))
                {
                    State.CurrentBuyLpItemsState = BuyLpItemsState.Idle;
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastBuyLpItemAttempt), DateTime.UtcNow);
                    ControllerManager.Instance.AddController(new BuyLpItemsController());
                    return false;
                }

            return true;
        }

        private static bool AttemptToCourierContractItems()
        {
            if (Settings.Instance.CreateCourierContracts)
                if (DateTime.UtcNow > ESCache.Instance.EveAccount.LastCreateContract.AddDays(1) && DateTime.UtcNow > ESCache.Instance.EveAccount.LastCreateContractAttempt.AddHours(4))
                {
                    State.CurrentCourierContractState = CourierContractState.Idle;
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastCreateContractAttempt), DateTime.UtcNow);
                    ControllerManager.Instance.AddController(new CourierContractController());
                    return false;
                }

            return true;
        }

        /**
        private static void BeginAftermissionSalvagingCMBState()
        {
            Statistics.StartedSalvaging = DateTime.UtcNow;
            Drones.DronesShouldBePulled = false;
            Salvage.CurrentlyShouldBeSalvaging = true;

            if (DateTime.UtcNow.Subtract(_lastSalvageTrip).TotalMinutes < Time.Instance.DelayBetweenSalvagingSessions_minutes &&
                Settings.Instance.CharacterMode.ToLower() == "salvage".ToLower())
            {
                Log.WriteLine("Too early for next salvage trip");
                return;
            }

            if (DateTime.UtcNow > _nextBookmarkRefreshCheck)
            {
                _nextBookmarkRefreshCheck = DateTime.UtcNow.AddMinutes(1);
                if (ESCache.Instance.InStation && DateTime.UtcNow > _nextBookmarksrefresh)
                {
                    _nextBookmarksrefresh = DateTime.UtcNow.AddMinutes(ESCache.Instance.RandomNumber(2, 4));
                    Log.WriteLine("Refreshing Bookmarks Now: Next Bookmark refresh in [" +
                                  Math.Round(_nextBookmarksrefresh.Subtract(DateTime.UtcNow).TotalMinutes, 0) +
                                  "min]");
                    ESCache.Instance.DirectEve.RefreshBookmarks();
                    return;
                }

                Log.WriteLine("Next Bookmark refresh in [" + Math.Round(_nextBookmarksrefresh.Subtract(DateTime.UtcNow).TotalMinutes, 0) + "min]");
            }

            Salvage.OpenWrecks = true;

            if (State.CurrentArmState == ArmState.Idle)
                Arm.ChangeArmState(ArmState.ActivateSalvageShip);

            Arm.ProcessState();
            if (State.CurrentArmState == ArmState.Done)
            {
                Arm.ChangeArmState(ArmState.Idle);
                DirectBookmark bookmark = ESCache.Instance.GetSalvagingBookmark;
                if (bookmark == null && ESCache.Instance.BookmarksByLabel(Settings.Instance.BookmarkPrefix + " ").Any())
                {
                    bookmark = ESCache.Instance.BookmarksByLabel(Settings.Instance.BookmarkPrefix + " ").OrderBy(b => b.CreatedOn).FirstOrDefault();
                    if (bookmark == null)
                    {
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, false);
                        return;
                    }
                }

                _lastSalvageTrip = DateTime.UtcNow;
                Traveler.Destination = new BookmarkDestination(bookmark);
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoSalvageBookmark, false);
            }
        }
        **/

        private static bool CMBEveryPulse(DirectAgent myAgent)
        {
            if (!Settings.Instance.DefaultSettingsLoaded)
                Settings.Instance.LoadSettings();

            if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                return false;

            if (Settings.Instance.FinishWhenNotSafe && State.CurrentCombatMissionBehaviorState != CombatMissionsBehaviorState.GotoNearestStation)
                if (ESCache.Instance.InSpace &&
                    !ESCache.Instance.LocalSafe(Settings.Instance.LocalBadStandingPilotsToTolerate, Settings.Instance.LocalBadStandingLevelToConsiderBad))
                {
                    EntityCache station = null;
                    if (ESCache.Instance.Stations.Any())
                        station = ESCache.Instance.Stations.OrderBy(x => x.Distance).FirstOrDefault();

                    if (station != null)
                    {
                        Log.WriteLine("Station found. Going to nearest station");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoNearestStation, true, null);
                    }
                    else
                    {
                        Log.WriteLine("Station not found. Going back to base");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                    }
                }

            Panic.ProcessState();

            if (State.CurrentPanicState == PanicState.Resume)
            {
                if (ESCache.Instance.InSpace || ESCache.Instance.InStation)
                {
                    State.CurrentPanicState = PanicState.Normal;

                    if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.Storyline)
                    {
                        Log.WriteLine("PanicState.Resume: CMB State is Storyline");
                        if (MissionSettings.StorylineInstance.StorylineHandler is GenericCombatStoryline)
                        {
                            (MissionSettings.StorylineInstance.StorylineHandler as GenericCombatStoryline).CurrentGenericCombatStorylineState = GenericCombatStorylineState.GotoMission;
                            Log.WriteLine("PanicState.Resume: Setting GenericCombatStorylineState to GotoMission");
                        }

                        return true;
                    }

                    if (MissionSettings.MyMission != null && MissionSettings.MyMission.Important && !MissionSettings.MyMission.Name.ToLower().Contains("Cash Flow for Capsuleers".ToLower()))
                    {
                        Log.WriteLine("PanicState.Resume: MissionSettings.RegularMission.Important");
                        if (MissionSettings.StorylineInstance.StorylineHandler is GenericCombatStoryline)
                        {
                            (MissionSettings.StorylineInstance.StorylineHandler as GenericCombatStoryline).CurrentGenericCombatStorylineState = GenericCombatStorylineState.GotoMission;
                            Log.WriteLine("PanicState.Resume: Setting GenericCombatStorylineState to GotoMission");
                        }

                        return true;
                    }

                    State.CurrentTravelerState = TravelerState.Idle;
                    if (!Cleanup.RepairItems()) return false; //attempt to use repair facilities if avail in station(););

                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoMission, false, myAgent);
                    return true;
                }

                return false;
            }

            return true;
        }

        private static void CompleteMissionCMBState(DirectAgent myAgent)
        {
            if (!ESCache.Instance.InStation) return;

            if (State.CurrentAgentInteractionState == AgentInteractionState.Idle)
            {
                Log.WriteLine("Start Conversation [Complete RegularMission]");
                State.CurrentAgentInteractionState = AgentInteractionState.StartConversation;
                //AgentInteraction.Purpose = AgentInteractionPurpose.CompleteMission;
            }

            AgentInteraction.ProcessState(myAgent);

            if (State.CurrentAgentInteractionState == AgentInteractionState.Done)
            {
                //AgentInteraction.CloseConversation();
                State.CurrentAgentInteractionState = AgentInteractionState.Idle;

                if (myAgent.Mission != null && myAgent.Mission.MissionCompletionErrors == 0)
                {
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Statistics, false, myAgent);
                    return;
                }

                Log.WriteLine("Skipping statistics: We have not yet completed a mission");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.UnloadLoot, false, myAgent);
            }
        }

        private static void CourierMissionArmCmbState(DirectAgent myAgent)
        {
            //if (!AttemptToBuyAmmo()) return;
            if (!AttemptToBuyLpItems()) return;

            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.CourierMission, false, myAgent);
        }

        private static void DelayedGotoBaseCMBState(DirectAgent myAgent)
        {
            Log.WriteLine("Heading back to base");
            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
        }

        private static void ExecuteMissionCMBState(DirectAgent myAgent)
        {
            if (!ESCache.Instance.InSpace)
                return;

            if (!ESCache.Instance.InMission)
            {
                //if (ESCache.Instance.MyShipEntity.HasInitiatedWarp) Log.WriteLine("InMission [" + ESCache.Instance.InMission + "]");
                return;
            }

            ActionControl.ProcessState(myAgent.Mission, myAgent);

            bool inMission = ESCache.Instance.InMission;
            if (_previousInMission != inMission && ESCache.Instance.EntitiesOnGrid.Any(e => e.BracketType == BracketType.NPC_Frigate
                                                                                            || e.BracketType == BracketType.NPC_Cruiser
                                                                                            || e.BracketType == BracketType.NPC_Battleship
                                                                                            || e.BracketType == BracketType.NPC_Destroyer))
            {
                if (!_previousInMission && inMission)
                {
                    Log.WriteLine($"NPCs found on grid and InMission has been changed. Reloading.");
                    Combat.Combat.ReloadAll();
                }

                _previousInMission = inMission;
            }

            if (State.CurrentCombatState == CombatState.OutOfAmmo)
            {
                Log.WriteLine("Out of DefinedAmmoTypes! - Not enough [" + MissionSettings.CurrentDamageType + "] ammo in cargohold: MinimumCharges: [" +
                              Combat.Combat.MinimumAmmoCharges +
                              "]");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                ESCache.Instance.LootedContainers.Clear();
            }

            if (State.CurrentCombatMissionCtrlState == ActionControlState.Done)
            {
                Log.WriteLine("Done: if (State.CurrentCombatMissionCtrlState == ActionControlState.Done)");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                ESCache.Instance.LootedContainers.Clear();
            }

            if (State.CurrentCombatMissionCtrlState == ActionControlState.Error)
            {
                Log.WriteLine("Error");
                DirectEventManager.NewEvent(new DirectEvent(DirectEvents.QUESTOR_ERROR, "Questor Error."));
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                ESCache.Instance.LootedContainers.Clear();
            }
        }

        private static void GotoBaseCMBState(DirectAgent myAgent)
        {
            //
            // if we are already in the correct place, we are done.
            //
            if (ESCache.Instance.InStation)
            {
                if (myAgent == null)
                {
                    Log.WriteLine("GotoBaseCMBState: if (myAgent == null)");
                    return;
                }
                //
                // we are docked
                //
                if (myAgent != null && myAgent.StationId == ESCache.Instance.DirectEve.Session.StationId)
                {
                    if (DebugConfig.DebugGotobase) Log.WriteLine("GotoBaseCMBState: if (MissionSettings.AgentToPullNextRegularMissionFrom.StationId == ESCache.Instance.DirectEve.Session.StationId)");
                    if (WeAreDockedAtTheCorrectStationNowWhat(myAgent)) return;
                    return;
                }

                if (!PrepareToMoveToNewStation(myAgent))
                {
                    if (DebugConfig.DebugGotobase) Log.WriteLine("GotoBaseCMBState: if (!PrepareToMoveToNewStation())");
                    return;
                }

                if (!CMBBringSpoilsOfWar())
                {
                    if (DebugConfig.DebugGotobase) Log.WriteLine("GotoBaseCMBState: if (!BringSpoilsOfWar())");
                    return;
                }
            }

            //
            // if we arent already in the correct place, travel...
            //
            Salvage.CurrentlyShouldBeSalvaging = false;

            if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugGotobase) Log.WriteLine("GotoBase: AvoidBumpingThings()");
                NavigateOnGrid.AvoidBumpingThings(ESCache.Instance.BigObjects.FirstOrDefault(), "CombatMissionsBehaviorState.GotoBase", NavigateOnGrid.TooCloseToStructure, NavigateOnGrid.AvoidBumpingThingsBool());
            }

            if (DebugConfig.DebugGotobase) Log.WriteLine("GotoBase: Traveler.TravelHome()");

            Traveler.TravelHome(MissionSettings.AgentToPullNextRegularMissionFrom);

            if (State.CurrentTravelerState == TravelerState.AtDestination && ESCache.Instance.InStation)
                if (DebugConfig.DebugGotobase) Log.WriteLine("GotoBase: We are at destination");
        }

        private static void GotoMissionCmbState(DirectAgent myAgent)
        {
            try
            {
                if (ESCache.Instance.InSpace && ESCache.Instance.MyShipEntity != null && ESCache.Instance.MyShipEntity.HasInitiatedWarp) return;

                if (MissionSettings.MyMission == null || MissionSettings.MyMission != null && MissionSettings.MyMission.State != MissionState.Accepted)
                {
                    Log.WriteLine("if (MissionSettings.RegularMission == null || (MissionSettings.RegularMission != null && MissionSettings.RegularMission.State != MissionState.Accepted))");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Start, true, myAgent);
                }

                MissionBookmarkDestination missionDestination = Traveler.Destination as MissionBookmarkDestination;

                if (missionDestination == null || missionDestination.AgentId != myAgent.AgentId)
                    if (MissionSettings.GetMissionBookmark(myAgent, "Encounter") != null)
                    {
                        Log.WriteLine("Setting Destination to 1st bookmark from Agent: " + myAgent.Name + " with [" + "Encounter" +
                                      "] in the title");
                        Traveler.Destination =
                            new MissionBookmarkDestination(MissionSettings.GetMissionBookmark(myAgent, "Encounter"));
                        if (ESCache.Instance.DirectEve.Navigation.GetLocation(Traveler.Destination.SolarSystemId) != null)
                        {
                            ESCache.Instance.MissionSolarSystem = ESCache.Instance.DirectEve.Navigation.GetLocation(Traveler.Destination.SolarSystemId);
                            Log.WriteLine("MissionSolarSystem is [" + ESCache.Instance.MissionSolarSystem.Name + "]");
                        }
                    }
                    else
                    {
                        //
                        // we used to "gotobase" here. I dont think thats needed
                        //
                        Log.WriteLine("We have no mission bookmark available for our current/normal agent: waiting for bookmark");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Start, true, myAgent);
                        return;
                    }

                Traveler.ProcessState();

                if (State.CurrentTravelerState == TravelerState.AtDestination)
                {
                    State.CurrentCombatMissionCtrlState = ActionControlState.Start;
                    Traveler.Destination = null;
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.ExecuteMission, true, myAgent);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void GotoNearestStationCMBState(DirectAgent myAgent)
        {
            if (!ESCache.Instance.InSpace || ESCache.Instance.InSpace && ESCache.Instance.InWarp || ESCache.Instance.InSpace && ESCache.Instance.MyShipEntity.HasInitiatedWarp) return;
            EntityCache station = null;
            if (ESCache.Instance.Stations.Any())
                station = ESCache.Instance.Stations.OrderBy(x => x.Distance).FirstOrDefault();

            if (station != null)
            {
                if (station.Distance <= (int)Distances.DockingRange)
                {
                    if (station.Dock())
                    {
                        Log.WriteLine("[" + station.Name + "] which is [" + Math.Round(station.Distance / 1000, 0) + "k away]");
                        return;
                    }

                    return;
                }
                NavigateOnGrid.NavigateToTarget(station, 0);

                return;
            }

            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Error, true, myAgent);
        }

        private static void IdleCMBState(DirectAgent myAgent)
        {
            if (ESCache.Instance.InSpace)
            {
                Log.WriteLine("Idle: We started in space: GoToBase");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                return;
            }

            State.CurrentAgentInteractionState = AgentInteractionState.Idle;
            State.CurrentArmState = ArmState.Idle;
            State.CurrentDroneState = DroneState.Idle;
            State.CurrentSalvageState = SalvageState.Idle;
            State.CurrentStorylineState = StorylineState.Idle;
            State.CurrentTravelerState = TravelerState.AtDestination;
            State.CurrentUnloadLootState = UnloadLootState.Idle;
            //State.CurrentQuestorState = QuestorState.Idle;

            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Start, true, myAgent);
        }

        private static void LocalWatchCMBState(DirectAgent myAgent)
        {
            if (Settings.Instance.UseLocalWatch)
            {
                Time.Instance.LastLocalWatchAction = DateTime.UtcNow;

                if (DebugConfig.DebugArm) Log.WriteLine("Starting: Is LocalSafe check...");
                if (ESCache.Instance.LocalSafe(Settings.Instance.LocalBadStandingPilotsToTolerate, Settings.Instance.LocalBadStandingLevelToConsiderBad))
                {
                    Log.WriteLine("local is clear");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.WarpOutStation, false, myAgent);
                    return;
                }

                Log.WriteLine("Bad standings pilots in local: We will stay 5 minutes in the station and then we will check if it is clear again");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.WaitingforBadGuytoGoAway, true, myAgent);
                return;
            }

            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.WarpOutStation, false, myAgent);
        }

        private static void PrepareStorylineGotoBaseCMBState(DirectAgent myAgent)
        {
            if (DebugConfig.DebugGotobase) Log.WriteLine("PrepareStorylineGotoBase: AvoidBumpingThings()");
            NavigateOnGrid.AvoidBumpingThings(ESCache.Instance.BigObjects.FirstOrDefault(), "CombatMissionsBehaviorState.PrepareStorylineGotoBase", NavigateOnGrid.TooCloseToStructure, NavigateOnGrid.AvoidBumpingThingsBool());

            if (DebugConfig.DebugGotobase) Log.WriteLine("PrepareStorylineGotoBase: Traveler.TravelHome()");

            if (Settings.Instance.StoryLineBaseBookmark != "")
            {
                if (!Traveler.TravelToBookmarkName(Settings.Instance.StoryLineBaseBookmark))
                    Traveler.TravelHome(MissionSettings.AgentToPullNextRegularMissionFrom);
            }
            else
            {
                Traveler.TravelHome(MissionSettings.AgentToPullNextRegularMissionFrom);
            }

            if (State.CurrentTravelerState == TravelerState.AtDestination && ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugGotobase) Log.WriteLine("PrepareStorylineGotoBase: We are at destination");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Storyline, true, myAgent);
            }
        }

        private static bool ResetStatesToDefaults()
        {
            Log.WriteLine("CombatMissionsBehavior.ResetStatesToDefaults: start");
            State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Idle;
            State.CurrentAgentInteractionState = AgentInteractionState.Idle;
            State.CurrentArmState = ArmState.Idle;
            State.CurrentUnloadLootState = UnloadLootState.Idle;
            State.CurrentTravelerState = TravelerState.AtDestination;
            Log.WriteLine("CombatMissionsBehavior.ResetStatesToDefaults: done");
            return true;
        }

        /**
        private static void SalvageCMBState()
        {
            Salvage.SalvageAll = true;
            Salvage.OpenWrecks = true;
            Salvage.CurrentlyShouldBeSalvaging = true;

            EntityCache deadlyNPC = Combat.Combat.PotentialCombatTargets.FirstOrDefault();
            if (deadlyNPC != null)
            {
                List<DirectBookmark> missionSalvageBookmarks = ESCache.Instance.BookmarksByLabel(Settings.Instance.BookmarkPrefix + " ");
                Log.WriteLine("could not be completed because of NPCs left in the mission: deleting on grid salvage bookmark");

                if (Salvage.DeleteBookmarksWithNPC)
                {
                    if (!ESCache.Instance.DeleteBookmarksOnGrid("CombatMissionsBehavior.Salvage")) return;
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoSalvageBookmark, true);
                    DirectBookmark bookmark = missionSalvageBookmarks.OrderBy(i => i.CreatedOn).FirstOrDefault();
                    Traveler.Destination = new BookmarkDestination(bookmark);
                    return;
                }

                Log.WriteLine("could not be completed because of NPCs left in the mission: on grid salvage bookmark not deleted");
                Salvage.SalvageAll = false;
                Statistics.FinishedSalvaging = DateTime.UtcNow;
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase);
                return;
            }

            if (Salvage.UnloadLootAtStation)
                if (ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.UsedCapacity > 0)
                    if (ESCache.Instance.CurrentShipsCargo.Capacity - ESCache.Instance.CurrentShipsCargo.UsedCapacity <
                        Salvage.ReserveCargoCapacity + 10)
                    {
                        if (Drones.DronePriorityEntities.Any(pt => pt.IsWarpScramblingMe))
                            return;

                        Log.WriteLine("We are full: My Cargo is at [" +
                                      Math.Round(ESCache.Instance.CurrentShipsCargo.UsedCapacity, 2) + "m3] of[" +
                                      Math.Round(ESCache.Instance.CurrentShipsCargo.Capacity, 2) + "] Reserve [" +
                                      Math.Round((double)Salvage.ReserveCargoCapacity, 2) + "m3 + 10], go to base to unload");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase);
                        return;
                    }

            if (!ESCache.Instance.MyShipEntity.SalvagersAvailable || !ESCache.Instance.UnlootedContainers.Any() ||
                DateTime.UtcNow > Time.Instance.LastInWarp.AddMinutes(Time.Instance.MaxSalvageMinutesPerPocket))
            {
                if (!ESCache.Instance.DeleteBookmarksOnGrid("CombatMissionsBehavior.Salvage")) return;

                if (DateTime.UtcNow > Time.Instance.LastInWarp.AddMinutes(Time.Instance.MaxSalvageMinutesPerPocket))
                    Log.WriteLine("We have been salvaging this pocket for more than [" + Time.Instance.MaxSalvageMinutesPerPocket +
                                  "] min - moving on - something probably went wrong here somewhere. (debugSalvage might help narrow down what)");

                Log.WriteLine("Finished salvaging the pocket. UnlootedContainers [" + ESCache.Instance.UnlootedContainers.Count() + "] Wrecks [" +
                              ESCache.Instance.Wrecks +
                              "] Salvagers? [" + ESCache.Instance.MyShipEntity.SalvagersAvailable + "]");
                Statistics.FinishedSalvaging = DateTime.UtcNow;

                if (!ESCache.Instance.AfterMissionSalvageBookmarks.Any() && !ESCache.Instance.GateInGrid())
                {
                    Log.WriteLine("We have salvaged all bookmarks, go to base");
                    Salvage.SalvageAll = false;
                    Statistics.FinishedSalvaging = DateTime.UtcNow;
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase);
                    return;
                }

                if (!ESCache.Instance.GateInGrid())
                {
                    Log.WriteLine("Go to the next salvage bookmark");
                    DirectBookmark bookmark;
                    if (Salvage.FirstSalvageBookmarksInSystem)
                        bookmark =
                            ESCache.Instance.AfterMissionSalvageBookmarks.FirstOrDefault(c => c.LocationId == ESCache.Instance.DirectEve.Session.SolarSystemId) ??
                            ESCache.Instance.AfterMissionSalvageBookmarks.FirstOrDefault();
                    else
                        bookmark = ESCache.Instance.AfterMissionSalvageBookmarks.OrderBy(i => i.CreatedOn).FirstOrDefault() ??
                                   ESCache.Instance.AfterMissionSalvageBookmarks.FirstOrDefault();

                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoSalvageBookmark, true);
                    Traveler.Destination = new BookmarkDestination(bookmark);
                    return;
                }

                if (Salvage.UseGatesInSalvage)
                {
                    Log.WriteLine("Acceleration gate found - moving to next pocket");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.SalvageUseGate, true);
                    return;
                }

                Log.WriteLine("Acceleration gate found, useGatesInSalvage set to false - Returning to base");
                Statistics.FinishedSalvaging = DateTime.UtcNow;
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true);
                Traveler.Destination = null;
                return;
            }

            if (DebugConfig.DebugSalvage)
                Log.WriteLine("salvage: we __cannot ever__ approach in salvage.cs so this section _is_ needed");
            Salvage.MoveIntoRangeOfWrecks();
            try
            {
                Salvage.DedicatedSalvagerMaximumWreckTargets = ESCache.Instance.MaxLockedTargets;
                Salvage.DedicatedSalvagerReserveCargoCapacity = 80;
                Salvage.DedicatedSalvagerLootEverything = true;
            }
            finally
            {
                Salvage.DedicatedSalvagerMaximumWreckTargets = null;
                Salvage.DedicatedSalvagerReserveCargoCapacity = null;
                Salvage.DedicatedSalvagerLootEverything = null;
            }
        }
        **/

        /**
        private static void SalvageGotoBookmarkCMBState()
        {
            Traveler.ProcessState();

            if (State.CurrentTravelerState == TravelerState.AtDestination || ESCache.Instance.GateInGrid())
            {
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Salvage, true);
                Traveler.Destination = null;
            }
        }
        **/

        /**
        private static void SalvageNextPocketCMBState()
        {
            Salvage.OpenWrecks = true;
            double distance = ESCache.Instance.DistanceFromMe(_lastX, _lastY, _lastZ);
            if (distance > (int)Distances.NextPocketDistance)
            {
                Log.WriteLine("We have moved to the next Pocket [" + Math.Round(distance / 1000, 0) + "k away]");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Salvage, true);
                return;
            }

            if (DateTime.UtcNow.Subtract(_lastPulse).TotalMinutes > 2)
            {
                Log.WriteLine("We have timed out, retry last action");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.SalvageUseGate, true);
            }
        }
        **/

        /**
        private static void SalvageUseGateCMBState()
        {
            Salvage.OpenWrecks = true;

            if (ESCache.Instance.AccelerationGates == null || !ESCache.Instance.AccelerationGates.Any())
            {
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoSalvageBookmark, true);
                return;
            }

            _lastX = ESCache.Instance.ActiveShip.Entity.X;
            _lastY = ESCache.Instance.ActiveShip.Entity.Y;
            _lastZ = ESCache.Instance.ActiveShip.Entity.Z;

            EntityCache closest = ESCache.Instance.AccelerationGates.OrderBy(t => t.Distance).FirstOrDefault();
            if (closest != null && closest.Distance < (int)Distances.DecloakRange)
            {
                Log.WriteLine("Gate found: [" + closest.Name + "] groupID[" + closest.GroupId + "]");

                if (closest.Activate())
                {
                    Log.WriteLine("Activate [" + closest.Name + "] and change States.CurrentCombatMissionBehaviorState to 'NextPocket'");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.SalvageNextPocket, true);
                    _lastPulse = DateTime.UtcNow;
                    return;
                }

                return;
            }

            NavigateOnGrid.NavigateToTarget(closest, 0);
            _lastPulse = DateTime.UtcNow.AddSeconds(10);
        }
        **/

        private static void StartCMBState(DirectAgent myAgent)
        {
            if (MissionSettings.StorylineMissionDetected())
            {
                Log.WriteLine("if (MissionSettings.StorylineMissionDetected())");
                MissionSettings.StorylineInstance.Reset();
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.PrepareStorylineSwitchAgents, true, myAgent);
                return;
            }

            if (!ESCache.LootAlreadyUnloaded)
            {
                Log.WriteLine("if (!ESCache.LootAlreadyUnloaded)");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Switch, true, myAgent);
                return;
            }

            if (ESCache.Instance.InSpace)
            {
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                return;
            }

            if (ESCache.Instance.InStation)
            {
                if (Statistics.MissionsThisSession >= 10)
                {
                    ESCache.Instance.CloseQuestor("Statistics.MissionsThisSession >= 10: the schedule will restart questor as needed");
                    return;
                }
            }

            if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
            {
                if (DebugConfig.DebugTargetWrecks)
                    Log.WriteLine("Salvage.OpenWrecks = false;");
                Salvage.OpenWrecks = false;
            }
            else
            {
                Salvage.OpenWrecks = true;
            }

            if (State.CurrentAgentInteractionState == AgentInteractionState.Idle)
            {
                ESCache.Instance.Wealth = ESCache.Instance.DirectEve.Me.Wealth;

                Statistics.WrecksThisMission = 0;
                Log.WriteLine("Start conversation [Start Mission]");
                State.CurrentAgentInteractionState = AgentInteractionState.StartConversation;
            }

            AgentInteraction.ProcessState(myAgent);

            if (AgentInteraction.LastButtonPushedPerAgentId.ContainsKey(myAgent.AgentId))
            {
                ButtonType tempButton;
                AgentInteraction.LastButtonPushedPerAgentId.TryGetValue(myAgent.AgentId, out tempButton);
                if (tempButton == ButtonType.COMPLETE_MISSION)
                {
                    if (State.CurrentAgentInteractionState == AgentInteractionState.Done)
                    {
                        //AgentInteraction.CloseConversation();
                        State.CurrentAgentInteractionState = AgentInteractionState.Idle;
                        if (MissionSettings.CourierMission(myAgent))
                        {
                            AgentInteraction.LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.None);
                            CourierMissionCtrl.ChangeCourierMissionCtrlState(myAgent.Mission, CourierMissionCtrlState.Start);
                            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.CourierMissionArm, false, myAgent);
                            return;
                        }

                        AgentInteraction.LastButtonPushedPerAgentId.AddOrUpdate(myAgent.AgentId, ButtonType.None);
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.UnloadLoot, false, myAgent);
                        return;
                    }

                    return;
                }
            }

            if (State.CurrentAgentInteractionState == AgentInteractionState.Done)
            {
                //
                // If AgentInteraction changed the state of CurrentCombatMissionBehaviorState to Idle: return
                //
                if (State.CurrentCombatMissionBehaviorState == CombatMissionsBehaviorState.Idle)
                    return;

                if (ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.Items != null && ESCache.Instance.CurrentShipsCargo.Items.Any() &&
                    ESCache.Instance.ActiveShip.GivenName.ToLower() != Combat.Combat.CombatShipName.ToLower())
                {
                    Log.WriteLine("Start: if(Cache.Instance.CurrentShipsCargo.Items.Any()) UnloadLoot");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.UnloadLoot, false, myAgent);
                    return;
                }

                //
                // otherwise continue on and change to the Arm state
                //
                State.CurrentAgentInteractionState = AgentInteractionState.Idle;
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Arm, false, myAgent);
            }
        }

        private static void StorylineReturnToBaseCMBState(DirectAgent myAgent)
        {
            MissionSettings.StorylineInstance.Reset();
            if (DebugConfig.DebugGotobase) Log.WriteLine("StorylineReturnToBase: AvoidBumpingThings()");
            NavigateOnGrid.AvoidBumpingThings(ESCache.Instance.BigObjects.FirstOrDefault(), "CombatMissionsBehaviorState.StorylineReturnToBase", NavigateOnGrid.TooCloseToStructure, NavigateOnGrid.AvoidBumpingThingsBool());

            if (DebugConfig.DebugGotobase) Log.WriteLine("StorylineReturnToBase: TravelToStorylineBase");

            Traveler.TravelHome(MissionSettings.AgentToPullNextRegularMissionFrom);

            if (State.CurrentTravelerState == TravelerState.AtDestination && ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugGotobase) Log.WriteLine("StorylineReturnToBase: We are at destination");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Switch, true, myAgent);
            }
        }

        private static void SwitchCMBState(DirectAgent myAgent)
        {
            if (!ESCache.Instance.InStation && ESCache.Instance.InSpace)
            {
                Log.WriteLine("Switch: We are in space: GoToBase");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                return;
            }

            if (MissionSettings.MyMission != null && MissionSettings.MyMission.Type.ToLower().Contains("Courier".ToLower()) &&
                (MissionSettings.MyMission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.DropOffItem ||
                 MissionSettings.MyMission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.GotoDropOffLocation ||
                 MissionSettings.MyMission.CurrentCourierMissionCtrlState == CourierMissionCtrlState.GotoPickupLocation))
            {
                Log.WriteLine("We doing a courier mission: CombatMissionsBehaviorState.CourierMission");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.CourierMission, false, myAgent);
            }

            if (ESCache.Instance.DirectEve.Session.StationId != null && myAgent != null &&
                ESCache.Instance.DirectEve.Session.StationId != myAgent.StationId && MissionSettings.MyMission != null && !MissionSettings.MyMission.Type.Contains("Trade") && !MissionSettings.MyMission.Type.Contains("Courier"))
            {
                Log.WriteLine("We're not in the right station, going home.");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
                return;
            }



            if (ESCache.Instance.CurrentShipsCargo == null || ESCache.Instance.CurrentShipsCargo.Items == null || ESCache.Instance.ItemHangar == null ||
                ESCache.Instance.ItemHangar.Items == null)
                return;

            if (ESCache.Instance.InStation && Settings.Instance.BuyPlex && BuyPlexController.ShouldBuyPlex)
            {
                //BuyPlexController.CheckBuyPlex();
                //ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, true);
                //return;
            }

            if (ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.Items != null && ESCache.Instance.CurrentShipsCargo.Items.Any() &&
                ESCache.Instance.ActiveShip.GivenName.ToLower() != Combat.Combat.CombatShipName.ToLower())
            {
                Log.WriteLine("if(Cache.Instance.CurrentShipsCargo.Items.Any())");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.UnloadLoot, false, myAgent);
                return;
            }

            if (State.CurrentArmState == ArmState.Idle)
                if (myAgent != null && myAgent.DivisionId == 24) //24 == security
                {
                    Log.WriteLine("Begin: Using Agent [" + myAgent.Name + "] Level [" + myAgent.Level + "] Division [" + myAgent.DivisionName + "]");
                    Arm.SwitchShipsOnly = true;
                    if (MissionSettings.MyMission != null && MissionSettings.MyMission.Faction == null)
                        return;

                    Arm.ChangeArmState(ArmState.ActivateCombatShip, true, myAgent);
                }
                else
                {
                    Arm.ChangeArmState(ArmState.Done, true, myAgent);
                }

            if (DebugConfig.DebugArm) Log.WriteLine("CombatMissionBehavior.Switch is Entering Arm.Processstate");

            Arm.ProcessState(myAgent);

            if (State.CurrentArmState == ArmState.Done)
            {
                Log.WriteLine("Switch: Done: GoToBase");
                Arm.SwitchShipsOnly = false;
                Arm.ChangeArmState(ArmState.Idle, false, myAgent);
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase, true, null);
            }
        }

        private static void TravelerCMBState(DirectAgent myAgent)
        {
            try
            {
                if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
                {
                    if (DebugConfig.DebugTargetWrecks) Log.WriteLine("Salvage.OpenWrecks = false;");
                    Salvage.OpenWrecks = false;
                }

                List<long> destination = ESCache.Instance.DirectEve.Navigation.GetDestinationPath();
                if (destination == null || destination.Count == 0)
                {
                    Log.WriteLine("No destination?");
                    State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Error;
                    return;
                }

                if (destination.Count == 1 && destination.FirstOrDefault() == 0)
                    destination[0] = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;

                if (Traveler.Destination == null || Traveler.Destination.SolarSystemId != destination.LastOrDefault())
                {
                    if (ESCache.Instance.DirectEve.Bookmarks != null && ESCache.Instance.DirectEve.Bookmarks.Any())
                    {
                        IEnumerable<DirectBookmark> bookmarks = ESCache.Instance.DirectEve.Bookmarks.Where(b => b.LocationId == destination.LastOrDefault()).ToList();
                        if (bookmarks.FirstOrDefault() != null && bookmarks.Any())
                        {
                            Traveler.Destination = new BookmarkDestination(bookmarks.OrderBy(b => b.CreatedOn).FirstOrDefault());
                            return;
                        }

                        Log.WriteLine("Destination: [" + ESCache.Instance.DirectEve.Navigation.GetLocation(destination.Last()).Name + "]");
                        long lastSolarSystemInRoute = destination.LastOrDefault();

                        Log.WriteLine("Destination: [" + lastSolarSystemInRoute + "]");
                        Traveler.Destination = new SolarSystemDestination(destination.LastOrDefault());
                        return;
                    }

                    return;
                }

                if (State.CurrentTravelerState == TravelerState.AtDestination)
                {
                    if (State.CurrentCombatMissionCtrlState == ActionControlState.Error)
                    {
                        Log.WriteLine("an error has occurred");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Error, true, myAgent);
                        return;
                    }

                    if (ESCache.Instance.InSpace)
                    {
                        Log.WriteLine("Arrived at destination (in space, Questor stopped)");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Error, true, myAgent);
                        return;
                    }

                    Log.WriteLine("Arrived at destination");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, true, myAgent);
                    return;
                }

                Traveler.ProcessState();
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void UnloadLootCMBState(DirectAgent myAgent)
        {
            try
            {
                if (!ESCache.Instance.InStation)
                    return;

                if (State.CurrentUnloadLootState == UnloadLootState.Idle)
                    if (!ESCache.LootAlreadyUnloaded)
                    {
                        Log.WriteLine("UnloadLoot: Begin");
                        State.CurrentUnloadLootState = UnloadLootState.Begin;
                    }
                    else
                    {
                        Log.WriteLine("UnloadLoot: LootAlreadyUnloaded: Done");
                        State.CurrentUnloadLootState = UnloadLootState.Done;
                    }

                UnloadLoot.ProcessState();

                if (State.CurrentUnloadLootState == UnloadLootState.Done)
                {
                    Log.WriteLine("UnloadLoot: Done: Setting LootAlreadyUnloaded = true");
                    ESCache.LootAlreadyUnloaded = true;
                    State.CurrentUnloadLootState = UnloadLootState.Idle;

                    if (State.CurrentCombatState == CombatState.OutOfAmmo)
                    {
                        Log.WriteLine("State.CurrentCombatState == CombatState.OutOfAmmo");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, true, myAgent);
                        return;
                    }

                    int intMissionNum = 0;
                    if (ESCache.Instance.DirectEve.AgentMissions != null && ESCache.Instance.DirectEve.AgentMissions.Any())
                    {
                        foreach (DirectAgentMission tempMission in ESCache.Instance.DirectEve.AgentMissions)
                        {
                            intMissionNum++;
                            Log.WriteLine("[" + intMissionNum + "] Mission [" + tempMission.Name + "] is in State [" + tempMission.State + "]");
                        }

                        if (ESCache.Instance.DirectEve.AgentMissions.Any(i => i.Agent.IsAgentMissionAccepted))
                        {
                            if (MissionSettings.StorylineMission != null && MissionSettings.StorylineMission.Agent.IsAgentMissionAccepted)
                            {
                                if (MissionSettings.StorylineMission.Agent.Window == null)
                                {
                                    MissionSettings.StorylineMission.Agent.OpenAgentWindow(true);
                                    Log.WriteLine("if (MissionSettings.StorylineMission.Agent.Window == null)");
                                    return;
                                }

                                if (MissionSettings.StorylineMission.Agent.Window != null)
                                {
                                    if (AgentInteraction.PressCompleteButtonIfItExists("UnloadLoot Press CompleteButton", MissionSettings.StorylineMission.Agent)) return;

                                    if (!MissionSettings.StorylineMission.Agent.Window.Objective.Contains("Objectives Complete"))
                                    {
                                        Log.WriteLine("UnloadLoot: We have at least one mission that is currently Accepted");
                                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Arm, true, myAgent);
                                        return;
                                    }
                                }
                            }

                            if (myAgent.Window == null) return;
                            if (!myAgent.Window.Objective.Contains("Objectives Complete"))
                            {
                                Log.WriteLine("UnloadLoot: We have at least one mission that is currently Accepted");
                                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Arm, true, myAgent);
                                return;
                            }
                        }
                    }

                    if (MissionSettings.StorylineMission != null && MissionSettings.StorylineMission.State == MissionState.Accepted)
                    {
                        Log.WriteLine("UnloadLoot: StorylineMission [" + MissionSettings.StorylineMission.Name + "][" + MissionSettings.StorylineMission.State + "]: Arm");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Storyline, true, myAgent);
                        return;
                    }

                    //State.CurrentQuestorState = QuestorState.Start;
                    Log.WriteLine("CharacterMode: [" + Settings.Instance.CharacterMode + "], CombatMissionsBehaviorState: [" + State.CurrentCombatMissionBehaviorState + "]");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Start, true, myAgent);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void WaitingFoBadGuyToGoAway(DirectAgent myAgent)
        {
            if (DateTime.UtcNow.Subtract(Time.Instance.LastLocalWatchAction).TotalMinutes <
                Time.Instance.WaitforBadGuytoGoAway_minutes + ESCache.Instance.RandomNumber(1, 3))
                return;

            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.LocalWatch, true, myAgent);
        }

        private static void WarpOutBookmarkCMBState(DirectAgent myAgent)
        {
            if (ESCache.Instance.InStation &&  DateTime.UtcNow > Time.Instance.LastUndockAction.AddSeconds(10))
            {
                TravelerDestination.Undock();
                return;
            }

            if (!ESCache.Instance.InSpace)
                return;

            if (!string.IsNullOrEmpty(Settings.Instance.UndockBookmarkPrefix))
            {
                IEnumerable<DirectBookmark> warpOutBookmarks = ESCache.Instance.BookmarksByLabel(Settings.Instance.UndockBookmarkPrefix ?? "");
                if (warpOutBookmarks != null && warpOutBookmarks.Any())
                {
                    DirectBookmark warpOutBookmark =
                        warpOutBookmarks.OrderByDescending(b => b.CreatedOn)
                            .FirstOrDefault(b => b.LocationId == ESCache.Instance.DirectEve.Session.SolarSystemId && 100000000 > b.DistanceFromEntity(ESCache.Instance.ClosestStation._directEntity));

                    long solarid = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;

                    if (warpOutBookmark == null)
                    {
                        Log.WriteLine("No Bookmark");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoMission, false, myAgent);
                    }
                    else if (warpOutBookmark.LocationId == solarid)
                    {
                        if (Traveler.Destination == null)
                        {
                            Log.WriteLine("Warp at " + warpOutBookmark.Title);
                            Traveler.Destination = new BookmarkDestination(warpOutBookmark);
                        }

                        Traveler.ProcessState();
                        if (State.CurrentTravelerState == TravelerState.AtDestination)
                        {
                            Log.WriteLine("Safe!");
                            Traveler.Destination = null;
                            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoMission, false, myAgent);
                        }
                    }
                    else
                    {
                        Log.WriteLine("No Bookmark in System");
                        ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoMission, false, myAgent);
                    }

                    return;
                }
            }

            Log.WriteLine("No Bookmark in System");
            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoMission, false, myAgent);
        }

        private static bool WeAreDockedAtTheCorrectStationNowWhat(DirectAgent myAgent)
        {
            if (Settings.Instance.BuyPlex && BuyPlexController.ShouldBuyPlex)
            {
                //BuyPlexController.CheckBuyPlex();
                //ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Idle, false);
                //return;
            }

            if (State.CurrentCombatMissionCtrlState == ActionControlState.Error)
            {
                Log.WriteLine("CMB: if (State.CurrentCombatMissionCtrlState == CombatMissionCtrlState.Error)");
                Traveler.Destination = null;
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Error, true, myAgent);
                return true;
            }

            //
            // we are already docked at the regular (non-storyline!) agents station
            //
            if (State.CurrentCombatState != CombatState.OutOfAmmo && myAgent.Mission != null &&
                myAgent.Mission.State == MissionState.Accepted)
            {
                Traveler.Destination = null;
                if (myAgent.Mission != null && myAgent.Mission.Type.Contains("Encounter") && DateTime.UtcNow > myAgent.Mission.LastMissionCompletionError.AddSeconds(30))
                {
                    //if (MissionSettings.MyMission == MissionSettings.StorylineMission)
                    //{
                    //    Log.WriteLine("GotoBase: We are in the storyline agents station: MissionState is Accepted - changing state to: CompleteMission");
                    //    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.Storyline, false);
                    //    return true;
                    //}

                    Log.WriteLine("GotoBase: We are in [" + myAgent.Name + "]'s station: [" + myAgent.Mission.Name + "] MissionState is Accepted - changing state to: CompleteMission");
                    ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.CompleteMission, false, myAgent);
                    return true;
                }

                Log.WriteLine("GotoBase: We are in [" + myAgent.Name + "]'s station: [" + myAgent.Mission.Name + "] MissionState is Accepted - We tried to Complete the mission and it failed. Continuing");
                ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.UnloadLoot, false, myAgent);
                return true;
            }

            Traveler.Destination = null;
            Log.WriteLine("GotoBase: We are in [" + myAgent.Name + "]'s station: changing state to: UnloadLoot");
            ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.UnloadLoot, false, myAgent);
            return true;
        }

        #endregion Methods
    }
}