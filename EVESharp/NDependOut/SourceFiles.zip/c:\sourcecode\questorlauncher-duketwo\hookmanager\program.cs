﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 29.12.2013
 * Time: 21:20
 *
 * ---------------------------------------
 */

using EasyHook;
using HookManager.Win32Hooks;
using SharedComponents.EVE;
using SharedComponents.IPC;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HookManager
{
    /// <summary>
    ///     Class with program entry point.
    /// </summary>
    internal sealed class Program
    {
        #region Methods

        private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            HandleException(e.Exception);
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            HandleException((Exception) e.ExceptionObject);
        }

        private static void HandleException(Exception e)
        {
            Console.WriteLine(e);
            Debug.WriteLine(e);
        }

        /// <summary>
        ///     Program entry point.
        /// </summary>
        [STAThread]
        private static void Main(string[] args)
        {
            try
            {
                // args are always length == 2; [proxyId || charName, pipeName]
                if (args.Length != 2)
                {
                    Environment.Exit(0);
                    Environment.FailFast("");
                }

                // parse args, setup wcf pipe name

                Process cp = Process.GetCurrentProcess();
                string cpName = cp.ProcessName.ToLower();
                int cpId = cp.Id;
                HookManagerImpl.Instance.CharName = cpName.ToLower().Equals("firefox") ? string.Empty : args[0];
                HookManagerImpl.Instance.PipeName = args[1];

                TaskScheduler.UnobservedTaskException += TaskSchedulerOnUnobservedTaskException;
                AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
                Application.ThreadException += Application_ThreadException;
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                int proxyId = cpName.Equals("firefox") ? Convert.ToInt32(args[0]) : 0;
                WCFClient.Instance.pipeName = HookManagerImpl.Instance.PipeName;
                WCFClient.Instance.GetPipeProxy.Ping();
                WCFClient.Instance.GetPipeProxy.RemoteLog(string.Format("Injected in process [{0}] pid [{1}]", cpName,
                    cpId));

                switch (cpName)
                {
                    case "firefox":
                    {
                        Proxy p = WCFClient.Instance.GetPipeProxy.GetProxy(proxyId);
                        WCFClient.Instance.GetPipeProxy.RemoteLog($"Proxy retrieved. Description [{p.Description}]");
                        HookManagerImpl.Instance.InitFirefoxHooks(p);
                        RemoteHooking.WakeUpProcess();
                    }
                        break;

                    case "exefile":
                    case "putty":
                    case "notepad":
                    default:
                        while (HookManagerImpl.Instance.EveAccount == null)
                        {
                            WCFClient.Instance.GetPipeProxy.RemoteLog("RemoteProcess: if (HookManagerImpl.Instance.EveAccount == null)");
                            //RemoteHooking.WakeUpProcess();
                            Environment.Exit(0);
                            Environment.FailFast("");
                            return;
                        }

                        try
                        {
                            Proceed();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("HM Exception:" + ex);
                        }

                        break;
                }

                MainForm form = new MainForm();
                Application.Run(form);

                while (true)
                {
                    if (HookManagerImpl.Instance.EveAccount.RestartOfQuestorNeeded)
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(HookManagerImpl.Instance.EveAccount.CharacterName, nameof(EveAccount.RestartOfQuestorNeeded), false);
                        //restart questor here
                        MainForm.RestartQuestor(null);
                    }

                    Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("HM Exception:" + ex);
            }
        }

        private static void Proceed()
        {
            try
            {
                WCFClient.Instance.GetPipeProxy.RemoteLog(string.Format("EveAccount [{0}] successfully retrieved via WCF.",
                    HookManagerImpl.Instance.EveAccount.AccountName));

                WCFClient.Instance.GetPipeProxy.RemoteLog("RemoteProcess: InitEVEHooks");
                HookManagerImpl.Instance.InitEVEHooks();
                WCFClient.Instance.GetPipeProxy.RemoteLog("RemoteProcess: Waking up the launched process.");
                RemoteHooking.WakeUpProcess();
                WCFClient.Instance.GetPipeProxy.RemoteLog("RemoteProcess: Waiting for eve.");
                HookManagerImpl.Instance.WaitForEVE();
                WCFClient.Instance.GetPipeProxy.RemoteLog("RemoteProcess: Lauching app domain.");
                HookManagerImpl.Instance.LaunchAppDomain();
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(HookManagerImpl.Instance.EveAccount.CharacterName, nameof(EveAccount.DoneLaunchingEveInstance), true);
            }
            catch (Exception ex)
            {
                Console.WriteLine("HM Exception:" + ex);
            }
        }

        private static void TaskSchedulerOnUnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
        {
            HandleException(e.Exception);
        }

        #endregion Methods
    }
}