﻿// ------------------------------------------------------------------------------
//   <copyright from='2010' to='2015' company='THEHACKERWITHIN.COM'>
//     Copyright (c) TheHackerWithin.COM. All Rights Reserved.
//
//     Please look in the accompanying license.htm file for the license that
//     applies to this source code. (a copy can also be found at:
//     http://www.thehackerwithin.com/license.htm)
//   </copyright>
// -------------------------------------------------------------------------------

using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using System;

namespace EVESharpCore.Questor.Traveller
{
    public class BookmarkDestination2 : TravelerDestination
    {
        #region Fields

        private DateTime _nextAction;

        #endregion Fields

        #region Properties

        public long BookmarkId { get; set; }

        #endregion Properties

        #region Constructors

        public BookmarkDestination2(DirectBookmark bookmark)
        {
            if (bookmark == null)
            {
                Log.WriteLine("Invalid bookmark destination!");

                SolarSystemId = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;
                BookmarkId = -1;
                return;
            }

            Log.WriteLine("Destination set to bookmark [" + bookmark.Title + "]");
            DirectLocation location = GetBookmarkLocation(bookmark);
            if (location == null)
            {
                Log.WriteLine("Invalid bookmark destination!");

                SolarSystemId = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;
                BookmarkId = -1;
                return;
            }

            BookmarkId = bookmark.BookmarkId ?? -1;
            SolarSystemId = location.SolarSystemId ?? ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;
        }

        public BookmarkDestination2(long bookmarkId)
            : this(ESCache.Instance.BookmarkById(bookmarkId))
        {
        }

        #endregion Constructors

        #region Methods

        public override bool PerformFinalDestinationTask()
        {
            DirectBookmark bookmark = ESCache.Instance.BookmarkById(BookmarkId);
            return PerformFinalDestinationTask2(bookmark, 150000, ref _nextAction);
        }

        internal static bool PerformFinalDestinationTask2(DirectBookmark bookmark, int warpDistance, ref DateTime nextAction)
        {
            // The bookmark no longer exists, assume we are there
            if (bookmark == null)
                return true;

            DirectLocation location = GetBookmarkLocation(bookmark);
            if (ESCache.Instance.InStation)
            {
                // We have arrived
                if (bookmark.ItemId.HasValue && (bookmark.ItemId == ESCache.Instance.DirectEve.Session.StationId ||
                                                 bookmark.ItemId == ESCache.Instance.DirectEve.Session.Structureid))
                    return true;

                // We are apparently in a station that is incorrect
                Log.WriteLine("We're docked in the wrong station, undocking");
                if (Undock())
                {
                    Time.Instance.NextActivateModules = DateTime.UtcNow.AddMilliseconds(ESCache.Instance.RandomNumber(4000, 6000));
                    nextAction = DateTime.UtcNow.AddSeconds(7);
                }

                return false;
            }

            // Is this a station bookmark?
            if (bookmark.Entity != null && (bookmark.Entity.GroupId == (int)Group.Station || bookmark.Entity.GroupId == (int)Group.Citadel))
            {
                bool arrived = StationDestination2.PerformFinalDestinationTask(bookmark.Entity.Id, bookmark.Entity.Name, ref nextAction);
                if (arrived)
                    Log.WriteLine("Arrived at bookmark [" + bookmark.Title + "]");
                return arrived;
            }

            // Its not a station bookmark, make sure we are in space
            if (ESCache.Instance.InStation)
            {
                // We are in a station, but not the correct station!
                if (nextAction < DateTime.UtcNow)
                {
                    Log.WriteLine("We're docked but our destination is in space, undocking");
                    if (Undock())
                    {
                        Time.Instance.NextActivateModules = DateTime.UtcNow.AddMilliseconds(ESCache.Instance.RandomNumber(4000, 6000));
                        nextAction = DateTime.UtcNow.AddSeconds(7);
                    }
                }

                // We are not there yet
                return false;
            }

            if (!ESCache.Instance.DirectEve.Session.IsInSpace)
                return false;

            UndockAttempts = 0;

            // This bookmark has no x / y / z, assume we are there.
            if (bookmark.X == -1 || bookmark.Y == -1 || bookmark.Z == -1 || bookmark.X == null || bookmark.Y == null || bookmark.Z == null)
            {
                Log.WriteLine("Arrived at the bookmark [" + bookmark.Title + "][No XYZ]");
                return true;
            }

            double distance = ESCache.Instance.DistanceFromMe(bookmark.X ?? 0, bookmark.Y ?? 0, bookmark.Z ?? 0);
            if (distance < warpDistance)
            {
                Log.WriteLine("Arrived at the bookmark [" + bookmark.Title + "]");
                return true;
            }

            if (nextAction > DateTime.UtcNow)
                return false;

            if (ESCache.Instance.GateInGrid() && distance / 1000 < (int)Distances.MaxPocketsDistanceKm)
                Log.WriteLine("Bookmark [" + bookmark.Title + "][" +
                              Math.Round(distance / 1000 / 149598000, 2) + "] AU away. Which is [" +
                              Math.Round(distance / 1000, 2) + "].");

            if (bookmark.WarpTo())
            {
                Log.WriteLine("Warping to bookmark [" + bookmark.Title + "][" + Math.Round(distance / 1000 / 149598000, 2) +
                              "] AU away. Which is [" + Math.Round(distance / 1000, 2) + "]");
                Time.Instance.NextTravelerAction = DateTime.UtcNow.AddSeconds(7);
                nextAction = DateTime.UtcNow.AddSeconds(30);
                return false;
            }

            return false;
        }

        private static DirectLocation GetBookmarkLocation(DirectBookmark bookmark)
        {
            DirectLocation location = ESCache.Instance.DirectEve.Navigation.GetLocation(bookmark.ItemId ?? -1);
            if (!location.IsValid)
                location = ESCache.Instance.DirectEve.Navigation.GetLocation(bookmark.LocationId ?? -1);
            if (!location.IsValid)
                return null;

            return location;
        }

        #endregion Methods
    }
}