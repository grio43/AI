﻿namespace SharedComponents.FastPriorityQueue
{
    public class StablePriorityQueueNode : FastPriorityQueueNode
    {
        #region Properties

        /// <summary>
        ///     Represents the order the node was inserted in
        /// </summary>
        public long InsertionIndex { get; internal set; }

        #endregion Properties
    }
}