extern alias SC;

using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.States;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Xml.Linq;

namespace EVESharpCore.Questor.BackgroundTasks
{
    public static class SkillQueue
    {
        #region Constructors

        static SkillQueue()
        {
            Interlocked.Increment(ref SkillQueueInstances);
            State.CurrentSkillQueueState = SkillQueueState.Begin;
        }

        #endregion Constructors

        #region Fields

        public static int SkillQueueIterations = 0;

        //public static bool skillWasInjected = false;
        private static readonly Dictionary<char, int> RomanDictionary = new Dictionary<char, int>

        {
            {'I', 1},
            {'V', 5}
        };

        private static readonly int SkillQueueInstances;
        private static DateTime _lastPulse = DateTime.UtcNow;
        private static List<string> _myRawSkillPlan = new List<string>();

        //private static int _mySkillPlanImportCount = 1;

        //public static int InjectSkillBookAttempts;
        //private static DateTime _nextSkillTrainingAction = DateTime.MinValue;
        private static DateTime _nextRetrieveSkillQueueInfoAction = DateTime.MinValue;

        //public static bool buyingSkill = false;
        //public static int buyingIterator = 0;
        //public static int buyingSkillTypeID = 0;
        //public static string buyingSkillTypeName = string.Empty;
        //public static bool doneWithAllPlannedSKills = false;
        //public static int attemptsToDoSomethingWithNonInjectedSkills = 0;
        private static XDocument _xmlSkillPreReqs;

        private static Dictionary<DirectSkill, int> mySkillPlanAsDirectSkill = new Dictionary<DirectSkill, int>();
        private static Dictionary<string, int> mySkillPlanAsText = new Dictionary<string, int>();

        #endregion Fields

        #region Properties

        //private static DateTime _nextRetrieveCharactersheetInfoAction = DateTime.MinValue;
        private static List<DirectSkill> MyCharacterSheetSkills { get; set; }

        private static List<DirectSkill> MySkillQueue { get; set; }

        #endregion Properties

        #region Methods

        public static bool AddPlannedSkillsToSkillQueue()
        {
            if (!ESCache.Instance.InStation && !ESCache.Instance.InSpace)
                return false;

            if (!ESCache.Instance.DirectEve.Skills.AreMySkillsReady)
            {
                Log.WriteLine("SkillQueueController: RefreshMySkills");
                Time.Instance.LastRefreshMySkills = DateTime.UtcNow;
                ESCache.Instance.DirectEve.Skills.RefreshMySkills();
                return false;
            }

            if (!ESCache.Instance.DirectEve.Skills.IsReady)
                return false;

            if (ESCache.Instance.DirectEve.Skills.MySkillQueue.Any() &&
                ESCache.Instance.DirectEve.Skills.SkillQueueLength >= ESCache.Instance.DirectEve.Skills.MaxQueueLength)
            {
                if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillQueueController: We have no room in the skill queue. SkillQueueLength [" + ESCache.Instance.DirectEve.Skills.SkillQueueLength.TotalHours + "] hours worth of training left before queue is empty");
                return false;
            }

            if (ESCache.Instance.DirectEve.Skills.MySkillQueue.Any() &&
                ESCache.Instance.DirectEve.Skills.SkillQueueLength > TimeSpan.FromHours(18))
            {
                if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillQueueController: We have more than 18 hours of skills in the skill queue. SkillQueueLength [" + ESCache.Instance.DirectEve.Skills.SkillQueueLength.TotalHours + "] hours worth of training left before queue is empty");
                return false;
            }

            if (!ESCache.Instance.DirectEve.Skills.MySkillQueue.Any() || TimeSpan.FromHours(18) > ESCache.Instance.DirectEve.Skills.SkillQueueLength)
            {
                ImportRawSkillPlan();
                ReadySkillPlanAsText();
                //ReadySkillPlanAsDirectSkill();

                int skillNum = 0;
                foreach (KeyValuePair<string, int> skillInSkillPlan in mySkillPlanAsText)
                {
                    skillNum++;
                    Log.WriteLine("[" + skillNum + "] SkillPlan Skill [" + skillInSkillPlan.Key + "] Level [" + skillInSkillPlan.Value + "]");
                    foreach (DirectSkill skillInMyHead in ESCache.Instance.DirectEve.Skills.MySkills)
                        if (skillInMyHead.TypeName == skillInSkillPlan.Key)
                            if (skillInMyHead.Level < skillInMyHead.MaxCloneSkillLevel)
                            {
                                Log.WriteLine("[" + skillInMyHead.TypeName + "][" + skillInMyHead.Level + "] is less than MaxCloneSkillLevel [" + skillInMyHead.MaxCloneSkillLevel + "]");
                                if (skillInMyHead.Level < skillInSkillPlan.Value)
                                {
                                    Log.WriteLine("[" + skillInMyHead.TypeName + "][" + skillInMyHead.Level + "] is less than skillInSkillPlan.Level [" + skillInSkillPlan.Value + "]");
                                    if (ESCache.Instance.DirectEve.Skills.MySkillQueue.All(i => i.TypeName != skillInSkillPlan.Key))
                                    {
                                        Log.WriteLine("[" + skillInMyHead.TypeName + "][" + (skillInMyHead.Level + 1) + "] Add Skill to end of queue.");
                                        ESCache.Instance.DirectEve.Skills.AddSkillToEndOfQueue(skillInMyHead.TypeId);
                                        Time.Instance.LastSkillQueueModification = DateTime.UtcNow;
                                        Time.Instance.LastSkillQueueCheck = DateTime.UtcNow;
                                    }
                                }
                            }
                }

                Time.Instance.LastSkillQueueCheck = DateTime.UtcNow;
                return true;
            }

            Time.Instance.LastSkillQueueCheck = DateTime.UtcNow;
            return true;
        }

        public static bool ChangeSkillQueueState(SkillQueueState state)
        {
            try
            {
                if (State.CurrentSkillQueueState != state)
                {
                    //ClearDataBetweenStates();
                    Log.WriteLine("New SkillQueueState [" + state + "]");
                    State.CurrentSkillQueueState = state;
                    return true;
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        public static void ClearSystemSpecificSettings()
        {
            try
            {
                _myRawSkillPlan.Clear();
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static bool DoWeHaveTheRightPrerequisites(int skillID)
        {
            try
            {
                if (_xmlSkillPreReqs == null)
                {
                    _xmlSkillPreReqs = XDocument.Load(Settings.Instance.Path + "\\Skill_Prerequisites.xml");
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("Skill_Prerequisites.xml Loaded.");
                }
            }
            catch (Exception)
            {
                if (DebugConfig.DebugSkillQueue) Log.WriteLine("Skill_Prerequisites.xml exception -- does the file exist?");
                return false;
            }

            foreach (XElement skills in _xmlSkillPreReqs.Descendants("skill"))
                if (skillID.ToString().Equals(skills.Attribute("id").Value))
                {
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("skillID.ToString().Equals(skills.Attribute(\"id\").Value == TRUE");
                    foreach (XElement preRegs in skills.Descendants("preqskill"))
                        if (MyCharacterSheetSkills.Any(i => i.TypeId.ToString().Equals(preRegs.Attribute("id").Value)))
                        {
                            if (DebugConfig.DebugSkillQueue) Log.WriteLine("We have this Prerequisite: " + preRegs.Attribute("id").Value);
                            if (MyCharacterSheetSkills.Any(i => i.TypeId.ToString().Equals(preRegs.Attribute("id").Value) && i.Level < Convert.ToInt32(preRegs.Value)))
                            {
                                if (DebugConfig.DebugSkillQueue) Log.WriteLine("We don't meet the required level on this skill: " + preRegs.Attribute("id").Value);
                                return false;
                            }

                            if (DebugConfig.DebugSkillQueue) Log.WriteLine("We meet the required skill level on this skill: " + preRegs.Attribute("id").Value);
                        }
                        else
                        {
                            if (DebugConfig.DebugSkillQueue) Log.WriteLine("We don't have this prerequisite: " + preRegs.Attribute("id").Value);
                        }
                    // this is also good for skills with no pre requirements
                    return true;
                }
            return false;
            // not in list which is unlikely
        }

        public static bool DoWeHaveThisSkillAlreadyInOurItemHangar(int skillID)
        {
            if (!ESCache.Instance.InStation) return false;
            IEnumerable<DirectItem> items = ESCache.Instance.ItemHangar.Items.Where(k => k.TypeId == skillID).ToList();
            if (items.Any())
            {
                if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.DoWeHaveThisSkillAlreadyInOurItemHangar: We already have this skill in our hangar " + skillID);
                return true;
            }

            if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.DoWeHaveThisSkillAlreadyInOurItemHangar: We don't have this skill in our hangar " + skillID);
            return false;
        }

        public static bool ImportRawSkillPlan()
        {
            if (_myRawSkillPlan == null || !_myRawSkillPlan.Any())
            {
                //_mySkillPlanImportCount = 1;
                if (_myRawSkillPlan == null)
                    _myRawSkillPlan = new List<string>();

                _myRawSkillPlan.Clear();

                try
                {
                    string skillPlanFile = Path.Combine(Settings.Instance.Path, "QuestorSettings\\skillPlan-", ESCache.Instance.DirectEve.Me.Name, ".txt").ToLower();

                    if (!File.Exists(skillPlanFile))
                    {
                        string genericSkillPlanFile = Path.Combine(Settings.Instance.Path, "QuestorSettings\\skillPlan.txt").ToLower();
                        Log.WriteLine("importskillplan: Missing Character Specific skill plan file [" + skillPlanFile + "], trying generic file [" + genericSkillPlanFile + "]");
                        skillPlanFile = genericSkillPlanFile;
                    }

                    if (!File.Exists(skillPlanFile))
                    {
                        Log.WriteLine("importskillplan: Missing Generic skill plan file [" + skillPlanFile + "]");
                        return false;
                    }

                    Log.WriteLine("importskillplan: Loading SkillPlan from [" + skillPlanFile + "]");

                    // Use using StreamReader for disposing.
                    using (StreamReader readTextFile = new StreamReader(skillPlanFile))
                    {
                        string line;
                        while ((line = readTextFile.ReadLine()) != null)
                            _myRawSkillPlan.Add(line);
                    }

                    return true;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("importskillplan: Exception was: [" + exception + "]");
                    return false;
                }
            }

            return true;
        }

        public static bool InjectSkillBook(int skillID)
        {
            try
            {
                IEnumerable<DirectItem> items = ESCache.Instance.ItemHangar.Items.Where(k => k.TypeId == skillID).ToList();
                if (DoWeHaveThisSkillAlreadyInOurItemHangar(skillID))
                {
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillBook [" + skillID + "] found in ItemHangar");
                    DirectItem SkillBookToInject = items.FirstOrDefault(s => s.TypeId == skillID);
                    if (SkillBookToInject != null)
                    {
                        if (MyCharacterSheetSkills != null && !MyCharacterSheetSkills.Any(i => i.TypeName == SkillBookToInject.TypeName || i.GivenName == SkillBookToInject.TypeName))
                        {
                            if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillBook:  GivenName [" + SkillBookToInject.GivenName + "] TypeName [" + SkillBookToInject.TypeName + "] is being injected");
                            if (DoWeHaveTheRightPrerequisites(SkillBookToInject.TypeId))
                            {
                                SkillBookToInject.InjectSkill();
                                State.CurrentSkillQueueState = SkillQueueState.ReadCharacterSheetSkills;
                                return true;
                            }

                            if (DebugConfig.DebugSkillQueue) Log.WriteLine("Skillbook: We don't have the right Prerequisites for " + SkillBookToInject.GivenName);
                        }

                        if (MyCharacterSheetSkills != null && MyCharacterSheetSkills.Any(i => i.TypeName == SkillBookToInject.TypeName))
                        {
                            if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillBook:  TypeName [" + SkillBookToInject.TypeName + "] is already injected, why are we trying to do so again? aborting injection attempt ");
                            return true;
                        }
                    }

                    return false;
                }
                Log.WriteLine("We don't have this skill in our hangar");
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        public static void LoadSettings(XElement characterSettingsXml, XElement commonSettingsXml)
        {
            try
            {
                Log.WriteLine("LoadSettings: SkillQueue");
                //_courierContractHaulingProvider = (string)characterSettingsXml.Element("courierContractHaulingProvider") ??
                //                                  (string)commonSettingsXml.Element("courierContractHaulingProvider") ?? null;
                //_courierContractDestinationStationID = (string)characterSettingsXml.Element("courierContractDestinationStationID") ??
                //                                       (string)commonSettingsXml.Element("courierContractDestinationStationID") ?? null;
                //_courierContractMinimumDaysBetweenContracts = (int?)characterSettingsXml.Element("courierContractMinimumDaysBetweenContracts") ??
                //                                              (int?)commonSettingsXml.Element("courierContractMinimumDaysBetweenContracts") ?? 6;
                //_courierContractRewardToOffer = (double?)characterSettingsXml.Element("courierContractRewardToOffer") ??
                //                                (double?)commonSettingsXml.Element("courierContractRewardToOffer") ?? 6;
                //
                // Item types to put into a courier contract
                //

                /**
                _listOfItemsToCourierContract = new List<InventoryItem>();
                XElement xmlListOfItemsToCourierContract = characterSettingsXml.Element("itemsToCourierContract") ?? commonSettingsXml.Element("itemsToBuyFromLpStore");
                if (xmlListOfItemsToCourierContract != null)
                {
                    int itemNum = 0;
                    foreach (XElement item in xmlListOfItemsToCourierContract.Elements("itemToCourierContract"))
                    {
                        itemNum++;
                        InventoryItem itemToCourierContract = new InventoryItem(item);
                        Logging.Log.WriteLine("ListOfItemsToCourierContract: [" + itemNum + "][" + itemToCourierContract.Name + "][" + itemToCourierContract.TypeId + "][" + itemToCourierContract.Quantity + "]");
                        _listOfItemsToCourierContract.Add(itemToCourierContract);
                    }
                }
                **/
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static void ProcessState()
        {
            if (!ESCache.Instance.DirectEve.Session.IsReady)
                return;

            if (DateTime.UtcNow.Subtract(_lastPulse).TotalMilliseconds < 3500)
                return;
            _lastPulse = DateTime.UtcNow;

            if (DateTime.UtcNow < Time.Instance.LastSkillQueueModification.AddMilliseconds(ESCache.Instance.RandomNumber(6000, 15000)))
            {
                if (DebugConfig.DebugSkillQueue)
                    Log.WriteLine("DebugSkillQueue: if (DateTime.UtcNow < Time.Instance.LastSkillQueueModification.AddMilliseconds(QCache.Instance.RandomNumber(6000, 15000)))");
                return;
            }

            if (DebugConfig.DebugSkillQueue)
                Log.WriteLine("DebugSkillQueue: SkillQueue ProcessState");

            if (!ESCache.Instance.EveAccount.AutoSkillTraining)
            {
                if (DebugConfig.DebugSkillQueue)
                    Log.WriteLine("DebugSkillQueue: AutoSkillTraining [" + ESCache.Instance.EveAccount.AutoSkillTraining + "]");
               return;
            }

            if (!ESCache.Instance.InStation && !ESCache.Instance.InSpace)
            {
                if (DebugConfig.DebugSkillQueue)
                    Log.WriteLine("DebugSkillQueue: !QCache.Instance.InStation && !QCache.Instance.InSpace");
                return;
            }

            if (Time.Instance.QuestorStarted_DateTime.AddSeconds(6) > DateTime.UtcNow)
            {
                if (DebugConfig.DebugSkillQueue)
                    Log.WriteLine("DebugSkillQueue: if (Time.Instance.QuestorStarted_DateTime.AddSeconds(6) > DateTime.UtcNow)");
                return;
            }

            if (ESCache.Instance.InStation && Time.Instance.LastDockAction.AddSeconds(10) > DateTime.UtcNow)
            {
                if (DebugConfig.DebugSkillQueue)
                    Log.WriteLine("DebugSkillQueue: LastDockAction [" + Time.Instance.LastDockAction.ToShortTimeString() + "] waiting");
                return;
            }

            //if (Time.Instance.LastSkillQueueCheck.AddSeconds(QCache.Instance.RandomNumber(60 * 10, 60 * 15)) > DateTime.UtcNow)
            //{
            //    if (DebugConfig.DebugSkillQueue) Log.WriteLine("DebugSkillQueue: if (Time.Instance.LastSkillQueueCheck.AddSeconds(QCache.Instance.RandomNumber(60 * 10, 60 * 15))[" + Time.Instance.LastSkillQueueCheck.AddSeconds(QCache.Instance.RandomNumber(60 * 10, 60 * 15)) + "] > DateTime.UtcNow)");
            //    return;
            //}

            switch (State.CurrentSkillQueueState)
            {
                case SkillQueueState.Idle:
                    if (DateTime.UtcNow > Time.Instance.LastSkillQueueCheck.AddMinutes(45))
                        ChangeSkillQueueState(SkillQueueState.Begin);

                    break;

                case SkillQueueState.Begin:
                    ChangeSkillQueueState(SkillQueueState.LoadPlan);
                    break;

                case SkillQueueState.LoadPlan:
                    if (!ImportRawSkillPlan()) return;
                    ChangeSkillQueueState(SkillQueueState.CheckTrainingQueue);
                    break;

                case SkillQueueState.CheckTrainingQueue:
                    if (!AddPlannedSkillsToSkillQueue()) return;
                    ChangeSkillQueueState(SkillQueueState.Idle);
                    break;
            }
        }

        public static void ReadySkillPlanAsDirectSkill()
        {
            if (mySkillPlanAsDirectSkill == null || !mySkillPlanAsDirectSkill.Any())
                try
                {
                    if (mySkillPlanAsDirectSkill == null)
                        mySkillPlanAsDirectSkill = new Dictionary<DirectSkill, int>();

                    mySkillPlanAsDirectSkill.Clear();
                    //int i = 1;

                    foreach (KeyValuePair<string, int> plannedSkillAsText in mySkillPlanAsText)
                        foreach (DirectSkill SkillInMyHead in ESCache.Instance.DirectEve.Skills.MySkills)
                            if (plannedSkillAsText.Key == SkillInMyHead.TypeName)
                            {
                                //mySkillPlanAsDirectSkill.
                            }
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                }
        }

        public static void ReadySkillPlanAsText()
        {
            if (mySkillPlanAsText == null || !mySkillPlanAsText.Any())
                try
                {
                    if (mySkillPlanAsText == null)
                        mySkillPlanAsText = new Dictionary<string, int>();

                    mySkillPlanAsText.Clear();
                    int i = 1;
                    foreach (string importedSkill in _myRawSkillPlan)
                    {
                        string romanNumeral = ParseRomanNumeral(importedSkill);
                        string skillName = importedSkill.Substring(0, importedSkill.Length - CountNonSpaceChars(romanNumeral));
                        skillName = skillName.Trim();
                        int levelPlanned = Decode(romanNumeral);
                        if (mySkillPlanAsText.ContainsKey(skillName))
                        {
                            if (mySkillPlanAsText.FirstOrDefault(x => x.Key == skillName).Value < levelPlanned)
                            {
                                mySkillPlanAsText.Remove(skillName);
                                mySkillPlanAsText.Add(skillName, levelPlanned);
                            }
                            continue;
                        }

                        mySkillPlanAsText.Add(skillName, levelPlanned);
                        if (DebugConfig.DebugSkillQueue) Log.WriteLine("Skills.readySkillPlan [" + i + "]" + importedSkill + "] LevelPlanned[" + levelPlanned + "][" + romanNumeral + "]");
                    }
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                }
        }

        public static bool RetrieveSkillQueueInfo()
        {
            try
            {
                if (DateTime.UtcNow > _nextRetrieveSkillQueueInfoAction)
                {
                    MySkillQueue = ESCache.Instance.DirectEve.Skills.MySkillQueue;
                    _nextRetrieveSkillQueueInfoAction = DateTime.UtcNow.AddSeconds(10);
                    if (MySkillQueue != null)
                    {
                        if (DebugConfig.DebugSkillQueue) Log.WriteLine("MySkillQueue is not null, continue");
                        return true;
                    }

                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("RetrieveSkillQueueInfo: MySkillQueue is null, how? retry in 10 sec");
                    return true;
                }

                if (DebugConfig.DebugSkillQueue) Log.WriteLine("Waiting...");
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("SkillPlan: Exception [" + exception + "]");
                return false;
            }
        }

        /**
        public static bool BuySkill(int skillID, string typeName)
        {
            try
            {
                if (!QCache.Instance.InStation) return false;
                if (DateTime.UtcNow < _nextSkillTrainingAction)
                {
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.buySkill: Next Skill Training Action is set to continue in [" + Math.Round(_nextSkillTrainingAction.Subtract(DateTime.UtcNow).TotalSeconds, 0) + "] seconds");
                    return false;
                }

                if (buyingSkillTypeID != 0)
                {
                    buyingIterator++;

                    if (buyingIterator > 20)
                    {
                        Log.WriteLine("buySkill: buying iterator < 20 with SkillID" + skillID);
                        buyingSkillTypeID = 0;
                        buyingSkillTypeName = string.Empty;
                        buyingIterator = 0;
                        return true;
                    }
                    // only buy if we do not have it already in our itemhangar
                    if (DoWeHaveThisSkillAlreadyInOurItemHangar(skillID))
                    {
                        Log.WriteLine("buySkill: We already purchased this skill" + skillID);
                        buyingSkillTypeID = 0;
                        buyingSkillTypeName = string.Empty;
                        buyingIterator = 0;
                        return true;
                    }

                    DirectMarketWindow marketWindow = QCache.Instance.DirectEve.Windows.OfType<DirectMarketWindow>().FirstOrDefault();
                    if (true)
                    {
                        if (marketWindow == null)
                        {
                            _nextSkillTrainingAction = DateTime.UtcNow.AddSeconds(10);
                            Log.WriteLine("Opening market window");
                            QCache.Instance.DirectEve.ExecuteCommand(DirectCmd.OpenMarket);
                            Statistics.LogWindowActionToWindowLog("MarketWindow", "MarketWindow Opened");
                            return false;
                        }

                        if (!marketWindow.IsReady)
                        {
                            _nextSkillTrainingAction = DateTime.UtcNow.AddSeconds(3);
                            return false;
                        }

                        if (marketWindow.DetailTypeId != skillID)
                        {
                            // No, load the right order
                            marketWindow.LoadTypeId(skillID);
                            Log.WriteLine("Loading market with right typeid ");
                            _nextSkillTrainingAction = DateTime.UtcNow.AddSeconds(6);
                            return false;
                        }

                        // Get the median sell price
                        DirectInvType type;
                        type = QCache.Instance.DirectEve.GetInvType(skillID);
                        double? maxPrice = 0;
                        if (type != null)
                        {
                            //maxPrice = type.AveragePrice * 10;
                            Log.WriteLine("maxPrice " + maxPrice.ToString());
                            // Do we have orders?
                            //IEnumerable<DirectOrder> orders = marketWindow.SellOrders.Where(o => o.StationId == Cache.Instance.DirectEve.Session.StationId && o.Price < maxPrice).ToList();
                            IEnumerable<DirectOrder> orders = marketWindow.SellOrders.Where(o => o.StationId == QCache.Instance.DirectEve.Session.StationId).ToList();
                            if (orders.Any())
                            {
                                DirectOrder order = orders.OrderBy(o => o.Price).FirstOrDefault();
                                if (order != null)
                                {
                                    //
                                    // do we have the isk to perform this transaction? - not as silly as you think, some skills are expensive!
                                    //
                                    if (order.Price < QCache.Instance.MyWalletBalance)
                                    {
                                        order.Buy(1, DirectOrderRange.Station);
                                        Log.WriteLine("Buying skill with typeid & waiting 20 seconds ( to ensure we do not buy the skillbook twice ) " + skillID);
                                        buyingSkillTypeID = 0;
                                        buyingSkillTypeName = string.Empty;
                                        buyingIterator = 0;
                                        // Wait for the order to go through
                                        _nextRetrieveCharactersheetInfoAction = DateTime.MinValue;
                                        // ensure we get the character sheet update
                                        _nextSkillTrainingAction = DateTime.UtcNow.AddSeconds(20);
                                        return true;
                                    }

                                    Log.WriteLine("We do not have enough isk to purchase [" + typeName + "] at [" + Math.Round(order.Price, 0) + "] isk. We have [" + Math.Round(QCache.Instance.MyWalletBalance, 0) + "] isk");
                                    buyingSkillTypeID = 0;
                                    buyingSkillTypeName = string.Empty;
                                    buyingIterator = 0;
                                    return false;
                                }

                                Log.WriteLine("order was null.");
                                buyingSkillTypeID = 0;
                                buyingSkillTypeName = string.Empty;
                                buyingIterator = 0;
                                return false;
                            }

                            Log.WriteLine("No orders for the skill could be found with a price less than 10 * the AveragePrice");
                            buyingSkillTypeID = 0;
                            buyingSkillTypeName = string.Empty;
                            buyingIterator = 0;
                            return false;
                        }

                        Log.WriteLine("no skill could be found with a typeid of [" + buyingSkillTypeID + "]");
                        buyingSkillTypeID = 0;
                        buyingSkillTypeName = string.Empty;
                        buyingIterator = 0;
                        return false;
                    }
                }

                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }
        **/

        public static int SkillLevel(string SkillToLookFor)
        {
            try
            {
                if (MyCharacterSheetSkills == null || !MyCharacterSheetSkills.Any())
                {
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillLevel: if (!MyCharacterSheetSkills.Any())");

                    MyCharacterSheetSkills = ESCache.Instance.DirectEve.Skills.MySkills;
                }

                foreach (DirectSkill knownskill in MyCharacterSheetSkills)
                    if (knownskill.TypeName == SkillToLookFor)
                        return knownskill.Level;

                if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillLevel: We do not have [" + SkillToLookFor + "] yet");
                return 0;
            }
            catch (Exception exception)
            {
                Log.WriteLine("SkillLevel: Exception [" + exception + "]");
                return 0;
            }
        }

        private static int CountNonSpaceChars(string value)
        {
            return value.Count(c => !char.IsWhiteSpace(c));
        }

        /**
        public static bool CheckTrainingQueue(string module)
        {
            try
            {
                if (DateTime.UtcNow < _nextSkillTrainingAction)
                {
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.CheckTrainingQueue: Next Skill Training Action is set to continue in [" + Math.Round(_nextSkillTrainingAction.Subtract(DateTime.UtcNow).TotalSeconds, 0) + "] seconds");
                    return false;
                }

                if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.CheckTrainingQueue: Current iCount is: " + _mySkillPlanImportCount);
                _mySkillPlanImportCount++;

                if (QCache.Instance.DirectEve.Skills.AreMySkillsReady)
                {
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.CheckTrainingQueue: if (Cache.Instance.DirectEve.Skills.AreMySkillsReady)");
                    _nextSkillTrainingAction = DateTime.UtcNow.AddSeconds(3);

                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.CheckTrainingQueue: Current Training Queue Length is [" + QCache.Instance.DirectEve.Skills.SkillQueueLength.ToString() + "]");
                    if (QCache.Instance.DirectEve.Skills.SkillQueueLength.TotalMinutes < 1337 && QCache.Instance.DirectEve.Skills.SkillQueueLength.TotalMinutes >= 0) // 1440 = 60*24
                    {
                        Log.WriteLine("SkillPlan.CheckTrainingQueue: Training Queue currently has room. [" + Math.Round(24 - QCache.Instance.DirectEve.Skills.SkillQueueLength.TotalHours, 2) + " hours free]");
                        if (doneWithAllPlannedSKills) return true;
                        if (!AddPlannedSkillToQueue("SkillPlan")) return false;
                        if (_mySkillPlanImportCount > 30) return true; //this should only happen if the actual adding of items to the skill queue fails or if we can't add enough skills to the queue <24h
                    }
                    else
                    {
                        Log.WriteLine("SkillPlan.CheckTrainingQueue: Training Queue is full. [" + Math.Abs(Math.Round(QCache.Instance.DirectEve.Skills.SkillQueueLength.TotalHours, 2)) + " is more than 24 hours]");
                        return true;
                    }
                }
                else
                {
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("SkillPlan.CheckTrainingQueue:  false: if (Cache.Instance.DirectEve.Skills.AreMySkillsReady)");
                }
                return false;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }
        **/

        private static int Decode(string roman)
        {
            roman = roman.ToUpper();
            int total = 0, minus = 0;

            for (int icount2 = 0; icount2 < roman.Length; icount2++) // Iterate through characters.
            {
                int thisNumeral = RomanDictionary[roman[icount2]] - minus;

                if (icount2 >= roman.Length - 1 ||
                    thisNumeral + minus >= RomanDictionary[roman[icount2 + 1]])
                {
                    total += thisNumeral;
                    minus = 0;
                }
                else
                {
                    minus = thisNumeral;
                }
            }
            return total;
        }

        private static int GetInvTypeId(string moduleName)
        {
            try
            {
                if (_xmlSkillPreReqs == null)
                {
                    _xmlSkillPreReqs = XDocument.Load(Settings.Instance.Path + "\\Skill_Prerequisites.xml");
                    if (DebugConfig.DebugSkillQueue) Log.WriteLine("Skill_Prerequisites.xml Loaded.");
                }

                return Convert.ToInt32(_xmlSkillPreReqs.Element("document").Elements("skill").Where(i => i.Attribute("name").Value.ToLower() == moduleName.ToLower()).Select(e => e.Attribute("id").Value).FirstOrDefault());
            }
            catch (Exception e)
            {
                Log.WriteLine("Exception:  [" + e.Message + "]");
                return 0;
            }
        }

        /**
        private static bool AddPlannedSkillToQueue(string module)
        {
            try
            {
                foreach (KeyValuePair<string, int> skill in mySkillPlan)
                {
                    //if (DebugConfig.DebugSkillQueue) Logging.Log("AddPlannedSkillToQueue", "Currently working with [" + skill.Key + "] level [" + skill.Value + "]");
                    if (!SkillAlreadyQueued(skill) && SkillIsBelowPlannedLevel(skill) && SkillAlreadyInCharacterSheet(skill)) // not queued && below planned level && in our character sheet
                    {
                        TrainSkillNow(skill);
                        _nextSkillTrainingAction = DateTime.UtcNow.AddSeconds(QCache.Instance.RandomNumber(2, 5));
                        return false;
                    }

                    if (!SkillAlreadyInCharacterSheet(skill) && attemptsToDoSomethingWithNonInjectedSkills <= 15)
                    {
                        // skill not already in our character sheet
                        attemptsToDoSomethingWithNonInjectedSkills++;
                        Log.WriteLine("AddPlannedSkillToQueue: Skill [" + skill.Key + "] will be bought(if in station & price < average sell * 10) and/or injected if in itemhangar");
                        buyingSkillTypeID = GetInvTypeId(skill.Key);
                        buyingSkillTypeName = skill.Key;
                        if (buyingSkillTypeID != 0)
                        {
                            if (DoWeHaveThisSkillAlreadyInOurItemHangar(buyingSkillTypeID))
                            {
                                InjectSkillBook(buyingSkillTypeID);
                                return false;
                            }

                            if (QCache.Instance.InStation)
                            {
                                _State.CurrentSkillQueueState = SkillQueueState.BuyingSkill;
                                return false;
                            }

                            //if we could not find the skillbook in our hangar and for whatever reason could not buy one, move on to the next skill in the list
                            continue;
                        }

                        return false;
                    }
                }
                if (DebugConfig.DebugSkillQueue) Log.WriteLine("AddPlannedSkillToQueue: Done with all planned skills");
                doneWithAllPlannedSKills = true;
                return true;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }
        **/

        private static string ParseRomanNumeral(string importedSkill)
        {
            string subString = importedSkill.Substring(importedSkill.Length - 3);

            try
            {
                bool startsWithWhiteSpace = char.IsWhiteSpace(subString, 0); // 0 = first character
                if (startsWithWhiteSpace || char.IsLower(subString, 0))
                {
                    subString = importedSkill.Substring(importedSkill.Length - 2);
                    startsWithWhiteSpace = char.IsWhiteSpace(subString, 0); // 0 = first character
                    if (startsWithWhiteSpace)
                    {
                        subString = importedSkill.Substring(importedSkill.Length - 1);
                        startsWithWhiteSpace = char.IsWhiteSpace(subString, 0); // 0 = first character
                        if (startsWithWhiteSpace)
                            return subString;
                        return subString;
                    }
                    return subString;
                }
                return subString;
            }
            catch (Exception exception)
            {
                Log.WriteLine("ParseRomanNumeral: Exception was [" + exception + "]");
            }
            return subString;
        }

        #endregion Methods
    }

    public class SkillQueueItem
    {
        #region Methods

        public SkillQueueItem Clone()
        {
            SkillQueueItem stuffToHaul = new SkillQueueItem
            {
                TypeId = TypeId,
                Quantity = Quantity,
                Description = Description
            };
            return stuffToHaul;
        }

        #endregion Methods

        #region Fields

        //
        // use priority levels to decide what to do 1st vs last, 1 being the highest priority.
        //
        public int Priority = 5;

        private string _name = string.Empty;

        #endregion Fields

        #region Constructors

        public SkillQueueItem()
        {
        }

        public SkillQueueItem(XElement xmlSkillQueueItem)
        {
            try
            {
                TypeId = (int)xmlSkillQueueItem.Attribute("typeId");
                Quantity = (int)xmlSkillQueueItem.Attribute("quantity");
                Description = (string)xmlSkillQueueItem.Attribute("description") ?? (string)xmlSkillQueueItem.Attribute("typeId");

                if (!ESCache.Instance.DirectEve.DoesInvTypeExistInTypeStorage(TypeId))
                    Log.WriteLine("ERROR: xmlInventoryItem.TypeId: " + TypeId + " was NOT found in type storage. Fix your xmlInventoryItem type ids.");
                //else
                //    Log.WriteLine("xmlInventoryItem.TypeId: " + TypeId + " was found in type storage");
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        #endregion Constructors

        #region Properties

        public string Description { get; set; }

        public string Name
        {
            get
            {
                if (!string.IsNullOrEmpty(_name))
                    return _name;

                string ret = string.Empty;
                if (!ESCache.Instance.DirectEve.DoesInvTypeExistInTypeStorage(TypeId))
                    return ret;

                DirectInvType invType = ESCache.Instance.DirectEve.GetInvType(TypeId);

                if (invType == null)
                    return ret;

                string typeName = invType.TypeName;
                _name = typeName;
                return typeName;
            }
        }

        public int Quantity { get; set; }
        public int TypeId { get; private set; }

        #endregion Properties
    }
}