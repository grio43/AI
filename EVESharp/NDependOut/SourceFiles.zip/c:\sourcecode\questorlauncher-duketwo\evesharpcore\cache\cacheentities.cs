﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Framework;
using EVESharpCore.Framework.Events;
using EVESharpCore.Logging;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Stats;
using EVESharpCore.Questor.Traveller;
using SC::SharedComponents.Events;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Cache
{
    extern alias SC;

    public partial class ESCache
    {
        #region Fields

        public IEnumerable<DirectSolarSystem> _solarSystems;
        public IEnumerable<EntityCache> _TotalTargetsandTargeting;
        public Dictionary<long, bool> EntityIsEntutyIShouldLeaveAlone = new Dictionary<long, bool>();
        public Dictionary<long, bool> EntityIsHighValueTarget = new Dictionary<long, bool>();
        public Dictionary<long, bool> EntityIsLowValueTarget = new Dictionary<long, bool>();
        private List<EntityCache> _chargeEntities;
        private List<EntityCache> _entities;
        private IEnumerable<EntityCache> _entitiesActivelyBeingLocked;
        private List<EntityCache> _entitiesNotSelf;
        private List<EntityCache> _entitiesOnGrid;
        private bool? _inSpace;
        private bool? _inStation;
        private List<EntityCache> _myAmmoInSpace;
        private EntityCache _myShipEntity;
        //private bool? _warpDriveActive;
        private IEnumerable<EntityCache> _wrecks;
        private bool? _inWarp { get; set; }
        private bool? _previouslyInWarp { get; set; }
        private bool? _previouslyInMission { get; set; }

        #endregion Fields

        #region Properties

        public IEnumerable<EntityCache> AbyssalBigObjects
        {
            get
            {
                return _abyssalBigObjects ?? (_abyssalBigObjects = Instance.EntitiesOnGrid.Where(e => e.IsLargeCollidable
                                                                                                      && e.Distance < (double)Distances.OnGridWithMe)
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> AbyssalDeadspaceBioluminesenceCloud
        {
            get
            {
                return _AbyssalDeadspaceBioluminescenceCloud ?? (_AbyssalDeadspaceBioluminescenceCloud = Instance.EntitiesOnGrid.Where(e =>
                               e.IsAbyssalDeadspaceBioluminesenceCloud
                               && e.Distance < (double)Distances.OnGridWithMe
                               && e.TypeId != (int)TypeID.Beacon)
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> AbyssalDeadspaceCausticCloud
        {
            get
            {
                return _AbyssalDeadspaceCausticCloud ?? (_AbyssalDeadspaceCausticCloud = Instance.EntitiesOnGrid.Where(e =>
                               e.IsAbyssalDeadspaceCausticCloud
                               && e.Distance < (double)Distances.OnGridWithMe
                               && e.TypeId != (int)TypeID.Beacon)
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> AbyssalDeadspaceDeviantAutomataSuppressor
        {
            get
            {
                return _AbyssalDeadspaceDeviantAutomataSuppressor ?? (_AbyssalDeadspaceDeviantAutomataSuppressor = Instance.EntitiesOnGrid.Where(e =>
                               e.IsAbyssalDeadspaceDeviantAutomataSuppressor
                               && e.Distance < (double)Distances.OnGridWithMe
                               && e.TypeId != (int)TypeID.Beacon)
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> AbyssalDeadspaceFilamentCloud
        {
            get
            {
                return _AbyssalDeadspaceFilamentCloud ?? (_AbyssalDeadspaceFilamentCloud = Instance.EntitiesOnGrid.Where(e =>
                               e.IsAbyssalDeadspaceFilamentCloud
                               && e.Distance < (double)Distances.OnGridWithMe
                               && e.TypeId != (int)TypeID.Beacon)
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> AbyssalDeadspaceMultibodyTrackingPylon
        {
            get
            {
                return _AbyssalDeadspaceMultibodyTrackingPylon ?? (_AbyssalDeadspaceMultibodyTrackingPylon = Instance.EntitiesOnGrid.Where(e =>
                               e.IsAbyssalDeadspaceMultibodyTrackingPylon
                               && e.Distance < (double)Distances.OnGridWithMe
                               && e.TypeId != (int)TypeID.Beacon)
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> AccelerationGates
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                return _gates ?? (_gates = Instance.EntitiesOnGrid.Where(e =>
                               e.Distance < (double)Distances.OnGridWithMe &&
                               e.IsAccelerationGate &&
                               e.Name != "Triglavian Proving Conduit")
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> BigObjects
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                return _bigObjectsAndGates ?? (_bigObjectsAndGates = Instance.EntitiesOnGrid.Where(e =>
                               (e.IsLargeCollidable ||
                                e.CategoryId == (int)CategoryID.Asteroid ||
                                e.GroupId == (int)Group.SpawnContainer ||
                                e.Name.ToLower() == "ENV_Triglavian_Construction_01a".ToLower())
                               && e.Distance < (double)Distances.OnGridWithMe
                               && e.TypeId != (int)TypeID.Beacon)
                           .OrderBy(t => t.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> ChargeEntities
        {
            get
            {
                try
                {
                    if (_chargeEntities == null)
                    {
                        _chargeEntities =
                            Instance.DirectEve.Entities.Where(e => e.IsValid && !e.HasExploded && !e.HasReleased && e.CategoryId == (int)CategoryID.Charge)
                                .Select(i => new EntityCache(i))
                                .ToList();
                        return _chargeEntities;
                    }

                    return _chargeEntities;
                }
                catch (NullReferenceException)
                {
                }

                return new List<EntityCache>();
            }
        }

        public IEnumerable<EntityCache> Citadels => Entities.Where(e => e.CategoryId == (int)CategoryID.Citadel).OrderBy(i => i.Distance);

        public EntityCache ClosestStargate
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return null;

                    if (Instance.InSpace)
                    {
                        if (Instance.Entities != null && Instance.Entities.Any())
                        {
                            if (Instance.Stargates.Any())
                                return Instance.Stargates.OrderBy(s => s.Distance).FirstOrDefault() ?? null;

                            return null;
                        }

                        return null;
                    }

                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public EntityCache ClosestWormhole
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return null;

                    if (Instance.InSpace)
                    {
                        if (Instance.EntitiesOnGrid != null && Instance.EntitiesOnGrid.Any())
                        {
                            if (Instance.Wormholes != null && Instance.Wormholes.Any())
                                return Instance.Wormholes.OrderBy(s => s.Distance).FirstOrDefault() ?? null;

                            return null;
                        }

                        return null;
                    }

                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }
        public EntityCache ClosestStation
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return null;

                    if (Stations != null && Stations.Any())
                        return Stations.OrderBy(s => s.Distance).FirstOrDefault() ?? Instance.Entities.OrderByDescending(s => s.Distance).FirstOrDefault();

                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public IEnumerable<EntityCache> Containers
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return null;

                    return _containers ?? (_containers = Instance.EntitiesOnGrid.Where(e =>
                                   e.IsContainer &&
                                   e.HaveLootRights &&
                                   e.Name != "Abandoned Container")
                               .OrderBy(i => i.IsWreck).ThenBy(i => i.IsWreckEmpty) //Containers first, then wrecks
                               .ToList());
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return new List<EntityCache>();
                }
            }
        }

        public IEnumerable<EntityCache> ContainersIgnoringLootRights
        {
            get
            {
                return _containers ?? (_containers = Instance.EntitiesOnGrid.Where(e =>
                               e.IsContainer &&
                               e.Name != "Abandoned Container")
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> Entities
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                    if (_entities == null)
                    {
                        _entities =
                            Instance.DirectEve.Entities.Where(e => e.IsValid && !e.HasExploded && !e.HasReleased && e.CategoryId != (int)CategoryID.Charge)
                                .Select(i => new EntityCache(i))
                                .ToList();
                        return _entities;
                    }

                    return _entities;
                }
                catch (NullReferenceException)
                {
                }

                return new List<EntityCache>();
            }
        }

        public IEnumerable<EntityCache> EntitiesActivelyBeingLocked
        {
            get
            {
                if (!InSpace)
                    return new List<EntityCache>();

                if (Instance.EntitiesNotSelf.Any())
                {
                    if (_entitiesActivelyBeingLocked == null)
                    {
                        _entitiesActivelyBeingLocked = Instance.EntitiesNotSelf.Where(i => i.IsTargeting).ToList();
                        if (_entitiesActivelyBeingLocked.Any())
                            return _entitiesActivelyBeingLocked;

                        return new List<EntityCache>();
                    }

                    return _entitiesActivelyBeingLocked;
                }

                return new List<EntityCache>();
            }
        }

        public IEnumerable<EntityCache> EntitiesNotSelf
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                if (_entitiesNotSelf == null)
                {
                    _entitiesNotSelf =
                        Instance.EntitiesOnGrid.Where(i => i.Id != Instance.ActiveShip.ItemId).ToList();
                    if (_entitiesNotSelf.Any())
                        return _entitiesNotSelf;

                    return new List<EntityCache>();
                }

                return _entitiesNotSelf;
            }
        }

        public IEnumerable<EntityCache> EntitiesOnGrid
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                    if (_entitiesOnGrid == null)
                    {
                        _entitiesOnGrid = Instance.Entities.Where(e => e.IsOnGridWithMe).ToList();
                        return _entitiesOnGrid;
                    }

                    if (_entitiesOnGrid.Any())
                        return _entitiesOnGrid;

                    return new List<EntityCache>();
                }
                catch (NullReferenceException)
                {
                }

                return new List<EntityCache>();
            }
        }

        // the entity we are following (approach, orbit, keep at range)
        public EntityCache FollowingEntity => Instance.ActiveShip.Entity != null && Instance.ActiveShip.FollowingEntity != null ? new EntityCache(Instance.ActiveShip.FollowingEntity) : null;

        public bool InSpace
        {
            get
            {
                try
                {
                    if (_inSpace != null) return (bool)_inSpace;

                    if (DateTime.UtcNow < Time.Instance.QuestorStarted_DateTime.AddSeconds(3))
                        return false;

                    _inSpace = false;

                    if (DirectEve.Session != null && DirectEve.Session.IsInSpace)
                    {
                        if (DebugConfig.DebugInSpace) Log.WriteLine("InSpace: DirectEve.Session.IsInSpace");
                        _inSpace = true;
                    }

                    //if (QCache.Instance.ClosestStation != null && QCache.Instance.ClosestStation.Distance < (double)Distances.DockingRange)
                    //{
                    //    if (DateTime.UtcNow < Time.Instance.LastDockAction.AddSeconds(10))
                    //    {
                    //        if (DebugConfig.DebugInSpace) Log.WriteLine("InSpace: if (DateTime.UtcNow < Time.Instance.LastDockAction.AddSeconds(10))");
                    //        _inSpace = false;
                    //        if (QCache.Instance.EveAccount != null && QCache.Instance.EveAccount.IsLeader && QCache.Instance.EveAccount.LeaderInSpace) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(QCache.Instance.EveAccount.CharacterName, nameof(EveAccountLeaderInSpace", _inSpace);
                    //        return _inSpace ?? false;
                    //    }
                    //}
                    //
                    //if (DateTime.UtcNow < Time.Instance.LastJumpAction.AddSeconds(5))
                    //{
                    //    if (DebugConfig.DebugInSpace) Log.WriteLine("InSpace: if (DateTime.UtcNow < Time.Instance.LastJumpAction.AddSeconds(5))");
                    //    _inSpace = false;
                    //    if (QCache.Instance.EveAccount != null && QCache.Instance.EveAccount.IsLeader && QCache.Instance.EveAccount.LeaderInSpace) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(QCache.Instance.EveAccount.CharacterName, nameof(EveAccountLeaderInSpace", _inSpace);
                    //    return _inSpace ?? false;
                    //}

                    if (Instance.EveAccount != null)
                    {
                        if (Instance.EveAccount.IsDocked && (bool)_inSpace)
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(CharName, nameof(EveAccount.IsDocked), false);

                        if (Instance.EveAccount.IsLeader)
                        {
                            if (Instance.EveAccount.LeaderInSpace != _inSpace)
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInSpace), _inSpace);

							if (ESCache.Instance.Star != null && ESCache.Instance.Stargates.Any())
                            {
                                string systemName = Instance.DirectEve.SolarSystems.FirstOrDefault(i => i.Key == Instance.DirectEve.Session.SolarSystemId).Value.Name;
                                if (Instance.EveAccount.LeaderIsInSystemName != systemName)
                                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderIsInSystemName), systemName);
                            }

                            if (Instance.EveAccount.LeaderIsInSystemId != Instance.DirectEve.Session.SolarSystemId)
                                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderIsInSystemId), Instance.DirectEve.Session.SolarSystemId);
                        }
                    }

                    return _inSpace ?? false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine(ex.ToString());
                    return false;
                }
            }
        }

        public bool InStation
        {
            get
            {
                try
                {
                    if (_inStation != null) return (bool)_inStation;

                    if (DateTime.UtcNow < Time.Instance.QuestorStarted_DateTime.AddSeconds(3))
                        return false;

                    _inStation = false;
                    long whereAmIDocked = 0;

                    if (DirectEve.Session.IsInDockableLocation)
                    {
                        if (DirectEve.Session.StationId.HasValue)
                            whereAmIDocked = (int)DirectEve.Session.StationId;
                        else if (DirectEve.Session.Structureid.HasValue)
                            whereAmIDocked = (long)DirectEve.Session.Structureid;

                        Traveler.myTravelToBookmark = null;
                        _inStation = true;
                        DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "InStation"));
                    }

                    if (Instance.EveAccount.IsLeader && Instance.EveAccount.LeaderInStation != _inStation)
                    {
                        if (Instance.EveAccount.LeaderInStation) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInStation), _inStation);
                        if (Instance.EveAccount.LeaderInStationId != 0) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInStationId), whereAmIDocked);
                    }

                    if (!Instance.EveAccount.IsDocked && (bool)_inStation)
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.IsDocked), _inStation);

                    if (Instance.EveAccount.IsDocked && !(bool)_inStation)
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.IsDocked), _inStation);

                    if (Instance.EveAccount.myCorpId != Instance.DirectEve.Session.CorporationId.ToString())
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.myCorpId), Instance.DirectEve.Session.CorporationId.ToString());

                    if (Instance.EveAccount.myCorp != Instance.DirectEve.Me.CorpName)
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.myCorp), Instance.DirectEve.Me.CorpName);

                    return _inStation ?? false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine(ex.ToString());
                    return false;
                }
            }
        }

        public bool InWarp
        {
            get
            {
                try
                {
                    if (_inWarp != null) return _inWarp ?? false;

                    if (Instance.InSpace && !Instance.InStation)
                    {
                        if (Instance.ActiveShip != null)
                        {
                            if (Instance.ActiveShip.Entity != null)
                            {
                                if (Instance.ActiveShip.Entity.Mode == 3)
                                {
                                    int atThisVelocityWeConsiderOurselvesInWarp = 10000;
                                    atThisVelocityWeConsiderOurselvesInWarp = (int)Instance.ActiveShip.MaxVelocity + 1;

                                    if (Instance.MyShipEntity.Velocity > atThisVelocityWeConsiderOurselvesInWarp)
                                    {
                                        //AttemptingToWarp = false;
                                        if (Instance.Weapons != null && Instance.Weapons.Any())
                                            Combat.ReloadAll();

                                        if (Combat.PrimaryWeaponPriorityEntities != null && Combat.PrimaryWeaponPriorityEntities.Any())
                                            Combat.RemovePrimaryWeaponPriorityTargets(Combat.PrimaryWeaponPriorityEntities.ToList());

                                        if (Drones.UseDrones && Drones.DronePriorityEntities != null && Drones.DronePriorityEntities.Any())
                                            Drones.RemoveDronePriorityTargets(Drones.DronePriorityEntities.ToList());

                                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LastInWarp), DateTime.UtcNow);
                                        Time.Instance.LastInWarp = DateTime.UtcNow;
                                        SetInWarpState(true);
                                        if (Instance.EveAccount.IsLeader && !Instance.EveAccount.LeaderInWarp) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInWarp), _inWarp);
                                        DirectEventManager.NewEvent(new DirectEvent(DirectEvents.KEEP_ALIVE, "InWarp"));
                                        return _inWarp ?? false;
                                    }

                                    if (Time.Instance.LastInWarp.AddSeconds(5) > DateTime.UtcNow)
                                        return true;
                                }

                                SetInWarpState(false);
                                if (Instance.EveAccount.IsLeader && !Instance.EveAccount.LeaderInWarp) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInWarp), _inWarp);
                                return _inWarp ?? false;
                            }

                            SetInWarpState(false);
                            if (Instance.EveAccount.IsLeader && !Instance.EveAccount.LeaderInWarp) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInWarp), _inWarp);
                            return _inWarp ?? false;
                        }

                        SetInWarpState(false);
                        if (Instance.EveAccount.IsLeader && !Instance.EveAccount.LeaderInWarp) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInWarp), _inWarp);
                        return _inWarp ?? false;
                    }

                    SetInWarpState(false);
                    if (Instance.EveAccount.IsLeader && !Instance.EveAccount.LeaderInWarp) WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(Instance.EveAccount.CharacterName, nameof(EveAccount.LeaderInWarp), _inWarp);
                    return _inWarp ?? false;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("InWarp check failed, exception [" + exception + "]");
                }

                return false;
            }
        }

        public int? MaxLockedTargets
        {
            get
            {
                try
                {
                    if (_maxLockedTargets == null)
                    {
                        _maxLockedTargets = Math.Min(Instance.DirectEve.Me.MaxLockedTargets, Instance.ActiveShip.MaxLockedTargets);
                        return (int)_maxLockedTargets;
                    }

                    return (int)_maxLockedTargets;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public IEnumerable<EntityCache> myAmmoInSpace
        {
            get
            {
                if (_myAmmoInSpace == null)
                {
                    if (myCurrentAmmoInWeapon != null)
                    {
                        _myAmmoInSpace =
                            Instance.Entities.Where(e => e.Distance > 3000 && e.IsOnGridWithMe && e.TypeId == myCurrentAmmoInWeapon.TypeId && e.Velocity > 50)
                                .ToList();
                        if (_myAmmoInSpace.Any())
                            return _myAmmoInSpace;

                        return null;
                    }

                    return null;
                }

                return _myAmmoInSpace;
            }
        }

        public EntityCache MyShipEntity
        {
            get
            {
                if (_myShipEntity == null)
                {
                    if (!Instance.InSpace)
                        return null;

                    _myShipEntity = Instance.EntitiesOnGrid.FirstOrDefault(e => e.Id == Instance.ActiveShip.ItemId);
                    return _myShipEntity;
                }

                return _myShipEntity;
            }
        }

        public IEnumerable<EntityCache> NPCStations => Entities.Where(e => e.CategoryId == (int)CategoryID.Station).OrderBy(i => i.Distance);

        public IEnumerable<EntityCache> FreeportCitadels
        {
            get
            {
                try
                {
                    IEnumerable<EntityCache> freeportCitadels;
                    freeportCitadels = Entities.Where(e => e.GroupId == (int)Group.Citadel && e._directEntity.IsDockable).OrderBy(i => i.Distance);
                    return freeportCitadels ?? new List<EntityCache>();
                }
                catch (Exception)
                {
                    //Log.WriteLine("Exception [" + ex + "]");
                    return new List<EntityCache>();
                }
            }
        }


        public IEnumerable<DirectSolarSystem> SolarSystems
        {
            get
            {
                try
                {
                    if (Instance.InSpace || Instance.InStation)
                    {
                        if (_solarSystems == null || !_solarSystems.Any() || _solarSystems.Count() < 5400)
                        {
                            if (Instance.DirectEve.SolarSystems.Any())
                            {
                                if (Instance.DirectEve.SolarSystems.Values.Any())
                                    _solarSystems = Instance.DirectEve.SolarSystems.Values.OrderBy(s => s.Name).ToList();

                                return null;
                            }

                            return null;
                        }

                        return _solarSystems;
                    }

                    return null;
                }
                catch (NullReferenceException)
                {
                    return null;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return null;
                }
            }
        }

        public EntityCache Star
        {
            get { return _star ?? (_star = Entities.FirstOrDefault(e => e.CategoryId == (int)CategoryID.Celestial && e.GroupId == (int)Group.Star)); }
        }

        public List<EntityCache> Stargates
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                    if (_stargates == null)
                    {
                        if (Instance.Entities != null && Instance.Entities.Any())
                        {
                            _stargates = Instance.Entities.Where(e => e.GroupId == (int)Group.Stargate).ToList();
                            return _stargates ?? new List<EntityCache>();
                        }

                        return new List<EntityCache>();
                    }

                    return _stargates;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return new List<EntityCache>();
                }
            }
        }

        public IEnumerable<EntityCache> Stations => Entities.Where(e => e.CategoryId == (int)CategoryID.Station || e.CategoryId == (int)CategoryID.Citadel).OrderBy(i => i.Distance).ToList() ?? new List<EntityCache>();

        public List<EntityCache> _wormholes;

        public List<EntityCache> Wormholes
        {
            get
            {
                try
                {
                    if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                    if (_wormholes == null)
                    {
                        if (Instance.Entities != null && Instance.Entities.Any())
                        {
                            _wormholes = Instance.Entities.Where(e => e.GroupId == (int) Group.Wormhole).ToList();
                            return _wormholes ?? new List<EntityCache>();
                        }

                        return new List<EntityCache>();
                    }

                    return _wormholes ?? new List<EntityCache>();
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    return new List<EntityCache>();
                }
            }
        }

        public IEnumerable<EntityCache> Targeting
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                if (_targeting == null)
                    _targeting = Instance.EntitiesOnGrid.Where(e => e.IsTargeting || Instance.TargetingIDs.ContainsKey(e.Id)).ToList();

                if (_targeting.Any())
                    return _targeting;

                return new List<EntityCache>();
            }
        }

        public int TargetingSlotsNotBeingUsedBySalvager
        {
            get
            {
                if (Salvage.MaximumWreckTargets > 0 && Instance.MaxLockedTargets >= 5)
                    return Instance.MaxLockedTargets ?? 2 - Salvage.MaximumWreckTargets;

                return Instance.MaxLockedTargets ?? 2;
            }
        }

        public IEnumerable<EntityCache> Targets
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                if (_targets == null)
                {
                    _targets = EntitiesOnGrid.Where(e => e.IsTarget).ToList();
                    foreach (EntityCache target in _targets.Where(t => TargetingIDs.ContainsKey(t.Id)))
                        TargetingIDs.Remove(target.Id);
                }

                return _targets;
            }
        }

        public IEnumerable<EntityCache> TotalTargetsandTargeting
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                if (_TotalTargetsandTargeting == null)
                {
                    _TotalTargetsandTargeting = Targets.Concat(Targeting.Where(i => !i.IsTarget));
                    return _TotalTargetsandTargeting;
                }

                return _TotalTargetsandTargeting;
            }
        }

        public int TotalTargetsandTargetingCount
        {
            get
            {
                if (!TotalTargetsandTargeting.Any())
                    return 0;

                return TotalTargetsandTargeting.Count();
            }
        }

        public IEnumerable<EntityCache> UnlootedContainers
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                return _unlootedContainers ?? (_unlootedContainers = Instance.EntitiesOnGrid.Where(e =>
                               e.IsContainer &&
                               e.HaveLootRights &&
                               !LootedContainers.Contains(e.Id))
                           .OrderBy(
                               e => e.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> UnlootedWrecksAndSecureCans
        {
            get
            {
                if (!ESCache.Instance.InSpace) return new List<EntityCache>();

                return _unlootedWrecksAndSecureCans ?? (_unlootedWrecksAndSecureCans = Instance.EntitiesOnGrid.Where(e =>
                               (e.GroupId == (int)Group.Wreck ||
                               e.GroupId == (int)Group.SecureContainer ||
                               e.GroupId == (int)Group.AuditLogSecureContainer ||
                               e.GroupId == (int)Group.FreightContainer))
                           .OrderBy(e => e.Distance)
                           .ToList());
            }
        }

        public IEnumerable<EntityCache> Wrecks
        {
            get { return _wrecks ?? (_wrecks = Instance.EntitiesOnGrid.Where(e => e.GroupId == (int)Group.Wreck).ToList()); }
        }

        private void SetInWarpState(bool State)
        {
            if (_previouslyInWarp == State)
            {
                _inWarp = State;
                return;
            }

            _inWarp = State;
            _previouslyInWarp = State;
            Log.WriteLine("InWarp is now [" + _inWarp + "]");

            //RemoveTargetsFromBountyListBeforeWarping();
        }

        private void SetInMissionState(bool State)
        {
            if (_previouslyInMission == State)
            {
                _inMission = State;
                return;
            }

            _inMission = State;
            _previouslyInMission = State;
            Log.WriteLine("InMission is now [" + _inMission + "]");
        }

        #endregion Properties

        #region Methods

        public double DistanceFromMe(double x, double y, double z)
        {
            try
            {
                if (Instance.ActiveShip.Entity == null)
                    return 0;

                if (x == 0 || y == 0 || z == 0)
                    return 0;

                double curX = Instance.ActiveShip.Entity.X;
                double curY = Instance.ActiveShip.Entity.Y;
                double curZ = Instance.ActiveShip.Entity.Z;

                return Math.Round(Math.Sqrt((curX - x) * (curX - x) + (curY - y) * (curY - y) + (curZ - z) * (curZ - z)), 2);
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return 0;
            }
        }

        public IEnumerable<EntityCache> EntitiesByPartialName(string nameToSearchFor)
        {
            try
            {
                if (Instance.Entities != null && Instance.Entities.Any())
                {
                    IEnumerable<EntityCache> _entitiesByPartialName = Instance.Entities.Where(e => e.Name.ToLower().Contains(nameToSearchFor.ToLower())).ToList();
                    if (!_entitiesByPartialName.Any())
                        _entitiesByPartialName = Instance.Entities.Where(e => e.Name.ToLower() == nameToSearchFor.ToLower()).ToList();

                    if (!_entitiesByPartialName.Any())
                        _entitiesByPartialName = null;

                    return _entitiesByPartialName;
                }

                return null;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return null;
            }
        }

        public IEnumerable<EntityCache> EntitiesThatContainTheName(string label)
        {
            try
            {
                return Instance.Entities.Where(e => !string.IsNullOrEmpty(e.Name) && e.Name.ToLower().Contains(label.ToLower())).ToList();
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return null;
            }
        }

        public EntityCache EntityById(long id)
        {
            try
            {
                if (_entitiesById.ContainsKey(id))
                    return _entitiesById[id];

                EntityCache entity = Instance.EntitiesOnGrid.FirstOrDefault(e => e.Id == id);
                _entitiesById[id] = entity;
                return entity;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return null;
            }
        }

        public EntityCache EntityByName(string name)
        {
            return Instance.Entities.FirstOrDefault(e => string.Compare(e.Name, name, StringComparison.OrdinalIgnoreCase) == 0);
        }

        public bool GateInGrid()
        {
            try
            {
                if (Instance.AccelerationGates.FirstOrDefault() == null || !Instance.AccelerationGates.Any())
                    return false;

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }
        }

        //public IEnumerable<EntityCache> EntitiesByName(string nameToSearchFor, IEnumerable<EntityCache> EntitiesToLookThrough)
        //{
        //    return EntitiesToLookThrough.Where(e => e.Name.ToLower() == nameToSearchFor.ToLower()).ToList();
        //}
        public Func<EntityCache, int> OrderByLowestHealth()
        {
            try
            {
                return t => (int)(t.ShieldPct + t.ArmorPct + t.StructurePct);
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return null;
            }
        }

        public EntityCache StargateByName(string locationName)
        {
            {
                return _stargate ??
                       (_stargate =
                           Instance.Stargates.FirstOrDefault(i => i.Name.ToLower() == locationName.ToLower()));
            }
        }

        public EntityCache StationByName(string stationName)
        {
            EntityCache station = Stations.First(x => x.Name.ToLower() == stationName.ToLower());
            return station;
        }

        private void RemoveTargetsFromBountyListBeforeWarping()
        {
            try
            {
                if (Instance.EntitiesOnGrid != null && Instance.EntitiesOnGrid.Any() && Statistics.BountyValues != null && Statistics.BountyValues.Any())
                    foreach (EntityCache e in Instance.EntitiesOnGrid.Where(e => Statistics.BountyValues.TryGetValue(e.Id, out var val) && val > 0))
                    {
                        foreach (KeyValuePair<long, double> BountyValue in Statistics.BountyValues)
                        {
                            if (e.Id == BountyValue.Key)
                                Statistics.BountyValues.Remove(e.Id);
                        }
                    }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        #endregion Methods
    }
}