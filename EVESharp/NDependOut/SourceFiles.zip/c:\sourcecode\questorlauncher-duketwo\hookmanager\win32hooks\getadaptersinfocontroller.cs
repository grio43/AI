﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 21.06.2014
 * Time: 16:57
 *
 * ---------------------------------------
 */

using EasyHook;
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

namespace HookManager.Win32Hooks
{
    /// <summary>
    ///     Description of GetAdaptersInfoController.
    /// </summary>
    public class GetAdaptersInfoController : IDisposable, IHook
    {
        #region Constructors

        public GetAdaptersInfoController(IntPtr address, string guid, string mac, string ipaddress)
        {
            Name = typeof(GetAdaptersInfoController).Name;
            _guid = guid;
            _mac = mac;
            _address = ipaddress;

            try
            {
                _name = string.Format("GetAdaptersInfoHook_{0:X}", address.ToInt32());
                _hook = LocalHook.Create(address, new GetAdaptersInfoDelegate(GetAdaptersInfoDetour), this);
                _hook.ThreadACL.SetExclusiveACL(new int[] { });
            }
            catch (Exception)
            {
                Error = true;
            }
        }

        #endregion Constructors

        #region Delegates

        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Ansi, SetLastError = true)]
        private delegate int GetAdaptersInfoDelegate(IntPtr AdaptersInfo, IntPtr OutputBuffLen);

        #endregion Delegates

        #region Fields

        private readonly string _address;

        private readonly string _guid;
        private LocalHook _hook;
        private readonly string _mac;

        private string _name;

        #endregion Fields

        #region Properties

        public bool Error { get; set; }

        public string Name { get; set; }

        #endregion Properties

        #region Methods

        [DllImport("Iphlpapi.dll", SetLastError = true)]
        public static extern int GetAdaptersInfo(IntPtr AdaptersInfo, IntPtr OutputBuffLen);

        public void Dispose()
        {
            if (_hook == null)
                return;

            _hook.Dispose();
            _hook = null;
        }

        private string ByteArrayToString(byte[] arr)
        {
            ASCIIEncoding enc = new ASCIIEncoding();
            return enc.GetString(arr);
        }

        private int GetAdaptersInfoDetour(IntPtr AdaptersInfo, IntPtr OutputBuffLen)
        {
            int result = GetAdaptersInfo(AdaptersInfo, OutputBuffLen);
            if (AdaptersInfo != IntPtr.Zero)
            {
                IP_ADAPTER_INFO structureBefore = (IP_ADAPTER_INFO) Marshal.PtrToStructure(AdaptersInfo, typeof(IP_ADAPTER_INFO));
                string macBefore = BitConverter.ToString(structureBefore.Address);

                HookManagerImpl.Log(
                    "[BEFORE] " + structureBefore.IpAddressList.IpAddress.Address + " [GUID] " + structureBefore.AdapterName + " [MAC] " + macBefore,
                    Color.Orange);
                structureBefore.AdapterName = _guid.ToUpper();
                for (int i = 0; i < structureBefore.Address.Length - 1; i = i + 2)
                {
                    structureBefore.Address[i] = Convert.ToByte(_mac.Replace("-", "")[i] + _mac.Replace("-", "")[i + 1].ToString(), 16);
                    structureBefore.Next = IntPtr.Zero;
                }

                structureBefore.IpAddressList.IpAddress.Address = _address;
                Marshal.StructureToPtr(structureBefore, AdaptersInfo, true);
                IP_ADAPTER_INFO structureAfter = (IP_ADAPTER_INFO) Marshal.PtrToStructure(AdaptersInfo, typeof(IP_ADAPTER_INFO));
                string macAfter = BitConverter.ToString(structureAfter.Address);

                HookManagerImpl.Log(
                    "[AFTER] " + structureAfter.IpAddressList.IpAddress.Address + " [GUID] " + structureAfter.AdapterName + " [MAC] " + macAfter,
                    Color.Orange);
            }

            return result;
        }

        #endregion Methods

        #region Structs

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct IP_ADAPTER_INFO
        {
            public IntPtr Next;
            public int ComboIndex;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256 + 4)] public string AdapterName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128 + 4)] public string AdapterDescription;
            public uint AddressLength;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] public byte[] Address;
            public int Index;
            public uint Type;
            public uint DhcpEnabled;
            public IntPtr CurrentIpAddress;
            public IP_ADDR_STRING IpAddressList;
            public IP_ADDR_STRING GatewayList;
            public IP_ADDR_STRING DhcpServer;
            public bool HaveWins;
            public IP_ADDR_STRING PrimaryWinsServer;
            public IP_ADDR_STRING SecondaryWinsServer;
            public int LeaseObtained;
            public int LeaseExpires;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct IP_ADDR_STRING
        {
            public IntPtr Next;
            public IP_ADDRESS_STRING IpAddress;
            public IP_ADDRESS_STRING IpMask;
            public int Context;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct IP_ADDRESS_STRING
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)] public string Address;
        }

        #endregion Structs
    }
}