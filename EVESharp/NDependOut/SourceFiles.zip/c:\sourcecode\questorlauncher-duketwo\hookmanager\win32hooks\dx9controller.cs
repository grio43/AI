﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 21.06.2014
 * Time: 17:02
 *
 * ---------------------------------------
 */

using EasyHook;
using SharedComponents.EVE;
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace HookManager.Win32Hooks
{
    /// <summary>
    ///     Description of DX9Controller.
    /// </summary>
    public class DX9Controller : IDisposable, IHook
    {
        #region Constructors

        public DX9Controller(HWSettings settings)
        {
            _settings = settings;
            Name = typeof(DX9Controller).Name;
            IntPtr direct3D = Direct3DCreate9(32);

            try
            {
                if (direct3D == IntPtr.Zero)
                {
                    MessageBox.Show("error");
                    throw new Exception("Failed to create D3D.");
                }

                IntPtr adapterIdentPtr = Marshal.ReadIntPtr(Marshal.ReadIntPtr(direct3D), 20);

                GetAdapterIdentifierOriginal =
                    (GetAdapterIdentifierDelegate) Marshal.GetDelegateForFunctionPointer(adapterIdentPtr, typeof(GetAdapterIdentifierDelegate));

                _name = string.Format("GetAdapterIdentHook_{0:X}", adapterIdentPtr.ToInt32());
                _hook = LocalHook.Create(adapterIdentPtr, new GetAdapterIdentifierDelegate(GetAdapterIdentifierDetour), this);
                _hook.ThreadACL.SetExclusiveACL(new int[] { });
            }
            catch (Exception ex)
            {
                HookManagerImpl.Log("Exception: " + ex);
                Error = true;
            }
        }

        #endregion Constructors

        #region Delegates

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate uint GetAdapterIdentifierDelegate(uint Adapter, ulong Flags, [In] [Out] IntPtr pIdentifier);

        #endregion Delegates

        #region Fields

        private LocalHook _hook;

        private string _name;
        private readonly HWSettings _settings;
        private readonly GetAdapterIdentifierDelegate GetAdapterIdentifierOriginal;

        #endregion Fields

        #region Properties

        public bool Error { get; set; }

        public string Name { get; set; }

        #endregion Properties

        #region Methods

        public void Dispose()
        {
            if (_hook == null)
                return;

            _hook.Dispose();
            _hook = null;
        }

        [DllImport("d3d9.dll")]
        private static extern IntPtr Direct3DCreate9(uint sdkVersion);

        private uint GetAdapterIdentifierDetour(uint Adapter, ulong Flags, [In] [Out] IntPtr pIdentifier)
        {
            uint result = GetAdapterIdentifierOriginal(Adapter, Flags, pIdentifier);

            D3DADAPTER_IDENTIFIER9 newStructBefore = (D3DADAPTER_IDENTIFIER9) Marshal.PtrToStructure(pIdentifier, typeof(D3DADAPTER_IDENTIFIER9));
            string before = string.Format("[BEFORE] [DESC] {0} [DEVICE_ID] {1} [IDENT] {2} [DRIVER_VER] {3} [REVISION] {4} [VENDOR_ID] {5}",
                newStructBefore.Description, newStructBefore.DeviceId, newStructBefore.DeviceIdentifier,
                newStructBefore.DriverVersion.QuadPart, newStructBefore.Revision, newStructBefore.VendorId,
                Color.Orange);
            HookManagerImpl.Log(before, Color.Orange);

            newStructBefore.Description = _settings.GpuDescription;
            newStructBefore.DeviceId = _settings.GpuDeviceId;

            newStructBefore.DeviceIdentifier = Guid.Parse(_settings.GpuIdentifier);

            newStructBefore.DriverVersion.QuadPart = _settings.GpuDriverversion;
            newStructBefore.Revision = _settings.GpuRevision;
            newStructBefore.VendorId = _settings.GpuVendorId;
            Marshal.StructureToPtr(newStructBefore, pIdentifier, true);

            D3DADAPTER_IDENTIFIER9 newStructAfter = (D3DADAPTER_IDENTIFIER9) Marshal.PtrToStructure(pIdentifier, typeof(D3DADAPTER_IDENTIFIER9));

            string after = string.Format("[AFTER] [DESC] {0} [DEVICE_ID] {1} [IDENT] {2} [DRIVER_VER] {3} [REVISION] {4} [VENDOR_ID] {5}",
                newStructAfter.Description, newStructAfter.DeviceId, newStructAfter.DeviceIdentifier,
                newStructAfter.DriverVersion.QuadPart, newStructAfter.Revision, newStructAfter.VendorId,
                Color.Orange);
            HookManagerImpl.Log(after, Color.Orange);
            return 0; // D3D_OK
        }

        #endregion Methods

        #region Structs

        [StructLayout(LayoutKind.Sequential)]
        public struct _GUID
        {
            public int Data1;
            public short Data2;
            public short Data3;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)] public byte[] Data4;
        }

        [StructLayout(LayoutKind.Explicit, Size = 8)]
        public struct LARGE_INTEGER
        {
            [FieldOffset(0)] public long QuadPart;
            [FieldOffset(0)] public uint LowPart;
            [FieldOffset(4)] public uint HighPart;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct D3DADAPTER_IDENTIFIER9
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 512)] public string Driver;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 512)] public string Description;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string DeviceName;
            [MarshalAs(UnmanagedType.Struct)] public LARGE_INTEGER DriverVersion;
            [MarshalAs(UnmanagedType.U4)] public uint VendorId;
            [MarshalAs(UnmanagedType.U4)] public uint DeviceId;
            [MarshalAs(UnmanagedType.U4)] public uint SubSysId;
            [MarshalAs(UnmanagedType.U4)] public uint Revision;
            [MarshalAs(UnmanagedType.Struct)] public Guid DeviceIdentifier;
            [MarshalAs(UnmanagedType.U4)] public uint WHQLLevel;
        }

        #endregion Structs
    }
}