﻿using SharedComponents.Utility;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

/*
 * User: duketwo - https://github.com/duketwo/
 * Date: 10.11.2016
 */

namespace SharedComponents.SharpLogLite.Model
{
    public class LogModelHandler : IDisposable
    {
        #region Delegates

        public delegate void SharpLogMessageDelegate(SharpLogMessage msg);

        #endregion Delegates

        #region Constructors

        public LogModelHandler(ManualResetEvent manualResetEvent, LogSeverity logSeverity)
        {
            ManualResetEvent = manualResetEvent;
            Pid = null;
            LogSeverity = logSeverity;
        }

        #endregion Constructors

        #region Events

        public static event SharpLogMessageDelegate OnMessage;

        #endregion Events

        #region Fields

        private static readonly List<Regex> FILTERED_MESSAGES = new List<Regex>
        {
            new Regex("Warping got a None planet ball"),
            new Regex("Tried to add an item that is already there"),
            new Regex("FIXUP: godma is using an old thrown away invCacheContainer"),
            new Regex("Client is using a session bound remote object while"),
            new Regex("Discarded  \\d*  messages"),
            new Regex("self destination path 0 is own solarsystem, picking next node instead."),
            new Regex("Retrying \\(Retry\\(total=4.*renew.*token")
        };

        private static readonly int VERSION = 2;

        private readonly LogSeverity LogSeverity;
        private readonly ManualResetEvent ManualResetEvent;
        private Socket handler;
        private uint? Pid;

        #endregion Fields

        #region Methods

        public void AcceptCallback(IAsyncResult ar)
        {
            Debug.WriteLine("Accepting a new connection...");
            Socket listener = (Socket)ar.AsyncState;

            try
            {
                handler = listener.EndAccept(ar);
                ManualResetEvent.Set();
                StateObject state = new StateObject();
                state.workSocket = handler;
                handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0,
                    ReadCallback, state);
            }
            catch (ObjectDisposedException)
            {
                Debug.WriteLine("Socket has been closed.");
            }
        }

        public void Dispose()
        {
            if (handler != null)
                handler.Close();
        }

        private void ReadCallback(IAsyncResult ar)
        {
            StateObject state = (StateObject)ar.AsyncState;
            try
            {
                int read = handler.EndReceive(ar);
                if (read > 0)
                {
                    RawLogMessage msg = Util.ByteArrayToStructure<RawLogMessage>(state.buffer);

                    if (msg.Type == MessageType.CONNECTION_MESSAGE)
                    {
                        Pid = msg.ConnectionMessage.Pid;

                        Debug.WriteLine("Accepted a new connection from PID {0}.", Pid);

                        if (msg.ConnectionMessage.Version > VERSION)
                        {
                            Debug.WriteLine("Error: Client using a newer verison: {0}.", msg.ConnectionMessage.Version);
                            Dispose();
                        }
                    }

                    if (Pid == null && msg.Type != MessageType.CONNECTION_MESSAGE)
                    {
                        Debug.WriteLine("Error: Initial CONNECTION_MESSAGE message was not received.");
                        Dispose();
                    }

                    if (msg.Type == MessageType.SIMPLE_MESSAGE ||
                        msg.Type == MessageType.LARGE_MESSAGE)
                        state.sharpLogMessage = new SharpLogMessage(
                            Util.Unix2DateTime(msg.TextMessage.Timestamp),
                            msg.TextMessage.Severity,
                            msg.TextMessage.Module,
                            msg.TextMessage.Channel,
                            msg.TextMessage.Message,
                            (int)Pid
                        );

                    if (msg.Type == MessageType.CONTINUATION_MESSAGE)
                        state.sharpLogMessage.Message += msg.TextMessage.Message;

                    if (msg.Type == MessageType.CONTINUATION_END_MESSAGE)
                        state.sharpLogMessage.Message += msg.TextMessage.Message;

                    if ((msg.Type == MessageType.SIMPLE_MESSAGE ||
                         msg.Type == MessageType.CONTINUATION_END_MESSAGE) && state.sharpLogMessage.Severity >= LogSeverity)
                    {
                        SharpLogMessage msgCopy = state.sharpLogMessage.Copy();
                        Task.Run(() =>
                        {
                            try
                            {
                                if (!FILTERED_MESSAGES.Any(f => f.Match(msgCopy.Message).Success))
                                    OnMessage?.Invoke(msgCopy);
                            }
                            catch (Exception e)
                            {
                                Debug.WriteLine(e);
                            }
                        });
                    }

                    state.buffer = new byte[StateObject.BufferSize];
                    handler.BeginReceive(state.buffer, 0, StateObject.BufferSize, 0, ReadCallback, state);
                }
                else
                {
                    Dispose();
                }
            }
            catch (Exception e)
            {
                Debug.WriteLine("Exception: {0}", e);
                Dispose();
            }
        }

        #endregion Methods
    }
}