﻿namespace SharedComponents.EVE.ClientSettings
{
    public enum MissionType
    {
        L1,
        L2,
        L3,
        L4
    }
}