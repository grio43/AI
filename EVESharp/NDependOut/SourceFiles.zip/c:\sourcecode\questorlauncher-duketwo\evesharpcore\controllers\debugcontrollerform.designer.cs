﻿namespace EVESharpCore.Controllers
{
    partial class DebugControllerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.DebugCreateNewFleet = new System.Windows.Forms.Button();
            this.buttonStopMyShip = new System.Windows.Forms.Button();
            this.buttonApproachPointInSpaceWest = new System.Windows.Forms.Button();
            this.buttonApproachPointInSpaceEast = new System.Windows.Forms.Button();
            this.buttonApproachPointInSpaceSouth = new System.Windows.Forms.Button();
            this.buttonApproachPointInSpaceNorth = new System.Windows.Forms.Button();
            this.buttonApproachPointInSpaceDown = new System.Windows.Forms.Button();
            this.buttonApproachPointInSpaceUp = new System.Windows.Forms.Button();
            this.DebugAssetsButton = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Controls.Add(this.DebugCreateNewFleet);
            this.panel1.Controls.Add(this.buttonStopMyShip);
            this.panel1.Controls.Add(this.buttonApproachPointInSpaceWest);
            this.panel1.Controls.Add(this.buttonApproachPointInSpaceEast);
            this.panel1.Controls.Add(this.buttonApproachPointInSpaceSouth);
            this.panel1.Controls.Add(this.buttonApproachPointInSpaceNorth);
            this.panel1.Controls.Add(this.buttonApproachPointInSpaceDown);
            this.panel1.Controls.Add(this.buttonApproachPointInSpaceUp);
            this.panel1.Controls.Add(this.DebugAssetsButton);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(650, 253);
            this.panel1.TabIndex = 6;
            // 
            // DebugCreateNewFleet
            // 
            this.DebugCreateNewFleet.BackColor = System.Drawing.Color.White;
            this.DebugCreateNewFleet.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.DebugCreateNewFleet.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DebugCreateNewFleet.Location = new System.Drawing.Point(396, 212);
            this.DebugCreateNewFleet.Name = "DebugCreateNewFleet";
            this.DebugCreateNewFleet.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DebugCreateNewFleet.Size = new System.Drawing.Size(242, 21);
            this.DebugCreateNewFleet.TabIndex = 161;
            this.DebugCreateNewFleet.Text = "Debug CreateNewFleet";
            this.DebugCreateNewFleet.UseVisualStyleBackColor = false;
            this.DebugCreateNewFleet.Click += new System.EventHandler(this.DebugCreateNewFleet_Click);
            // 
            // buttonStopMyShip
            // 
            this.buttonStopMyShip.BackColor = System.Drawing.Color.White;
            this.buttonStopMyShip.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonStopMyShip.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonStopMyShip.Location = new System.Drawing.Point(396, 185);
            this.buttonStopMyShip.Name = "buttonStopMyShip";
            this.buttonStopMyShip.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.buttonStopMyShip.Size = new System.Drawing.Size(242, 21);
            this.buttonStopMyShip.TabIndex = 160;
            this.buttonStopMyShip.Text = "Debug StopMyShip()";
            this.buttonStopMyShip.UseVisualStyleBackColor = false;
            this.buttonStopMyShip.Click += new System.EventHandler(this.buttonStopMyShip_Click);
            // 
            // buttonApproachPointInSpaceWest
            // 
            this.buttonApproachPointInSpaceWest.BackColor = System.Drawing.Color.White;
            this.buttonApproachPointInSpaceWest.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonApproachPointInSpaceWest.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonApproachPointInSpaceWest.Location = new System.Drawing.Point(396, 158);
            this.buttonApproachPointInSpaceWest.Name = "buttonApproachPointInSpaceWest";
            this.buttonApproachPointInSpaceWest.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.buttonApproachPointInSpaceWest.Size = new System.Drawing.Size(242, 21);
            this.buttonApproachPointInSpaceWest.TabIndex = 159;
            this.buttonApproachPointInSpaceWest.Text = "Debug Approach Point In Space - West";
            this.buttonApproachPointInSpaceWest.UseVisualStyleBackColor = false;
            this.buttonApproachPointInSpaceWest.Click += new System.EventHandler(this.buttonApproachPointInSpaceWest_Click);
            // 
            // buttonApproachPointInSpaceEast
            // 
            this.buttonApproachPointInSpaceEast.BackColor = System.Drawing.Color.White;
            this.buttonApproachPointInSpaceEast.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonApproachPointInSpaceEast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonApproachPointInSpaceEast.Location = new System.Drawing.Point(396, 131);
            this.buttonApproachPointInSpaceEast.Name = "buttonApproachPointInSpaceEast";
            this.buttonApproachPointInSpaceEast.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.buttonApproachPointInSpaceEast.Size = new System.Drawing.Size(242, 21);
            this.buttonApproachPointInSpaceEast.TabIndex = 158;
            this.buttonApproachPointInSpaceEast.Text = "Debug Approach Point In Space - East";
            this.buttonApproachPointInSpaceEast.UseVisualStyleBackColor = false;
            this.buttonApproachPointInSpaceEast.Click += new System.EventHandler(this.buttonApproachPointInSpaceEast_Click);
            // 
            // buttonApproachPointInSpaceSouth
            // 
            this.buttonApproachPointInSpaceSouth.BackColor = System.Drawing.Color.White;
            this.buttonApproachPointInSpaceSouth.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonApproachPointInSpaceSouth.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonApproachPointInSpaceSouth.Location = new System.Drawing.Point(396, 104);
            this.buttonApproachPointInSpaceSouth.Name = "buttonApproachPointInSpaceSouth";
            this.buttonApproachPointInSpaceSouth.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.buttonApproachPointInSpaceSouth.Size = new System.Drawing.Size(242, 21);
            this.buttonApproachPointInSpaceSouth.TabIndex = 157;
            this.buttonApproachPointInSpaceSouth.Text = "Debug Approach Point In Space - South";
            this.buttonApproachPointInSpaceSouth.UseVisualStyleBackColor = false;
            this.buttonApproachPointInSpaceSouth.Click += new System.EventHandler(this.buttonApproachPointInSpaceSouth_Click);
            // 
            // buttonApproachPointInSpaceNorth
            // 
            this.buttonApproachPointInSpaceNorth.BackColor = System.Drawing.Color.White;
            this.buttonApproachPointInSpaceNorth.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonApproachPointInSpaceNorth.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonApproachPointInSpaceNorth.Location = new System.Drawing.Point(396, 77);
            this.buttonApproachPointInSpaceNorth.Name = "buttonApproachPointInSpaceNorth";
            this.buttonApproachPointInSpaceNorth.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.buttonApproachPointInSpaceNorth.Size = new System.Drawing.Size(242, 21);
            this.buttonApproachPointInSpaceNorth.TabIndex = 156;
            this.buttonApproachPointInSpaceNorth.Text = "Debug Approach Point In Space - North";
            this.buttonApproachPointInSpaceNorth.UseVisualStyleBackColor = false;
            this.buttonApproachPointInSpaceNorth.Click += new System.EventHandler(this.buttonApproachPointInSpaceNorth_Click);
            // 
            // buttonApproachPointInSpaceDown
            // 
            this.buttonApproachPointInSpaceDown.BackColor = System.Drawing.Color.White;
            this.buttonApproachPointInSpaceDown.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonApproachPointInSpaceDown.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonApproachPointInSpaceDown.Location = new System.Drawing.Point(396, 50);
            this.buttonApproachPointInSpaceDown.Name = "buttonApproachPointInSpaceDown";
            this.buttonApproachPointInSpaceDown.Size = new System.Drawing.Size(242, 21);
            this.buttonApproachPointInSpaceDown.TabIndex = 155;
            this.buttonApproachPointInSpaceDown.Text = "Debug Approach Point In Space - Down";
            this.buttonApproachPointInSpaceDown.UseVisualStyleBackColor = false;
            this.buttonApproachPointInSpaceDown.Click += new System.EventHandler(this.buttonApproachPointInSpaceDown_Click);
            // 
            // buttonApproachPointInSpaceUp
            // 
            this.buttonApproachPointInSpaceUp.BackColor = System.Drawing.Color.White;
            this.buttonApproachPointInSpaceUp.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.buttonApproachPointInSpaceUp.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonApproachPointInSpaceUp.Location = new System.Drawing.Point(396, 23);
            this.buttonApproachPointInSpaceUp.Name = "buttonApproachPointInSpaceUp";
            this.buttonApproachPointInSpaceUp.Size = new System.Drawing.Size(242, 21);
            this.buttonApproachPointInSpaceUp.TabIndex = 154;
            this.buttonApproachPointInSpaceUp.Text = "Debug Approach Point In Space - Up";
            this.buttonApproachPointInSpaceUp.UseVisualStyleBackColor = false;
            this.buttonApproachPointInSpaceUp.Click += new System.EventHandler(this.buttonApproachPointInSpaceUp_Click);
            // 
            // DebugAssetsButton
            // 
            this.DebugAssetsButton.BackColor = System.Drawing.Color.White;
            this.DebugAssetsButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.DebugAssetsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DebugAssetsButton.Location = new System.Drawing.Point(12, 212);
            this.DebugAssetsButton.Name = "DebugAssetsButton";
            this.DebugAssetsButton.Size = new System.Drawing.Size(123, 21);
            this.DebugAssetsButton.TabIndex = 153;
            this.DebugAssetsButton.Text = "Debug Assets";
            this.DebugAssetsButton.UseVisualStyleBackColor = false;
            this.DebugAssetsButton.Click += new System.EventHandler(this.DebugAssetsButton_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(12, 185);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(123, 21);
            this.button7.TabIndex = 152;
            this.button7.Text = "Debug Windows";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(12, 158);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(123, 21);
            this.button6.TabIndex = 151;
            this.button6.Text = "Debug Map";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(12, 131);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(123, 21);
            this.button5.TabIndex = 150;
            this.button5.Text = "Debug Channels";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(12, 104);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(123, 21);
            this.button3.TabIndex = 149;
            this.button3.Text = "Debug Scan";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 77);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(123, 21);
            this.button2.TabIndex = 148;
            this.button2.Text = "Debug Skills";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(12, 50);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(123, 21);
            this.button4.TabIndex = 147;
            this.button4.Text = "Debug Modules";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 21);
            this.button1.TabIndex = 146;
            this.button1.Text = "Debug Entities";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DebugControllerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 253);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DebugControllerForm";
            this.Text = "Debug";
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button DebugAssetsButton;
        private System.Windows.Forms.Button buttonApproachPointInSpaceUp;
        private System.Windows.Forms.Button buttonStopMyShip;
        private System.Windows.Forms.Button buttonApproachPointInSpaceWest;
        private System.Windows.Forms.Button buttonApproachPointInSpaceEast;
        private System.Windows.Forms.Button buttonApproachPointInSpaceSouth;
        private System.Windows.Forms.Button buttonApproachPointInSpaceNorth;
        private System.Windows.Forms.Button buttonApproachPointInSpaceDown;
        private System.Windows.Forms.Button DebugCreateNewFleet;
    }
}