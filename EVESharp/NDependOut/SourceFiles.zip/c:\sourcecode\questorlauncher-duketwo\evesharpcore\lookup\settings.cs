﻿extern alias SC;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Xml;
using System.Xml.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Questor.Activities;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.Stats;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;
using SC::SharedComponents.Utility;

namespace EVESharpCore.Lookup
{
    public class Settings
    {
        #region Constructors

        public Settings()
        {
            try
            {
                Interlocked.Increment(ref SettingsInstances);
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception: [" + exception + "]");
            }
        }

        #endregion Constructors

        #region Destructors

        ~Settings()
        {
            Interlocked.Decrement(ref SettingsInstances);
        }

        #endregion Destructors

        #region Fields

        //public List<string> CharacterNamesForMasterToInviteToFleet = new List<string>();
        public static bool CharacterXMLExists = true;

        public static bool CommonXMLExists;

        public static int SettingsInstances;

        public bool DefaultSettingsLoaded = false;

        public List<InventoryItem> ListOfItemsToBuyFromLpStore = new List<InventoryItem>();

        public List<InventoryItem> ListOfItemsToKeepInStock = new List<InventoryItem>();

        public List<InventoryItem> ListOfItemsToTakeToMarket = new List<InventoryItem>();

        public int NumberOfModulesToActivateInCycle = 4;

        //
        // path information - used to load the XML and used in other modules
        //
        public string Path = Util.AssemblyPath;

        /// <summary>
        ///     Singleton implementation
        /// </summary>
        private static readonly Settings _instance = new Settings();

        private static string _characterSettingsPath;
        private static string _commonSettingsPath;
        private DateTime _lastModifiedDateOfMyCommonSettingsFile;
        private DateTime _lastModifiedDateOfMySettingsFile;
        private int SettingsLoadedICount;

        #endregion Fields

        #region Properties

        public static string CharacterSettingsPath
        {
            get
            {
                if (!string.IsNullOrEmpty(_characterSettingsPath)) return _characterSettingsPath;
                //CharacterName-DayOfMonth.xml: ex: JohnDoe-14.xml
                string testCharacterSettingsPath = System.IO.Path.Combine(Instance.Path, "QuestorSettings", Log.FilterPath(ESCache.Instance.EveAccount.CharacterName) + "-" + DateTime.Now.Day + ".xml");

                //CharacterName-DayOfWeek.xml: ex: JohnDoe-Wednesday.xml
                if (!File.Exists(testCharacterSettingsPath))
                {
                    if (DebugConfig.DebugLoadSettings) Log.WriteLine("DateOfMonth [" + DateTime.Now.Day + "] - [" + testCharacterSettingsPath + "] not found");
                    testCharacterSettingsPath = System.IO.Path.Combine(Instance.Path, "QuestorSettings", Log.FilterPath(ESCache.Instance.EveAccount.CharacterName) + "-" + CurrentDayOfTheWeek() + ".xml");
                }

                //CharacterName.xml ex: JohnDoe.xml
                if (!File.Exists(testCharacterSettingsPath))
                {
                    if (DebugConfig.DebugLoadSettings) Log.WriteLine("DayOfWeek [" + CurrentDayOfTheWeek() + "] - [" + testCharacterSettingsPath + "] not found");
                    testCharacterSettingsPath = System.IO.Path.Combine(Instance.Path, "QuestorSettings", Log.FilterPath(ESCache.Instance.EveAccount.CharacterName) + ".xml");
                }

                _characterSettingsPath = testCharacterSettingsPath;
                return _characterSettingsPath;
            }
        }

        public static XElement CharacterSettingsXml { get; set; }

        public static string CommonSettingsFileName //just the filename, no path, with file extension
        {
            get
            {
                try
                {
                    return (string) CharacterSettingsXml.Element("commonSettingsFileName") ?? "common.xml";
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return "common.xml";
                }
            }
        }

        public static string CommonSettingsPath
        {
            get
            {
                try
                {
                    if (!string.IsNullOrEmpty(_commonSettingsPath)) return _commonSettingsPath;

                    // System.IO.Path.GetFileNameWithoutExtension(System.IO.Path.Combine(Instance.Path, "QuestorSettings", Instance.CommonSettingsFileName));
                    string tempCommonSettingsFileName = System.IO.Path.Combine(Instance.Path, "QuestorSettings", NameOfCommonXML + "-" + DateTime.Now.Day + ".xml");

                    //ex: Does common-1.xml exist? if not try to find common-monday.xml
                    if (!File.Exists(tempCommonSettingsFileName))
                    {
                        if (DebugConfig.DebugLoadSettings) Log.WriteLine("DateOfMonth [" + DateTime.Now.Day + "] - [" + _commonSettingsPath + "] not found");
                        tempCommonSettingsFileName = System.IO.Path.Combine(Instance.Path, "QuestorSettings", NameOfCommonXML + "-" + CurrentDayOfTheWeek() + ".xml");
                    }
                    //ex: Does common-monday.xml exist? if not use common.xml
                    if (!File.Exists(tempCommonSettingsFileName))
                    {
                        if (DebugConfig.DebugLoadSettings) Log.WriteLine("DayOfWeek [" + CurrentDayOfTheWeek() + "] - [" + _commonSettingsPath + "] not found");
                        tempCommonSettingsFileName = System.IO.Path.Combine(Instance.Path, "QuestorSettings", NameOfCommonXML + ".xml");
                    }

                    _commonSettingsPath = tempCommonSettingsFileName;
                    return _commonSettingsPath;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return System.IO.Path.Combine(Instance.Path, "QuestorSettings", NameOfCommonXML + ".xml");
                }
            }
        }

        public static XElement CommonSettingsXml { get; set; }
        public static Settings Instance => _instance;

        public static string NameOfCommonXML //full path plus filename without file extension
        {
            get
            {
                try
                {
                    return System.IO.Path.GetFileNameWithoutExtension(System.IO.Path.Combine(Instance.Path, "QuestorSettings", CommonSettingsFileName));
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return string.Empty;
                }
            }
        }

        public int AncillaryShieldBoosterScript { get; private set; }
        public string BookmarkFolder { get; set; }

        //
        // Travel and Undock Settings
        //
        public string BookmarkPrefix { get; set; }

        public bool BuyAmmo { get; private set; }
        public int BuyAmmoStationID { get; private set; }
        public bool BuyLpItems { get; private set; }
        public bool BuyPlex { get; private set; }

        public int CapacitorInjectorScript
        {
            get
            {
                try
                {
                    if (MissionSettings.MissionCapacitorInjectorScript != null && MissionSettings.MissionCapacitorInjectorScript != 0)
                        return (int) MissionSettings.MissionCapacitorInjectorScript;

                    if (GlobalCapacitorInjectorScript != 0)
                        return GlobalCapacitorInjectorScript;

                    return 0;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        //
        // Misc Settings
        //
        public string CharacterMode { get; set; }

        public string CharacterToAcceptInvitesFrom { get; set; }
        public bool CreateCourierContracts { get; private set; }
        public bool CreateDockBookmarksAsNeeded { get; set; }
        public bool CreateUndockBookmarksAsNeeded { get; set; }

        //public bool DefendWhileTraveling { get; set; }
        public bool DetailedCurrentTargetHealthLogging { get; set; }

        public bool Disable3D
        {
            get
            {
                if (ESCache.Instance.EveAccount.ManuallyPausedViaUI)
                    return false;

                return Disable3dGlobal;
            }
        }

        public bool DisableResourceLoad
        {
            get
            {
                if (ESCache.Instance.EveAccount.ManuallyPausedViaUI)
                    return false;

                return DisableResourceLoadGlobal;
            }
        }

        public bool DisableResourceLoadGlobal { get; set; }

        public bool Disable3dGlobal { get; set; }

        //
        // Enable / Disable Major Features that do not have categories of their own below
        //
        public bool EnableStorylines { get; set; }

        public int EnforcedDelayBetweenModuleClicks { get; set; }

        //public bool setEveClientDestinationWhenTraveling { get; set; }
        public string EveServerName { get; set; }

        public bool FinishWhenNotSafe { get; set; }
        public int GlobalCapacitorInjectorScript { get; set; }
        public int GlobalNumberOfCapBoostersToLoad { get; set; }
        public string HighTierLootContainer { get; set; }

        //
        // Storage location for loot, ammo, and bookmarks
        //
        public string HomeBookmarkName { get; set; }

        public bool KeepWeaponsGrouped { get; set; }
        public double LocalBadStandingLevelToConsiderBad { get; set; }

        //
        // Local Watch settings - if enabled
        //
        public int LocalBadStandingPilotsToTolerate { get; set; }

        public string LootContainerName { get; set; }
        public string MiningShipName { get; set; }

        //they are not scripts, but they work the same, but are consumable for our purposes that does not matter
        public int NumberOfCapBoostersToLoad
        {
            get
            {
                try
                {
                    if (MissionSettings.MissionNumberOfCapBoostersToLoad != null && MissionSettings.MissionNumberOfCapBoostersToLoad != 0)
                        return (int) MissionSettings.MissionNumberOfCapBoostersToLoad;

                    if (GlobalNumberOfCapBoostersToLoad != 0)
                        return GlobalNumberOfCapBoostersToLoad;

                    return 0;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return 0;
                }
            }
        }

        public string SafeSpotBookmarkPrefix { get; set; }

        //
        // Ship Names
        //
        public string SalvageShipName { get; set; }

        public int SensorBoosterScript { get; private set; }
        public int SensorDampenerScript { get; private set; }
        public string StationDockBookmarkPrefix { get; set; }
        public string StoryLineBaseBookmark { get; set; }
        public bool StorylineDoNotTryToDoCourierMissions { get; set; }
        public bool StorylineDoNotTryToDoEncounterMissions { get; set; }
        public bool StorylineDoNotTryToDoMiningMissions { get; set; }
        public bool StorylineDoNotTryToDoTradeMissions { get; set; }
        public bool DoNotTryToDoEncounterMissions { get; set; }
        public string StorylineTransportShipName { get; set; }
        public int TrackingComputerScript { get; private set; }

        //
        // Script Settings - TypeIDs for the scripts you would like to use in these modules
        //
        public int TrackingDisruptorScript { get; private set; }

        public int TrackingLinkScript { get; private set; }
        public string TransportShipName { get; set; }
        public string TravelShipName { get; set; }
        public string UndockBookmarkPrefix { get; set; }
        public bool UseCorpAmmoHangar { get; set; }
        public bool UseCorpLootHangar { get; set; }
        public int LootCorpHangarDivisionNumber = 1;
        public int AmmoCorpHangarDivisionNumber = 1;
        public int HighTierLootCorpHangarDivisionNumber = 1;

        public bool UseDockBookmarks { get; set; }

        private bool GlobalUseFittingManager { get; set; }

        public bool UseFittingManager
        {
            get
            {
                if (ESCache.Instance.EveAccount.SelectedController == "AbyssalDeadspaceController")
                {
                    if (DebugConfig.DebugFittingMgr) Log.WriteLine("UseFittingManager we are using AbyssalDeadspaceController return false");
                    return false;
                }

                if (ESCache.Instance.InWormHoleSpace)
                {
                    if (DebugConfig.DebugFittingMgr) Log.WriteLine("UseFittingManager we are in InWormHoleSpace return false");
                    return false;
                }

                if (GlobalUseFittingManager)
                    return true;

                if (DebugConfig.DebugFittingMgr) Log.WriteLine("UseFittingManager is [" + GlobalUseFittingManager + "]");
                return false;
            }
            set
            {
                GlobalUseFittingManager = value;
                if (DebugConfig.DebugFittingMgr) Log.WriteLine("UseFittingManager is now [" + GlobalUseFittingManager + "]");
            }
        }
        public bool UseFleetManager { get; set; }
        public bool UseLocalWatch { get; set; }
        public bool UseUndockBookmarks { get; set; }
        public bool WatchForActiveWars { get; set; }

        #endregion Properties

        #region Methods

        public static void InvalidateCache()
        {
            _characterSettingsPath = null;
            _commonSettingsPath = null;
        }

        public void CreateDirectoriesForLogging()
        {
            try
            {
                Statistics.DroneStatsLogPath = Log.Logpath;
                Statistics.DroneStatslogFile = System.IO.Path.Combine(Statistics.DroneStatsLogPath, ESCache.Instance.EveAccount.CharacterName + ".DroneStats.csv");
                Statistics.MissionAcceptDeclineStatsLogPath = Log.Logpath;
                Statistics.MissionAcceptDeclineStatsLogFile = System.IO.Path.Combine(Statistics.MissionAcceptDeclineStatsLogPath, ESCache.Instance.EveAccount.CharacterName + ".MissionAcceptDecline.csv");

                Statistics.WreckOutOfRangeLootSkipLogPath = Log.Logpath;
                Statistics.WreckOutOfRangeLootSkipLogFile = System.IO.Path.Combine(Statistics.WreckOutOfRangeLootSkipLogPath, ESCache.Instance.EveAccount.CharacterName + ".WreckOutOfRangeLootSkipLog.csv");

                Statistics.WindowStatsLogPath = System.IO.Path.Combine(Log.Logpath, "WindowStats\\");
                Statistics.WindowStatslogFile = System.IO.Path.Combine(Statistics.WindowStatsLogPath,
                    ESCache.Instance.EveAccount.CharacterName + ".WindowStats-DayOfYear[" + DateTime.UtcNow.DayOfYear + "].csv");
                Statistics.WreckLootStatisticsPath = Log.Logpath;
                Statistics.WreckLootStatisticsFile = System.IO.Path.Combine(Statistics.WreckLootStatisticsPath,
                    ESCache.Instance.EveAccount.CharacterName + ".WreckLootStatisticsDump.csv");

                Statistics.MissionStats3LogPath = System.IO.Path.Combine(Log.Logpath, "MissionStats\\");
                Statistics.MissionStats3LogFile = System.IO.Path.Combine(Statistics.MissionStats3LogPath,
                    ESCache.Instance.EveAccount.CharacterName + ".CustomDatedStatistics.csv");
                Statistics.MissionDungeonIdLogPath = System.IO.Path.Combine(Log.Logpath, "MissionStats\\");
                Statistics.MissionDungeonIdLogFile = System.IO.Path.Combine(Statistics.MissionDungeonIdLogPath,
                    ESCache.Instance.EveAccount.CharacterName + "Mission-DungeonId-list.csv");
                Statistics.PocketStatisticsPath = System.IO.Path.Combine(Log.Logpath, "PocketStats\\");
                Statistics.PocketStatisticsFile = System.IO.Path.Combine(Statistics.PocketStatisticsPath,
                    ESCache.Instance.EveAccount.CharacterName + "pocketstats-combined.csv");
                Statistics.PocketObjectStatisticsPath = System.IO.Path.Combine(Log.Logpath, "PocketObjectStats\\");
                Statistics.PocketObjectStatisticsFile = System.IO.Path.Combine(Statistics.PocketObjectStatisticsPath,
                    ESCache.Instance.EveAccount.CharacterName + "PocketObjectStats-combined.csv");
                Statistics.MissionDetailsHtmlPath = System.IO.Path.Combine(Log.Logpath, "MissionDetailsHTML\\");
                Statistics.MissionPocketObjectivesPath = System.IO.Path.Combine(Log.Logpath, "MissionPocketObjectives\\");
            }
            catch (Exception ex)
            {
                Log.WriteLine("Problem creating directory path strings for logs [" + ex + "]");
            }

            try
            {
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Log.LogPath [" + Log.Logpath + "]");
                Directory.CreateDirectory(Log.Logpath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Log.ConsoleLogPath [" + Log.ConsoleLogPath + "]");
                Directory.CreateDirectory(Log.ConsoleLogPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.DroneStatsLogPath [" + Statistics.DroneStatsLogPath + "]");
                Directory.CreateDirectory(Statistics.DroneStatsLogPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.MissionAcceptDeclineStatsLogPath [" + Statistics.MissionAcceptDeclineStatsLogPath + "]");
                Directory.CreateDirectory(Statistics.MissionAcceptDeclineStatsLogPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.WreckLootStatisticsPath [" + Statistics.WreckLootStatisticsPath + "]");
                Directory.CreateDirectory(Statistics.WreckLootStatisticsPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.MissionStats3LogPath [" + Statistics.MissionStats3LogPath + "]");
                Directory.CreateDirectory(Statistics.MissionStats3LogPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.MissionDungeonIdLogPath [" + Statistics.MissionDungeonIdLogPath + "]");
                Directory.CreateDirectory(Statistics.MissionDungeonIdLogPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.PocketStatisticsPath [" + Statistics.PocketStatisticsPath + "]");
                Directory.CreateDirectory(Statistics.PocketStatisticsPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.PocketObjectStatisticsPath [" + Statistics.PocketObjectStatisticsPath + "]");
                Directory.CreateDirectory(Statistics.PocketObjectStatisticsPath);
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("CreateDirectory Statistics.WindowStatsLogPath [" + Statistics.WindowStatsLogPath + "]");
                Directory.CreateDirectory(Statistics.WindowStatsLogPath);
            }
            catch (Exception exception)
            {
                Log.WriteLine("Problem creating directories for logs [" + exception + "]");
            }
            //create all the logging directories even if they are not configured to be used - we can adjust this later if it really bugs people to have some potentially empty directories.
        }

        public void LoadSettings(bool forcereload = false)
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.NextLoadSettings)
                    return;

                Time.Instance.NextLoadSettings = DateTime.UtcNow.AddSeconds(10);

                try
                {
                    bool reloadSettings = true;
                    if (File.Exists(CharacterSettingsPath))
                    {
                        reloadSettings = _lastModifiedDateOfMySettingsFile != File.GetLastWriteTime(CharacterSettingsPath);
                        if (!reloadSettings)
                            if (File.Exists(CommonSettingsPath)) reloadSettings = _lastModifiedDateOfMyCommonSettingsFile != File.GetLastWriteTime(CommonSettingsPath);
                        if (!reloadSettings && forcereload) reloadSettings = true;

                        if (!reloadSettings)
                            return;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }

                if (!File.Exists(CharacterSettingsPath) && !Instance.DefaultSettingsLoaded)
                    //if the settings file does not exist initialize these values. Should we not halt when missing the settings XML?
                {
                    State.CurrentQuestorState = QuestorState.Error;
                    State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.Error;
                    State.CurrentCombatMissionCtrlState = ActionControlState.Error;
                    Log.WriteLine("ERROR: if (!File.Exists(Logging.CharacterSettingsPath) && !Settings.Instance.DefaultSettingsLoaded)");
                }
                else //if the settings file exists - load the characters settings XML
                {
                    CharacterXMLExists = true;

                    using (XmlTextReader reader = new XmlTextReader(CharacterSettingsPath))
                    {
                        reader.EntityHandling = EntityHandling.ExpandEntities;
                        CharacterSettingsXml = XDocument.Load(reader).Root;
                    }

                    if (CharacterSettingsXml == null)
                        Log.WriteLine("unable to find [" + CharacterSettingsPath + "] FATAL ERROR - use the provided settings.xml to create that file.");
                    else
                        try
                        {
                            PushInfoToEveSharpLauncher();
                            if (File.Exists(CharacterSettingsPath)) _lastModifiedDateOfMySettingsFile = File.GetLastWriteTime(CharacterSettingsPath);
                            if (File.Exists(CommonSettingsPath)) _lastModifiedDateOfMyCommonSettingsFile = File.GetLastWriteTime(CommonSettingsPath);
                            CreateDirectoriesForLogging();
                            ReadSettingsFromXML();
                        }
                        catch (Exception ex)
                        {
                            Log.WriteLine("Exception [" + ex + "]");
                        }
                }

                if (!Instance.DefaultSettingsLoaded)
                {
                    SettingsLoadedICount++;
                    if (CommonXMLExists)
                        Log.WriteLine("[" + SettingsLoadedICount + "] Done Loading Settings from [" + CommonSettingsPath + "] and");
                    Log.WriteLine("[" + SettingsLoadedICount + "] Done Loading Settings from [" + CharacterSettingsPath + "]");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Problem creating directories for logs [" + ex + "]");
            }
        }

        public void PushInfoToEveSharpLauncher()
        {
            try
            {
                if (DebugConfig.DebugLoadSettings) Log.WriteLine("Settings: myCharacterId [" + ESCache.Instance.DirectEve.Session.CharacterId + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.myCharacterId), ESCache.Instance.DirectEve.Session.CharacterId.ToString());
                if (ESCache.Instance.DirectEve.Session.SolarSystemId != null)
                {
                    string solarsystem = ESCache.Instance.DirectEve.GetLocationName((long) ESCache.Instance.DirectEve.Session.SolarSystemId);
                    if (DebugConfig.DebugLoadSettings) Log.WriteLine("Settings: SolarSystem [" + solarsystem + "]");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.SolarSystem), solarsystem);
                }

                if (DebugConfig.DebugLoadSettings) Log.WriteLine("Settings: IsOmegaClone [" + ESCache.Instance.DirectEve.Me.IsOmegaClone + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.IsOmegaClone), ESCache.Instance.DirectEve.Me.IsOmegaClone);

                //Log.WriteLine("Settings: SubEnd [" + QCache.Instance.DirectEve.Me.SubTimeEnd + "]");
                //WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(QCache.Instance.EveAccount.CharacterName, nameof(EveAccountSubEnd", QCache.Instance.DirectEve.Me.SubTimeEnd);

                if (DebugConfig.DebugLoadSettings) Log.WriteLine("Settings: IsAtWar [" + ESCache.Instance.DirectEve.Me.IsAtWar + "]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.IsAtWar), ESCache.Instance.DirectEve.Me.IsAtWar);

                if (ESCache.Instance.DirectEve.Me.IsAtWar)
                {
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NextWarCheck), DateTime.UtcNow.AddDays(1));
                    if (ESCache.Instance.InSpace && State.CurrentCombatMissionBehaviorState != CombatMissionsBehaviorState.GotoBase)
                    {
                        Log.WriteLine("Settings: IsAtWar [" + ESCache.Instance.DirectEve.Me.IsAtWar + "] and we are in space. GoToBase");
                        State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.GotoBase;
                        return;
                    }

                    Log.WriteLine("Settings: IsAtWar [" + ESCache.Instance.DirectEve.Me.IsAtWar + "] and we are in station. pausing.");
                    ControllerManager.Instance.SetPause(true);
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public int RandomNumber(int min, int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }

        public void ReadSettingsFromXML()
        {
            try
            {
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.CharName, nameof(EveAccount.RestartOfEveClientNeeded), false);
                Log.WriteLine("Start reading settings from xml");

                if (File.Exists(CommonSettingsPath))
                {
                    Log.WriteLine("Loading Common Settings XML [" + CommonSettingsPath + "]");
                    CommonXMLExists = true;
                    CommonSettingsXml = XDocument.Load(CommonSettingsPath).Root;
                    if (CommonSettingsXml == null)
                        Log.WriteLine("found [" + CommonSettingsPath +
                                      "] but was unable to load it: FATAL ERROR - use the provided settings.xml to create that file.");
                }
                else
                {
                    CommonXMLExists = false;
                    //
                    // if the common XML does not exist, load the characters XML into the CommonSettingsXml just so we can simplify the XML element loading stuff.
                    //
                    Log.WriteLine("Common Settings XML [" + CommonSettingsPath + "] not found.");
                    CommonSettingsXml = XDocument.Load(CharacterSettingsPath).Root;
                }

                if (CommonSettingsXml == null)
                    return;

                // this should never happen as we load the characters xml here if the common xml is missing. adding this does quiet some warnings though

                if (CommonXMLExists)
                    Log.WriteLine("Loading Settings from [" + CommonSettingsPath + "] and");
                Log.WriteLine("Loading Settings from [" + CharacterSettingsPath + "]");
                //
                // these are listed by feature and should likely be re-ordered to reflect that
                //

                //
                // Debug Settings
                //
                DebugConfig.LoadSettings(CharacterSettingsXml, CommonSettingsXml);

                DetailedCurrentTargetHealthLogging = (bool?) CharacterSettingsXml.Element("detailedCurrentTargetHealthLogging") ??
                                                     (bool?) CommonSettingsXml.Element("detailedCurrentTargetHealthLogging") ?? false;
                //Log.WriteLine("LoadSettings: Settings: detailedCurrentTargetHealthLogging [" + DetailedCurrentTargetHealthLogging + "]");
                CreateCourierContracts = (bool?) CharacterSettingsXml.Element("createCourierContracts") ?? (bool?) CommonSettingsXml.Element("createCourierContracts") ?? false;
                //Log.WriteLine("LoadSettings: Settings: createCourierContracts [" + CreateCourierContracts + "]");
                BuyPlex = (bool?) CharacterSettingsXml.Element("buyPlex") ?? (bool?) CommonSettingsXml.Element("buyPlex") ?? false;
                //Log.WriteLine("LoadSettings: Settings: buyPlex [" + BuyPlex + "]");
                BuyAmmo = (bool?) CharacterSettingsXml.Element("buyAmmo") ?? (bool?) CommonSettingsXml.Element("buyAmmo") ?? false;
                //Log.WriteLine("LoadSettings: Settings: buyAmmo [" + BuyAmmo + "]");
                BuyLpItems = (bool?) CharacterSettingsXml.Element("buyLpItems") ?? (bool?) CommonSettingsXml.Element("buyLpItems") ?? false;
                //Log.WriteLine("LoadSettings: Settings: buyLpItems [" + BuyLpItems + "]");
                BuyAmmoStationID = (int?) CharacterSettingsXml.Element("buyAmmoStationID") ?? (int?) CommonSettingsXml.Element("buyAmmoStationID") ?? 60003760;
                //Log.WriteLine("LoadSettings: Settings: buyAmmoStationID [" + BuyAmmoStationID + "]");
                //DefendWhileTraveling = (bool?)CharacterSettingsXml.Element("defendWhileTraveling") ??
                //                       (bool?)CommonSettingsXml.Element("defendWhileTraveling") ?? true;

                CharacterToAcceptInvitesFrom = (string) CharacterSettingsXml.Element("characterToAcceptInvitesFrom") ??
                                               (string) CommonSettingsXml.Element("characterToAcceptInvitesFrom") ?? string.Empty;
                //Log.WriteLine("LoadSettings: Settings: characterToAcceptInvitesFrom [" + CharacterToAcceptInvitesFrom + "]");
                EveServerName = (string) CharacterSettingsXml.Element("eveServerName") ?? (string) CommonSettingsXml.Element("eveServerName") ?? "Tranquility";
                EnforcedDelayBetweenModuleClicks = (int?) CharacterSettingsXml.Element("enforcedDelayBetweenModuleClicks") ??
                                                   (int?) CommonSettingsXml.Element("enforcedDelayBetweenModuleClicks") ?? 3000;

                //
                // Misc Settings
                //
                CharacterMode = (string) CharacterSettingsXml.Element("characterMode") ??
                                (string) CommonSettingsXml.Element("characterMode") ?? "Combat Missions".ToLower();

                //other option is "salvage"

                if (Instance.CharacterMode.ToLower() == "dps".ToLower())
                    Instance.CharacterMode = "Combat Missions".ToLower();

                Disable3dGlobal = (bool?) CharacterSettingsXml.Element("disable3D") ?? (bool?) CommonSettingsXml.Element("disable3D") ?? true;
                Log.WriteLine("LoadSettings: Settings: disable3D [" + Disable3dGlobal + "]");

                DisableResourceLoadGlobal = (bool?)CharacterSettingsXml.Element("disableResourceLoad") ?? (bool?)CommonSettingsXml.Element("disableResourceLoad") ?? true;
                Log.WriteLine("LoadSettings: Settings: disableResourceLoad [" + DisableResourceLoadGlobal + "]");

                try
                {
                    UseCorpAmmoHangar =
                        (bool?)CharacterSettingsXml.Element("useCorpAmmoHangar") ??
                        (bool?)CommonSettingsXml.Element("useCorpAmmoHangar") ?? false;
                    Log.WriteLine("LoadSettings: Settings: useCorpAmmoHangar [" + UseCorpAmmoHangar + "]");

                    UseCorpLootHangar =
                        (bool?)CharacterSettingsXml.Element("useCorpLootHangar") ??
                        (bool?)CommonSettingsXml.Element("useCorpLootHangar") ?? false;
                    Log.WriteLine("LoadSettings: Settings: useCorpLootHangar [" + UseCorpLootHangar + "]");

                    UseFittingManager = (bool?) CharacterSettingsXml.Element("UseFittingManager") ??
                                        (bool?) CommonSettingsXml.Element("UseFittingManager") ?? true;
                    Log.WriteLine("LoadSettings: Settings: UseFittingManager [" + GlobalUseFittingManager + "]");
                    UseFleetManager = (bool?) CharacterSettingsXml.Element("UseFleetManager") ??
                                      (bool?) CommonSettingsXml.Element("UseFleetManager") ?? true;
                    //Log.WriteLine("LoadSettings: Settings: UseFleetManager [" + UseFleetManager + "]");
                    EnableStorylines = (bool?) CharacterSettingsXml.Element("enableStorylines") ??
                                       (bool?) CommonSettingsXml.Element("enableStorylines") ?? false;
                    Log.WriteLine("LoadSettings: Settings: enableStorylines [" + EnableStorylines + "]");
                    StorylineDoNotTryToDoEncounterMissions = (bool?) CharacterSettingsXml.Element("storylineDoNotTryToDoEncounterMissions") ??
                                                             (bool?) CommonSettingsXml.Element("storylineDoNotTryToDoEncounterMissions") ?? false;
                    //Log.WriteLine("LoadSettings: Settings: storylineDoNotTryToDoEncounterMissions [" + StorylineDoNotTryToDoEncounterMissions + "]");
                    StorylineDoNotTryToDoCourierMissions = (bool?) CharacterSettingsXml.Element("storylineDoNotTryToDoCourierMissions") ??
                                                           (bool?) CommonSettingsXml.Element("storylineDoNotTryToDoCourierMissions") ?? false;
                    //Log.WriteLine("LoadSettings: Settings: storylineDoNotTryToDoCourierMissions [" + StorylineDoNotTryToDoCourierMissions + "]");
                    StorylineDoNotTryToDoTradeMissions = (bool?) CharacterSettingsXml.Element("storylineDoNotTryToDoTradeMissions") ??
                                                         (bool?) CommonSettingsXml.Element("storylineDoNotTryToDoTradeMissions") ?? false;
                    DoNotTryToDoEncounterMissions = (bool?)CharacterSettingsXml.Element("doNotTryToDoEncounterMissions") ??
                                                         (bool?)CommonSettingsXml.Element("doNotTryToDoEncounterMissions") ?? false;
                    //Log.WriteLine("LoadSettings: Settings: storylineDoNotTryToDoTradeMissions [" + StorylineDoNotTryToDoTradeMissions + "]");
                    StorylineDoNotTryToDoMiningMissions = (bool?) CharacterSettingsXml.Element("storylineDoNotTryToDoMiningMissions") ??
                                                          (bool?) CommonSettingsXml.Element("storylineDoNotTryToDoMiningMissions") ?? false;
                    //Log.WriteLine("LoadSettings: Settings: storylineDoNotTryToDoMiningMissions [" + StorylineDoNotTryToDoMiningMissions + "]");
                    StoryLineBaseBookmark = (string) CharacterSettingsXml.Element("storyLineBaseBookmark") ??
                                            (string) CommonSettingsXml.Element("storyLineBaseBookmark") ?? string.Empty;
                    UseLocalWatch = (bool?) CharacterSettingsXml.Element("UseLocalWatch") ?? (bool?) CommonSettingsXml.Element("UseLocalWatch") ?? true;
                    //Log.WriteLine("LoadSettings: Settings: UseLocalWatch [" + UseLocalWatch + "]");
                    WatchForActiveWars = (bool?) CharacterSettingsXml.Element("watchForActiveWars") ??
                                         (bool?) CommonSettingsXml.Element("watchForActiveWars") ?? true;
                    //Log.WriteLine("LoadSettings: Settings: watchForActiveWars [" + WatchForActiveWars + "]");
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Major Feature Settings: Exception [" + exception + "]");
                }

                try
                {
                    Log.WriteLine("LoadSettings: CacheHangars");

                    AmmoCorpHangarDivisionNumber =
                        (int?)CharacterSettingsXml.Element("ammoCorpHangarDivisionNumber") ?? (int?)CharacterSettingsXml.Element("ammoCorpHangarDivisionNumber") ??
                        (int?)CommonSettingsXml.Element("ammoCorpHangarDivisionNumber") ?? (int?)CommonSettingsXml.Element("ammoCorpHangarDivisionNumber") ?? 1;
                    Log.WriteLine("LoadSettings: CacheHangars: AmmoCorpHangarDivisionNumber [" + AmmoCorpHangarDivisionNumber + "]");
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                    AmmoCorpHangarDivisionNumber = 1;
                    Log.WriteLine("LoadSettings: CacheHangars: AmmoCorpHangarDivisionNumber [" + AmmoCorpHangarDivisionNumber + "]");
                }
                try
                {
                    LootCorpHangarDivisionNumber =
                        (int?) CharacterSettingsXml.Element("lootCorpHangarDivisionNumber") ?? (int?) CharacterSettingsXml.Element("lootCorpHangarDivisionNumber") ??
                        (int?) CommonSettingsXml.Element("lootCorpHangarDivisionNumber") ?? (int?) CommonSettingsXml.Element("lootCorpHangarDivisionNumber") ?? 1;
                    Log.WriteLine("LoadSettings: CacheHangars: LootCorpHangarDivisionNumber [" + LootCorpHangarDivisionNumber + "]");
                }
                catch (Exception)
                {
                    //Log.WriteLine("Exception [" + exception + "]");
                    LootCorpHangarDivisionNumber = 1;
                    Log.WriteLine("LoadSettings: CacheHangars: LootCorpHangarDivisionNumber [" + LootCorpHangarDivisionNumber + "]");
                }
                try
                {
                    HighTierLootCorpHangarDivisionNumber =
                        (int?)CharacterSettingsXml.Element("highTierLootCorpHangarDivisionNumber") ?? (int?)CharacterSettingsXml.Element("highTierLootCorpHangarDivisionNumber") ??
                        (int?)CommonSettingsXml.Element("highTierLootCorpHangarDivisionNumber") ?? (int?)CommonSettingsXml.Element("highTierLootCorpHangarDivisionNumber") ?? 1;
                    Log.WriteLine("LoadSettings: CacheHangars: HighTierLootCorpHangarDivisionNumber [" + HighTierLootCorpHangarDivisionNumber + "]");
                }
                catch (Exception)
                {
                    //Log.WriteLine("Exception [" + exception + "]");
                    HighTierLootCorpHangarDivisionNumber = 1;
                    Log.WriteLine("LoadSettings: CacheHangars: HighTierLootCorpHangarDivisionNumber [" + HighTierLootCorpHangarDivisionNumber + "]");
                }


                //
                // Local Watch Settings - if enabled
                //
                try
                {
                    //LocalBadStandingPilotsToTolerate = (int?) CharacterSettingsXml.Element("LocalBadStandingPilotsToTolerate") ??
                    //                                   (int?) CommonSettingsXml.Element("LocalBadStandingPilotsToTolerate") ?? 1;
                    //Log.WriteLine("LoadSettings: Settings: LocalBadStandingPilotsToTolerate [" + LocalBadStandingPilotsToTolerate + "]");
                    //LocalBadStandingLevelToConsiderBad = (double?) CharacterSettingsXml.Element("LocalBadStandingLevelToConsiderBad") ??
                    //                                     (double?) CommonSettingsXml.Element("LocalBadStandingLevelToConsiderBad") ?? -0.1;
                    //Log.WriteLine("LoadSettings: Settings: LocalBadStandingLevelToConsiderBad [" + LocalBadStandingLevelToConsiderBad + "]");
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Local watch Settings: Exception [" + exception + "]");
                }


                //used in value calculations

                //
                // Undock settings
                //
                UndockBookmarkPrefix = (string) CharacterSettingsXml.Element("stationUndockPrefix") ?? (string) CharacterSettingsXml.Element("stationundockprefix") ??
                                       (string) CommonSettingsXml.Element("stationUndockPrefix") ?? (string) CommonSettingsXml.Element("stationundockprefix") ??
                                       (string) CharacterSettingsXml.Element("undockprefix") ?? (string) CharacterSettingsXml.Element("undockPrefix") ??
                                       (string) CommonSettingsXml.Element("undockprefix") ?? (string) CommonSettingsXml.Element("undockPrefix") ??
                                       (string) CharacterSettingsXml.Element("bookmarkWarpOut") ?? (string) CommonSettingsXml.Element("bookmarkWarpOut") ?? "insta";
                Log.WriteLine("LoadSettings: Settings: stationUndockPrefix [" + UndockBookmarkPrefix + "]");
                CreateUndockBookmarksAsNeeded = (bool?) CharacterSettingsXml.Element("createUndockBookmarksAsNeeded") ?? (bool?) CharacterSettingsXml.Element("createundockbookmarksasneeded") ??
                                                (bool?) CommonSettingsXml.Element("createUndockBookmarksAsNeeded") ?? (bool?) CommonSettingsXml.Element("createundockbookmarksasneeded") ?? false;
                Log.WriteLine("LoadSettings: Settings: CreateUndockBookmarksAsNeeded [" + CreateUndockBookmarksAsNeeded + "]");
                CreateDockBookmarksAsNeeded = (bool?) CharacterSettingsXml.Element("createDockBookmarksAsNeeded") ?? (bool?) CharacterSettingsXml.Element("createdockbookmarksasneeded") ??
                                              (bool?) CommonSettingsXml.Element("createDockBookmarksAsNeeded") ?? (bool?) CommonSettingsXml.Element("createdockbookmarksasneeded") ?? false;
                Log.WriteLine("LoadSettings: Settings: createDockBookmarksAsNeeded [" + CreateDockBookmarksAsNeeded + "]");
                UseUndockBookmarks = (bool?) CharacterSettingsXml.Element("useUndockBookmarks") ?? (bool?) CharacterSettingsXml.Element("useundockbookmarks") ??
                                     (bool?) CommonSettingsXml.Element("useUndockBookmarks") ?? (bool?) CommonSettingsXml.Element("useundockbookmarks") ?? false;
                Log.WriteLine("LoadSettings: Settings: useUndockBookmarks [" + UseUndockBookmarks + "]");
                UseDockBookmarks =
                    (bool?) CharacterSettingsXml.Element("useDockBookmarks") ?? (bool?) CharacterSettingsXml.Element("usedockbookmarks") ??
                    (bool?) CommonSettingsXml.Element("useDockBookmarks") ?? (bool?) CommonSettingsXml.Element("usedockbookmarks") ?? false;
                Log.WriteLine("LoadSettings: Settings: useDockBookmarks [" + UseDockBookmarks + "]");
                //
                // Ship Names
                //
                try
                {
                    SalvageShipName = (string) CharacterSettingsXml.Element("salvageShipName") ??
                                      (string) CommonSettingsXml.Element("salvageShipName") ?? "My Destroyer of salvage";
                    Log.WriteLine("LoadSettings: Settings: salvageShipName [" + SalvageShipName + "]");
                    TransportShipName = (string) CharacterSettingsXml.Element("transportShipName") ??
                                        (string) CommonSettingsXml.Element("transportShipName") ?? "My Hauler of transportation";
                    Log.WriteLine("LoadSettings: Settings: transportShipName [" + TransportShipName + "]");
                    StorylineTransportShipName = (string) CharacterSettingsXml.Element("storylineTransportShipName") ??
                                                 (string) CommonSettingsXml.Element("storylineTransportShipName") ?? TransportShipName;
                    Log.WriteLine("LoadSettings: Settings: storylineTransportShipName [" + StorylineTransportShipName + "]");
                    TravelShipName = (string) CharacterSettingsXml.Element("travelShipName") ??
                                     (string) CommonSettingsXml.Element("travelShipName") ?? "My Shuttle of traveling";
                    Log.WriteLine("LoadSettings: Settings: travelShipName [" + TravelShipName + "]");
                    MiningShipName = (string) CharacterSettingsXml.Element("miningShipName") ??
                                     (string) CommonSettingsXml.Element("miningShipName") ?? "My Exhumer of Destruction";
                    Log.WriteLine("LoadSettings: Settings: miningShipName [" + MiningShipName + "]");
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Ship Name Settings [" + exception + "]");
                }

                //
                // Storage Location for Loot, DefinedAmmoTypes, Bookmarks
                //
                try
                {
                    HomeBookmarkName = (string) CharacterSettingsXml.Element("homeBookmarkName") ??
                                       (string) CommonSettingsXml.Element("homeBookmarkName") ?? "myHomeBookmark";
                    Log.WriteLine("LoadSettings: Settings: homeBookmarkName [" + HomeBookmarkName + "]");
                    LootContainerName = (string) CharacterSettingsXml.Element("lootContainer") ?? (string) CommonSettingsXml.Element("lootContainer");
                    if (LootContainerName != null)
                        LootContainerName = LootContainerName.ToLower();
                    HighTierLootContainer = (string) CharacterSettingsXml.Element("highValueLootContainer") ??
                                            (string) CommonSettingsXml.Element("highValueLootContainer") ?? "FactionLoot";
                    if (HighTierLootContainer != null)
                        HighTierLootContainer = HighTierLootContainer.ToLower();
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Hangar Settings [" + exception + "]");
                }

                try
                {
                    BookmarkPrefix = (string) CharacterSettingsXml.Element("bookmarkPrefix") ??
                                     (string) CommonSettingsXml.Element("bookmarkPrefix") ?? "Salvage:";
                    Log.WriteLine("LoadSettings: Settings: bookmarkPrefix [" + BookmarkPrefix + "]");
                    StationDockBookmarkPrefix = (string) CharacterSettingsXml.Element("stationDockBookmarkPrefix") ??
                                                (string) CommonSettingsXml.Element("stationDockBookmarkPrefix") ?? "Undock @ 0";
                    Log.WriteLine("LoadSettings: Settings: stationDockBookmarkPrefix [" + StationDockBookmarkPrefix + "]");
                    SafeSpotBookmarkPrefix = (string) CharacterSettingsXml.Element("safeSpotBookmarkPrefix") ??
                                             (string) CommonSettingsXml.Element("safeSpotBookmarkPrefix") ?? "safespot";
                    Log.WriteLine("LoadSettings: Settings: safeSpotBookmarkPrefix [" + SafeSpotBookmarkPrefix + "]");
                    BookmarkFolder = (string) CharacterSettingsXml.Element("bookmarkFolder") ??
                                     (string) CommonSettingsXml.Element("bookmarkFolder") ?? "Salvage:";
                    Log.WriteLine("LoadSettings: Settings: bookmarkFolder [" + BookmarkFolder + "]");
                    KeepWeaponsGrouped = (bool?) CharacterSettingsXml.Element("keepWeaponsGrouped") ??
                                         (bool?) CommonSettingsXml.Element("keepWeaponsGrouped") ??
                                         false;
                    Log.WriteLine("LoadSettings: Settings: keepWeaponsGrouped [" + KeepWeaponsGrouped + "]");
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Hangar Settings [" + exception + "]");
                }

                //
                // Script and Shield and Armor Repair Settings - TypeIDs for the scripts you would like to use in these modules
                //
                try
                {
                    TrackingDisruptorScript = (int?) CharacterSettingsXml.Element("trackingDisruptorScript") ??
                                              (int?) CommonSettingsXml.Element("trackingDisruptorScript") ?? (int) TypeID.TrackingSpeedDisruptionScript;
                    Log.WriteLine("LoadSettings: Settings: TrackingDisruptorScript [" + TrackingDisruptorScript + "]");
                    TrackingComputerScript = (int?) CharacterSettingsXml.Element("trackingComputerScript") ??
                                             (int?) CommonSettingsXml.Element("trackingComputerScript") ?? (int) TypeID.TrackingSpeedScript;
                    Log.WriteLine("LoadSettings: Settings: TrackingComputerScript [" + TrackingComputerScript + "]");
                    TrackingLinkScript = (int?) CharacterSettingsXml.Element("trackingLinkScript") ??
                                         (int?) CommonSettingsXml.Element("trackingLinkScript") ?? (int) TypeID.TrackingSpeedScript;
                    Log.WriteLine("LoadSettings: Settings: TrackingLinkScript [" + TrackingLinkScript + "]");
                    SensorBoosterScript = (int?) CharacterSettingsXml.Element("sensorBoosterScript") ??
                                          (int?) CommonSettingsXml.Element("sensorBoosterScript") ?? (int) TypeID.TargetingRangeScript;
                    Log.WriteLine("LoadSettings: Settings: SensorBoosterScript [" + SensorBoosterScript + "]");
                    SensorDampenerScript = (int?) CharacterSettingsXml.Element("sensorDampenerScript") ??
                                           (int?) CommonSettingsXml.Element("sensorDampenerScript") ?? (int) TypeID.TargetingRangeDampeningScript;
                    Log.WriteLine("LoadSettings: Settings: SensorDampenerScript [" + SensorDampenerScript + "]");
                    AncillaryShieldBoosterScript = (int?) CharacterSettingsXml.Element("ancillaryShieldBoosterScript") ??
                                                   (int?) CommonSettingsXml.Element("ancillaryShieldBoosterScript") ??
                                                   (int) TypeID.AncillaryShieldBoosterScript;
                    Log.WriteLine("LoadSettings: Settings: AncillaryShieldBoosterScript [" + AncillaryShieldBoosterScript + "]");
                    GlobalCapacitorInjectorScript = (int?) CharacterSettingsXml.Element("capacitorInjectorScript") ??
                                                    (int?) CommonSettingsXml.Element("capacitorInjectorScript") ?? 0;
                    GlobalNumberOfCapBoostersToLoad = (int?) CharacterSettingsXml.Element("capacitorInjectorToLoad") ??
                                                      (int?) CommonSettingsXml.Element("capacitorInjectorToLoad") ??
                                                      (int?) CharacterSettingsXml.Element("capBoosterToLoad") ??
                                                      (int?) CommonSettingsXml.Element("capBoosterToLoad") ?? 0;
                    Log.WriteLine("LoadSettings: Settings: capacitorInjectorToLoad [" + GlobalNumberOfCapBoostersToLoad + "]");
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Script and Booster Settings [" + exception + "]");
                }

                try
                {
                    if (MissionSettings.SelectedControllerUsesCombatMissionsBehavior)
                    {
                        MissionSettings.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                        CourierContractController.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                        AgentInteraction.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    }
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error SelectedControllerUsesCombatMissionsBehavior Settings [" + exception + "]");
                }

                try
                {
                    if (ESCache.Instance.EveAccount.SelectedController == "AbyssalDeadspaceController")
                       AbyssalDeadspaceBehavior.LoadSettings(CharacterSettingsXml, CommonSettingsXml);

                    if (ESCache.Instance.EveAccount.SelectedController == "FleetAbyssalDeadspaceController")
                        AbyssalDeadspaceBehavior.LoadSettings(CharacterSettingsXml, CommonSettingsXml);

                    if (ESCache.Instance.EveAccount.SelectedController == "HighSecAnomalyController")
                        HighSecAnomalyBehavior.LoadSettings(CharacterSettingsXml, CommonSettingsXml);

                    if (ESCache.Instance.EveAccount.SelectedController == "MarketAdjustController")
                        MarketAdjustBehavior.LoadSettings(CharacterSettingsXml, CommonSettingsXml);

                    if (ESCache.Instance.EveAccount.SelectedController == "MonitorGridController")
                        MonitorGridController.LoadSettings(CharacterSettingsXml, CommonSettingsXml);

                    if (ESCache.Instance.EveAccount.SelectedController == "WSpaceScoutController")
                        WSpaceScoutBehavior.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                }

                try
                {
                    Arm.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    Salvage.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    Combat.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    Drones.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    NavigateOnGrid.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    Defense.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    Panic.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    SkillQueue.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                    Traveler.LoadSettings(CharacterSettingsXml, CommonSettingsXml);
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception [" + exception + "]");
                }

                try
                {
                    //
                    // Items to buy on market and bring to home station (if needed)
                    //
                    ListOfItemsToBuyFromLpStore = new List<InventoryItem>();
                    XElement xmlListOfItemsToBuyFromLpStore = CharacterSettingsXml.Element("itemsToBuyFromLpStore") ?? CommonSettingsXml.Element("itemsToBuyFromLpStore");
                    if (xmlListOfItemsToBuyFromLpStore != null)
                    {
                        int itemNum = 0;
                        foreach (XElement item in xmlListOfItemsToBuyFromLpStore.Elements("itemToBuyFromLpStore"))
                        {
                            itemNum++;
                            InventoryItem _itemToBuy = new InventoryItem(item);
                            Log.WriteLine("ListOfItemsToBuyFromLpStore: [" + itemNum + "][" + _itemToBuy.Name + "][" + _itemToBuy.TypeId + "][" + _itemToBuy.Quantity + "]");
                            ListOfItemsToBuyFromLpStore.Add(_itemToBuy);
                        }
                    }

                    //
                    // Items to buy on market and bring to home station (if needed)
                    //
                    ListOfItemsToKeepInStock = new List<InventoryItem>();
                    XElement xmlStuffToKeepInStock = CharacterSettingsXml.Element("itemsToKeepInStock") ?? CommonSettingsXml.Element("itemsToKeepInStock");

                    if (xmlStuffToKeepInStock != null)
                    {
                        int itemNum = 0;
                        foreach (XElement item in xmlStuffToKeepInStock.Elements("itemToKeepInStock"))
                        {
                            itemNum++;
                            InventoryItem _itemToHaul = new InventoryItem(item);
                            Log.WriteLine("ListOfItemsToKeepInStock: [" + itemNum + "][" + _itemToHaul.Name + "][" + _itemToHaul.TypeId + "][" + _itemToHaul.Quantity + "]");
                            ListOfItemsToKeepInStock.Add(_itemToHaul);
                        }
                    }

                    //
                    // Items to bring from home station to market station (if available)
                    //
                    ListOfItemsToTakeToMarket = new List<InventoryItem>();
                    XElement xmlStuffToTakeTomarket = CharacterSettingsXml.Element("itemsToTakeToMarket") ?? CommonSettingsXml.Element("itemsToTakeToMarket");

                    if (xmlStuffToTakeTomarket != null)
                    {
                        int itemNum = 0;
                        foreach (XElement item in xmlStuffToTakeTomarket.Elements("itemToTakeToMarket"))
                        {
                            itemNum++;
                            InventoryItem _itemToHaul = new InventoryItem(item);
                            Log.WriteLine("ListOfItemsToTakeToMarket: [" + itemNum + "][" + _itemToHaul.Name + "][" + _itemToHaul.TypeId + "]");
                            ListOfItemsToTakeToMarket.Add(_itemToHaul);
                        }
                    }
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Error Loading Settings [" + exception + "]");
                }

                //
                // Enable / Disable the different types of logging that are available
                //
                Statistics.DroneStatsLog = (bool?) CharacterSettingsXml.Element("DroneStatsLog") ?? (bool?) CommonSettingsXml.Element("DroneStatsLog") ?? true;
                Statistics.WreckLootStatistics = (bool?) CharacterSettingsXml.Element("WreckLootStatistics") ??
                                                 (bool?) CommonSettingsXml.Element("WreckLootStatistics") ?? true;
                Statistics.MissionDungeonIdLog = (bool?) CharacterSettingsXml.Element("MissionDungeonIdLog") ??
                                                 (bool?) CommonSettingsXml.Element("MissionDungeonIdLog") ?? true;
                Statistics.PocketStatistics = (bool?) CharacterSettingsXml.Element("PocketStatistics") ??
                                              (bool?) CommonSettingsXml.Element("PocketStatistics") ?? true;
                Statistics.PocketStatsUseIndividualFilesPerPocket = (bool?) CharacterSettingsXml.Element("PocketStatsUseIndividualFilesPerPocket") ??
                                                                    (bool?) CommonSettingsXml.Element("PocketStatsUseIndividualFilesPerPocket") ?? true;
                Statistics.PocketObjectStatisticsLog = (bool?) CharacterSettingsXml.Element("PocketObjectStatisticsLog") ??
                                                       (bool?) CommonSettingsXml.Element("PocketObjectStatisticsLog") ?? true;
                Statistics.WindowStatsLog = (bool?) CharacterSettingsXml.Element("WindowStatsLog") ??
                                            (bool?) CommonSettingsXml.Element("WindowStatsLog") ?? true;
                Statistics.IskPerLP = (double?) CharacterSettingsXml.Element("IskPerLP") ?? (double?) CommonSettingsXml.Element("IskPerLP") ?? 500;
            }
            catch (Exception exception)
            {
                Log.WriteLine("ReadSettingsFromXML: Exception [" + exception + "]");
            }
        }

        public bool ReturnBoolSetting(bool? CharacterXMLBool, bool? CommonXMLBool, bool GuiSettingBool)
        {
            if (CharacterXMLBool != null)
                return (bool) CharacterXMLBool;

            if (CommonXMLBool != null)
                return (bool) CommonXMLBool;

            return GuiSettingBool;
        }

        private static string CurrentDayOfTheWeek()
        {
            try
            {
                string DayOfTheWeek = string.Empty;
                int day = (int) DateTime.Now.DayOfWeek == 0 ? 7 : (int) DateTime.Now.DayOfWeek;
                switch (day)
                {
                    case 1: //Monday
                        DayOfTheWeek = "monday";
                        return DayOfTheWeek;

                    case 2: //Tuesday
                        DayOfTheWeek = "tuesday";
                        return DayOfTheWeek;

                    case 3: //Wednesday
                        DayOfTheWeek = "wednesday";
                        return DayOfTheWeek;

                    case 4: //Thursday
                        DayOfTheWeek = "thursday";
                        return DayOfTheWeek;

                    case 5: //Friday
                        DayOfTheWeek = "friday";
                        return DayOfTheWeek;

                    case 6: //Saturday
                        DayOfTheWeek = "saturday";
                        return DayOfTheWeek;

                    case 7: //Sunday
                        DayOfTheWeek = "sunday";
                        return DayOfTheWeek;
                }

                return string.Empty;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [ " + ex + " ]");
                return string.Empty;
            }
        }

        #endregion Methods
    }
}