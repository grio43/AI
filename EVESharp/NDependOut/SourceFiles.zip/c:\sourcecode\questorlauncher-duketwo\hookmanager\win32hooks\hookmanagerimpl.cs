﻿using EasyHook;
using SharedComponents.EVE;
using SharedComponents.IPC;
using SharedComponents.Utility;
using SharedComponents.Utility.AsyncLogQueue;
using SharedComponents.WinApiUtil;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HookManager.Win32Hooks
{
    public class HookManagerImpl
    {
        #region Constructors

        public HookManagerImpl()
        {
            _controllerList = new List<IHook>();

            try
            {
                var files = Directory.GetFiles(AssemblyPath, "*.exe", SearchOption.TopDirectoryOnly);
                foreach (var f in files)
                {
                    var k = Path.GetFileNameWithoutExtension(f.ToLower());
                    ExeNamesToHide.Add(k);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        #endregion Constructors

        #region Fields

        public static List<string> DirectoryBlackList = new List<string>(new string[] { });
        public static List<string> DirectoryWhiteListRead = new List<string>(new string[] { });
        public static List<string> DirectoryWhiteListWrite = new List<string>(new string[] { });

        public static List<string> ExeNamesToHide =
            new List<string>(new string[] { });

        public static List<string> FileNamesToHide;

        public static List<string> FileWhiteList =
            new List<string>(new string[] { "comctl32", "kernel32", "dbghelp", "wtsapi", "ntdll", "psapi", "blue", "python27" });

        public AppDomain QAppDomain = null;
        public Thread t = null;
        private static readonly HookManagerImpl _instance = new HookManagerImpl();
        private static AsyncLogQueue _asyncLogQueue;
        private static object _asyncLogQueueLock = new object();
        private static string _getLogFileName;
        private string _assemblyPath;

        private List<IHook> _controllerList;
        private EveAccount _EveAccount = null;
        private IntPtr? EveHwndValue = null;
        private DateTime LastEveAccountPoll = DateTime.MinValue;
        private IntPtr? QuestorHwndValue = null;

        #endregion Fields



        #region Properties

        public static AsyncLogQueue AsyncLogQueue
        {
            get
            {
                lock (_asyncLogQueueLock)
                {
                    if (_asyncLogQueue == null)
                    {
                        _asyncLogQueue = new AsyncLogQueue();
                    }
                    return _asyncLogQueue;
                }
            }
        }

        public static HookManagerImpl Instance { get; } = new HookManagerImpl();

        public string AssemblyPath
        {
            get
            {
                if (_assemblyPath == null)
                    _assemblyPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                return _assemblyPath;
            }
        }

        public string CharName { get; set; }
        public string CurrentProcName => _currentProcName ?? (_currentProcName = Process.GetCurrentProcess().ProcessName.ToLower());

        public EveAccount EveAccount
        {
            get
            {
                if (_EveAccount == null || LastEveAccountPoll.AddMilliseconds(1000) < DateTime.UtcNow)
                {
                    LastEveAccountPoll = DateTime.UtcNow;
                    try
                    {
                        var ret = WCFClient.Instance.GetPipeProxy.GetEveAccount(CharName);
                        if (ret != null)
                        {
                            _EveAccount = ret;
                            return _EveAccount;
                        }

                        Cache.Instance.Log("HookManagerImpl: EveAccount: GetEveAccount returned null");
                        return null;
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        Debug.WriteLine(e);
                    }
                }

                return _EveAccount;
            }
        }

        public IntPtr EveHWnd
        {
            get
            {
                if (EveHwndValue == null || !WinApiUtil.IsValidHWnd((IntPtr)EveHwndValue))
                    try
                    {
                        EveHwndValue = (IntPtr)Instance.EveAccount.EveHWnd;
                    }
                    catch (Exception)
                    {
                        if (EveHwndValue != null)
                            return EveHwndValue.Value;
                        return IntPtr.Zero;
                    }

                return (IntPtr)EveHwndValue;
            }
        }

        public IntPtr EVESharpCoreFormHWnd
        {
            get
            {
                if (QuestorHwndValue == null || !WinApiUtil.IsValidHWnd((IntPtr)QuestorHwndValue))
                    try
                    {
                        QuestorHwndValue = (IntPtr)Instance.EveAccount.EVESharpCoreFormHWnd;
                    }
                    catch (Exception)
                    {
                        if (QuestorHwndValue != null)
                            return (IntPtr)QuestorHwndValue;
                        return IntPtr.Zero;
                    }

                return (IntPtr)QuestorHwndValue;
            }
        }

        public bool EveWndShown { get; set; }
        public bool IsInjectedIntoEve => CurrentProcName == "exefile";
        public string PipeName { get; set; }

        private static string GetLogFileName
        {
            get
            {
                if (string.IsNullOrEmpty(_getLogFileName))
                {
                    var logPath = Instance.AssemblyPath + Path.DirectorySeparatorChar + "Logs" + Path.DirectorySeparatorChar + Instance.CharName;
                    if (!Directory.Exists(logPath))
                        Directory.CreateDirectory(logPath);
                    var fileName = logPath + Path.DirectorySeparatorChar + "HookManager.log";
                    _getLogFileName = fileName;
                }
                return _getLogFileName;
            }
        }

        private string _currentProcName { get; set; }

        #endregion Properties

        #region Methods

        public static bool IsBacklistedDirectory(string path)
        {
            if (path == string.Empty || path == null || path == "") return false;
            foreach (var dir in DirectoryBlackList)
                if (path.Contains(dir))
                    return true;
            return false;
        }

        public static bool IsWhiteListedFileName(string lpModName)
        {
            var fileExtPos = lpModName.LastIndexOf(".");
            var lpModNameWithoutExtension = fileExtPos >= 0 ? lpModName.Substring(0, fileExtPos) : lpModName;
            return FileWhiteList.Contains(lpModNameWithoutExtension.ToLower()) ? true : false;
        }

        public static bool IsWhiteListedReadDirectory(string path)
        {
            if (path == string.Empty || path == null || path == "") return false;
            foreach (var dir in DirectoryWhiteListRead)
                if (path.Contains(dir))
                    return true;
            return false;
        }

        public static bool IsWhiteListedWriteDirectory(string path)
        {
            if (path == string.Empty || path == null || path == "") return false;
            foreach (var dir in DirectoryWhiteListWrite)
                if (path.Contains(dir))
                    return true;
            return false;
        }

        public static void Log(string text, Color? col = null, [CallerMemberName] string memberName = "")
        {
            if (!Instance.EveWndShown)
                return;

            try
            {
                AsyncLogQueue.File = GetLogFileName;
                AsyncLogQueue.Enqueue(new LogEntry(text, memberName, col));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        public static bool NeedsToBeCloaked(string lpModName)
        {
            var found = FileNamesToHide.Where(e => e.IndexOf(lpModName) != -1).ToList();
            return found.Any() ? true : false;
        }

        public void AddController(IHook controller)
        {
            if (!_controllerList.Contains(controller))
                _controllerList.Add(controller);
        }

        public void CloseQuestorWindow()
        {
            if (!WinApiUtil.IsValidHWnd(Instance.EVESharpCoreFormHWnd))
                return;

            var timeout = DateTime.UtcNow.AddSeconds(5);
            while (WinApiUtil.IsValidHWnd(Instance.EVESharpCoreFormHWnd) && timeout > DateTime.UtcNow)
            {
                WinApiUtil.CloseWindow(Instance.EVESharpCoreFormHWnd);
                Thread.Sleep(5);
            }
        }

        public bool EverythingHooked()
        {
            foreach (var controller in _controllerList)
                if (controller != null)
                    if (controller.Error)
                        return false;
            return true;
        }

        public String GetControllersWithHookErrors()
        {
            var ret = String.Empty;

            foreach (var controller in _controllerList)
                if (controller != null && controller.Error)
                    ret += " " + controller.Name;
            return ret;
        }

        public void InitEVEHooks()
        {
            var questorLauncherDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            FileNamesToHide = Directory.GetFiles(questorLauncherDir, "*.*").ToList();
            DirectoryWhiteListRead.Add(Environment.GetFolderPath(Environment.SpecialFolder.Windows)); // win folder
            DirectoryWhiteListRead.Add(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)); // folder of current assembly
            DirectoryWhiteListWrite.Add(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)); // folder of current assembly
            DirectoryWhiteListRead.Add(EveAccount.GetAppDataFolder());
            DirectoryWhiteListWrite.Add(EveAccount.GetAppDataFolder());
            DirectoryWhiteListRead.Add(EveAccount.GetPersonalFolder());
            DirectoryWhiteListWrite.Add(EveAccount.GetPersonalFolder());
            DirectoryWhiteListRead.Add(EveAccount.GetEveRootPath()); // eve folder

            Util.LoadLibrary("blue.dll");
            Util.LoadLibrary("python27.dll");
            Util.LoadLibrary("WS2_32.dll");
            Util.LoadLibrary("Kernel32.dll");
            Util.LoadLibrary("advapi32.dll");
            Util.LoadLibrary("Iphlpapi.dll");
            Util.LoadLibrary("DbgHelp.dll");
            Util.LoadLibrary("_ctypes.pyd");
            Util.LoadLibrary("wininet.dll");
            Util.LoadLibrary("psapi.dll");
            Util.LoadLibrary("fastprox.dll");
            Util.LoadLibrary("user32.dll");


            if (EveAccount.DX11)
                Util.LoadLibrary("d3d11.dll");
            else
                Util.LoadLibrary("d3d9.dll");

            Util.CheckCreateDirectorys(EveAccount.HWSettings.WindowsUserLogin);

            _controllerList.Add(new SHGetFolderPathAController(EveAccount.GetPersonalFolder(), EveAccount.GetAppDataFolder()));
            _controllerList.Add(new SHGetFolderPathWController(EveAccount.GetPersonalFolder(), EveAccount.GetAppDataFolder()));

            EnvVars.SetEnvironment(EveAccount.HWSettings);

            //proxy
            var p = EveAccount.HWSettings.Proxy;

            if (p == null)
            {
                WCFClient.Instance.GetPipeProxy.RemoteLog("Error: Proxy == null.");
                Environment.Exit(0);
                Environment.FailFast("exit");
                return;
            }

            //AddController(new WinSockConnectController(LocalHook.GetProcAddress("WS2_32.dll", "connect"), p.Ip, p.Socks5Port, p.Username, p.Password));

            if (!Guid.TryParse(EveAccount.HWSettings.MachineGuid, out _) || string.IsNullOrEmpty(EveAccount.HWSettings.MachineGuid))
            {
                MessageBox.Show("Hook error (0): EveAccount.HWSettings.MachineGuid [" + EveAccount.HWSettings.MachineGuid + "]");
                Environment.Exit(0);
                Environment.FailFast("exit");
                return;
            }

            AddController(new RegQueryValueExAController(LocalHook.GetProcAddress("advapi32.dll", "RegQueryValueExA"), EveAccount.HWSettings));


            if (EveAccount.HWSettings.SystemReservedMemory == 0)
            {
                MessageBox.Show("Hook error (1)");
                Environment.Exit(0);
                Environment.FailFast("exit");
                return;
            }


            var globalMemoryStatusExMem = EveAccount.HWSettings.TotalPhysRam - EveAccount.HWSettings.SystemReservedMemory;
            var getPhysicallyInstalledSystemMem = EveAccount.HWSettings.TotalPhysRam;

            AddController(new GetPhysInstalledMemController(getPhysicallyInstalledSystemMem));
            AddController(new GlobalMemoryStatusController(LocalHook.GetProcAddress("kernel32.dll", "GlobalMemoryStatusEx"), globalMemoryStatusExMem));

            AddController(new GetAdaptersInfoController(LocalHook.GetProcAddress("Iphlpapi.dll", "GetAdaptersInfo"), EveAccount.HWSettings.NetworkAdapterGuid,
                EveAccount.HWSettings.MacAddress, EveAccount.HWSettings.NetworkAddress));



            if (EveAccount.DX11)
            {
            }
            else
            {
                AddController(new DX9Controller(EveAccount.HWSettings));
                AddController(new EnumDisplayDevicesController(EveAccount.HWSettings));
            }

            AddController(new InternetConnectAController());
            AddController(new InternetConnectWController());

            AddController(new IsDebuggerPresentController());
            AddController(new LoadLibraryAController());
            AddController(new LoadLibraryWController());
            AddController(new GetModuleHandleWController());
            AddController(new GetModuleHandleAController());
            AddController(new EnumProcessesControllerPSAPI());
            AddController(new EnumProcessesControllerK32());
            AddController(new MiniWriteDumpController());

            AddController(new CreateFileWController());
            AddController(new CreateFileAController());
            AddController(new CryptHashDataController());
            //AddController(new CryptCreateHashController());
            AddController(new CryptEncryptController());
            //AddController(new CryptDecryptController());
            AddController(new IWbemClassObjectGetController());

            if (!EverythingHooked())
            {
                MessageBox.Show("Hook error (2)");
                Environment.Exit(0);
                Environment.FailFast("exit");
            }

            var hooksInit = string.Format("Hooks initialized. [{0}]", EveAccount.AccountName);
            Log(hooksInit);
            WCFClient.Instance.GetPipeProxy.RemoteLog(hooksInit);
        }

        public void InitFirefoxHooks(Proxy p)
        {
            Util.LoadLibrary("WS2_32.dll");
            WCFClient.Instance.GetPipeProxy.RemoteLog($"Loaded WS2_32.dll.");
            AddController(new WinSockConnectController(LocalHook.GetProcAddress("WS2_32.dll", "connect"), p.Ip, p.Socks5Port, p.Username, p.Password));
            WCFClient.Instance.GetPipeProxy.RemoteLog($"Added WinSockConnectController.");

            if (!EverythingHooked())
            {
                MessageBox.Show("Hook error (3)");
                Environment.Exit(0);
                Environment.FailFast("exit");
                return;
            }

            var hooksInit = string.Format("Hooks initialized.");
            WCFClient.Instance.GetPipeProxy.RemoteLog(hooksInit);
        }

        public void LaunchAppDomain()
        {
            try
            {
                t = new Thread(delegate ()
                {
                    try
                    {
                        try
                        {
                            CopyEveSharpCoreForEachUserAtStart();
                        }
                        catch (Exception){}

                        //UnloadAppDomain();
                        QAppDomain = AppDomain.CreateDomain("QAppDomain");
                        GC.Collect();
                        GC.WaitForPendingFinalizers();
                        AppDomain.MonitoringIsEnabled = true;
                        var path = Instance.AssemblyPath;
                        QAppDomain.ExecuteAssembly(path + "\\CoreDomainMiddleware.exe",
                            new String[] { Instance.CharName, Instance.PipeName });
                    }
                    catch (Exception ex)
                    {
                        Log("Exception: " + ex);
                    }
                });

                t.Start();
            }
            catch (Exception)
            {
            }
        }

        private void CopyEveSharpCoreForEachUserAtStart()
        {
            try
            {
                string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                string evesharpcoreexe = Path.Combine(path, "evesharpcore.exe");
                string evesharpcorepdb = Path.Combine(path, "evesharpcore.pdb");
                string perToonEvesharpcoreexe = Path.Combine(path, "evesharpcore-" + Instance.CharName + ".exe");
                string perToonEvesharpcorepdb = Path.Combine(path, "evesharpcore-" + Instance.CharName + ".pdb");

                try
                {
                    File.Copy(evesharpcoreexe, perToonEvesharpcoreexe, true);
                    File.Copy(evesharpcorepdb, perToonEvesharpcorepdb, true);
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log("Exception [" + ex + "]");
                }
            }
            catch (Exception ex)
            {
                Cache.Instance.Log("Exception [" + ex + "]");
            }

            return;
        }


        public void RemoveController(IHook controller)
        {
            _controllerList.Remove(controller);
        }

        public void SendToInjectorLog(string text)
        {
            WCFClient.Instance.GetPipeProxy.RemoteLog($"{text} [{CharName}].");
        }

        public void SetupWindowHooks(int eveWindowThreadId, IntPtr eveHwnd, IntPtr hookmanagerHwnd)
        {
            Hooks.CreateHook(HookType.WH_CBT, eveWindowThreadId).OnHookProcEvent += (code, param, lParam) =>
            {
                var hbct = (HCBT)code;

                switch (hbct)
                {
                    case HCBT.MinMax:
                        var sw = (int)lParam;

                        switch (sw)
                        {
                            case Pinvokes.SW_MINIMIZE:
                            case Pinvokes.SW_FORCEMINIMIZE:

                                break;

                            case Pinvokes.SW_MAXIMIZE:

                                break;

                            default:
                                break;
                        }

                        break;

                    case HCBT.MoveSize:
                        var rect = (RECT)Marshal.PtrToStructure(lParam, typeof(RECT));

                        //Win32Hooks.HookManager.Log("HCBT.MoveSize");
                        try
                        {
                            WinApiUtil.DockToParentWindow(rect, eveHwnd, EVESharpCoreFormHWnd, Alignment.TOP);
                            WinApiUtil.DockToParentWindow(rect, eveHwnd, hookmanagerHwnd, Alignment.RIGHTBOT);
                        }
                        catch (Exception exception)
                        {
                            Console.WriteLine(exception);
                        }

                        break;

                    default:
                        break;
                }
            };

            DateTime lastMoveUpdate = DateTime.MinValue;
            Hooks.CreateHook(HookType.WH_CALLWNDPROCRET, eveWindowThreadId).OnHookProcEvent += (code, param, lParam) =>
            {
                var cwpretstruct = (CWPRETSTRUCT)Marshal.PtrToStructure(lParam, typeof(CWPRETSTRUCT));
                var msg = (WM)cwpretstruct.message;
                switch (msg)
                {
                    case WM.MOVING:
                    case WM.MOVE:
                        try
                        {
                            if (lastMoveUpdate.AddMilliseconds(30) < DateTime.UtcNow)
                            {
                                lastMoveUpdate = DateTime.UtcNow;
                                var rect = WinApiUtil.GetWindowRect(eveHwnd);
                                WinApiUtil.DockToParentWindow(rect, eveHwnd, EVESharpCoreFormHWnd, Alignment.TOP);
                                WinApiUtil.DockToParentWindow(rect, eveHwnd, hookmanagerHwnd, Alignment.RIGHTBOT);
                            }
                        }
                        catch (Exception exception)
                        {
                            Console.WriteLine(exception);
                        }
                        break;

                    case WM.SYSCOMMAND:
                        var sc = (int)cwpretstruct.wParam;
                        var sysCmd = (SysCommands)sc;
                        switch (sysCmd)
                        {
                            case SysCommands.SC_ICON:
                                //Win32Hooks.HookManager.Log("SC_ICON");
                                try
                                {
                                    WinApiUtil.ShowWindow(eveHwnd);
                                    WinApiUtil.SetForegroundWindow(eveHwnd);
                                    var rectMin = WinApiUtil.GetWindowRect(eveHwnd);
                                    WinApiUtil.DockToParentWindow(rectMin, eveHwnd, EVESharpCoreFormHWnd, Alignment.TOP);
                                    WinApiUtil.DockToParentWindow(rectMin, eveHwnd, hookmanagerHwnd, Alignment.RIGHTBOT);
                                    WinApiUtil.SetWindowTopMost(EVESharpCoreFormHWnd, true);
                                    WinApiUtil.SetWindowTopMost(hookmanagerHwnd, true);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex);
                                }

                                break;

                            case SysCommands.SC_MAXIMIZE:
                            case SysCommands.SC_RESTORE:
                                //Win32Hooks.HookManager.Log("SC_MAXIMIZE_SC_RESTORE");
                                try
                                {
                                    var rectMax = WinApiUtil.GetWindowRect(eveHwnd);
                                    WinApiUtil.DockToParentWindow(rectMax, eveHwnd, EVESharpCoreFormHWnd, Alignment.TOP);
                                    WinApiUtil.DockToParentWindow(rectMax, eveHwnd, hookmanagerHwnd, Alignment.RIGHTBOT);
                                    WinApiUtil.SetWindowTopMost(EVESharpCoreFormHWnd, true);
                                    WinApiUtil.SetWindowTopMost(hookmanagerHwnd, true);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex);
                                }
                                break;

                            default:
                                break;
                        }

                        break;

                    case WM.KILLFOCUS:


                            //Win32Hooks.HookManager.Log("WM.KILLFOCUS");
                            try
                            {
                                if (!WinApiUtil.IsValidHWnd(eveHwnd))
                                    return;

                                if (WinApiUtil.IsValidHWnd(hookmanagerHwnd))
                                {
                                    WinApiUtil.SetWindowTopMost(hookmanagerHwnd, false);
                                }

                            if (WinApiUtil.IsValidHWnd(EVESharpCoreFormHWnd))
                                {
                                WinApiUtil.SetWindowTopMost(EVESharpCoreFormHWnd, false);
                                }

                                var fgw = WinApiUtil.GetForegroundWindow();
                            WinApiUtil.SetHWndInsertAfter(hookmanagerHwnd, fgw);
                            WinApiUtil.SetHWndInsertAfter(EVESharpCoreFormHWnd, fgw);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine(ex.ToString());
                            }


                        break;

                    case WM.SETFOCUS:

                        //Win32Hooks.HookManager.Log("WM.SETFOCUS");
                        try
                        {
                            WinApiUtil.SetWindowTopMost(hookmanagerHwnd, true);
                            WinApiUtil.SetWindowTopMost(EVESharpCoreFormHWnd, true);
                            WinApiUtil.SetWindowTopMost(hookmanagerHwnd, false);
                            WinApiUtil.SetWindowTopMost(EVESharpCoreFormHWnd, false);
                            WinApiUtil.SetHWndInsertAfter(hookmanagerHwnd, EVESharpCoreFormHWnd);
                            WinApiUtil.SetHWndInsertAfter(eveHwnd, hookmanagerHwnd);
                            WinApiUtil.SetWindowTopMost(hookmanagerHwnd, true);
                            WinApiUtil.SetWindowTopMost(EVESharpCoreFormHWnd, true);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(ex.ToString());
                        }

                        break;

                    default:
                        break;
                }
            };
        }

        public void UnloadAppDomain()
        {
            try
            {
                CloseQuestorWindow();
                if (QAppDomain != null)
                {
                    AppDomain.Unload(QAppDomain);
                    QAppDomain = null;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void WaitForEVE()
        {
            var pid = Process.GetCurrentProcess().Id;
            var eveWndOpen = false;
            var started = DateTime.UtcNow;
            while (!eveWndOpen)
            {
                var eveHWnd = WinApiUtil.GetEveHWnd(pid);
                if (eveHWnd != IntPtr.Zero)
                {
                    eveWndOpen = true;
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValueBlocking(CharName, nameof(EveAccount.EveHWnd),
                        (Int64)eveHWnd);
                }

                if (started.AddSeconds(45) < DateTime.UtcNow)
                {
                    var msg = "Couldn't find EVE window after waiting 45 seconds. Quitting.";
                    Log(msg, Color.Purple);
                    Console.WriteLine(msg);
                    Debug.WriteLine(msg);
                    Environment.Exit(0);
                    Environment.FailFast("");
                }

                Thread.Sleep(30);
            }

            EveWndShown = true;
        }

        #endregion Methods
    }
}