﻿using EVESharpCore.Cache;
using EVESharpCore.Controllers.Debug;
using EVESharpCore.Questor.BackgroundTasks;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using EVESharpCore.Framework;

namespace EVESharpCore.Controllers
{
    public partial class DebugControllerForm : Form
    {
        #region Fields

        private DebugController _debugController;

        #endregion Fields

        #region Constructors

        public DebugControllerForm(DebugController debugController)
        {
            _debugController = debugController;
            InitializeComponent();
        }

        #endregion Constructors

        private void DebugAssetsButton_Click(object sender, EventArgs e)
        {
            new DebugWindows().Show();
        }

        #region Methods

        private void button1_Click(object sender, EventArgs e)
        {
            new DebugEntities().Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new DebugSkills().Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new DebugScan().Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new DebugModules().Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new DebugChannels().Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            new DebugMap().Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            new DebugWindows().Show();
        }

        #endregion Methods

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void buttonStopMyShip_Click(object sender, EventArgs e)
        {
            //Task.Run(() =>
            //{
            //    return Invoke(new Action(() =>
            //    {
                    Logging.Log.WriteLine("Button: StopMyShip");
                    NavigateOnGrid.StopMyShip("Button: StopMyShip");
            //    }));
            //});
        }

        private void buttonApproachPointInSpaceDown_Click(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                return Invoke(new Action(() =>
                {
                    Logging.Log.WriteLine("Button: PointInSpaceDirectlyDown);");
                    ESCache.Instance.ActiveShip.MoveTo(ESCache.Instance.MyShipEntity._directEntity.PointInSpaceDirectlyDown);
                }));
            });
        }

        private void buttonApproachPointInSpaceUp_Click(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                return Invoke(new Action(() =>
                {
                    Logging.Log.WriteLine("Button: PointInSpaceDirectlyUp);");
                    ESCache.Instance.ActiveShip.MoveTo(ESCache.Instance.MyShipEntity._directEntity.PointInSpaceDirectlyUp);
                }));
            });
        }

        private void buttonApproachPointInSpaceNorth_Click(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                return Invoke(new Action(() =>
                {
                    Logging.Log.WriteLine("Button: PointInSpaceDirectlyNorth);");
                    ESCache.Instance.ActiveShip.MoveTo(ESCache.Instance.MyShipEntity._directEntity.PointInSpaceDirectlyNorth);
                }));
            });
        }

        private void buttonApproachPointInSpaceSouth_Click(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                return Invoke(new Action(() =>
                {
                    Logging.Log.WriteLine("Button: PointInSpaceDirectlySouth);");
                    ESCache.Instance.ActiveShip.MoveTo(ESCache.Instance.MyShipEntity._directEntity.PointInSpaceDirectlySouth);
                }));
            });
        }

        private void buttonApproachPointInSpaceEast_Click(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                return Invoke(new Action(() =>
                {
                    Logging.Log.WriteLine("Button: PointInSpaceDirectlyEast);");
                    ESCache.Instance.ActiveShip.MoveTo(ESCache.Instance.MyShipEntity._directEntity.PointInSpaceDirectlyEast);
                }));
            });
        }

        private void buttonApproachPointInSpaceWest_Click(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                return Invoke(new Action(() =>
                {
                    Logging.Log.WriteLine("Button: PointInSpaceDirectlyWest);");
                    ESCache.Instance.ActiveShip.MoveTo(ESCache.Instance.MyShipEntity._directEntity.PointInSpaceDirectlyWest);
                }));
            });
        }

        private void DebugCreateNewFleet_Click(object sender, EventArgs e)
        {
            if (!ESCache.Instance.DirectEve.Session.InFleet)
                ESCache.Instance.DirectEve.FormNewFleet();
        }
    }
}