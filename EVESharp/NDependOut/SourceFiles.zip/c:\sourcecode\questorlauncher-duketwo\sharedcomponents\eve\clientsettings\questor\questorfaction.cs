﻿using System;
using System.ComponentModel;

namespace SharedComponents.EVE.ClientSettings
{
    [Serializable]
    public class QuestorFaction
    {
        #region Properties

        [Browsable(false)]
        public FactionType FactionType { get; set; }

        #endregion Properties
    }
}