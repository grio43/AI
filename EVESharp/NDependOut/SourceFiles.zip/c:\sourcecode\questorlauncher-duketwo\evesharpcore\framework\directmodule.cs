﻿extern alias SC;
using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Logging;
using SC::SharedComponents.EVE.ClientSettings;
using SC::SharedComponents.Py;

namespace EVESharpCore.Framework
{
    extern alias SC;

    public class DirectModule : DirectItem
    {
        #region Constructors

        internal DirectModule(DirectEve directEve, PyObject pyModule) : base(directEve)
        {
            GetPyModule = pyModule;
        }

        #endregion Constructors

        #region Fields

        private bool _isDeactivating;
        private static readonly Dictionary<long, DateTime> LastModuleAction = new Dictionary<long, DateTime>();

        private bool _isActive;

        private bool _isReloadingAmmo;

        private long? _targetId;

        #endregion Fields

        #region Properties

        private const int ModuleReactivationDelay = 400;
        private double? _emMissileDamage;
        private double? _emMissileDps;
        private double? _emTurretDamage;
        private double? _emTurretDps;
        private double? _explosiveDamage;
        private double? _explosiveDps;
        private double? _explosiveMissileDamage;
        private double? _explosiveMissileDps;
        private double? _kineticMissileDamage;
        private double? _kineticMissileDps;
        private double? _kineticTurretDamage;
        private double? _kineticTurretDps;
        private AmmoType _chargeAmmoType;
        private DirectItem _missileDirectItem;
        private double? _missileDps;
        private double? _missileLaunchDuration;
        private double? _thermalMissileDamage;
        private double? _thermalMissileDps;
        private double? _thermalTurretDamage;
        private double? _thermalTurretDps;
        private double? _turretDps;
        public static List<AmmoType> DefinedAmmoTypes { get; set; } = new List<AmmoType>();
        public double? ArmorTransferRange => Attributes.TryGet<double>("maxRange");
        public bool AutoReload { get; internal set; }
        public bool AutoRepeat { get; internal set; }
        public bool Blinking { get; internal set; }
        public double? CapacitorNeed => Attributes.TryGet<double>("capacitorNeed");
        public DirectItem Charge { get; internal set; }

        public AmmoType ChargeAmmoType
        {
            get
            {
                if (!IsWeapon) return null;

                if (_chargeAmmoType != null)
                {
                    if (Charge != null)
                    {
                        foreach (AmmoType definedAmmoType in DefinedAmmoTypes)
                            if (definedAmmoType.TypeId == Charge.TypeId)
                            {
                                _chargeAmmoType = definedAmmoType;
                                return _chargeAmmoType;
                            }

                        return null;
                    }

                    return null;
                }

                return _chargeAmmoType;
            }
        }

        public int ChargeQty => Charge != null ? Charge.Quantity : 0;

        public double ChargeRange
        {
            get
            {
                if (ChargeAmmoType != null)
                    return ChargeAmmoType.Range;

                return 0;
            }
        }

        public int CurrentCharges => Charge != null ? Charge.Quantity : 0;
        public double Damage { get; internal set; }
        public double? DamageMultiplier => Attributes.TryGet<double>("damageMultiplier");
        public double DamagePercent { get; internal set; }
        public bool DisableAutoReload => !IsInLimboState && AutoReload && SetAutoReload(false);
        public double? Duration => Attributes.TryGet<double>("duration");
        public bool EffectActivating => GetPyModule.Attribute("effect_activating").ToBool();

        public bool IsMaster => GetPyModule.Attribute("isMaster").ToBool();
        public int? EffectCategory => this?.DefEffect.Attribute("effectCategory").ToInt() ?? null;
        public int? EffectId => this?.DefEffect.Attribute("effectID").ToInt() ?? null;
        public string EffectName => this?.DefEffect.Attribute("effectName").ToUnicodeString() ?? null;

        public double? EmRawMissileDamage
        {
            get
            {
                if (_emMissileDamage == null)
                {
                    if (MissileDirectItem != null && MissileDirectItem.TypeId != 0)
                    {
                        _emMissileDamage = MissileDirectItem.Attributes.TryGet<double>("emDamage");
                        if (_emMissileDamage.HasValue)
                            return _emMissileDamage.Value;

                        return 0;
                    }

                    return 0;
                }

                return _kineticMissileDamage;
            }
        }

        public double? EmRawMissileDps
        {
            //
            // https://wiki.eveuniversity.org/Missile_mechanics
            //
            get
            {
                if (_emMissileDps == null)
                {
                    if (EmRawMissileDamage != null && MissileRateOfFire != null)
                    {
                        _emMissileDps = (double) EmRawMissileDamage / (double) MissileRateOfFire;
                        if (_emMissileDps != null && !double.IsNaN(_emMissileDps.Value) && !double.IsInfinity(_emMissileDps.Value))
                            return _emMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _emMissileDps;
            }
        }

        public double? EmRawTurretDamage
        {
            get
            {
                if (_emTurretDamage == null)
                {
                    _emTurretDamage = (float)PyInvType.Attribute("emDamage");
                    if (_emTurretDamage.HasValue)
                        return _emTurretDamage.Value;

                    return 0;
                }

                return _emTurretDamage.Value;
            }
        }

        public double? EmRawTurretDps
        {
            get
            {
                if (_emTurretDps == null)
                {
                    if (EmRawTurretDamage != null && DamageMultiplier != null && RateOfFire != null)
                    {
                        _emTurretDps = (double) EmRawTurretDamage * (double) DamageMultiplier / (double) RateOfFire;
                        return _emTurretDps.Value;
                    }

                    return 0;
                }

                return _emTurretDps;
            }
        }

        public double? ExplosiveRawMissileDamage
        {
            get
            {
                if (_explosiveMissileDamage == null)
                {
                    if (MissileDirectItem != null && MissileDirectItem.TypeId != 0)
                    {
                        _explosiveMissileDamage = MissileDirectItem.Attributes.TryGet<double>("explosiveDamage");
                        if (_explosiveMissileDamage.HasValue)
                            return _explosiveMissileDamage.Value;

                        return 0;
                    }

                    return 0;
                }

                return _explosiveMissileDamage;
            }
        }

        public double? ExplosiveRawMissileDps
        {
            get
            {
                if (_explosiveMissileDps == null)
                {
                    if (ExplosiveRawMissileDamage != null && ExplosiveRawMissileDamage != 0 && MissileRateOfFire != null)
                    {
                        _explosiveMissileDps = (double) ExplosiveRawMissileDamage / (double) MissileRateOfFire;
                        if (_explosiveMissileDps != null && !double.IsNaN(_explosiveMissileDps.Value) && !double.IsInfinity(_explosiveMissileDps.Value))
                            return _explosiveMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _explosiveMissileDps;
            }
        }

        public double? ExplosiveRawTurretDamage
        {
            get
            {
                if (_explosiveDamage == null)
                {
                    _explosiveDamage = Attributes.TryGet<double>("explosiveDamage");
                    if (_explosiveDamage.HasValue)
                        return _explosiveDamage.Value;

                    return 0;
                }

                return _explosiveDamage.Value;
            }
        }

        public double? ExplosiveRawTurretDps
        {
            get
            {
                if (_explosiveDps == null)
                {
                    if (ExplosiveRawTurretDamage != null && DamageMultiplier != null && RateOfFire != null)
                    {
                        _explosiveDps = (double) ExplosiveRawTurretDamage * (double) DamageMultiplier / (double) RateOfFire;
                        if (_explosiveDps != null && !double.IsNaN(_explosiveDps.Value) && !double.IsInfinity(_explosiveDps.Value))
                            return _explosiveDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _explosiveDps;
            }
        }

        public double? FallOff => Attributes.TryGet<double>("falloff");

        public double? FalloffEffectiveness => Attributes.TryGet<double>("falloffEffectiveness");
        public PyObject GetPyModule { get; }

        public double Hp { get; internal set; }
        public double WaitingForActiveTarget { get; internal set; }
        public bool IsActivatable => DefEffect != null && DefEffect.IsValid;
        public bool IsActive => IsActivatable && (DefEffect.Attribute("isActive").ToBool() || _isActive);
        public bool IsBeingRepaired { get; internal set; }
        public bool IsDeactivating => IsActivatable && DefEffect.Attribute("isDeactivating").ToBool() || _isDeactivating;
        public bool? IsEffectOffensive => this?.DefEffect.Attribute("isOffensive").ToBool() ?? null;
        public bool IsEnergyWeapon => GroupId == (int) Group.EnergyWeapon;

        public bool IsEwarModule => GroupId == (int) Group.WarpDisruptor
                                    || GroupId == (int) Group.StasisWeb
                                    || GroupId == (int) Group.TargetPainter
                                    || GroupId == (int) Group.TrackingDisruptor
                                    || GroupId == (int) Group.SensorDampener
                                    || GroupId == (int) Group.Ecm
                                    || GroupId == (int) Group.Neutralizer;

        public bool IsInLimboState => !IsActivatable
                                      || !IsOnline
                                      || IsDeactivating
                                      || IsReloadingAmmo
                                      || IsBeingRepaired
                                      || !DirectEve.Session.IsInSpace
                                      || DirectEve.Session.IsInDockableLocation
                                      || EffectActivating
                                      || DirectEve.IsEffectActivating(this)
                                      || ReactivationDelay > 0;

        public bool IsMissileLauncher => GroupId == (int) Group.AssaultMissileLaunchers
                                         || GroupId == (int) Group.CitadelCruiseLaunchers
                                         || GroupId == (int) Group.CitadelTorpLaunchers
                                         || GroupId == (int) Group.CruiseMissileLaunchers
                                         || GroupId == (int) Group.DefenderMissileLaunchers
                                         || GroupId == (int) Group.HeavyAssaultMissileLaunchers
                                         || GroupId == (int) Group.HeavyMissileLaunchers
                                         || GroupId == (int) Group.LightMissileLaunchers
                                         || GroupId == (int) Group.RapidHeavyMissileLaunchers
                                         || GroupId == (int) Group.RapidLightMissileLaunchers
                                         || GroupId == (int) Group.RocketLaunchers
                                         || GroupId == (int) Group.StandardMissileLaunchers
                                         || GroupId == (int) Group.TorpedoLaunchers;

        public bool IsOnline { get; internal set; }
        public bool IsOverloaded { get; internal set; }
        public bool IsPendingOverloading { get; internal set; }
        public bool IsPendingStopOverloading { get; internal set; }
        public bool IsReloadingAmmo => GetPyModule.IsValid && GetPyModule.Attribute("reloadingAmmo").ToBool() || _isReloadingAmmo;

        public bool IsTurret => GroupId == (int) Group.EnergyWeapon
                                || GroupId == (int) Group.ProjectileWeapon
                                || GroupId == (int)Group.PrecursorWeapon
                                || GroupId == (int) Group.HybridWeapon
                                || IsCivilianWeapon;

        public bool IsCivilianWeapon
        {
            get
            {
                if (TypeId == (int)TypeID.CivilianGatlingAutocannon)
                    return true;

                if (TypeId == (int)TypeID.CivilianGatlingPulseLaser)
                    return true;

                if (TypeId == (int)TypeID.CivilianGatlingRailgun)
                    return true;

                if (TypeId == (int)TypeID.CivilianLightElectronBlaster)
                    return true;

                return false;
            }
        }

        //
        // Smartbombs arent considered weapons? they should probably stay a special case...
        //
        public bool IsWeapon => IsMissileLauncher || IsTurret;

        public double? KineticRawMissileDamage
        {
            get
            {
                if (_kineticMissileDamage == null)
                {
                    if (MissileDirectItem != null && MissileDirectItem.TypeId != 0)
                    {
                        _kineticMissileDamage = MissileDirectItem.Attributes.TryGet<double>("kineticDamage");
                        if (_kineticMissileDamage.HasValue)
                            return _kineticMissileDamage.Value;

                        return 0;
                    }

                    return 0;
                }

                return _kineticMissileDamage;
            }
        }

        public double? KineticRawMissileDps
        {
            get
            {
                if (_kineticMissileDps == null)
                {
                    if (KineticRawMissileDamage != null && KineticRawMissileDamage != 0 && MissileRateOfFire != null)
                    {
                        _kineticMissileDps = (double) KineticRawMissileDamage / (double) MissileRateOfFire;
                        if (_kineticMissileDps != null && !double.IsNaN(_kineticMissileDps.Value) && !double.IsInfinity(_kineticMissileDps.Value))
                            return _kineticMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _kineticMissileDps;
            }
        }

        public double? KineticRawTurretDamage
        {
            get
            {
                if (_kineticTurretDamage == null)
                {
                    _kineticTurretDamage = (float)PyInvType.Attribute("kineticDamage");
                    if (_kineticTurretDamage.HasValue)
                        return _kineticTurretDamage.Value;

                    return 0;
                }

                return _kineticTurretDamage.Value;
            }
        }

        public double? KineticRawTurretDps
        {
            get
            {
                if (_kineticTurretDps == null)
                {
                    if (KineticRawTurretDamage != null && DamageMultiplier != null && RateOfFire != null)
                    {
                        _kineticTurretDps = (double) KineticRawTurretDamage * (double) DamageMultiplier / (double) RateOfFire;
                        if (_kineticTurretDps != null && !double.IsNaN(_kineticTurretDps.Value) && !double.IsInfinity(_kineticTurretDps.Value))
                            return _kineticTurretDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _kineticTurretDps;
            }
        }

        public int MaxCharges
        {
            get
            {
                if (Capacity == 0)
                    return 0;

                if (Charge != null && Charge.Volume > 0)
                    return (int) (Capacity / Charge.Volume);

                /*if (MatchingAmmo.Count > 0)
                    return (int) (Capacity/MatchingAmmo[0].Volume);*/

                return 0;
            }
        }

        public DirectItem MissileDirectItem
        {
            get
            {
                if (_missileDirectItem != null)
                {
                    if (Charge != null)
                    {
                        if (Charge.IsMissile)
                        {
                            _missileDirectItem = Charge;
                            if (_missileDirectItem.TypeId != 0)
                                return _missileDirectItem;

                            return null;
                        }

                        return null;
                    }

                    return null;
                }

                return _missileDirectItem;
            }
        }

        public double? MissileLaunchDuration
        {
            get
            {
                if (_missileLaunchDuration == null)
                    _missileLaunchDuration = (float)PyInvType.Attribute("missileLaunchDuration");

                return _missileLaunchDuration.Value;
            }
        }

        //missileLaunchDuration
        public double? MissileRateOfFire => MissileLaunchDuration;

        public new double? OptimalRange => Attributes.TryGet<double>("maxRange");

        public double? PowerTransferRange => Attributes.TryGet<double>("powerTransferRange");

        public bool RampActive => GetPyModule.Attribute("ramp_active").ToBool();

        public double? RateOfFire => Speed;

        public double RawMissileDps
        {
            get
            {
                if (_missileDps == null)
                {
                    _missileDps = EmRawMissileDps ?? 0 + ExplosiveRawMissileDps ?? 0 + KineticRawMissileDps ?? 0 + ThermalRawMissileDps ?? 0;
                    if (_missileDps != null && !double.IsNaN(_missileDps.Value) && !double.IsInfinity(_missileDps.Value))
                        return _missileDps.Value;

                    return 0;
                }

                return (double) _missileDps;
            }
        }

        public double RawTurretDps
        {
            get
            {
                if (_turretDps == null)
                {
                    _turretDps = EmRawTurretDps ?? 0 + ExplosiveRawTurretDps ?? 0 + KineticRawTurretDps ?? 0 + ThermalRawTurretDps ?? 0;
                    if (_turretDps != null && !double.IsNaN(_turretDps.Value) && !double.IsInfinity(_turretDps.Value))
                        return _turretDps.Value;

                    return 0;
                }

                return (double) _turretDps;
            }
        }

        public double? ShieldTransferRange => Attributes.TryGet<double>("shieldTransferRange");

        public double? Speed => Attributes.TryGet<double>("speed");

        // target id is either 0 (activatable with target possible) or -1 (activateable without a target possible) or targetid
        public long? TargetId => _targetId.HasValue ? _targetId : (_targetId = DefEffect.Attribute("targetID").ToLong());

        public double? ThermalRawMissileDamage
        {
            get
            {
                if (_thermalMissileDamage == null)
                {
                    if (MissileDirectItem != null && MissileDirectItem.TypeId != 0)
                    {
                        _thermalMissileDamage = MissileDirectItem.Attributes.TryGet<double>("thermalDamage");
                        if (_thermalMissileDamage.HasValue)
                            return _thermalMissileDamage.Value;

                        return 0;
                    }

                    return 0;
                }

                return _thermalMissileDamage;
            }
        }

        public double? ThermalRawMissileDps
        {
            get
            {
                if (_thermalMissileDps == null)
                {
                    if (ThermalRawMissileDamage != null && ThermalRawMissileDamage != 0 && MissileRateOfFire != null)
                    {
                        _thermalMissileDps = (double) ThermalRawMissileDamage / (double) MissileRateOfFire;
                        if (_thermalMissileDps != null && !double.IsNaN(_thermalMissileDps.Value) && !double.IsInfinity(_thermalMissileDps.Value))
                            return _thermalMissileDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _thermalMissileDps;
            }
        }

        public double? ThermalRawTurretDamage
        {
            get
            {
                if (_thermalTurretDamage == null)
                {
                    _thermalTurretDamage = (float)PyInvType.Attribute("thermalDamage");
                    if (_thermalTurretDamage.HasValue)
                        return _thermalTurretDamage.Value;

                    return 0;
                }

                return _thermalTurretDamage.Value;
            }
        }

        public double? ThermalRawTurretDps
        {
            get
            {
                if (_thermalTurretDps == null)
                {
                    if (ThermalRawTurretDamage != null && DamageMultiplier != null && RateOfFire != null)
                    {
                        _thermalTurretDps = (double) ThermalRawTurretDamage * (double) DamageMultiplier / (double) RateOfFire;
                        if (_thermalTurretDps != null && !double.IsNaN(_thermalTurretDps.Value) && !double.IsInfinity(_thermalTurretDps.Value))
                            return _thermalTurretDps.Value;

                        return 0;
                    }

                    return 0;
                }

                return _thermalTurretDps;
            }
        }

        public double? TrackingSpeed => Attributes.TryGet<double>("trackingSpeed");
        private PyObject DefEffect { get; set; }

        private int OverloadState { get; set; }

        #endregion Properties

        /*public List<DirectItem> MatchingAmmo
        {
            get
            {
                if (_matchingAmmo == null)
                {
                    _matchingAmmo = new List<DirectItem>();

                    var pyCharges = _pyModule.Call("GetMatchingAmmo", TypeId).ToList();
                    foreach (var pyCharge in pyCharges)
                    {
                        var charge = new DirectItem(DirectEve);
                        charge.PyItem = pyCharge;
                        _matchingAmmo.Add(charge);
                    }
                }

                return _matchingAmmo;
            }
        }*/

        #region Methods

        private static HashSet<int> _chargeCompatibleGroups;

        public bool CanBeReloaded => ChargeCompatibleGroups.Contains(GroupId);

        public bool IsShieldRepairModule
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.ShieldBoosters;
                    result |= GroupId == (int)Group.AncillaryShieldBooster;
                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsShieldTankModule
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.ShieldHardeners;
                    result |= GroupId == (int)Group.ShieldExtender;
                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsArmorRepairModule
        {
            get
            {
                try
                {
                    bool result = false;
                    result |= GroupId == (int)Group.ArmorRepairer;
                    result |= GroupId == (int)Group.AncillaryArmorBooster;
                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public bool IsArmorTankModule
        {
            get
            {
                try
                {
                    if (IsArmorRepairModule) return true;

                    bool result = false;
                    result |= GroupId == (int)Group.ArmorHardeners;
                    result |= GroupId == (int)Group.ArmorPlate;
                    return result;
                }
                catch (Exception exception)
                {
                    Log.WriteLine("Exception: [" + exception + "]");
                    return false;
                }
            }
        }

        public HashSet<int> ChargeCompatibleGroups
        {
            get
            {
                if (_chargeCompatibleGroups != null)
                    return _chargeCompatibleGroups;

                _chargeCompatibleGroups = new HashSet<int>();

                PyObject pyObj = PySharp.Import("__builtin__").Attribute("cfg").Attribute("__chargecompatiblegroups__");
                if (pyObj.IsValid)
                {
                    int size = pyObj.Size();
                    for (int i = 0; i < size; i++)
                        _chargeCompatibleGroups.Add(pyObj.Item(i).ToInt());
                }
                return _chargeCompatibleGroups;
            }
        }

        public double ReactivationDelay
        {
            get
            {
                PyObject dictEntry = GetPyModule.Attribute("stateManager").Attribute("lastStopTimesByItemID").DictionaryItem(ItemId);
                if (dictEntry.IsValid)
                {
                    DateTime delayedUntil = dictEntry.Item(0).ToDateTime().AddMilliseconds(dictEntry.Item(1).ToFloat());
                    if (delayedUntil > DateTime.UtcNow)
                        return (delayedUntil - DateTime.UtcNow).TotalMilliseconds;
                }
                return 0d;
            }
        }

        public bool Activate(long targetId)
        {
            try
            {
                if (IsActive)
                    return false;

                if (IsInLimboState)
                    return false;

                //if (DisableAutoReload)
                //    return false;

                DirectEve.EntitiesById.TryGetValue(targetId, out var ent);
                if (ent != null)
                {
                    if (!ent.IsValid)
                        return false;

                    if (!DirectEve.IsTargetStillValid(targetId))
                        return false;

                    if (ent.IsEwarImmune && IsEwarModule)
                        return false;

                    if (!DirectEve.HasFrameChanged(ItemId + nameof(Activate)))
                        return false;

                    if (LastModuleAction.ContainsKey(ItemId) && LastModuleAction[ItemId].AddMilliseconds(ModuleReactivationDelay) > DateTime.UtcNow)
                        return false;

                    _isActive = true;
                    LastModuleAction[ItemId] = DateTime.UtcNow;
                    _targetId = targetId;
                    return DirectEve.ThreadedCall(GetPyModule.Attribute("ActivateEffect"), GetPyModule.Attribute("def_effect"), targetId);
                }

                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine("DirectEve.Activate Exception [" + ex + "]");
                return false;
            }
        }

        /// <summary>
        ///     Cancels the repairing of DirectModule in space
        /// </summary>
        /// <returns></returns>
        public bool CancelRepair()
        {
            return DirectEve.ThreadedCall(GetPyModule.Attribute("CancelRepair"));
        }

        public bool ChangeAmmo(DirectItem charge)
        {
            if (!CanBeReloaded)
                return true;

            if (charge.ItemId <= 0)
                return false;

            if (IsInLimboState)
                return false;

            if (charge.TypeId <= 0)
                return false;

            if (charge.Stacksize <= 0)
                return false;

            if (!DirectEve.HasFrameChanged(ItemId + nameof(ChangeAmmo)))
                return false;

            if (LastModuleAction.ContainsKey(ItemId) && LastModuleAction[ItemId].AddMilliseconds(ModuleReactivationDelay) > DateTime.UtcNow)
                return false;

            LastModuleAction[ItemId] = DateTime.UtcNow;

            PyObject reloadInfo = GetPyModule.Call("GetChargeReloadInfo");

            if (!reloadInfo.IsValid)
            {
                DirectEve.Log("GetChargeReloadInfo is not valid! Error.");
                return false;
            }

            List<PyObject> reloadInfoList = reloadInfo.ToList();

            if (!reloadInfoList.Any())
            {
                DirectEve.Log("ReloadInfoList is empty! Error.");
                return false;
            }

            if (charge.TypeId == (int) reloadInfoList[0])
                return ReloadAmmo(charge, true);
            GetPyModule.Attribute("stateManager").Call("ChangeAmmoTypeForModule", ItemId, charge.TypeId);
            return ReloadAmmo(charge, true);
        }

        public bool Click(int moduleReactivationDelay = ModuleReactivationDelay)
        {
            if (IsInLimboState)
                return false;

            //if (!IsMaster)
            //    return true;

            if (!DirectEve.HasFrameChanged(ItemId + nameof(Click))) return false;

            if (LastModuleAction.ContainsKey(ItemId) && LastModuleAction[ItemId].AddMilliseconds(ModuleReactivationDelay) > DateTime.UtcNow)
                return false;

            if (TargetId.HasValue)
            {
                if (DirectEve.IsTargetBeingRemoved(TargetId.Value))
                    return false;

                if (DirectEve.Entities.Any(entity => entity.Id == TargetId.Value && entity.ShieldArmorHullAllAt0))
                    return false;
            }

            if (IsActive)
                _isDeactivating = true;
            else
                _isActive = true;

            LastModuleAction[ItemId] = DateTime.UtcNow;
            return DirectEve.ThreadedCall(GetPyModule.Attribute("Click"));
        }

        public bool Deactivate()
        {
            if (IsInLimboState)
                return false;

            if (!DirectEve.HasFrameChanged(ItemId + nameof(Deactivate))) return false;

            if (LastModuleAction.ContainsKey(ItemId) && LastModuleAction[ItemId].AddMilliseconds(ModuleReactivationDelay) > DateTime.UtcNow)
                return false;

            LastModuleAction[ItemId] = DateTime.UtcNow;
            DirectEve.AddEffectTimer(this);

            return DirectEve.ThreadedCall(GetPyModule.Attribute("DeactivateEffect"), GetPyModule.Attribute("def_effect"));
        }

        public bool OfflineModule()
        {
            if (!IsOnline)
                return true;

            if (IsInLimboState)
                return false;

            if (DirectEve.ThreadedCall(GetPyModule.Attribute("ChangeOnline"), 0))
                return true;

            return false;
        }

        public bool OnlineModule()
        {
            if (IsOnline)
                return true;

            if (DirectEve.ThreadedCall(GetPyModule.Attribute("ChangeOnline"), 1))
                return true;

            return false;
        }

        public bool ReloadAmmo(DirectItem newCharge, bool ignoreModuleAction = false, DirectEntity entity = null)
        {
            if (IsInLimboState)
                return false;

            if (newCharge.ItemId <= 0)
                return false;

            if (newCharge.TypeId <= 0)
                return false;

            if (ItemId <= 0)
                return false;

            if (IsDeactivating)
                return false;

            if (!DirectEve.HasFrameChanged(ItemId + nameof(ReloadAmmo)))
                return false;

            if (!ignoreModuleAction)
            {
                if (LastModuleAction.ContainsKey(ItemId) && LastModuleAction[ItemId].AddMilliseconds(ModuleReactivationDelay) > DateTime.UtcNow)
                    return false;

                LastModuleAction[ItemId] = DateTime.UtcNow;
            }

            _isReloadingAmmo = true;

            string potentialEntityToChangeAmmoFor = string.Empty;
            if (entity != null)
            {
                potentialEntityToChangeAmmoFor = " so we can hit [" + entity.Name + "][" + Math.Round(entity.Distance / 1000, 0) + "k]";
            }

            string ExistingChargeName = string.Empty;

            if (Charge != null)
                ExistingChargeName = Charge.TypeName;
            Log.WriteLine("Reloading/Changing [" + ItemId + "][" + TypeName + "] from [" + ExistingChargeName + "] to [" + newCharge.TypeName + "]" + potentialEntityToChangeAmmoFor);
            DirectEve.AddEffectTimer(this);
            DirectEve.ThreadedCall(DirectEve.GetLocalSvc("clientDogmaIM").Attribute("dogmaLocation").Attribute("LoadAmmoTypeToModule"), ItemId, newCharge.TypeId);
            return true;
        }

        /// <summary>
        ///     Repairs a DirectModule in space with nanite paste
        /// </summary>
        /// <returns></returns>
        public bool Repair()
        {
            return DirectEve.ThreadedCall(GetPyModule.Attribute("RepairModule"));
        }

        public bool SetAutoReload(bool on)
        {
            return DirectEve.ThreadedCall(GetPyModule.Attribute("SetAutoReload"), on);
        }

        /// <summary>
        ///     Toggles overload of the DirectModule. If it's not allowed it will fail silently.
        /// </summary>
        /// <returns></returns>
        public bool ToggleOverload()
        {
            return DirectEve.ThreadedCall(GetPyModule.Attribute("ToggleOverload"));
        }

        public bool UnloadToCargo()
        {
            if (IsInLimboState)
                return false;

            if (Charge == null)
                return false;

            if (Charge.ItemId <= 0)
                return false;

            if (Charge.TypeId <= 0)
                return false;

            if (DirectEve.ThreadedCall(GetPyModule.Attribute("UnloadToCargo"), Charge.ItemId))
                return true;

            return false;
        }

        internal static List<DirectModule> GetModules(DirectEve directEve)
        {
            List<DirectModule> modules = new List<DirectModule>();

            PySharp pySharp = directEve.PySharp;
            PyObject carbonui = pySharp.Import("carbonui");

            Dictionary<long, PyObject> pyModules = carbonui.Attribute("uicore")
                .Attribute("uicore")
                .Attribute("layer")
                .Attribute("shipui")
                .Attribute("slotsContainer")
                .Attribute("modulesByID")
                .ToDictionary<long>();
            foreach (KeyValuePair<long, PyObject> pyModule in pyModules)
            {
                DirectModule module = new DirectModule(directEve, pyModule.Value);
                module.PyItem = pyModule.Value.Attribute("moduleinfo");
                module.ItemId = pyModule.Key;
                module.IsOnline = (bool) pyModule.Value.Attribute("online");
                //module.IsReloadingAmmo = pyModule.Value.Attribute("reloadingAmmo").ToBool();
                module.Damage = (double) pyModule.Value.Attribute("moduleinfo").Attribute("damage");
                module.Hp = (double) pyModule.Value.Attribute("moduleinfo").Attribute("hp");
                module.DamagePercent = module.Hp != 0 ? module.Damage / module.Hp * 100 : 0;
                module.OverloadState = pyModule.Value.Attribute("stateManager").Call("GetOverloadState", module.ItemId).ToInt();
                module.IsOverloaded = module.OverloadState == 1;
                module.IsPendingOverloading = module.OverloadState == 2;
                module.IsPendingStopOverloading = module.OverloadState == 3;
                module.IsBeingRepaired = (bool) pyModule.Value.Attribute("isBeingRepaired");
                module.AutoReload = (bool) pyModule.Value.Attribute("autoreload");
                //module.AutoRepeat = (bool)pyModule.Value.Attribute("autorepeat");
                module.DefEffect = pyModule.Value.Attribute("def_effect");
                //module.WaitingForActiveTarget = (double)pyModule.Value.Attribute("waitingForActiveTarget");
                //module.Blinking = (bool)pyModule.Value.Attribute("blinking");

                //module.IsActivatable = effect.IsValid;
                //module.IsActive = (bool)effect.Attribute("isActive");
                //module.IsDeactivating = (bool)effect.Attribute("isDeactivating");
                //module.TargetId = (long?)effect.Attribute("targetID");

                PyObject pyCharge = pyModule.Value.Attribute("charge");
                if (pyCharge.IsValid)
                {
                    module.Charge = new DirectItem(directEve);
                    module.Charge.PyItem = pyCharge;
                }

                modules.Add(module);

                /**
                int intAttribute = 0;
                if (module.GroupId == (int) Group.ProjectileWeapon && attributeLogging)
                {
                    var attributes = module.Attributes.GetAttributes();
                    Log.WriteLine("Module is [" + module.TypeName + "] TypeID [" + module.TypeId + "] GroupID [" + module.GroupId + "]");
                    foreach (KeyValuePair<string, Type> a in attributes)
                    {
                        intAttribute++;
                        Log.WriteLine("Module Attribute [" + intAttribute + "] Key[" + a.Key + "] Value [" + a.Value.ToString() + "]");
                    }

                    attributeLogging = false;
                }
                **/
            }

            return modules;
        }

        #endregion Methods
    }
}

//		public bool Activate()
//		{
//			try
//			{
//
//				if (LastActivatedModule.ContainsKey(this.ItemId) && LastActivatedModule[this.ItemId].AddMilliseconds(500) > DateTime.UtcNow)
//				{
//					return false;
//				}
//
//				LastActivatedModule[this.ItemId] = DateTime.UtcNow;
//				return DirectEve.ThreadedCall(_pyModule.Attribute("ActivateEffect"), _pyModule.Attribute("def_effect"));
//
//			}
//			catch (Exception ex)
//			{
//
//				Console.WriteLine("DirectEve.Activate Exception [" + ex + "]");
//				return false;
//			}
//
//		}