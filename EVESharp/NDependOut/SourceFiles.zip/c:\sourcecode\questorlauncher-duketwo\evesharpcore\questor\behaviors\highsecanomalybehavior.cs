﻿extern alias SC;
using EVESharpCore.Cache;
using EVESharpCore.Controllers;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Actions;
using EVESharpCore.Questor.Activities;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.States;
using EVESharpCore.Questor.Traveller;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace EVESharpCore.Questor.Behaviors
{
    public class HighSecAnomalyBehavior
    {
        #region Constructors

        public HighSecAnomalyBehavior()
        {
            ResetStatesToDefaults();
        }

        #endregion Constructors

        #region Fields

        private static int AnomalyPrerequisiteCheckRetries;
        private static DateTime LastAbyssalSitePrerequisiteCheck = DateTime.UtcNow.AddDays(-1);

        #endregion Fields

        #region Properties

        public static string HomeBookmarkName { get; set; } = "HomeBookmark";

        #endregion Properties

        #region Methods

        public static bool ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState _StateToSet, bool wait = false, string LogMessage = null)
        {
            try
            {
                if (State.CurrentHighSecAnomalyBehaviorState != _StateToSet)
                {
                    if (_StateToSet == HighSecAnomalyBehaviorState.GotoHomeBookmark)
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, "AbyssalPocketNumber", 0);
                        Traveler.Destination = null;
                        State.CurrentTravelerState = TravelerState.Idle;
                    }

                    //if (_StateToSet == HighSecAnomalyBehaviorState.GotoAbyssalBookmark)
                    //{
                    //    Traveler.Destination = null;
                    //    State.CurrentTravelerState = TravelerState.Idle;
                    //}

                    if (_StateToSet == HighSecAnomalyBehaviorState.ExecuteMission)
                    {
                        State.CurrentCombatMissionCtrlState = ActionControlState.Start;
                        Traveler.Destination = null;
                        State.CurrentTravelerState = TravelerState.AtDestination;
                    }

                    Log.WriteLine("New HighSecAnomalyBehaviorState [" + _StateToSet + "]");
                    State.CurrentHighSecAnomalyBehaviorState = _StateToSet;
                    //if (!wait) ProcessState();
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }

            return true;
        }

        public static void LoadSettings(XElement CharacterSettingsXml, XElement CommonSettingsXml)
        {
            Log.WriteLine("LoadSettings: HighSecAnomalyBehavior");

            HomeBookmarkName =
                (string)CharacterSettingsXml.Element("HomeBookmark") ?? (string)CharacterSettingsXml.Element("HomeBookmark") ??
                (string)CommonSettingsXml.Element("HomeBookmark") ?? (string)CommonSettingsXml.Element("HomeBookmark") ?? "HomeBookmark";
            Log.WriteLine("LoadSettings: HighSecAnomalyBehavior: HomeBookmarkName [" + HomeBookmarkName + "]");

            HealthCheckMinimumShieldPercentage =
                (int?)CharacterSettingsXml.Element("HealthCheckMinimumShieldPercentage") ??
                (int?)CommonSettingsXml.Element("HealthCheckMinimumShieldPercentage") ?? 30;
            Log.WriteLine("LoadSettings: HighSecAnomalyBehavior: HealthCheckMinimumShieldPercentage [" + HealthCheckMinimumShieldPercentage + "]");
            HealthCheckMinimumArmorPercentage =
                (int?)CharacterSettingsXml.Element("HealthCheckMinimumArmorPercentage") ??
                (int?)CommonSettingsXml.Element("HealthCheckMinimumArmorPercentage") ?? 30;
            Log.WriteLine("LoadSettings: HighSecAnomalyBehavior: HealthCheckMinimumArmorPercentage [" + HealthCheckMinimumArmorPercentage + "]");
            HealthCheckMinimumCapacitorPercentage =
                (int?)CharacterSettingsXml.Element("HealthCheckMinimumCapacitorPercentage") ??
                (int?)CommonSettingsXml.Element("HealthCheckMinimumCapacitorPercentage") ?? 30;
            Log.WriteLine("LoadSettings: HighSecAnomalyBehavior: HealthCheckMinimumCapacitorPercentage [" + HealthCheckMinimumCapacitorPercentage + "]");



            //RunAbyssalDeadspaceSitesUntilOurCargoContainsNoMoreCorrectFilaments =
            //    (bool?)CharacterSettingsXml.Element("RunAbyssalDeadspaceSitesUntilOurCargoContainsNoMoreCorrectFilaments") ??
            //    (bool?)CommonSettingsXml.Element("RunAbyssalDeadspaceSitesUntilOurCargoContainsNoMoreCorrectFilaments") ?? false;
        }

        public static void ProcessState()
        {
            try
            {
                if (!EveryPulse()) return;

                if (DebugConfig.DebugHighSecAnomalyBehavior) Log.WriteLine("State.CurrentHighSecAnomalyBehaviorState is [" + State.CurrentAbyssalDeadspaceBehaviorState + "]");

                switch (State.CurrentHighSecAnomalyBehaviorState)
                {
                    case HighSecAnomalyBehaviorState.Idle:
                        MissionSettings.MissionSafeDistanceFromStructure = 22000;
                        IdleCMBState();
                        break;

                    case HighSecAnomalyBehaviorState.Start:
                        StartCMBState();
                        break;

                    case HighSecAnomalyBehaviorState.Switch:
                        SwitchCMBState();
                        break;

                    case HighSecAnomalyBehaviorState.Arm:
                        ArmCMBState(1);
                        break;

                    case HighSecAnomalyBehaviorState.LocalWatch:
                        LocalWatchCMBState();
                        break;

                    case HighSecAnomalyBehaviorState.WaitingforBadGuytoGoAway:
                        WaitingFoBadGuyToGoAway();
                        break;

                    case HighSecAnomalyBehaviorState.WarpOutStation:
                        WarpOutBookmarkCMBState();
                        break;

                    case HighSecAnomalyBehaviorState.FindAnomaly:
                        FindAnomalyState();
                        break;

                    case HighSecAnomalyBehaviorState.Traveler:
                        TravelToNextSystem();
                        break;

                    case HighSecAnomalyBehaviorState.BookmarkAnomaly:
                        BookmarkAnomalyState();
                        break;

                    case HighSecAnomalyBehaviorState.ExecuteMission:
                        Salvage.LootWhileSpeedTanking = true;
                        AnomalyPrerequisiteCheckRetries = 0;
                        ExecuteAnomalySiteState();
                        break;

                    case HighSecAnomalyBehaviorState.GotoHomeBookmark:
                        GotoHomeBookmarkState();
                        break;

                    case HighSecAnomalyBehaviorState.UnloadLoot:
                        UnloadLootCMBState();
                        break;

                    case HighSecAnomalyBehaviorState.Default:
                        ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Idle);
                        break;
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        private static bool AnomalyPrerequisiteCheck()
        {
            if (DateTime.UtcNow < LastAbyssalSitePrerequisiteCheck.AddMinutes(10))
            {
                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                AnomalyPrerequisiteCheckRetries++;
                return false;
            }

            if (AnomalyPrerequisiteCheckRetries > 3)
            {
                Log.WriteLine("AnomalyPrerequisiteCheck: if (AbyssalSitePrerequisiteCheckRetries > 10): go home");
                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                AnomalyPrerequisiteCheckRetries++;
                return false;
            }

            if (ESCache.Instance.CurrentShipsCargo != null && ESCache.Instance.CurrentShipsCargo.Items.Any())
            {
                if (ESCache.Instance.CurrentShipsCargo.Items.All(i => i.GroupId != (int)Group.AbyssalDeadspaceFilament))
                {
                    Log.WriteLine("AbyssalSitePrerequisiteCheck: We have no filaments in our cargo: go home");
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                    AnomalyPrerequisiteCheckRetries++;
                    return false;
                }

                DirectItem abyssalFilament = ESCache.Instance.CurrentShipsCargo.Items.FirstOrDefault(i => i.GroupId == (int)Group.AbyssalDeadspaceFilament);
                if (abyssalFilament != null && !abyssalFilament.IsSafeToUseAbyssalKeyHere)
                {
                    Log.WriteLine("AnomalyPrerequisiteCheck: We have a filament but it is not safe to activate it here! go home and pause");
                    ESCache.Instance.PauseAfterNextDock = true;
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                    AnomalyPrerequisiteCheckRetries++;
                    return false;
                }

                if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.All(i => !i.IsEnergyWeapon))
                {
                    if (ESCache.Instance.CurrentShipsCargo.UsedCapacity > ESCache.Instance.CurrentShipsCargo.Capacity * .8)
                    {
                        Log.WriteLine("AnomalyPrerequisiteCheck: Less than 80% of our cargo space left: go home");
                        ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                        AnomalyPrerequisiteCheckRetries++;
                        return false;
                    }

                    if (ESCache.Instance.CurrentShipsCargo.Items.Any(i => i.CategoryId == (int)CategoryID.Charge))
                    {
                        foreach (DirectItem ammoItem in ESCache.Instance.CurrentShipsCargo.Items.Where(i => i.CategoryId == (int)CategoryID.Charge))
                        {
                            Log.WriteLine("AnomalyPrerequisiteCheck: CargoHoldItem: [" + ammoItem.TypeName + "] TypeId [" + ammoItem.TypeId + "] Quantity [" + ammoItem.Quantity + "]");

                            if (ammoItem.Quantity < 2500 && ESCache.Instance.Weapons.All(i => i.GroupId == (int)Group.ProjectileWeapon ||
                                                                                              i.GroupId == (int)Group.HybridWeapon ||
                                                                                              i.IsMissileLauncher))
                            {
                                Log.WriteLine("AnomalyPrerequisiteCheck: Less than 2500 units, go back to base");
                                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                                AnomalyPrerequisiteCheckRetries++;
                                return false;
                            }

                            if (ammoItem.Quantity < 500 && ESCache.Instance.Weapons.All(i => i.GroupId == (int)Group.PrecursorWeapon))
                            {
                                Log.WriteLine("AnomalyPrerequisiteCheck: Less than 500 units of Precursor weapon ammo, go back to base");
                                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                                AnomalyPrerequisiteCheckRetries++;
                                return false;
                            }
                        }

                        Log.WriteLine("AnomalyPrerequisiteCheck: We have enough ammo.");
                        AnomalyPrerequisiteCheckRetries = 0;
                        return true;
                        /**
                        if (Drones.UseDrones)
                        {
                            //if (Drones.DroneBay != null && Drones.DroneBay.Capacity > 0)
                            //{
                            //    if (Drones.DroneBay.Capacity - Drones.DroneBay.UsedCapacity >= 25)
                            //    {
                            //        Log.WriteLine("AbyssalSitePrerequisiteCheck: if (Drones.DroneBay.Capacity - Drones.DroneBay.UsedCapacity >= 25)");
                            //        ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.GotoHomeBookmark);
                            //        return false;
                            //    }
                            //
                            Log.WriteLine("AbyssalSitePrerequisiteCheck: We assume we have enough drones!?!");
                            LastAbyssalSitePrerequisiteCheck = DateTime.UtcNow;
                            AbyssalSitePrerequisiteCheckRetries = 0;
                            return true;
                            //}

                            //AbyssalSitePrerequisiteCheckRetries++;
                            //return false;
                        }
                        Log.WriteLine("AbyssalSitePrerequisiteCheck: UseDrones is false");
                        AbyssalSitePrerequisiteCheckRetries = 0;
                        return true;
                        **/
                    }

                    Log.WriteLine("AbyssalSitePrerequisiteCheck: We have no ammo left in the cargo!");
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                    AnomalyPrerequisiteCheckRetries++;
                    return false;
                }

                //Log.WriteLine("AbyssalSitePrerequisiteCheck: We are using Lasers we do not check for ammo when using lasers");
                AnomalyPrerequisiteCheckRetries = 0;
                return true;
            }

            Log.WriteLine("AbyssalSitePrerequisiteCheck: We have no items in our cargo!");
            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
            return false;
        }
        public static int HealthCheckMinimumShieldPercentage = 30;
        public static int HealthCheckMinimumArmorPercentage = 30;
        public static int HealthCheckMinimumCapacitorPercentage = 30;

        private static void ArmCMBState(int FilamentsToLoad = 1)
        {
            //if (QCache.Instance.DirectEve.Session.Structureid.HasValue)
            //{
            //    Log.WriteLine("Pausing: Currently Arm does not work in Citadels, manually arm your ammo, drones, repair, etc and unpause");
            //    State.CurrentAbyssalDeadspaceBehaviorState = AbyssalDeadspaceBehaviorState.LocalWatch;
            //    ControllerManager.Instance.SetPause(true);
            //    return;
            //}

            if (!AttemptToBuyAmmo()) return;

            if (State.CurrentArmState == ArmState.Idle)
            {
                Log.WriteLine("Begin Arm");
                Arm.ChangeArmState(ArmState.Begin, true, null);
            }

            if (!ESCache.Instance.InStation) return;

            Arm.ProcessState();

            if (State.CurrentArmState == ArmState.NotEnoughAmmo ||
                State.CurrentArmState == ArmState.NotEnoughDrones)
            {
                if (Settings.Instance.BuyAmmo)
                {
                    Log.WriteLine("Armstate [" + State.CurrentArmState + "]: BuyAmmo [" + Settings.Instance.BuyAmmo + "]");
                    ESCache.Instance.EveAccount.LastAmmoBuy.AddDays(-1);
                    Arm.ChangeArmState(ArmState.Done, true, null);
                    return;
                }

                Log.WriteLine("Armstate [" + State.CurrentArmState + "]: BuyAmmo [" + Settings.Instance.BuyAmmo + "]");
                Arm.ChangeArmState(ArmState.NotEnoughAmmo, true, null);
                return;
            }

            if (State.CurrentArmState == ArmState.Done)
            {
                Arm.ChangeArmState(ArmState.Idle, true, null);

                if (Settings.Instance.BuyAmmo && BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.DisabledForThisSession)
                {
                    BuyAmmoController.CurrentBuyAmmoState = BuyAmmoState.Idle;
                    ControllerManager.Instance.RemoveController(typeof(BuyAmmoController));
                }

                State.CurrentDroneState = DroneState.WaitingForTargets;
                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.LocalWatch, true);
            }
        }

        private static bool AttemptToBuyAmmo()
        {
            if (ESCache.Instance.DirectEve.Session.IsAbyssalDeadspace || ESCache.Instance.InWormHoleSpace)
                return true;

            if (Settings.Instance.BuyAmmo)
                if (BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.Done && BuyAmmoController.CurrentBuyAmmoState != BuyAmmoState.DisabledForThisSession)
                    if (DateTime.UtcNow > ESCache.Instance.EveAccount.LastAmmoBuy.AddHours(8) && DateTime.UtcNow > ESCache.Instance.EveAccount.LastBuyLpItemAttempt.AddHours(1))
                    {
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastAmmoBuyAttempt), DateTime.UtcNow);
                        ControllerManager.Instance.AddController(new BuyAmmoController());
                        return false;
                    }

            return true;
        }

        //private static bool WeHaveBeenInPocketTooLong_WarningSent = false;


        private static void ProcessAlerts()
        {
            //TimeSpan ItHasBeenThisLongSinceWeStartedThePocket = Statistics.StartedPocket - DateTime.UtcNow;
            //int minutesInPocket = ItHasBeenThisLongSinceWeStartedThePocket.Minutes;
            //if (minutesInPocket > (AbyssalPocketWarningSeconds / 60) && !WeHaveBeenInPocketTooLong_WarningSent)
            //{
            //    DirectEventManager.NewEvent(new DirectEvent(DirectEvents.ABYSSAL_POCKET_TIME, "HighSecAnomalyBehavior: FYI: We have been in pocket number [" + ActionControl.PocketNumber + "] for [" + minutesInPocket + "] min: You might need to check that we arnt stuck."));
            //    WeHaveBeenInPocketTooLong_WarningSent = true;
            //    Log.WriteLine("We have been in AbyssalPocket [" + ActionControl.PocketNumber + "] for more than [" + AbyssalPocketWarningSeconds + "] seconds!");
            //    return;
            //}

            return;
        }

        public static void ClearPerSystemCache()
        {
            CachedSolarSystemtoGotoNextId = null;
            return;
        }

        private static bool EveryPulse()
        {
            if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugHighSecAnomalyBehavior) Log.WriteLine("HighSecAnomalyBehavior: CMBEveryPulse: if (!QCache.Instance.InSpace && !QCache.Instance.InStation)");
                return false;
            }

            if (ESCache.Instance.InAnomaly)
            {
                if (DebugConfig.DebugHighSecAnomalyBehavior) Log.WriteLine("HighSecAnomalyBehavior: CMBEveryPulse: if (QCache.Instance.InAbyssalDeadspace)");

                if (State.CurrentHighSecAnomalyBehaviorState != HighSecAnomalyBehaviorState.ExecuteMission)
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.ExecuteMission);

                ProcessAlerts();
                //next process panic as needed
            }

            Panic.ProcessState();

            if (State.CurrentPanicState == PanicState.Resume)
            {
                if (ESCache.Instance.InSpace || ESCache.Instance.InStation)
                {
                    State.CurrentPanicState = PanicState.Normal;
                    State.CurrentTravelerState = TravelerState.Idle;
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                    return true;
                }

                if (DebugConfig.DebugHighSecAnomalyBehavior) Log.WriteLine("HighSecAnomalyBehavior: CMBEveryPulse: if (State.CurrentPanicState == PanicState.Resume)");
                return false;
            }

            return true;
        }

        private static void ExecuteAnomalySiteState()
        {
            if (!ESCache.Instance.InSpace)
            {
                if (DebugConfig.DebugHighSecAnomalyBehavior) Log.WriteLine("AbyssalDeadspaceBehavior: ExecuteAbyssalDeadspaceSiteState: if (!QCache.Instance.InSpace)");
                return;
            }

            if (ESCache.Instance.CurrentShipsCargo == null)
            {
                if (DebugConfig.DebugHighSecAnomalyBehavior) Log.WriteLine("AbyssalDeadspaceBehavior: ExecuteAbyssalDeadspaceSiteState: if (QCache.Instance.CurrentShipsCargo == null)");
                return;
            }

            if (!ESCache.Instance.InAnomaly && DateTime.UtcNow > Time.Instance.LastActivateFilamentAttempt.AddSeconds(60))
            {
                //if (QCache.Instance.CurrentShipsCargo != null &&
                //    QCache.Instance.CurrentShipsCargo.Items != null &&
                //    QCache.Instance.CurrentShipsCargo.Items.Any(i => i.TypeId == AbyssalDeadspaceFilamentTypeId) &&
                //    RunAbyssalDeadspaceSitesUntilOurCargoContainsNoMoreCorrectFilaments)
                //{
                //    Log.WriteLine("AbyssalDeadspaceBehavior: ExecuteMission: InRegularSpace: RunAbyssalDeadspaceSitesUntilOurCargoContainsNoMoreCorrectFilaments");
                //    ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.GotoAbyssalBookmark);
                //    return;
                //}

                Log.WriteLine("HighSecAnomalyBehavior: ExecuteMission: We are not in an Anomaly: Go Home");
                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
                return;
            }

            if (DebugConfig.DebugHighSecAnomalyBehavior) Log.WriteLine("HighSecAnomalyBehavior: ExecuteMission: _actionControl.ProcessState();");

            ActionControl.ProcessState(null, null);

            if (NavigateOnGrid.ChooseNavigateOnGridTargets != null)
                NavigateOnGrid.NavigateIntoRange(NavigateOnGrid.ChooseNavigateOnGridTargets.FirstOrDefault(), "ClearPocket", true);
        }

        private static void GotoHomeBookmarkState()
        {
            if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
            {
                if (DebugConfig.DebugGotobase) Log.WriteLine("GotoHomeBookmark: AvoidBumpingThings()");
                NavigateOnGrid.AvoidBumpingThings(ESCache.Instance.BigObjects.FirstOrDefault(), "AbyssalDeadspaceBehaviorState.GotoBase", NavigateOnGrid.TooCloseToStructure, NavigateOnGrid.AvoidBumpingThingsBool());
            }

            if (DebugConfig.DebugGotobase) Log.WriteLine("GotoHomeBookmark: Traveler.TravelToBookmarkName(" + HomeBookmarkName + ");");

            Traveler.TravelToBookmarkName(HomeBookmarkName);

            if (State.CurrentTravelerState == TravelerState.AtDestination)
            {
                if (ESCache.Instance.InSpace)
                {
                    Log.WriteLine("HomeBookmark is defined as [" + HomeBookmarkName + "] and should be a bookmark of a station or citadel we can dock at: why are we still in space?!");
                    //Log.WriteLine("Pausing!");
                    //ControllerManager.Instance.SetPause(true);
                    return;
                }

                Traveler.Destination = null;
                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Start, true);
            }
        }

        private static void IdleCMBState()
        {
            State.CurrentAgentInteractionState = AgentInteractionState.Idle;
            State.CurrentArmState = ArmState.Idle;
            State.CurrentDroneState = DroneState.Idle;
            State.CurrentSalvageState = SalvageState.Idle;
            State.CurrentStorylineState = StorylineState.Idle;
            //State.CurrentTravelerState = TravelerState.AtDestination;
            State.CurrentUnloadLootState = UnloadLootState.Idle;

            if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
            {
                if (DebugConfig.DebugTargetWrecks)
                    Log.WriteLine("Salvage.OpenWrecks = false;");
                Salvage.OpenWrecks = false;
            }
            else
            {
                Salvage.OpenWrecks = true;
            }

            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.GotoHomeBookmark);
        }

        public static void InvalidateCache()
        {
        }

        private static void LocalWatchCMBState()
        {
            if (Settings.Instance.UseLocalWatch)
            {
                Time.Instance.LastLocalWatchAction = DateTime.UtcNow;

                if (DebugConfig.DebugArm) Log.WriteLine("Starting: Is LocalSafe check...");
                if (ESCache.Instance.LocalSafe(Settings.Instance.LocalBadStandingPilotsToTolerate, Settings.Instance.LocalBadStandingLevelToConsiderBad))
                {
                    Log.WriteLine("local is clear");
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.WarpOutStation);
                    return;
                }

                Log.WriteLine("Bad standings pilots in local: We will stay 5 minutes in the station and then we will check if it is clear again");
                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.WaitingforBadGuytoGoAway);
                return;
            }

            if (ESCache.Instance.DirectEve.Me.IsPvpLogoffTimerActive)
            {
                Log.WriteLine("LocalWatchCheck: We have pvp timer: waiting");
                return;
            }

            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.WarpOutStation);
        }

        private static bool ResetStatesToDefaults()
        {
            Log.WriteLine("HighSecAnomalyBehavior.ResetStatesToDefaults: start");
            State.CurrentHighSecAnomalyBehaviorState = HighSecAnomalyBehaviorState.Idle;
            State.CurrentArmState = ArmState.Idle;
            State.CurrentUnloadLootState = UnloadLootState.Idle;
            State.CurrentTravelerState = TravelerState.AtDestination;
            Log.WriteLine("HighSecAnomalyBehavior.ResetStatesToDefaults: done");
            return true;
        }

        private static void StartCMBState()
        {
            //
            // It takes 20 minutes (potentially) to do an anomaly: if it is within 25min of Downtime (10:35 evetime) pause
            //
            if (DateTime.UtcNow.Hour == 10 && DateTime.UtcNow.Minute > 35)
            {
                Log.WriteLine("HighSecAnomalyBehavior: Arm: Downtime is less than 25 minutes from now: Pausing");
                ControllerManager.Instance.SetPause(true);
                return;
            }

            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Switch);
        }

        private static void SwitchCMBState()
        {
            //if (QCache.Instance.CurrentShipsCargo == null || QCache.Instance.CurrentShipsCargo.Items == null || QCache.Instance.ItemHangar == null ||
            //    QCache.Instance.ItemHangar.Items == null)
            //    return;

            //if (QCache.Instance.InStation && Settings.Instance.BuyPlex && BuyPlexController.ShouldBuyPlex)
            //{
            //    BuyPlexController.CheckBuyPlex();
            //    ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.Idle);
            //    return;
            //}

            if (State.CurrentArmState == ArmState.Idle)
            {
                Log.WriteLine("Begin");
                Arm.SwitchShipsOnly = true;
                Arm.ChangeArmState(ArmState.ActivateCombatShip, true, null);
            }

            if (DebugConfig.DebugArm) Log.WriteLine("CombatMissionBehavior.Switch is Entering Arm.Processstate");
            Arm.ProcessState();

            if (State.CurrentArmState == ArmState.Done)
            {
                Log.WriteLine("Done");
                Arm.SwitchShipsOnly = false;
                Arm.ChangeArmState(ArmState.Idle, true, null);
                ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.UnloadLoot);
            }
        }

        private static void TravelerCMBState()
        {
            try
            {
                if (NavigateOnGrid.SpeedTank && !Salvage.LootWhileSpeedTanking)
                {
                    if (DebugConfig.DebugTargetWrecks) Log.WriteLine("Salvage.OpenWrecks = false;");
                    Salvage.OpenWrecks = false;
                }

                List<long> destination = ESCache.Instance.DirectEve.Navigation.GetDestinationPath();
                if (destination == null || destination.Count == 0)
                {
                    Log.WriteLine("No destination?");
                    State.CurrentHighSecAnomalyBehaviorState = HighSecAnomalyBehaviorState.Error;
                    return;
                }

                if (destination.Count == 1 && destination.FirstOrDefault() == 0)
                    destination[0] = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;

                if (Traveler.Destination == null || Traveler.Destination.SolarSystemId != destination.LastOrDefault())
                {
                    if (ESCache.Instance.DirectEve.Bookmarks != null && ESCache.Instance.DirectEve.Bookmarks.Any())
                    {
                        IEnumerable<DirectBookmark> bookmarks = ESCache.Instance.DirectEve.Bookmarks.Where(b => b.LocationId == destination.LastOrDefault()).ToList();
                        if (bookmarks.FirstOrDefault() != null && bookmarks.Any())
                        {
                            Traveler.Destination = new BookmarkDestination(bookmarks.OrderBy(b => b.CreatedOn).FirstOrDefault());
                            return;
                        }

                        Log.WriteLine("Destination: [" + ESCache.Instance.DirectEve.Navigation.GetLocation(destination.Last()).Name + "]");
                        long lastSolarSystemInRoute = destination.LastOrDefault();

                        Log.WriteLine("Destination: [" + lastSolarSystemInRoute + "]");
                        Traveler.Destination = new SolarSystemDestination(destination.LastOrDefault());
                        return;
                    }

                    return;
                }

                Traveler.ProcessState();

                if (State.CurrentTravelerState == TravelerState.AtDestination)
                {
                    if (State.CurrentCombatMissionCtrlState == ActionControlState.Error)
                    {
                        Log.WriteLine("an error has occurred");
                        ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Error, true);
                        return;
                    }

                    if (ESCache.Instance.InSpace)
                    {
                        Log.WriteLine("Arrived at destination (in space, Questor stopped)");
                        ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Error, true);
                        return;
                    }

                    Log.WriteLine("Arrived at destination");
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Idle, true);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void UnloadLootCMBState()
        {
            try
            {
                if (!ESCache.Instance.InStation)
                    return;

                //if (QCache.Instance.DirectEve.Session.Structureid.HasValue)
                //{
                //    Log.WriteLine("Currently Unloadloot does not work in Citadels, manually move your loot.");
                //    ChangeAbyssalDeadspaceBehaviorState(AbyssalDeadspaceBehaviorState.Arm);
                //    return;
                //}

                if (State.CurrentUnloadLootState == UnloadLootState.Idle)
                {
                    Log.WriteLine("UnloadLoot: Begin");
                    State.CurrentUnloadLootState = UnloadLootState.Begin;
                }

                UnloadLoot.ProcessState();

                if (State.CurrentUnloadLootState == UnloadLootState.Done)
                {
                    State.CurrentUnloadLootState = UnloadLootState.Idle;

                    if (State.CurrentCombatState == CombatState.OutOfAmmo)
                        Log.WriteLine("State.CurrentCombatState == CombatState.OutOfAmmo");

                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Arm, true);
                }
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
            }
        }

        private static void WaitingFoBadGuyToGoAway()
        {
            if (DateTime.UtcNow.Subtract(Time.Instance.LastLocalWatchAction).TotalMinutes <
                Time.Instance.WaitforBadGuytoGoAway_minutes + ESCache.Instance.RandomNumber(1, 3))
                return;

            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.LocalWatch);
        }

        private static void WarpOutBookmarkCMBState()
        {
            if (ESCache.Instance.EveAccount.OtherToonsAreStillLoggingIn)
            {
                Log.WriteLine("WarpOutBookmarkCMBState: Waiting for other toons to finish logging in before we undock!");
                return;
            }

            if (!string.IsNullOrEmpty(Settings.Instance.UndockBookmarkPrefix))
            {
                IEnumerable<DirectBookmark> warpOutBookmarks = ESCache.Instance.BookmarksByLabel(Settings.Instance.UndockBookmarkPrefix ?? "");
                if (warpOutBookmarks != null && warpOutBookmarks.Any())
                {
                    DirectBookmark warpOutBookmark = warpOutBookmarks.FirstOrDefault(b => b.LocationId == ESCache.Instance.DirectEve.Session.SolarSystemId && b.Distance < 10000000 && b.Distance > (int)Distances.WarptoDistance);

                    long solarid = ESCache.Instance.DirectEve.Session.SolarSystemId ?? -1;

                    if (warpOutBookmark == null)
                    {
                        Log.WriteLine("No Bookmark");
                        State.CurrentTravelerState = TravelerState.Idle;
                        ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.FindAnomaly);
                    }
                    else if (warpOutBookmark.LocationId == solarid)
                    {
                        if (Traveler.Destination == null)
                        {
                            Log.WriteLine("Warp at " + warpOutBookmark.Title);
                            Traveler.Destination = new BookmarkDestination(warpOutBookmark);
                        }

                        Traveler.ProcessState();
                        if (State.CurrentTravelerState == TravelerState.AtDestination)
                        {
                            Log.WriteLine("Safe!");
                            State.CurrentTravelerState = TravelerState.Idle;
                            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.FindAnomaly);
                            Traveler.Destination = null;
                        }
                    }
                    else
                    {
                        Log.WriteLine("No Bookmark in System");
                        State.CurrentTravelerState = TravelerState.Idle;
                        ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.FindAnomaly);
                    }

                    return;
                }
            }

            Log.WriteLine("No Bookmark in System");
            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.FindAnomaly);
        }

        private static void FindAnomalyState()
        {
            if (ESCache.Instance.InStation && !ESCache.Instance.InSpace)
            {
                TravelerDestination.Undock();
                return;
            }

            if (!ESCache.Instance.InSpace)
                return;

            if (ESCache.Instance.InWarp)
                return;

            if (!ESCache.Instance.InAnomaly)
            {
                if (Scanner.ProbeScanResultsReady)
                {
                    if (Scanner.AnomalyScanResults.Any())
                    {
                        //
                        // we want to filter the results based on the name of the anom and move on if we find none of that type
                        //
                        int intAnomNum = 0;
                        foreach (DirectSystemScanResult AnomalyScanResult in Scanner.AnomalyScanResults)
                        {
                            intAnomNum++;
                            Log.WriteLine("[" + intAnomNum + "][" + AnomalyScanResult.Id + "] GroupName [" + AnomalyScanResult.GroupName + "][" + AnomalyScanResult.ScanGroup + "][" + AnomalyScanResult.TypeName + "]");
                        }

                        //
                        // this return may need to be removed once this gets fleshed out more
                        //
                        return;
                    }
                    else
                    {
                        if (!ListOfSolarSystemsWeHaveChecked.Contains(ESCache.Instance.DirectEve.Session.SolarSystem))
                            ListOfSolarSystemsWeHaveChecked.Add(ESCache.Instance.DirectEve.Session.SolarSystem);

                        if (!ListOfSolarSystemsWeShouldAvoid.Contains(ESCache.Instance.DirectEve.Session.SolarSystem))
                            ListOfSolarSystemsWeShouldAvoid.Add(ESCache.Instance.DirectEve.Session.SolarSystem);
                    }

                    SetDestinationToNextSystem();
                    ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Traveler);
                    return;
                }

                Log.WriteLine("if (!Scanner.ProbeScanResultsReady)");
                return;
            }

            Log.WriteLine("if (ESCache.Instance.InAnomaly)");
            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.BookmarkAnomaly);
            return;
        }

        private static List<DirectSolarSystem> ListOfSolarSystemsWeHaveChecked = new List<DirectSolarSystem>();
        private static List<DirectSolarSystem> ListOfSolarSystemsWeShouldAvoid = new List<DirectSolarSystem>();

        private static DirectSolarSystem SolarSystemToGotoNext
        {
            get
            {
                //
                // need options to stay in the same constellation and or the same region: maybe a list of constellations?
                //
                if (ESCache.Instance.Stargates.Any(i => i.LeadsToSolarSystem.IsHighSecuritySpace && !ListOfSolarSystemsWeShouldAvoid.Contains(i.LeadsToSolarSystem)))
                {
                    foreach (EntityCache stargate in ESCache.Instance.Stargates.OrderBy(x => ListOfSolarSystemsWeHaveChecked.Contains(x.LeadsToSolarSystem)).Where(i => i.LeadsToSolarSystem.IsHighSecuritySpace && !ListOfSolarSystemsWeShouldAvoid.Contains(i.LeadsToSolarSystem) && SystemMeetsTravelLimitations(i.LeadsToSolarSystem)))
                    {
                        return stargate.LeadsToSolarSystem;
                    }
                }

                ListOfSolarSystemsWeShouldAvoid = new List<DirectSolarSystem>();
                if (ESCache.Instance.Stargates.Any(i => i.LeadsToSolarSystem.IsHighSecuritySpace && !ListOfSolarSystemsWeShouldAvoid.Contains(i.LeadsToSolarSystem)))
                {
                    foreach (EntityCache stargate in ESCache.Instance.Stargates.OrderBy(x => ListOfSolarSystemsWeHaveChecked.Contains(x.LeadsToSolarSystem)).Where(i => i.LeadsToSolarSystem.IsHighSecuritySpace && !ListOfSolarSystemsWeShouldAvoid.Contains(i.LeadsToSolarSystem) && SystemMeetsTravelLimitations(i.LeadsToSolarSystem)))
                    {
                        return stargate.LeadsToSolarSystem;
                    }
                }

                ListOfSolarSystemsWeShouldAvoid = new List<DirectSolarSystem>();
                if (ESCache.Instance.Stargates.Any(i => i.LeadsToSolarSystem.IsHighSecuritySpace && !ListOfSolarSystemsWeShouldAvoid.Contains(i.LeadsToSolarSystem)))
                {
                    foreach (EntityCache stargate in ESCache.Instance.Stargates.OrderBy(x => ListOfSolarSystemsWeHaveChecked.Contains(x.LeadsToSolarSystem)).Where(i => i.LeadsToSolarSystem.IsHighSecuritySpace && !ListOfSolarSystemsWeShouldAvoid.Contains(i.LeadsToSolarSystem)))
                    {
                        return stargate.LeadsToSolarSystem;
                    }
                }

                return ESCache.Instance.ClosestStargate.LeadsToSolarSystem;
            }
        }

        private static void SetDestinationToNextSystem()
        {
            CachedSolarSystemtoGotoNextId = SolarSystemToGotoNext.Id;
        }

        private static bool limitTravelToSameRegion = false;
        private static bool limitTravelToSameConstellation = false;

        private static bool SystemMeetsTravelLimitations(DirectSolarSystem destinationSolarSystem)
        {
            if (limitTravelToSameRegion)
            {
                if (ESCache.Instance.DirectEve.Session.Region.Id != destinationSolarSystem.Region.Id)
                {
                    return false;
                }
            }

            if (limitTravelToSameConstellation)
            {
                if (ESCache.Instance.DirectEve.Session.Constellation.Id != destinationSolarSystem.Constellation.Id)
                {
                    return false;
                }
            }

            return false;
        }

        private static long? CachedSolarSystemtoGotoNextId = null;

        private static void TravelToNextSystem()
        {
            if (CachedSolarSystemtoGotoNextId != null)
            {
                Traveler.TravelToSystemId((long)CachedSolarSystemtoGotoNextId);
                return;
            }

            ChangeHighSecAnomalyBehaviorState(HighSecAnomalyBehaviorState.Idle);
        }


        private static void BookmarkAnomalyState()
        {

            return;
        }

        #endregion Methods
    }
}