﻿using HtmlAgilityPack;
using ImapX.Collections;
using SharedComponents.EVE;
using SharedComponents.EVEAccountCreator;
using SharedComponents.EVEAccountCreator.Curl;
using SharedComponents.IMAP;
using SharedComponents.Socks5.Socks5Relay;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Authentication;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;
using Message = ImapX.Message;

namespace EVESharpLauncher
{
    public partial class EveAccountCreatorForm : Form
    {
        #region Constructors

        public EveAccountCreatorForm()
        {
            InitializeComponent();
            Tasks = new List<Task<Tuple<bool, string, string, string>>>();
            cTokenSource = new CancellationTokenSource();
            CurrentEmailProvider = EmailProviders.Last();
        }

        #endregion Constructors

        #region Properties

        private bool IsIndicatingProgress { get; set; }

        #endregion Properties

        #region Enums

        private enum EmailProvider
        {
            Google,
            Yandex,
            Outlook
        }

        #endregion Enums

        #region Fields

        private readonly List<IDisposable> drivers = new List<IDisposable>();

        private readonly Dictionary<EmailProvider, Tuple<string, string>> EmailProviders = new Dictionary<EmailProvider, Tuple<string, string>>
        {
            {EmailProvider.Google, new Tuple<string, string>("imap.gmail.com", "@gmail.com")},
            {EmailProvider.Yandex, new Tuple<string, string>("imap.yandex.com", "@yandex.com")},
            {EmailProvider.Outlook, new Tuple<string, string>("imap-mail.outlook.com", "@outlook.com")}
        };

        private CancellationTokenSource cTokenSource;

        private KeyValuePair<EmailProvider, Tuple<string, string>> CurrentEmailProvider;
        private List<Task<Tuple<bool, string, string, string>>> Tasks;

        #endregion Fields

        #region Methods

        private void button1_Click(object sender, EventArgs e)
        {
            StopAllTasks();
        }

        private void ButtonAbortEmailValidation_Click(object sender, EventArgs e)
        {
            StopAllTasks();
        }

        private void ButtonAddTrial_Click(object sender, EventArgs e)
        {
            cTokenSource = new CancellationTokenSource();
            int upDownValue = (int) numericUpDown1.Value;
            Tasks = new List<Task<Tuple<bool, string, string, string>>>();

            new Thread(() =>
            {
                try
                {
                    Invoke(new Action(() => buttonStartAlphaCreation.Enabled = false));

                    Proxy prx = (Proxy) Invoke(new Func<Proxy>(() => (Proxy) comboBoxProxies.SelectedItem));

                    if (prx == null || !prx.IsValid)
                    {
                        Cache.Instance.Log("Proxy is null or Invalid. Is there a valid proxy selected in the Hardware Profile?");
                        return;
                    }

                    if (!prx.InternetConnectivityTest())
                        return;

                    RunProgressbar();

                    List<Tuple<string, string, string>> eveAccounts = new List<Tuple<string, string, string>>();

                    for (int i = 0; i < upDownValue; i++)
                    {
                        string eveUsername = UserPassGen.Instance.GenerateUsername();
                        string evePassword = UserPassGen.Instance.GeneratePassword();
                        int n = i;
                        Task<Tuple<bool, string, string, string>> t =
                            Task.Run(
                                async () =>
                                {
                                    return await new EveAccountCreatorImpl(n).CreateEveAlphaAccountAndValidate(string.Empty, eveUsername, evePassword,
                                        prx.GetSocks5IpPort(), prx.GetUserPassword(), cTokenSource.Token);
                                }, cTokenSource.Token);

                        Tasks.Add(t);
                    }

                    foreach (Task<Tuple<bool, string, string, string>> task in Tasks)
                        try
                        {
                            task.Wait();
                        }
                        catch (AggregateException)
                        {
                        }

                    foreach (Task<Tuple<bool, string, string, string>> task in Tasks)
                    {
                        if (task.Exception != null)
                            continue;
                        if (task.Result != null && task.Result.Item1)
                            eveAccounts.Add(new Tuple<string, string, string>(task.Result.Item2, task.Result.Item3, task.Result.Item4));
                    }

                    foreach (Tuple<string, string, string> a in eveAccounts)
                    {
                        EveAccount eA = new EveAccount(a.Item1, a.Item1, a.Item2, DateTime.UtcNow, DateTime.UtcNow, false);
                        eA.HWSettings = new HWSettings();
                        eA.HWSettings.GenerateRandomProfile();
                        eA.HWSettings.Proxy = prx;
                        eA.Email = a.Item3;
                        Invoke(new Action(() => Cache.Instance.EveAccountSerializeableSortableBindingList.List.Add(eA)));
                    }
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log(ex.ToString());
                    Debug.WriteLine(ex.ToString());
                }
                finally
                {
                    try
                    {
                        IsIndicatingProgress = false;
                        Invoke(new Action(() => buttonStartAlphaCreation.Enabled = true));
                    }
                    catch (Exception exception)
                    {
                        Cache.Instance.Log(exception.ToString());
                        Debug.WriteLine(exception);
                    }
                }
            }).Start();
        }

        private void ButtonCreateEmailAccount_Click(object sender, EventArgs e)
        {
            Proxy prx = GetProxy();
            if (prx == null || !prx.IsValid)
            {
                Cache.Instance.Log("Proxy is null or Invalid. Is there a valid proxy selected in the Hardware Profile?");
                return;
            }

            if (!prx.InternetConnectivityTest())
                return;

            switch (CurrentEmailProvider.Key)
            {
                case EmailProvider.Google:
                    break;

                case EmailProvider.Yandex:
                    YandexCurl yandexImpl = new YandexCurl();
                    yandexImpl.CreateYandexEmail(textBoxEmailAddress.Text, textBoxPassword.Text, GetProxy());
                    break;

                case EmailProvider.Outlook:
                    Outlook outlookImpl = new Outlook();
                    drivers.Add(outlookImpl);
                    new Task(() =>
                    {
                        try
                        {
                            outlookImpl.CreateOutlookEmail(textBoxEmailAddress.Text.Split('@')[0], textBoxPassword.Text, prx, textBoxRecoveryEmailAddress.Text);
                        }
                        catch (Exception ex)
                        {
                            Cache.Instance.Log("Exception: " + ex);
                        }
                    }).Start();
                    break;
            }
        }

        private void ButtonCreateEveAccount_Click(object sender, EventArgs e)
        {
            if (GetProxy() != null)
            {
                Proxy prx = GetProxy();

                if (prx == null || !prx.IsValid)
                {
                    Cache.Instance.Log("Proxy is null or Invalid. Is there a valid proxy selected in the Hardware Profile?");
                    return;
                }

                if (!prx.InternetConnectivityTest())
                    return;

                //                using (var curlWorker = new CurlWorker())
                //                {
                //                    var res = new EveAccountCreatorImpl(0).CreateEveAccount(string.Empty, textBoxEmailAddress.Text, textBoxEveAccountName.Text,
                //                        textBoxPassword.Text, p.GetIpPort(), p.GetUserPassword(), curlWorker);
                //
                //                    if (res)
                //                    {
                //                        var msg = string.Format("Eve account created. Email [{0}] Acc [{1}] Password [{2}]", textBoxEmailAddress.Text,
                //                            textBoxEveAccountName.Text,
                //                            textBoxPassword.Text);
                //                        Cache.Instance.Log(msg);
                //                        Debug.WriteLine(msg);
                //                    }
                //                }

                prx.StartFireFoxInject("https://secure.eveonline.com/signup/");
            }
        }

        private void ButtonGenerateRandom_Click(object sender, EventArgs e)
        {
            GenerateRandom();
        }

        private void ButtonOpenFirefox_Click(object sender, EventArgs e)
        {
            Proxy p = (Proxy) comboBoxProxies.SelectedItem;
            if (p != null)
                p.StartFireFoxInject();
        }

        private void ButtonValidateEveAccount_Click(object sender, EventArgs e)
        {
            Proxy prx = GetProxy();

            if (prx == null || !prx.IsValid)
            {
                Cache.Instance.Log("Proxy is null or Invalid. Is there a valid proxy selected in the Hardware Profile?");
                return;
            }

            if (!prx.InternetConnectivityTest())
                return;

            cTokenSource = new CancellationTokenSource();

            new Thread(() =>
            {
                try
                {
                    Invoke(new Action(() => buttonValidateEveAccount.Enabled = false));

                    RunProgressbar();

                    Task t = new Task(() =>
                    {
                        bool emailFound = false;
                        while (!emailFound)
                        {
                            Cache.Instance.Log("Validation task running.");
                            try
                            {
                                if (cTokenSource.Token.IsCancellationRequested)
                                    return;

                                MessageCollection emails = Imap.GetInboxEmails(textBoxIMAPHost.Text, 993, SslProtocols.Default, true, textBoxEmailAddress.Text, textBoxPassword.Text, prx.Ip, Convert.ToInt32(prx.Socks5Port),
                                    prx.Username, prx.Password);

                                foreach (Message email in emails)
                                {
                                    Cache.Instance.Log(email.Body.Text);
                                    Cache.Instance.Log(email.Body.Html);
                                    try
                                    {
                                        HtmlDocument htmlDoc = new HtmlDocument();
                                        htmlDoc.LoadHtml(email.Body.Html);
                                        HtmlNodeCollection nodes = htmlDoc.DocumentNode.SelectNodes("//a[contains(@href, 'http://click.service.ccpgames.com/?')]");

                                        if (nodes.Count > 0 && nodes.Count == 2)
                                        {
                                            Cache.Instance.Log("We found a node with the link. Nodes: " + nodes.Count);
                                            HtmlNode node = nodes.FirstOrDefault();

                                            if (node != null)
                                            {
                                                string verificationUrl = node.Attributes["href"].Value;
                                                Cache.Instance.Log(string.Format("Verification url found [{0}]", verificationUrl));

                                                prx.StartFireFoxInject(verificationUrl);

                                                Cache.Instance.Log($"Added account {textBoxEveAccountName.Text}");
                                                EveAccount eA = new EveAccount(textBoxEveAccountName.Text, textBoxEveAccountName.Text, textBoxPassword.Text,
                                                    DateTime.UtcNow, DateTime.UtcNow, false);
                                                eA.HWSettings = new HWSettings();
                                                eA.HWSettings.GenerateRandomProfile();
                                                eA.HWSettings.Proxy = prx;
                                                eA.Email = textBoxEmailAddress.Text;
                                                eA.IMAPHost = textBoxIMAPHost.Text;
                                                Invoke(new Action(() => Cache.Instance.EveAccountSerializeableSortableBindingList.List.Add(eA)));

                                                emailFound = true;
                                            }
                                            else
                                            {
                                                Cache.Instance.Log("Node is null.");
                                            }
                                        }
                                        else
                                        {
                                            Cache.Instance.Log("No nodes found.");
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        Cache.Instance.Log("Exception: " + ex);
                                    }
                                }
                            }
                            catch (Exception exception)
                            {
                                Cache.Instance.Log("Exception:" + exception);
                            }
                            finally
                            {
                                if (!emailFound)
                                    Task.Delay(500);
                            }
                        }
                    });

                    t.Start();
                    t.Wait();
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log(ex.ToString());
                    Debug.WriteLine(ex.ToString());
                }
                finally
                {
                    try
                    {
                        IsIndicatingProgress = false;
                        Invoke(new Action(() => buttonValidateEveAccount.Enabled = true));
                    }
                    catch (Exception exception)
                    {
                        Cache.Instance.Log(exception.ToString());
                        Debug.WriteLine(exception);
                    }
                }
            }).Start();
        }

        private void ComboBoxProxies_SelectedIndexChanged(object sender, EventArgs e)
        {
            Proxy p = GetProxy();
            if (p != null)
                try
                {
                    string s = p.GetUserPassword() + "@" + p.GetSocks5IpPort();
                    Debug.WriteLine("Relaying args: " + s);
                    DsocksHandler.StartChain(new[] {s});
                }
                catch (Exception ex)
                {
                    Cache.Instance.Log(ex.ToString());
                }
        }

        private void EveAccountCreatorForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            foreach (IDisposable d in drivers)
                if (d != null)
                    try
                    {
                        d.Dispose();
                    }
                    catch (Exception exception)
                    {
                        Debug.WriteLine(exception);
                    }
        }

        private void EveAccountCreatorForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopAllTasks();
            DsocksHandler.Dispose();
            Outlook.KillGeckoDrivers();
        }

        private void EveAccountCreatorForm_Load(object sender, EventArgs e)
        {
            Outlook.KillGeckoDrivers();

            comboBoxProxies.DataSource = Cache.Instance.EveSettings.Proxies;
            comboBoxProxies.DisplayMember = "Description";
            comboBoxProxies.SelectedIndex = -1;
        }

        private void EveAccountCreatorForm_Shown(object sender, EventArgs e)
        {
            GenerateRandom();
            comboBoxProxies.Select();
        }

        private void GenerateRandom()
        {
            textBoxEmailAddress.Text = UserPassGen.Instance.GenerateUsername() + CurrentEmailProvider.Value.Item2;
            textBoxPassword.Text = UserPassGen.Instance.GeneratePassword();
            textBoxEveAccountName.Text = UserPassGen.Instance.GenerateUsername();
            textBoxRecoveryEmailAddress.Text = Cache.Instance.EveSettings.ReceiverEmailAddress;
        }

        private Proxy GetProxy()
        {
            return (Proxy) comboBoxProxies.SelectedItem;
        }

        private void RadioButtonGmail_CheckedChanged(object sender, EventArgs e)
        {
            CurrentEmailProvider = EmailProviders.Where(em => em.Key == EmailProvider.Google).First();
            textBoxIMAPHost.Text = CurrentEmailProvider.Value.Item1;
            GenerateRandom();
        }

        private void RadioButtonOutlook_CheckedChanged(object sender, EventArgs e)
        {
            CurrentEmailProvider = EmailProviders.Where(em => em.Key == EmailProvider.Outlook).First();
            textBoxIMAPHost.Text = CurrentEmailProvider.Value.Item1;
            GenerateRandom();
        }

        private void RadioButtonYandex_CheckedChanged(object sender, EventArgs e)
        {
            CurrentEmailProvider = EmailProviders.Where(em => em.Key == EmailProvider.Yandex).First();
            textBoxIMAPHost.Text = CurrentEmailProvider.Value.Item1;
            GenerateRandom();
        }

        private void RunProgressbar()
        {
            if (IsIndicatingProgress)
                return;

            IsIndicatingProgress = true;
            new Thread(() =>
            {
                while (IsIndicatingProgress)
                {
                    Thread.Sleep(1000);
                    try
                    {
                        progressBar1.Invoke(new Action(() =>
                        {
                            if (progressBar1.Value == progressBar1.Maximum)
                                progressBar1.Value = 0;
                            progressBar1.PerformStep();
                        }));
                    }
                    catch (Exception)
                    {
                    }
                }

                progressBar1.Invoke(new Action(() => { progressBar1.Value = 0; }));
            }).Start();
        }

        private void StopAllTasks()
        {
            Cache.Instance.Log("Cancellation of all tasks requested.");
            cTokenSource.Cancel();
        }

        #endregion Methods
    }
}