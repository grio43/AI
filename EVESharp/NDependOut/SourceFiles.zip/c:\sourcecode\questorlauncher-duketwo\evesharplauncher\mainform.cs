﻿using EVESharpLauncher.SocksServer;
using SharedComponents.EVE;
using SharedComponents.Events;
using SharedComponents.Extensions;
using SharedComponents.IPC;
using SharedComponents.Notifcations;
using SharedComponents.SharpLogLite.Model;
using SharedComponents.Utility;
using SharedComponents.WinApiUtil;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EVESharpLauncher
{
    public partial class MainForm : Form
    {
        #region Constructors

        public MainForm()
        {
            InitializeComponent();
            evenTabs = new Dictionary<string, MainFormEventTab>();
            logTab = new MainFormEventTab("Log", true);
            tabControl1.TabPages.Add(logTab);
            Cache.AsyncLogQueue.OnMessage += Log;
            DirectEventHandler.OnDirectEvent += OnNewDirectEvent;
            SharpLogLiteHandler.Instance.OnSharpLogLiteMessage += InstanceOnSharpLogLiteMessage;
            Cache.Instance.Log("EveSharpLauncher: Started");
            //thumbPreviewTab = new ThumbPreviewTab(this, mainTabCtrl);
            EveManager.Instance.StartEveManager();
        }

        #endregion Constructors

        #region Classes

        public static class DrawingControl
        {
            #region Fields

            private const int WM_SETREDRAW = 11;

            #endregion Fields

            #region Methods

            /// <summary>
            ///     Resume drawing updates for the specified control.
            /// </summary>
            /// <param name="control">The control to resume draw updates on.</param>
            public static void ResumeDrawing(Control control)
            {
                SendMessage(control.Handle, WM_SETREDRAW, true, 0);
                control.Refresh();
            }

            [DllImport("user32.dll")]
            public static extern int SendMessage(IntPtr hWnd, int wMsg, bool wParam, int lParam);

            /// <summary>
            ///     Some controls, such as the DataGridView, do not allow setting the DoubleBuffered property.
            ///     It is set as a protected property. This method is a work-around to allow setting it.
            ///     Call this in the constructor just after InitializeComponent().
            /// </summary>
            /// <param name="control">The Control on which to set DoubleBuffered to true.</param>
            public static void SetDoubleBuffered(Control control)
            {
                // if not remote desktop session then enable double-buffering optimization
                if (!SystemInformation.TerminalServerSession)
                    typeof(Control).InvokeMember("DoubleBuffered",
                        BindingFlags.SetProperty |
                        BindingFlags.Instance |
                        BindingFlags.NonPublic,
                        null,
                        control,
                        new object[] {true});
            }

            /// <summary>
            ///     Suspend drawing updates for the specified control. After the control has been updated
            ///     call DrawingControl.ResumeDrawing(Control control).
            /// </summary>
            /// <param name="control">The control to suspend draw updates on.</param>
            public static void SuspendDrawing(Control control)
            {
                SendMessage(control.Handle, WM_SETREDRAW, false, 0);
            }

            #endregion Methods
        }

        #endregion Classes

        #region Fields

        private static readonly Color backColor = Color.FromArgb(0, 113, 188);
        private static SemaphoreSlim sema = new SemaphoreSlim(1, 1);
        private ClientSettingForm clientSettingForm;

        private ThumbPreviewTab thumbPreviewTab;

        #endregion Fields

        #region Properties

        private IntPtr CurrentHandle { get; set; }
        private Dictionary<string, MainFormEventTab> evenTabs { get; }
        private MainFormEventTab logTab { get; }

        #endregion Properties

        #region Methods

        public void DisableDrawDatagrid()
        {
            Pinvokes.SendMessage(dataGridEveAccounts.Handle, Pinvokes.WM_SETREDRAW, false, 0);
        }

        public void EnableDrawDatagrid()
        {
            Pinvokes.SendMessage(dataGridEveAccounts.Handle, Pinvokes.WM_SETREDRAW, true, 0);
            dataGridEveAccounts.Refresh();
        }

        public void Log(string msg, Color? col = null)
        {
            if (!IsHandleCreated)
                return;
            try
            {
                logTab.Invoke(new Action(() => { logTab.AddRawMessage(msg); }));
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
            }
        }

        public void OnNewDirectEvent(string charName, DirectEvent directEvent)
        {
            try
            {
                Invoke(new Action(() =>
                {
                    Email.onNewDirectEvent(charName, directEvent);
                    GetEventTab(charName).AddNewEvent(directEvent);
                }));
            }
            catch (Exception e)
            {
                Debug.WriteLine(e);
                throw;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                if (eA.GetClientCallback() != null)
                {
                    Debug.WriteLine(eA.CharacterName + " callback available, calling...");
                    eA.GetClientCallback().OnCallback();
                }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Thread(() =>
            {
                try
                {
                    Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(k => k.GetClientCallback() != null)
                        .ToList()
                        .ForEach(k =>
                        {
                            try
                            {
                                k.GetClientCallback().GotoHomebaseAndIdle();
                            }
                            catch
                            {
                            }
                        });
                    //EveManager.Instance.DisposeEveManager();
                }
                catch (Exception ex)
                {
                    Log("Exception: " + ex);
                }
            }).Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Thread(() =>
            {
                try
                {
                    Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(k => k.GetClientCallback() != null)
                        .ToList()
                        .ForEach(k =>
                        {
                            try
                            {
                                k.GetClientCallback().PauseAfterNextDock();
                            }
                            catch
                            {
                            }
                        });
                    //EveManager.Instance.DisposeEveManager();
                }
                catch (Exception ex)
                {
                    Log("Exception: " + ex);
                }
            }).Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            new Thread(() =>
            {
                try
                {
                    Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(k => k.GetClientCallback() != null)
                        .ToList()
                        .ForEach(k =>
                        {
                            try
                            {
                                k.GetClientCallback().GotoJita();
                            }
                            catch
                            {
                            }
                        });
                    //EveManager.Instance.DisposeEveManager();
                }
                catch (Exception ex)
                {
                    Log("Exception: " + ex);
                }
            }).Start();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Cache.Instance.EveAccountSerializeableSortableBindingList.List.ToList().ForEach(k => k.ClearCache());
        }

        private void ButtonbuttonKillAllEveInstancesNowClick(object sender, EventArgs e)
        {
            EveManager.Instance.KillEveInstances();
        }

        private void buttonCheckHWProfiles_Click(object sender, EventArgs e)
        {
            Cache.Instance.AnyAccountsLinked(true);
        }

        private void ButtonGenNewBeginEndClick(object sender, EventArgs e)
        {
            foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                eA.GenerateNewTimeSpans();
        }

        private void ButtonKillAllEveInstancesClick(object sender, EventArgs e)
        {
            EveManager.Instance.KillEveInstancesDelayed();
        }

        private void ButtonStartEveMangerClick(object sender, EventArgs e)
        {
            EveManager.Instance.StartEveManager();
        }

        private void ButtonStopEveMangerClick(object sender, EventArgs e)
        {
            EveManager.Instance.DisposeEveManager();
        }

        private void testImapEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridView dgv = ActiveControl as DataGridView;
            if (dgv == null) return;
            int index = dgv.SelectedCells[0].OwningRow.Index;
            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
            eA.TestImapEmail();
        }

        private void clearCacheToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DataGridView dgv = ActiveControl as DataGridView;
            if (dgv == null) return;
            int index = dgv.SelectedCells[0].OwningRow.Index;
            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
            eA.ClearCache();
        }

        private void CompileQuestorToolStripMenuItemClick(object sender, EventArgs e)
        {
            Util.RunInDirectory("Updater.exe", "CompileAllAndCopy");
        }

        private void ContextMenuStrip1Opening(object sender, CancelEventArgs e)
        {
            try
            {
                DataGridView dgv = ActiveControl as DataGridView;
                if (dgv == null) return;
                int index = dgv.SelectedCells[0].OwningRow.Index;
                EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
            }
            catch (Exception exception)
            {
                Debug.WriteLine(exception.ToString());
            }
        }

        private void dataGridEveAccounts_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            Task.Run(() =>
            {
                dataGridEveAccounts.Invoke(new Action(() =>
                {
                    dataGridEveAccounts.ColumnHeadersDefaultCellStyle.BackColor = backColor; // #0071BC
                    dataGridEveAccounts.BackColor = backColor;
                }));
                Cache.Instance.EveAccountSerializeableSortableBindingList.List.RaiseListChangedEvents = false;
            });
            dataGridEveAccounts.SuspendLayout();
        }

        private void dataGridEveAccounts_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            Task.Run(() =>
            {
                try
                {
                    dataGridEveAccounts.Invoke(new Action(() => { dataGridEveAccounts.ColumnHeadersDefaultCellStyle.BackColor = SystemColors.Control; }));
                    Cache.Instance.EveAccountSerializeableSortableBindingList.List.RaiseListChangedEvents = true;
                }
                catch (Exception){}
            });
            dataGridEveAccounts.ResumeLayout();
        }

        private void dataGridEveAccounts_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            try
            {
                if (dataGridEveAccounts.CurrentCell != null && dataGridEveAccounts.CurrentCell.IsInEditMode)
                {
                    int cIndex = dataGridEveAccounts.CurrentCell.ColumnIndex;
                    int rIndex = dataGridEveAccounts.CurrentCell.RowIndex;

                    if (e.RowIndex == rIndex && e.ColumnIndex == cIndex)
                        return;
                }

                string name = dataGridEveAccounts.Columns[e.ColumnIndex].Name;
                if (name.Equals("Password") && e.Value != null)
                {
                    dataGridEveAccounts.Rows[e.RowIndex].Tag = e.Value;
                    e.Value = new string('\u25CF', e.Value.ToString().Length);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        private void dataGridEveAccounts_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridView dgv = (DataGridView) sender;
                DataGridViewCell c = dataGridEveAccounts.SelectedCells[0];
                int index = c.OwningRow.Index;
                if (c.OwningColumn.Name == "Controller")
                {
                    EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
                    eA.SelectedController = (string) c.Value;
                }
            }
            catch
            {
            }
        }

        private void dataGridEveAccounts_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            // Don't throw an exception when we're done.
            e.ThrowException = false;

            //extra : more customized to replace the
            // system error text & in any language
            string exType = e.Exception.GetType().ToString();

            // Display an error message.
            string txt = "Error with [ " + dataGridEveAccounts.Columns[e.ColumnIndex].HeaderText + " ] \n\n" + e.Exception.Message;
            if (exType == "System.FormatException")
                Cache.Instance.Log($"Datagrid error: {txt}");
            // If this is true, then the user is trapped in this cell.
            e.Cancel = false;
        }

        private void dataGridEveAccounts_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
        }

        private void dataGridEveAccounts_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(dataGridEveAccounts.RowHeadersDefaultCellStyle.ForeColor))
            {
                e.Graphics.DrawString((e.RowIndex + 1).ToString(), e.InheritedRowStyle.Font, b, e.RowBounds.Location.X + 14, e.RowBounds.Location.Y + 4);
            }
        }

        private void dataGridEveAccounts_SelectionChanged(object sender, EventArgs e)
        {
            Task.Run(() =>
            {
                try
                {
                    TableLayoutPanel eventTableLayoutPanel = new TableLayoutPanel();
                    eventTableLayoutPanel.Location = new Point(3, 3);
                    int count = 12;
                    eventTableLayoutPanel.RowCount = count;
                    eventTableLayoutPanel.ColumnCount = 1;
                    eventTableLayoutPanel.Dock = DockStyle.Fill;
                    eventTableLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
                    Dictionary<int, Label> labelDict = new Dictionary<int, Label>();

                    for (int i = 0; i < count; i++)
                    {
                        eventTableLayoutPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100 / count));
                        Label l1 = new Label();
                        labelDict[i] = l1;
                        l1.Dock = DockStyle.Fill;
                        eventTableLayoutPanel.Controls.Add(l1);
                    }

                    tabPage3.Controls.Clear();
                    tabPage3.Controls.Add(eventTableLayoutPanel);

                    if (!(ActiveControl is DataGridView dgv)) return;
                    if (dgv.SelectedCells.Count > 0)
                    {
                        int index = dgv.SelectedCells[0].OwningRow.Index;
                        if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.ElementAtOrDefault(index) != null)
                        {
                            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
                            if (eA != null && eA.CharsOnAccount != null)
                                labelDict[0].Text = $"Other chars: {string.Join(", ", eA.CharsOnAccount.Where(h => !h.Equals(eA.CharacterName)))}";
                            labelDict[1].Text = $"Last ammo buy: {eA.LastAmmoBuy}";
                            labelDict[2].Text = $"Last plex buy: {eA.LastPlexBuy}";
                            labelDict[3].Text = $"Last start time: {eA.LastStartTime}";
                            labelDict[4].Text = $"Next cache deletion: {eA.NextCacheDeletion}";
                            labelDict[5].Text = $"Process Id: {eA.Pid}";
                            labelDict[6].Text = $"Ram usage: {Math.Round(eA.RamUsage, 1)} mb";
                            labelDict[7].Text = $"Run time today: {Math.Round(eA.StartingTokenTimespan.TotalHours, 2)} h";
                            DateTime skillQueueEnd = eA.mySkillQueueEnds > DateTime.UtcNow ? eA.mySkillQueueEnds : DateTime.UtcNow;
                            labelDict[8].Text = $"Skill queue end: {Math.Round((skillQueueEnd - DateTime.UtcNow).TotalDays, 2)} days";
                            labelDict[9].Text = $"Dump loot iterations: {eA.DumpLootIterations}";
                        }
                    }

                    //tabControl3.Invoke(new Action(() =>
                    //{
                    //    tabPage3.Controls.Clear();
                    //    tabPage3.SuspendLayout();
                    //    tabPage3.Controls.Add(eventTableLayoutPanel);
                    //    tabPage3.ResumeLayout();
                    //}));
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.ToString());
                }
            });
        }

        private void DeleteToolStripMenuItem1Click(object sender, EventArgs e)
        {
            if (!(ActiveControl is DataGridView dgv)) return;
            int selected = dgv.SelectedCells[0].OwningRow.Index;

            if (selected >= 0)
                Cache.Instance.EveAccountSerializeableSortableBindingList.List.RemoveAt(selected);
        }

        private void EditAdapteveHWProfileToolStripMenuItemClick(object sender, EventArgs e)
        {
            DataGridView dgv = ActiveControl as DataGridView;
            if (dgv == null) return;
            int index = dgv.SelectedCells[0].OwningRow.Index;
            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];

            HWProfileForm hwPf = new HWProfileForm(eA);
            hwPf.Show();
        }

        private void editClientConfigurationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /**
            DataGridView dgv = ActiveControl as DataGridView;
            if (dgv == null) return;
            int index = dgv.SelectedCells[0].OwningRow.Index;
            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
            if (clientSettingForm != null)
                clientSettingForm.Close();
            clientSettingForm = new ClientSettingForm(eA);
            clientSettingForm.Show();
            **/
        }

        private MainFormEventTab GetEventTab(string charName)
        {
            MainFormEventTab tab;
            evenTabs.TryGetValue(charName, out tab);
            if (tab == null)
            {
                tab = new MainFormEventTab(charName);
                evenTabs[charName] = tab;
                tabControl1.TabPages.Add(tab);
            }
            return tab;
        }

        private void HideToolStripMenuItemClick(object sender, EventArgs e)
        {
            foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(a => a.IsProcessAlive()))
                eA.HideWindows();
        }

        private void InstanceOnSharpLogLiteMessage(SharpLogMessage msg)
        {
            string charName;
            if (EveAccount.CharnameByPid.TryGetValue(msg.Pid, out charName))
                Invoke(new Action(() =>
                {
                    MainFormEventTab tab = GetEventTab(charName);
                    tab.AddSharpLogLiteMessage(msg, charName);
                }));
        }

        private void MainForm_Shown(object sender, EventArgs e)
        {
            CurrentHandle = Handle;
            MainFormResize(this, new EventArgs());
            Cache.Instance.MainFormHWnd = (long) CurrentHandle;
        }

        private void MainFormFormClosed(object sender, FormClosedEventArgs e)
        {
            SharpLogLiteHandler.Instance.Dispose();
            Cache.Instance.EveAccountSerializeableSortableBindingList.List.XmlSerialize(Cache.Instance.EveAccountSerializeableSortableBindingList.FilePathName);
            Cache.Instance.EveSettingsSerializeableSortableBindingList.List.XmlSerialize(
                Cache.Instance.EveSettingsSerializeableSortableBindingList.FilePathName);
            SharpLogLiteHandler.Instance.OnSharpLogLiteMessage -= InstanceOnSharpLogLiteMessage;
            DirectEventHandler.OnDirectEvent -= OnNewDirectEvent;
            EveManager.Instance.Dispose();
            Cache.IsShuttingDown = true;
            Cache.BroadcastShutdown();
            try
            {
                Application.Exit();
            }
            catch (Exception)
            {
            }
        }

        private void MainFormLoad(object sender, EventArgs e)
        {
            dataGridEveAccounts.DataSource = Cache.Instance.EveAccountSerializeableSortableBindingList.List; //.OrderBy(i => i.AccountName);
            DrawingControl.SetDoubleBuffered(dataGridEveAccounts);
            DrawingControl.SuspendDrawing(dataGridEveAccounts);

            DataGridViewComboBoxColumn cmb = new DataGridViewComboBoxColumn();
            cmb.HeaderText = "Controller";
            cmb.Name = "Controller";
            cmb.MaxDropDownItems = EveAccount.AvailableControllers.Count + 1;
            cmb.DataSource = EveAccount.AvailableControllers;
            dataGridEveAccounts.Columns.Insert(dataGridEveAccounts.Columns["UseScheduler"].Index, cmb);

            foreach (DataGridViewRow r in dataGridEveAccounts.Rows)
            {
                r.Resizable = DataGridViewTriState.True;
                r.Frozen = false;
                foreach (DataGridViewCell c in r.Cells)
                    if (c.OwningColumn.Name == "Controller")
                    {
                        int index = c.OwningRow.Index;
                        try
                        {
                            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
                            c.Value = eA.SelectedController;
                        }
                        catch
                        {
                        }
                    }
            }

            //dataGridEveAccounts.Columns["Info"].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            //dataGridEveAccounts.Columns["Info"].Width = 220;

            foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(eA => !eA.IsProcessAlive()))
                eA.Pid = -1;

            try
            {
                if (textBoxPastebin != null)
                    textBoxPastebin.Text = Regex.Replace(Cache.Instance.EveSettings.Pastebin, @"\r\n|\n\r|\n|\r", Environment.NewLine);
            }
            catch (Exception)
            {
            }

            WCFServer.Instance.StartWCFServer();
            WCFClient.Instance.pipeName = Cache.Instance.EveSettings.WCFPipeName;

            foreach (DataGridViewColumn col in dataGridEveAccounts.Columns)
            {
                int index = col.Index;
                string name = col.Name;
                ToolStripMenuItem menuItem = new ToolStripMenuItem();
                menuItem.Checked = true;
                col.Frozen = false;
                col.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                col.Resizable = DataGridViewTriState.True;

                if (Cache.Instance.EveSettings.DatagridViewHiddenColumns.Contains(index))
                {
                    menuItem.Checked = false;
                    dataGridEveAccounts.Columns[index].Visible = false;
                }

                if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.All(i => !i.SelectedController.Contains("QuestorController") && !i.SelectedController.Contains("CareerAgentController")))
                {
                    if (col.Name == "Agent") col.Visible = false;
                    if (col.Name == "AgentLevel") col.Visible = false;
                    if (col.Name == "AgentCorp") col.Visible = false;
                    if (col.Name == "IskPerLp") col.Visible = false;
                    if (col.Name == "InMission") col.Visible = false;
                    if (col.Name == "LoyaltyPoints") col.Visible = false;
                    if (col.Name == "LpValue") col.Visible = false;
                    if (col.Name == "LastBuyLpItemAttempt") col.Visible = false;
                    if (col.Name == "LastMissionName") col.Visible = false;
                    if (col.Name == "MissionStarted") col.Visible = false;
                    if (col.Name == "LastBuyLpItems") col.Visible = false;
                }

                if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.All(i => !i.SelectedController.Contains("AbyssalDeadspaceController")))
                {
                    if (col.Name == "InAbyssalDeadspace") col.Visible = false;
                    if (col.Name == "AbyssalPocketNumber") col.Visible = false;
                    if (col.Name == "NumOfAbyssalSitesBeforeRestarting") col.Visible = false;
                }

                if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.All(i => !i.SelectedController.Contains("AbyssalDeadspaceController") && !i.SelectedController.Contains("QuestorController")))
                {
                    if (col.Name == "CMBCtrlAction") col.Visible = false;
                    if (col.Name == "FleetName") col.Visible = false;
                }

                if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.All(i => !i.SelectedController.Contains("HydraController") && !i.SelectedController.Contains("CombatDontMoveController")))
                {
                    if (col.Name == "IsLeader") col.Visible = false;
                    if (col.Name == "FleetName") col.Visible = false;
                }

                if (Cache.Instance.EveAccountSerializeableSortableBindingList.List.All(i => !i.SelectedController.Contains("HydraController")))
                {
                    if (col.Name == "BotUsesHydra") col.Visible = false;
                }

                menuItem.Click += (o, args) =>
                {
                    ToolStripMenuItem ts = (ToolStripMenuItem) o;
                    ts.Checked = !ts.Checked;
                    dataGridEveAccounts.Columns[index].Visible = ts.Checked;

                    if (ts.Checked)
                    {
                        if (Cache.Instance.EveSettings.DatagridViewHiddenColumns.Any(k => k == index))
                            Cache.Instance.EveSettings.DatagridViewHiddenColumns.Remove(index);
                    }
                    else
                    {
                        if (!Cache.Instance.EveSettings.DatagridViewHiddenColumns.Any(k => k == index))
                            Cache.Instance.EveSettings.DatagridViewHiddenColumns.Add(index);
                    }
                };

                menuItem.Text = name;

                if (menuItem.Text == "WalletBalance" ||
                    menuItem.Text == "LpValue" ||
                    menuItem.Text == "TotalValue" ||
                    menuItem.Text == "ItemHangarValue")
                    col.DefaultCellStyle.Format = "c0";

                if (menuItem.Text == "LoyaltyPoints")
                    col.DefaultCellStyle.Format = "n0";

                /**
                if (menuItem.Text == "StartTime" ||
                    menuItem.Text == "EndTime" ||
                    menuItem.Text == "LastAmmoBuy" ||
                    menuItem.Text == "MissionStarted" ||
                    menuItem.Text == "LastInWarp" ||
                    menuItem.Text == "LastSessionChange")
                {
                    col.DefaultCellStyle.Format = "MM/dd HH:mm";
                }
                **/
                columnsToolStripMenuItem.DropDownItems.Add(menuItem);
            }

            //dataGridEveAccounts.FastAutoSizeColumns();
            dataGridEveAccounts.AllowUserToResizeColumns = true;
            dataGridEveAccounts.AlternatingRowsDefaultCellStyle.BackColor = Color.LightGray;
            dataGridEveAccounts.Anchor = AnchorStyles.None;
            dataGridEveAccounts.Dock = DockStyle.Fill;
            dataGridEveAccounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridEveAccounts.ColumnHeadersHeight = 50;
            dataGridEveAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;
            dataGridEveAccounts.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.EnableResizing;
            dataGridEveAccounts.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            dataGridEveAccounts.ScrollBars = ScrollBars.Both;
            DrawingControl.ResumeDrawing(dataGridEveAccounts);

            //Type dgvType = dataGridEveAccounts.GetType();
            //PropertyInfo pi = dgvType.GetProperty("DoubleBuffered",
            //    BindingFlags.Instance | BindingFlags.NonPublic);
            //pi.SetValue(dataGridEveAccounts, true, null);

            foreach (DataGridViewColumn col in dataGridEveAccounts.Columns)
            {
                ToolStripMenuItem menuItem = new ToolStripMenuItem();
                menuItem.Text = col.Name;

                if (menuItem.Text == "CharacterName")
                {
                    col.DividerWidth = 2;
                    col.Frozen = true;
                }
            }


            //FormUtil.SetDoubleBuffered(dataGridEveAccounts);
            //SetDoubleBuffered(flowLayoutPanel1);

            CancellationTokenSource tokenSource = new CancellationTokenSource();
            Task.Run(() =>
            {
                while (!tokenSource.Token.IsCancellationRequested)
                {
                    tokenSource.Token.WaitHandle.WaitOne(5000);
                    try
                    {
                        dataGridEveAccounts.Invoke(new Action(() => { dataGridEveAccounts.FastAutoSizeColumns(); }));
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.ToString());
                    }
                }
            }, tokenSource.Token);

            EveManager.Instance.StartSettingsManager();
        }

        private void MainFormResize(object sender, EventArgs e)
        {
            try
            {
                Rectangle screenRectangle = RectangleToScreen(ClientRectangle);
                int titleHeight = screenRectangle.Top - Top;
                dataGridEveAccounts.Height = Height - logTab.Height - titleHeight - menuStrip1.Height;
                //groupBox2.Width = screenRectangle.Right - groupBox2.Left - screenRectangle.Left - 3;

                if (WindowState == FormWindowState.Minimized)
                {
                    Visible = false;
                    notifyIconQL.Visible = true;
                    Cache.Instance.IsMainFormMinimized = true;

                    if (Cache.Instance.EveSettings.ToggleHideShowOnMinimize)
                        foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List) //.Where(i => i.AllowHideEveWindow))
                            eA.HideWindows();
                }
            }
            catch (Exception ex)
            {
                Cache.Instance.Log(ex.ToString());
            }
        }

        private void mainTabCtrl_Selected(object sender, TabControlEventArgs e)
        {
            // pass to...
            thumbPreviewTab.Selected(sender, e);
        }

        private void notifyIconQL_Click(object sender, EventArgs e)
        {
            ((NotifyIcon) sender).Visible = !((NotifyIcon) sender).Visible;
            Visible = !Visible;
            Cache.Instance.IsMainFormMinimized = false;
            //WindowState = FormWindowState.Maximized;
            foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(eA => !eA.Hidden))
                eA.ShowWindows();
            WindowState = FormWindowState.Normal;
        }

        private void NotifyIconQLMouseDoubleClick(object sender, MouseEventArgs e)
        {
            ((NotifyIcon) sender).Visible = !((NotifyIcon) sender).Visible;
            Visible = !Visible;
            Cache.Instance.IsMainFormMinimized = false;

            WindowState = FormWindowState.Maximized;

            if (Cache.Instance.EveSettings.ToggleHideShowOnMinimize)
                foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List)
                    eA.ShowWindows();

            WindowState = FormWindowState.Normal;
        }

        private void openEveAccountCreatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new EveAccountCreatorForm().Show();
        }

        private void proxiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new ProxiesForm().Show();
        }

        private void SelectProcessToProxyToolStripMenuItemClick(object sender, EventArgs e)
        {
            DataGridView dgv = ActiveControl as DataGridView;
            if (dgv == null) return;
            int index = dgv.SelectedCells[0].OwningRow.Index;
            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];
            eA.StartExecuteable(string.Empty);
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SettingsForm form = new SettingsForm();
            form.ShowDialog();
        }

        private void showRealHardwareInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new RealHardwareInfoForm().Show();
        }

        private void ShowToolStripMenuItemClick(object sender, EventArgs e)
        {
            foreach (EveAccount eA in Cache.Instance.EveAccountSerializeableSortableBindingList.List.Where(a => a.IsProcessAlive()))
                eA.ShowWindows();
        }

        private void StartInjectToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (!(ActiveControl is DataGridView dgv))
            {
                Cache.Instance.Log("if (!(ActiveControl is DataGridView dgv))");
                return;
            }

            int index = dgv.SelectedCells[0].OwningRow.Index;
            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];

            if (eA.HWSettings.Proxy.IsValid)
            {
                bool checkSocks5Proxy = eA.HWSettings.Proxy.CheckSocks5InternetConnectivity();
                if (checkSocks5Proxy)
                {
                    Cache.Instance.Log("Checking Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckSocks5InternetConnectivity [ true ]");
                    bool checkHttpProxy = eA.HWSettings.Proxy.CheckHttpProxyInternetConnectivity();
                    if (checkHttpProxy)
                    {
                        Cache.Instance.Log("Checking Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckHttpProxyInternetConnectivity [ true ]");
                        eA.ManuallyStarted = true;
                        Thread threadStartEveInject = new Thread(eA.StartEveInject);
                        threadStartEveInject.SetApartmentState(ApartmentState.STA);
                        threadStartEveInject.Start();
                    }
                    else Cache.Instance.Log("Checking Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckHttpProxyInternetConnectivity [ false ]");
                }
                else Cache.Instance.Log("Checking Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "]: CheckHttpProxyInternetConnectivity [ false ]");
            }
            else Cache.Instance.Log("Checking Eve: Account [" + eA.AccountName + "] Character [" + eA.CharacterName + "] Failed: Proxy is not Valid!");
        }

        private void StatisticsToolStripMenuItemClick(object sender, EventArgs e)
        {
            new Thread(() =>
                {
                    try
                    {
                        new StatisticsForm().ShowDialog();
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex);
                    }
                }
            ).Start();
        }

        private void textBoxPastebin_TextChanged(object sender, EventArgs e)
        {
            Cache.Instance.EveSettings.Pastebin = textBoxPastebin.Text;
        }

        private void TextBoxPastebinTextChanged(object sender, EventArgs e)
        {
            Cache.Instance.EveSettings.Pastebin = textBoxPastebin.Text;
        }

        //private void textBoxPastebin_TextChanged(object sender, EventArgs e)
        //{
        //    Cache.Instance.EveSettings.Pastebin = textBoxPastebin.Text;
        //}

        private DateTime _nextRecalcStats = DateTime.MinValue;
        private DateTime _nextRecalcStats2 = DateTime.MinValue;

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                //ReOrderAccountsBasedOnNum();
                lblCurrentEVETime.Text = "EVE Time (GMT): [ " + DateTime.UtcNow.ToShortDateString() + " " + DateTime.UtcNow.ToLongTimeString() + " ]";
                //EveSetting.ClearEveSettingsStatistics();
                lblISK.Text = "Wallet (ISK): " + EveSetting.FormatIsk(EveSetting.StatisticsAllIsk);
                lblLP.Text = "LoyaltyPoints (LP): " + EveSetting.FormatIsk(EveSetting.StatisticsAllLp);
                lblLPISK.Text = "LoyaltyPoints (ISK): " + EveSetting.FormatIsk(EveSetting.StatisticsAllLpValue);
                lblHangarValue.Text = "Hangar value (ISK): " + EveSetting.FormatIsk(EveSetting.StatisticsAllItemHangar);
                lblTotalValue.Text = "Net Worth (ISK): " + EveSetting.FormatIsk(EveSetting.StatisticsNetWorth);
                EveSharpCompileTimelbl.Text = "EVESharpCore.exe Compile Time: [ " + Cache.Instance.EveSharpCoreCompileTime + " ]";
                EveSharpLauncherCompileTimelbl.Text = "EVESharpLauncher.exe Compile Time: [ " + Cache.Instance.EveSharpLauncherCompileTime + " ]";
                if (EveManager.eveManagerThread.IsAlive) lblEVESharpLauncherScheduler.Text = "EVESharpLauncher Scheduler: [ Running ]";
                else lblEVESharpLauncherScheduler.Text = "EVESharpLauncher Scheduler: [ Stopped ]";
                if (EveManager.eveSettingsManagerThread.IsAlive) lblEVESharpLauncherIPC.Text = "EVESharpLauncher IPC: [ Running ]";
                else lblEVESharpLauncherIPC.Text = "EVESharpLauncher IPC: [ Stopped ]";
                //lblActiveThreads.Text = "Active Threads: " + EveSetting.EveSharpLauncherThreads;

                if (_nextRecalcStats > DateTime.UtcNow)
                {
                    EveSetting.ClearEveSettingsStatistics();
                    Cache.Instance.ClearCache();
                    _nextRecalcStats = _nextRecalcStats.AddSeconds(10);
                }

                if (_nextRecalcStats2 > DateTime.UtcNow)
                {
                    EveSetting.ClearEveSettingsStatisticsEveryFewSec();
                    _nextRecalcStats2 = _nextRecalcStats2.AddSeconds(3);
                }

            }
            catch (Exception)
            {
            }
        }

        private void ToolStripMenuItem1Click(object sender, EventArgs e)
        {
            DataGridView dgv = ActiveControl as DataGridView;
            if (dgv == null) return;

            int index = dgv.SelectedCells[0].OwningRow.Index;
            EveAccount eA = Cache.Instance.EveAccountSerializeableSortableBindingList.List[index];

            if (eA.HWSettings != null && eA.HWSettings.Proxy != null)
                eA.HWSettings.Proxy.StartFireFoxInject();
        }

        private void UpdateEVESharpToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Cache.Instance.EveSettings.UrlToPullEveSharpCode))
                Util.RunInDirectory("Updater.exe", Cache.Instance.EveSettings.UrlToPullEveSharpCode, false);
            else
                Util.RunInDirectory("Updater.exe", false);

            Close();
            try
            {
                Application.Exit();
            }
            catch (Exception)
            {
            }
        }

        #endregion Methods
    }
}