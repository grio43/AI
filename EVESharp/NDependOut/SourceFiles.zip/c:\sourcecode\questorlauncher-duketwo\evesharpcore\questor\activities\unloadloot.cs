﻿using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.States;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Questor.Activities
{
    public static class UnloadLoot
    {
        #region Properties

        private static int CargoRetry { get; set; }
        private static int HangarRetry { get; set; }
        private static long CurrentLootValue { get; set; }
        private static DateTime LastUnloadLootAttempt { get; set; } = DateTime.MinValue;

        #endregion Properties

        #region Fields

        private static readonly int inventoryRetryLimit = 5;
        //private static DateTime LastUnloadAction { get; set; } = DateTime.MinValue;
        private static DateTime LastHighTierLootContainerAction { get; set; } = DateTime.MinValue;
        private static DateTime LastAmmoHangarAction { get; set; } = DateTime.MinValue;
        private static DateTime LastLootContainerAction { get; set; } = DateTime.MinValue;
        private static DateTime LastItemHangarAction { get; set; } = DateTime.MinValue;

        #endregion Fields

        #region Methods

        public static bool ChangeUnloadLootState(UnloadLootState state, bool wait = true)
        {
            try
            {
                if (State.CurrentUnloadLootState != state)
                {
                    ClearDataBetweenStates();
                    Log.WriteLine("New UnloadLootState [" + state + "]");
                    State.CurrentUnloadLootState = state;
                }

                if (wait)
                {
                    return true;
                }

                ProcessState();
                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        public static long CurrentLootValueInCurrentShipInventory()
        {
            return LootValueOfItems(LootItemsInCurrentShipInventory());
        }

        public static long CurrentLootValueInItemHangar()
        {
            return LootValueOfItems(LootItemsInLootHangar());
        }

        public static bool IsLootItem(DirectItem i)
        {
            // need to add recently added items, like new scripts etc
            return DirectModule.DefinedAmmoTypes.All(a => a.TypeId != i.TypeId)
                   && MissionSettings.ModulesInAllInGameFittings.All(x => x.TypeId != i.TypeId)
                   && Settings.Instance.CapacitorInjectorScript != i.TypeId
                   && i.Volume != 0
                   && i.TypeId != (int)CategoryID.Skill
                   && i.TypeId != (int)TypeID.AngelDiamondTag
                   && i.TypeId != (int)TypeID.GuristasDiamondTag
                   && i.TypeId != (int)TypeID.ImperialNavyGatePermit
                   && i.GroupId != (int)Group.AccelerationGateKeys
                   && i.GroupId != (int)Group.Livestock
                   && i.GroupId != (int)Group.MiscSpecialMissionItems
                   && i.GroupId != (int)Group.Kernite
                   && i.GroupId != (int)Group.Omber
                   && i.GroupId != (int)Group.Commodities
                   //&& i.TypeId != (int)TypeID.MetalScraps
                   //&& i.TypeId != (int)TypeID.ReinforcedMetalScraps
                   && i.TypeId != (int)TypeID.AncillaryShieldBoosterScript
                   && i.TypeId != (int)TypeID.CapacitorInjectorScript
                   && i.TypeId != (int)TypeID.FocusedWarpDisruptionScript
                   && i.TypeId != (int)TypeID.OptimalRangeDisruptionScript
                   && i.TypeId != (int)TypeID.OptimalRangeScript
                   && i.TypeId != (int)TypeID.ScanResolutionDampeningScript
                   && i.TypeId != (int)TypeID.ScanResolutionScript
                   && i.TypeId != (int)TypeID.TargetingRangeDampeningScript
                   && i.TypeId != (int)TypeID.TargetingRangeScript
                   && i.TypeId != (int)TypeID.TrackingSpeedDisruptionScript
                   && i.TypeId != (int)TypeID.TrackingSpeedScript
                   && i.GroupId != (int)Group.CapacitorGroupCharge
                   && i.CategoryId != (int)CategoryID.Ship
                   && i.CategoryId != (int)CategoryID.Asteroid
                   && !i.IsCommonMissionItem
                   || ESCache.Instance.UnloadLootTheseItemsAreLootById.ContainsKey(i.TypeId);
        }

        public static bool IsNotLootItem(DirectItem i)
        {
            return DirectModule.DefinedAmmoTypes.All(a => a.TypeId == i.TypeId)
                   || Settings.Instance.CapacitorInjectorScript == i.TypeId
                   && i.Volume != 0
                   || i.TypeId == (int) TypeID.AngelDiamondTag
                   || i.TypeId == (int) TypeID.GuristasDiamondTag
                   || i.TypeId == (int) TypeID.ImperialNavyGatePermit
                   || i.GroupId == (int) Group.AccelerationGateKeys
                   || i.GroupId == (int) Group.Livestock
                   || i.GroupId == (int) Group.MiscSpecialMissionItems
                   || i.GroupId == (int) Group.Kernite
                   || i.GroupId == (int) Group.Omber
                   || i.GroupId == (int) Group.Commodities
                   //|| i.TypeId == (int) TypeID.MetalScraps
                   //|| i.TypeId == (int) TypeID.ReinforcedMetalScraps
                   || i.TypeId == (int) TypeID.Marines
                   //|| i.TypeId == (int) TypeID.AncillaryShieldBoosterScript
                   //|| i.TypeId == (int) TypeID.CapacitorInjectorScript
                   //|| i.TypeId == (int) TypeID.FocusedWarpDisruptionScript
                   //|| i.TypeId == (int) TypeID.OptimalRangeDisruptionScript
                   //|| i.TypeId == (int) TypeID.OptimalRangeScript
                   //|| i.TypeId == (int) TypeID.ScanResolutionDampeningScript
                   //|| i.TypeId == (int) TypeID.ScanResolutionScript
                   //|| i.TypeId == (int) TypeID.TargetingRangeDampeningScript
                   //|| i.TypeId == (int) TypeID.TargetingRangeScript
                   //|| i.TypeId == (int) TypeID.TrackingSpeedDisruptionScript
                   //|| i.TypeId == (int) TypeID.TrackingSpeedScript
                   //|| i.GroupId == (int) Group.CapacitorGroupCharge
                   || i.CategoryId == (int)CategoryID.Asteroid
                   || i.IsCommonMissionItem;
        }

        public static List<DirectItem> LootItemsInCurrentShipInventory()
        {
            return ESCache.Instance.CurrentShipsCargo.Items.Where(IsLootItem).ToList();
        }

        public static List<DirectItem> LootItemsInLootHangar()
        {
            return ESCache.Instance.LootHangar.Items.Where(IsLootItem).ToList();
        }

        public static long LootValueOfItems(List<DirectItem> items)
        {
            long lootValue = 0;
            foreach (DirectItem item in items)
                lootValue += (long)item.AveragePrice() * Math.Max(item.Quantity, 1);
            return lootValue;
        }

        public static bool MoveHighTierLoot(DirectContainer fromContainer, UnloadLootState nextState)
        {
            if (DateTime.UtcNow < LastHighTierLootContainerAction.AddMilliseconds(2000))
                return false;

            if (fromContainer == null)
            {
                CargoRetry++;
                Log.WriteLine("MoveHighTierLoot: if (FromContainer == null)");
                if (CargoRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            //
            // todo: this can and should be configurable to be a different hangar
            //
            if (ESCache.Instance.LootHangar == null)
            {
                HangarRetry++;
                Log.WriteLine("if (ESCache.Instance.LootHangar == null)");
                if (HangarRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (!fromContainer.Items.Any())
            {
                ChangeUnloadLootState(nextState, false);
                return true;
            }

            List<DirectItem> highTierLootToMove = null; //FromContainer.Items.Where(i => i.Metalevel >= 6).ToList();

            if (highTierLootToMove != null && highTierLootToMove.Any())
                try
                {
                    CurrentLootValue = LootValueOfItems(highTierLootToMove);
                    if (ESCache.Instance.LootContainer != null)
                    {
                        Log.WriteLine("Moving HighTier [" + highTierLootToMove.Count + "][" + highTierLootToMove.Sum(i => i.GetAveragePrice * Math.Min(i.Quantity, 1)) + " isk] items from CargoHold to HighTierLootContainer");
                        if (!ESCache.Instance.HighTierLootContainer.Add(highTierLootToMove)) return false;
                        LastHighTierLootContainerAction = DateTime.UtcNow;
                        return false;
                    }
                    //else if (QCache.Instance.LootCorpHangar != null)
                    //{
                    //    Log.WriteLine("Moving HighTier [" + highTierLootToMove.Count + "] items from CargoHold to HighTierLoothangar");
                    //    QCache.Instance.HighTierLootCorpHangar.Add(highTierLootToMove);
                    //    LootIsBeingMoved = true;
                    //    _lastUnloadAction = DateTime.UtcNow;
                    //    return false;
                    //}
                    Log.WriteLine("Moving HighTier [" + highTierLootToMove.Count + "][" + highTierLootToMove.Sum(i => i.GetAveragePrice * Math.Min(i.Quantity, 1)) + " isk] items from CargoHold to ItemHangar");
                    if (!ESCache.Instance.HighTierLootContainer.Add(highTierLootToMove)) return false;
                    LastHighTierLootContainerAction = DateTime.UtcNow;
                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    ChangeUnloadLootState(nextState, true);
                    return false;
                }
            ChangeUnloadLootState(nextState, false);

            return false;
        }

        public static void ProcessState()
        {
            if (!EveryUnloadLootPulse()) return;

            switch (State.CurrentUnloadLootState)
            {
                case UnloadLootState.Idle:
                    break;

                case UnloadLootState.Done:
                    break;

                case UnloadLootState.Begin:
                    if (LastUnloadLootAttempt.AddMinutes(1) > DateTime.UtcNow)
                        ChangeUnloadLootState(UnloadLootState.Done, false);

                    //if (State.CurrentStorylineState == StorylineState.GotoAgent)
                    //{
                    //    ....
                    //}

                    LastUnloadLootAttempt = DateTime.UtcNow;
                    ChangeUnloadLootState(UnloadLootState.StackItemHangar, false);
                    CurrentLootValue = 0;
                    break;

                case UnloadLootState.StackItemHangar:
                    if (!StackHangar(ESCache.Instance.ItemHangar, UnloadLootState.StackLootHangar)) return;
                    break;

                case UnloadLootState.StackLootHangar:
                    if (Settings.Instance.UseCorpLootHangar)
                        if (!StackHangar(ESCache.Instance.LootHangar, UnloadLootState.StackAmmoHangar)) return;

                    ChangeUnloadLootState(UnloadLootState.StackAmmoHangar);
                    break;

                case UnloadLootState.StackAmmoHangar:
                    if (Settings.Instance.UseCorpAmmoHangar && Settings.Instance.AmmoCorpHangarDivisionNumber != Settings.Instance.LootCorpHangarDivisionNumber)
                        if (!StackHangar(ESCache.Instance.AmmoHangar, UnloadLootState.MoveAmmoItems)) return;

                    ChangeUnloadLootState(UnloadLootState.MoveAmmoItems);
                    break;

                case UnloadLootState.MoveAmmoItems:
                    if (ESCache.Instance.EveAccount.SelectedController == "AbyssalDeadspaceController")
                    {
                        if (!MoveAmmoItems(ESCache.Instance.CurrentShipsCargo, UnloadLootState.MoveLoot)) return;
                        break;
                    }

                    if (!MoveAmmoItems(ESCache.Instance.CurrentShipsCargo, UnloadLootState.MoveAmmoItemsFromFleetHangar)) return;
                    break;

                case UnloadLootState.MoveAmmoItemsFromFleetHangar:
                    if (!ESCache.Instance.ActiveShip.IsShipWithFleetHangar)
                    {
                        ChangeUnloadLootState(UnloadLootState.MoveMissionCompletionItems);
                        return;
                    }

                    if (!MoveAmmoItems(ESCache.Instance.CurrentShipsFleetHangar, UnloadLootState.MoveMissionCompletionItems)) return;
                    break;

                //case UnloadLootState.MoveMobileTractor:
                //    if (!MoveMobileTractor(ESCache.Instance.CurrentShipsCargo, UnloadLootState.MoveMissionCompletionItems)) return;
                //    break;

                case UnloadLootState.MoveMissionCompletionItems:
                    if (!MoveMissionCompletionItems(ESCache.Instance.CurrentShipsCargo, UnloadLootState.MoveHighTierLoot)) return;
                    break;

                //case UnloadLootState.MoveMissionCompletionItemsFromFleetHangar:
                //    if (!ESCache.Instance.ActiveShip.IsShipWithFleetHangar)
                //    {
                //        ChangeUnloadLootState(UnloadLootState.MoveHighTierLoot);
                //        return;
                //    }
                //
                //    if (!MoveMissionCompletionItems(ESCache.Instance.CurrentShipsFleetHangar, UnloadLootState.MoveHighTierLoot)) return;
                //    break;

                case UnloadLootState.MoveHighTierLoot:
                    if (!MoveHighTierLoot(ESCache.Instance.CurrentShipsCargo, UnloadLootState.MoveLoot)) return;
                    break;

                //case UnloadLootState.MoveHighTierLootFromFleetHangar:
                //    if (!ESCache.Instance.ActiveShip.IsShipWithFleetHangar)
                //    {
                //        ChangeUnloadLootState(UnloadLootState.MoveLoot);
                //        return;
                //    }
                //
                //    if (!MoveHighTierLoot(ESCache.Instance.CurrentShipsFleetHangar, UnloadLootState.MoveLoot)) return;
                //    break;

                case UnloadLootState.MoveLoot:
                    if (!MoveLoot(ESCache.Instance.CurrentShipsCargo, UnloadLootState.MoveRestOfCargo)) return;
                    break;

                case UnloadLootState.MoveRestOfCargo:
                    if (!MoveRestOfCargo(ESCache.Instance.CurrentShipsCargo, UnloadLootState.Done)) return;
                    break;

                //case UnloadLootState.MoveLootFromFleetHangar:
                //    if (!ESCache.Instance.ActiveShip.IsShipWithFleetHangar)
                //    {
                //        ChangeUnloadLootState(UnloadLootState.Done);
                //        return;
                //    }
                //
                //    if (!MoveLoot(ESCache.Instance.CurrentShipsFleetHangar, UnloadLootState.Done)) return;
                //    break;
            }
        }

        private static void ClearDataBetweenStates()
        {
            CargoRetry = 0;
            HangarRetry = 0;
        }

        private static bool EveryUnloadLootPulse()
        {
            try
            {
                if (!ESCache.Instance.InStation)
                    return false;

                if (ESCache.Instance.InSpace)
                    return false;

                return true;
            }
            catch (Exception exception)
            {
                Log.WriteLine("Exception [" + exception + "]");
                return false;
            }
        }

        private static bool MoveMobileTractor(DirectContainer fromContainer, UnloadLootState nextState)
        {
            if (DateTime.UtcNow < LastAmmoHangarAction.AddMilliseconds(2000))
                return false;

            if (fromContainer == null)
            {
                CargoRetry++;
                Log.WriteLine("if (FromContainer == null)");
                if (CargoRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (ESCache.Instance.AmmoHangar == null)
            {
                HangarRetry++;
                Log.WriteLine("if (ESCache.Instance.AmmoHangar == null)");
                if (HangarRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (!fromContainer.Items.Any())
            {
                ChangeUnloadLootState(nextState, false);
                return true;
            }

            List<DirectItem> mobileTractorToMove = null;
            mobileTractorToMove = fromContainer.Items.Where(i => i.GroupId == (int)Group.MobileTractor).ToList();

            if (mobileTractorToMove.Any() && ESCache.Instance.AmmoHangar != null)
            {
                Log.WriteLine("Moving mobileTractor [" + mobileTractorToMove.Count() + "] from CargoHold to AmmoHangar");
                if (!ESCache.Instance.AmmoHangar.Add(mobileTractorToMove)) return false;
                LastAmmoHangarAction = DateTime.UtcNow;
                return false;
            }
            ChangeUnloadLootState(nextState, false);

            return false;
        }

        private static bool MoveAmmoItems(DirectContainer fromContainer, UnloadLootState nextState)
        {
            if (DateTime.UtcNow < LastAmmoHangarAction.AddMilliseconds(1000))
                return false;

            if (!Settings.Instance.UseCorpAmmoHangar && !Settings.Instance.UseCorpAmmoHangar)
            {
                if (DateTime.UtcNow < LastItemHangarAction.AddMilliseconds(1000))
                    return false;
            }

            if (fromContainer == null)
            {
                CargoRetry++;
                Log.WriteLine("MoveAmmoItems: if (FromContainer == null)");
                if (CargoRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (ESCache.Instance.AmmoHangar == null)
            {
                HangarRetry++;
                Log.WriteLine("if (ESCache.Instance.AmmoHangar == null)");
                if (HangarRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (!fromContainer.Items.Any())
            {
                ChangeUnloadLootState(nextState, false);
                return true;
            }

            List<DirectItem> ammoItemsToMove = null;
            ammoItemsToMove = fromContainer.Items.Where(i => i.CategoryId == (int)CategoryID.Charge).ToList();

            if (ammoItemsToMove.Any())
            {
                CurrentLootValue = LootValueOfItems(ammoItemsToMove);
                Log.WriteLine("MoveAmmoItems: Moving DefinedAmmoTypes [" + ammoItemsToMove.Count() + "] items from CargoHold to ItemHangar");
                if (!ESCache.Instance.AmmoHangar.Add(ammoItemsToMove)) return false;
                LastAmmoHangarAction = DateTime.UtcNow;
                return false;
            }

            Log.WriteLine("MoveAmmoItems: Done moving Ammo");
            ChangeUnloadLootState(nextState, false);
            return false;
        }

        private static bool MoveLoot(DirectContainer fromContainer, UnloadLootState nextState)
        {
            if (DateTime.UtcNow < LastLootContainerAction.AddMilliseconds(1000))
                return false;

            if (!Settings.Instance.UseCorpAmmoHangar && !Settings.Instance.UseCorpAmmoHangar)
            {
                if (DateTime.UtcNow < LastAmmoHangarAction.AddMilliseconds(1000))
                    return false;
            }

            if (fromContainer == null)
            {
                CargoRetry++;
                Log.WriteLine("MoveLoot: if (FromContainer == null)");
                if (CargoRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (ESCache.Instance.LootHangar == null)
            {
                HangarRetry++;
                Log.WriteLine("if (ESCache.Instance.LootHangar == null)");
                if (HangarRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            //if (Settings.Instance.LootHangarCorpHangarDivisionNumber != null && Settings.Instance.LootHangarCorpHangarDivisionNumber != 0)
            //{
            //    if (QCache.Instance.LootCorpHangar == null)
            //    {
            //        Log.WriteLine("if (QCache.Instance.LootCorpHangar == null)");
            //        return false;
            //    }
            //}

            if (!string.IsNullOrEmpty(Settings.Instance.LootContainerName))
                if (ESCache.Instance.LootContainer == null)
                {
                    Log.WriteLine("if (QCache.Instance.LootContainer == null)");
                    return false;
                }

            if (fromContainer.Items.All(i => i.IsCommonMissionItem))
            {
                ChangeUnloadLootState(nextState, false);
                return true;
            }

            List<DirectItem> lootToMove = fromContainer.Items.Where(i => i.GroupId != (int)Group.MobileTractor && !i.IsCommonMissionItem).ToList();

            if (lootToMove.Any())
                try
                {
                    CurrentLootValue = LootValueOfItems(lootToMove);
                    if (ESCache.Instance.LootContainer != null)
                    {
                        Log.WriteLine("Moving [" + lootToMove.Count + "] items worth [" + CurrentLootValue + "] from CargoHold to LootContainer [" + Settings.Instance.LootContainerName + "]");
                        if (!ESCache.Instance.LootContainer.Add(lootToMove)) return false;
                        LastLootContainerAction = DateTime.UtcNow;
                        return false;
                    }

                    //if (QCache.Instance.LootCorpHangar != null)
                    //{
                    //    Log.WriteLine("Moving [" + lootToMove.Count + "] items worth [" + CurrentLootValue + "] from CargoHold to LootCorpHangar Division [" + Settings.Instance.LootHangarCorpHangarDivisionNumber + "]");
                    //    QCache.Instance.LootCorpHangar.Add(lootToMove);
                    //    LootIsBeingMoved = true;
                    //    _lastUnloadAction = DateTime.UtcNow;
                    //    return false;
                    //}

                    if (ESCache.Instance.LootHangar != null)
                    {
                        Log.WriteLine("Moving [" + lootToMove.Count + "] items worth [" + CurrentLootValue + "] from CargoHold to ItemHangar");
                        if (!ESCache.Instance.LootHangar.Add(lootToMove)) return false;
                        LastLootContainerAction = DateTime.UtcNow;
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    ChangeUnloadLootState(nextState, false);
                    return false;
                }
            else
                ChangeUnloadLootState(nextState, false);

            return false;
        }

        private static bool MoveRestOfCargo(DirectContainer fromContainer, UnloadLootState nextState)
        {
            if (DateTime.UtcNow < LastItemHangarAction.AddMilliseconds(2000))
                return false;

            if (fromContainer == null)
            {
                CargoRetry++;
                Log.WriteLine("MoveRestOfCargo: if (FromContainer == null)");
                if (CargoRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (ESCache.Instance.ItemHangar == null)
            {
                HangarRetry++;
                Log.WriteLine("if (ESCache.Instance.ItemHangar == null)");
                if (HangarRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            //if (Settings.Instance.LootHangarCorpHangarDivisionNumber != null && Settings.Instance.LootHangarCorpHangarDivisionNumber != 0)
            //{
            //    if (QCache.Instance.LootCorpHangar == null)
            //    {
            //        Log.WriteLine("if (QCache.Instance.LootCorpHangar == null)");
            //        return false;
            //    }
            //}

            if (!fromContainer.Items.Any())
            {
                ChangeUnloadLootState(nextState, false);
                return true;
            }

            List<DirectItem> itemsToMove = fromContainer.Items.ToList();

            if (itemsToMove.Any())
                try
                {
                    CurrentLootValue = LootValueOfItems(itemsToMove);
                    if (ESCache.Instance.ItemHangar != null)
                    {
                        Log.WriteLine("Moving [" + itemsToMove.Count + "] items worth [" + CurrentLootValue + "] from CargoHold to ItemHangar");
                        if (!ESCache.Instance.ItemHangar.Add(itemsToMove)) return false;
                        LastItemHangarAction = DateTime.UtcNow;
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    ChangeUnloadLootState(nextState, false);
                    return false;
                }
            else
                ChangeUnloadLootState(nextState, false);

            return false;
        }

        private static bool MoveMissionCompletionItems(DirectContainer fromContainer, UnloadLootState nextState)
        {
            if (DateTime.UtcNow < LastItemHangarAction.AddMilliseconds(2000))
                return false;

            if (fromContainer == null)
            {
                CargoRetry++;
                Log.WriteLine("MoveMissionCompletionItems: if (FromContainer == null)");
                if (CargoRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (ESCache.Instance.ItemHangar == null)
            {
                HangarRetry++;
                Log.WriteLine("if (ESCache.Instance.AmmoHangar == null)");
                if (HangarRetry > inventoryRetryLimit) ChangeUnloadLootState(nextState);
                return false;
            }

            if (!fromContainer.Items.Any() ||
                ESCache.Instance.EveAccount.SelectedController == "AbyssalDeadspaceController" ||
                ESCache.Instance.EveAccount.SelectedController == "FleetAbyssalDeadspaceController" ||
                ESCache.Instance.EveAccount.SelectedController == "HydraController")
            {
                ChangeUnloadLootState(nextState, false);
                return true;
            }

            List<DirectItem> missionCompletionItemsToMove = null;
            if (ESCache.Instance.ListofMissionCompletionItemsToLoot != null && ESCache.Instance.ListofMissionCompletionItemsToLoot.Any())
                missionCompletionItemsToMove = fromContainer.Items.Where(i => i.IsCommonMissionItem).ToList();

            if (missionCompletionItemsToMove != null && missionCompletionItemsToMove.Any() && ESCache.Instance.AmmoHangar != null)
            {
                CurrentLootValue = LootValueOfItems(missionCompletionItemsToMove);
                Log.WriteLine("Moving MissionCompletionItems [" + missionCompletionItemsToMove.Count() + "] items from CargoHold to ItemHangar");
                if (!ESCache.Instance.ItemHangar.Add(missionCompletionItemsToMove)) return false;
                LastItemHangarAction = DateTime.UtcNow;
                return false;
            }

            ChangeUnloadLootState(nextState, false);

            return false;
        }

        private static bool StackHangar(DirectContainer hangarToStack, UnloadLootState nextState)
        {
            try
            {
                if (DateTime.UtcNow < LastAmmoHangarAction.AddMilliseconds(ESCache.Instance.RandomNumber(2000, 3000)))
                    return false;

                if (DateTime.UtcNow < LastLootContainerAction.AddMilliseconds(ESCache.Instance.RandomNumber(2000, 3000)))
                    return false;

                try
                {
                    if (!ESCache.Instance.StackHangar(hangarToStack)) return false;
                    ChangeUnloadLootState(nextState, false);
                    return true;
                }
                catch (NullReferenceException)
                {
                }
                return false;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }

            return false;
        }

        #endregion Methods
    }
}