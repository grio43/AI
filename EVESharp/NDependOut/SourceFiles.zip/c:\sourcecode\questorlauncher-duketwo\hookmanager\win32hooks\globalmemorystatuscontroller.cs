﻿/*
 * ---------------------------------------
 * User: duketwo
 * Date: 21.06.2014
 * Time: 16:48
 *
 * ---------------------------------------
 */

using EasyHook;
using System;
using System.Drawing;
using System.Runtime.InteropServices;

namespace HookManager.Win32Hooks
{
    /// <summary>
    ///     Description of GlobalMemoryStatusController.
    /// </summary>
    public class GlobalMemoryStatusController : IDisposable, IHook
    {
        #region Constructors

        public GlobalMemoryStatusController(IntPtr address, ulong totalPhys)
        {
            _totalPhys = totalPhys;
            Name = typeof(GlobalMemoryStatusController).Name;

            try
            {
                _name = string.Format("MemoryHook{0:X}", address.ToInt32());
                _hook = LocalHook.Create(address, new GlobalMemoryStatusDelegate(GlobalMemoryStatusDetour), this);
                _hook.ThreadACL.SetExclusiveACL(new int[] { });
            }
            catch (Exception)
            {
                Error = true;
            }
        }

        #endregion Constructors

        #region Delegates

        [UnmanagedFunctionPointer(CallingConvention.StdCall)]
        private delegate bool GlobalMemoryStatusDelegate(IntPtr memStruct);

        #endregion Delegates

        #region Classes

        [StructLayout(LayoutKind.Sequential)]
        public class MEMORYSTATUSEX
        {
            public uint dwLength;
            public uint dwMemoryLoad;
            public ulong ullAvailExtendedVirtual;
            public ulong ullAvailPageFile;
            public ulong ullAvailPhys;
            public ulong ullAvailVirtual;
            public ulong ullTotalPageFile;
            public ulong ullTotalPhys;
            public ulong ullTotalVirtual;

            public MEMORYSTATUSEX()
            {
                dwLength = (uint) Marshal.SizeOf(typeof(MEMORYSTATUSEX));
            }
        }

        #endregion Classes

        #region Fields

        private readonly ulong _totalPhys;
        private LocalHook _hook;

        private string _name;
        private MEMORYSTATUSEX _struct;

        #endregion Fields

        #region Properties

        public bool Error { get; set; }

        public string Name { get; set; }

        #endregion Properties

        #region Methods

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GlobalMemoryStatusEx(IntPtr memStruct);

        [DllImport("Kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern bool GlobalMemoryStatusEx(MEMORYSTATUSEX lpBuffer);

        public void Dispose()
        {
            if (_hook == null)
                return;

            _hook.Dispose();
            _hook = null;
        }

        private bool GlobalMemoryStatusDetour(IntPtr memStruct)
        {
            if (_struct == null)
            {
                bool result = GlobalMemoryStatusEx(memStruct);
                _struct = (MEMORYSTATUSEX) Marshal.PtrToStructure(memStruct, typeof(MEMORYSTATUSEX));
                ulong before = _struct.ullTotalPhys / 1024 / 1024;
                _struct.ullTotalPhys = _totalPhys * 1024 * 1024;
                ulong after = _struct.ullTotalPhys / 1024 / 1024;
                HookManagerImpl.Log("[BEFORE] " + before + " [AFTER] " + after, Color.Orange);
            }

            Marshal.StructureToPtr(_struct, memStruct, true);
            return true;
        }

        #endregion Methods
    }
}