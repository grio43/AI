﻿extern alias SC;

using System;
using System.Collections.Generic;
using System.Linq;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.BackgroundTasks;
using EVESharpCore.Questor.Behaviors;
using EVESharpCore.States;
using SC::SharedComponents.IPC;

namespace EVESharpCore.Questor.Combat
{
    public static partial class Combat
    {
        #region Fields

        public static HashSet<long> ListLeaderTargets;

        #endregion Fields

        #region Methods

        public static DateTime DebugInfoLogged = DateTime.UtcNow;

        public static void BuildListLeaderTargets()
        {
            ListLeaderTargets = new HashSet<long>();
            if (ESCache.Instance.EveAccount.LeaderIsTargetingId1 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId1 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId1, "LeaderIsTargetingId1");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId1 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId1 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId1);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId2 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId2 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId2, "LeaderIsTargetingId2");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId2 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId2 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId2);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId3 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId3 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId3, "LeaderIsTargetingId3");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId3 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId3 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId3);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId4 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId4 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId4, "LeaderIsTargetingId4");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId4 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId4 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId4);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId5 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId5 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId5, "LeaderIsTargetingId5");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId5 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId5 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId5);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId6 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId6 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId6, "LeaderIsTargetingId6");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId6 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId6 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId6);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId7 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId7 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId7, "LeaderIsTargetingId7");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId7 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId7 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId7);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId8 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId8 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId8, "LeaderIsTargetingId8");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId8 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId8 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId8);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId9 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId9 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId9, "LeaderIsTargetingId9");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId9 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId9 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId9);
            }

            if (ESCache.Instance.EveAccount.LeaderIsTargetingId10 != null && ESCache.Instance.EveAccount.LeaderIsTargetingId10 > 0)
            {
                CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId10, "LeaderIsTargetingId10");
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("BuildListLeaderTargets: LeaderIsTargetingId10 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId10 + "]");
                ListLeaderTargets.Add((long)ESCache.Instance.EveAccount.LeaderIsTargetingId10);
            }
        }

        public static void CheckForEntityWithEntityId(long? leaderIsTargetingIdNumber, string targetNum)
        {
            if (leaderIsTargetingIdNumber == null)
                return;

            if (leaderIsTargetingIdNumber == 0)
                return;

            foreach (EntityCache entity in ESCache.Instance.EntitiesOnGrid)
                if (entity.Id == leaderIsTargetingIdNumber)
                    return;

            long emptyValue = 0;
            if (DebugConfig.DebugTargetCombatants) Log.WriteLine("Hydra: CheckForEntityWithEntityID [" + leaderIsTargetingIdNumber + "] Not found. Removing [ LeaderIsTargetingId" + targetNum + " ]");
            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, "LeaderIsTargetingId" + targetNum, emptyValue);
            if (DebugConfig.DebugTargetCombatants) Log.WriteLine("Hydra: CheckForEntityWithEntityID [" + leaderIsTargetingIdNumber + "] Not found.. Checking LeaderIsTargetingId1 is [" + ESCache.Instance.EveAccount.LeaderIsTargetingId1 + "]");
        }

        public static void DetermineMaxTargetsICanLock()
        {
            if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
            {
                int? totalTargetingSlotsWeNeed = maxHighValueTargets + maxLowValueTargets + Salvage.GlobalMaximumWreckTargets;
                if (totalTargetingSlotsWeNeed != null && ESCache.Instance.ActiveShip.MaxLockedTargets > totalTargetingSlotsWeNeed)
                    switch (ESCache.Instance.ActiveShip.MaxLockedTargets)
                    {
                        case 1:
                        case 2:
                        case 3:
                            maxHighValueTargets = 1;
                            maxLowValueTargets = 1;
                            Salvage.GlobalMaximumWreckTargets = 1;
                            break;

                        case 4:
                            maxHighValueTargets = 2;
                            maxLowValueTargets = 1;
                            Salvage.GlobalMaximumWreckTargets = 1;
                            break;

                        case 5:
                            maxHighValueTargets = 2;
                            maxLowValueTargets = 2;
                            Salvage.GlobalMaximumWreckTargets = 1;
                            break;

                        case 6:
                            maxHighValueTargets = 3;
                            maxLowValueTargets = 2;
                            Salvage.GlobalMaximumWreckTargets = 1;
                            break;

                        case 7:
                            maxHighValueTargets = 3;
                            maxLowValueTargets = 3;
                            Salvage.GlobalMaximumWreckTargets = 1;
                            break;

                        case 8:
                            maxHighValueTargets = 3;
                            maxLowValueTargets = 3;
                            Salvage.GlobalMaximumWreckTargets = 2;
                            break;

                        case 9:
                            maxHighValueTargets = 4;
                            maxLowValueTargets = 3;
                            Salvage.GlobalMaximumWreckTargets = 2;
                            break;

                        case 10:
                            maxHighValueTargets = 4;
                            maxLowValueTargets = 4;
                            Salvage.GlobalMaximumWreckTargets = 2;
                            break;

                        case 11:
                            maxHighValueTargets = 5;
                            maxLowValueTargets = 4;
                            Salvage.GlobalMaximumWreckTargets = 2;
                            break;

                        case 12:
                            maxHighValueTargets = 5;
                            maxLowValueTargets = 5;
                            Salvage.GlobalMaximumWreckTargets = 2;
                            break;
                    }
            }
        }

        public static bool PushTargetInfo()
        {
            int targetNum = 0;
            foreach (EntityCache target in ESCache.Instance.EntitiesOnGrid.Where(i => !i.IsLargeCollidable && !i.IsOreOrIce && !i.IsStation && (i.IsTarget || i.IsTargeting)))
            {
                targetNum++;
                if (targetNum > 10) break;
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("LeaderIsTargetingId" + targetNum + " [" + target.Name + "][" + target.Id + "][" + Math.Round(target.Distance / 1000, 0) + "k]");
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, "LeaderIsTargetingId" + targetNum, target.Id);
            }

            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId1, "1");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId2, "2");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId3, "3");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId4, "4");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId5, "5");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId6, "6");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId7, "7");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId8, "8");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId9, "9");
            CheckForEntityWithEntityId(ESCache.Instance.EveAccount.LeaderIsTargetingId10, "10");
            return false;
        }

        private static bool EcmJammingChecks()
        {
            if (ESCache.Instance.MaxLockedTargets == 0)
            {
                if (!_isJammed)
                    Log.WriteLine("We are jammed and can not target anything");

                _isJammed = true;
                if (ESCache.Instance.Weapons != null && ESCache.Instance.Weapons.Any())
                {
                    if (ESCache.Instance.Weapons.Any(i => 10 > i.ChargeQty && !i.IsReloadingAmmo))
                        ReloadAll();
                }

                return true;
            }

            if (_isJammed)
            {
                ESCache.Instance.TargetingIDs.Clear();
                Log.WriteLine("We are no longer jammed, reTargeting");
            }

            _isJammed = false;
            return true;
        }

        private static void DebugLogTargetInfo()
        {
            if (DebugConfig.DebugCombatMissionsBehavior && DateTime.UtcNow > DebugInfoLogged.AddSeconds(300))
            {
                int potentialCombatTargetNumber = 0;
                foreach (EntityCache potentialCombatTarget in PotentialCombatTargets)
                {
                    Log.WriteLine("[" + potentialCombatTargetNumber + "][" + potentialCombatTarget.Name + "][" + Math.Round(potentialCombatTarget.Distance / 1000, 0) + "k]");
                    potentialCombatTargetNumber++;
                    //int attributeNum = 0;
                    //Dictionary<string, object> potenaialCombatTargetAttributes = ESCache.Instance.DirectEve.GetInvType(potentialCombatTarget.TypeId).GetAttributesInvType();
                    //foreach (KeyValuePair<string, object> potentialCombatTargetAttribute in potenaialCombatTargetAttributes)
                    //{
                    //    attributeNum++;
                    //    Log.WriteLine(attributeNum + ";" + potentialCombatTarget.Name + ";" + potentialCombatTargetAttribute.Key + ";" + potentialCombatTargetAttribute.Value + ";" + potentialCombatTargetAttribute.Value.GetType());
                    //}

                    Log.WriteLine("[" + potentialCombatTarget.Name + ";EntityAttackRange;" + potentialCombatTarget._directEntity.EntityAttackRange);

                    Log.WriteLine("[" + potentialCombatTarget.Name + ";EmRawTurretDamage;" + potentialCombatTarget._directEntity.NpcEmRawTurretDamage);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";ExplosiveRawTurretDamage;" + potentialCombatTarget._directEntity.ExplosiveRawTurretDamage);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";KineticTurretDamage;" + potentialCombatTarget._directEntity.NpcKineticTurretDamage);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";ThermalRawTurretDamage;" + potentialCombatTarget._directEntity.NpcThermalRawTurretDamage);

                    Log.WriteLine("[" + potentialCombatTarget.Name + ";EmRawTurretDps;" + potentialCombatTarget._directEntity.NpcEmRawTurretDps);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcExplosiveRawTurretDps;" + potentialCombatTarget._directEntity.NpcExplosiveRawTurretDps);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcKineticRawTurretDps;" + potentialCombatTarget._directEntity.NpcKineticRawTurretDps);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcThermalRawTurretDps;" + potentialCombatTarget._directEntity.NpcThermalRawTurretDps);

                    Log.WriteLine("[" + potentialCombatTarget.Name + ";EmRawMissileDamage;" + potentialCombatTarget._directEntity.NpcEmRawMissileDamage);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcExplosiveRawMissileDamage;" + potentialCombatTarget._directEntity.NpcExplosiveRawMissileDamage);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";KineticRawMissileDamage;" + potentialCombatTarget._directEntity.NpcKineticRawMissileDamage);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";ThermalRawMissileDamage;" + potentialCombatTarget._directEntity.NpcThermalRawMissileDamage);

                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcEmRawMissileDps;" + potentialCombatTarget._directEntity.NpcEmRawMissileDps);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcExplosiveRawMissileDps;" + potentialCombatTarget._directEntity.NpcExplosiveRawMissileDps);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcKineticRawMissileDps;" + potentialCombatTarget._directEntity.NpcKineticRawMissileDps);
                    Log.WriteLine("[" + potentialCombatTarget.Name + ";NpcThermalRawMissileDps);" + potentialCombatTarget._directEntity.NpcThermalRawMissileDps);

                    Log.WriteLine("-------------------------");
                    if (potentialCombatTargetNumber >= 20) break;
                }

                DebugInfoLogged = DateTime.UtcNow;
            }
        }

        public static int PotentialCombatTargetsCount_AtLastLockedTarget = 0;

        public static int CurrentPotentialCombatTargetsCount => PotentialCombatTargets.Count();

        private static bool UnlockTargetsThatAreOutOfRange()
        {
            //Remove any target that is out of range(lower of Weapon Range or targeting range, definitely matters if damped)
            if (ESCache.Instance.InWormHoleSpace && ESCache.Instance.Targets.Any() && ESCache.Instance.Targets.Count() > 4 && Time.Instance.NextUnlockTargetOutOfRange < DateTime.UtcNow)
            {
                if (DebugConfig.DebugTargetCombatants)
                    Log.WriteLine("DebugTargetCombatants: if (ESCache.Instance.InWormHoleSpace && ESCache.Instance.Targets.Any() && ESCache.Instance.Targets.Count() > 4 && Time.Instance.NextUnlockTargetOutOfRange < DateTime.UtcNow)");

                Time.Instance.NextUnlockTargetOutOfRange = DateTime.UtcNow.AddSeconds(Time.Instance.Rnd.Next(5, 8));
                if (CurrentPotentialCombatTargetsCount > PotentialCombatTargetsCount_AtLastLockedTarget)
                {
                    if (DebugConfig.DebugTargetCombatants)
                        Log.WriteLine("DebugTargetCombatants: if (CurrentPotentialCombatTargetsCount > PotentialCombatTargetsCount_AtLastLockedTarget)");
                    foreach (EntityCache target in ESCache.Instance.Targets.Where(target => target.IsTarget && !target.IsBattleship && !target.IsNPCBattleship && !target.IsNpcCapitalEscalation))
                    {
                        target.UnlockTarget();
                    }
                }
            }

            if (ESCache.Instance.Targets.Any() && ESCache.Instance.Targets.Count() > 1 && Time.Instance.NextUnlockTargetOutOfRange < DateTime.UtcNow)
            {
                Time.Instance.NextUnlockTargetOutOfRange = DateTime.UtcNow.AddSeconds(Time.Instance.Rnd.Next(5, 8));
                if (!UnlockLowValueTarget("[lowValue]OutOfRange or Ignored", true)) return false;
                if (!UnlockHighValueTarget("Combat.TargetCombatants", "[highValue]OutOfRange or Ignored", true)) return false;
            }

            return true;
        }

        public static bool TargetCombatants()
        {
            try
            {
                if (!CombatIsAppropriateHere())
                {
                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetCombatants: if (!CombatIsAppropriateHere())");
                    return false;
                }

                DetermineMaxTargetsICanLock();

                if (State.CurrentHydraState == HydraState.Combat)
                {
                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetCombatants: if (State.CurrentHydraState == HydraState.Combat)");
                    if (TargetSpecificEntities()) return true;
                    return false;
                }

                if (State.CurrentHydraState == HydraState.Leader)
                {
                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetCombatants: if (State.CurrentHydraState == HydraState.Leader)");
                    if (PushTargetInfo()) return true;
                    return false;
                }

                if (ESCache.Instance.EveAccount.BotUsesHydra)
                {
                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetCombatants: if (QCache.Instance.EveAccount.BotUsesHydra)");
                    PushTargetInfo();
                }

                DebugLogTargetInfo();

                if (!EcmJammingChecks()) return false;
                if (!UnlockTargetsThatAreOutOfRange()) return false;

                if (ESCache.Instance.InAbyssalDeadspace)
                {
                    if (Time.Instance.LastJumpAction.AddSeconds(15) > DateTime.UtcNow)
                        return false;

                    if (AbyssalDeadspaceBehavior.TriglavianConstructionSiteSpawnFoundDozenPlusBSs)
                    {
                        if (DebugConfig.DebugTargetCombatants)
                            Log.WriteLine("DebugTargetCombatants: Targeting_AbyssalConstructionYard();");
                        Targeting_AbyssalConstructionYard();
                        return true;
                    }

                    if (ESCache.Instance.MyShipEntity.IsFrigate)
                    {
                        if (DebugConfig.DebugTargetCombatants)
                            Log.WriteLine("DebugTargetCombatants: Targeting_FrigateAbyssal();");
                        Targeting_FrigateAbyssal();
                        return true;
                    }

                    if (DebugConfig.DebugTargetCombatants)
                        Log.WriteLine("DebugTargetCombatants: Targeting_Abyssal();");
                    Targeting_Abyssal();
                    return true;
                }

                if (ESCache.Instance.InWormHoleSpace)
                {
                    if (ESCache.Instance.MyShipEntity.GroupId == (int)Group.Dreadnaught)
                    {
                        //
                        // determine if guns are high angle guns or not (how?)
                        //
                        if (ESCache.Instance.Weapons.Any() && ESCache.Instance.Weapons.Any(weapon => weapon.IsHighAngleWeapon))
                        {
                            if (DebugConfig.DebugTargetCombatants)
                                Log.WriteLine("DebugTargetCombatants: Targeting_WormHoleAnomaly_Dread_HAW();");
                            Targeting_WormHoleAnomaly_Dread_HAW();
                            return true;
                        }

                        if (DebugConfig.DebugTargetCombatants)
                            Log.WriteLine("DebugTargetCombatants: Targeting_WormHoleAnomaly_Dread();");
                        Targeting_WormHoleAnomaly_Dread();
                        return true;
                    }

                    if (DebugConfig.DebugTargetCombatants)
                        Log.WriteLine("DebugTargetCombatants: Targeting_WormHoleAnomaly();");
                    Targeting_WormHoleAnomaly();
                    return true;
                }

                if (ESCache.Instance.EveAccount.SelectedController == "CombatDontMoveController") //ESCache.Instance.DirectEve.Me.IsInvasionActive
                {
                    if (ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Nestor)
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetCombatants: if (ESCache.Instance.ActiveShip.TypeId == (int)TypeID.Nestor)");
                        Targeting_TriglavianNestor();
                        return true;
                    }

                    if (ESCache.Instance.ActiveShip.GroupId == (int)Group.Logistics)
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetCombatants: if (ESCache.Instance.ActiveShip.GroupId == (int)Group.Logistics)");
                        Targeting_TriglavianLogistics();
                        return true;
                    }

                    if (!ESCache.Instance.Stations.All(i => i.IsOnGridWithMe) && !ESCache.Instance.Stargates.All(i => i.IsOnGridWithMe) && PotentialCombatTargets.Any() && !ESCache.Instance.Weapons.Any() && (ESCache.Instance.ActiveShip.GroupId == (int)Group.CommandShip || ESCache.Instance.ActiveShip.GroupId == (int)Group.Battlecruiser))
                    {
                        if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetCombatants: if (!ESCache.Instance.Stations.All(i => i.IsOnGridWithMe) && !ESCache.Instance.Stargates.All(i => i.IsOnGridWithMe) && PotentialCombatTargets.Any() && !ESCache.Instance.Weapons.Any() && (ESCache.Instance.ActiveShip.GroupId == (int)Group.CommandShip || ESCache.Instance.ActiveShip.GroupId == (int)Group.Battlecruiser))");
                        Targeting_TriglavianAntiLooter();
                        return true;
                    }

                    if (ESCache.Instance.AccelerationGates.Any(i => i.Name.Contains("Observatory")) || ESCache.Instance.Entities.Any(i => i.Name.Contains("Triglavian Stellar Accelerator")) || ESCache.Instance.Entities.Any(i => i.Name.Contains("Stellar Observatory")))
                    {
                        Targeting_TriglavianInvasionObservatory();
                        return true;
                    }

                    if (DebugConfig.DebugTargetCombatants)
                        Log.WriteLine("DebugTargetCombatants: Targeting_TriglavianInvasion();");
                    Targeting_TriglavianInvasion();
                    return true;
                }

                if (MissionSettings.SelectedControllerUsesCombatMissionsBehavior)
                {
                    if (ESCache.Instance.InMission)
                    {
                        if (MissionSettings.MyMission != null && MissionSettings.MyMission.Name.Contains("Anomic"))
                        {
                            Targeting_BurnerMissions();
                            return true;
                        }
                    }
                }

                if (DebugConfig.DebugTargetCombatants)
                    Log.WriteLine("DebugTargetCombatants: Targeting_Defaults();");
                if (!Targeting_Defaults()) return false;

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return false;
            }
        }

        public static void Targeting_WormHoleAnomaly_Dread_HAW()
        {
            IOrderedEnumerable<EntityCache> potentialCombatTargetsToLock = PotentialCombatTargets.Where(e => e.IsReadyToTarget)
                .OrderByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.Name.Contains("Arithmos Tyrannos"))
                .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange && j.HealthPct < 100)
                .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable)
                .ThenByDescending(j => j.IsNPCBattleship && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.IsInOptimalRange)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCCruiser && j.IsTrackable)
                .ThenByDescending(j => j.IsNPCCruiser && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCCruiser)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.IsInOptimalRange)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsTrackable)
                .ThenByDescending(j => j.IsNPCFrigate && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCFrigate)
                .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                .ThenByDescending(j => j.IsTrackable && j.IsInOptimalRange)
                .ThenByDescending(j => j.IsTrackable && j.HealthPct < 100)
                .ThenByDescending(j => j.IsTrackable)
                .ThenByDescending(j => j.HealthPct < 100)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);

            TargetTheseEntities(potentialCombatTargetsToLock, "Targeting_WormHoleAnomaly_Dread_HAW");
        }

        public static void Targeting_WormHoleAnomaly_Dread()
        {
            IOrderedEnumerable<EntityCache> potentialCombatTargetsToLock = PotentialCombatTargets.Where(e => e.IsReadyToTarget && (e.IsNpcCapitalEscalation || e.IsNPCBattleship || e.Name.Contains("Arithmos Tyrannos")))
                .OrderByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.IsInOptimalRange && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.IsTrackable && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && j.HealthPct < 100 && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsNpcCapitalEscalation && ESCache.Instance.Modules.All(module => !module.IsHighAngleWeapon))
                .ThenByDescending(j => j.IsDecloakedTransmissionRelay)
                .ThenByDescending(j => j.Name.Contains("Arithmos Tyrannos"))
                .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange && j.HealthPct < 100)
                .ThenByDescending(j => j.IsSentry && j.IsInOptimalRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100 && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.IsInWebRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.IsInOptimalRange)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTrackable)
                .ThenByDescending(j => j.IsNPCBattleship && j.HealthPct < 100)
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);

            TargetTheseEntities(potentialCombatTargetsToLock, "Targeting_WormHoleAnomaly_Dread");
        }

        public static void Targeting_BurnerMissions()
        {
            IOrderedEnumerable<EntityCache> potentialCombatTargetsToLock = PotentialCombatTargets.Where(e => !e.IsTarget && !e.IsTargeting && (e.IsBurnerMainNPC || e.IsKillTarget || e.IsDroneKillTarget || e.isPreferredPrimaryWeaponTarget || e.isPreferredDroneTarget))
                .OrderByDescending(j => j.isPreferredPrimaryWeaponTarget)
                .ThenByDescending(j => j.isPreferredDroneTarget)
                .ThenByDescending(j => j.IsBurnerMainNPC)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);

            TargetTheseEntities(potentialCombatTargetsToLock, "Targeting_BurnerMissions");
        }

        public static void Targeting_WormHoleAnomaly()
        {
            IOrderedEnumerable<EntityCache> potentialCombatTargetsToLock = PotentialCombatTargets.Where(e => e.IsReadyToTarget)
                .OrderByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCBattlecruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600)
                .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.TriglavianDamage != null && j.TriglavianDamage > 800)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasRemoteRepair)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsSensorDampeningMe)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsWebbingMe)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasNeutralizers)
                .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(k => k.IsNPCBattlecruiser)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCFrigate && Drones.DronesKillHighValueTargets && j.IsNeutralizingMe && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);

            TargetTheseEntities(potentialCombatTargetsToLock, "Targeting_WormHoleAnomaly");
        }

        private static IOrderedEnumerable<EntityCache> Targeting_AbyssalTargetsToLock { get; set; } = null;
        private static IOrderedEnumerable<EntityCache> Targeting_TriglavianInvasionTargetsToLock { get; set; } = null;
        private static IOrderedEnumerable<EntityCache> Targeting_TriglavianInvasionNestorTargetsToLock { get; set; } = null;
        private static IOrderedEnumerable<EntityCache> Targeting_TriglavianInvasionLogisticsTargetsToLock { get; set; } = null;
        private static IOrderedEnumerable<EntityCache> Targeting_TriglavianInvasionAntiLooterTargetsToLock { get; set; } = null;

        public static void Targeting_TriglavianInvasionObservatory()
        {
            if (Targeting_TriglavianInvasionTargetsToLock == null)
            {
                Targeting_TriglavianInvasionTargetsToLock = PotentialCombatTargets.Where(e => e.IsReadyToTarget && e.WeCanKillThisNPCAndStillHaveEnoughDpsOnFieldToKillLooters)
                .OrderByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(l => l.IsNPCBattlecruiser && !l.IsAttacking)
                .ThenByDescending(k => k.IsNPCBattlecruiser)
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule) && !j.IsAttacking)
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && !j.IsAttacking)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCCruiser && j.WeShouldFocusFire)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsWithinOptimalOfDrones)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsCloseToDrones)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && k.IsAbyssalDeadspaceTriglavianBioAdaptiveCacheReadyToTarget)
                //.ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode && k.IsAbyssalDeadspaceTriglavianExtractionNodeReadyToTarget)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWithinOptimalOfDrones)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsCloseToDrones)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps)
                .ThenByDescending(i => i.IsNPCFrigate && i.IsTrackable)
                .ThenByDescending(i => i.IsNPCFrigate && i.IsInOptimalRange)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);
            }

            TargetTheseEntities(Targeting_TriglavianInvasionTargetsToLock, "Targeting_TriglavianInvasionObservatory");
        }

        public static void Targeting_TriglavianInvasion()
        {
            if (Targeting_TriglavianInvasionTargetsToLock == null)
            {
                Targeting_TriglavianInvasionTargetsToLock = PotentialCombatTargets.Where(e => e.IsReadyToTarget)
                    .OrderByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(l => l.IsNPCBattlecruiser && !l.IsAttacking)
                    .ThenByDescending(k => k.IsNPCBattlecruiser)
                    .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule) && !j.IsAttacking)
                    .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && !j.IsAttacking)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                    .ThenByDescending(j => j.IsNPCCruiser && j.WeShouldFocusFire)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsWithinOptimalOfDrones)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsCloseToDrones)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(j => j.IsNPCBattleship)
                    .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(l => l.IsNPCCruiser)
                    .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                    .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                    .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                    .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && k.IsAbyssalDeadspaceTriglavianBioAdaptiveCacheReadyToTarget)
                    //.ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode && k.IsAbyssalDeadspaceTriglavianExtractionNodeReadyToTarget)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsWithinOptimalOfDrones)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsCloseToDrones)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                    .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps)
                    .ThenByDescending(i => i.IsNPCFrigate && i.IsTrackable)
                    .ThenByDescending(i => i.IsNPCFrigate && i.IsInOptimalRange)
                    .ThenBy(p => p.StructurePct)
                    .ThenBy(q => q.ArmorPct)
                    .ThenBy(r => r.ShieldPct);
            }

            TargetTheseEntities(Targeting_TriglavianInvasionTargetsToLock, "Targeting_TriglavianInvasion");
        }

        public static void Targeting_TriglavianNestor()
        {
            //if (!ESCache.Instance.DirectEve.Session.InFleet)
            //    return;

            if (Targeting_TriglavianInvasionNestorTargetsToLock == null)
            {
                Targeting_TriglavianInvasionNestorTargetsToLock = ESCache.Instance.MyCorpMatesAsEntities.Where(e => e.IsReadyToTarget &&
                                                                                                                    e.Id != ESCache.Instance.MyShipEntity.Id &&
                                                                                                                    (e.TypeId == (int)TypeID.Nestor || e.IsInMyRepairGroup))
                            .OrderByDescending(j => j.TypeId == (int)TypeID.Nestor)
                            .ThenByDescending(j => j.IsInMyRepairGroup)
                            .ThenByDescending(j => j.GroupId == (int)Group.Logistics)
                            .ThenByDescending(j => j.IsBattlecruiser)
                            .ThenByDescending(j => j.IsBattleship);

                if (DebugConfig.DebugTargetCombatants)
                {
                    Log.WriteLine("Targeting_TriglavianNestor: InFleet [" + ESCache.Instance.DirectEve.Session.InFleet + "])");
                    int intCorpMate = 0;
                    foreach (EntityCache MyCorpMateAsEntity in ESCache.Instance.MyCorpMatesAsEntities)
                    {
                        intCorpMate++;
                        Log.WriteLine("MyCorpMateAsEntity [" + intCorpMate + "][" + MyCorpMateAsEntity.Name + "][" + Math.Round(MyCorpMateAsEntity.Distance / 1000, 0) + "k]");
                    }

                    Log.WriteLine("Leader and Slave Info from launcher (all non-leader toons in the same fleet as this leader)");
                    Log.WriteLine("LeaderCharacterName  [" + ESCache.Instance.EveAccount.LeaderCharacterName + "][" + ESCache.Instance.EveAccount.RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName1  [" + ESCache.Instance.EveAccount.SlaveCharacterName1 + "][" + ESCache.Instance.EveAccount.SlaveCharacter1RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName2  [" + ESCache.Instance.EveAccount.SlaveCharacterName2 + "][" + ESCache.Instance.EveAccount.SlaveCharacter2RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName3  [" + ESCache.Instance.EveAccount.SlaveCharacterName3 + "][" + ESCache.Instance.EveAccount.SlaveCharacter3RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName4  [" + ESCache.Instance.EveAccount.SlaveCharacterName4 + "][" + ESCache.Instance.EveAccount.SlaveCharacter4RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName5  [" + ESCache.Instance.EveAccount.SlaveCharacterName5 + "][" + ESCache.Instance.EveAccount.SlaveCharacter5RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName6  [" + ESCache.Instance.EveAccount.SlaveCharacterName6 + "][" + ESCache.Instance.EveAccount.SlaveCharacter6RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName7  [" + ESCache.Instance.EveAccount.SlaveCharacterName7 + "][" + ESCache.Instance.EveAccount.SlaveCharacter7RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName8  [" + ESCache.Instance.EveAccount.SlaveCharacterName8 + "][" + ESCache.Instance.EveAccount.SlaveCharacter8RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName9  [" + ESCache.Instance.EveAccount.SlaveCharacterName9 + "][" + ESCache.Instance.EveAccount.SlaveCharacter9RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName10 [" + ESCache.Instance.EveAccount.SlaveCharacterName10 + "][" + ESCache.Instance.EveAccount.SlaveCharacter10RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName11 [" + ESCache.Instance.EveAccount.SlaveCharacterName11 + "][" + ESCache.Instance.EveAccount.SlaveCharacter11RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName12 [" + ESCache.Instance.EveAccount.SlaveCharacterName12 + "][" + ESCache.Instance.EveAccount.SlaveCharacter12RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName13 [" + ESCache.Instance.EveAccount.SlaveCharacterName13 + "][" + ESCache.Instance.EveAccount.SlaveCharacter13RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName14 [" + ESCache.Instance.EveAccount.SlaveCharacterName14 + "][" + ESCache.Instance.EveAccount.SlaveCharacter14RepairGroup + "]");
                    Log.WriteLine("SlaveCharacterName15 [" + ESCache.Instance.EveAccount.SlaveCharacterName15 + "][" + ESCache.Instance.EveAccount.SlaveCharacter15RepairGroup + "]");
                }

            }

            TargetTheseEntities(Targeting_TriglavianInvasionNestorTargetsToLock, "Targeting_TriglavianNestor");
        }

        public static void Targeting_TriglavianAntiLooter()
        {
            if (Targeting_TriglavianInvasionAntiLooterTargetsToLock == null)
            {
                Targeting_TriglavianInvasionAntiLooterTargetsToLock = ESCache.Instance.Entities.Where(e => e.IsReadyToTarget && e.IsPotentialNinjaLooter)
                            .OrderByDescending(j => j.IsFrigate)
                            .ThenByDescending(j => j.IsCruiser);
            }

            TargetTheseEntities(Targeting_TriglavianInvasionAntiLooterTargetsToLock, "Targeting_TriglavianAntiLooter");
        }

        public static void Targeting_TriglavianLogistics()
        {
            //if (!ESCache.Instance.DirectEve.Session.InFleet)
            //    return;

            if (Targeting_TriglavianInvasionLogisticsTargetsToLock == null)
            {
                Targeting_TriglavianInvasionLogisticsTargetsToLock = ESCache.Instance.MyCorpMatesAsEntities.Where(e => e.IsReadyToTarget)
                            .OrderByDescending(j => j.IsInMyRepairGroup)
                            .ThenByDescending(j => j.GroupId == (int)Group.Logistics)
                            .ThenByDescending(j => j.IsBattlecruiser)
                            .ThenByDescending(j => j.IsBattleship);
            }

            TargetTheseEntities(Targeting_TriglavianInvasionLogisticsTargetsToLock, "Targeting_TriglavianLogistics");
        }

        public static void Targeting_Abyssal()
        {
            if (Targeting_AbyssalTargetsToLock == null)
            {
                Targeting_AbyssalTargetsToLock = PotentialCombatTargets.Where(e => !e.IsTarget && !e.IsTargeting)
                    .OrderByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule) && !j.IsAttacking)
                    .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && !j.IsAttacking)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                    .ThenByDescending(j => j.IsNPCCruiser && j.WeShouldFocusFire)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsWithinOptimalOfDrones)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsCloseToDrones)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(j => j.IsNPCBattleship)
                    .ThenByDescending(l => l.IsNPCBattlecruiser && !l.IsAttacking)
                    .ThenByDescending(k => k.IsNPCBattlecruiser)
                    .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(l => l.IsNPCCruiser)
                    .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                    .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                    .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                    .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache && k.IsAbyssalDeadspaceTriglavianBioAdaptiveCacheReadyToTarget)
                    //.ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode && k.IsAbyssalDeadspaceTriglavianExtractionNodeReadyToTarget)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsWithinOptimalOfDrones)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsCloseToDrones)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                    .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps)
                    .ThenByDescending(i => i.IsNPCFrigate && i.IsTrackable)
                    .ThenByDescending(i => i.IsNPCFrigate && i.IsInOptimalRange)
                    .ThenBy(p => p.StructurePct)
                    .ThenBy(q => q.ArmorPct)
                    .ThenBy(r => r.ShieldPct);
            }

            TargetTheseEntities(Targeting_AbyssalTargetsToLock, "Targeting_Abyssal");
        }

        public static void Targeting_FrigateAbyssal()
        {
            IOrderedEnumerable<EntityCache> potentialCombatTargetsToLock = PotentialCombatTargets.Where(e => e.IsReadyToTarget)
                .OrderByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCFrigate && !l.IsAttacking)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCFrigate && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                .ThenByDescending(j => j.IsNPCFrigate && j.IsHighDps)
                .ThenByDescending(i => i.IsNPCFrigate && i.IsTrackable)
                .ThenByDescending(i => i.IsNPCFrigate && i.IsInOptimalRange)
                .ThenByDescending(j => j.IsNPCCruiser && j.WeShouldFocusFire)
                .ThenByDescending(l => l.IsNPCCruiser && !l.IsAttacking)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(l => l.IsNPCCruiser)
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule) && !j.IsAttacking)
                .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && !j.IsAttacking)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                //.ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsWithinOptimalOfDrones)
                .ThenByDescending(l => l.IsNPCCruiser && l.IsCloseToDrones)
                .ThenByDescending(l => l.IsNPCBattlecruiser && !l.IsAttacking)
                .ThenByDescending(k => k.IsNPCBattlecruiser)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                .ThenByDescending(l => l.IsNPCBattleship && l.IsWithinOptimalOfDrones)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsCloseToDrones)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasRemoteRepair)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                .ThenByDescending(l => l.IsNPCBattleship && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                .ThenByDescending(j => j.IsNPCBattleship)
                .ThenBy(p => p.StructurePct)
                .ThenBy(q => q.ArmorPct)
                .ThenBy(r => r.ShieldPct);

            TargetTheseEntities(potentialCombatTargetsToLock, "Targeting_FrigateAbyssal");
        }

        public static void Targeting_AbyssalConstructionYard()
        {
            try
            {
                IOrderedEnumerable<EntityCache> potentialCombatTargetsToLock = PotentialCombatTargets.Where(e => !e.IsTarget && !e.IsTargeting)
                    .OrderByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.NpcHasNeutralizers && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 0)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCCruiser && j.TriglavianDamage != null && j.TriglavianDamage > 400)
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600 && j.NpcHasRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattlecruiser && j.TriglavianDamage != null && j.TriglavianDamage > 600)
                    .ThenByDescending(l => l.IsNPCBattleship && l.StructurePct < 90)
                    .ThenByDescending(l => l.IsNPCBattleship && l.ArmorPct < 90)
                    .ThenByDescending(l => l.IsNPCBattleship && l.ShieldPct < 90)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasNeutralizers)
                    .ThenByDescending(j => j.IsNPCBattleship && j.NpcHasALotOfRemoteRepair)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsWebbingMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsSensorDampeningMe)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsHighDps)
                    .ThenByDescending(j => j.IsNPCBattleship && j.IsTargetPaintingMe)
                    .ThenByDescending(j => j.IsNPCBattleship)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasRemoteRepair)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsSensorDampeningMe)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsWebbingMe)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.NpcHasNeutralizers)
                    .ThenByDescending(k => k.IsNPCBattlecruiser && k.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCBattlecruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(k => k.IsNPCBattlecruiser)
                    .ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianBioAdaptiveCache)
                    //.ThenByDescending(k => k.IsAbyssalDeadspaceTriglavianExtractionNode)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasRemoteRepair)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsSensorDampeningMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsWebbingMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.NpcHasNeutralizers)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCCruiser && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                    .ThenByDescending(l => l.IsNPCCruiser)
                    .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                    .ThenByDescending(j => j.IsNPCFrigate && Drones.DronesKillHighValueTargets && j.IsNeutralizingMe && ESCache.Instance.Modules.Any(i => i.IsShieldRepairModule || i.IsArmorRepairModule))
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasRemoteRepair)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsSensorDampeningMe)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsWebbingMe)
                    .ThenByDescending(l => l.IsNPCFrigate && l.NpcHasNeutralizers)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTargetPaintingMe)
                    .ThenByDescending(l => l.IsNPCFrigate && l.IsTrackingDisruptingMe && DoWeCurrentlyHaveTurretsMounted())
                    .ThenBy(p => p.StructurePct)
                    .ThenBy(q => q.ArmorPct)
                    .ThenBy(r => r.ShieldPct);

                TargetTheseEntities(potentialCombatTargetsToLock, "Targeting_AbyssalConstructionYard");
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
            }
        }

        public static bool Targeting_Defaults()
        {
            if (TargetingSlotsAreAvailable)
            {
                if (PotentialCombatTargets.Any(i => i.IsTargetedBy))
                {
                    if (TargetingSlotsAreAvailableForLowValueTargets && PickWhatToLockNextBasedOnTargetsForLowValueTargets.Any())
                    {
                        LockOptimalTargets(PickWhatToLockNextBasedOnTargetsForLowValueTargets, true, maxLowValueTargets ?? 2, "Targeting (Small)");
                    }

                    if (TargetingSlotsAreAvailableForHighValueTargets && PickWhatToLockNextBasedOnTargetsForBattleship.Any())
                    {
                        LockOptimalTargets(PickWhatToLockNextBasedOnTargetsForBattleship, true, maxHighValueTargets ?? 3, "Targeting (Large)");
                    }
                }
                else if (PotentialCombatTargets.All(i => !i.IsTarget && !i.IsTargeting))
                {
                    if (Time.Instance.LastInWarp.AddSeconds(15) > DateTime.UtcNow)
                        return true;

                    LockOptimalTargets(PotentialCombatTargets.Where(i => !i.IsTarget && !i.IsTargeting).OrderBy(j => j.Distance), true, maxLowValueTargets ?? 2, "Targeting (Lock closest target)");
                }
            }

            return true;
        }

        public static void TargetTheseEntities(IOrderedEnumerable<EntityCache> Targeting_TargetsToLock, string TargetingRoutineDescription)
        {
            if (DebugConfig.DebugTargetCombatants)
            {
                if (Targeting_TargetsToLock != null && Targeting_TargetsToLock.Any())
                {
                    int targetnum = 0;
                    Log.WriteLine("DebugTargetCombatants: Lock Targets in this order:");
                    foreach (EntityCache potentialCombatTargetToLock in Targeting_TargetsToLock)
                    {
                        targetnum++;
                        Log.WriteLine("[" + targetnum + "][" + potentialCombatTargetToLock.Name + "][" + Math.Round(potentialCombatTargetToLock.Distance / 1000, 0) + "]");
                    }
                    Log.WriteLine("DebugTargetCombatants: End Of List");
                }
            }

            if (Targeting_TargetsToLock == null || !Targeting_TargetsToLock.Any())
                return;

            int TotalLockedTargets = 0;
            if (ESCache.Instance.TotalTargetsandTargeting != null && ESCache.Instance.TotalTargetsandTargeting.Any())
                TotalLockedTargets = ESCache.Instance.TotalTargetsandTargeting.Count();

            if (Targeting_TargetsToLock.Any() && TotalLockedTargets < ESCache.Instance.MaxLockedTargets)
            {
                if (DebugConfig.DebugTargetCombatants)
                    Log.WriteLine("DebugTargetCombatants: MyMaxTargetRange [" + MaxTargetRange + "] [" + Targeting_TargetsToLock.Count() +
                                  "] IsNotYetTargetingMeAndNotYetTargeted targets");

                foreach (EntityCache targetToLock in Targeting_TargetsToLock)
                {
                    if (targetToLock != null)
                    {
                        if (DebugConfig.DebugTargetCombatants)
                            Log.WriteLine("DebugTargetCombatants [" + targetToLock.Name + "][" + Math.Round(targetToLock.Distance / 1000, 0) + "k] IsReadyToTarget [" + targetToLock.IsReadyToTarget + "]");
                        if (targetToLock.IsReadyToTarget
                        && targetToLock.LockTarget(TargetingRoutineDescription))
                        {
                            Log.WriteLine("Targeting [" + targetToLock.Name + "][GroupID: " +
                                          targetToLock.GroupId +
                                          "][TypeID: " + targetToLock.TypeId + "][" + targetToLock.MaskedId + "][" +
                                          Math.Round(targetToLock.Distance / 1000, 0) + "k away]");
                            if (ESCache.Instance.TotalTargetsandTargeting.Any() &&
                                ESCache.Instance.TotalTargetsandTargeting.Count() >= ESCache.Instance.MaxLockedTargets)
                                Time.Instance.NextTargetAction = DateTime.UtcNow.AddSeconds(Time.Instance.TargetsAreFullDelay_seconds);

                            return;
                        }
                    }
                }
            }
            else
            {
                if (DebugConfig.DebugTargetCombatants)
                    Log.WriteLine("DebugTargetCombatants: 0 IsNotYetTargetingMeAndNotYetTargeted targets");
            }
        }

        private static IOrderedEnumerable<EntityCache> PickWhatToLockNextBasedOnTargetsForBattleship
        {
            get
            {
                if (_pickWhatToLockNextBasedOnTargetsForABattleship == null)
                {
                    _pickWhatToLockNextBasedOnTargetsForABattleship = PotentialCombatTargets.Where(i => !i.IsContainer && !i.IsBadIdea && !i.IsIgnored && i.IsReadyToTarget && (i.IsHighValueTarget || (i.IsLargeCollidable && (i.IsPrimaryWeaponKillPriority || i.IsDronePriorityTarget))))
                        .OrderByDescending(j => j.IsWarpScramblingMe)
                        //.ThenByDescending(j => !j.IsTrigger)
                        .ThenByDescending(i => i.IsLargeCollidableWeAlwaysWantToBlowupFirst)
                        .ThenByDescending(g => (g.IsFrigate || g.IsNPCFrigate) && g.IsTrackable && Defense.SpeedModAvailable && g.IsWebbingMe && 100 > g.HealthPct)
                        .ThenByDescending(g => (g.IsFrigate || g.IsNPCFrigate) && g.IsTrackable && Defense.SpeedModAvailable && g.IsWebbingMe)
                        .ThenByDescending(j => j.IsPrimaryWeaponPriorityTarget)
                        .ThenByDescending(i => i.IsTargetedBy)
                        .ThenByDescending(i => i.IsAttacking)
                        //.ThenByDescending(i => i.IsAttacking && i.IsPlayer && i.IsBattlecruiser)
                        //.ThenByDescending(i => i.IsAttacking && i.IsPlayer && i.IsBattleship)
                        //.ThenByDescending(i => i.IsAttacking && i.IsPlayer && i.IsCruiser)
                        .ThenByDescending(i => i.IsTrackable)
                        .ThenByDescending(i => i.IsInOptimalRange)
                        //.ThenByDescending(i => i.IsCorrectSizeForMyWeapons && i.IsWarpScramblingMe && !i.IsLargeCollidable)
                        //.ThenByDescending(i => i.IsCorrectSizeForMyWeapons)
                        //.ThenByDescending(i => i.IsEntityIShouldKeepShooting)
                        .ThenByDescending(i => i.IsNPCBattleship && 100 > i.HealthPct)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCBattleship && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattleship)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && 100 > i.HealthPct)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCBattlecruiser && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCBattlecruiser)
                        .ThenByDescending(i => i.IsNPCCruiser && 100 > i.HealthPct)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisWarpScramblingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisSensorDampeningNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTrackingDisruptingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.KillThisTargetPaintingNpc)
                        .ThenByDescending(i => i.IsNPCCruiser && i.IsAttacking)
                        .ThenByDescending(i => i.IsNPCCruiser)
                        //If the PotentialCombatTarget is repote repairing we should prioritize that target! but we do not
                        .ThenByDescending(i => i.KillThisNeutralizingNpc)
                        .ThenByDescending(i => i.IsLargeCollidableWeAlwaysWantToBlowupLast)
                        .ThenBy(i => i.StructurePct)
                        .ThenBy(i => i.ArmorPct)
                        .ThenBy(i => i.ShieldPct);

                    if (DebugConfig.DebugLogOrderOfKillTargets)
                        LogOrderOfKillTargets(_pickWhatToLockNextBasedOnTargetsForABattleship);

                    return _pickWhatToLockNextBasedOnTargetsForABattleship;
                }

                return _pickWhatToLockNextBasedOnTargetsForABattleship;
            }
        }

        private static IOrderedEnumerable<EntityCache> PickWhatToLockNextBasedOnTargetsForLowValueTargets
        {
            get
            {
                if (_pickWhatToLockNextBasedOnTargetsForLowValueTargets == null)
                {
                    _pickWhatToLockNextBasedOnTargetsForLowValueTargets = PotentialCombatTargets.Where(i => !i.IsContainer && !i.IsBadIdea && !i.IsIgnored && i.IsReadyToTarget && !i.IsHighValueTarget)
                        .OrderByDescending(a => a.IsWarpScramblingMe && 100 > a.HealthPct)
                        .ThenByDescending(b => b.IsWarpScramblingMe)
                        .ThenByDescending(b => b.WarpScrambleChance > 0 && 100 > b.HealthPct)
                        .ThenByDescending(b => b.WarpScrambleChance)
                        .ThenByDescending(c => c.isPreferredDroneTarget && 100 > c.HealthPct)
                        .ThenByDescending(c => c.isPreferredDroneTarget)
                        //.ThenByDescending(j => !j.IsTrigger)
                        .ThenByDescending(g => (g.IsFrigate || g.IsNPCFrigate) && 100 > g.HealthPct)
                        .ThenByDescending(g => (g.IsFrigate || g.IsNPCFrigate) && g.IsWebbingMe && 100 > g.HealthPct)
                        .ThenByDescending(g => (g.IsFrigate || g.IsNPCFrigate) && g.IsWebbingMe)
                        .ThenByDescending(e => e.IsTargetedBy)
                        .ThenByDescending(f => f.IsAttacking)
                        .ThenByDescending(g => g.IsFrigate || g.IsNPCFrigate)
                        .ThenByDescending(n => n.IsNeutralizingMe && ESCache.Instance.Modules.Any(module => module.IsShieldRepairModule || module.IsArmorRepairModule))
                        .ThenByDescending(o => o != Combat.killTarget && o.IsNPCFrigate && !o.IsWarpScramblingMe)
                        .ThenBy(p => p.HealthPct)
                        .ThenBy(s => s.Nearest5kDistance);

                    if (DebugConfig.DebugLogOrderOfKillTargets)
                        LogOrderOfKillTargets(_pickWhatToLockNextBasedOnTargetsForLowValueTargets);

                    return _pickWhatToLockNextBasedOnTargetsForLowValueTargets;
                }

                return _pickWhatToLockNextBasedOnTargetsForLowValueTargets;
            }
        }

        private static bool TargetingSlotsAreAvailable
        {
            get
            {
                try
                {
                    int totalLockedTargets = 0;
                    if (ESCache.Instance.TotalTargetsandTargeting != null && ESCache.Instance.TotalTargetsandTargeting.Any())
                        totalLockedTargets = ESCache.Instance.TotalTargetsandTargeting.Count();

                    if (ESCache.Instance.MaxLockedTargets > totalLockedTargets)
                        return true;

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        private static bool TargetingSlotsAreAvailableForLowValueTargets
        {
            get
            {
                try
                {
                    if (!TargetingSlotsAreAvailable)
                        return false;

                    int totalLockedLowValueTargets = 0;
                    if (ESCache.Instance.TotalTargetsandTargeting != null && ESCache.Instance.TotalTargetsandTargeting.Any())
                        totalLockedLowValueTargets = ESCache.Instance.TotalTargetsandTargeting.Count(i => i.IsLowValueTarget);

                    if (maxLowValueTargets > totalLockedLowValueTargets)
                        return true;

                    if (!PotentialCombatTargets.Any(i => i.IsHighValueTarget))
                    {
                        if (maxLowValueTargets + 1 > totalLockedLowValueTargets)
                            return true;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        private static bool TargetingSlotsAreAvailableForHighValueTargets
        {
            get
            {
                try
                {
                    if (!TargetingSlotsAreAvailable)
                        return false;

                    int totalLockedHighValueTargets = 0;
                    if (ESCache.Instance.TotalTargetsandTargeting != null && ESCache.Instance.TotalTargetsandTargeting.Any())
                        totalLockedHighValueTargets = ESCache.Instance.TotalTargetsandTargeting.Count(i => i.IsHighValueTarget);

                    if (maxLowValueTargets > totalLockedHighValueTargets)
                        return true;

                    //if (!PotentialCombatTargets.Any(i => i.IsLowValueTarget))
                    //{
                    //    if (maxHighValueTargets + 1 > totalLockedHighValueTargets)
                    //        return true;
                    //}

                    return false;
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                    return false;
                }
            }
        }

        private static bool DebugLogOrderTargetsWillBeTargeted(IOrderedEnumerable<EntityCache> potentialTargetsToLock)
        {
            try
            {
                if (DebugConfig.DebugTargetCombatants)
                {
                    int targetnum = 0;
                    Log.WriteLine("DebugTargetCombatants: Lock Targets in this order:");
                    foreach (EntityCache potentialTargetToLock in potentialTargetsToLock)
                    {
                        targetnum++;
                        Log.WriteLine("[" + targetnum + "][" + potentialTargetToLock.Name + "][" + Math.Round(potentialTargetToLock.Distance / 1000, 0) + "] Attacking [" + potentialTargetToLock.IsAttacking + "]");
                    }
                    Log.WriteLine("DebugTargetCombatants: End Of List");
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }
        }

        private static bool LockOptimalTargets(IOrderedEnumerable<EntityCache> potentialCombatTargetsToLock, bool doWeHaveEnoughOfTheCorrectTargetingSlotsAvailable, int maxCorrectlySizedTargetingSlots, string module)
        {
            try
            {
                if (potentialCombatTargetsToLock.Any())
                {
                    if (doWeHaveEnoughOfTheCorrectTargetingSlotsAvailable)
                    {
                        if (DebugConfig.DebugTargetCombatants)
                            Log.WriteLine("DebugTargetCombatants: [" + potentialCombatTargetsToLock.Count() +
                                          "] IsNotYetTargetingMeAndNotYetTargeted targets");

                        foreach (EntityCache potentialCombatTargetToLock in potentialCombatTargetsToLock.Take(maxCorrectlySizedTargetingSlots))
                            if (potentialCombatTargetToLock != null
                                && potentialCombatTargetToLock.Distance < MaxTargetRange
                                && potentialCombatTargetToLock.IsReadyToTarget
                                && potentialCombatTargetToLock.LockTarget(module))
                            {
                                Log.WriteLine("Targeting [" + potentialCombatTargetToLock.Name + "][GroupID: " +
                                              potentialCombatTargetToLock.GroupId +
                                              "][TypeID: " + potentialCombatTargetToLock.TypeId + "][" + potentialCombatTargetToLock.MaskedId + "][" +
                                              Math.Round(potentialCombatTargetToLock.Distance / 1000, 0) + "k away]");

                                if (ESCache.Instance.TotalTargetsandTargeting.Any() &&
                                    ESCache.Instance.TotalTargetsandTargeting.Count() >= ESCache.Instance.MaxLockedTargets)
                                {
                                    Time.Instance.NextTargetAction = DateTime.UtcNow.AddSeconds(Time.Instance.TargetsAreFullDelay_seconds);
                                }

                                return false;
                            }

                        return true;
                    }

                    return true;
                }

                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception [" + ex + "]");
                return true;
            }
        }

        public static bool TargetSpecificEntities()
        {
            if (DebugConfig.DebugTargetCombatants) Log.WriteLine("TargetSpecificEntities");
            BuildListLeaderTargets();

            if (ListLeaderTargets != null && ListLeaderTargets.Any())
            {
                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (ListLeaderTargets != null && ListLeaderTargets.Any())");
                foreach (EntityCache unlockTarget in ESCache.Instance.Targets.Where(i => ListLeaderTargets.All(a => a != i.Id)))
                {
                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("unlocktarget [" + unlockTarget.Name + "]");
                    if (unlockTarget.UnlockTarget())
                        return false;
                }

                if (ESCache.Instance.Targets.Count() >= ESCache.Instance.MaxLockedTargets)
                {
                    if (DebugConfig.DebugTargetCombatants) Log.WriteLine("if (QCache.Instance.Targets.Count() >= QCache.Instance.MaxLockedTargets)");
                    return false;
                }

                foreach (long entityId in ListLeaderTargets)
                    foreach (EntityCache lockTarget in ESCache.Instance.EntitiesOnGrid.Where(i => !i.IsTarget && !i.IsTargeting && i.Distance < ESCache.Instance.ActiveShip.MaxTargetRange))
                        if (lockTarget.Id == entityId)
                        {
                            if (lockTarget.LockTarget("Lock"))
                                Log.WriteLine("LeaderTargets: Locking [" + lockTarget + "] at [" + Math.Round(lockTarget.Distance / 1000, 0) + "k]");

                            return false;
                        }

                if (DebugConfig.DebugTargetCombatants) Log.WriteLine("no targets to lock.");
                return false;
            }

            if (ESCache.Instance.Targets != null && ESCache.Instance.Targets.Any())
                foreach (EntityCache target in ESCache.Instance.Targets)
                {
                    target.UnlockTarget();
                    return false;
                }

            if (DebugConfig.DebugTargetCombatants) Log.WriteLine("ListLeaderTargets is empty.");
            return false;
        }

        #endregion Methods
    }
}