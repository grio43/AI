﻿extern alias SC;

using SC::SharedComponents.Py;
using System.Collections.Generic;
using System.Linq;

namespace EVESharpCore.Framework
{
    public enum JournalTab
    {
        Unknown = -1,
        Missions = 0,
        Research = 1,
        LPs = 2
    }

    public class DirectJournalWindow : DirectWindow
    {
        #region Constructors

        internal DirectJournalWindow(DirectEve directEve, PyObject pyWindow)
            : base(directEve, pyWindow)
        {
        }

        #endregion Constructors

        #region Methods
        /**
        public void SwitchTab(JournalTab t)
        {
            DirectEve.Interval(3000);
            if (SelectedTab != JournalTab.Unknown && SelectedTab != t)
                DirectEve.ThreadedCall(PyWindow.Attribute("ShowAgentTab"), (int) t);
        }
        **/
        #endregion Methods

        #region Properties

        public JournalTab SelectedTab => (JournalTab)CurrentSelectedIndex;
        private int CurrentSelectedIndex => CurrentSelectedTab != null ? Tabs.IndexOf(CurrentSelectedTab) : -1;
        private PyObject CurrentSelectedTab => Tabs.FirstOrDefault(t => t.Attribute("_selected").ToBool());
        private List<PyObject> Tabs => PyWindow.Attribute("sr").Attribute("agenttabs").Attribute("sr").Attribute("tabs").ToList();

        #endregion Properties
    }
}