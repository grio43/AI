﻿extern alias SC;

using SC::SharedComponents.Py;
using System;

namespace EVESharpCore.Framework
{
    public class DirectBooster : DirectObject
    {
        #region Constructors

        internal DirectBooster(DirectEve directEve, PyObject py) : base(directEve)
        {
            PyObject = py;
            TypeID = PyObject.Attribute("boosterTypeID").ToInt();
            ExpireTime = PyObject.Attribute("expiryTime").ToDateTime();
            BoosterSlot = PyObject.Attribute("boosterSlot").ToFloat();
        }

        #endregion Constructors

        #region Properties

        public float BoosterSlot { get; }
        public DateTime ExpireTime { get; }
        public PyObject PyObject { get; }

        public int TypeID { get; }

        #endregion Properties
    }

    //<KeyVal: {'typeID': 3898, 'boosterSlot': 1.0, 'expiryTime': 131556791200131939L, 'boosterID': 1026065316343L, 'boosterTypeID': 3898, 'boosterDuration': 5040000.0, 'sideEffectIDs': []}>
}