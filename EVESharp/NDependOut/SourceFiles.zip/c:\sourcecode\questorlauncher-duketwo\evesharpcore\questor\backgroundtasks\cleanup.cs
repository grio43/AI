extern alias SC;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using EVESharpCore.Cache;
using EVESharpCore.Framework;
using EVESharpCore.Logging;
using EVESharpCore.Lookup;
using EVESharpCore.Questor.Combat;
using EVESharpCore.Questor.Stats;
using EVESharpCore.States;
using SC::SharedComponents.EVE;
using SC::SharedComponents.IPC;


namespace EVESharpCore.Questor.BackgroundTasks
{
    public static class Cleanup
    {
        #region Constructors

        static Cleanup()
        {

        }

        #endregion Constructors

        #region Fields

        public static bool doneUsingRepairWindow;
        public static bool LogEVEWindowDetails;
        private static int _droneBayClosingAttempts;
        private static DateTime NextCleanupControllerTimeStamp { get; set; }

        #endregion Fields

        #region Methods

        public static bool RepairItems()
        {
            try
            {
                if (DateTime.UtcNow < Time.Instance.NextRepairItemsAction)
                    return false;

                if (!ESCache.Instance.Windows.Any())
                    return false;

                if (ESCache.Instance.InStation)
                {
                    foreach (DirectWindow window in ESCache.Instance.Windows)
                        if (window.Name == "modal")
                            if (!string.IsNullOrEmpty(window.Html))
                            {
                                if (window.Html.Contains("Repairing these items will cost"))
                                {
                                    if (window.Html != null)
                                        Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                                    Log.WriteLine("Closing Quote for Repairing All with YES");
                                    window.AnswerModal("Yes");
                                    Time.Instance.NextRepairItemsAction = DateTime.UtcNow.AddSeconds(Settings.Instance.RandomNumber(1, 2));
                                    doneUsingRepairWindow = true;
                                    return false;
                                }

                                if (window.Html.Contains("How much would you like to repair?"))
                                {
                                    if (window.Html != null)
                                        Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                                    Log.WriteLine("Closing Quote for Repairing All with OK");
                                    window.AnswerModal("OK");
                                    Time.Instance.NextRepairItemsAction = DateTime.UtcNow.AddSeconds(Settings.Instance.RandomNumber(1, 2));
                                    doneUsingRepairWindow = true;
                                    return false;
                                }
                            }

                    if (!ESCache.Instance.EveAccount.NeedRepair) return true;

                    //if (ESCache.Instance.DirectEve.hasRepairFacility() == null)
                    //    return false;

                    /**
                    if (!(bool)ESCache.Instance.DirectEve.hasRepairFacility())
                    {
                        Log("This station does not have repair facilities to use! aborting attempt to use non-existent repair facility.");
                        if (MissionSettings.SelectedControllerUsesCombatMissionsBehavior && MissionSettings.AgentToPullNextRegularMissionFrom != null && ESCache.Instance.DirectEve.Session.LocationId != MissionSettings.AgentToPullNextRegularMissionFrom.StationId)
                        {
                            CombatMissionsBehavior.ChangeCombatMissionBehaviorState(CombatMissionsBehaviorState.GotoBase);
                            Panic.HeadedToRepairStation = true;
                            Log("CleanupController setting GotoBase");
                            return true;
                        }

                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), false);
                        return true;
                    }
                    **/

                    //if (MissionSettings.MissionSpecificMissionFitting != null && !string.IsNullOrEmpty(MissionSettings.MissionSpecificMissionFitting.Ship))
                    //    return true;

                    DirectRepairShopWindow repairWindow = ESCache.Instance.Windows.OfType<DirectRepairShopWindow>().FirstOrDefault();

                    DirectWindow repairQuote = ESCache.Instance.GetWindowByName("Set Quantity");

                    if (doneUsingRepairWindow)
                    {
                        doneUsingRepairWindow = false;
                        if (repairWindow != null) repairWindow.Close();
                        return true;
                    }

                    if (repairQuote != null && repairQuote.IsModal && repairQuote.IsKillable)
                    {
                        if (repairQuote.Html != null)
                            Log.WriteLine("Content of modal window (HTML): [" + repairQuote.Html.Replace("\n", "").Replace("\r", "") + "]");
                        Log.WriteLine("Closing Quote for Repairing All with OK");
                        repairQuote.AnswerModal("OK");
                        Time.Instance.NextRepairItemsAction = DateTime.UtcNow.AddSeconds(Settings.Instance.RandomNumber(1, 2));
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), false);
                        doneUsingRepairWindow = true;
                        return false;
                    }

                    if (repairWindow == null)
                    {
                        Log.WriteLine("Opening repairshop window");
                        ESCache.Instance.DirectEve.OpenRepairShop();
                        Statistics.LogWindowActionToWindowLog("RepairWindow", "Opening RepairWindow");
                        Time.Instance.NextRepairItemsAction = DateTime.UtcNow.AddSeconds(Settings.Instance.RandomNumber(1, 3));
                        return false;
                    }

                    if (ESCache.Instance.AmmoHangar == null)
                    {
                        Log.WriteLine("if (Cache.Instance.ItemHangar == null)");
                        return false;
                    }
                    if (ESCache.Instance.ShipHangar == null)
                    {
                        Log.WriteLine("if (Cache.Instance.ShipHangar == null)");
                        return false;
                    }

                    if (Drones.UseDrones && ESCache.Instance.ActiveShip != null && !ESCache.Instance.ActiveShip.IsShipWithNoDroneBay)
                        if (Drones.DroneBay == null)
                        {
                            Log.WriteLine("RepairItems: if (Drones.DroneBay == null)");
                            return false;
                        }

                    if (ESCache.Instance.ShipHangar.Items == null)
                    {
                        Log.WriteLine("Cache.Instance.ShipHangar.Items == null");
                        return false;
                    }

                    List<DirectItem> repairAllItems = ESCache.Instance.ShipHangar.Items;

                    repairAllItems.AddRange(ESCache.Instance.ItemHangar.Items);
                    if (Drones.UseDrones)
                        repairAllItems.AddRange(Drones.DroneBay.Items);

                    if (repairAllItems.Any())
                    {
                        if (string.IsNullOrEmpty(repairWindow.AvgDamage()))
                        {
                            Log.WriteLine("Add items to repair list");
                            repairWindow.RepairItems(repairAllItems);
                            return false;
                        }

                        Log.WriteLine("Repairing Items: repairWindow.AvgDamage: " + repairWindow.AvgDamage());
                        if (repairWindow.AvgDamage().Equals("Avg: 0.0 % Damaged") || repairWindow.AvgDamage().Equals("Avg: 0,0 % Damaged"))
                        {
                            Log.WriteLine("Repairing Items: Zero Damage: skipping repair.");
                            repairWindow.Close();
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), false);
                            Statistics.LogWindowActionToWindowLog("RepairWindow", "Closing RepairWindow");
                            return true;
                        }

                        if (!ESCache.Instance.EveAccount.OkToInteractWithEveNow)
                        {
                            if (DebugConfig.DebugInteractWithEve) Log.WriteLine("CleanupController: RepairItems: RepairAll: !OkToInteractWithEveNow");
                            return false;
                        }

                        repairWindow.RepairAll();
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), false);
                        WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.LastInteractedWithEVE), DateTime.UtcNow);
                        Time.Instance.NextRepairItemsAction = DateTime.UtcNow.AddSeconds(Settings.Instance.RandomNumber(2, 3));
                        return false;
                    }

                    Log.WriteLine("No items available, nothing to repair.");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), false);
                    return true;
                }

                Log.WriteLine("Not in station.");
                return true;
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception:" + ex);
                return false;
            }
        }

        public static void CheckOmegaClone()
        {
            if (ESCache.Instance.InStation && ESCache.Instance.EveAccount.RequireOmegaClone)
            {
                if (!ESCache.Instance.DirectEve.Me.IsOmegaClone.HasValue || (bool)ESCache.Instance.DirectEve.Me.IsOmegaClone)
                {

                }


                Log.WriteLine("RequireOmegaClone is true and IsOmegaClone is false! Pausing!");
                ControllerManager.Instance.SetPause(true);
            }

            if (ESCache.Instance.InStation && ESCache.Instance.DirectEve.Me.IsOmegaClone.HasValue && (bool)ESCache.Instance.DirectEve.Me.IsOmegaClone)
            {
                string TextToLog = "SubEnd: NotInitialized: SubTimeEnd [" + ESCache.Instance.DirectEve.Me.SubTimeEnd + "]";
                //
                // if saved value is in the past
                //
                if (ESCache.Instance.EveAccount.SubEnd > DateTime.UtcNow)
                    TextToLog = ESCache.Instance.EveAccount.SubEnd.ToString();
                else if (ESCache.Instance.DirectEve.Me.SubTimeEnd != ESCache.Instance.EveAccount.SubEnd)
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.SubEnd), ESCache.Instance.DirectEve.Me.SubTimeEnd);


                if (DateTime.UtcNow.AddDays(2) > ESCache.Instance.DirectEve.Me.SubTimeEnd)
                {
                    //
                    // if we havent checked in the last hour or so
                    //
                    if (DateTime.UtcNow > Time.Instance.LastSubscriptionTimeLeftCheckAttempt.AddMinutes(ESCache.Instance.RandomNumber(60, 120)))
                    {
                        if (ESCache.Instance.DirectEve.Me.SubTimeEnd != DateTime.MinValue)
                        {
                            Time.Instance.LastSubscriptionTimeLeftCheckAttempt = DateTime.UtcNow;
                            TextToLog = ESCache.Instance.DirectEve.Me.SubTimeEnd.ToString();
                            WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.SubEnd), ESCache.Instance.DirectEve.Me.SubTimeEnd);
                        }
                    }
                }

                if (DebugConfig.DebugSubscriptionEnd) Log.WriteLine("SubEnd: " + TextToLog);
            }
        }

        public static void CheckWindows()
        {
            if (DateTime.UtcNow < NextCleanupControllerTimeStamp)
                return;

            if (DebugConfig.DebugCleanup) Log.WriteLine("CheckWindows");

            //if (ESCache.Instance.DirectEve.Login.AtLogin || ESCache.Instance.DirectEve.Login.AtCharacterSelection)
            //    return;

            if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                return;

            NextCleanupControllerTimeStamp = DateTime.UtcNow.AddSeconds(3);

            if (Time.Instance.LastJumpAction.AddSeconds(5) > DateTime.UtcNow)
            {
                if (DebugConfig.DebugCleanup) Log.WriteLine("if (DateTime.UtcNow > Time.Instance.LastJumpAction.AddSeconds(5))");
                return;
            }

            if (Time.Instance.LastUndockAction.AddSeconds(5) > DateTime.UtcNow)
            {
                if (DebugConfig.DebugCleanup) Log.WriteLine("if (DateTime.UtcNow > Time.Instance.LastUndockAction.AddSeconds(5))");
                return;
            }

            if (Time.Instance.LastDockAction.AddSeconds(5) > DateTime.UtcNow)
            {
                if (DebugConfig.DebugCleanup) Log.WriteLine("if (DateTime.UtcNow > Time.Instance.LastDockAction.AddSeconds(5))");
                return;
            }

            if (ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                if (ESCache.Instance.Stargates.Any() && Time.Instance.LastInWarp.AddSeconds(30) > DateTime.UtcNow)
                    if (ESCache.Instance.ClosestStargate != null && ESCache.Instance.ClosestStargate.IsOnGridWithMe && ESCache.Instance.ClosestStargate.Distance < 10000)
                    {
                        if (DebugConfig.DebugCleanup) Log.WriteLine("CheckModalWindows: We are within 10k of a stargate, do nothing while we wait to jump.");
                        return;
                    }

            if (DebugConfig.DebugCleanup) Log.WriteLine("Checkmodal checking for windows next...");
            if (ESCache.Instance.Windows == null || !ESCache.Instance.Windows.Any())
            {
                if (DebugConfig.DebugCleanup)
                    Log.WriteLine("CheckModalWindows: Cache.Instance.Windows returned null or empty");
                State.CurrentCleanupState = CleanupState.Idle;
                return;
            }

            if (DebugConfig.DebugCleanup) Log.WriteLine("About to: foreach (DirectWindow regularWindow in ESCache.Instance.DirectEve.Windows)");
            foreach (DirectWindow regularWindow in ESCache.Instance.DirectEve.Windows)
            {
                if (DebugConfig.DebugCleanup)  Log.WriteLine("Window: Name [" + regularWindow.Name + "] Type [" + regularWindow.Type + "] IsKillable [" + regularWindow.IsKillable + "] isDialog [" + regularWindow.IsDialog + "] isModal [" + regularWindow.IsModal + "]");

                if (ESCache.Instance.EveAccount.ManuallyPausedViaUI) continue;

                if (ESCache.Instance.InSpace && regularWindow.Type == "form.AgentDialogueWindow")
                {
                    Log.WriteLine("Closing Window [" + regularWindow.Caption + "]");
                    regularWindow.Close();
                    continue;
                }

                if (ESCache.Instance.InSpace && regularWindow.Type == "form.FittingMgmt")
                {
                    Log.WriteLine("Closing Window [" + regularWindow.Caption + "]");
                    regularWindow.Close();
                    continue;
                }

                //new WindowType("__guid__", "form.FittingMgmt", (directEve, pyWindow) => new DirectFittingManagerWindow(directEve, pyWindow)),

                //if (ESCache.Instance.InSpace && regularWindow.Type == "form.Overview")
                //{
                //    bool minimized = regularWindow.PyWindow.Attribute("_minimized").ToBool();
                //    if (!minimized)
                //    {
                //        Log("Minimizing Overview Window [" + regularWindow.Caption + "]");
                //        regularWindow.Minimize();
                //    }
                //}

                //if (!LoginController.LoggedIn && !ESCache.Instance.DirectEve.Session.IsReady && ESCache.Instance.DirectEve.Login.AtCharacterSelection && ESCache.Instance.DirectEve.Login.IsCharacterSelectionReady && regularWindow.Type == "uicontrols.Window" && regularWindow.Name == "LoginRewardWindow")
                //
                //
                //
                if (regularWindow.Type == "uicontrols.Window" && regularWindow.Name == "LoginRewardWindow")
                {
                    //Log("Closing Window [" + regularWindow.Caption + "]");
                    //regularWindow.Close();
                }

                //
                // new feature notify window: new campaigns...
                //
                if (regularWindow.Type == "uicontrols.Window" && regularWindow.Name == "NewFeatureNotifyWnd")
                {
                    Log.WriteLine("Closing Window [" + regularWindow.Caption + "]");
                    regularWindow.Close(); //doesnt work!?
                    continue;
                }

                if (regularWindow.Name == "telecom" || regularWindow.Type.ToLower() == "form.Telecom".ToLower())
                {
                    Log.WriteLine("Closing telecom message...");
                    Log.WriteLine("Content of telecom window (HTML): [" + (regularWindow.Html ?? string.Empty).Replace("\n", "").Replace("\r", "") +
                        "]");
                    regularWindow.Close();
                    continue;
                }

                try
                {
                    /**
                    if (regularWindow.Name == "modal" && regularWindow.Html.Contains("wants you to join their fleet, do you accept"))
                    {
                        if (regularWindow.Html.Contains(ESCache.Instance.EveAccount.LeaderCharacterName) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName1) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName2) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName3) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName4) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName5) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName6) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName7) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName8) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName9) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName10) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName11) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName12) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName13) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName14) ||
                            regularWindow.Html.Contains(ESCache.Instance.EveAccount.SlaveCharacterName15))
                        {
                            Log.WriteLine("CleanupController: Found a fleet invite that we should accept");
                            Log.WriteLine("FleetInviteWindow.Name: [" + regularWindow.Name + "]");
                            Log.WriteLine("FleetInviteWindow.Html: [" + regularWindow.Html + "]");
                            Log.WriteLine("FleetInviteWindow.Type: [" + regularWindow.Type + "]");
                            Log.WriteLine("FleetInviteWindow.IsModal: [" + regularWindow.IsModal + "]");
                            Log.WriteLine("FleetInviteWindow.Caption: [" + regularWindow.Caption + "]");
                            Log.WriteLine("--------------------------------------------------");
                            //regularWindow.AnswerModal("Yes"); //this does not work for fleet invite windows! why?
                            continue;
                        }

                        Log.WriteLine("CleanupController: Found a fleet invite that did not contain CharacterToAcceptInvitesFrom [ " + Settings.Instance.CharacterToAcceptInvitesFrom + " ] or LeaderCharacterName [" + ESCache.Instance.EveAccount.LeaderCharacterName + "]");
                        Log.WriteLine("CleanupController: Found a fleet invite HTML: [ " + regularWindow.Html + " ]");
                        //regularWindow.AnswerModal("No"); //this does not work for fleet invite windows! why?
                    }
                    **/
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }
            }

            if (DebugConfig.DebugCleanup) Log.WriteLine("Checking Each window in Cache.Instance.Windows");

            foreach (DirectWindow window in ESCache.Instance.DirectEve.ModalWindows)
            {
                if (DebugConfig.DebugCleanup) Log.WriteLine("ModalWindow: Name [" + window.Name + "] Type [" + window.Type + "] IsKillable [" + window.IsKillable + "] isDialog [" + window.IsDialog + "] isModal [" + window.IsModal + "]");
                bool close = false;
                bool restart = false;
                bool gotoBaseNow = false;
                bool sayYes = false;
                bool sayOk = false;
                bool pause = false;
                bool quit = false;
                bool stackHangars = false;
                bool clearPocket = false;
                bool disableInstance = false;
                bool needHumanIntervention = false;
                bool notAllItemsCouldBeFitted = false;

                if (window.Html.Contains("You are too far away from the acceleration gate to activate it"))
                {
                    Time.Instance.NextActivateAction = DateTime.MinValue;
                    Log.WriteLine("Closing message about the gate being too far away...");
                    window.Close();
                }

                /**
                if (window.Name == "telecom")
                {
                    Log("Closing telecom message...");
                    Log("Content of telecom window (HTML): [" + (window.Html ?? string.Empty).Replace("\n", "").Replace("\r", "") +
                        "]");
                    window.Close();
                }
                **/

                if (window.IsModal || window.Name == "modal")
                    if (!string.IsNullOrEmpty(window.Html))
                    {
                        gotoBaseNow |= window.Html.Contains("for a short unscheduled reboot");
                        disableInstance |= window.Html.Contains("banned");
                        pause |= window.Html.Contains("Cannot move");

                        if (window.Type == "form.MessageBox" && window.IsDialog && window.IsModal && window.IsKillable)
                            sayOk |=
                                window.Html.Contains(
                                    "If you decline of fail a mission from an agent he/she might become displeased and lower your standing towards him/her. You can decline a mission every four hours without penalty");

                        close |= window.Html.Contains("Do you really want to quit now?");

                        close |= window.Html.Contains("Please make sure your characters are out of harm");
                        close |= window.Html.Contains("the servers are down for 30 minutes each day for maintenance and updates");

                        close |= window.Html.Contains("Item cannot be moved back to a loot container.");
                        close |= window.Html.Contains("you do not have the cargo space");
                        close |= window.Html.Contains("You are too far away from the acceleration gate to activate it!");
                        close |= window.Html.Contains("maximum distance is 2500 meters");
                        close |= window.Html.Contains("Broker found no match for your order");
                        close |= window.Html.Contains("All the weapons in this group are already full");

                        close |=
                            window.Html.Contains(
                                "If you decline of fail a mission from an agent he/she might become displeased and lower your standing towards him/her. You can decline a mission every four hours without penalty");
                        close |= window.Html.Contains("Do you wish to proceed with this dangerous action?");
                        close |= window.Html.Contains("weapons in that group are already full");
                        close |= window.Html.Contains("No rigs were added to or removed from the ship");
                        close |= window.Html.Contains("You can't fly your active ship into someone else's hangar");
                        close |= window.Html.Contains("You can't do this quite so fast");
                        clearPocket |= window.Html.Contains("This gate is locked!");

                        close |= window.Html.Contains("The Zbikoki's Hacker Card");
                        close |= window.Html.Contains(" units free.");
                        close |= window.Html.Contains("already full");
                        close |= window.Html.Contains("All the weapons in this group are already full");
                        close |=
                            window.Html.Contains(
                                "At any time you can log in to the account management page and change your trial account to a paying account");

                        close |= window.Html.ToLower().Contains("please make sure your characters are out of harms way");
                        close |= window.Html.ToLower().Contains("accepting connections");
                        close |= window.Html.ToLower().Contains("could not connect");
                        close |= window.Html.ToLower().Contains("the connection to the server was closed");
                        close |= window.Html.ToLower().Contains("server was closed");
                        close |= window.Html.ToLower().Contains("make sure your characters are out of harm");
                        close |= window.Html.ToLower().Contains("connection to server lost");
                        close |= window.Html.ToLower().Contains("the socket was closed");
                        close |= window.Html.ToLower().Contains("the specified proxy or server node");
                        close |= window.Html.ToLower().Contains("starting up");
                        close |= window.Html.ToLower().Contains("unable to connect to the selected server");
                        close |= window.Html.ToLower().Contains("could not connect to the specified address");
                        close |= window.Html.ToLower().Contains("connection timeout");
                        close |= window.Html.ToLower().Contains("the cluster is not currently accepting connections");
                        close |= window.Html.ToLower().Contains("your character is located within");
                        close |= window.Html.ToLower().Contains("the transport has not yet been connected");
                        close |= window.Html.ToLower().Contains("the user's connection has been usurped");
                        close |= window.Html.ToLower().Contains("the EVE cluster has reached its maximum user limit");
                        close |= window.Html.ToLower().Contains("the connection to the server was closed");
                        close |= window.Html.ToLower().Contains("client is already connecting to the server");
                        close |= window.Html.ToLower().Contains("client update is available and will now be installed");
                        close |= window.Html.ToLower().Contains("change your trial account to a paying account");
                        close |= window.Html.ToLower().Contains("Not all the items could be fitted");

                        restart |= window.Html.Contains("The user's connection has been usurped on the proxy");
                        restart |= window.Html.Contains("The connection to the server was closed");
                        restart |= window.Html.Contains("server was closed");
                        restart |= window.Html.Contains("The socket was closed");
                        restart |= window.Html.Contains("The connection was closed");
                        restart |= window.Html.Contains("Connection to server lost");
                        restart |= window.Html.Contains("The user connection has been usurped on the proxy");
                        restart |= window.Html.Contains("The transport has not yet been connected, or authentication was not successful");
                        restart |= window.Html.Contains("Your client has waited");
                        restart |= window.Html.Contains("This could mean the server is very loaded");
                        restart |= window.Html.Contains("Local cache is corrupt");
                        restart |= window.Html.Contains("Local session information is corrupt");
                        restart |= window.Html.ToLower().Contains("You are already performing a");
                        restart |= window.Html.ToLower().Contains("the socket was closed");
                        restart |= window.Html.ToLower().Contains("the connection was closed");
                        restart |= window.Html.ToLower().Contains("connection to server lost.");
                        restart |= window.Html.ToLower().Contains("local cache is corrupt");
                        restart |= window.Html.ToLower().Contains("The client's local session");
                        restart |= window.Html.ToLower().Contains("restart the client prior to logging in");

                        quit |= window.Html.ToLower().Contains("the cluster is shutting down");

                        sayYes |= window.Html.Contains("objectives requiring a total capacity");
                        sayYes |= window.Html.Contains("your ship only has space for");
                        sayYes |= window.Html.Contains("Are you sure you want to remove location");

                        sayYes |= window.Html.Contains("Are you sure you would like to decline this mission");
                        sayYes |= window.Html.Contains("has no other missions to offer right now. Are you sure you want to decline");
                        sayYes |= window.Html.Contains("You are about to remove a storyline mission from your journal");
                        sayYes |= window.Html.Contains("If you quit this mission you will lose standings with your agent");

                        sayOk |= window.Html.Contains("Are you sure you want to accept this offer?");
                        sayOk |= window.Html.Contains("You do not have an outstanding invitation to this fleet.");
                        sayOk |= window.Html.Contains("You have already selected a character for this session.");
                        sayOk |= window.Html.Contains("If you decline or fail a mission from an agent");
                        sayOk |= window.Html.Contains("The transport has not yet been connected, or authentication was not successful");
                        sayOk |= window.Html.ToLower().Contains("local session information is corrupt");

                        //errors that are repeatable and unavoidable even after a restart of eve/questor
                        needHumanIntervention |= window.Html.Contains("One or more mission objectives have not been completed");
                        needHumanIntervention |= window.Html.Contains("Please check your mission journal for further information");
                        sayOk |= window.Html.Contains("You have to be at the drop off location to deliver the items in person");
                        needHumanIntervention |= window.Html.Contains("cargo units would be required to complete this operation.");

                        stackHangars |= window.Html.Contains("as there are simply too many items here already");
                    }
                //else //non-modal windows
                //{
                //    notAllItemsCouldBeFitted |= window.Html.ToLower().Contains("Not all the items could be fitted".ToLower());
                //}

                if (State.CurrentArmState == ArmState.RepairShop || State.CurrentPanicState == PanicState.Panic)
                    sayOk |= window.Type.Contains("form.HybridWindow") && window.Caption.Contains("Set Quantity");

                if (restart || disableInstance)
                {
                    Log.WriteLine("Restarting eve...");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    string msg = string.Format("Connection lost on account [{0}]", ESCache.Instance.EveAccount.AccountName);
                    Log.WriteLine(msg);
                    WCFClient.Instance.GetPipeProxy.RemoteLog(msg);
                    Environment.Exit(0);
                    Environment.FailFast("");
                    return;
                }

                if (sayYes)
                {
                    Log.WriteLine("[sayYes] Found a window that needs 'yes' chosen...");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    if (!window.AnswerModal("Yes"))
                    {
                        Log.WriteLine("[sayYes] We can only press buttons on modal windows. trying to close instead");
                        window.Close();
                    }
                    continue;
                }

                if (sayOk)
                {
                    Log.WriteLine("[sayOk] Found a window that needs 'ok' chosen...");

                    if (window.Html == null)
                    {
                        Log.WriteLine("WINDOW HTML == NULL");
                    }
                    else
                    {
                        Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");

                        if (window.Html.Contains("Repairing these items will cost"))
                            doneUsingRepairWindow = true;
                        if (!window.AnswerModal("OK"))
                        {
                            Log.WriteLine("[sayOk] We can only press buttons on modal windows. trying to close instead");
                            window.Close();
                        }
                    }

                    continue;
                }

                if (stackHangars)
                {
                    if (!ESCache.Instance.StackHangar(ESCache.Instance.ItemHangar)) return;
                    if (Settings.Instance.UseCorpAmmoHangar)
                        if (!ESCache.Instance.StackHangar(ESCache.Instance.AmmoHangar)) return;
                    if (Settings.Instance.UseCorpLootHangar && Settings.Instance.LootCorpHangarDivisionNumber != Settings.Instance.AmmoCorpHangarDivisionNumber)
                        if (!ESCache.Instance.StackHangar(ESCache.Instance.LootHangar)) return;
                    continue;
                }

                if (gotoBaseNow)
                {
                    Log.WriteLine("[gotoBaseNow] Evidently the cluster is dieing... and CCP is restarting the server");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    State.CurrentCombatMissionBehaviorState = CombatMissionsBehaviorState.GotoBase;
                    ESCache.Instance.PauseAfterNextDock = true;
                    window.Close();
                    continue;
                }

                if (pause)
                {
                    Log.WriteLine("This window indicates an error fitting the ship. pausing");
                    ControllerManager.Instance.SetPause(true);
                }

                if (close)
                {
                    Log.WriteLine("[close] Closing modal window...");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    window.Close();
                    continue;
                }

                if (quit)
                {
                    Log.WriteLine("[quit] Closing modal window...");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    if (!window.AnswerModal("Quit"))
                    {
                        Log.WriteLine("[sayOk] We can only press buttons on modal windows. trying to close instead");
                        window.Close();
                    }
                    continue;
                }

                if (clearPocket)
                {
                    Log.WriteLine("[clearPocket] Closing modal window...");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    window.Close();
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.ReplaceMissionsActions), true);
                    continue;
                }

                if (notAllItemsCouldBeFitted)
                {
                    Log.WriteLine("[notAllItemsCouldBeFitted] Closing modal window...");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.notAllItemsCouldBeFitted), true);
                    window.Close();
                    return;
                }

                if (needHumanIntervention)
                {
                    Log.WriteLine("[needHumanIntervention] Closing modal window...");
                    Log.WriteLine("Content of modal window (HTML): [" + window.Html.Replace("\n", "").Replace("\r", "") + "]");
                    WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.needHumanIntervention), true);
                    window.Close();
                    return;
                }

                // Debug LOG
                //                Logging.Log("window.Name is: " + window.Name);
                //                Logging.Log("window.Html is: " + window.Html);
                //                Logging.Log("window.Caption is: " + window.Caption);
                //                Logging.Log("window.Type is: " + window.Type);
                //                Logging.Log("window.ID is: " + window.Id);
                //                Logging.Log("window.IsDialog is: " + window.IsDialog);
                //                Logging.Log("window.IsKillable is: " + window.IsKillable);
                //                Logging.Log("window.Viewmode is: " + window.ViewMode);

                if (ESCache.Instance.InSpace || ESCache.Instance.InStation)


                if (ESCache.Instance.InSpace)
                {
                    if (window.IsDialog && window.IsModal && window.Caption == "Duel Invitation")
                    {
                        // maybe close?
                    }

                    //sayYes |= window.Html.Contains(Settings.Instance.CharacterToAcceptInvitesFrom + " wants you to join their fleet");

                    if (window.Name.Contains("_ShipDroneBay_") && window.Caption == "Drone Bay")
                    {
                        if (Drones.UseDrones && ESCache.Instance.ActiveShip.GroupId != (int)Group.Shuttle &&
                            ESCache.Instance.ActiveShip.GroupId != (int)Group.Industrial &&
                            ESCache.Instance.ActiveShip.GroupId != (int)Group.TransportShip && _droneBayClosingAttempts <= 1)
                        {
                            _droneBayClosingAttempts++;
                            window.Close();
                        }
                    }
                    else
                    {
                        _droneBayClosingAttempts = 0;
                    }
                }
            }
        }

        public static void DebugModalWindows()
        {
            if (!LogEVEWindowDetails) return;

            try
            {
                //Log("Checkmodal windows called.");
                if (ESCache.Instance.Windows == null || !ESCache.Instance.Windows.Any())
                {
                    Log.WriteLine("CheckModalWindows: Cache.Instance.Windows returned null or empty");
                    return;
                }

                Log.WriteLine("Checking Each window in Cache.Instance.Windows");

                int windowNum = 0;
                foreach (DirectWindow window in ESCache.Instance.Windows)
                {
                    windowNum++;
                    Log.WriteLine("[" + windowNum + "] Debug_Window.Name: [" + window.Name + "]");
                    Log.WriteLine("[" + windowNum + "] Debug_Window.Html: [" + window.Html + "]");
                    Log.WriteLine("[" + windowNum + "] Debug_Window.Type: [" + window.Type + "]");
                    Log.WriteLine("[" + windowNum + "] Debug_Window.IsModal: [" + window.IsModal + "]");
                    Log.WriteLine("[" + windowNum + "] Debug_Window.Caption: [" + window.Caption + "]");
                    Log.WriteLine("--------------------------------------------------");
                }
            }
            catch (Exception ex)
            {
                Log.WriteLine("Exception: " + ex);
            }
            finally
            {
                LogEVEWindowDetails = false;
            }
        }

        public static void FormFleet()
        {
            if (!ESCache.Instance.InSpace && !ESCache.Instance.InStation)
                return;

            if (Time.Instance.QuestorStarted_DateTime.AddSeconds(25) > DateTime.UtcNow)
                return;

            if (Time.Instance.LastInWarp.AddSeconds(15) > DateTime.UtcNow)
                return;

            if (Time.Instance.LastFormFleetAttempt.AddSeconds(15) > DateTime.UtcNow)
                return;

            if (!ESCache.Instance.EveAccount.IsLeader)
                return;

            if (ESCache.Instance.EveAccount.SelectedController.ToLower().Contains("fleet".ToLower()) ||
                ESCache.Instance.EveAccount.SelectedController.ToLower().Contains("hydra".ToLower()) ||
                ESCache.Instance.EveAccount.SelectedController.ToLower().Contains("combatdontmove".ToLower()))
            {
                //
                // if we are not in a fleet, but we do have the fleet window open...
                //
                if (!ESCache.Instance.DirectEve.Session.InFleet && ESCache.Instance.FleetWindow != null)
                {
                    //
                    // form a fleet with ourselves
                    //
                    if (ESCache.Instance.DirectEve.FormNewFleet())
                    {
                        Time.Instance.LastFormFleetAttempt = DateTime.UtcNow;
                        Log.WriteLine("CleanupController: We are not yet in a fleet. Attempting to create a fleet now.");
                    }
                }

                return;
            }
        }

        //private string externalIP;

        public static string GetExternalIPAddress()
        {
            string result = string.Empty;
            try
            {
                using (var client = new System.Net.WebClient())
                {
                    client.Headers["User-Agent"] =
                    "Mozilla/4.0 (Compatible; Windows NT 5.1; MSIE 6.0) " +
                    "(compatible; MSIE 6.0; Windows NT 5.1; " +
                    ".NET CLR 1.1.4322; .NET CLR 2.0.50727)";

                    try
                    {
                        byte[] arr = client.DownloadData("http://checkip.amazonaws.com/");

                        string response = System.Text.Encoding.UTF8.GetString(arr);

                        result = response.Trim();
                    }
                    catch (WebException)
                    {
                    }
                }
            }
            catch
            {
            }

            if (string.IsNullOrEmpty(result))
            {
                try
                {
                    result = new WebClient().DownloadString("https://ipinfo.io/ip").Replace("\n", "");
                }
                catch
                {
                }
            }

            if (string.IsNullOrEmpty(result))
            {
                try
                {
                    result = new WebClient().DownloadString("https://api.ipify.org").Replace("\n", "");
                }
                catch
                {
                }
            }

            if (string.IsNullOrEmpty(result))
            {
                try
                {
                    result = new WebClient().DownloadString("https://icanhazip.com").Replace("\n", "");
                }
                catch
                {
                }
            }

            if (string.IsNullOrEmpty(result))
            {
                try
                {
                    result = new WebClient().DownloadString("https://wtfismyip.com/text").Replace("\n", "");
                }
                catch
                {
                }
            }

            if (string.IsNullOrEmpty(result))
            {
                try
                {
                    result = new WebClient().DownloadString("http://bot.whatismyipaddress.com/").Replace("\n", "");
                }
                catch
                {
                }
            }

            if (string.IsNullOrEmpty(result))
            {
                try
                {
                    string url = "http://checkip.dyndns.org";
                    System.Net.WebRequest req = System.Net.WebRequest.Create(url);
                    System.Net.WebResponse resp = req.GetResponse();
                    System.IO.StreamReader sr = new System.IO.StreamReader(resp.GetResponseStream());
                    string response = sr.ReadToEnd().Trim();
                    string[] a = response.Split(':');
                    string a2 = a[1].Substring(1);
                    string[] a3 = a2.Split('<');
                    result = a3[0];
                }
                catch (Exception ex)
                {
                    Log.WriteLine("Exception [" + ex + "]");
                }
            }

            return result;
        }

        public static void ProcessState()
        {
            if (DebugConfig.DebugDisableCleanup)
                return;

            if (ESCache.Instance.InSpace && !ESCache.Instance.EveAccount.NeedRepair && ESCache.Instance.ActiveShip != null && ESCache.Instance.ActiveShip.ArmorPercentage < 100 || ESCache.Instance.ActiveShip.StructurePercentage < 100)
                WCFClient.Instance.GetPipeProxy.SetEveAccountAttributeValue(ESCache.Instance.EveAccount.CharacterName, nameof(EveAccount.NeedRepair), true);

            CheckWindows();
            //FormFleet();
        }

            #endregion Methods
        }
    }