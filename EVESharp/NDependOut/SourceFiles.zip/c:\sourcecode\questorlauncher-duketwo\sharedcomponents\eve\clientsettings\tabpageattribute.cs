﻿using System;

namespace SharedComponents.EVE.ClientSettings
{
    [AttributeUsage(AttributeTargets.All)]
    public class TabPageAttribute : Attribute
    {
        #region Fields

        // Private fields.

        #endregion Fields

        #region Constructors

        public TabPageAttribute(string name)
        {
            Name = name;
        }

        #endregion Constructors

        #region Properties

        public virtual string Name { get; }

        #endregion Properties
    }
}